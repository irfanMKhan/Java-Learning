package com.reddot.ecrm.api.payload.response.payment;

import lombok.Data;

import java.io.Serializable;

@Data
public class QueryDepositAmountErrorResponse implements Serializable {
  private String transaction_id;

  private String code;

  private Object data;

  private String message;
}
