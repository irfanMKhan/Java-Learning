package com.reddot.ecrm.api.payload.response.contract.subscriber;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.lang.Integer;
import java.lang.Long;
import java.lang.String;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateCorporateSubscriberSubResponse implements Serializable {
  private CreateCorporateSubRspMsg CreateCorporateSubRspMsg;

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class CreateCorporateSubRspMsg implements Serializable {
    private RspHeader RspHeader;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor

    public static class RspHeader implements Serializable {
      private Long RspTime;

      private String ReturnCode;

      private String ReturnMsg;

      private Integer Version;
    }
  }
}
