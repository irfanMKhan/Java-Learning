package com.reddot.ecrm.CustomerValidation.model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class CustomerType {
    private String MSISDN,OPERATOR, CONNECTION_TYPE;
    private boolean STATUS;

    public boolean getSTATUS() {
        return STATUS;
    }

    public void setSTATUS(boolean STATUS) {
        this.STATUS = STATUS;
    }
}
