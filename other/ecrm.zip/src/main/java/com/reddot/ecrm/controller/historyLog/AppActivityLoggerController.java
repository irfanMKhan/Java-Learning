package com.reddot.ecrm.controller.historyLog;

import com.reddot.ecrm.menu.MenuViewer;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

@RequestMapping("/log/activityLog")
@Controller
@RequiredArgsConstructor
public class AppActivityLoggerController {

    @GetMapping("")
    public String viewAppActivityLog() {
        return "redirect:/log/activityLog/list";
    }

    @GetMapping("/list")
    String viewAppActivityLogList(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "App Log");
        return "log_view/app_activity_log";
    }
}
