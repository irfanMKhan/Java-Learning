package com.reddot.ecrm.controller.swapSim;

import com.reddot.ecrm.dto.cdr.CDRSearchDTO;
import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.service.customerInfo.CustomerInfoService;
import com.reddot.ecrm.service.swapSim.SwapSimService;
import com.reddot.ecrm.spring_config.session.SessionManager;
import lombok.RequiredArgsConstructor;
import net.sf.jasperreports.engine.JRException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Controller
@RequiredArgsConstructor
@RequestMapping("/swapSim/swap")
public class SwapSimController {
    private final SwapSimService swapSimService;

    @GetMapping(value = "/search")
    public String search(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        List<CompanyEntity> listOfCompany = swapSimService.GetAllCompanyNameWithContactTablePICMapped(request);
        MDUserModel mdUserModel = SessionManager.getUserDetails(request);

        model.put("title", "Swap Sim");
        model.addAttribute("listOfCompany", listOfCompany);
        model.put("userType", mdUserModel.getUSER_TYPE().toUpperCase().toString());
        return "swapSim/index";
    }

    @GetMapping(value = "/view")
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        List<CompanyEntity> listOfCompany = swapSimService.GetAllCompanyNameWithContactTablePICMapped(request);
        MDUserModel mdUserModel = SessionManager.getUserDetails(request);

        model.put("title", "Swap Sim");
        model.addAttribute("listOfCompany", listOfCompany);
        model.put("userType", mdUserModel.getUSER_TYPE().toUpperCase().toString());
        return "swapSim/view";
    }

    @RequestMapping(value = "/download", method = RequestMethod.POST)
    @ResponseBody
    public void download(HttpServletRequest request, HttpServletResponse response, @RequestParam(value = "fileName", required = true) String fileName) throws Exception {
        swapSimService.downloadFile(request, response, fileName);
    }
}
