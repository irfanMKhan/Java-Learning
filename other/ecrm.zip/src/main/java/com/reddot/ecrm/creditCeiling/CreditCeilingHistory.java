package com.reddot.ecrm.creditCeiling;

import lombok.*;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Entity
@Table(name = "tbl_credit_ceiling_history", schema = "ecrm")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class CreditCeilingHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "active")
    private boolean active;

    @Column(name = "company_id")
    private Long companyId;

    @Column(name = "company_name")
    private String companyName;

    @Column(name = "type_id")
    private Long typeId;

    @Column(name = "type_name")
    private String typeName;

    @Column(name = "credit_ceiling")
    private double creditCeiling;

    @Column(name = "credit_limit")
    private double creditLimit;

    @Column(name = "amount")
    private double amount;

    @Column(name = "new_cc")
    private double newCC;

    @Column(name = "reference_id")
    private Long referenceId;

    @Column(name = "reference_name")
    private String referenceName;

//    @Column(name = "status_id")
//    private Long statusId;
//
//    @Column(name = "status_name")
//    private String statusName;

    @Column(name = "transaction_no", unique = true)
    private String transactionNo;

    @Column(name = "approval_status")
    private String approvalStatus;

//    @Column(name = "expiration_date")
//    private Long expirationDate;

//    @Column(name = "attachment")
//    private String attachment;

    @Column(name = "created_at")
    private Long createdAt;

    @Column(name = "created_at_dt")
    private Timestamp createdAtDt;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_by_username")
    private String createdByUsername;

    @Column(name = "updated_at")
    private Long updatedAt;

    @Column(name = "updated_at_dt")
    private Timestamp updatedAtDt;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_by_username")
    private String updatedByUsername;
}
