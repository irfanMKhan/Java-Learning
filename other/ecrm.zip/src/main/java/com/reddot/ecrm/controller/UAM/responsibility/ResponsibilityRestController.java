package com.reddot.ecrm.controller.UAM.responsibility;

import com.google.gson.Gson;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.model.menu.MDMenuModel;
import com.reddot.ecrm.model.responsibility.ResponsibilityModel;
import com.reddot.ecrm.service.responsibility.ResponsibilityService;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RequestMapping(value = "/api/responsibility", method = RequestMethod.GET)
@RestController
public class ResponsibilityRestController {
    @Autowired
    private ResponsibilityService service;

    @GetMapping("/DTData")
    public DataTablesOutput<ResponsibilityModel> DTData(@Valid DataTablesInput input, HttpServletRequest request,
                                                @RequestParam(value = "searchText", required = false) String customQuery,
                                                @RequestParam(value = "customSearchCriteria", required = false) String customSearchCriteria){
        if (customSearchCriteria == null) {
            customSearchCriteria = "";
        }

        if (Utility.isColumnSpecificSearch(input.getColumnsAsMap())) {
            customQuery = "";
        }
        return service.DTData(input, request, customSearchCriteria, customQuery);
    }

    @GetMapping("/getData")
    public CommonRestResponse getResponsibilityById(@RequestParam String id, HttpServletRequest request){
        String respID = new Gson().fromJson(id, String.class);
        return service.getResponsibilityById(respID, request);
    }

    @GetMapping("/all")
    public CommonRestResponse getAllResponsibility(){
        return service.getAllResponsibility();
    }

    @PostMapping("/addResponsibility")
    public CommonRestResponse addResponsibilityFunction(@RequestBody String respData, HttpServletRequest request){
        ResponsibilityModel responsibilityModel = new Gson().fromJson(respData, ResponsibilityModel.class);
        return service.addResFunction(responsibilityModel, request);
    }

    @PostMapping("/updateResponsibility")
    public CommonRestResponse updateResponsibilityFunction(@RequestBody String respData, HttpServletRequest request){
        ResponsibilityModel responsibilityModel = new Gson().fromJson(respData, ResponsibilityModel.class);
        return service.updateResFunction(responsibilityModel, request);
    }


}
