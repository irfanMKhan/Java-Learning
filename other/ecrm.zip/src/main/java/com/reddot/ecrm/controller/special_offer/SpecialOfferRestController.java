package com.reddot.ecrm.controller.special_offer;

import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.special_offer.SpecialOfferService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/special-offer/rest")
@RequiredArgsConstructor
public class SpecialOfferRestController {
    @Autowired
    SpecialOfferService specialOfferService;

    @PostMapping("/get/allOfferDataByCompanyId")
    public CommonRestResponse getAllOfferDataByCompanyId(@RequestBody Long companyId) {
        return specialOfferService.getAllOfferListByCompanyId(companyId);
    }

    @PostMapping("/get/allOfferDataByCompanyName")
    public CommonRestResponse getAllOfferDataByCompanyName(@RequestBody String companyName) {
        return specialOfferService.getAllOfferListByCompanyName(companyName);
    }
}
