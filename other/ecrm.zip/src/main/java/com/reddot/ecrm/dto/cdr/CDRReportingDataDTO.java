package com.reddot.ecrm.dto.cdr;

import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CDRReportingDataDTO {
    private String fromDate;
    private String toDate;
    private String printDate;
    private String fileType;
    private String usageType;
    private String fileName;

    private String accountNumber;
    private String address;
    private String image;
    private List<SampleDummyData> dataList;

}
