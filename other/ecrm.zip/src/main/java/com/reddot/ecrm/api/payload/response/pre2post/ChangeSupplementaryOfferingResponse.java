package com.reddot.ecrm.api.payload.response.pre2post;

import lombok.Data;

import java.io.Serializable;

@Data
public class ChangeSupplementaryOfferingResponse implements Serializable {
    private ChangeSupplementaryOfferingRspMsg ChangeSupplementaryOfferingRspMsg;

    @Data
    public static class ChangeSupplementaryOfferingRspMsg implements Serializable {
        private RspHeader RspHeader;

        @Data
        public static class RspHeader implements Serializable {
            private Long RspTime;

            private String ReturnCode;

            private String ReturnMsg;

            private Integer Version;
        }
    }
}
