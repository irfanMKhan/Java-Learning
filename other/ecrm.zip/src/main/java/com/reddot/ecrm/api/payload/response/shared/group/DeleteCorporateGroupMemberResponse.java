package com.reddot.ecrm.api.payload.response.shared.group;

import lombok.Data;

import java.io.Serializable;
import java.lang.Integer;
import java.lang.Long;
import java.lang.String;

@Data
public class DeleteCorporateGroupMemberResponse implements Serializable {
  private DeleteCorporateGroupMemberRspMsg DeleteCorporateGroupMemberRspMsg;

  @Data
  public static class DeleteCorporateGroupMemberRspMsg implements Serializable {
    private RspHeader RspHeader;

    @Data
    public static class RspHeader implements Serializable {
      private Long RspTime;

      private String ReturnCode;

      private String ReturnMsg;

      private Integer Version;
    }
  }
}
