package com.reddot.ecrm.controller.notification;

import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.notification.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/notification/rest")
public class NotificationRestController {
    @Autowired
    NotificationService notificationService;


    @GetMapping("/getAllNotificationData")
    public CommonRestResponse getAllNotificationData(HttpServletRequest request) {
        return notificationService.getNotificationAllData(request);
    }

}
