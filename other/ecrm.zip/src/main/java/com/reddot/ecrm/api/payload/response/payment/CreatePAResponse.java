package com.reddot.ecrm.api.payload.response.payment;

import lombok.Data;

import java.io.Serializable;

@Data
public class CreatePAResponse implements Serializable {
  private String code;

  private String message;

  private Data data;

  @lombok.Data
  public static class Data implements Serializable {
    private String PAId;
  }
  private String transaction_id;
}
