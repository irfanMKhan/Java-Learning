package com.reddot.ecrm.api.payload.response.payment;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class QueryDepositAmountResponse implements Serializable {
  private String transaction_id;

  private String code;

  private Data data;

  private String message;

  @lombok.Data
  public static class Data implements Serializable {
    private QueryBalance QueryBalance;

    @lombok.Data
    public static class QueryBalance implements Serializable {
      private AcctList AcctList;

      @lombok.Data
      public static class AcctList implements Serializable {
        private AccountCredit AccountCredit;

        private String AcctKey;

        private List<BalanceResult> BalanceResult;

        @lombok.Data
        public static class AccountCredit implements Serializable {
          private String CreditLimitTypeName;

          private CreditAmountInfo CreditAmountInfo;

          private String TotalCreditAmount;

          private String CreditLimitType;

          private String TotalUsageAmount;

          private String TotalRemainAmount;

          private String CurrencyID;

          @lombok.Data
          public static class CreditAmountInfo implements Serializable {
            private String CreditInstID;

            private String EffectiveTime;

            private String Amount;

            private String ExpireTime;

            private String LimitClass;
          }
        }

        @lombok.Data
        public static class BalanceResult implements Serializable {
          private String DepositFlag;

          private String BalanceTypeName;

          private String ReservedAmount;

          private String BalanceType;

          private String RefundFlag;

          private List<BalanceDetail> BalanceDetail;

          private String TotalAmount;

          private String CurrencyID;

          @lombok.Data
          public static class BalanceDetail implements Serializable {
            private String EffectiveTime;

            private String BalanceInstanceID;

            private String InitialAmount;

            private String Amount;

            private String ExpireTime;
          }
        }
      }
    }
  }
}
