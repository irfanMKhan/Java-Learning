package com.reddot.ecrm.controller;

import com.reddot.ecrm.menu.MenuViewer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Controller
@RequestMapping("/language")
public class LanguageChangeController {

    @Autowired
    private MessageSource messageSource;

    @GetMapping
    public String language(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Change Language");
        return "languageChange/languageChangePage";
    }

    @PostMapping("/changeLanguage")
    @ResponseBody
    public Map<String, String> changeLanguage(@RequestParam("locale") String locale, HttpSession session) throws IOException {
        session.setAttribute(SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME, new Locale(locale));

        Map<String, String> response = new HashMap<>();

        System.out.println(messageSource);
//        while (messageSource.getMessage())


        response.put("title", messageSource.getMessage("welcome.title", null, new Locale(locale)));
        response.put("message", messageSource.getMessage("welcome.message", null, new Locale(locale)));
        return response;
    }
}
