package com.reddot.ecrm.dto.contact;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ContactDTO {
    private String id;
    private String tempNO;
    private String salutation;
    private String salutationApiValue;
    private String salutationText;
    private String name;
    private String lastName;
    private String position;
    private String personType;
    private String personTypeText;
    private String mobile;
    private String email;
    private String dateOfBirth;
    private String[] products;
    private String productsText;
    private Boolean webPortal;
    private Boolean notification;

    private Boolean isCRContract;
    private Long companyId;
    private String companyName;
    private Long userId;
    private String userName;

    private String contractNumber;
    private Long contractId;
    private Long opportunityId;
    private String opportunityNumber;

    private String createBy;
    private String createByName;
    private LocalDateTime createDate;
    private LocalDate createdDateOnly;
    private String updateBy;
    private String updateByName;
    private LocalDateTime updateDate;
    private LocalDate updatedDateOnly;
    private String deleteBy;
    private String deleteByName;
    private LocalDateTime deleteDate;
    private LocalDate deletedDateOnly;
    private Boolean isChanged;

    private String certificationNoApiValue;
    private String certificationNo;
    private String certificationType;
    private String certificationTypeName;
}
