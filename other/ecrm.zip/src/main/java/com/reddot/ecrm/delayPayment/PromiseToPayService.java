package com.reddot.ecrm.delayPayment;

import com.reddot.ecrm.api.SmartAxiataAPI;
import com.reddot.ecrm.api.payload.request.payment.CreatePAMultiInvoiceRequest;
import com.reddot.ecrm.delayPayment.rest.dto.*;
import com.reddot.ecrm.deposit.GetAllMasterAccByCompanyIdReqBody;
import com.reddot.ecrm.deposit.GetAllMasterAccByCompanyNameReqBody;
import com.reddot.ecrm.dto.attachment.AttachmentDTO;
import com.reddot.ecrm.dto.httpServletRequest.HttpServletRequestDto;
import com.reddot.ecrm.entity.approval.ApprovalFlowEntity;
import com.reddot.ecrm.entity.approval.ApprovalRequestEntity;
import com.reddot.ecrm.entity.attachment.AttachmentEntity;
import com.reddot.ecrm.entity.company.CompanyAccountEntity;
import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.entity.msisdn.MsisdnEntity;
import com.reddot.ecrm.enum_config.approval.ApprovalEnum;
import com.reddot.ecrm.enum_config.approval.ApprovalForEnum;
import com.reddot.ecrm.enum_config.bulk.BulkProcessFileTypeEnum;
import com.reddot.ecrm.enum_config.cr.CRStatusEnum;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.module.commonConfig.CommonConfigRepo;
import com.reddot.ecrm.repository.approval.ApprovalFlowRepo;
import com.reddot.ecrm.repository.attachment.AttachmentRepository;
import com.reddot.ecrm.repository.company.CompanyAccountRepo;
import com.reddot.ecrm.repository.company.CompanyRepository;
import com.reddot.ecrm.repository.msisdn.MsisdnRepository;
import com.reddot.ecrm.sbGeneralMethodCollection.GeneralFuntionalities;
import com.reddot.ecrm.service.approval.ApprovalRequestService;
import com.reddot.ecrm.spring_config.session.SessionManager;
import com.reddot.ecrm.util.Utility;
import com.reddot.ecrm.util.unique_id_generate.UniqueIDGenerator;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import static java.lang.Math.toIntExact;

@Service
public class PromiseToPayService {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    @Autowired
    private ApprovalFlowRepo approvalFlowRepo;
    @Autowired
    private ApprovalRequestService approvalRequestService;

    @Autowired
    private PromiseToPayRepo promiseToPayRepo;

    @Autowired
    private PromiseToPayInvoiceMappingRepo promiseToPayInvoiceMappingRepo;

    @Autowired
    private CommonConfigRepo commonConfigRepo;

    @Autowired
    private CompanyRepository companyRepository;

    @Autowired
    private CompanyAccountRepo companyAccountRepo;

    @Autowired
    private MsisdnRepository msisdnRepository;

    @Autowired
    private SmartAxiataAPI smartAxiataAPI;

    @Autowired
    private AttachmentRepository attachmentRepository;

    @Autowired
    private GeneralFuntionalities generalFuntionalities;

    static String getDDMMYYYY(String dateString) {
        String yyyy = "";
        String mm = "";
        String dd = "";
        for (int i = 0; i < 4; i++) {
            yyyy = yyyy + dateString.charAt(i);
        }
        for (int i = 4; i < 6; i++) {
            mm = mm + dateString.charAt(i);
        }
        for (int i = 6; i < 8; i++) {
            dd = dd + dateString.charAt(i);
        }
        return dd + "/" + mm + "/" + yyyy;
    }

    public ResponseEntity<?> addPromiseToPay(HttpServletRequest httpServletRequest, PromiseToPayAddReqBody reqBody) {

        PromiseToPay promiseToPay = savePromiseToPay(reqBody);

        // promiseToPay.getApprovalStatus().equals(CRStatusEnum.Created.toString()

        if (reqBody.getTransType().equals("DNT")) {
            doPromiseToPayDetailSavingActivityForTransTypeDNT(promiseToPay, reqBody, httpServletRequest);
        } else if (reqBody.getTransType().equals("BLL")) {
            doPromiseToPayDetailSavingActivityForTransTypeBLL(promiseToPay, reqBody, httpServletRequest);
        }

//        List<PromiseToPayInvoiceMappingReqDTO> promiseToPayInvoiceMappingList = reqBody.getPromiseToPayInvoiceMappingList();
//
//        long totalPAAmount = 0;
//        List<CreatePAMultiInvoiceRequest.CreatePARequest.PAInvoiceInfo> paInvoiceInfoList = new ArrayList<>();
//
//        String primaryIdentity = "";
//
//        PromiseToPayInvoiceMapping promiseToPayInvoiceMapping;
//        for (PromiseToPayInvoiceMappingReqDTO reqDTO : promiseToPayInvoiceMappingList) {
//
//            if (reqDTO.getStatus().equals("O") && reqDTO.getTransType().equals("DNT")) {
//                promiseToPayInvoiceMapping = new PromiseToPayInvoiceMapping();
//
//                promiseToPayInvoiceMapping.setPromiseToPayId(promiseToPay.getId());
//                promiseToPayInvoiceMapping.setAcctKey(reqDTO.getAcctKey());
//                promiseToPayInvoiceMapping.setCustKey(reqDTO.getCustKey());
//                promiseToPayInvoiceMapping.setSubKey(reqDTO.getSubKey());
//                promiseToPayInvoiceMapping.setPrimaryIdentity(reqDTO.getPrimaryIdentity());
//
//                //
//                primaryIdentity = reqDTO.getPrimaryIdentity();
//                //
//
//                promiseToPayInvoiceMapping.setTransType(reqDTO.getTransType());
//                promiseToPayInvoiceMapping.setInvoiceID(reqDTO.getInvoiceID());
//
//                promiseToPayInvoiceMapping.setInvoiceNo(reqDTO.getInvoiceNo());
//
//                promiseToPayInvoiceMapping.setBillCycleID(reqDTO.getBillCycleID());
//                promiseToPayInvoiceMapping.setBillCycleBeginTime(reqDTO.getBillCycleBeginTime());
//                promiseToPayInvoiceMapping.setBillCycleEndTime(reqDTO.getBillCycleEndTime());
//                promiseToPayInvoiceMapping.setInvoiceAmount(reqDTO.getInvoiceAmount());
//                promiseToPayInvoiceMapping.setOpenAmount(reqDTO.getOpenAmount());
//                promiseToPayInvoiceMapping.setDisputeAmount(reqDTO.getDisputeAmount());
//                promiseToPayInvoiceMapping.setCurrencyId(reqDTO.getCurrencyId());
//                promiseToPayInvoiceMapping.setInvoiceDate(reqDTO.getInvoiceDate());
//                promiseToPayInvoiceMapping.setDueDate(reqDTO.getDueDate());
//                promiseToPayInvoiceMapping.setStatus(reqDTO.getStatus());
//
//                promiseToPayInvoiceMapping.setInvoiceDetailInvoiceID(reqDTO.getInvoiceDetailInvoiceID());
//                promiseToPayInvoiceMapping.setServiceCategory(reqDTO.getServiceCategory());
//                promiseToPayInvoiceMapping.setChargeCode(reqDTO.getChargeCode());
//                promiseToPayInvoiceMapping.setChargeAmount(reqDTO.getChargeAmount());
//
//                promiseToPayInvoiceMapping.setAgreedAmount(reqDTO.getAgreedAmount());
//
//                promiseToPayInvoiceMappingRepo.save(promiseToPayInvoiceMapping);
//            }
//
//        }
//
//        // promiseToPay.setAgreedPaidDate(reqBody.getPromiseToPay().getAgreedPaidDate());
//        // promiseToPay.setAgreedPaidAmt(String.valueOf(totalPAAmount));
//        promiseToPay.setTransactionId(generalFuntionalities.generateTransactionID());
//        promiseToPay.setPrimaryIdentity(primaryIdentity);

        // Attachment Save --> starts here
//        MDUserModel user = SessionManager.getUserDetails(httpServletRequest);
//        ModelMapper mapper = new ModelMapper();
//        List<AttachmentEntity> attachmentEntityList = new ArrayList<>();
//        List<AttachmentDTO> attachmentDTOList = reqBody.getAttachmentList();
//        for (AttachmentDTO attachmentDTO : attachmentDTOList) {
//
//            AttachmentEntity attachment = new AttachmentEntity();
//            mapper.map(attachmentDTO, attachment);
//            attachment.setIsFinalSave(true);
//            attachment.setCreateBy(user.getID().toString());
//            attachment.setCreateByName(user.getLOGIN_NAME());
//            attachment.setModulePrimaryId(promiseToPay.getId());
//            attachment.setModuleTableName(BulkProcessFileTypeEnum.Delay_payment.getKey());
//            attachmentEntityList.add(attachment);
//
//        }
//
//        if (attachmentEntityList.size() > 0) {
//            attachmentRepository.saveAll(attachmentEntityList);
//        }
        // Attachment Save --> ends here

//        if (reqBody.getTransType().equals("DNT")) {
//            promiseToPay.setSucceeded(true);
//            promiseToPayRepo.save(promiseToPay);
//            return new ResponseEntity<>("Promise to pay successfully created with Promise To Pay Invoice Mapping....", HttpStatus.OK);
//        }

        // for createPA 3rd party api call
//        if (reqBody.getTransType().equals("BILL")) {
//            CreatePAMultiInvoiceRequest createPAMultiInvoiceRequest = new CreatePAMultiInvoiceRequest();
//
//            createPAMultiInvoiceRequest.setTransaction_id(generateTransactionIdForCreatePAReq());
//
//            com.reddot.ecrm.api.payload.request.payment.CreatePAMultiInvoiceRequest.CreatePARequest createPARequest = new CreatePAMultiInvoiceRequest.CreatePARequest();
//            createPARequest.setPAExternalID("1001");
//            createPARequest.setPAType(1);
//            createPARequest.setTotalPAAmount(String.valueOf(totalPAAmount));
//            createPARequest.setPAInvoiceInfo(paInvoiceInfoList);
//            createPARequest.setPAReminderFlag("0");
//
//            List<CreatePAMultiInvoiceRequest.CreatePARequest.PADetailInfo> paDetailInfoList = new ArrayList<>();
//
//            CreatePAMultiInvoiceRequest.CreatePARequest.PADetailInfo paDetailInfo = null;
//            paDetailInfo.setAgreedPaidAmt(String.valueOf(totalPAAmount));
//
//            String agreedPaidDate = reqBody.getPromiseToPay().getAgreedPaidDate();
//            String agreedPaidDateFormatted = "";
//
//            String dd = "";
//            String mm = "";
//            String yyyy = "";
//            for (int i = 0; i < agreedPaidDate.length(); i++) {
//                if (i == 0 || i == 1) {
//                    dd = dd + agreedPaidDate.charAt(i);
//                } else if (i == 3 || i == 4) {
//                    mm = mm + agreedPaidDate.charAt(i);
//                } else if (i == 6 || i == 7 || i == 8 || i == 9) {
//                    yyyy = yyyy + agreedPaidDate.charAt(i);
//                }
//            }
//
//            agreedPaidDateFormatted = yyyy + mm + dd + "000000";
//
//            paDetailInfo.setAgreedPaidDate(agreedPaidDateFormatted);
//            paDetailInfo.setCurrencyId("1153");
//            paDetailInfo.setRemark(reqBody.getPromiseToPay().getRemark());
//
//            paDetailInfoList.add(paDetailInfo);
//
//            createPARequest.setPADetailInfo(paDetailInfoList);
//            createPAMultiInvoiceRequest.setCreatePARequest(createPARequest);
//
//            smartAxiataAPI.createPAMultipleInvoice(createPAMultiInvoiceRequest);
//
//            if (smartAxiataAPI.createPAMultipleInvoice(createPAMultiInvoiceRequest).equals("118110885") || smartAxiataAPI.createPAMultipleInvoice(createPAMultiInvoiceRequest).equals("118111206")) {
//                promiseToPay.setSucceeded(false);
//                promiseToPayRepo.save(promiseToPay);
//            } else if (smartAxiataAPI.createPAMultipleInvoice(createPAMultiInvoiceRequest).equals("0")) {
//                promiseToPay.setSucceeded(true);
//                promiseToPayRepo.save(promiseToPay);
//            }
//        }
        // createPA 3rd party api call ends

        return new ResponseEntity<>("Promise to pay successfully created with Promise To Pay Invoice Mapping....", HttpStatus.OK);
    }

    private void doPromiseToPayDetailSavingActivityForTransTypeBLL(PromiseToPay promiseToPay, PromiseToPayAddReqBody reqBody, HttpServletRequest httpServletRequest) {


        List<PromiseToPayInvoiceMappingReqDTO> promiseToPayInvoiceMappingList = reqBody.getInvoiceList();

        long totalPAAmount = 0;
        List<CreatePAMultiInvoiceRequest.CreatePARequest.PAInvoiceInfo> paInvoiceInfoList = new ArrayList<>();

//        String primaryIdentity = "";

        PromiseToPayInvoiceMapping promiseToPayInvoiceMapping;
        for (PromiseToPayInvoiceMappingReqDTO reqDTO : promiseToPayInvoiceMappingList) {

            if (reqDTO.getStatus().equals("O") && reqDTO.getTransType().equals("BLL")) {
                promiseToPayInvoiceMapping = new PromiseToPayInvoiceMapping();

                promiseToPayInvoiceMapping.setPromiseToPayId(promiseToPay.getId());
                promiseToPayInvoiceMapping.setAcctKey(reqDTO.getAcctKey());
                promiseToPayInvoiceMapping.setCustKey(reqDTO.getCustKey());
                promiseToPayInvoiceMapping.setSubKey(reqDTO.getSubKey());
                promiseToPayInvoiceMapping.setPrimaryIdentity(reqDTO.getPrimaryIdentity());

                //
//                primaryIdentity = reqDTO.getPrimaryIdentity();
                //

                promiseToPayInvoiceMapping.setTransType(reqDTO.getTransType());
                promiseToPayInvoiceMapping.setInvoiceID(reqDTO.getInvoiceID());

                promiseToPayInvoiceMapping.setInvoiceNo(reqDTO.getInvoiceNo());

                promiseToPayInvoiceMapping.setBillCycleID(reqDTO.getBillCycleID());
                promiseToPayInvoiceMapping.setBillCycleBeginTime(reqDTO.getBillCycleBeginTime());
                promiseToPayInvoiceMapping.setBillCycleEndTime(reqDTO.getBillCycleEndTime());
                promiseToPayInvoiceMapping.setInvoiceAmount(reqDTO.getInvoiceAmount());
                promiseToPayInvoiceMapping.setOpenAmount(reqDTO.getOpenAmount());
                promiseToPayInvoiceMapping.setDisputeAmount(reqDTO.getDisputeAmount());
                promiseToPayInvoiceMapping.setCurrencyId(reqDTO.getCurrencyId());
                promiseToPayInvoiceMapping.setInvoiceDate(reqDTO.getInvoiceDate());
                promiseToPayInvoiceMapping.setDueDate(reqDTO.getDueDate());
                promiseToPayInvoiceMapping.setStatus(reqDTO.getStatus());

                promiseToPayInvoiceMapping.setInvoiceDetailInvoiceID(reqDTO.getInvoiceDetailInvoiceID());
                promiseToPayInvoiceMapping.setServiceCategory(reqDTO.getServiceCategory());
                promiseToPayInvoiceMapping.setChargeCode(reqDTO.getChargeCode());
                promiseToPayInvoiceMapping.setChargeAmount(reqDTO.getChargeAmount());

                promiseToPayInvoiceMapping.setAgreedAmount(reqDTO.getAgreedAmount());

                promiseToPayInvoiceMappingRepo.save(promiseToPayInvoiceMapping);
            }
        }

//        if (reqBody.getTransType().equals("BILL")) {
        CreatePAMultiInvoiceRequest createPAMultiInvoiceRequest = new CreatePAMultiInvoiceRequest();

        createPAMultiInvoiceRequest.setTransaction_id(generateTransactionIdForCreatePAReq());

        com.reddot.ecrm.api.payload.request.payment.CreatePAMultiInvoiceRequest.CreatePARequest createPARequest = new CreatePAMultiInvoiceRequest.CreatePARequest();
        createPARequest.setPAExternalID("1001");
        createPARequest.setPAType(1);
        createPARequest.setTotalPAAmount(String.valueOf(totalPAAmount));
//            createPARequest.setPAInvoiceInfo(paInvoiceInfoList);
        createPARequest.setPAReminderFlag("0");

        List<CreatePAMultiInvoiceRequest.CreatePARequest.PADetailInfo> paDetailInfoList = new ArrayList<>();

        CreatePAMultiInvoiceRequest.CreatePARequest.PADetailInfo paDetailInfo = null;
//            paDetailInfo.setAgreedPaidAmt(String.valueOf(totalPAAmount));

//        String agreedPaidDate = reqBody.getPromiseToPay().getAgreedPaidDate();
//        String agreedPaidDateFormatted = "";
//
//        String dd = "";
//        String mm = "";
//        String yyyy = "";
//        for (int i = 0; i < agreedPaidDate.length(); i++) {
//            if (i == 0 || i == 1) {
//                dd = dd + agreedPaidDate.charAt(i);
//            } else if (i == 3 || i == 4) {
//                mm = mm + agreedPaidDate.charAt(i);
//            } else if (i == 6 || i == 7 || i == 8 || i == 9) {
//                yyyy = yyyy + agreedPaidDate.charAt(i);
//            }
//        }
//
//        agreedPaidDateFormatted = yyyy + mm + dd + "000000";
//
//        paDetailInfo.setAgreedPaidDate(agreedPaidDateFormatted);
//        paDetailInfo.setCurrencyId("1153");
//        paDetailInfo.setRemark(reqBody.getPromiseToPay().getRemark());

        paDetailInfoList.add(paDetailInfo);

        createPARequest.setPADetailInfo(paDetailInfoList);
        createPAMultiInvoiceRequest.setCreatePARequest(createPARequest);

        smartAxiataAPI.createPAMultipleInvoice(createPAMultiInvoiceRequest);

        if (smartAxiataAPI.createPAMultipleInvoice(createPAMultiInvoiceRequest).equals("118110885") || smartAxiataAPI.createPAMultipleInvoice(createPAMultiInvoiceRequest).equals("118111206")) {
//                promiseToPay.setSucceeded(false);
            promiseToPayRepo.save(promiseToPay);
        } else if (smartAxiataAPI.createPAMultipleInvoice(createPAMultiInvoiceRequest).equals("0")) {
//                promiseToPay.setSucceeded(true);
            promiseToPayRepo.save(promiseToPay);
        }
//        }
    }

    private String generateTransactionIdForCreatePAReq() {
        return "";
    }

    private void checkApproval(PromiseToPayInvoiceMapping promiseToPayInvoiceMapping, HttpServletRequest httpServletRequest) {
        Boolean HasApproval = false;
        String transactionId = UniqueIDGenerator.getNextUniqueNumberOnly();
        Long tenantId = Utility.loggedInTenantId(httpServletRequest);
        try {
            ApprovalRequestEntity approvalRequestEntity = new ApprovalRequestEntity();
            Optional<ApprovalFlowEntity> approvalFlowEntity = approvalFlowRepo.findByNameAndTenantId(ApprovalEnum.PTP_REQUEST.getKey(), tenantId);
            if (approvalFlowEntity.isPresent()) {
                approvalRequestEntity.setApprovalFlowId(approvalFlowEntity.get().getId());
                approvalRequestEntity.setApprovalFlowName(ApprovalEnum.PTP_REQUEST.getKey());
                approvalRequestEntity.setHasRequestedAmount(false);
                approvalRequestEntity.setApprovalFor(ApprovalForEnum.Delay_Payment_Request.getKey());
                approvalRequestEntity.setIsCategoryType(false);
                approvalRequestEntity.setRequestDetailsId(promiseToPayInvoiceMapping.getId());
                approvalRequestEntity.setRequestTransactionId(transactionId);
                approvalRequestEntity.setCompanyName(promiseToPayInvoiceMapping.getCompanyName());

                String description = "";

                // todo: calculate the days in Integer
                // Integer intervalOfDays = 15;

                //
                Date invoiceDate;
                Date dueDate;
                DateFormat formatter = new SimpleDateFormat("dd/MM/yy");
                try {
                    invoiceDate = formatter.parse(getDDMMYYYY(promiseToPayInvoiceMapping.getInvoiceDate()));
                    dueDate = formatter.parse(getDDMMYYYY(promiseToPayInvoiceMapping.getDueDate()));
                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }

                long duration = dueDate.getTime() - invoiceDate.getTime();
                long diffInDays = TimeUnit.MILLISECONDS.toDays(duration);
                //

                Integer intervalOfDays = Integer.valueOf(toIntExact(diffInDays));

                approvalRequestEntity.setRequestedNumberTypeData(intervalOfDays);
                approvalRequestEntity.setUnitType(approvalFlowEntity.get().getUnit());

                HasApproval = true;

                if (HasApproval) {
                    description = "Delay Payment Request";
                    approvalRequestEntity.setRequestDescription(description);
                    HttpServletRequestDto request = Utility.createHttpServletDTO(httpServletRequest);
                    HasApproval = (Boolean) approvalRequestService.addRequestData(approvalRequestEntity, request).getData();
                    promiseToPayInvoiceMapping.setApprovalStatus(CRStatusEnum.Pending.toString());
                    promiseToPayInvoiceMappingRepo.saveAndFlush(promiseToPayInvoiceMapping);
                }

            } else {
                logger.info("%s Approval Flow not exists.", ApprovalEnum.PTP_REQUEST.getKey());
            }

        } catch (Exception e) {
            logger.error(String.format("DelayPaymentRequest:ApprovalCheckForDelayPaymentRequest() Error: %s", e.getMessage()));
        }
    }

    public PromiseToPay savePromiseToPay(PromiseToPayAddReqBody reqBody) {
        PromiseToPay promiseToPay = new PromiseToPay();
        promiseToPay.setAccountCode(reqBody.getAccountCode());
        promiseToPay.setTransType(reqBody.getTransType());
        promiseToPay.setPrimaryIdentity(reqBody.getInvoiceList().get(0).getPrimaryIdentity());
        promiseToPay.setTransactionId(generalFuntionalities.generateTransactionID());
        // primarily saving it to get the id
        // since this id will be used in PromiseToPayInvoiceMapping(tbl_promise_to_pay_detail)
        promiseToPayRepo.save(promiseToPay);
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        return promiseToPay;
    }

    private void doPromiseToPayDetailSavingActivityForTransTypeDNT(PromiseToPay promiseToPay, PromiseToPayAddReqBody reqBody, HttpServletRequest httpServletRequest) {
        List<PromiseToPayInvoiceMappingReqDTO> promiseToPayInvoiceMappingList = reqBody.getInvoiceList();

        PromiseToPayInvoiceMapping promiseToPayInvoiceMapping;
        for (PromiseToPayInvoiceMappingReqDTO reqDTO : promiseToPayInvoiceMappingList) {

            if (reqDTO.getStatus().equals("O") && reqDTO.getTransType().equals("DNT")) {
                promiseToPayInvoiceMapping = new PromiseToPayInvoiceMapping();

                promiseToPayInvoiceMapping.setPromiseToPayId(promiseToPay.getId());
                promiseToPayInvoiceMapping.setAcctKey(reqDTO.getAcctKey());
                promiseToPayInvoiceMapping.setCustKey(reqDTO.getCustKey());
                promiseToPayInvoiceMapping.setSubKey(reqDTO.getSubKey());
                promiseToPayInvoiceMapping.setPrimaryIdentity(reqDTO.getPrimaryIdentity());
                promiseToPayInvoiceMapping.setTransType(reqDTO.getTransType());
                promiseToPayInvoiceMapping.setInvoiceID(reqDTO.getInvoiceID());
                promiseToPayInvoiceMapping.setInvoiceNo(reqDTO.getInvoiceNo());
                promiseToPayInvoiceMapping.setBillCycleID(reqDTO.getBillCycleID());
                promiseToPayInvoiceMapping.setBillCycleBeginTime(reqDTO.getBillCycleBeginTime());
                promiseToPayInvoiceMapping.setBillCycleEndTime(reqDTO.getBillCycleEndTime());
                promiseToPayInvoiceMapping.setInvoiceAmount(reqDTO.getInvoiceAmount());
                promiseToPayInvoiceMapping.setOpenAmount(reqDTO.getOpenAmount());
                promiseToPayInvoiceMapping.setDisputeAmount(reqDTO.getDisputeAmount());
                promiseToPayInvoiceMapping.setCurrencyId(reqDTO.getCurrencyId());

                promiseToPayInvoiceMapping.setInvoiceDate(reqDTO.getInvoiceDate());
                promiseToPayInvoiceMapping.setDueDate(reqDTO.getDueDate());

//
//                System.out.println("invoice date --> " + reqDTO.getInvoiceDate());
//                System.out.println("due date --> " + reqDTO.getDueDate());
//
//                System.out.println(getDDMMYYYY(reqDTO.getInvoiceDate()));
//                System.out.println(getDDMMYYYY(reqDTO.getDueDate()));
//
//                Date invoiceDate;
//                Date dueDate;
//                DateFormat formatter = new SimpleDateFormat("dd/MM/yy");
//                try {
//                    invoiceDate = formatter.parse(getDDMMYYYY(reqDTO.getInvoiceDate()));
//                    dueDate = formatter.parse(getDDMMYYYY(reqDTO.getDueDate()));
//                } catch (ParseException e) {
//                    throw new RuntimeException(e);
//                }
//
//                long duration = dueDate.getTime() - invoiceDate.getTime();
//                long diffInDays = TimeUnit.MILLISECONDS.toDays(duration);

                promiseToPayInvoiceMapping.setStatus(reqDTO.getStatus());
                promiseToPayInvoiceMapping.setInvoiceDetailInvoiceID(reqDTO.getInvoiceDetailInvoiceID());
                promiseToPayInvoiceMapping.setServiceCategory(reqDTO.getServiceCategory());
                promiseToPayInvoiceMapping.setChargeCode(reqDTO.getChargeCode());
                promiseToPayInvoiceMapping.setChargeAmount(reqDTO.getChargeAmount());
                promiseToPayInvoiceMapping.setAgreedAmount(reqDTO.getAgreedAmount());
                promiseToPayInvoiceMapping.setApprovalStatus(CRStatusEnum.Created.toString());

                promiseToPayInvoiceMappingRepo.save(promiseToPayInvoiceMapping);

                checkApproval(promiseToPayInvoiceMapping, httpServletRequest);
            }
        }
        doAttachmentSaveActivityForDelayPayment(promiseToPay, reqBody, httpServletRequest);
        promiseToPayRepo.save(promiseToPay);
    }

    private void doAttachmentSaveActivityForDelayPayment(PromiseToPay promiseToPay, PromiseToPayAddReqBody reqBody, HttpServletRequest httpServletRequest) {
        MDUserModel user = SessionManager.getUserDetails(httpServletRequest);
        ModelMapper mapper = new ModelMapper();
        List<AttachmentEntity> attachmentEntityList = new ArrayList<>();
        List<AttachmentDTO> attachmentDTOList = reqBody.getAttachmentList();
        for (AttachmentDTO attachmentDTO : attachmentDTOList) {

            AttachmentEntity attachment = new AttachmentEntity();
            mapper.map(attachmentDTO, attachment);
            attachment.setIsFinalSave(true);
            attachment.setCreateBy(user.getID().toString());
            attachment.setCreateByName(user.getLOGIN_NAME());
            attachment.setModulePrimaryId(promiseToPay.getId());
            attachment.setModuleTableName(BulkProcessFileTypeEnum.Delay_payment.getKey());
            attachmentEntityList.add(attachment);
        }

        if (attachmentEntityList.size() > 0) {
            attachmentRepository.saveAll(attachmentEntityList);
        }
    }

//    public ResponseEntity<?> getAllFromPromiseToPay(HttpServletRequest httpServletRequest) {
//        List<PromiseToPayInvoiceMapping> promiseToPayInvoiceMappingList = new ArrayList<>();
//        promiseToPayInvoiceMappingList = promiseToPayInvoiceMappingRepo.findAll();
//
//        PromiseToPay promiseToPay;
//        PromiseToPayListEntireListResponseObj obj;
//        List<PromiseToPayListEntireListResponseObj> finalResp = new ArrayList<>();
//
//        for (PromiseToPayInvoiceMapping promise : promiseToPayInvoiceMappingList) {
//            obj = new PromiseToPayListEntireListResponseObj();
//
//            obj.setId(promise.getId());
//            obj.setPromiseToPayId(promise.getPromiseToPayId());
//            obj.setAcctKey(promise.getAcctKey());
//            obj.setCustKey(promise.getCustKey());
//            obj.setPrimaryIdentity(promise.getPrimaryIdentity());
//            obj.setInvoiceID(promise.getInvoiceID());
//            obj.setInvoiceNo(promise.getInvoiceNo());
//            obj.setBillCycleID(promise.getBillCycleID());
//            obj.setBillCycleBeginTime(promise.getBillCycleBeginTime());
//            obj.setBillCycleEndTime(promise.getBillCycleEndTime());
//            obj.setInvoiceAmount(promise.getInvoiceAmount());
//            obj.setOpenAmount(promise.getOpenAmount());
//            obj.setDisputeAmount(promise.getDisputeAmount());
//            obj.setInvoiceDate(promise.getInvoiceDate());
//            obj.setDueDate(promise.getDueDate());
//
//            promiseToPay = new PromiseToPay();
//
//            Optional<PromiseToPay> optionalPromiseToPay = promiseToPayRepo.findById(promise.getPromiseToPayId());
//            promiseToPay = optionalPromiseToPay.get();
//
//            obj.setDueAmount(promiseToPay.getDueAmount());
//            obj.setStatusId(promiseToPay.getStatusId());
//            obj.setStatusName(promiseToPay.getStatusName());
//            obj.setRemarks(promiseToPay.getRemarks());
//            obj.setDateOfAgreedPayment(promiseToPay.getDateOfAgreedPayment());
//            obj.setEffectiveDate(promiseToPay.getEffectiveDate());
//            obj.setAttachment(promiseToPay.getAttachment());
//
//            finalResp.add(obj);
//        }
//
//        return new ResponseEntity<>(finalResp, HttpStatus.OK);
//    }

    public ResponseEntity<?> getAllFromPromiseToPay(HttpServletRequest httpServletRequest) {
        List<PromiseToPay> promiseToPayList = new ArrayList<>();
        promiseToPayList = promiseToPayRepo.findAll();

        List<PromiseToPayResponseDTO> response = new ArrayList<>();

        PromiseToPayResponseDTO dto;

        for (PromiseToPay promiseToPay : promiseToPayList) {
            dto = new PromiseToPayResponseDTO();

            dto.setId(String.valueOf(promiseToPay.getId()));
            dto.setAccountCode(promiseToPay.getAccountCode());
            dto.setTransType(promiseToPay.getTransType());
            dto.setTransactionId(promiseToPay.getTransactionId());
            dto.setPrimaryIdentity(promiseToPay.getPrimaryIdentity());
//            dto.setAgreedPaidDate(promiseToPay.getAgreedPaidDate());
//            dto.setAgreedPaidAmt(promiseToPay.getAgreedPaidAmt());
            //dto.setRemark(promiseToPay.getRemark());

            response.add(dto);
        }

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    public ResponseEntity<?> getAllFromPromiseToPayByPromiseId(HttpServletRequest httpServletRequest, String promiseToPayId) {
        List<PromiseToPayInvoiceMapping> promiseToPayInvoiceMappingList = new ArrayList<>();
        promiseToPayInvoiceMappingList = promiseToPayInvoiceMappingRepo.findAllByPromiseToPayId(Long.valueOf(promiseToPayId));
        return new ResponseEntity<>(promiseToPayInvoiceMappingList, HttpStatus.OK);
    }

    public ResponseEntity<?> getAllCompany(HttpServletRequest httpServletRequest) {
        List<CompanyEntity> list = companyRepository.findAll();
        return new ResponseEntity<>(list, HttpStatus.OK);
    }

    public ResponseEntity<?> getAllMasterAccByCompanyId(HttpServletRequest httpServletRequest, GetAllMasterAccByCompanyIdReqBody reqBody) {
        List<CompanyAccountEntity> companyAccountEntityList = new ArrayList<>();
        companyAccountEntityList = companyAccountRepo.findAllByCompanyIdAndIsParentCorporateAccount(Long.valueOf(reqBody.getCompanyId()), true);
        return new ResponseEntity<>(companyAccountEntityList, HttpStatus.OK);
    }

    public ResponseEntity<?> getAllMasterAccByCompanyName(HttpServletRequest httpServletRequest, GetAllMasterAccByCompanyNameReqBody reqBody) {
        List<CompanyAccountEntity> companyAccountEntityList = new ArrayList<>();
        companyAccountEntityList = companyAccountRepo.findAllByCompanyNameAndIsParentCorporateAccount(reqBody.getCompanyName(), true);
        // companyAccountEntityList = companyAccountRepo.findAllByCompanyName(reqBody.getCompanyName());
        return new ResponseEntity<>(companyAccountEntityList, HttpStatus.OK);
    }

    public ResponseEntity<?> getAllMsisdnByCompanyId(HttpServletRequest httpServletRequest, GetAllMsisdnByCompanyAccIdReqBody reqBody) {
        List<MsisdnEntity> msisdnEntityList = new ArrayList<>();

        Long companyId = 0L;

        MDUserModel mdUserModel = SessionManager.getUserDetails(httpServletRequest);
        if (mdUserModel != null && mdUserModel.getUSER_TYPE().equals("PIC")) {
            companyId = mdUserModel.getCOMPANY_ID();
        } else {
            companyId = Long.valueOf(reqBody.getCompanyId());
        }

        msisdnEntityList = msisdnRepository.findAllByCompanyId(companyId);
        return new ResponseEntity<>(msisdnEntityList, HttpStatus.OK);
    }

    public ResponseEntity<?> getCompanyByPIC(HttpServletRequest httpServletRequest) {
        MDUserModel mdUserModel = SessionManager.getUserDetails(httpServletRequest);

        DTOCompanyOrPICResp resp = new DTOCompanyOrPICResp();

        if (mdUserModel.getCOMPANY_ID() == null) {
            List<CompanyEntity> companyEntityList = new ArrayList<>();
            companyEntityList = companyRepository.findAllByActive(true);
            resp.setKeyword("NO_PIC");
            resp.setList(companyEntityList);
            return new ResponseEntity<>(resp, HttpStatus.OK);
        }

        Optional<CompanyEntity> companyEntityOptional = companyRepository.findById(mdUserModel.getCOMPANY_ID());
        resp.setKeyword("PIC");
        List<CompanyEntity> temp = new ArrayList<>();
        temp.add(companyEntityOptional.get());
        resp.setKeyword("PIC");
        resp.setList(temp);
        return new ResponseEntity<>(resp, HttpStatus.OK);
    }

    public ResponseEntity<?> getAllPromiseToPayByAccountCode(HttpServletRequest httpServletRequest, GetAllPromiseToPayByAccountCode reqBody) {
        List<PromiseToPay> promiseToPayList = promiseToPayRepo.findAllByAccountCode(reqBody.getAccountCode());
        return new ResponseEntity<>(promiseToPayList, HttpStatus.OK);
    }

    public ResponseEntity<?> getAllMsisdnByCompanyAccCode(HttpServletRequest httpServletRequest, GetAllMsisdnByCompanyAccCode reqBody) {
        List<MsisdnEntity> msisdnEntityList = new ArrayList<>();
        msisdnEntityList = msisdnRepository.findAllByMsisdnAccountCode(reqBody.getMsisdnAccountCode());
        return new ResponseEntity<>(msisdnEntityList, HttpStatus.OK);
    }

//    public ResponseEntity<?> getAllPromiseToPayDetailByPromiseToPayId(HttpServletRequest httpServletRequest, GetAllPromiseToPayDetailByPromiseToPayId reqBody) {
//        try {
//            List<PromiseToPayInvoiceMapping> promiseToPayInvoiceMappingList = new ArrayList<>();
//
//            promiseToPayInvoiceMappingList = promiseToPayInvoiceMappingRepo.findAllByPromiseToPayId()
//
//        } catch (Exception e) {
//            return new ResponseEntity<>(e, HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//        return null;
//    }

//    public ResponseEntity<?> getCompanyByPIC(HttpServletRequest httpServletRequest) {
//        MDUserModel mdUserModel = SessionManager.getUserDetails(httpServletRequest);
//        Optional<CompanyEntity> companyEntityOptional = companyRepository.findById(mdUserModel.getCOMPANY_ID());
//        if (!companyEntityOptional.isPresent())
//            return new ResponseEntity<>("bugbug", HttpStatus.OK);
//        System.out.println(companyEntityOptional.get().getId() + " :: " + companyEntityOptional.get().getName());
//        return new ResponseEntity<>(companyEntityOptional.get(), HttpStatus.OK);
//    }
}
