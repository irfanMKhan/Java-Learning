package com.reddot.ecrm.controller.eshop;

import com.reddot.ecrm.entity.eshop.SimKit;
import com.reddot.ecrm.service.eshop.SimKitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.security.Principal;

@RestController
@RequestMapping("/crm/eShop")
public class SimKitRestController {

    @Autowired
    private SimKitService simKitService;

    @GetMapping("/dataTable/simKitData")
    public DataTablesOutput<SimKit> simKitData(@Valid DataTablesInput input, HttpServletRequest request, @RequestParam(value = "searchText", required = false) String searchText, @RequestParam(value = "searchCol", required = false) String searchCol, @RequestParam(value = "simKitPurchaseNo", required = false) String purchaseNo) {
        return simKitService.getDataTableSimKit(input, request, searchText, searchCol, purchaseNo);
    }

    @GetMapping(value = "/deleteSimKitData")
    public String deleteSimKitData(ModelMap model, HttpServletRequest request, Principal principal, @RequestParam(value = "id", required = false) Long id) {
        return simKitService.deleteSimKitModalDataById(id);

    }

    @PostMapping("/addSimKit")
    public String addSimKit(HttpServletRequest request, @RequestBody SimKit data) {
        return simKitService.addSimKit(request, data);


    }
}
