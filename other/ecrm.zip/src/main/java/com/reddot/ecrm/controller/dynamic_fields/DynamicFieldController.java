package com.reddot.ecrm.controller.dynamic_fields;

import com.reddot.ecrm.enum_config.dynamicfield.FeatureEnum;
import com.reddot.ecrm.enum_config.dynamicfield.ModuleEnum;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.repository.dynamicfield.DynamicFieldRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;

@Controller
@RequestMapping("/dynamic")
public class DynamicFieldController {
    @Autowired
    private DynamicFieldRepository dynamicFieldRepository;
    @Autowired
    private CommonRepository commonRepository;

    @GetMapping
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        model.put("title", "Dynamic Field Add");
        return "dynamicfiled/dynamicfieldadd";
    }

    @GetMapping("/addnewfield")
    public String viewPageAddNewField(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        ModuleEnum[] moduleEnums = ModuleEnum.values();
        FeatureEnum[] featureEnums = FeatureEnum.values();



//        System.out.println(commonRepository.CommoGetData("select * from tbl_dynamic_data"));
//        System.out.println(dynamicFieldRepository.findAll());

        System.out.println(Arrays.toString(ModuleEnum.values()));
        model.addAttribute("moduleEnums", moduleEnums);
        model.addAttribute("featureEnums", featureEnums);
        model.put("title", "Dynamic Field Add Page");
        return "dynamicfiled/dynamicfieldaddform";
    }
}
