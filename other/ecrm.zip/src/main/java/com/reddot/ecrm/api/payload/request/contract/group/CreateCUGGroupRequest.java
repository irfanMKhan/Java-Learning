package com.reddot.ecrm.api.payload.request.contract.group;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.lang.String;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateCUGGroupRequest implements Serializable {
  @NotNull(message = "transaction_id is required.")
  @NotEmpty(message = "transaction_id is required.")
  private String transaction_id;

  @Valid
  @NotNull(message = "CreateCUGGroupReq is required.")
  private CreateCUGGroupReq CreateCUGGroupReq;

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class CreateCUGGroupReq implements Serializable {
    @Valid
    @NotNull(message = "Order is required.")
    private Order Order;

    @Valid
    @NotNull(message = "CUG is required.")
    private CUG CUG;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Order implements Serializable {
      @NotNull(message = "OrderType is required.")
      @NotEmpty(message = "OrderType is required.")
      private String OrderType;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class CUG implements Serializable {
      @NotNull(message = "GroupName is required.")
      @NotEmpty(message = "GroupName is required.")
      private String GroupName;

      @NotNull(message = "MaxGroupMember is required.")
      @NotEmpty(message = "MaxGroupMember is required.")
      private String MaxGroupMember;

      @Valid
      @NotNull(message = "AdditionalProperty is required.")
      private List<AdditionalProperty> AdditionalProperty;

      @Valid
      @NotNull(message = "PrimaryOffering is required")
      private PrimaryOffering PrimaryOffering;

      @Data
      @AllArgsConstructor
      @NoArgsConstructor
      public static class PrimaryOffering implements Serializable {
        @Valid
        @NotNull(message = "OfferingId is required.")
        private OfferingId OfferingId;
        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class OfferingId implements Serializable {
          @NotNull(message = "OfferingId is required.")
          @NotEmpty(message = "OfferingId is required.")
          private String OfferingId;
        }
      }

      @Data
      @AllArgsConstructor
      @NoArgsConstructor
      public static class AdditionalProperty implements Serializable {
        @NotNull(message = "Value is required.")
        @NotEmpty(message = "Value is required.")
        private String Value;

        @NotNull(message = "Code is required.")
        @NotEmpty(message = "Code is required.")
        private String Code;
      }
    }
  }
}
