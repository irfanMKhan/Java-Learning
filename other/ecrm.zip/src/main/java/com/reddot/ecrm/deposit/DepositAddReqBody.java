package com.reddot.ecrm.deposit;

import com.reddot.ecrm.dto.attachment.AttachmentDTO;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class DepositAddReqBody {
    private String companyId;
    private String companyName;
    private String companyAccountCode;
    private String currentDepositAmount;
    private String requestedDepositAmount;
    private String newDepositAmount;
    private String statusId;
    private String statusName;
    private String attachment;
    private List<AttachmentDTO> attachmentList;
}