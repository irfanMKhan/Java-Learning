package com.reddot.ecrm.controller.bulk_files;

import com.reddot.ecrm.dto.bulk.FileDetailsDTO;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.bulkfile.BulkFileService;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/bulkfile/rest")
@RequiredArgsConstructor
@Slf4j
public class BulkFilesRestController {
    private final BulkFileService bulkFileService;
    @Value("${bulk.filelocation}")
    String bulkFileLocation;

    @PostMapping("/getAllBulkFilesWithoutCompanyId")
    public CommonRestResponse getAllBulkFilesWithoutCompanyId(@RequestParam("processId") Integer processId, HttpServletRequest request) {

        return bulkFileService.getAllBulkFilesByUserIDAndProcessID(request, processId);
    }

    @PostMapping("/getAllBulkFiles")
    public CommonRestResponse getAllBulkFiles(@RequestParam("companyId") Long companyId,
                                              @RequestParam("processId") Integer processId, HttpServletRequest request) {

        return bulkFileService.getAllBulkFilesByCompanyIdAndUserID(companyId, request, processId);
    }


    @PostMapping("/getAllBulkFileDetails")
    public CommonRestResponse getAllBulkFileDetails(@RequestParam(value = "companyId") Long companyId,
                                                    @RequestParam("fileId") Long fileId,
                                                    @RequestParam("processId") Integer processId, HttpServletRequest request) {
        return bulkFileService.getAllBulkFileDetailsByCompanyIdAndUserIDAndFileId(companyId, request, fileId, processId);
    }

    @PostMapping("/getAllBulkFileDetailsWithoutCompanyId")
    public CommonRestResponse getAllBulkFileDetailsWithOutCompanyId(@RequestParam("fileId") Long fileId, @RequestParam("processId") Integer processId, HttpServletRequest request) {
        return bulkFileService.getAllBulkFileDetailsByUserIDAndFileId(request, fileId, processId);
    }


    @PostMapping("/upload/bulkFileNewNumber")
    public CommonRestResponse bulkUpload(HttpServletRequest request, @RequestParam("file") MultipartFile file,
                                         @RequestParam("processNow") String processNow, @RequestParam("companyName") String companyName,
                                         @RequestParam("processDate") String processDate, @RequestParam("companyId") String companyId,
                                         @RequestParam("processTypeId") String processTypeId, @RequestParam("processType") String processType
    ) throws ServletException, IOException {

        return bulkFileService.addBulkFileDataNew(request, file, processDate, processNow, companyId, companyName, processType, processTypeId);
    }

    @PostMapping("/download/excelFile")
    public synchronized ResponseEntity<?> downloadExcelFile(@RequestBody String processName) throws IOException {
        try {
            String filename = Utility.getCurrentTimestamp() + "_" + processName + ".xlsx";

            String PATH = Utility.demo_excel_file_full_path;
            String excelTemplateLocation = PATH + "DemoTemplate.xlsx";

            Boolean isFileCreationSuccess = bulkFileService.createTemplateFileBasedOnProcessTypeName(processName, filename);
            log.info("Excel Template File Location {} and createFileSuccess {}", excelTemplateLocation, isFileCreationSuccess);
            if (isFileCreationSuccess) {
                InputStreamResource simpleFile = new InputStreamResource(new FileInputStream(excelTemplateLocation));

                if (simpleFile != null && simpleFile.exists()) {

                    return ResponseEntity.ok()
                            .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
                            .contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
                            .body(simpleFile);
                } else {
                    log.info("File Not Found. Failed to create the Template Excel file ");
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                            .body("Failed to create the Template Excel file.");
                }

            } else {
                log.info("isFileCreationSuccess failed. Failed to create the Template Excel file ");
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body("Failed to create the Template Excel file.");
            }

        } catch (Exception e) {
            log.info("downloadExcelFile() Error {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to create the Template Excel file.");
        }
    }

    @GetMapping("/downloadFile")
    public void downloadFile(@RequestParam("fileId") Long fileId,
                             @RequestParam("uuid") String uuid,
                             HttpServletRequest request, HttpServletResponse response) {

        System.out.println(fileId);
        System.out.println(uuid);
        bulkFileService.downloadZipFile(response, uuid);
        //return new CommonRestResponse();
    }


    @PostMapping("/getAllBulkFilesByFilePath")
    public List<FileDetailsDTO> getAllBulkFilesListByFilePath(@RequestBody String filePathToSearch) {
        return bulkFileService.getAllBulkFilesList(filePathToSearch);
    }

    @GetMapping("/getAllBulkFilesByFilePath")
    public List<FileDetailsDTO> getAllBulkFilesDirectory() {
        return bulkFileService.getAllBulkFilesDirectory();
    }


//    @PostMapping("/download/excelFileByFullPath")
//    public synchronized ResponseEntity<?> downloadExcelFileByFileFullPath(@RequestParam("fileFullPath") String fileFullPath) throws IOException {
//        try {
//            String filename = Utility.getCurrentTimestamp() + "_" + processName + ".xlsx";
//
//            String PATH = Utility.demo_excel_file_full_path;
//            String excelTemplateLocation = PATH + "DemoTemplate.xlsx";
//
//            Boolean isFileCreationSuccess = bulkFileService.createTemplateFileBasedOnProcessTypeName(processName, filename);
//            log.info("Excel Template File Location {} and createFileSuccess {}", excelTemplateLocation, isFileCreationSuccess);
//            if (isFileCreationSuccess) {
//                InputStreamResource simpleFile = new InputStreamResource(new FileInputStream(excelTemplateLocation));
//
//                if (simpleFile != null && simpleFile.exists()) {
//
//                    return ResponseEntity.ok()
//                            .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
//                            .contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
//                            .body(simpleFile);
//                } else {
//                    log.info("File Not Found. Failed to create the Template Excel file ");
//                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                            .body("Failed to create the Template Excel file.");
//                }
//
//            } else {
//                log.info("isFileCreationSuccess failed. Failed to create the Template Excel file ");
//                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                        .body("Failed to create the Template Excel file.");
//            }
//
//        } catch (Exception e) {
//            log.info("downloadExcelFile() Error {}", e.getMessage());
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body("Failed to create the Template Excel file.");
//        }
//    }

    @PostMapping("/delete/excelFileByFullPath")
    public synchronized String deleteExcelFileByFileFullPath(@RequestBody String fileFullPath) throws IOException {
        try {
            boolean isDeleteSuccess = bulkFileService.deleteFileByFullPath(fileFullPath);
        } catch (Exception e) {
            log.info("downloadExcelFile() Error {}", e.getMessage());
        }
        return "deleted";
    }


    @PostMapping("/upload/bulkTemplateWithDirectory")
    public CommonRestResponse bulkTemplateUploadWithDirectory(HttpServletRequest request, @RequestParam("file") MultipartFile file,
                                                              @RequestParam("fileUploadDirectory") String fileUploadDirectory
    ) throws ServletException, IOException {

        return bulkFileService.bulkTemplateUploadWithDirectory(request, file, fileUploadDirectory);
    }


    @GetMapping("/download/excelTemplateFile")
    public synchronized ResponseEntity<?> downloadExcelTemplateFile(@RequestParam("processName") String processName) throws IOException {
        try {
            String filename = Utility.getCurrentTimestamp() + "_" + processName + ".xlsx";

            InputStreamResource simpleFile = bulkFileService.getExcelTemplateFileByFileProcessName(processName);
            if (simpleFile != null && simpleFile.exists()) {
                return ResponseEntity.ok()
                        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
                        .contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
                        .body(simpleFile);
            } else {
                log.info("downloadExcelFile() Error {} No file Found.");
                return ResponseEntity.status(HttpStatus.NO_CONTENT)
                        .body("downloadExcelFile() Error: No file Found.");
            }

        } catch (Exception e) {
            log.info("downloadExcelFile() Error {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to create the Template Excel file.");
        }
    }
}
