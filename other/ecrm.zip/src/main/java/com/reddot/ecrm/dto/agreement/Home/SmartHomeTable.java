package com.reddot.ecrm.dto.agreement.Home;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
public class SmartHomeTable {
    private String itemDescription;
    private String basic;
    private String standard;
    private String premium;
}
