package com.reddot.ecrm.dto.agreement.postpaid;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class PostPaidAnnexDataDTO {
    private Integer no;
    private String number;
    private String plan;
    private String totalCredit;
    private String maxMonthlyFee;
    private String upfrontFee;
    private String depositOrGuaranteeLetter;
    private String offering;
    private String device;
    private String effectiveDate;

}
