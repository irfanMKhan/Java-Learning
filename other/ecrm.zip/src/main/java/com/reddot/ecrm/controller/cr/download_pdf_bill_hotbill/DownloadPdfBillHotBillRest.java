package com.reddot.ecrm.controller.cr.download_pdf_bill_hotbill;

import com.reddot.ecrm.service.cr.download_pdf_bill_hotbill.DownloadPdfBillHotbillService;
import com.reddot.ecrm.service.report_generator.accountReceiptForCustomerGenerator.AccountReceiptForCustomerService;
import com.reddot.ecrm.service.report_generator.exportAccountantHotBillReceiptGenerator.ExportAccountantHotBillReceiptService;
import com.reddot.ecrm.service.report_generator.payMyBillReceiptGenerator.PayMyBillReceiptGeneratorService;
import com.reddot.ecrm.service.report_generator.statement_note.StatementNoteGeneratorService;
import net.sf.jasperreports.engine.JRException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import org.springframework.core.io.ClassPathResource;
import org.springframework.web.bind.annotation.GetMapping;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@RestController
@RequestMapping("/api/cr/downloadPdfBillHotBill")
public class DownloadPdfBillHotBillRest {


    private DownloadPdfBillHotbillService downloadBillService;
    private PayMyBillReceiptGeneratorService myBillReceiptGeneratorService;
    private ExportAccountantHotBillReceiptService exportAccountantHotBillReceiptService;
    private AccountReceiptForCustomerService accountReceiptForCustomerService;
    private StatementNoteGeneratorService statementNoteGeneratorService;


    @Autowired
    public DownloadPdfBillHotBillRest(DownloadPdfBillHotbillService downloadBillService,
                                      PayMyBillReceiptGeneratorService myBillReceiptGeneratorService,
                                      ExportAccountantHotBillReceiptService exportAccountantHotBillReceiptService,
                                      AccountReceiptForCustomerService accountReceiptForCustomerService,
                                      StatementNoteGeneratorService statementNoteGeneratorService) {
        this.downloadBillService = downloadBillService;
        this.myBillReceiptGeneratorService = myBillReceiptGeneratorService;
        this.exportAccountantHotBillReceiptService = exportAccountantHotBillReceiptService;
        this.accountReceiptForCustomerService = accountReceiptForCustomerService;
        this.statementNoteGeneratorService = statementNoteGeneratorService;
    }

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());


//    @GetMapping("/fetchFile")
//    public ResponseEntity<?> downloadPdfBillHotbill() throws IOException {
//
////        CommonRestResponse commonRestResponse = new CommonRestResponse();
//        String storedFileLocation = "Bills/temp.pdf";
//
//        // Load the file from the resource folder
//        Resource resource = new ClassPathResource(storedFileLocation);
//
//        InputStreamResource pdfBillHotbill = new InputStreamResource(resource.getInputStream());
//
//
//        return ResponseEntity.ok()
//                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + resource.getFilename())
//                .contentType(MediaType.parseMediaType("application/pdf"))
//                .body(pdfBillHotbill);
//    }


    @GetMapping("/exportPayMyBillReport")
    public void exportMyBillReport(HttpServletResponse response) throws JRException {
        logger.info("Downloading exportPayMyBillReport report");

        try {
            myBillReceiptGeneratorService.generatePayMyBillReport(response);
        }
        catch (JRException e)
        {
            throw new RuntimeException(e);
        }

    }


    @GetMapping("/exportAccountantHotBillReceipt")
    public void exportAccountantHotBillReceipt(HttpServletResponse response) throws JRException {
        logger.info("Downloading exportAccountantHotBillReceipt report");

        try {
            exportAccountantHotBillReceiptService.generateExportAccountantHotBill(response);
        }
        catch (JRException e)
        {
            throw new RuntimeException(e);
        }

    }

    @GetMapping("/exportAccountantReceiptForCustomerDeposit")
    public void exportAccountantReceiptForCustomerDeposit(HttpServletResponse response) throws JRException {
        logger.info("Downloading exportAccountantHotBillReceipt report");

        try {
            accountReceiptForCustomerService.generateAccountReceiptForCustomerService(response);
        }
        catch (JRException e)
        {
            throw new RuntimeException(e);
        }

    }

    @GetMapping("/exportStatementNote")
    public void exportStatementNote(HttpServletResponse response) throws JRException {
        logger.info("Downloading statement note");

        try {
            statementNoteGeneratorService.generateStatementNote(response);
        }
        catch (JRException e)
        {
            throw new RuntimeException(e);
        }

    }

    @GetMapping("/fetchFile")
    public ResponseEntity<?> downloadPdfBillHotbill() {

        String storedFileLocation = "Bills/temp.pdf";
        try {
            // Load the file from the resource folder
            Resource resource = new ClassPathResource(storedFileLocation);
            // Check if resource exists
            if (!resource.exists()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("File not found");
            }
            InputStreamResource pdfBillHotbill = new InputStreamResource(resource.getInputStream());

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + resource.getFilename())
                    .contentType(MediaType.parseMediaType("application/pdf"))
                    .body(pdfBillHotbill);

        } catch (IOException e) {
            // Exception handling here, e.g., return an error status
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred: " + e.getMessage());
        }
    }




}





