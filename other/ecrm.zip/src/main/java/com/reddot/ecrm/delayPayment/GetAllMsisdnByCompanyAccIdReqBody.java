package com.reddot.ecrm.delayPayment;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetAllMsisdnByCompanyAccIdReqBody {
    private String companyId;
}
