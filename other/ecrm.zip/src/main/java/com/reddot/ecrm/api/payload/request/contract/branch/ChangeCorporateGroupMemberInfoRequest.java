package com.reddot.ecrm.api.payload.request.contract.branch;

import lombok.Data;

import java.io.Serializable;

@Data
public class ChangeCorporateGroupMemberInfoRequest implements Serializable {
  private ReqHeader ReqHeader;

  private AccessInfo AccessInfo;

  private String CustomerId;

  private ChangeMemberInfo ChangeMemberInfo;

  private String GroupId;

  @Data
  public static class ReqHeader implements Serializable {
    private String ReqTime;

    private String Version;

    private String BusinessCode;

    private String Channel;

    private String AccessPassword;

    private String PartnerId;

    private String TransactionId;

    private String AccessUser;
  }

  @Data
  public static class AccessInfo implements Serializable {
    private String ObjectId;

    private String ObjectIdType;
  }

  @Data
  public static class ChangeMemberInfo implements Serializable {
    private String HybridFlag;

    private String MemberType;

    private String DepartmentName;

    private String DepartmentID;

    private String OperateType;
  }
}
