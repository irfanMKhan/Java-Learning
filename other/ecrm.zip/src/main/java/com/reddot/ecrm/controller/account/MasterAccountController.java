package com.reddot.ecrm.controller.account;

import com.reddot.ecrm.dto.contact.ContactDTO;
import com.reddot.ecrm.dto.contact.ContactListDTO;
import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.entity.contact.ContactEntity;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.repository.company.CompanyRepository;
import com.reddot.ecrm.service.contact.ContactService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/account/masterAccount")
@RequiredArgsConstructor
public class MasterAccountController {
    private final CompanyRepository companyRepository;
    private final ContactService contactService;

    @GetMapping
    public String indexPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        List<CompanyEntity> companyList = this.companyRepository.findAllByActiveAndContractStatus(true, 2);

        model.addAttribute("breadcrumb", "Master Account List");
        model.put("company_list", companyList);
        model.put("title", "Master Account List");

        return "account/master_account/index";
    }

    @GetMapping("/create")
    public String createPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        List<CompanyEntity> companyList = this.companyRepository.findAllByActiveAndContractStatus(true, 2);

        model.addAttribute("breadcrumb", "Add Master Account");
        model.put("company_list", companyList);
        model.put("title", "Add Master Account");

        return "account/master_account/create";
    }
}
