package com.reddot.ecrm.dto.contract;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SpecialNumberApprovalCheckDTO {
    private String msisdnCategory;
    private String planName;
    private String planOfferingId;
}
