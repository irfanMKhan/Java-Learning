package com.reddot.ecrm.deposit;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DepositSearchReqDTO {
    private String companyId;
    private String companyAccountCode;
    private String approvalStatus;
    // private String statusId;
    //private String currentDepositAmount;
    //private String requestedDepositAmount;
}
