package com.reddot.ecrm.dto.agreement.sponsored;

import com.reddot.ecrm.dto.agreement.sponsored.StandardPackageTable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SponsoredDTO {
    private String contractNo;
    private String effectiveDate;
    private String companyName;
    private String address;
    private String registrationNo;
    private String date;
    private String representedBy;
    private String position;
    private String agreementDate;
    private String useApplication_1;
    private String useApplication_2;
    private String Services;
    private String months;

    private String companyOwnerName_1;
    private String companyOwnerPosition_1;
    private String SmartOwnerName_1;
    private String SmartOwnerPosition_1;

    private String companyOwnerName_2;
    private String companyOwnerPosition_2;
    private String SmartOwnerName_2;
    private String SmartOwnerPosition_2;


    private String uniqueNumber;
    private String templateName;


}
