package com.reddot.ecrm.dto.contract;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class QueryApiInformationDto {
    private ContractDTO contractDTO;
    private Integer stepNumber;
    private String stepDescription;
    private String uniqueTransactionNumber;
}
