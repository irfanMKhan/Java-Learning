package com.reddot.ecrm.dto.contact;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
public class AddressDTO {
    private String houseno;
    private String street;
    private String country;
    private String province;
    private String district;
    private String sangkat;
    private String villageGroup;
    private String postcode;
}
