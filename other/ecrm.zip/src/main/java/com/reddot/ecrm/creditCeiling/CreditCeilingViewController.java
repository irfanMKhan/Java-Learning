package com.reddot.ecrm.creditCeiling;

import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.service.DropDownService;
import com.reddot.ecrm.service.inventory.InventoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequiredArgsConstructor
@RequestMapping(value = "/credit_ceiling")
public class CreditCeilingViewController {

    private final InventoryService inventoryService;
    private final DropDownService dropDownService;

    @GetMapping
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "credit ceiling List");
        return "/credit_ceiling/list";
    }
}
