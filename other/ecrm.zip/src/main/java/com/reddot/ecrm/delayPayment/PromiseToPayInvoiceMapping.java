package com.reddot.ecrm.delayPayment;

import lombok.*;

import javax.persistence.*;

@Entity
@Table(name = "tbl_promise_to_pay_detail", schema = "ecrm")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class PromiseToPayInvoiceMapping {
    // for tbl_promise_to_pay_detail, coming from QueryInvoice
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @Column(name = "id")
//    private Long id;
//    @Column(name = "promise_to_pay_id")
//    private Long promiseToPayId;
//    @Column(name = "acct_key")
//    private Long acctKey;
//    @Column(name = "cust_key")
//    private Long custKey;
//    @Column(name = "sub_key")
//    private Long subKey;
//    @Column(name = "primary_identity")
//    private Long primaryIdentity;
//    @Column(name = "trans_type")
//    private String transType;
//    @Column(name = "invoice_id")
//    private Long invoiceID;
//    @Column(name = "invoice_no")
//    private Integer invoiceNo;
//    @Column(name = "bill_cycle_id")
//    private Long billCycleID;
//    @Column(name = "bill_cycle_begin_time")
//    private Long billCycleBeginTime;
//    @Column(name = "bill_cycle_end_time")
//    private Long billCycleEndTime;
//    @Column(name = "invoice_amount")
//    private Long invoiceAmount;
//    @Column(name = "open_amount")
//    private Long openAmount;
//    @Column(name = "dispute_amount")
//    private Long disputeAmount;
//    @Column(name = "currency_id")
//    private Long currencyId;
//    @Column(name = "invoice_date")
//    private String invoiceDate;
//    @Column(name = "due_date")
//    private String dueDate;
//    @Column(name = "status")
//    private String status;
//    @Column(name = "invoice_detail_invoice_id")
//    private Long invoiceDetailInvoiceID;
//    @Column(name = "service_category")
//    private String serviceCategory;
//    @Column(name = "charge_code")
//    private String chargeCode;
//    @Column(name = "charge_amount")
//    private Long chargeAmount;
//    @Column(name = "agreed_amount")
//    private Long agreedAmount;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
    @Column(name = "promise_to_pay_id")
    private Long promiseToPayId;
    @Column(name = "acct_key")
    private String acctKey;
    @Column(name = "cust_key")
    private String custKey;
    @Column(name = "sub_key")
    private String subKey;
    @Column(name = "primary_identity")
    private String primaryIdentity;
    @Column(name = "trans_type")
    private String transType;
    @Column(name = "invoice_id")
    private String invoiceID;
    @Column(name = "invoice_no")
    private String invoiceNo;
    @Column(name = "bill_cycle_id")
    private String billCycleID;
    @Column(name = "bill_cycle_begin_time")
    private String billCycleBeginTime;
    @Column(name = "bill_cycle_end_time")
    private String billCycleEndTime;
    @Column(name = "invoice_amount")
    private String invoiceAmount;
    @Column(name = "open_amount")
    private String openAmount;
    @Column(name = "dispute_amount")
    private String disputeAmount;
    @Column(name = "currency_id")
    private String currencyId;
    @Column(name = "invoice_date")
    private String invoiceDate;
    @Column(name = "due_date")
    private String dueDate;
    @Column(name = "status")
    private String status;
    @Column(name = "invoice_detail_invoice_id")
    private String invoiceDetailInvoiceID;
    @Column(name = "service_category")
    private String serviceCategory;
    @Column(name = "charge_code")
    private String chargeCode;
    @Column(name = "charge_amount")
    private String chargeAmount;
    @Column(name = "agreed_amount")
    private String agreedAmount;

    @Column(name = "approval_status")
    private String approvalStatus;

    private String companyName;
}
