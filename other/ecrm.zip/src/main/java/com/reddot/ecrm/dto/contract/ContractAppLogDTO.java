package com.reddot.ecrm.dto.contract;

import com.reddot.ecrm.dto.httpServletRequest.HttpServletRequestDto;
import com.reddot.ecrm.dto.opportunity.OpportunityDTO;
import com.reddot.ecrm.entity.account.AccountDetailsEntity;
import com.reddot.ecrm.entity.attachment.AttachmentEntity;
import com.reddot.ecrm.entity.contact.ContactEntity;
import com.reddot.ecrm.entity.contract.BillMediumContractEntity;
import com.reddot.ecrm.entity.contract.ContractEntity;
import com.reddot.ecrm.entity.contract.ProductDetailsContractAnnexEntity;
import com.reddot.ecrm.entity.event.EventEntity;
import com.reddot.ecrm.entity.opportunity.OpportunityEntity;
import com.reddot.ecrm.entity.special_offer.SpecialOfferEntity;
import com.reddot.ecrm.entity.special_offer.SpecialOfferRequestedEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ContractAppLogDTO {
    private ContractDTO contractDTO;
    private OpportunityDTO opportunityDTO;
    private ContractDetails contractDetails;
    private OpportunityDetails opportunityDetails;

    private HttpServletRequestDto httpServletRequestDto;
    private Long compnayId;

    private List<BillMediumContractEntity> billMediumList;
    private List<ProductDetailsContractAnnexEntity> productList;
    private List<EventEntity> eventEntityList;
    private List<AttachmentEntity> attachmentEntityList;
    private List<ContactEntity> contactEntityList;
    private List<SpecialOfferRequestedEntity> specialOfferList;


    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ContractDetails {
        private ContractEntity contract;
        private AccountDetailsEntity accountDetails;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class OpportunityDetails {
        private OpportunityEntity opportunity;
        private AccountDetailsEntity accountDetails;
    }

}
