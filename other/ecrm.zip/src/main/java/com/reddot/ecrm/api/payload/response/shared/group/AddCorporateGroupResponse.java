package com.reddot.ecrm.api.payload.response.shared.group;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AddCorporateGroupResponse implements Serializable {
    private AddCorporateGroupMemberRspMsg AddCorporateGroupMemberRspMsg;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class AddCorporateGroupMemberRspMsg implements Serializable {
        private RspHeader RspHeader;


        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class RspHeader implements Serializable {
            private Long RspTime;

            private String ReturnCode;

            private String ReturnMsg;

            private Integer Version;

        }
    }
}
