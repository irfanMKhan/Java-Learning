package com.reddot.ecrm.controller.lead.settings;

import com.reddot.ecrm.dto.lead.settings.NumberOfEmployeesDto;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.lead.settings.NumberOfEmployeesService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequestMapping("lead/numberOfEmployees")
public class NumberOfEmployeesRestController {
    
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    
    @Autowired
    private NumberOfEmployeesService numberOfEmployeesService;
    
    @GetMapping("/dt/all")
    public DataTablesOutput<NumberOfEmployeesDto> dtNumberOfEmployees(@Valid DataTablesInput input,
                                                                HttpServletRequest request,
                                                        @RequestParam(value = "searchText", required = false) String searchText, @RequestParam(value = "searchCol", required = false) String searchCol) {
        return numberOfEmployeesService.getDTNumberOfEmployees(input, request, searchText, searchCol);
    }
    
    @PostMapping("/add")
    public CommonRestResponse addNumberOfEmployees(HttpServletRequest request, @RequestBody NumberOfEmployeesDto numberOfEmployeesDto) {
        return numberOfEmployeesService.addNumberOfEmployees(request, numberOfEmployeesDto);
    }
    
    @GetMapping("/details")
    public CommonRestResponse getNumberOfEmployeesById(@RequestParam("id") Long id) {
        return numberOfEmployeesService.getNumberOfEmployeesById(id);
    }
    
    @PostMapping("/update")
    public CommonRestResponse updateNumberOfEmployees(HttpServletRequest request,
                                               @RequestBody NumberOfEmployeesDto numberOfEmployeesDto) {
        return numberOfEmployeesService.updateNumberOfEmployees(request, numberOfEmployeesDto);
    }
    
}