package com.reddot.ecrm.api.payload.response.contract.subscriber;

import lombok.Data;

import java.io.Serializable;
import java.lang.Object;
import java.lang.String;

@Data
public class ChangePrepaidToPostpaidResponse implements Serializable {
  private String transaction_id;

  private String transaction_status;

  private Metadata metadata;

  private Object data;

  @Data
  public static class Metadata implements Serializable {
    private String operator_id;

    private String channel_id;
  }
}
