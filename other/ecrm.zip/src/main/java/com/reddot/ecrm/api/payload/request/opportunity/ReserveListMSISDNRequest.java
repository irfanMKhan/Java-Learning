package com.reddot.ecrm.api.payload.request.opportunity;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class ReserveListMSISDNRequest implements Serializable {
    private Metadata metadata;

    private String correlation_id;

    private String sim_type;

    private List<Long> msisdn;

    private String release_time;

    @Data
    @AllArgsConstructor
    public static class Metadata implements Serializable {
        private Integer store_id;

        private Integer channel_id;
    }
}
