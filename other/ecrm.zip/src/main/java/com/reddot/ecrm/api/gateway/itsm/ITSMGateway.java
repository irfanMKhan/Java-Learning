package com.reddot.ecrm.api.gateway.itsm;

import com.reddot.ecrm.api.exception.ApiRequestException;
import com.reddot.ecrm.api.exception.InternalServerErrorSmartException;
import com.reddot.ecrm.api.exception.InvalidAccessTokenException;
import com.reddot.ecrm.api.exception.InvalidClientCredentialException;
import com.reddot.ecrm.api.payload.request.itsm.*;
import com.reddot.ecrm.api.payload.response.itsm.*;
import com.reddot.ecrm.api.security.AuthorizationGateway;
import com.reddot.ecrm.api.utility.CommonConstant;
import com.reddot.ecrm.api.utility.HttpClient;
import com.google.gson.Gson;
import com.reddot.ecrm.model.itsm.CreateServiceRequestResponseModel;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor
public class ITSMGateway {
    @Value("${smart.igw.base.url}")
    String baseUrlIGW;
    private final HttpClient httpClient;
    private final Gson gson;
    private final AuthorizationGateway authorizationGateway;

    public FetchContactIdByEmailResponse fetchContactId() {

        String apiUrl = baseUrlIGW + "/api/oracle-b2c-services/1/v1.4/contacts/1650003";

        Map<String, String> headers = getIGWHeaders();

        log.error("FetchContactIdByEmailRequest::fetchContactIdByEmail() -> apiUrl:: " + apiUrl);

        try (Response response = httpClient.get(apiUrl, headers)) {
            log.error("FetchContactIdByEmailRequest::fetchContactIdByEmail() -> response");
            Utility.EntityObjectToJsonConvertGson(response);

            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), FetchContactIdByEmailResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else if (response.code() == HttpStatus.INTERNAL_SERVER_ERROR.value()) {
                return new FetchContactIdByEmailResponse();

            } else {
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("FetchContactIdByEmail Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("FetchContactIdByEmail Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("FetchContactIdByEmail Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("FetchContactIdByEmail Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    public FetchContactIdByEmailResponse fetchContactIdByEmail(String email) {

        String apiUrl = baseUrlIGW + "/api/oracle-b2c-services/1/v1.3/queryResults/?query=select Contacts.ID from Contacts where Contacts.Emails.Address ='"+email+"' AND Contacts.Emails.addresstype.id=0&category=send to BO";

        Map<String, String> headers = getIGWHeaders();

        log.error("FetchContactIdByEmailRequest::fetchContactIdByEmail() -> apiUrl:: " + apiUrl);

        try (Response response = httpClient.get(apiUrl, headers)) {
            log.error("FetchContactIdByEmailRequest::fetchContactIdByEmail() -> response");
            Utility.EntityObjectToJsonConvertGson(response);

            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), FetchContactIdByEmailResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else if (response.code() == HttpStatus.INTERNAL_SERVER_ERROR.value()) {
                return new FetchContactIdByEmailResponse();

            } else {
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("FetchContactIdByEmail Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("FetchContactIdByEmail Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("FetchContactIdByEmail Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("FetchContactIdByEmail Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    public FetchServiceRequestDetailsResponse fetchServiceRequestDetails(String incidentId) {
        String apiUrl = baseUrlIGW + "/api/oracle-b2c-services/1/v1.3/queryResults/?query=Select I.PrimaryContact.ParentContact.Lookupname Name , \n" +
                "I.PrimaryContact.ParentContact.Emails.Address, \n" +
                "I.PrimaryContact.ParentContact.CustomFields.ITSM.StaffPosition Jobtitile \n" +
                ",I.PrimaryContact.ParentContact.CustomFields.ITSM.StaffLocation \n" +
                "Location,I.PrimaryContact.ParentContact.Phones.Number OfficePhone,I.createdTime \n" +
                "DateCreated,I.updatedTime DateLastUpdated,I.closedTime DateCloded, \n" +
                "I.Product.LookupName Category , I.Category.LookupName ServiceRequestType, \n" +
                "I.AssignedTo.Account.LookupName Assigned , I.StatusWithType.Status.LookupName \n" +
                "Status, I.CustomFields.c.resolutiontime ResolutionTime , I.CustomFields.c.effectivedate \n" +
                "EffectiveDate ,I. CustomFields.c.targetresolution TargetResolution , \n" +
                "I.CustomFields.CO.Issue Description , I.CustomFields.c.priority.LookupName Priority , \n" +
                "I.CustomFields.c.urged_count NoOfPhoneNumbers,I.CustomFields.ITSM.BORefNumbers \n" +
                "PhoneNumbers from Incidents I where I.ID="+incidentId+" and \n" +
                "I.PrimaryContact.ParentContact.Emails.addresstype.id=0 and \n" +
                "I.PrimaryContact.ParentContact.Phones.PhoneList.PhoneType=3";

        try (Response response = httpClient.get(apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), FetchServiceRequestDetailsResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("FetchServiceRequestDetails Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("FetchServiceRequestDetails Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("FetchServiceRequestDetails Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("FetchServiceRequestDetails Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    public String addNewCategory(AddNewCategoryRequest addNewCategoryRequest) {
        String apiUrl = baseUrlIGW + "/api/oracle-b2c-services/1/v1.3/incidents";
        String json = gson.toJson(addNewCategoryRequest);

        try (Response response = httpClient.post(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.CREATED.value()) {
                return response.body().string();
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("addNewCategory Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("addNewCategory Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("addNewCategory Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("addNewCategory Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    public String addResponse(String incidentId, AddResponseRequest addResponseRequest) {
        String apiUrl = baseUrlIGW + "/api/oracle-b2c-services/1/v1.3/incidents/"+incidentId;
        String json = gson.toJson(addResponseRequest);

        try (Response response = httpClient.patch(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return "{\"message\" : \"Response added successfully.\"}";
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("addResponse Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("addResponse Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("addResponse Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("addResponse Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    public CreateServiceRequestResponseModel createServiceRequest(CreateServiceRequest createServiceRequest) {
        String apiUrl = baseUrlIGW + "/api/oracle-b2c-services/1/v1.3/incidents";
        String json = gson.toJson(createServiceRequest);

        try (Response response = httpClient.post(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.CREATED.value()) {
                return gson.fromJson(response.body().string(), CreateServiceRequestResponseModel.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("createServiceRequest Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("createServiceRequest Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("createServiceRequest Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("createServiceRequest Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }
    public CreateServiceRequestResponseModel changePostpaidToPrepaid(ChangePostpaidToPrepaidRequest changePostpaidToPrepaidRequest) {
        String apiUrl = baseUrlIGW + "/api/oracle-b2c-services/1/v1.3/incidents";
        String json = gson.toJson(changePostpaidToPrepaidRequest);

        try (Response response = httpClient.post(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.CREATED.value()) {
                return gson.fromJson(response.body().string(), CreateServiceRequestResponseModel.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("changePostpaidToPrepaid Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("changePostpaidToPrepaid Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("changePostpaidToPrepaid Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("changePostpaidToPrepaid Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }
    public UploadFileAttachmentResponse uploadFileAttachment(String incidentId, UploadFileAttachmentRequest uploadFileAttachmentRequest) {
        String apiUrl = baseUrlIGW + "/api/oracle-b2c-services/1/v1.3/incidents/"+incidentId+"/fileAttachments";
        String json = gson.toJson(uploadFileAttachmentRequest);

        try (Response response = httpClient.post(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.CREATED.value()) {
                return gson.fromJson(response.body().string(), UploadFileAttachmentResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("UploadFileAttachment Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("UploadFileAttachment Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("UploadFileAttachment Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("UploadFileAttachment Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }
    public GetFileAttachmentsResponse fileAttachmentsResponse(String incidentId) {
        String apiUrl = baseUrlIGW + "/api/oracle-b2c-services/1/v1.3/incidents/"+incidentId+"/fileAttachments";

        try (Response response = httpClient.get(apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), GetFileAttachmentsResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("GetFileAttachments Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("GetFileAttachments Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("GetFileAttachments Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("GetFileAttachments Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    public DownloadFileAttachmentResponseData downloadFileAttachmentData(String incidentId, String attachmentId) {
        String apiUrl = baseUrlIGW + "/api/oracle-b2c-services/1/v1.3/incidents/"+incidentId+"/fileAttachments/"+attachmentId+"/data";

        try (Response response = httpClient.get(apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), DownloadFileAttachmentResponseData.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else if (response.code() == HttpStatus.INTERNAL_SERVER_ERROR.value() && response.message().equalsIgnoreCase("Not Found")) {
                throw new ApiRequestException("Not found.");
            } else {
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("DownloadFileAttachment Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("DownloadFileAttachment Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("DownloadFileAttachment Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("DownloadFileAttachment Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    public DownloadFileAttachmentResponse downloadFileAttachmentResponse(String incidentId, String attachmentId){
        String apiUrl = baseUrlIGW + "/api/oracle-b2c-services/1/v1.3/incidents/"+incidentId+"/fileAttachments/"+attachmentId;

        try (Response response = httpClient.get(apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), DownloadFileAttachmentResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else if (response.code() == HttpStatus.INTERNAL_SERVER_ERROR.value() && response.message().equalsIgnoreCase("Not Found")) {
                throw new ApiRequestException("Not found.");
            } else {
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("DownloadFileAttachment Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("DownloadFileAttachment Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("DownloadFileAttachment Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("DownloadFileAttachment Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    public String deleteFileAttachment(String incidentId, String attachmentId) {
        String apiUrl = baseUrlIGW + "/api/oracle-b2c-services/1/v1.3/incidents/"+incidentId+"/fileAttachments/"+attachmentId;

        try (Response response = httpClient.delete(apiUrl, getIGWHeaders())) {
            if (response.code() == HttpStatus.OK.value()) {
                return "{\"message\" : \"Attachment deleted successfully.\"}";
            } if (response.code() == HttpStatus.NOT_FOUND.value()) {
               log.debug("Url Not Found: " + apiUrl);
               throw new ApiRequestException(CommonConstant.COMMON_ERROR);
           } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
               throw new InvalidAccessTokenException();
           } else if (response.code() == HttpStatus.INTERNAL_SERVER_ERROR.value() && response.message().equalsIgnoreCase("Not Found")) {
               throw new ApiRequestException("Not found.");
           } else {
               throw new ApiRequestException(CommonConstant.COMMON_ERROR);
           }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("DeleteFileAttachment Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("DeleteFileAttachment Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("DeleteFileAttachment Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("DeleteFileAttachment Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    private Map<String, String> getIGWHeaders() {
        String bearerToken = authorizationGateway.getTokenIGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }
}
