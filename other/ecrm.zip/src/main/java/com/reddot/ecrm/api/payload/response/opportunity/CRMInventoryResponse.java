package com.reddot.ecrm.api.payload.response.opportunity;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class CRMInventoryResponse implements Serializable {
  private List<MSISDNEntities> MSISDNEntities;

  private ResHeader ResHeader;

  private Integer TotalRecords;

  @Data
  public static class MSISDNEntities implements Serializable {
    private Integer Status;

    private String MSISDN;

    private String Category;

    private String Dept;

    private String Prefix;
  }

  @Data
  public static class ResHeader implements Serializable {
    private Integer ReturnCode;

    private String ReturnMsg;

    private String ReturnDesc;
  }
}
