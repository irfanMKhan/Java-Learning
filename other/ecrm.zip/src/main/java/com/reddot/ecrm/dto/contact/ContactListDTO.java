package com.reddot.ecrm.dto.contact;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ContactListDTO {
    private Long id;
    private String salutation;
    private String email;
    private String name;
    private String lastName;
    private String personType;
    private String personTypeText;
    private String mobile;
    private String position;
}
