package com.reddot.ecrm.api.payload.response.shared.account;

import lombok.Data;

import java.io.Serializable;
import java.lang.String;

@Data
public class CreditNoteResponse implements Serializable {
  private String transaction_id;

  private String transaction_status;

  private Data data;

  @lombok.Data
  public static class Data implements Serializable {
    private String AcctKey;

    private AdjustmentInfo AdjustmentInfo;

    @lombok.Data
    public static class AdjustmentInfo implements Serializable {
      private String BalanceTypeName;

      private String OldBalanceAmt;

      private String BalanceType;

      private String NewBalanceAmt;

      private String CurrencyID;
    }
  }
}
