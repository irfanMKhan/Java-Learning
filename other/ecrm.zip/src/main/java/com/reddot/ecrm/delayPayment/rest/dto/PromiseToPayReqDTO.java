package com.reddot.ecrm.delayPayment.rest.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PromiseToPayReqDTO {
    private String agreedPaidDate;
    private String remark;
    private String attachment;
}
