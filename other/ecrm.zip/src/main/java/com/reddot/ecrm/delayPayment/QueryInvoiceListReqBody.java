package com.reddot.ecrm.delayPayment;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class QueryInvoiceListReqBody {
    private String accountCode;
    private String numberOfBillCycle;
    private String msisdn;
    private String msisdnEntityId;
}
