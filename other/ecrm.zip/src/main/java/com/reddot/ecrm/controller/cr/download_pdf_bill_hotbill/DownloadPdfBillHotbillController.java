package com.reddot.ecrm.controller.cr.download_pdf_bill_hotbill;

import com.reddot.ecrm.menu.MenuViewer;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping(value = "/cr/downloadPdfBillHotBill", method = RequestMethod.GET)
public class DownloadPdfBillHotbillController {

    @GetMapping("")
    public String viewPageSummary(ModelMap model, HttpServletRequest request)
    {
        new MenuViewer().setupSideMenu(model, request);
        model.addAttribute("breadcrumb", "Download PDF Bill/ Hotbill");
        model.addAttribute("title", "Download PDF Bill/ Hotbill");
        model.addAttribute("filename", "Bills/temp.pdf");

        return "cr/download_pdf_bill_hotbill/download_bill_hotbill";
    }


}
