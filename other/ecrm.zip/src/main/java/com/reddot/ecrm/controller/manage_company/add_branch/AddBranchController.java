package com.reddot.ecrm.controller.manage_company.add_branch;

import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.repository.company.CompanyRepository;
import com.reddot.ecrm.spring_config.session.SessionManager;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/manageCompany/branch")
@RequiredArgsConstructor
public class AddBranchController {
    private final CompanyRepository companyRepository;

    @GetMapping("")
    public String indexPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        List<CompanyEntity> companyList = this.companyRepository.findAllByActiveAndContractStatus(true, 2);

        MDUserModel mdUserModel = SessionManager.getUserDetails(request);
        Long loggedInPICCompanyId = mdUserModel.getCOMPANY_ID();

        boolean isPICUser = !ObjectUtils.isEmpty(loggedInPICCompanyId);

        if (ObjectUtils.isEmpty(loggedInPICCompanyId)) {
            model.put("loggedInPICCompanyId", "-99");
        } else {
            model.put("loggedInPICCompanyId", loggedInPICCompanyId);
        }

        model.put("isPICUser", isPICUser);
        model.addAttribute("breadcrumb", "Branch List");
        model.put("company_list", companyList);
        model.put("title", "Branch List");

        return "manage_company/add_branch/index";
    }

    @GetMapping("/create")
    public String createPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        List<CompanyEntity> companyList = this.companyRepository.findAllByActiveAndContractStatus(true, 2);

        MDUserModel mdUserModel = SessionManager.getUserDetails(request);
        Long loggedInPICCompanyId = mdUserModel.getCOMPANY_ID();

        boolean isPICUser = !ObjectUtils.isEmpty(loggedInPICCompanyId);

        if (ObjectUtils.isEmpty(loggedInPICCompanyId)) {
            model.put("loggedInPICCompanyId", "-99");
        } else {
            model.put("loggedInPICCompanyId", loggedInPICCompanyId);
        }

        model.put("isPICUser", isPICUser);

        model.addAttribute("breadcrumb", "Add Branch");
        model.put("company_list", companyList);
        model.put("title", "Add Branch");

        return "manage_company/add_branch/create";
    }
}
