package com.reddot.ecrm.api.payload.request.shared.account;

import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.lang.String;
import java.util.List;

@Data
public class CreditNoteRequest implements Serializable {
  @Valid
  @NotNull(message = "AdjustmentRequest is required.")
  private AdjustmentRequest AdjustmentRequest;

  @Data
  public static class AdjustmentRequest implements Serializable {
    @NotNull(message = "AdjustmentSerialNo is required.")
    @NotEmpty(message = "AdjustmentSerialNo is required.")
    private String AdjustmentSerialNo;

    @NotNull(message = "PayType is required.")
    @NotEmpty(message = "PayType is required.")
    private String PayType;

    @NotNull(message = "OpType is required.")
    @NotEmpty(message = "OpType is required.")
    private String OpType;

    @Valid
    @NotNull(message = "AdjustmentInfo is required.")
    private List<AdjustmentInfo> AdjustmentInfo;

    @NotNull(message = "AdjustmentReasonCode is required.")
    @NotEmpty(message = "AdjustmentReasonCode is required.")
    private String AdjustmentReasonCode;

    @Data
    public static class AdjustmentInfo implements Serializable {
      @NotNull(message = "AdjustmentType is required.")
      @NotEmpty(message = "AdjustmentType is required.")
      private String AdjustmentType;

      @NotNull(message = "AdjustmentAmt is required.")
      @NotEmpty(message = "AdjustmentAmt is required.")
      private String AdjustmentAmt;

      @NotNull(message = "CurrencyID is required.")
      @NotEmpty(message = "CurrencyID is required.")
      private String CurrencyID;

      @NotNull(message = "EffectiveTime is required.")
      @NotEmpty(message = "EffectiveTime is required.")
      private String EffectiveTime;
    }
  }
  @NotNull(message = "transaction_id is required.")
  @NotEmpty(message = "transaction_id is required.")
  private String transaction_id;
}
