package com.reddot.ecrm.controller.mandatoryOffering;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.dto.mandatoryOffering.MandatoryOfferingDTO;
import com.reddot.ecrm.dto.mandatoryOffering.MandatoryOfferingSearchDTO;
import com.reddot.ecrm.entity.mandatory_offering.MandatoryOfferingEntity;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.module.supplementaryOffering.SuppOffering;
import com.reddot.ecrm.module.supplementaryOffering.SuppOfferingRepo;
import com.reddot.ecrm.service.mandatoryOffering.MandatoryOfferingServiceImplementation;
import com.reddot.ecrm.spring_config.session.SessionManager;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@Controller
@RequiredArgsConstructor
@RequestMapping(value = "/mandatory_offering")
public class MandatoryOfferingViewController {

    private final MandatoryOfferingServiceImplementation serviceImplementation;
    private final SuppOfferingRepo suppOfferingRepo;

    @GetMapping
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Mandatory Offering List");
        return "/mandatory_offering/index";
    }

    @ResponseBody
    @RequestMapping(value = "/list/search-dt", method = RequestMethod.POST)
    public DataTablesOutput<MandatoryOfferingEntity> getOpportunityListDT(@RequestBody Map<String, Object> data) throws JsonProcessingException {

        DataTablesInput input = new Gson().fromJson(
                Utility.ObjectToJson(data.get("dtInput")),
                new TypeToken<DataTablesInput>() {
                }.getType()
        );

        ObjectMapper mapper = new ObjectMapper();
        MandatoryOfferingSearchDTO searchDTO = mapper.readValue(data.get("searchData").toString(), MandatoryOfferingSearchDTO.class);

        return serviceImplementation.searchDataTable(input, searchDTO);
    }

    @ResponseBody
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public List<MandatoryOfferingEntity> getOpportunityList() {
        return serviceImplementation.getAllActive();
    }

    @ResponseBody
    @RequestMapping(value = "/list/supplementary", method = RequestMethod.GET)
    public List<SuppOffering> getMandatorySupplementaryOffering() {
        return suppOfferingRepo.getMandatorySuppOfferData();
    }


    @GetMapping("/add")
    String viewOpportunityAdd(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        MDUserModel user = SessionManager.getUserDetails(request);

        String unique_id = "";

        model.put("title", "Add New Mandatory Offering");
        model.put("login_name", user.getLOGIN_NAME());
        model.put("name", user.getNAME());
        model.put("logged_in_id", user.getID());
        model.put("unique_id", unique_id);

        return "/mandatory_offering/add";
    }

    @ResponseBody
    @PostMapping(value = "/add/submit", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> addOpportunity(@Valid @RequestBody MandatoryOfferingDTO offeringDTO, HttpServletRequest request) {
        serviceImplementation.save(offeringDTO, request);
        return new ResponseEntity<>("Success", HttpStatus.OK);
    }

}
