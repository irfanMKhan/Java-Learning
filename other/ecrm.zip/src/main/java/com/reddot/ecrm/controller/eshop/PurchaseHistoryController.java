package com.reddot.ecrm.controller.eshop;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.dto.eshop.PurchaseHistoryDTO;

import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.entity.eshop.EshopFileInfo;
import com.reddot.ecrm.enum_config.purchase.*;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.UserModel;

import com.reddot.ecrm.service.company.CompanyService;
import com.reddot.ecrm.service.eshop.EshopFileInfoService;
import com.reddot.ecrm.service.eshop.PurchaseHistoryService;
import com.reddot.ecrm.service.eshop.SubContractsService;
import com.reddot.ecrm.service.user.UserService;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URLConnection;
import java.nio.file.Files;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/crm/eShop")
public class PurchaseHistoryController {

    @Autowired
    private PurchaseHistoryService purchaseHistoryService;

    @Autowired
    private UserService userService;

    @Autowired
    private CompanyService companyService;

    @Autowired
    private SubContractsService subContractsService;

    @Autowired
    private EshopFileInfoService eshopFileInfoService;


    @RequestMapping(value = "/purchase", method = RequestMethod.GET)
    public String viewSubContract(ModelMap model, HttpServletRequest request) {

        new MenuViewer().setupSideMenu(model, request);
        model.addAttribute("purchaseHistory", purchaseHistoryService.getAllPurchaseHistory());
        model.addAttribute("title", "Purchase-History");
        model.addAttribute("breadcrumb", "PurchaseHistory");

        return "purchase/purchaseHistoryList";
    }

    @RequestMapping(value = "/addPurchaseHistory", method = RequestMethod.GET)
    public String addPurchaseHistory(ModelMap model, HttpServletRequest request, Principal principal) {

        new MenuViewer().setupSideMenu(model, request);
        List<UserModel> userData = new ArrayList<>();
        userData = new Gson().fromJson(Utility.ObjectToJson(userService.getUserByUserName(principal.getName())), new TypeToken<List<UserModel>>() {
        }.getType());

        List<CompanyEntity> listOfCompany = companyService.getAllCompany();
        model.addAttribute("deliveryOptionEnumList", DeliveryOptionEnum.values());
        model.addAttribute("optionOfReceivingEnumList", OptionOfReceivingEnum.values());
        model.addAttribute("paymentTypeForPurchaseEnumList", PaymentTypeForPurchaseEnum.values());
        model.addAttribute("prePaymentOptionEnumList", PrePaymentOptionEnum.values());
        model.addAttribute("productCategoryEnumList", ProductCategoryEnum.values());
        model.addAttribute("topUpTypeEnumList", TopUpTypeEnum.values());


        model.addAttribute("listOfCompany", listOfCompany);
        model.addAttribute("subContractList", subContractsService.getAllSubContracts());
        model.addAttribute("purchaseNo", purchaseHistoryService.getPurchaseHistorySequence());

        return "purchase/addEditPurchaseHistory";
    }

    @RequestMapping(value = "/editPurchaseHistory/{id}", method = RequestMethod.GET)
    public String editPurchaseHistory(ModelMap model, HttpServletRequest request, Principal principal, @PathVariable(name = "id") Long id) {

        new MenuViewer().setupSideMenu(model, request);

        List<CompanyEntity> listOfCompany = companyService.getAllCompany();

        PurchaseHistoryDTO purchaseHistoryDTO = purchaseHistoryService.editPurchaseHistory(request, id);
        model.put("product", purchaseHistoryDTO.getProduct());
        model.put("edit", "edit");


        model.put("purchaseHistoryDTO", purchaseHistoryDTO);
        model.put("deliveryOptionEnumList", DeliveryOptionEnum.values());
        model.put("optionOfReceivingEnumList", OptionOfReceivingEnum.values());
        model.put("paymentTypeForPurchaseEnumList", PaymentTypeForPurchaseEnum.values());
        model.put("prePaymentOptionEnumList", PrePaymentOptionEnum.values());
        model.put("productCategoryEnumList", ProductCategoryEnum.values());
        model.put("topUpTypeEnumList", TopUpTypeEnum.values());
        model.put("listOfCompany", listOfCompany);
        model.put("selectedCompany", purchaseHistoryDTO.getCompany());

        model.put("selectedOptionOfReceivingEnumList", purchaseHistoryDTO.getTopUpOptionOfReceiving());
        model.put("selectedTopUpTypeEnumList", purchaseHistoryDTO.getTopUpType());
        model.put("selectedTopUpPaymentType", purchaseHistoryDTO.getTopUpPaymentType());
        model.put("selectedTopUpPrePaymentOption", purchaseHistoryDTO.getTopUpPrePaymentOption());

        model.put("selectedScratchCardPaymentType", purchaseHistoryDTO.getScratchCardPaymentType());
        model.put("selectedScratchCardPrePaymentOption", purchaseHistoryDTO.getScratchCardPrePaymentOption());
        model.put("selectedScratchCardDeliveryOption", purchaseHistoryDTO.getScratchCardDeliveryOption());

        model.put("selectedSimKitPaymentType", purchaseHistoryDTO.getSimKitPaymentType());
        model.put("selectedSimKitPrePaymentOption", purchaseHistoryDTO.getSimKitPrePaymentOption());
        model.put("selectedSimKitDeliveryOption", purchaseHistoryDTO.getSimKitDeliveryOption());

        model.put("selectedDeviceAccessoriesProductCategory", purchaseHistoryDTO.getDeviceAccessoriesProductCategory());
        model.put("selectedDeviceAccessoriesPaymentType", purchaseHistoryDTO.getDeviceAccessoriesPaymentType());
        model.put("selectedDeviceAccessoriesPrePaymentOption", purchaseHistoryDTO.getDeviceAccessoriesPrePaymentOption());
        model.put("selectedDeviceAccessoriesDeliveryOption", purchaseHistoryDTO.getDeviceAccessoriesDeliveryOption());

        model.put("selectedSmartHomePaymentType", purchaseHistoryDTO.getSmartHomePaymentType());
        model.put("selectedSmartHomePrePaymentOption", purchaseHistoryDTO.getSmartHomePrePaymentOption());
        model.put("selectedSmartHomeDeliveryOption", purchaseHistoryDTO.getSmartHomeDeliveryOption());


        model.put("purchaseNo", purchaseHistoryDTO.getPurchaseNo());


        return "purchase/addEditPurchaseHistory";
    }

    @RequestMapping(value = "/viewPurchaseHistory/{id}", method = RequestMethod.GET)
    public String viewPurchaseHistory(ModelMap model, HttpServletRequest request, Principal principal, @PathVariable(name = "id") Long id) {

        new MenuViewer().setupSideMenu(model, request);

        List<CompanyEntity> listOfCompany = companyService.getAllCompany();

        PurchaseHistoryDTO purchaseHistoryDTO = purchaseHistoryService.editPurchaseHistory(request, id);
        model.put("product", purchaseHistoryDTO.getProduct());
        model.put("edit", "edit");


        model.put("purchaseHistoryDTO", purchaseHistoryDTO);
        model.put("deliveryOptionEnumList", DeliveryOptionEnum.values());
        model.put("optionOfReceivingEnumList", OptionOfReceivingEnum.values());
        model.put("paymentTypeForPurchaseEnumList", PaymentTypeForPurchaseEnum.values());
        model.put("prePaymentOptionEnumList", PrePaymentOptionEnum.values());
        model.put("productCategoryEnumList", ProductCategoryEnum.values());
        model.put("topUpTypeEnumList", TopUpTypeEnum.values());
        model.put("listOfCompany", listOfCompany);
        model.put("selectedCompany", purchaseHistoryDTO.getCompany());

        model.put("selectedOptionOfReceivingEnumList", purchaseHistoryDTO.getTopUpOptionOfReceiving());
        model.put("selectedTopUpTypeEnumList", purchaseHistoryDTO.getTopUpType());
        model.put("selectedTopUpPaymentType", purchaseHistoryDTO.getTopUpPaymentType());
        model.put("selectedTopUpPrePaymentOption", purchaseHistoryDTO.getTopUpPrePaymentOption());

        model.put("selectedScratchCardPaymentType", purchaseHistoryDTO.getScratchCardPaymentType());
        model.put("selectedScratchCardPrePaymentOption", purchaseHistoryDTO.getScratchCardPrePaymentOption());
        model.put("selectedScratchCardDeliveryOption", purchaseHistoryDTO.getScratchCardDeliveryOption());

        model.put("selectedSimKitPaymentType", purchaseHistoryDTO.getSimKitPaymentType());
        model.put("selectedSimKitPrePaymentOption", purchaseHistoryDTO.getSimKitPrePaymentOption());
        model.put("selectedSimKitDeliveryOption", purchaseHistoryDTO.getSimKitDeliveryOption());

        model.put("selectedDeviceAccessoriesProductCategory", purchaseHistoryDTO.getDeviceAccessoriesProductCategory());
        model.put("selectedDeviceAccessoriesPaymentType", purchaseHistoryDTO.getDeviceAccessoriesPaymentType());
        model.put("selectedDeviceAccessoriesPrePaymentOption", purchaseHistoryDTO.getDeviceAccessoriesPrePaymentOption());
        model.put("selectedDeviceAccessoriesDeliveryOption", purchaseHistoryDTO.getDeviceAccessoriesDeliveryOption());


        model.put("purchaseNo", purchaseHistoryDTO.getPurchaseNo());


        return "purchase/viewPurchaseHistory";
    }

    @RequestMapping(value = "/deletePurchaseHistory/{id}", method = RequestMethod.GET)
    public String deletePurchaseHistory(ModelMap model, HttpServletRequest request, Principal principal, @PathVariable(name = "id") Long id) {
        //purchaseHistoryService.deleteSubContractsById(id);
        return "purchase/purchaseHistoryList";

    }

    @RequestMapping(value = "/download", method = RequestMethod.POST)
    @ResponseBody
    public void downloadFile(HttpServletResponse response, @RequestParam(value = "purchaseNo", required = true) String purchaseNo) throws Exception {
        Optional<EshopFileInfo> data = eshopFileInfoService.getEshopFileInfoById(purchaseNo);
        try {
            String fileName = data.get().getName();
            String filePath = data.get().getUrl();

            try {
                File file = new File(filePath);
                FileInputStream in = new FileInputStream(filePath);

                response.setContentType(URLConnection.guessContentTypeFromStream(in));
                response.setContentLength(Files.readAllBytes(file.toPath()).length);
                response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");

                FileCopyUtils.copy(in, response.getOutputStream());
                in.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @RequestMapping(value = "/excelDownload", method = RequestMethod.POST)
    @ResponseBody
    public void excelDownload(HttpServletRequest request, HttpServletResponse response, @RequestParam(value = "excelFileType", required = true) String excelFileType) throws Exception {
        String dataDirectory = request.getServletContext().getRealPath("/WEB-INF/downloads/");
        String fileName = "";
        try {
            if (excelFileType.equals(TypesOfProductEnum.TOPUP.getName())) {
                fileName = "ETopUp.xlsx";

            } else if (excelFileType.equals(TypesOfProductEnum.SCRATCHCARD.getName())) {
                fileName = "ScratchCard.xlsx";
            } else if (excelFileType.equals(TypesOfProductEnum.SIMKIT.getName())) {
                fileName = "SimKit.xlsx";
            } else if (excelFileType.equals(TypesOfProductEnum.ACCESSORIES.getName())) {
                fileName = "AddDeviceDescription.xlsx";
            }
            String filePath = dataDirectory + fileName;

            try {
                File file = new File(filePath);
                FileInputStream in = new FileInputStream(filePath);

                response.setContentType(URLConnection.guessContentTypeFromStream(in));
                response.setContentLength(Files.readAllBytes(file.toPath()).length);
                response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");

                FileCopyUtils.copy(in, response.getOutputStream());
                in.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
