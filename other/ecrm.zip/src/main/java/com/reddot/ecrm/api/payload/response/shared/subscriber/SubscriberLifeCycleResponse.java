package com.reddot.ecrm.api.payload.response.shared.subscriber;

import lombok.Data;

import java.io.Serializable;
import java.lang.String;

@Data
public class SubscriberLifeCycleResponse implements Serializable {
  private QuerySubLifeCycleResult QuerySubLifeCycleResult;
  @Data
  public static class QuerySubLifeCycleResult implements Serializable {
    private String RBlacklistStatus;

    private String FraudTimes;
  }
}
