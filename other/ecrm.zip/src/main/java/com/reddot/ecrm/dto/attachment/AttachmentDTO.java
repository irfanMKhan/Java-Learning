package com.reddot.ecrm.dto.attachment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AttachmentDTO {
    private Long ID;
    private String name;
    private String tempNO;
    private String fileType;
    private String attachmentType;
    private Integer size;
    private String remarks;
    private String createBy;
    private String newFileUniqueName;
    private String uuidToken;
    private Long bulkFileId;

    private Long companyId;
    private String companyName;
    private String fileLocation;
    private String fileUploadServerIPAddress;
    private Integer fileProcessTypeId;
    private String fileProcessTypeName;

    private Boolean isFinalSave;
    private Boolean isPermanentDelete;
    private Boolean isTemporaryAddThenDel;
    private Boolean isChanged;
}


