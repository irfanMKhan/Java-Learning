package com.reddot.ecrm.controller.tempo;

import com.google.gson.Gson;

import com.reddot.ecrm.dto.tempo.TempCompanyPicDTO;
import com.reddot.ecrm.entity.tempo.TempCompany;
import com.reddot.ecrm.entity.tempo.TempPic;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.repository.tempo.TempCompanyRepository;
import com.reddot.ecrm.service.tempo.TempCompanyService;
import com.reddot.ecrm.service.tempo.TempPicService;
import com.reddot.ecrm.util.Utility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;

import static java.lang.Long.parseLong;


@RequestMapping(value = "/api/temp-company", method = RequestMethod.GET)
@RestController
public class TempCompanyRestController {

    private final Logger logger =  LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    private TempCompanyService tempCompanyService;

    @Autowired
    private TempPicService tempPicService;


    @GetMapping("/check-companyName")
    public ResponseEntity<Boolean> checkCompanyName(@RequestParam String name)
    {
        boolean exists = tempCompanyService.companyNameExists(name);
        return ResponseEntity.ok(exists);
    }

    @PostMapping("/add")
    public CommonRestResponse saveTempCompany(@RequestBody String companyData)
    {
        System.out.println("Response Data = " + companyData);
        TempCompanyPicDTO tempCompDTO = new Gson().fromJson(companyData, TempCompanyPicDTO.class);
        System.out.println("Company Name " + tempCompDTO.getCompany_name());
        System.out.println("PIC " + tempCompDTO.getTemp_pic());
        return tempCompanyService.saveTempCompany(tempCompDTO);
    }

    @PutMapping("/edit")
    public CommonRestResponse editTempCompany(@RequestBody String companyData)
    {
        System.out.println("Response Data = " + companyData);
        TempCompanyPicDTO tempCompanyPicDTO = new Gson().fromJson(companyData, TempCompanyPicDTO.class);
        System.out.println("Company Name " + tempCompanyPicDTO.getCompany_name());
        System.out.println("Company ID " +  tempCompanyPicDTO.getCompany_id());
        return tempCompanyService.editTempCompany(tempCompanyPicDTO);
    }

    @DeleteMapping(value = "/delete")
    public CommonRestResponse deleteTempCompany(@RequestBody String company_id)
    {
        System.out.println("In rest controller. Company ID: " + company_id);
        CommonRestResponse restResponse = tempCompanyService.deleteCompany(parseLong(company_id));
        System.out.println("Code received in controller from service: " + restResponse.getCode());
        return restResponse;
    }

    @GetMapping("/getPicData")
    public List<TempPic> getPicByCompanyId(@RequestParam(name = "company_id") String company_id, HttpServletRequest request){

        List<TempPic> picList = tempPicService.getPicByCompanyId(parseLong(company_id));

        return picList;
    }

    @GetMapping("/DTData")
    public DataTablesOutput<TempCompany> DTData(@Valid DataTablesInput input, HttpServletRequest request,
                                                @RequestParam(value = "searchText", required = false) String customQuery,
                                                @RequestParam(value = "customSearchCriteria", required = false) String customSearchCriteria){
        if (customSearchCriteria == null) {
            customSearchCriteria = "";
        }

        if (Utility.isColumnSpecificSearch(input.getColumnsAsMap())) {
            customQuery = "";
        }
        return tempCompanyService.DTData(input, request, customSearchCriteria, customQuery);
    }
}
