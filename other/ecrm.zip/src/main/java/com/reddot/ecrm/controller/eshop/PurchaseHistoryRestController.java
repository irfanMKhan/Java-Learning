package com.reddot.ecrm.controller.eshop;

import com.reddot.ecrm.dto.eshop.PurchaseHistoryDTO;
import com.reddot.ecrm.entity.eshop.EshopFileInfo;
import com.reddot.ecrm.entity.eshop.PurchaseHistory;
import com.reddot.ecrm.entity.eshop.SubContractsEntity;
import com.reddot.ecrm.service.eshop.EshopFileInfoService;
import com.reddot.ecrm.service.eshop.ExcelService;
import com.reddot.ecrm.service.eshop.FilesStorageService;
import com.reddot.ecrm.service.eshop.PurchaseHistoryService;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/crm/eShop")
public class PurchaseHistoryRestController {

    private final Path root = Paths.get("D:\\QRImages");

    @Autowired
    private PurchaseHistoryService purchaseHistoryService;

    @Autowired
    private FilesStorageService storageService;

    @Autowired
    private EshopFileInfoService eshopFileInfoService;

    @Autowired
    private ExcelService excelService;

    @GetMapping("/dataTable/purchaseData")
    public DataTablesOutput<PurchaseHistory> purchaseData(@Valid DataTablesInput input, HttpServletRequest request, @RequestParam(value = "searchText", required = false) String searchText, @RequestParam(value = "searchCol", required = false) String searchCol, @RequestParam(value = "customSearchCriteria", required = false) String customQuery) {
        return purchaseHistoryService.getDataTablePurchaseHistory(input, request, searchText, searchCol, customQuery);
    }

    @PostMapping("/addPurchaseHistory")
    public String purchaseData(HttpServletRequest request, @RequestBody PurchaseHistoryDTO purchaseHistoryData) {
        if (purchaseHistoryData.getId() != null) {
            //update
            return purchaseHistoryService.updatePurchaseHistory(request, purchaseHistoryData);
        }
        return purchaseHistoryService.addPurchaseHistory(request, purchaseHistoryData);
    }

    /*@GetMapping("/getSubContractProductName")
    public List<String> getSubContractProductName(HttpServletRequest request, @RequestParam(value = "companyName", required = false) String companyName) {
        return purchaseHistoryService.getSubContractProductName(request, companyName);
    }*/

    @GetMapping("/getSubContractProductName")
    public List<SubContractsEntity> getSubContractProductName(HttpServletRequest request, @RequestParam(value = "companyName", required = false) String companyName) {
        return purchaseHistoryService.getSubContractProductName(request, companyName);
    }


    @PostMapping("/upload")
    public String uploadFiles(@RequestParam("file") MultipartFile[] files, @RequestParam("purchaseNo") String purchaseNo, @RequestParam("product") String product, HttpServletRequest request) {
        String message = "";
        try {
            List<String> fileNames = new ArrayList<>();

            EshopFileInfo data = new EshopFileInfo();
            Arrays.asList(files).stream().forEach(file -> {
                String fileType = FilenameUtils.getExtension(file.getOriginalFilename());
                if (fileType.equalsIgnoreCase("XLSX")) {
                    excelService.eTopUpSave(file, purchaseNo, product, request);
                } else {

                    Optional<EshopFileInfo> oldData = eshopFileInfoService.getEshopFileInfoById(purchaseNo);
                    if (oldData.isPresent()) {
                        // EshopFileInfo oldData = eshopFileInfoService.getEshopFileInfoById(purchaseNo).get();

                        oldData.get().setType(FilenameUtils.getExtension(file.getOriginalFilename()));
                        oldData.get().setName(FilenameUtils.getName(file.getOriginalFilename()));
                        oldData.get().setUrl(root + "\\" + file.getOriginalFilename());
                        oldData.get().setProduct(product);
                        //eshopFileInfoRepository.save(data);
                        eshopFileInfoService.createEshopFileInfo(oldData.get());


                    } else {
                        data.setType(FilenameUtils.getExtension(file.getOriginalFilename()));
                        data.setName(FilenameUtils.getName(file.getOriginalFilename()));
                        data.setUrl(root + "\\" + file.getOriginalFilename());
                        data.setPurchaseNo(purchaseNo);
                        data.setProduct(product);
                        eshopFileInfoService.createEshopFileInfo(data);

                    }
                    try {
                        data.setData(file.getBytes());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    try {
                        data.setFileContent(file.getBytes());

                    } catch (Exception ex) {

                    }
                    storageService.save(file);

                }
                fileNames.add(file.getOriginalFilename());
            });

            return "success";
        } catch (Exception e) {
            return "fail";
        }
    }


}
