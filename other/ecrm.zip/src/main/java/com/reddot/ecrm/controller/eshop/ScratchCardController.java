package com.reddot.ecrm.controller.eshop;

import com.reddot.ecrm.service.eshop.ScratchCardService;
import com.reddot.ecrm.service.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/crm/eShop")
public class ScratchCardController {

    @Autowired
    private ScratchCardService scratchCardService;

    @Autowired
    private UserService userService;

    // we will use if we need later
}
