package com.reddot.ecrm.dto.contract;

import com.reddot.ecrm.dto.product.ProductDetailsDTO;
import com.reddot.ecrm.entity.msisdn.MsisdnEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ContractInformationDTO {

    private Long CompanyId;
    private Long parentCustomerAccountId;
    private Long mainCorAccountAccountId;
    private Long mainCorSubscriberAccountId;
    private Long branchAccountAccountId;
    private Long branchSubscriberAccountId;
    private Long cugId;
    private Long cugAccountId;

    private String CUST_ID;
    private String CUG_GRP_CODE;

    private String Branch_GRP_ID;
    private String Branch_GRP_CODE;
    private String Branch_GRP_NAME;

    private String Main_Grp_ID;
    private String Main_Grp_Code;
    private String Main_Grp_Name;

    private LogRelatedInfo logRelatedInfo;

    private List<MsisdnEntity> finalMsisdnListToSave;
    private List<ProductDetailsDTO> debitNoteProductList;

    private String otherTypeDescription;


    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class LogRelatedInfo {
        private Integer lastStepNumber;
        private String transactionNumber;
    }


}
