package com.reddot.ecrm.controller.lead.settings;

import com.reddot.ecrm.dto.lead.settings.ProdServDto;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.lead.settings.ProdServService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequestMapping("lead/prodServ")
public class ProdServRestController {
    
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    
    @Autowired
    private ProdServService prodServService;
    
    @GetMapping("/dt/all")
    public DataTablesOutput<ProdServDto> dtProdServ(@Valid DataTablesInput input, HttpServletRequest request,
                                                               @RequestParam(value = "searchText", required = false) String searchText, @RequestParam(value = "searchCol", required = false) String searchCol) {
        return prodServService.getDTProdServ(input, request, searchText, searchCol);
    }
    
    @PostMapping("/add")
    public CommonRestResponse addProdServ(HttpServletRequest request, @RequestBody ProdServDto prodServDto) {
        return prodServService.addProdServ(request, prodServDto);
    }
    
    @GetMapping("/details")
    public CommonRestResponse getProdServById(@RequestParam("id") Long id) {
        return prodServService.getProdServById(id);
    }
    
    @PostMapping("/update")
    public CommonRestResponse updateProdServ(HttpServletRequest request,
                                             @RequestBody ProdServDto prodServDto) {
        return prodServService.updateProdServ(request, prodServDto);
    }
    
}