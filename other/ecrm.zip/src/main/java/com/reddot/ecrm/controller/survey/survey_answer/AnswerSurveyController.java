package com.reddot.ecrm.controller.survey.survey_answer;


import com.reddot.ecrm.entity.survey.SurveyEntity;
import com.reddot.ecrm.entity.survey.survey_participated.ParticipatedSurveyAnswerEntity;
import com.reddot.ecrm.enum_config.survey.SurveyAnswerEnum;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.answerQuestionWithOption.AnswerQuestionWithOptionModel;
import com.reddot.ecrm.repository.survey.SurveyRepository;
import com.reddot.ecrm.repository.survey_participated.ParticipatedSurveyRepository;
import com.reddot.ecrm.service.survey.survey_answer.AnswerSurveyService;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/survey/answer")
public class AnswerSurveyController {


    @Autowired
    ParticipatedSurveyRepository participatedSurveyRepository;
    @Autowired
    private AnswerSurveyService answerSurveyService;
    @Autowired
    private SurveyRepository surveyRepository;

    @GetMapping
    public String viewPage(@RequestParam("id") Long surveyId, @RequestParam("token") String surveyUuidToken, ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        Optional<SurveyEntity> surveyEntity = surveyRepository.findByIdAndUuidToken(surveyId, surveyUuidToken);

        if (!surveyEntity.isPresent()) {
            return "Did Not Found any Survey!!!";
        }

        List<AnswerQuestionWithOptionModel> questionList = answerSurveyService.QuestionList1(surveyId);
        int totalCount = questionList.size();

        SurveyEntity survey = answerSurveyService.getSurveyById(surveyId);
        Optional<ParticipatedSurveyAnswerEntity> participatedSurvey = participatedSurveyRepository.findByCreatedByAndSurveyId(Utility.loggedInId(request),
                surveyId);
        if (participatedSurvey.isPresent() && !ObjectUtils.isEmpty(participatedSurvey.get().getStatus()) && participatedSurvey.get().getStatus().equals(SurveyAnswerEnum.FinalSave.toString())) {
            model.put("surveyAnsSaveType", SurveyAnswerEnum.FinalSave.toString());
        }

        model.put("surveyEntity", survey);
        model.put("questionList", questionList);

        model.put("totalQuesCount", totalCount);
        model.addAttribute("breadcrumb", "Survey Details");
        model.addAttribute("surveyName", survey.getSurveyName());
        model.put("title", "Survey Answer");
        return "survey/answerSurvey/answersurvey1";
    }


    @GetMapping("/viewResponse")
    public String viewResponseAnsPage(@RequestParam("sId") Long surveyId, @RequestParam("pId") Long participantId, ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

//        Optional<SurveyEntity> surveyEntity = surveyRepository.findByIdAndUuidToken(surveyId, surveyUuidToken);
//
//        if (!surveyEntity.isPresent()) {
//            return "Did Not Found any Survey!!!";
//        }

        List<AnswerQuestionWithOptionModel> questionList = answerSurveyService.QuestionList1(surveyId);
        int totalCount = questionList.size();

        SurveyEntity survey = answerSurveyService.getSurveyById(surveyId);
        Optional<ParticipatedSurveyAnswerEntity> participatedSurvey = participatedSurveyRepository.findByCreatedByAndSurveyId(participantId,
                surveyId);

        model.put("surveyAnsSaveType", SurveyAnswerEnum.FinalSave.toString()); //make final save to disable edit button, and hide submit div

        model.put("surveyEntity", survey);
        model.put("questionList", questionList);

        model.put("totalQuesCount", totalCount);
        model.addAttribute("breadcrumb", "Survey Details");
        model.addAttribute("surveyName", survey.getSurveyName());
        model.put("title", "Survey Answer");
        return "survey/answerSurvey/answersurvey1";
    }
// server side pagination
//    @GetMapping
//    public String viewPage(@RequestParam("id") Long surveyId, @RequestParam(value = "page", required = false) Integer page, ModelMap model, HttpServletRequest request) {
//        new MenuViewer().setupSideMenu(model, request);
//        Long totalCount = answerSurveyService.totalCountOfQuestion(surveyId);
//        Integer totalPage = (int) Math.ceil(Math.toIntExact(totalCount / 10));
//        Pageable pageable = PageRequest.of(page,10);
//        List<AnswerQuestionWithOptionModel> questionList = answerSurveyService.QuestionList(surveyId,pageable);
//
//        SurveyEntity survey = answerSurveyService.getSurveyById(surveyId);
//        model.put("surveyEntity", survey);
//        model.put("questionList", questionList);
//
//        model.put("curPage",page);
//        model.put("totalPage",totalPage);
//        model.put("title", "Survey Answer");
//        //return "answerSurvey/answerSurvey_datatable";
//        return "answerSurvey/answersurvey";
//    }
}
