package com.reddot.ecrm.creditCeiling;

import com.reddot.ecrm.menu.MenuViewer;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequiredArgsConstructor
@RequestMapping(value = "/tut_tut")
public class CreditCeilingHistoryController {
    @GetMapping
    public String viewCreditCeilingHistory(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "View Credit Ceiling History List");
        return "/credit_ceiling/credit_ceiling_list";
    }
}
