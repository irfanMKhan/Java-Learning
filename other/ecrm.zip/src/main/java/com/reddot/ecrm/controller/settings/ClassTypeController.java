package com.reddot.ecrm.controller.settings;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.UserModel;
import com.reddot.ecrm.model.settings.ClassTypeModel;
import com.reddot.ecrm.service.settings.ClassTypeService;
import com.reddot.ecrm.service.user.UserService;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/settings")
public class ClassTypeController {
    @Autowired
    UserService userService;

    @Autowired
    ClassTypeService classTypeService;

    @RequestMapping(value = "/classType", method = RequestMethod.GET)
    public String classTypeList(ModelMap model, HttpServletRequest request, Principal principal){
        new MenuViewer().setupSideMenu(model, request);
        List<UserModel> userData = new ArrayList<>();
        userData = new Gson().fromJson(Utility.ObjectToJson(userService.getUserByUserName(principal.getName())), new TypeToken<List<UserModel>>(){}
                .getType());
        model.addAttribute("userData", userData.get(0));
        model.addAttribute("title", "Class Type List");
        return "settings/class_type/class-type-list";
    }

    @RequestMapping(value = "/classType/add", method = RequestMethod.GET)
    public String addClassType(ModelMap model, HttpServletRequest request, Principal principal){
        new MenuViewer().setupSideMenu(model, request);

        List<UserModel> userData = new ArrayList<>();
        userData = new Gson().fromJson(Utility.ObjectToJson(userService.getUserByUserName(principal.getName())), new TypeToken<List<UserModel>>(){}
                .getType());
        model.addAttribute("userData", userData.get(0));
        model.addAttribute("title", "Add Class Type");

        return "settings/class_type/class-type-add";
    }

    @RequestMapping(value = "/classType/{id}", method = RequestMethod.GET)
    public String editClassType(ModelMap model, HttpServletRequest request, @PathVariable(name = "id") Long id, Principal principal){
        new MenuViewer().setupSideMenu(model, request);

        List<UserModel> userData = new ArrayList<>();
        userData = new Gson().fromJson(Utility.ObjectToJson(userService.getUserByUserName(principal.getName())), new TypeToken<List<UserModel>>(){}
                .getType());

        List<ClassTypeModel> classTypeModels = new ArrayList<>();
        classTypeModels = new Gson().fromJson(Utility.ObjectToJson(classTypeService.getClassTypeById(id)), new TypeToken<List<ClassTypeModel>>(){}
                .getType());

        model.addAttribute("userData", userData.get(0));
        model.addAttribute("title", "Update Class Type");
        model.addAttribute("classType", classTypeModels);

        return "settings/class_type/class-type-update";
    }
}
