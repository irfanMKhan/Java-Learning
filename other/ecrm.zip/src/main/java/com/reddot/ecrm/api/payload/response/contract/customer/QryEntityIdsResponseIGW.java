package com.reddot.ecrm.api.payload.response.contract.customer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class QryEntityIdsResponseIGW {
    private String Code;
    private String Message;
    private Data Data;


    @AllArgsConstructor
    @NoArgsConstructor
    @lombok.Data
    public static class Data {
        private String CustomerId;
        private String CustName;
        private String CreateDate;
        private List<AcctInfoNoMappingGroup> AcctInfoNoMappingGroup;
        private List<GroupInfo> GroupInfo;

        @lombok.Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class AcctInfoNoMappingGroup {
            private String AcctId;
            private String Acctcode;
            private String AcctName;
        }

        @lombok.Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class GroupInfo {
            private MainGroup MainGroup;
            private List<SubGroup> SubGroup;

            @lombok.Data
            @AllArgsConstructor
            @NoArgsConstructor
            public static class MainGroup {
                private String AcctId;
                private String Acctcode;
                private String AcctName;
                private String GroupId;
                private String GroupCode;
                private String GroupName;
            }

            @lombok.Data
            @AllArgsConstructor
            @NoArgsConstructor
            public static class SubGroup {
                private String AcctId;
                private String Acctcode;
                private String AcctName;
                private String GroupId;
                private String GroupCode;
                private String GroupName;
            }
        }
    }
}
