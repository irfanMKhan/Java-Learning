package com.reddot.ecrm.controller.approval.approval_flow_rules;

import com.reddot.ecrm.entity.approval.ApprovalFlowRulesEntity;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.approval.ApprovalFlowRulesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("approval/flow/rules/rest")
public class ApprovalFlowRulesRest {
    @Autowired
    ApprovalFlowRulesService approvalFlowRulesService;

    @GetMapping("/get/allCategoryData")
    public CommonRestResponse getAllCategoryData(HttpServletRequest request) {
        return approvalFlowRulesService.getAllCategoryData(request);
    }

    @PostMapping("/add")
    public CommonRestResponse addFlow(@RequestBody ApprovalFlowRulesEntity approvalFlowRulesEntity, HttpServletRequest request) {
        return approvalFlowRulesService.addRulesData(approvalFlowRulesEntity, request);
    }

    @PostMapping("/getAllByFlowID")
    public CommonRestResponse getAllByFlowID(@RequestBody Long flowId, HttpServletRequest request) {
        return approvalFlowRulesService.getAllByFlowID(flowId, request);
    }

    @PostMapping("/update")
    public CommonRestResponse updateData(@RequestBody ApprovalFlowRulesEntity approvalFlowRules, HttpServletRequest request) {
        return approvalFlowRulesService.updateData(approvalFlowRules, request);
    }

    @PostMapping("/delete")
    public CommonRestResponse deleteData(@RequestBody Long id) {
        return approvalFlowRulesService.deleteData(id);
    }
}
