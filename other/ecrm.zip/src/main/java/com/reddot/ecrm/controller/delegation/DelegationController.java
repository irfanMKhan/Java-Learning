package com.reddot.ecrm.controller.delegation;

import com.reddot.ecrm.entity.approval.ApprovalFlowEntity;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/delegation")
public class DelegationController {
    @Autowired
    CommonRepository commonRepository;

    @GetMapping()
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        String sql = String.format("Select * from %s where id not in (%s)", Utility.md_user, Utility.loggedInId(request));
        List<Map<String, Object>> userList = (List<Map<String, Object>>) commonRepository.CommoGetData(sql);

        model.put("userList", userList);
        model.put("title", "Delegation");
        return "delegation/delegation_ui";
    }
}
