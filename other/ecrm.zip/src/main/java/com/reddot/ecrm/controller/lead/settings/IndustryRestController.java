package com.reddot.ecrm.controller.lead.settings;

import com.reddot.ecrm.dto.lead.settings.IndustryDto;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.lead.settings.IndustryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequestMapping("lead/industry")
public class IndustryRestController {
    
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    
    @Autowired
    private IndustryService industryService;
    
    @GetMapping("/dt/all")
    public DataTablesOutput<IndustryDto> dtIndustry(@Valid DataTablesInput input, HttpServletRequest request,
                                                     @RequestParam(value = "searchText", required = false) String searchText, @RequestParam(value = "searchCol", required = false) String searchCol) {
        return industryService.getDTIndustry(input, request, searchText, searchCol);
    }
    
    @PostMapping("/add")
    public CommonRestResponse addIndustry(HttpServletRequest request, @RequestBody IndustryDto industryDto) {
        return industryService.addIndustry(request, industryDto);
    }
    
    @GetMapping("/details")
    public CommonRestResponse getIndustryById(@RequestParam("id") Long id) {
        return industryService.getIndustryById(id);
    }
    
    @PostMapping("/update")
    public CommonRestResponse updateIndustry(HttpServletRequest request,
                                               @RequestBody IndustryDto industryDto) {
        return industryService.updateIndustry(request, industryDto);
    }
    
}