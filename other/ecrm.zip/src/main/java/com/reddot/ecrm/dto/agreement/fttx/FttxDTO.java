package com.reddot.ecrm.dto.agreement.fttx;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class FttxDTO {
    private String uniqueNumber;
    private String templateName;
}
