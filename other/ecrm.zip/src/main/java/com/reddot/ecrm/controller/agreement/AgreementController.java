package com.reddot.ecrm.controller.agreement;

import com.reddot.ecrm.dto.GlobalSettings.User.MDUserModel;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.service.ContractAgreementReportService;
import com.reddot.ecrm.session.SessionManager;
import lombok.RequiredArgsConstructor;
import net.sf.jasperreports.engine.JRException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.concurrent.ExecutionException;

@Controller
@RequiredArgsConstructor
@RequestMapping("/agreement/report")
public class AgreementController {

    private final ContractAgreementReportService contractAgreementReportService;

    @GetMapping
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        MDUserModel mdUserModel = SessionManager.getUserDetails(request);
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Agreement Report");
        return "agreement/index";
    }

    @RequestMapping(value = "/emailOrDownload", method = RequestMethod.POST)
    @ResponseBody
    public void emailOrDownload(HttpServletRequest request, HttpServletResponse response, @RequestParam("fileType") String fileType,@RequestParam("companyName") String companyName,@RequestParam("buttonName") String buttonName) throws IOException, ExecutionException, InterruptedException, JRException {
        contractAgreementReportService.emailOrDownloadContractAgreement(request, response, fileType,null,buttonName);
    }
}
