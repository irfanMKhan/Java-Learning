package com.reddot.ecrm.controller.cr.delay_payment;

import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.spring_config.session.SessionManager;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/cr/delay-payment")
public class DelayPaymentController {

    @GetMapping("")
    public String viewDelayPayment() {
        return "redirect:/cr/delay-payment/list";
    }

    @GetMapping("/list")
    String viewDelayPaymentList(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "PTP/Delay Payment");
        return "cr/delay_payment/delay_payment_list";
    }

    @GetMapping("/add")
    String viewDelayPaymentAdd(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        MDUserModel user = SessionManager.getUserDetails(request);

        model.put("title", "PTP/Delay Payment");
        model.put("login_name", user.getLOGIN_NAME());
        model.put("name", user.getNAME());
        model.put("logged_in_id", user.getID());

        return "cr/delay_payment/delay_payment_add";
    }

    @GetMapping("/invoice-partial")
    String viewDelayPaymentPartial() {
        return "cr/delay_payment/delay_payment_partial";
    }
}
