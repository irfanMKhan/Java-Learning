package com.reddot.ecrm.delayPayment.rest.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetAllPromiseToPayDetailByPromiseToPayId {
    private String promiseToPayId;
}
