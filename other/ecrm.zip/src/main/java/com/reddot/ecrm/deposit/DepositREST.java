package com.reddot.ecrm.deposit;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.creditCeiling.CreditCeilingHistory;
import com.reddot.ecrm.creditCeiling.CreditCeilingHistoryReqBodyForAdd;
import com.reddot.ecrm.creditCeiling.CreditCeilingHistoryReqBodyForGetById;
import com.reddot.ecrm.creditCeiling.CreditCeilingHistorySearchReqDTO;
import com.reddot.ecrm.entity.attachment.AttachmentEntity;
import com.reddot.ecrm.entity.cr.CRMsisdnDetailsEntity;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping("/deposit")
public class DepositREST {

    @Autowired
    private DepositService depositService;

    @RequestMapping(value = "/get-all-v1", method = RequestMethod.GET)
    public ResponseEntity<?> getAllDepositList() {
        return depositService.getAllDepositList();
    }

    @RequestMapping(value = "/search-dt", method = RequestMethod.POST)
    public DataTablesOutput<Deposit> searchDT(HttpServletRequest request, @RequestBody Map<String, Object> data) throws IOException {
        DataTablesInput input = new Gson().fromJson(Utility.ObjectToJson(data.get("dtInput")), new TypeToken<DataTablesInput>() {
        }.getType());

        ObjectMapper mapper = new ObjectMapper();
        DepositSearchReqDTO depositSearchReqDTO = mapper.readValue(data.get("searchData").toString(), DepositSearchReqDTO.class);

        MDUserModel mdUserModel = Utility.getLoggedInUserDetails(request);
        if( mdUserModel.getUSER_TYPE().equalsIgnoreCase("PIC") ){
            depositSearchReqDTO.setCompanyId(mdUserModel.getCOMPANY_ID().toString());
        }

        System.out.println(depositSearchReqDTO.getCompanyId());

        return depositService.searchDT(input, depositSearchReqDTO);
    }

    @RequestMapping(value = "/get-all-company", method = RequestMethod.GET)
    public ResponseEntity<?> getAllCompany(HttpServletRequest httpServletRequest) {
        return depositService.getAllCompany(httpServletRequest);
    }

    @RequestMapping(value = "/get-all-master-acc-by-company-id", method = RequestMethod.POST)
    public ResponseEntity<?> getAllMasterAccByCompanyId(HttpServletRequest httpServletRequest, @RequestBody GetAllMasterAccByCompanyIdReqBody reqBody) {
        return depositService.getAllMasterAccByCompanyId(httpServletRequest, reqBody);
    }

    @RequestMapping(value = "/get-company-acc-by-id", method = RequestMethod.POST)
    public ResponseEntity<?> getCompanyAccById(HttpServletRequest httpServletRequest, @RequestBody GetCompanyAccByIdReqBody reqBody) {
        return depositService.getCompanyAccById(httpServletRequest, reqBody);
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public ResponseEntity<?> addDeposit(HttpServletRequest httpServletRequest, @RequestBody DepositAddReqBody reqBody) {
        return depositService.addDeposit(httpServletRequest, reqBody);
    }

    @RequestMapping(value = "/add-of-reopened-deposit", method = RequestMethod.POST)
    public ResponseEntity<?> addOfReopenedDeposit(HttpServletRequest httpServletRequest, @RequestBody DepositAddReqBody reqBody) {
        return depositService.addDeposit(httpServletRequest, reqBody);
    }

    @RequestMapping(value = "/get-deposite-row-by-id", method = RequestMethod.POST)
    public ResponseEntity<?> getDepositeRowByID(HttpServletRequest httpServletRequest, @RequestBody GetDepositeRowByIdReqBody reqBody) {
        return depositService.getDepositeRowByID(httpServletRequest, reqBody);
    }

    @PostMapping("/get-deposite-data-row-by-id")
    public DataTablesOutput<Deposit> getAllDepositData(HttpServletRequest httpServletRequest, DataTablesInput input, @RequestBody GetDepositeRowByIdReqBody reqBody) {
        return depositService.getAllDepositChildData(httpServletRequest, input, reqBody);
    }

    @PostMapping("/get-attachment")
    public List<AttachmentEntity> getAllDepositAttachment(HttpServletRequest httpServletRequest, DataTablesInput input, @RequestBody GetDepositeRowByIdReqBody reqBody) {
        return depositService.getAllDepositAttachment(httpServletRequest, reqBody);
    }

    @RequestMapping(value = "/get-third-party-data", method = RequestMethod.POST)
    public ResponseEntity<?> getThirdPartyData(HttpServletRequest httpServletRequest, @RequestBody ThirdPartyReqBody reqBody) {
        return depositService.getThirdPartyData(httpServletRequest, reqBody);
    }
}
