package com.reddot.ecrm.api.payload.response.opportunity;

import lombok.Data;

@Data
public class UnReserveMSISDNResponse {
    private int code;
    private String message;
    private String timestamp;
    private Data data;

    @lombok.Data
    public static class Data {
        private String code;
        private String message;
        private String correlation_id;
        private String release_date;
    }
}
