package com.reddot.ecrm.api.exception;

public class InternalServerErrorSmartException extends RuntimeException {

    public InternalServerErrorSmartException() {
        super();
    }

    public InternalServerErrorSmartException(String message) {
        super(message);
    }

    public InternalServerErrorSmartException(String message, Throwable throwable) {
        super(message, throwable);
    }

}
