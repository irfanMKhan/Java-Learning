package com.reddot.ecrm.controller.utility;

import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/v1")
public class UtilityController {

}
