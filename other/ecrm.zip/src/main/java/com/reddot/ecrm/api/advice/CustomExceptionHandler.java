package com.reddot.ecrm.api.advice;


import com.reddot.ecrm.api.exception.ApiRequestException;
import com.reddot.ecrm.api.exception.ConnectionResetException;
import com.reddot.ecrm.api.exception.InvalidAccessTokenException;
import com.reddot.ecrm.api.exception.InvalidClientCredentialException;
import com.reddot.ecrm.api.utility.CommonConstant;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
public class CustomExceptionHandler {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<BadRequestExceptionResponse> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();

        ex.getBindingResult().getFieldErrors().forEach(error ->
                errors.put(error.getField(), error.getDefaultMessage()));

        Map.Entry<String, String> entry = errors.entrySet().iterator().next();
        String firstErrorMessage = entry.getValue();

        BadRequestExceptionResponse response = new BadRequestExceptionResponse();
        response.setCode(HttpStatus.BAD_REQUEST.value());
        response.setMessage(firstErrorMessage);
        response.setErrors(errors);
        response.setTimestamp(new Date());

        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ResponseEntity<BadRequestExceptionResponse> handleMissingServletRequestParameterException(MissingServletRequestParameterException ex) {
        Map<String, String> errors = new HashMap<>();

        errors.put(ex.getParameterName(), ex.getParameterName() + " is required.");

        Map.Entry<String, String> entry = errors.entrySet().iterator().next();
        String firstErrorMessage = entry.getValue();

        BadRequestExceptionResponse response = new BadRequestExceptionResponse();
        response.setCode(HttpStatus.BAD_REQUEST.value());
        response.setMessage(firstErrorMessage);
        response.setErrors(errors);
        response.setTimestamp(new Date());

        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = ApiRequestException.class)
    public ResponseEntity<Object> handleApiRequestException(ApiRequestException e) {
        CustomExceptionResponse customExceptionResponse = new CustomExceptionResponse(
                HttpStatus.BAD_REQUEST.value(),
                e.getMessage(),
                new HashMap<>(),
                new Date()
        );
        return new ResponseEntity<>(customExceptionResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = MethodArgumentTypeMismatchException.class)
    public ResponseEntity<Object> handleMethodArgumentTypeMismatchException(MethodArgumentTypeMismatchException ex) {

        Map<String, String> errors = new HashMap<>();

        errors.put(ex.getParameter().getParameterName(), ex.getName() + " is invalid.");

        Map.Entry<String, String> entry = errors.entrySet().iterator().next();
        String firstErrorMessage = entry.getValue();

        BadRequestExceptionResponse response = new BadRequestExceptionResponse();
        response.setCode(HttpStatus.BAD_REQUEST.value());
        response.setMessage(firstErrorMessage);
        response.setErrors(errors);
        response.setTimestamp(new Date());

        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = InvalidAccessTokenException.class)
    public ResponseEntity<Object> handleInvalidAccessTokenException(InvalidAccessTokenException e) {
        CustomExceptionResponse customExceptionResponse = new CustomExceptionResponse(
                CommonConstant.ACCESS_TOKEN_ERROR_CODE,
                CommonConstant.ACCESS_TOKEN_ERROR_MGS,
                new HashMap<>(),
                new Date()
        );
        return new ResponseEntity<>(customExceptionResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = InvalidClientCredentialException.class)
    public ResponseEntity<Object> handleInvalidClientCredentialsException(InvalidClientCredentialException e) {
        CustomExceptionResponse customExceptionResponse = new CustomExceptionResponse(
                CommonConstant.AUTHORIZATION_CREDENTIALS_ERROR_CODE,
                CommonConstant.AUTHORIZATION_CREDENTIALS_ERROR_MGS,
                new HashMap<>(),
                new Date()
        );
        return new ResponseEntity<>(customExceptionResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = BadCredentialsException.class)
    public ResponseEntity<Object> handleBadCredentialsException(BadCredentialsException e) {
        CustomExceptionResponse customExceptionResponse = new CustomExceptionResponse(
                HttpStatus.BAD_REQUEST.value(),
                e.getMessage(),
                new HashMap<>(),
                new Date()
        );
        return new ResponseEntity<>(customExceptionResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = UsernameNotFoundException.class)
    public ResponseEntity<Object> handleUsernameNotFoundException(UsernameNotFoundException e) {
        CustomExceptionResponse customExceptionResponse = new CustomExceptionResponse(
                HttpStatus.BAD_REQUEST.value(),
                e.getMessage(),
                new HashMap<>(),
                new Date()
        );
        return new ResponseEntity<>(customExceptionResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(value = ConnectionResetException.class)
    public ResponseEntity<Object> handleConnectionResetException(ConnectionResetException e) {
        CustomExceptionResponse customExceptionResponse = new CustomExceptionResponse(
                HttpStatus.REQUEST_TIMEOUT.value(),
                e.getMessage(),
                new HashMap<>(),
                new Date()
        );
        return new ResponseEntity<>(customExceptionResponse, HttpStatus.REQUEST_TIMEOUT);
    }
}
