package com.reddot.ecrm.controller.home;


import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.model.User.UserInstituteModel;
import com.reddot.ecrm.service.company.CompanyService;
import com.reddot.ecrm.spring_config.session.SessionConstants;
import com.reddot.ecrm.spring_config.session.SessionManager;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

@Controller
@RequiredArgsConstructor
@RequestMapping(value = "/", method = RequestMethod.GET)
public class DashboardController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    private final CompanyService companyService;

    @GetMapping({"", "/dashboard"})
    public String redirectToHome() {
        return "redirect:/home";
    }

    @GetMapping(value = "/home")
    public String showHomePage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        AtomicBoolean is_admin = new AtomicBoolean(false);
        AtomicBoolean is_kam = new AtomicBoolean(false);
        AtomicBoolean is_pic = new AtomicBoolean(false);

        List<CompanyEntity> companyEntities;
        List<CompanyEntity> allCompanyEntities;

        model.addAttribute("title", "Dashboard");

        MDUserModel userModel = SessionManager.getUserDetails(request);
        if ( userModel != null && !userModel.getRoleEntityList().isEmpty()) {
            userModel.getRoleEntityList().forEach(item -> {
                if (item.getName().equals("KAM")) {
                    is_kam.set(true);
                }
                if (item.getName().equals("ADMIN")) {
                    is_admin.set(true);
                }
            });
        }

        model.addAttribute("is_kam", is_kam.get());
        model.addAttribute("is_admin", is_admin.get());
        if (userModel.getUSER_TYPE().equalsIgnoreCase("PIC")) {
            is_pic.set(true);
        }
        model.addAttribute("is_pic", is_pic.get());

        model.addAttribute("company_details", null);

        if (userModel.getCOMPANY_ID() != null && is_pic.get()) {
            CompanyEntity company = companyService.getCompanyById(userModel.getCOMPANY_ID().toString());
            model.addAttribute("company_details", company);
            return "home/index_pic";
        } else {
            companyEntities = companyService.getCompanyListForKam(userModel.getID());
            allCompanyEntities = companyService.getAllCompany();
            if (is_kam.get() && !companyEntities.isEmpty()) {
                model.addAttribute("company_details", Utility.EntityObjectToJsonConvert(companyEntities, false));
            }
            if (is_admin.get() && !allCompanyEntities.isEmpty()) {
                String objectToJson = Utility.EntityObjectToJsonConvert(allCompanyEntities, false);

                model.addAttribute("company_details", objectToJson);
            }
            return "home/index";
        }
    }

    @RequestMapping(value = "/preLogin", method = RequestMethod.GET)
    public String preLogin(ModelMap model, HttpServletRequest request) {
        model.put("userFullName", SessionManager.getUserDetails(request).getNAME());
        model.put("title", "Choose Company");
        List<String> companyList = new ArrayList<>();
        for (int i = 1; i <= 20; i++) {
            companyList.add("Company " + i);
        }

        try {
            if (SessionManager.getUserDetails(request).getUSER_GROUP_ID() == 1) {
                model.addAttribute("companyList", companyList);
                return "home/pre_login";
            }
        } catch (Exception e) {
            System.err.println("Error!");
            e.printStackTrace();
            logger.error(e.getMessage());

        }
        return "redirect:/home";
    }

    @RequestMapping(value = "/transit", method = RequestMethod.GET)
    public String showInstitute(ModelMap model, HttpServletRequest request) {
        List<UserInstituteModel> insList = new ArrayList<UserInstituteModel>();
        insList = SessionManager.getUserInstitutes(request);
        if (!insList.isEmpty() && insList.size() > 1) {
            model.addAttribute("title", "Institute Select");
            model.addAttribute("institutes", insList);
            return "home/transit";
        } else {
            return "redirect:/home";
        }
    }

    @RequestMapping(value = "/transit", method = RequestMethod.POST)
    public String redirectHome(ModelMap model, @RequestParam Long institute, HttpServletRequest request) {
        List<UserInstituteModel> insList = new ArrayList<UserInstituteModel>();
        try {
            Long id = Utility.getUserId(request);
            insList = SessionManager.getUserInstitutes(request);
            if (insList.stream().anyMatch(ins -> ins.getINSTITUTE_ID() == institute)) {
                UserInstituteModel userIns = insList.stream().filter(x -> x.getINSTITUTE_ID() == institute).findFirst().get();
                MDUserModel mdUserModel = SessionManager.getUserDetails(request);
                mdUserModel.setINSTITUTE_ID(userIns.getINSTITUTE_ID());
                mdUserModel.setACADEMIC_YEAR_ID(userIns.getACADEMIC_YEAR_ID());
                request.getSession().setAttribute(SessionConstants.USER_DETAILS_ECRM.name(), mdUserModel);
            } else {
                return "redirect:/logout";
            }

            return "redirect:/home";

        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return "redirect:/logout";
    }
}
