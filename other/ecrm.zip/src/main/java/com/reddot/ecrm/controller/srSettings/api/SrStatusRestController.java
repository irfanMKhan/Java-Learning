package com.reddot.ecrm.controller.srSettings.api;


import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.model.srSettings.SRStatusModel;
import com.reddot.ecrm.service.srsettings.SrPriorityService;
import com.reddot.ecrm.service.srsettings.SrStatusService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequestMapping(value = "/api/srStatus", method = RequestMethod.GET)
public class SrStatusRestController {

    private final Logger logger = LoggerFactory.getLogger("SR Status Logger");

    @Autowired
    private SrStatusService service;

    @GetMapping("/all")
    public Object getAllStatus(){
        return service.getAllStatus();
    }

    @GetMapping("/DTData")
    public DataTablesOutput<SRStatusModel> DTInteractionType(@Valid DataTablesInput input, HttpServletRequest request,
                                                             @RequestParam(value = "searchText", required = false) String customQuery,
                                                             @RequestParam(value = "customSearchCriteria", required = false) String customSearchCriteria){
        return service.DTSrStatus(input, request, customSearchCriteria, customQuery);
    }

    @PostMapping("/add")
    public CommonRestResponse srStatusAdd(@RequestBody String srStatus, HttpServletRequest request){
        SRStatusModel SrStatusModel = new Gson().fromJson(srStatus, new TypeToken<SRStatusModel>(){}.getType());
//        SrStatusModel SrStatusModel = new Gson().fromJson(srPriority, SrStatusModel.class);
        System.err.println(srStatus);
        System.err.println(SrStatusModel);
        return service.addSrStatusFunction(SrStatusModel, request);
    }

    @GetMapping("/item")
    public CommonRestResponse getStatusItemById(@RequestParam("item") String id, HttpServletRequest request){
        String statusId = new Gson().fromJson(id, String.class);
        return service.getStatusItemById(statusId);
    }

    @PostMapping("/update")
    public CommonRestResponse updateStatusFunction(@RequestBody String statusData, HttpServletRequest request){
//        SrStatusModel SrStatusModel = new Gson().fromJson(priorityData,SrStatusModel.class);
        SRStatusModel SrStatusModel = new Gson().fromJson(statusData, new TypeToken<SRStatusModel>(){}.getType());
        System.err.println(statusData);
        System.err.println(SrStatusModel);
        return service.updateStatusFunction(SrStatusModel, request);
    }


}
