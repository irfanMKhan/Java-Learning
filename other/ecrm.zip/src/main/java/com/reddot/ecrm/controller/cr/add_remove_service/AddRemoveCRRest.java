package com.reddot.ecrm.controller.cr.add_remove_service;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.reddot.ecrm.dto.cr.CRSummarySearchDTO;
import com.reddot.ecrm.dto.cr.CRWithAttachmentDTO;
import com.reddot.ecrm.entity.cr.CRMsisdnDetailsEntity;
import com.reddot.ecrm.enum_config.bulk.BulkProcessFileTypeEnum;
import com.reddot.ecrm.enum_config.feature.RequestTypeEnum;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.cr.add_remove_service.AddRemoveService;
import com.reddot.ecrm.service.cr.change_plan.ChangePlanService;
import com.reddot.ecrm.util.LocalDateTypeAdapter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/cr/addRemoveService/rest")
public class AddRemoveCRRest {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    @Autowired
    AddRemoveService addRemoveService;
    @Autowired
    ChangePlanService changePlanService;

    @GetMapping("/summary/getAllData")
    public DataTablesOutput<CRMsisdnDetailsEntity> getAllSummaryData(
            HttpServletRequest request,
            @Valid DataTablesInput input,
            @RequestParam(value = "searchDto", required = false) String searchDtoJson
    ) {
        CRSummarySearchDTO searchDTO = null;
        if (searchDtoJson != null) {
            try {
                Gson gson = new GsonBuilder()
                        .registerTypeAdapter(LocalDate.class, new LocalDateTypeAdapter())
                        .create();
                searchDTO = gson.fromJson(searchDtoJson, CRSummarySearchDTO.class);

            } catch (Exception e) {
                System.out.println(e.getMessage());
                logger.error(String.format("AddRemoveCRRest:getAllSummaryData() Error: %s", e.getMessage()));
            }
        }
        return changePlanService.getSummaryQueryDataCommon(request, input, searchDTO, RequestTypeEnum.Add_Remove_Service);
    }

    @PostMapping("/saveAllData")
    public CommonRestResponse saveAllData(@RequestBody CRWithAttachmentDTO crWithAttachmentDTO, HttpServletRequest request) {
        return addRemoveService.addCRDetailsData(crWithAttachmentDTO, request, RequestTypeEnum.Add_Remove_Service);
    }

    @PostMapping("/upload/primaryPlan")
    public CommonRestResponse bulkUpload1(@RequestParam("file") MultipartFile file, @RequestParam("type") String type) throws ServletException, IOException {
        return changePlanService.UploadExcelFileDataPostman(file,type);
    }

    @PostMapping("/upload/supplementary")
    public CommonRestResponse bulkUpload2(HttpServletRequest request, @RequestParam("file") MultipartFile file, @RequestParam("type") String type) throws ServletException, IOException {
        return changePlanService.UploadExcelFileDataPostman(file,type);
    }

    @PostMapping("/getAll/attachmentByMasterID")
    public CommonRestResponse getAllAttachmentByMasterID(@RequestBody Long crMasterID, HttpServletRequest request) {
        return changePlanService.getAllAttachmentByMasterID(crMasterID, BulkProcessFileTypeEnum.Add_Remove_Service);
    }
}
