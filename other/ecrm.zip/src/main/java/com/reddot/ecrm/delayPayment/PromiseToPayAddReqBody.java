package com.reddot.ecrm.delayPayment;

import com.reddot.ecrm.delayPayment.rest.dto.PromiseToPayInvoiceMappingReqDTO;
import com.reddot.ecrm.dto.attachment.AttachmentDTO;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class PromiseToPayAddReqBody {
    private String accountCode;
    // private PromiseToPayReqDTO promiseToPay;
    // private List<PromiseToPayInvoiceMappingReqDTO> promiseToPayInvoiceMappingList;
    private List<AttachmentDTO> attachmentList;
    private List<PromiseToPayInvoiceMappingReqDTO> invoiceList;
    private String transType;
}
