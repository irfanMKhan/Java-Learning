package com.reddot.ecrm.dto.contract;

import com.reddot.ecrm.entity.company.CompanyEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CompanyDetailsContractDTO {
    private Long companyId;
    private Boolean hasContract;
    private CompanyEntity companyEntity;

}
