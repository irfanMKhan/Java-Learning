package com.reddot.ecrm.controller.contract;

import com.google.gson.Gson;
import com.reddot.ecrm.dto.agreement.ReportDownloadDTO;
import com.reddot.ecrm.dto.contract.ContractDTO;
import com.reddot.ecrm.dto.contract.ContractReqSingleDTO;
import com.reddot.ecrm.dto.contract.SearchContractDTO;
import com.reddot.ecrm.dto.httpServletRequest.HttpServletRequestDto;
import com.reddot.ecrm.entity.attachment.AttachmentEntity;
import com.reddot.ecrm.entity.company.CompanyAccountEntity;
import com.reddot.ecrm.entity.contact.ContactEntity;
import com.reddot.ecrm.entity.contract.ContractEntity;
import com.reddot.ecrm.entity.product.ProductDetailsEntity;
import com.reddot.ecrm.enum_config.feature.RequestTypeEnum;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.module.commonConfig.CommonConfig;
import com.reddot.ecrm.module.commonConfig.CommonConfigRepo;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.service.ContractAgreementReportService;
import com.reddot.ecrm.service.DropDownService;
import com.reddot.ecrm.service.SequenceGeneratorService;
import com.reddot.ecrm.service.attachment.AttachmentService;
import com.reddot.ecrm.service.company.CompanyAccountService;
import com.reddot.ecrm.service.contact.ContactService;
import com.reddot.ecrm.service.contract.ContractService;
import com.reddot.ecrm.service.email.EmailService;
import com.reddot.ecrm.service.product.ProductDetailsService;
import com.reddot.ecrm.spring_config.ThreadPool.SingletonThreadPool;
import com.reddot.ecrm.spring_config.session.SessionManager;
import com.reddot.ecrm.util.Utility;
import freemarker.template.TemplateException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Controller
@RequiredArgsConstructor
@RequestMapping("/contract")
@Slf4j
public class ContractViewController {

    private final ContractService contractService;
    private final DropDownService dropDownService;
    private final ProductDetailsService productDetailsService;
    private final AttachmentService attachmentService;
    private final ContactService contactService;
    private final CommonConfigRepo commonConfigRepo;
    private final SequenceGeneratorService sequenceGeneratorService;
    private final EmailService emailService;
    private final CommonRepository commonRepository;
    private final ContractAgreementReportService agreementReportService;
    private final CompanyAccountService companyAccountService;
    
    @Value("${app.base_url}")
    private String baseUrl;


    private final ThreadPoolTaskExecutor threadPoolTaskExecutor = SingletonThreadPool.getInstance();

    @GetMapping
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Contract List");
        return "contract/index";
    }

    @ResponseBody
    @GetMapping("/list")
    public List<ContractEntity> getContractList(HttpServletRequest request) {
        return contractService.getAllContract(request);
    }

    @ResponseBody
    @GetMapping(value = "/list/search")
    public DataTablesOutput<ContractEntity> getSearchContractList(@RequestParam(value = "searchDto", required = false) String searchDtoJson,
                                                                  @Valid DataTablesInput input,
                                                                  HttpServletRequest request) throws IllegalAccessException {
        SearchContractDTO searchDTO = new SearchContractDTO();
        if (searchDtoJson != null) {
            try {
                searchDTO = new Gson().fromJson(searchDtoJson, SearchContractDTO.class);
            } catch (Exception e) {
                log.error("ContractViewController getSearchContractList() Error: {}", e.getMessage());
            }
        }
        return contractService.findBySearchDTO(input, searchDTO, request);
    }

    /**
     * Add Contract Page
     */
    @GetMapping("/add")
    public String viewAddPage(@RequestParam(value = "cId", required = false) Long cId, @RequestParam(value = "cToken", required = false) String cToken,
                              @RequestParam(value = "oID", required = false) String oId, @RequestParam(value = "oToken", required = false) String oToken,
                              @RequestParam(value = "viewMode", required = false) String viewMode, ModelMap model, HttpServletRequest request) throws MessagingException, TemplateException, IOException {
        new MenuViewer().setupSideMenu(model, request);

        MDUserModel user = SessionManager.getUserDetails(request);

//        String unique_id = sequenceGeneratorService.generateSequenceNumber("ES");

        //type: add new number and sub-type: special offer type
        List<CommonConfig> specialOfferType = commonConfigRepo.findAllByTypeIdAndSubTypeId(17L, 39L);
        //type: add new number and sub-type: special offer level
        List<CommonConfig> specialOfferLevel = commonConfigRepo.findAllByTypeIdAndSubTypeId(17L, 40L);

        String sql = String.format("Select * from %s", Utility.md_user);
        List<Map<String, Object>> userList = (List<Map<String, Object>>) commonRepository.CommoGetData(sql);


        model.put("userList", userList);
        model.put("cId", cId);
        model.put("cToken", cToken);
        model.put("oId", oId);
        model.put("oToken", oToken);
        model.put("viewMode", viewMode);
        model.put("specialOfferType", specialOfferType);
        model.put("specialOfferLevel", specialOfferLevel);
        model.put("title", "Contract");
        model.put("login_name", user.getLOGIN_NAME());
        model.put("name", user.getNAME());
        model.put("logged_in_id", user.getID());
//        model.put("unique_id", unique_id);
        model.put("requestTypeKey", RequestTypeEnum.Contract.getKey());
        model.put("requestTypeValue", RequestTypeEnum.Contract.getValue());
        model.put("conId", cId);
        
        model.put("baseUrl", baseUrl);

        if (!ObjectUtils.isEmpty(cId)) {
            ContractEntity contract = contractService.getContractById(cId);
            List<String> serviceTypes = companyAccountService.findUniqueServiceTypeByCompanyName(contract.getCustomerName());
            System.out.println("SERVICE TYPES: " + serviceTypes);
            model.put("serviceTypes", serviceTypes);
        }

        return "contract/add";
    }

    @GetMapping("/register")
    public String viewRegisterPage(@RequestParam(value = "cId", required = false) Long cId, @RequestParam(value = "cToken", required = false) String cToken,
                                   ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        MDUserModel user = SessionManager.getUserDetails(request);

        String unique_id = sequenceGeneratorService.generateSequenceNumber("ES");

        //type: add new number and sub-type: special offer type
        List<CommonConfig> specialOfferType = commonConfigRepo.findAllByTypeIdAndSubTypeId(17L, 39L);
        //type: add new number and sub-type: special offer level
        List<CommonConfig> specialOfferLevel = commonConfigRepo.findAllByTypeIdAndSubTypeId(17L, 40L);

        model.put("cId", cId);
        model.put("cToken", cToken);
        model.put("specialOfferType", specialOfferType);
        model.put("specialOfferLevel", specialOfferLevel);
        model.put("title", "Add Contract");
        model.put("login_name", user.getLOGIN_NAME());
        model.put("name", user.getNAME());
        model.put("logged_in_id", user.getID());
        model.put("unique_id", unique_id);
        model.put("title", "Register Contract");

        return "contract/contract_register";
    }

    @ResponseBody
    @PostMapping(value = "/add/submit")
    public CommonRestResponse addContract(@Valid @RequestBody ContractDTO contractDTO, HttpServletRequest request) {


        contractDTO.setTenantId(Utility.loggedInTenantId(request));
        HttpServletRequestDto requestDto = Utility.createHttpServletDTO(request);
        if (requestDto == null) {
            requestDto = new HttpServletRequestDto();
        }
        return contractService.saveContract(contractDTO, requestDto);

    }

    @ResponseBody
    @PostMapping(value = "/activate")
    public CommonRestResponse registerContract(@Valid @RequestBody ContractDTO contractDTO, HttpServletRequest request) throws UnsupportedEncodingException, ExecutionException, InterruptedException {

        CompletableFuture<CommonRestResponse> completableFuture = CompletableFuture.supplyAsync(() -> {
            System.out.println("Thread Name: " + Thread.currentThread().getName());

            try {
                return contractService.registerContract(contractDTO);
            } catch (UnsupportedEncodingException e) {
                throw new RuntimeException(e);
            }

        }, threadPoolTaskExecutor);
        CommonRestResponse commonRestResponse = completableFuture.get();
        return commonRestResponse;

    }


    @ResponseBody
    @GetMapping("/list/add/get/product_details")
    public List<ProductDetailsEntity> getProductDetailsList() {
        return productDetailsService.getAll();
    }

    @ResponseBody
    @GetMapping("/list/add/get/attachments")
    public List<AttachmentEntity> getAttachmentsList() {
        return attachmentService.getAll();
    }

    @ResponseBody
    @GetMapping("/list/add/get/contacts")
    public List<ContactEntity> getContactsList() {
        return contactService.getAll();
    }


    @ResponseBody
    @PostMapping(value = "/load/singleContractData")
    public CommonRestResponse loadContractByID(@RequestBody ContractReqSingleDTO contractReqSingleDTO, HttpServletRequest request) {
        if (contractReqSingleDTO.getCid() != null && contractReqSingleDTO.getCtoken() != null) {
            return contractService.getContractDetailsDataById(contractReqSingleDTO.getCid(), contractReqSingleDTO.getCtoken(), null);
        } else {
            String oId = contractReqSingleDTO.getOid();
            return contractService.getContractDetailsDataByOppNumber(oId);
        }
    }

    @ResponseBody
    @PostMapping(value = "/check/companyContractExits")
    public CommonRestResponse checkActiveContractExits(@RequestBody String companyName, HttpServletRequest request) {
        return contractService.checkActiveContractExits(companyName, request);
    }

    @ResponseBody
    @PostMapping(value = "/check/companyExits")
    public CommonRestResponse checkCompanyExitsAndReturnCompany(@RequestBody String companyName, HttpServletRequest request) {
        return contractService.checkCompanyExitsAndReturnCompany(companyName, request);
    }

    @ResponseBody
    @PostMapping(value = "/deleteById")
    public void deleteById(@RequestBody Map<String, Object> requestData, HttpServletRequest request) {
        List<Integer> idList = (List<Integer>) requestData.get("idList");
        String type = (String) requestData.get("type");
        if (idList == null || idList.size() == 0) {
            return;
        }
        List<Long> idNewList = new ArrayList<>();
        for (Integer id : idList) {
            idNewList.add(Long.valueOf(id));
        }
        contractService.deleteByIdAndType(idNewList, type, request);
    }

    @PostMapping("/generate")
    @ResponseBody
    public void downloadReport(@Valid @RequestBody ReportDownloadDTO reportDownloadDTO, HttpServletRequest request, HttpServletResponse response) throws JRException, IOException {
        agreementReportService.emailOrDownloadContractAgreement(request, response, reportDownloadDTO.getServiceType(), reportDownloadDTO.getContractId(), "download");
    }
}
