package com.reddot.ecrm.api.payload.request.contract.customer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.lang.String;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateCorporateCustomerRequest implements Serializable {
    @Valid
    @NotNull(message = "Customer is required.")
    private Customer Customer;

    @Valid
    @NotNull(message = "ReqHeader is required")
    private ReqHeader ReqHeader;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Customer implements Serializable {
        @NotNull(message = "Customer Level is required.")
        @NotEmpty(message = "Customer Level is required.")
        private String CustLevel;

        @Valid
        @NotNull(message = "Address is required.")
        private List<Address> Address;

        @NotNull(message = "Language is required.")
        @NotEmpty(message = "Language is required.")
        private String Language;

        @Valid
        @NotNull(message = "Manager is required.")
        private List<Manager> Manager;

        @Valid
        @NotNull(message = "Corporate Info is required.")
        private CorporateInfo CorporateInfo;

        @Valid
        @NotNull(message = "Contact Info is required.")
        private List<Contact> Contact;

        @NotNull(message = "WrittenLanguage is required.")
        @NotEmpty(message = "WrittenLanguage is required.")
        private String WrittenLanguage;

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class Address implements Serializable {
            @NotNull(message = "Address7 - House No is required.")
            @NotEmpty(message = "Address7 - House No is required.")
            private String Address7;

            @NotNull(message = "Address11 - Commune is required.")
            @NotEmpty(message = "Address11 - Commune is required.")
            private String Address11;

            @NotNull(message = "Address5 - Street is required.")
            @NotEmpty(message = "Address5 - Street is required.")
            private String Address5;

            @NotNull(message = "Address2 - Province is required.")
            @NotEmpty(message = "Address2 - Province is required.")
            private String Address2;

            @NotNull(message = "Address3 - Sangkat is required.")
            @NotEmpty(message = "Address3 - Sangkat is required.")
            private String Address3;

            @NotNull(message = "Address1 - Nationality Code is required.")
            @NotEmpty(message = "Address1 - Nationality Code is required.")
            private String Address1;

            @NotNull(message = "AddressType is required.")
            @NotEmpty(message = "AddressType is required.")
            private String AddressType;
        }

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class Manager implements Serializable {
            @NotNull(message = "Role is required.")
            @NotEmpty(message = "Role is required.")
            private String Role;

            @NotNull(message = "CustManagerSeq is required.")
            @NotEmpty(message = "CustManagerSeq is required.")
            private String CustManagerSeq;

            @NotNull(message = "Email is required.")
            @NotEmpty(message = "Email is required.")
            private String Email;

            @NotNull(message = "ManagerName is required.")
            @NotEmpty(message = "ManagerName is required.")
            private String ManagerName;

            @NotNull(message = "OperatorId is required.")
            @NotEmpty(message = "OperatorId is required.")
            private String OperatorId;

            @NotNull(message = "DepartmentId is required.")
            @NotEmpty(message = "DepartmentId is required.")
            private String DepartmentId;

            @NotNull(message = "MobilePhone is required.")
            @NotEmpty(message = "MobilePhone is required.")
            private String MobilePhone;
        }

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class CorporateInfo implements Serializable {
            @NotNull(message = "Industry is required.")
            @NotEmpty(message = "Industry is required.")
            private String Industry;

            @NotNull(message = "SubIndustry is required.")
            @NotEmpty(message = "SubIndustry is required.")
            private String SubIndustry;

            @NotNull(message = "Customer Type is required.")
            @NotEmpty(message = "Customer Type is required.")
            private String CustType;

            private String CustName;

            @NotNull(message = "CustPhoneNumber is required.")
            @NotEmpty(message = "CustPhoneNumber is required.")
            private String CustPhoneNumber;

            private String CustShortName;

            @NotNull(message = "RegisterDate is required.")
            @NotEmpty(message = "RegisterDate is required.")
            private String RegisterDate;

            @NotNull(message = "CustEmail is required.")
            @NotEmpty(message = "CustEmail is required.")
            private String CustEmail;

            @NotEmpty(message = "Customer Size is required.")
            @NotNull(message = "Customer Size is required.")
            private String CustSize;

            private String RegisterCapital;

            @NotEmpty(message = "CustWebSite is required.")
            @NotNull(message = "CustWebSite is required.")
            private String CustWebSite;

            @Valid
            @NotNull(message = "AdditionalProperty is required.")
            private List<AdditionalProperty> AdditionalProperty;

            @Valid
            @NotNull(message = "Certificate is required.")
            private Certificate Certificate;
            @Data
            public static class AdditionalProperty implements Serializable {
                @NotEmpty(message = "Value is required.")
                @NotNull(message = "Value is required.")
                private String Value;

                @NotEmpty(message = "Code is required.")
                @NotNull(message = "Code is required.")
                private String Code;
            }

            @Data
            @AllArgsConstructor
            @NoArgsConstructor
            public static class Certificate implements Serializable {
                @NotEmpty(message = "IdNum is required.")
                @NotNull(message = "IdNum is required.")
                private String IdNum;

                @NotEmpty(message = "IdType is required.")
                @NotNull(message = "IdType is required.")
                private String IdType;
            }
        }

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class Contact implements Serializable {
            @NotNull(message = "ContactType is required.")
            @NotEmpty(message = "ContactType is required.")
            private String ContactType;

            @NotNull(message = "Email is required.")
            @NotEmpty(message = "Email is required.")
            private String Email;

            @NotNull(message = "Priority is required.")
            @NotEmpty(message = "Priority is required.")
            private String Priority;

            @NotNull(message = "Title is required.")
            @NotEmpty(message = "Title is required.")
            private String Title;

            @NotNull(message = "MobilePhone is required.")
            @NotEmpty(message = "MobilePhone is required.")
            private String MobilePhone;

            @Valid
            @NotNull(message = "Name is required.")
            private Name Name;

            @Data
            @AllArgsConstructor
            @NoArgsConstructor
            public static class Name implements Serializable {
                private String FirstName;

                private String LastName;

                private String MiddleName;
            }
        }
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ReqHeader implements Serializable {
        @NotNull(message = "ReqTime is required.")
        @NotEmpty(message = "ReqTime is required.")
        private String ReqTime;

        @NotNull(message = "Version is required.")
        @NotEmpty(message = "Version is required.")
        private String Version;

        @NotNull(message = "Channel is required.")
        @NotEmpty(message = "Channel is required.")
        private String Channel;

        @NotNull(message = "AccessPassword is required.")
        @NotEmpty(message = "AccessPassword is required.")
        private String AccessPassword;

        @NotNull(message = "PartnerId is required.")
        @NotEmpty(message = "PartnerId is required.")
        private String PartnerId;

        @NotNull(message = "TransactionId is required.")
        @NotEmpty(message = "TransactionId is required.")
        private String TransactionId;

        @NotNull(message = "AccessUser is required.")
        @NotEmpty(message = "AccessUser is required.")
        private String AccessUser;
    }
}
