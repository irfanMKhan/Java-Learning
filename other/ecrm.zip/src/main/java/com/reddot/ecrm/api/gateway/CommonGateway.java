package com.reddot.ecrm.api.gateway;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.api.exception.*;
import com.reddot.ecrm.api.payload.request.opportunity.ReserveListMSISDNRequest;
import com.reddot.ecrm.api.payload.request.opportunity.ReserveRequest;
import com.reddot.ecrm.api.payload.request.shared.account.*;
import com.reddot.ecrm.api.payload.request.shared.group.AddCorporateGroupRequest;
import com.reddot.ecrm.api.payload.request.shared.group.AddGroupCUGRequest;
import com.reddot.ecrm.api.payload.request.shared.group.DeleteCorporateGroupMemberRequest;
import com.reddot.ecrm.api.payload.request.shared.offering.ChangeSupplementaryOfferingRequest;
import com.reddot.ecrm.api.payload.response.ErrorResponse;
import com.reddot.ecrm.api.payload.response.contract.account.QueryPurchasedSupplementaryOfferingResponse;
import com.reddot.ecrm.api.payload.response.opportunity.*;
import com.reddot.ecrm.api.payload.response.pre2post.QueryDebitnoteResponse;
import com.reddot.ecrm.api.payload.response.shared.account.*;
import com.reddot.ecrm.api.payload.response.shared.group.*;
import com.reddot.ecrm.api.payload.response.shared.offering.ChangeSupplementaryOfferingResponse;
import com.reddot.ecrm.api.security.AuthorizationGateway;
import com.reddot.ecrm.api.utility.CommonConstant;
import com.reddot.ecrm.api.utility.HttpClient;
import com.reddot.ecrm.api.utility.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.io.UnsupportedEncodingException;
import java.net.SocketException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Slf4j
@Service
@RequiredArgsConstructor
public class CommonGateway {

    private final Gson gson;

    private final HttpClient httpClient;

    private final AuthorizationGateway authorizationGateway;

    @Value("${smart.egw.base.url}")
    String baseUrlEGW;

    @Value("${smart.igw.base.url}")
    String baseUrlIGW;

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public ReserveResponse reserve(String msisdn, ReserveRequest reserveRequest) {
        String apiUrl = baseUrlIGW + "/api/sim-oms/v1/reservation/" + msisdn + "/reserve";
        String json = gson.toJson(reserveRequest);
        log.debug("{}", json);
        try (Response response = httpClient.put(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), ReserveResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ReserveResponse reserveResponse = gson.fromJson(response.body().string(), ReserveResponse.class);
                throw new ApiRequestException(reserveResponse.getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("ReserveResponse Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("ReserveResponse Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("ReserveResponse Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }else if (e instanceof SocketException) {
                log.error("ReserveResponse Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("ReserveResponse Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public UnReserveMSISDNResponse unReserve(String msisdn, ReserveRequest unReserve) {
        String json = gson.toJson(unReserve);

        String apiUrl = baseUrlIGW + "/api/sim-oms/v1/reservation/" + msisdn + "/un-reserve";

        try (Response response = httpClient.put(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), UnReserveMSISDNResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                UnReserveMSISDNResponse reserveResponse = gson.fromJson(response.body().string(), UnReserveMSISDNResponse.class);
                throw new ApiRequestException(reserveResponse.getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("UnReserveMSISDNResponse Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("UnReserveMSISDNResponse Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("UnReserveMSISDNResponse Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }else if (e instanceof SocketException) {
                log.error("UnReserveMSISDNResponse Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("UnReserveMSISDNResponse Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public ReserveListMSISDNResponse reserveListMSISDN(ReserveListMSISDNRequest reserveListMSISDNRequest) {
        String apiUrl = baseUrlIGW + "/sim-reservation/v1/reserve";
        String json = gson.toJson(reserveListMSISDNRequest);

        try (Response response = httpClient.put(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), ReserveListMSISDNResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("ReserveListMSISDN Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("ReserveListMSISDN Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("ReserveListMSISDN Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }else if (e instanceof SocketException) {
                log.error("ReserveListMSISDN Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("ReserveListMSISDN Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public QueryInventoryMSISDNResponse queryInventoryMSISDN(String page, String pageSize, String categoryId, String prefix, String msisdn) throws UnsupportedEncodingException {
        String apiUrl = baseUrlIGW + "/api/sim-oms/v1/msisdn?page=" + page + "&page_size=" + pageSize + "&category_id=" + categoryId;
        apiUrl = Objects.equals(prefix, "") ? apiUrl : apiUrl + "&prefix=" + prefix;
        apiUrl = Objects.equals(msisdn, "") ? apiUrl : apiUrl + "&msisdn=" + msisdn;

        try (Response response = httpClient.get(apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), QueryInventoryMSISDNResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("QtyInventory Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("QtyInventory Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("QtyInventory Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }else if (e instanceof SocketException) {
                log.error("QtyInventory Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("QtyInventory Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public CRMInventoryResponse crmInventory(String deptId,
                                             String status,
                                             String category,
                                             String prefix,
                                             String startRow,
                                             String endRow,
                                             String MSISDNPattern,
                                             String startRange,
                                             String endRange) {
        StringBuilder apiUrl = new StringBuilder();
        apiUrl.append(baseUrlEGW).append("/CRMInventory/qryMSISDN/v1.0?");

        if (!ObjectUtils.isEmpty(deptId)) {
            apiUrl.append("DeptId=").append(deptId);
        }
        if (!ObjectUtils.isEmpty(status)) {
            apiUrl.append("&Status=").append(status);
        }
        if (!ObjectUtils.isEmpty(category)) {
            apiUrl.append("&Category=").append(category);
        }
        if (!ObjectUtils.isEmpty(prefix)) {
            apiUrl.append("&Prefix=").append(prefix);
        }
        if (!ObjectUtils.isEmpty(startRow)) {
            apiUrl.append("&StartRow=").append(startRow);
        }
        if (!ObjectUtils.isEmpty(endRow)) {
            apiUrl.append("&EndRow=").append(endRow);
        }
        if (!ObjectUtils.isEmpty(MSISDNPattern)) {
            apiUrl.append("&MSISDNPattern=%25%25").append(MSISDNPattern);
            apiUrl.append("%25%25");
        }
        if (!ObjectUtils.isEmpty(startRange)) {
            apiUrl.append("&StartRange=").append(startRange);
        }
        if (!ObjectUtils.isEmpty(endRange)) {
            apiUrl.append("&EndRange=").append(endRange);
        }

        try (Response response = httpClient.get(String.valueOf(apiUrl), getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), CRMInventoryResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("CRMInventory Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("CRMInventory Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("CRMInventory Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }else if (e instanceof SocketException) {
                log.error("CRMInventory Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("CRMInventory Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public SearchInventoryByListMSISDNResponse searchInventoryByListMSISDN(String bssUsername,
                                                                           String bssPassword,
                                                                           String departmentId,
                                                                           String status,
                                                                           String msisdnList,
                                                                           String startRow,
                                                                           String totalRow,
                                                                           String fetchRow) {
        StringBuilder apiUrl = new StringBuilder();
        apiUrl
                .append(baseUrlIGW)
                .append("/api/bss/inventory/msisdn/v1/list?bss_username=").append(bssUsername)
                .append("&bss_password=").append(bssPassword)
                .append("&department_id=").append(departmentId)
                .append("&status=").append(status)
                .append("&msisdn_list=")
                .append(msisdnList);
        if (!ObjectUtils.isEmpty(startRow)) {
            apiUrl.append("&start_row=").append(startRow);
        }
        if (!ObjectUtils.isEmpty(totalRow)) {
            apiUrl.append("&total_row=").append(totalRow);
        }
        if (!ObjectUtils.isEmpty(fetchRow)) {
            apiUrl.append("&fetch_row=").append(fetchRow);
        }

        try (Response response = httpClient.get(String.valueOf(apiUrl), getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                String responseStr = response.body().string();

                log.info("Response from common gateway -> query msisdn list :: " + responseStr);

                JSONObject jsonObject = new JSONObject(responseStr);

                if (jsonObject.has("QueryResources")) {
                    JSONObject QueryResources = jsonObject.getJSONObject("QueryResources");

                    if (QueryResources.has("ResInfoList")) {
                        if (QueryResources.get("ResInfoList").getClass().getName().contains("org.json.JSONObject")) {
                            JSONObject ResInfoListObject = QueryResources.getJSONObject("ResInfoList");
                            JSONArray ResInfoListJsonArray = Utils.convertJsonObjectToArray(ResInfoListObject);
                            QueryResources.put("ResInfoList", ResInfoListJsonArray);
                        }

                    }
                }

                return gson.fromJson(String.valueOf(jsonObject), SearchInventoryByListMSISDNResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                SearchInventoryByListMSISDNErrorResponse errorResponse = gson.fromJson(response.body().string(), SearchInventoryByListMSISDNErrorResponse.class);
                throw new ApiRequestException(errorResponse.getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("SearchInventoryByMSISDN Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("SearchInventoryByMSISDN Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("SearchInventoryByMSISDN Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }else if (e instanceof SocketException) {
                log.error("SearchInventoryByMSISDN Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("SearchInventoryByMSISDN Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public DebitNoteResponse debitNote(String accAccessCodeAccCode, DebitNoteRequest debitNoteRequest) {
        String apiUrl = baseUrlIGW + "/api/cbsar/adjustment/v2?acctAccessCode.AccountCode=" + accAccessCodeAccCode;//"1.3222879";
        String json = gson.toJson(debitNoteRequest);

        try (Response response = httpClient.post(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.CREATED.value()) {
                return gson.fromJson(response.body().string(), DebitNoteResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                DebitNoteErrorResponse errorResponse = gson.fromJson(response.body().string(), DebitNoteErrorResponse.class);
                throw new ApiRequestException(errorResponse.getError().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("DebitNote Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("DebitNote Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("DebitNote Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }else if (e instanceof SocketException) {
                log.error("DebitNote Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("DebitNote Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public CreditNoteResponse creditNote(String accAccessCodeAccCode, CreditNoteRequest creditNoteRequest) {
        String apiUrl = baseUrlIGW + "/api/cbsar/adjustment/v2?acctAccessCode.AccountCode=" + accAccessCodeAccCode;
        String json = gson.toJson(creditNoteRequest);

        try (Response response = httpClient.post(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.CREATED.value()) {
                return gson.fromJson(response.body().string(), CreditNoteResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                SmartErrorResponse errorResponse = gson.fromJson(response.body().string(), SmartErrorResponse.class);
                throw new ApiRequestException(errorResponse.getError().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("CreditNote Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("CreditNote Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("CreditNote Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }else if (e instanceof SocketException) {
                log.error("CreditNote Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("CreditNote Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public CreditNoteResponse creditNoteV2(String accAccessCodeAccCode, CreditNoteReqV2 creditNoteReqV2) {
        String apiUrl = baseUrlIGW + "/api/cbsar/adjustment/v2?acctAccessCode.AccountCode=" + accAccessCodeAccCode;
        String json = gson.toJson(creditNoteReqV2);

        try (Response response = httpClient.post(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.CREATED.value()) {
                return gson.fromJson(response.body().string(), CreditNoteResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                SmartErrorResponse errorResponse = gson.fromJson(response.body().string(), SmartErrorResponse.class);
                throw new ApiRequestException(errorResponse.getError().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("CreditNote Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("CreditNote Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("CreditNote Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }else if (e instanceof SocketException) {
                log.error("CreditNote Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("CreditNote Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }


    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public QueryPurchasedSupplementaryOfferingResponse queryPurchasedSupplementaryOffering(String partnerId, String transactionId, String reqTime, String channel, String accessUser, String accessPassword, String objectIdType, String objectId) throws UnsupportedEncodingException {
        String apiUrl = baseUrlEGW + "/offering/queryPurchasedSupplementaryOffering/V1.0?partnerId=" + partnerId + "&" + "transactionId=" + transactionId + "&" + "reqTime=" + reqTime + "&" + "channel=" + channel + "&" + "accessUser=" + accessUser + "&" + "accessPassword=" + Utils.urlEncode(accessPassword) + "&" + "objectIdType=" + objectIdType + "&" + "objectId=" + objectId;

        try (Response response = httpClient.get(apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), QueryPurchasedSupplementaryOfferingResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("SupplementaryOffering Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("SupplementaryOffering Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("SupplementaryOffering Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }else if (e instanceof SocketException) {
                log.error("SupplementaryOffering Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("SupplementaryOffering Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public ChangeSupplementaryOfferingResponse changeSupplementaryOffering(ChangeSupplementaryOfferingRequest offeringRequest) {
        String apiUrl = baseUrlEGW + "/offering/changeSupplementaryOffering/V1.0";
        String json = gson.toJson(offeringRequest);

        try (Response response = httpClient.put(json, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), ChangeSupplementaryOfferingResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("Change SupplementaryOffering Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("Change SupplementaryOffering Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("Change SupplementaryOffering Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }else if (e instanceof SocketException) {
                log.error("Change SupplementaryOffering Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("Change SupplementaryOffering Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public ChangeAccountCreditLimitResponse changeAccountCreditLimit(ChangeAccountCreditLimitRequest creditLimitRequest) {
        String apiUrl = baseUrlEGW + "/HWCRM/Account/ChangeAccountCreditLimit/v1.0";
        String json = gson.toJson(creditLimitRequest);

        try (Response response = httpClient.post(json, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), ChangeAccountCreditLimitResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("Change Credit Limit Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("Change Credit Limit Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("Change Credit Limit Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }else if (e instanceof SocketException) {
                log.error("Change Credit Limit Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("Change Credit Limit Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }


    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public AddCorporateGroupResponse addCorporateGroup(AddCorporateGroupRequest groupReq) {
        String apiUrl = baseUrlEGW + "/AddCorporateGroup/V1.0";
        String json = gson.toJson(groupReq);

        try (Response response = httpClient.put(json, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), AddCorporateGroupResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("Add Corp Group Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("Add Corp Group Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("Add Corp Group Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }else if (e instanceof SocketException) {
                log.error("Add Corp Group Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("Add Corp Group Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = { PendingBusinessOrderException.class }, include = { ConnectionResetException.class },  maxAttemptsExpression = "${retry.maxAttempts}" , backoff = @Backoff(delayExpression = "${retry.maxDelay}"))
    public AddGroupCUGResponse addGroupCUG(AddGroupCUGRequest addGroupCUGRequest, String groupId) {
        String apiUrl = baseUrlIGW + "/api/bss/cug/v2/groups/"+groupId+"/members";
        String json = gson.toJson(addGroupCUGRequest);

        try (Response response = httpClient.post(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.CREATED.value()) {
                return gson.fromJson(response.body().string(), AddGroupCUGResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else if (response.code() == HttpStatus.BAD_REQUEST.value()) {
                SmartErrorResponse errorResponse = gson.fromJson(response.body().string(), SmartErrorResponse.class);
                if (errorResponse.getError().getCode().equalsIgnoreCase("1211001021")) {
                    throw new AlreadyExistsException(errorResponse.getError().getMessage());
                } else if (errorResponse.getError().getCode().equalsIgnoreCase("1211000472")) {
                    throw new PendingBusinessOrderException(errorResponse.getError().getMessage());
                } else {
                    throw new ApiRequestException(errorResponse.getError().getMessage());
                }
            } else {
                SmartErrorResponse errorResponse = gson.fromJson(response.body().string(), SmartErrorResponse.class);
                throw new ApiRequestException(errorResponse.getError().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("AddGroupCUG Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("AddGroupCUG Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("AddGroupCUG Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("AddGroupCUG Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            } else if (e instanceof AlreadyExistsException) {
                log.debug("AddGroupCUG already exists: {}", e.getMessage());
                throw new AlreadyExistsException(e.getMessage());
            } else if (e instanceof PendingBusinessOrderException) {
                log.debug("AddGroupCUG business order: {}", e.getMessage());
                throw new PendingBusinessOrderException(e.getMessage());
            }
            log.error("AddGroupCUG Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public ChangeAccountInformationCommonResponse changeAccountInformation(String accountId, ChangeAccountInformationRequest accountInformationRequest) {
        String apiUrl = baseUrlIGW + "/api/bss/0102/accounts/v2/" + accountId + "/info";
        String json = gson.toJson(accountInformationRequest);
        ChangeAccountInformationCommonResponse changeAccountInformationCommonResponse = new ChangeAccountInformationCommonResponse();
        try (Response response = httpClient.put(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                ChangeAccountInformationResponse changeAccountInformationResponse = gson.fromJson(response.body().string(), ChangeAccountInformationResponse.class);
                changeAccountInformationCommonResponse.setIsSuccess(true);
                changeAccountInformationCommonResponse.setCode("0000");
                changeAccountInformationCommonResponse.setMessage(changeAccountInformationResponse.getTransaction_status());

            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ChangeAccountInformationErrorResponse errorResponse = gson.fromJson(response.body().string(), ChangeAccountInformationErrorResponse.class);
                log.error(errorResponse.toString());
                log.error(response.body().string());
                changeAccountInformationCommonResponse.setIsSuccess(true);
                changeAccountInformationCommonResponse.setCode(errorResponse.getError().getCode());
                changeAccountInformationCommonResponse.setMessage(errorResponse.getError().getMessage());
            }
            return changeAccountInformationCommonResponse;
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("ChangeAccountInformation Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("ChangeAccountInformation Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("ChangeAccountInformation Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }else if (e instanceof SocketException) {
                log.error("ChangeAccountInformation Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("ChangeAccountInformation Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public DeleteCUGGroupMemberResponse deleteCUGGroupMember(String groupId, String idType, String memberId, String transaction_id) throws UnsupportedEncodingException {
        String apiUrl = baseUrlIGW + "/api/bss/cug/v2/groups/" + groupId + "/members/" + memberId + "?id_type=" + idType + "&transaction_id=" + transaction_id;

        try (Response response = httpClient.delete(apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), DeleteCUGGroupMemberResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                DebitNoteErrorResponse errorResponse = gson.fromJson(response.body().string(), DebitNoteErrorResponse.class);
                throw new ApiRequestException(errorResponse.getError().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("deleteCUGGroupMember Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("deleteCUGGroupMember Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("deleteCUGGroupMember Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }else if (e instanceof SocketException) {
                log.error("deleteCUGGroupMember Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("deleteCUGGroupMember Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public DeleteCorporateGroupMemberResponse deleteCorporateGroupMember(DeleteCorporateGroupMemberRequest groupMemberRequest) {
        String apiUrl = baseUrlEGW + "/DeleteCorporateGroupMember/V1.0";
        String json = gson.toJson(groupMemberRequest);

        try (Response response = httpClient.put(json, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), DeleteCorporateGroupMemberResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("DeleteCorporateGroupMember Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("DeleteCorporateGroupMember Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("DeleteCorporateGroupMember Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }else if (e instanceof SocketException) {
                log.error("DeleteCorporateGroupMember Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("DeleteCorporateGroupMember Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public List<QueryDebitnoteResponse> queryDebitNote(String extTransId) {
        String apiUrl = baseUrlIGW + "/api/debit-notes/v1/" + extTransId;

        try (Response response = httpClient.get(apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), new TypeToken<List<QueryDebitnoteResponse>>() {
                }.getType());
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("queryDebitNote Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("queryDebitNote Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("queryDebitNote Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }else if (e instanceof SocketException) {
                log.error("queryDebitNote Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("queryDebitNote Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    private Map<String, String> getHeaders() {
        String bearerToken = authorizationGateway.getTokenEGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }

    private Map<String, String> getIGWHeaders() {
        String bearerToken = authorizationGateway.getTokenIGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }
}
