package com.reddot.ecrm.controller.lead.quotation;

import com.reddot.ecrm.dto.lead.LeadDto;
import com.reddot.ecrm.dto.lead.quotation.QuotationDetailsDto;
import com.reddot.ecrm.dto.lead.quotation.QuotationDto;
import com.reddot.ecrm.dto.quotation.QuotationIdExcelDto;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.lead.LeadEmailDto;
import com.reddot.ecrm.service.lead.quotation.QuotationDetailsService;
import com.reddot.ecrm.service.lead.quotation.QuotationEmailDto;
import com.reddot.ecrm.service.lead.quotation.QuotationService;
import freemarker.template.TemplateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/quotation")
public class QuotationRestController {
    
    @Autowired
    private QuotationService quotationService;
    
    @Autowired
    private QuotationDetailsService quotationDetailsService;
    
    @GetMapping("/dt/all")
    public DataTablesOutput<QuotationDto> dtLead(HttpServletRequest request,
                                                 DataTablesInput input,
                                                 @RequestParam(value = "keyword", required = false, defaultValue = "") String keyword,
                                                 @RequestParam(value = "quotationNumber", required = false,
                                                         defaultValue = "") String quotationNumber,
                                                 @RequestParam(value = "leadId", required = false, defaultValue = "") String leadId,
                                                 @RequestParam(value = "receiverCompanyName", required = false, defaultValue = "") String receiverCompanyName,
                                                 @RequestParam(value = "senderName", required = false, defaultValue = "") String senderName,
                                                 @RequestParam(value = "createdFromDateString", required = false, defaultValue = "") String createdFromDateString,
                                                 @RequestParam(value = "createdToDateString", required = false, defaultValue = "") String createdToDateString,
                                                 @RequestParam(value = "orderField", required = false, defaultValue = "createdAtDateString") String orderField,
                                                 @RequestParam(value = "orderDirection", required = false, defaultValue = "desc") String orderDirection,
                                                 @RequestParam(value = "isActive", required = false, defaultValue = "") String isActive) {
        return quotationService.getDTQuotation(
                request,
                input,
                keyword,
                quotationNumber,
                leadId,
                receiverCompanyName,
                senderName,
                createdFromDateString,
                createdToDateString,
                orderField,
                orderDirection,
                isActive);
    }
    
    @PostMapping("/add")
    public CommonRestResponse addQuotation(HttpServletRequest request, @RequestBody QuotationDto quotationDto) {
        return quotationService.addQuotation(request, quotationDto);
    }
    
    @PostMapping("/update")
    public CommonRestResponse updateQuotation(HttpServletRequest request, @RequestBody QuotationDto quotationDto) {
        return quotationService.updateQuotation(request, quotationDto);
    }
    
    @GetMapping("/generateExcel/{quotationId}")
    public ResponseEntity<Resource> generateExcel(@PathVariable Long quotationId) {
        QuotationIdExcelDto quotationIdExcelDto = quotationService.generateExcel(quotationId);
        InputStreamResource file = new InputStreamResource(quotationIdExcelDto.getInp());
        String fileName = "QT_" + quotationIdExcelDto.getQuotation_id() + ".xlsx";
        
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName)
                .contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
                .body(file);
    }
    
    @PostMapping("/sendMail")
    public ResponseEntity<?> sendQuotationMail(HttpServletRequest request, @RequestBody QuotationEmailDto quotationEmailDto) throws MessagingException, TemplateException, IOException {
        if (quotationService.sendMail(quotationEmailDto, request)) {
            return new ResponseEntity<>("Email has been sent successfully!", HttpStatus.OK);
        } else return new ResponseEntity<>("Failed to send email!", HttpStatus.BAD_REQUEST);
    }
    
    @GetMapping("/quotation-details")
    public ResponseEntity<?> getAllQuotationDetailsByQuotationId(@RequestParam(value = "quotation_id") String quotationId){
        List<QuotationDetailsDto> quotationDetails =
                quotationDetailsService.getAllQuotationDetailsByQuotationId(Long.valueOf(quotationId));
        if(quotationDetails.isEmpty()){
            return new ResponseEntity<>("No data found!", HttpStatus.NO_CONTENT);
        }
        else return new ResponseEntity<>(quotationDetails, HttpStatus.OK);
    }
}