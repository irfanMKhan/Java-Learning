package com.reddot.ecrm.controller.approval.approval_request;

import com.reddot.ecrm.entity.approval.ApprovalFlowEntity;
import com.reddot.ecrm.entity.approval.ApprovalLogDetailsEntity;
import com.reddot.ecrm.entity.approval.ApprovalRequestEntity;
import com.reddot.ecrm.enum_config.approval.ApprovalEnum;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.repository.approval.ApprovalFlowRepo;
import com.reddot.ecrm.repository.approval.ApprovalLogDetailsRepo;
import com.reddot.ecrm.repository.approval.ApprovalRequestRepo;
import com.reddot.ecrm.service.approval.ApprovalFlowService;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Optional;


@Controller
@RequestMapping("/approval")
public class ApprovalRequestController {

    @Autowired
    ApprovalFlowService approvalFlowService;

    @Autowired
    ApprovalRequestRepo approvalRequestRepo;

    @Autowired
    ApprovalFlowRepo approvalFlowRepo;

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    ApprovalLogDetailsRepo logDetailsRepo;

    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Value("${app.base_url}")
    private String baseUrl;

    @GetMapping("/flow/request")
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        Long tenatId = Utility.loggedInTenantId(request);
        List<ApprovalFlowEntity> list = approvalFlowRepo.findAllByTenantId(tenatId);

        model.put("flowList", list);
        model.addAttribute("breadcrumb", "Approval Flow");
        model.put("title", "Approval Request");
        return "approval/approval_request";
    }

    @GetMapping("/flow/request/allrequest")
    public String viewALLReqDetailsPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        ApprovalEnum[] approvalEnumsList = ApprovalEnum.values();

        model.put("approvalEnumsList", approvalEnumsList);
        model.addAttribute("breadcrumb", "Approval Flow");
        model.put("title", "Request List");
        return "approval/RequestedByMe/approval_request_list_req_by_me";
    }

    @GetMapping("/flow/request/singleRequestDetails")
    public String viewSingleReqDetailsPage(@RequestParam("id") Long reqId, @RequestParam("token") String token, ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        Optional<ApprovalRequestEntity> approvalRequest = approvalRequestRepo.findById(reqId);
        List<ApprovalLogDetailsEntity> logDetailsEntityList = logDetailsRepo.findAllByApprovalReqIdAndUuidTokenAndIsActiveOrderByStepOrderDesc(reqId,
                token, true);

        model.put("logDetailsList", logDetailsEntityList);
        model.put("requestDetails", approvalRequest.get());
        model.addAttribute("breadcrumb", "Approval Flow");
        model.put("title", "Request Details");
        return "approval/RequestedByMe/approval_single_request_details_req_by_me";
    }


    @GetMapping("/flow/request/email/requestDetails")
    public String viewReqDetailsPage(@RequestParam("reqId") Long reqId, @RequestParam("approverId") String approverId,
                                     @RequestParam("token") String token, @RequestParam("logDetailsId") Long logDetailsId,
                                     ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        Optional<ApprovalRequestEntity> approvalRequest = approvalRequestRepo.findByIdAndUuidToken(reqId, token);
        //   ApprovalLogDetailsEntity approvalLogDetails = logDetailsRepo.findByApprovalReqIdAndApproverID(reqId, Long.valueOf(approverId));

        Optional<ApprovalLogDetailsEntity> approvalLogDetails = logDetailsRepo.findByApproverIDAndUuidTokenAndIdAndIsActive(Long.valueOf(approverId),
                token, logDetailsId, true);

        if (!approvalLogDetails.isPresent()) {
            return "This Approval Request is not valid!!!";
        }

        String acceptLink = String.format("%s/approval/flow/request/email/accept?approverId=%s&token=%s&approvalLogDetailsId=%s",
                baseUrl, approverId, token, logDetailsId);
        String rejectLink = String.format("%s/approval/flow/request/email/reject?approverId=%s&token=%s&approvalLogDetailsId=%s",
                baseUrl, approverId, token, logDetailsId);

        List<ApprovalLogDetailsEntity> logDetailsEntityList = logDetailsRepo.findAllByApprovalReqIdAndUuidTokenAndIsActiveOrderByStepOrderDesc(
                reqId, token, true);

        model.put("logDetailsList", logDetailsEntityList);
        model.put("acceptLink", acceptLink);
        model.put("rejectLink", rejectLink);
        model.put("approverId", approverId);
        model.put("token", token);
        model.put("approvalLogDetails", approvalLogDetails.get());
        model.put("reqDetails", approvalRequest.get());
        model.addAttribute("breadcrumb", "Approval Flow");
        model.put("title", "Approval Request Details");
        model.addAttribute("breadcrumb", "Approval Flow");
        return "approval/MyApprovalRequest/approval_accpt_reject_request_details";
    }

    @GetMapping("/flow/request/allApprovalRequest")
    public String viewALLApprovalReqDetailsPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        ApprovalEnum[] approvalEnumsList = ApprovalEnum.values();

        model.put("approvalEnumsList", approvalEnumsList);
        model.addAttribute("breadcrumb", "Approval Flow");
        model.put("title", "Approval Request List"); //todo: need to specify the approver request list by approverid
        return "approval/MyApprovalRequest/approval_approved_pending_rejected_list";
    }
}
