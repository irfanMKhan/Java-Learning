package com.reddot.ecrm.controller.GlobalSettingsController;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.model.GlobalSettings.District.MDDistrictModel;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.repository.GlobalSettingsRepository;
import com.reddot.ecrm.repository.UsersRepository;
import com.reddot.ecrm.util.QueryBuilder;
import com.reddot.ecrm.util.Utility;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

import static java.lang.Integer.parseInt;

@RestController
public class GlobalSettingsRESTController {
    private final Logger logger = LoggerFactory.getLogger("GlobalSettingsLogger");

    @Autowired
    private CommonRepository commonDAO;


    @RequestMapping(value = "/districtDataforDivision", method = RequestMethod.POST)
    public List<MDDistrictModel> districtDataforDivision(@RequestParam("serviceType") String serviceType) {
        logger.info("Inside districtDataforDivision");
        List<MDDistrictModel> srTypeModels = new ArrayList<>();
        try {
            String[] parts = serviceType.split("/");

            Map<String, Object> SrTypeData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            SrTypeData.put("DIVISION_ID", parts[0]);
            whereSearchType.put("DIVISION_ID", "AND");
            SrTypeData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");

            String qry_fetch = QueryBuilder.getSelectWhereQuery(Utility.md_district, SrTypeData, whereSearchType);
            logger.info(qry_fetch);
            Object srSrTypeList = commonDAO.getDataPostgres(qry_fetch);

            srTypeModels = new Gson().fromJson(Utility.ObjectToJson(srSrTypeList), new TypeToken<List<MDDistrictModel>>() {
            }.getType());

        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        logger.info("Returning from districtDataforDivision with data: " + srTypeModels.size());
        return srTypeModels;
    }


}
