package com.reddot.ecrm.controller.cr.download_customer_info;

import com.reddot.ecrm.menu.MenuViewer;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping(value = "/cr/downloadCustomerInfo", method = RequestMethod.GET)
public class DownloadCustomerInfoController {

    @GetMapping("")
    public String viewPageSummary(ModelMap model, HttpServletRequest request)
    {
        new MenuViewer().setupSideMenu(model, request);
        model.addAttribute("breadcrumb", "Download Customer Information");
        model.addAttribute("title", "Download Customer Information");

        return "cr/download_customer_info/download_customer_info_home";
    }
}
