package com.reddot.ecrm.controller.attachment;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.entity.attachment.AttachmentEntity;
import com.reddot.ecrm.entity.logger.APILogger;
import com.reddot.ecrm.module.deviceConfig.dto.req.DeviceConfigSearchReqDTO;
import com.reddot.ecrm.service.attachment.AttachmentService;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RequestMapping(value = "/api/attachments", method = RequestMethod.GET)
@RequiredArgsConstructor
@RestController
public class AttachmentRestController {
    private final AttachmentService attachmentService;
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @GetMapping("/all")
    public ResponseEntity<?> allAttachments(){
        List<AttachmentEntity> attachmentEntities = attachmentService.getAll();
        if(attachmentEntities.isEmpty()){
            return new ResponseEntity<>(attachmentEntities, HttpStatus.NO_CONTENT);
        }
        else return new ResponseEntity<>(attachmentEntities, HttpStatus.OK);
    }

    @PostMapping("/DT")
    public DataTablesOutput<AttachmentEntity> attachmentDatatable(@RequestBody Map<String, Object> reqBody){
        try{
            DataTablesInput input = new Gson().fromJson(Utility.ObjectToJson(reqBody.get("input")), new TypeToken<DataTablesInput>(){}.getType());
            ObjectMapper mapper = new ObjectMapper();
            AttachmentEntity attachment = mapper.readValue(reqBody.get("attachment").toString(), AttachmentEntity.class);
            return attachmentService.attachmentDataTable(input, attachment);
        }
        catch (Exception e){
            logger.error(e.getMessage());
            return null;
        }
    }
}
