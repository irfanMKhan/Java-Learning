package com.reddot.ecrm.dto.agreement;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
public class ReportDownloadDTO {
    @NotNull(message = "contractId is required.")
    @NotEmpty(message = "contractId is required.")
    private Long contractId;
    @NotNull(message = "serviceType is required.")
    @NotEmpty(message = "serviceType is required.")
    private String serviceType;
}
