package com.reddot.ecrm.dto.agreement.postpaid;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PostPaidDTO {
    private String contractNo;
    private String companyPhoneNumber;
    private String companyEmail;
    private String contractDate;
    private String companyName;
    private String companyAddress;


    private String primaryContactPersonName;
    private String primaryContactPersonEmail;
    private String primaryContactPersonPhone;
    private String primaryContactPersonPosition;

    private String billingContactPersonName;
    private String billingContactPersonEmail;
    private String billingContactPersonPhone;
    private String billingContactPersonPosition;

    private String subscriberName;
    private String subscriberPosition;
    private String subscriberDate;

    private String termInMonth;
    private String emailAndBunnatId;
    private String usdAmount;

    private String contactDetailOne;
    private String contactDetailTwo;
    private String contactDetailThree;


    private String uniqueNumber;
    private String templateName;
    private String image;

}
