package com.reddot.ecrm.controller.cr.suspend;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.entity.cr.CRMasterEntity;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.module.primaryOffering.PrimaryOffering;
import com.reddot.ecrm.module.primaryOffering.dto.PrimaryOfferingSearchReqDTO;
import com.reddot.ecrm.suspend.SuspendService;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Map;

@RestController
@RequestMapping(value = "/cr/suspend", method = RequestMethod.GET)
@RequiredArgsConstructor
public class SuspendDTRestController {
    private final SuspendService suspendService;

    @PostMapping("/searchDT")
    public DataTablesOutput<CRMasterEntity> searchDT(HttpServletRequest request, @RequestBody Map<String, Object> data) throws IOException {
        DataTablesInput input = new Gson().fromJson(Utility.ObjectToJson(data.get("dtInput")), new TypeToken<DataTablesInput>() {
        }.getType());

        ObjectMapper mapper = new ObjectMapper();
        SuspendSearchReqDto searchData = mapper.readValue(data.get("searchData").toString(), SuspendSearchReqDto.class);

        MDUserModel userModel = Utility.getLoggedInUserDetails(request);
        if( userModel != null && userModel.getUSER_TYPE().equals("PIC") ){
            searchData.setCompanyId(userModel.getCOMPANY_ID()+"");
        }

        return suspendService.searchDT(input, searchData);
    }
}
