package com.reddot.ecrm.api.payload.request.contract.subscriber;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.lang.String;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateCorporateSubscriberSubRequest implements Serializable {
  private Order Order;

  private String AcctId;

  private String CustId;

  private Subscriber Subscriber;

  private ReqHeader ReqHeader;


  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class Order implements Serializable {
    private String OrderType;
  }

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class Subscriber implements Serializable {
    private String GroupName;

    private String MaxGroupMember;

    private List<? extends AdditionalProperty> AdditionalProperty;

    private Subscriber.PrimaryOffering PrimaryOffering;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class PrimaryOffering implements Serializable {
      private CreateCorporateSubscriberRequest.Subscriber.PrimaryOffering.OfferingId OfferingId;
      @Data
      @AllArgsConstructor
      @NoArgsConstructor
      public static class OfferingId implements Serializable {
        private String OfferingId;
      }
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class AdditionalProperty implements Serializable {
      private String Value;

      private String Code;
    }
  }

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class ReqHeader implements Serializable {
    private String ReqTime;

    private String Version;

    private String Channel;

    private String BusinessCode;

    private String AccessPassword;

    private String PartnerId;

    private String OperatorId;

    private String BrandId;

    private String TransactionId;

    private String AccessUser;
  }
}
