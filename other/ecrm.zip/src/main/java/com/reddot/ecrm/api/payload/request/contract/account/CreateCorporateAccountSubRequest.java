package com.reddot.ecrm.api.payload.request.contract.account;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateCorporateAccountSubRequest implements Serializable {
    private Account Account;

    private String CustId;

    private ReqHeader ReqHeader;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Account implements Serializable {
        private List<Address> Address;

        private String BillCycleType;

        private List<CreditLimit> CreditLimit;

        private String Title;

        private String InitialBalance;

        private Name Name;

        private Contact Contact;

        private String AcctName;

        private String Currency;

        private String AcctPayMethod;

        private List<BillMedium> BillMedium;

        private String PaymentType;

        private List<AdditionalProperty> AdditionalProperty;

        private String BillLanguage;

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class Address implements Serializable {
            private String Address7;

            private String Address11;

            private String Address5;

            private String Address2;

            private String Address3;

            private String Address1;

            private String AddressType;
        }

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class CreditLimit implements Serializable {
            private String LimitType;

            private String LimitValue;
        }

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class Name implements Serializable {
            private String FirstName;

            private String LastName;

            private String MiddleName;
        }

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class Contact implements Serializable {
            private String Email;

            private String MobilePhone;
        }

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class BillMedium implements Serializable {
            private String BillMediumId;

            private String BillMediumCode;

            private String BillContentType;
        }

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class AdditionalProperty implements Serializable {
            private String Value;

            private String Code;
        }
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ReqHeader implements Serializable {
        private String ReqTime;

        private String Version;

        private String Channel;

        private String AccessPassword;

        private String PartnerId;

        private String TransactionId;

        private String AccessUser;
    }
}
