package com.reddot.ecrm.delayPayment;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetCompanyByPICReqBody {
    private String picID;
}
