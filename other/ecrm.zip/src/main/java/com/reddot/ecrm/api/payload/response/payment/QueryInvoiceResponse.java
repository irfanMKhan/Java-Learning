package com.reddot.ecrm.api.payload.response.payment;

import lombok.Data;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.List;

@Data
public class QueryInvoiceResponse implements Serializable {
    private QueryInvoiceResultMsg QueryInvoiceResultMsg;

    @Data
    public static class QueryInvoiceResultMsg implements Serializable {
        private ResultHeader ResultHeader;

        private QueryInvoiceResult QueryInvoiceResult;

        @Data
        public static class QueryInvoiceResult implements Serializable {
            private List<InvoiceInfo> InvoiceInfo;

            @Data
            public static class InvoiceInfo implements Serializable {
                private String Status;

                private Long AcctKey;

                private String TransType;

                // private BigInteger InvoiceNo;
                private String InvoiceNo;

                private BigInteger InvoiceAmount;

                private BigInteger InvoiceID;

                private BigInteger PrimaryIdentity;

                private BigInteger BillCycleID;

                private BigInteger CurrencyID;

                private BigInteger DisputeAmount;

                private Long BillCycleBeginTime;

                private Long BillCycleEndTime;

                private Long InvoiceDate;

                private Long DueDate;

                private Long CustKey;

                private Long SubKey;

                private BigInteger OpenAmount;

                private InvoiceDetail InvoiceDetail;

                @Data
                public static class InvoiceDetail implements Serializable {
                    private BigInteger DisputeAmount;

                    private String Status;

                    private String ChargeCode;

                    private String ServiceCategory;

                    private BigInteger InvoiceID;

                    private BigInteger ChargeAmount;

                    private BigInteger CurrencyID;

                    private BigInteger OpenAmount;
                }
            }
        }

        @Data
        public static class ResultHeader implements Serializable {
            private Integer Version;

            private Integer MsgLanguageCode;

            private String ResultDesc;

            private Integer ResultCode;
        }
    }
}
