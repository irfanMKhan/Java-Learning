//package com.reddot.ecrm.api.logger.repository;
//
//
//import com.reddot.ecrm.entity.logger.APILogger;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public interface ApiLoggerRepository extends JpaRepository<APILogger, Long> {
//}
