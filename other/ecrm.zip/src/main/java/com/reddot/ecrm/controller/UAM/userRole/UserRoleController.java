package com.reddot.ecrm.controller.UAM.userRole;

import com.reddot.ecrm.menu.MenuViewer;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping(value = "/user-roles", method = RequestMethod.GET)
public class UserRoleController {

    @GetMapping("")
    public String getUsersPage(){
        return "redirect:/user-roles/list";
    }

    @GetMapping({"/list"})
    public String getUserRoleListView(ModelMap model, HttpServletRequest request){
        new MenuViewer().setupSideMenu(model, request);
        model.addAttribute("title", "User Role");
        model.addAttribute("breadcrumb", "List");
        return "user_role/user_role_list";
    }

    @GetMapping({"/add"})
    public String getUserRoleAddView(ModelMap model, HttpServletRequest request){
        new MenuViewer().setupSideMenu(model, request);
        model.addAttribute("title", "User Role");
        model.addAttribute("breadcrumb", "Add");
        return "user_role/user_role_add";
    }
}
