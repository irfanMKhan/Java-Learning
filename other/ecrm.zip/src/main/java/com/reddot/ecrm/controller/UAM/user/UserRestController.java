package com.reddot.ecrm.controller.UAM.user;

import com.google.gson.Gson;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.model.User.UserModel;
import com.reddot.ecrm.model.userRole.RoleEntity;
import com.reddot.ecrm.service.user.UserService;
import com.reddot.ecrm.util.Utility;
import freemarker.template.TemplateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "/api/users", method = RequestMethod.GET)
public class UserRestController {

    @Autowired
    private UserService service;

    @GetMapping("/all")
    public CommonRestResponse getAllUsers(){
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error occurred! Please try again", null);
        return service.getAllUsers();
    }

    @GetMapping("/DTData")
    public DataTablesOutput<UserModel> DTData(@Valid DataTablesInput input, HttpServletRequest request,
                                                @RequestParam(value = "searchText", required = false) String customQuery,
                                                @RequestParam(value = "customSearchCriteria", required = false) String customSearchCriteria){
        if (customSearchCriteria == null) {
            customSearchCriteria = "";
        }

        if (Utility.isColumnSpecificSearch(input.getColumnsAsMap())) {
            customQuery = "";
        }
        return service.DTData(input, request, customSearchCriteria, customQuery);
    }

    @GetMapping("/getData")
    public CommonRestResponse getUserById(@RequestParam String id, HttpServletRequest request){
        String userId = new Gson().fromJson(id, String.class);
        return service.getUserById(userId);
    }

    @GetMapping("/pic")
    public CommonRestResponse getPIC(){
        return service.getAllUsers();
    }

    @PostMapping("/addUser")
    public CommonRestResponse addUserFunction(@RequestBody String userData, HttpServletRequest request){
        UserModel userModel = new Gson().fromJson(userData, UserModel.class);
        Map<String, String> createdInfo = new HashMap<>();
        createdInfo.put("createdBy", String.valueOf(Utility.loggedInId(request)));
        createdInfo.put("createdByUsername", Utility.loggedInName(request));

        return service.addUser(userModel, createdInfo);
    }

    @PostMapping("/updateUser")
    public CommonRestResponse updateUserFunction(@RequestBody String userData, HttpServletRequest request){
        UserModel userModel = new Gson().fromJson(userData, UserModel.class);
        return service.updateUserFunction(userModel, request);
    }

    @PostMapping("/resetPassword")
    public CommonRestResponse resetPassword(@RequestBody String userId, HttpServletRequest request) throws MessagingException, TemplateException, IOException {
        Long createdBy = Utility.loggedInId(request);
        String createdByUsername = Utility.loggedInName(request);
        return service.resetPassword(userId, createdBy, createdByUsername);
    }

    @GetMapping("/userByRole/{role_id}")
    public CommonRestResponse getUsersListByRoleName(@PathVariable("role_id") String roleId){
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error Occurred!", null);
        List<UserModel> result = service.getUsersListByRoleName(roleId);
        if(result.size()>0){
            commonRestResponse.setCode(200);
            commonRestResponse.setMessage("Users with role: KAM");
            commonRestResponse.setData(result);
        }
        else if (result.size()>0){
            commonRestResponse.setData(200);
            commonRestResponse.setData(result);
            commonRestResponse.setMessage("No users with role: KAM was found!");
        }
        return commonRestResponse;
    }
}
