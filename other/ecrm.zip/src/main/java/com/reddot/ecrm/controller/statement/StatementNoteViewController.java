package com.reddot.ecrm.controller.statement;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.dto.statement.StatementSearchDTO;
import com.reddot.ecrm.entity.statement_note.StatementNoteEntity;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.service.statement_note.StatementNoteService;
import com.reddot.ecrm.spring_config.session.SessionManager;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

@Controller
@RequiredArgsConstructor
@RequestMapping(value = "/statement/note")
public class StatementNoteViewController {

    private final StatementNoteService statementNoteService;

    @GetMapping
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        MDUserModel user = SessionManager.getUserDetails(request);

        model.put("login_name", user.getLOGIN_NAME());
        model.put("name", user.getNAME());
        model.put("logged_in_id", user.getID());
        model.put("userType", user.getUSER_TYPE());

        model.put("title", "Statement Note List");
        return "/statement/index";
    }

    @ResponseBody
    @RequestMapping(value = "/list/search-dt", method = RequestMethod.POST)
    public DataTablesOutput<StatementNoteEntity> getOpportunityListDT(@RequestBody Map<String, Object> data, HttpServletRequest request) throws JsonProcessingException {

        DataTablesInput input = new Gson().fromJson(
                Utility.ObjectToJson(data.get("dtInput")), new TypeToken<DataTablesInput>() {
                }.getType()
        );
        MDUserModel user = SessionManager.getUserDetails(request);

        ObjectMapper mapper = new ObjectMapper();
        StatementSearchDTO statementSearchDTO = mapper.readValue(data.get("searchData").toString(), StatementSearchDTO.class);

        if( user.getUSER_TYPE().equalsIgnoreCase("PIC") ){
            statementSearchDTO.setCompanyId(user.getCOMPANY_ID());
            statementSearchDTO.setCompanyName(user.getCOMPANY_NAME());
        }

        return statementNoteService.searchDataTable(input, statementSearchDTO);
    }

    @ResponseBody
    @RequestMapping(value = "/list/download-report", method = RequestMethod.POST)
    public ResponseEntity<?> downloadReport(@RequestBody StatementSearchDTO searchDTO, HttpServletRequest request, HttpServletResponse response) {
        statementNoteService.download(searchDTO, response);
        return new ResponseEntity<>("Ok", HttpStatus.OK);
    }
}
