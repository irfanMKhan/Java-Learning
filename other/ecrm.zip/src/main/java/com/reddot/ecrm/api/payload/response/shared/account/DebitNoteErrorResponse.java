package com.reddot.ecrm.api.payload.response.shared.account;

import lombok.Data;

import java.io.Serializable;
import java.lang.String;

@Data
public class DebitNoteErrorResponse implements Serializable {
  private Error error;

  @Data
  public static class Error implements Serializable {
    private String Exception;

    private String Code;

    private String Detail;

    private String message;
  }
}
