package com.reddot.ecrm.controller.lead.settings;

import com.reddot.ecrm.dto.lead.settings.CountryDto;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.lead.settings.CountryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("lead/country")
public class CountryRestController {
    
    @Autowired
    private CountryService countryService;
    
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    
    @GetMapping("/dt/all")
    public DataTablesOutput<CountryDto> dtCountry(@Valid DataTablesInput input, HttpServletRequest request,
                                                     @RequestParam(value = "searchText", required = false) String searchText, @RequestParam(value = "searchCol", required = false) String searchCol) {
        return countryService.getDTCountry(input, request, searchText, searchCol);
    }
    
    @GetMapping("/all")
    public ResponseEntity<?> getAllCountries(){
        List<CountryDto> countries = countryService.getAllCountriesWhereIsActive();
        if(countries.isEmpty()){
            return new ResponseEntity<>("No data found!", HttpStatus.NO_CONTENT);
        }
        else return new ResponseEntity<>(countries, HttpStatus.OK);
    }
    
    @PostMapping("/add")
    public CommonRestResponse addCountry(HttpServletRequest request, @RequestBody CountryDto countryDto) {
        return countryService.addCountry(request, countryDto);
    }
    
    @GetMapping("/details")
    public CommonRestResponse getCountryById(@RequestParam("id") Long id) {
        return countryService.getCountryById(id);
    }
    
    @PostMapping("/update")
    public CommonRestResponse updateCountry(HttpServletRequest request,
                                               @RequestBody CountryDto countryDto) {
        return countryService.updateCountry(request, countryDto);
    }
    
}