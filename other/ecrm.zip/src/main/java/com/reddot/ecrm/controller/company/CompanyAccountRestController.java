package com.reddot.ecrm.controller.company;

import com.reddot.ecrm.entity.company.CompanyAccountEntity;
import com.reddot.ecrm.service.company.CompanyAccountService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Set;

@RestController
@RequestMapping("company/account/rest")
@RequiredArgsConstructor
public class CompanyAccountRestController {
    private final CompanyAccountService companyAccountService;

    @PostMapping("/get/allBranchesByCompanyId")
    public Set<String> getAllBranchByCompanyIdAndService(@RequestBody CompanyAccountEntity companyAccount, HttpServletRequest request) {
        return companyAccountService.getAllBranchByCompanyIdAndService(companyAccount);
    }
}
