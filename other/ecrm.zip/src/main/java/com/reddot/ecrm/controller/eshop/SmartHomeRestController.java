package com.reddot.ecrm.controller.eshop;

import com.reddot.ecrm.entity.eshop.SimKit;
import com.reddot.ecrm.entity.eshop.SmartHome;
import com.reddot.ecrm.service.eshop.SimKitService;
import com.reddot.ecrm.service.eshop.SmartHomeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.security.Principal;

@RestController
@RequestMapping("/crm/eShop")
public class SmartHomeRestController {

    @Autowired
    private SmartHomeService smartHomeService;

    @GetMapping("/dataTable/smartHomeData")
    public DataTablesOutput<SmartHome> smartHomeData(@Valid DataTablesInput input, HttpServletRequest request, @RequestParam(value = "searchText", required = false) String searchText, @RequestParam(value = "searchCol", required = false) String searchCol, @RequestParam(value = "purchaseNo", required = false) String purchaseNo) {
        return smartHomeService.getDataTableSmartHome(input, request, searchText, searchCol, purchaseNo);
    }

    @GetMapping(value = "/deleteSmartHomeData")
    public String deleteSmartHomeData(ModelMap model, HttpServletRequest request, Principal principal, @RequestParam(value = "id", required = false) Long id) {
        return smartHomeService.deleteSmartHomeDataById(id);

    }

    @PostMapping("/addSmartHome")
    public String addSmartHome(HttpServletRequest request, @RequestBody SmartHome data) {
        return smartHomeService.addSmartHome(request, data);


    }
}
