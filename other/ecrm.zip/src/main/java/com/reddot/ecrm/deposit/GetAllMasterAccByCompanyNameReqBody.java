package com.reddot.ecrm.deposit;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetAllMasterAccByCompanyNameReqBody {
    private String companyName;
}
