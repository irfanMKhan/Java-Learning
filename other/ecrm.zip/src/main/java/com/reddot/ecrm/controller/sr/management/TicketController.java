package com.reddot.ecrm.controller.sr.management;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.dto.GlobalSettings.User.UserModelSR;
import com.reddot.ecrm.dto.sr.management.CreateSRModel;
import com.reddot.ecrm.dto.sr.management.SRCustomSearchModel;
import com.reddot.ecrm.dto.sr.management.TBLRecentRecordModelSR;
import com.reddot.ecrm.dto.sr.management.TBLSRActionModel;
import com.reddot.ecrm.dto.srsettings.QuesMgt.MDSmartScriptQuesListModel;
import com.reddot.ecrm.dto.srsettings.QuesMgt.SrSmartScriptQuesAnsList;
import com.reddot.ecrm.dto.srsettings.ServiceType.MDSrServiceTypeModel;
import com.reddot.ecrm.dto.srsettings.Status.MDSrStatusModel;
import com.reddot.ecrm.dto.srsettings.Type.SRTypeModelRedis;
import com.reddot.ecrm.dto.srsettings.subarea.MDSrSubAreaModel;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.Account.KDMModel;
import com.reddot.ecrm.model.CommonLovModel;
import com.reddot.ecrm.model.SMSTemplete;
import com.reddot.ecrm.model.TitleModel;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.repository.SRCreationRepository;
import com.reddot.ecrm.service.manageservice.ManageService;
import com.reddot.ecrm.session.SessionConstants;
import com.reddot.ecrm.spring_config.session.SessionManager;
import com.reddot.ecrm.util.QueryBuilder;
import com.reddot.ecrm.util.Utility;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Controller
@RequestMapping("/sr/management")
public class TicketController {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    private SRCreationRepository srdao;

    TitleModel titleModel = new TitleModel();

    @Autowired
    private CommonRepository commonDAO;

    @Autowired
    ManageService MS;

    @RequestMapping(value = "/viewticket", method = RequestMethod.GET)
    public String viewAllTicketsController(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        List<MDSrServiceTypeModel> empList = new ArrayList<>();
        titleModel = new TitleModel("ECRM", " Complaint Management", "", "", "Search SR");
//		SrTypeDAO SrTypeDAO = (SrTypeDAO) context.getBean("SrTypeDAO");
        model.addAttribute("ticketlist", empList);
        model.put("title", titleModel);
        List<CommonLovModel> areaList = new ArrayList<>();
        List<SRTypeModelRedis> srTypeList = new ArrayList<>();
        List<MDSrSubAreaModel> srSubAreaList = new ArrayList<>();
        List<MDSrStatusModel> statusList = new ArrayList<>();
        List<TBLRecentRecordModelSR> srList = new ArrayList<>();
        try {
//            srTypeList = redisDBSrSettings.getAllActiveSRType(1);
//            areaList = redisDBSrSettings.getAllActiveMDSrArea(1);

            Object objectss = commonDAO.getDataPostgres("SELECT NAME,ID, ACTIVE, SR_SERVICE_TYPE_NAME, SR_SERVICE_TYPE_ID FROM (SELECT SR_TYPE_NAME AS NAME, SR_TYPE_ID AS ID, ACTIVE, SR_SERVICE_TYPE_NAME, SR_SERVICE_TYPE_ID,  ROW_NUMBER() OVER(PARTITION BY SR_TYPE_NAME ORDER BY SR_TYPE_NAME) rn FROM " + Utility.md_sr_sub_area + " where active=1) t WHERE rn = 1 order by NAME");
            srTypeList = new Gson().fromJson(Utility.ObjectToJson(objectss), new TypeToken<List<CommonLovModel>>() {
            }.getType());

            Object objects = commonDAO.getDataPostgres("SELECT NAME,ID, ACTIVE, SR_SERVICE_TYPE_NAME, SR_SERVICE_TYPE_ID, SR_TYPE_ID, SR_TYPE_NAME FROM (SELECT SR_AREA_NAME AS NAME, SR_AREA_ID AS ID, ACTIVE, SR_SERVICE_TYPE_NAME, SR_SERVICE_TYPE_ID, SR_TYPE_ID, SR_TYPE_NAME,  ROW_NUMBER() OVER(PARTITION BY SR_AREA_NAME ORDER BY SR_AREA_NAME) rn FROM " + Utility.md_sr_sub_area + " where active=1) t WHERE rn = 1 order by NAME");
            areaList = new Gson().fromJson(Utility.ObjectToJson(objects), new TypeToken<List<CommonLovModel>>() {
            }.getType());

            Map<String, Object> searchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            searchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");
            String query = QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_sub_area, searchData, "ID,NAME", whereSearchType);
            logger.info(query);
            Object list = commonDAO.getDataPostgres(query);
            srSubAreaList = new Gson().fromJson(Utility.ObjectToJson(list), new TypeToken<List<MDSrSubAreaModel>>() {
            }.getType());
            Object statusListObject = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_status, searchData, "ID,NAME", whereSearchType));
            statusList = new Gson().fromJson(Utility.ObjectToJson(statusListObject), new TypeToken<List<MDSrStatusModel>>() {
            }.getType());

//            String recentRecordQuery = "SELECT SR_NUM FROM " + Utility.tbl_recent_records + " where USER_ID = '" + Utility.getUserId(request) + "' and VIEW_NAME='sr' GROUP BY SR_NUM OFFSET 0 ROWS FETCH NEXT 5 ROWS ONLY";
            String recentRecordQuery = "SELECT T.*\n" +
                    "FROM (SELECT tf.ID,\n" +
                    "             tf.SR_NUM,\n" +
                    "             ROW_NUMBER() OVER (\n" +
                    "                 PARTITION BY tf.SR_NUM\n" +
                    "                 ORDER BY tf.ID DESC\n" +
                    "                 ) as ROW_NUMBER\n" +
                    "      from tbl_recent_records tf\n" +
                    "      where tf.USER_ID = " + Utility.getUserId(request) + "\n" +
                    "        and tf.VIEW_NAME = 'sr'\n" +
                    "     ) T\n" +
                    "Where T.ROW_NUMBER = 1\n" +
                    "order by ID DESC\n" +
                    "OFFSET 0 ROWS FETCH NEXT 5 ROWS ONLY";
            Object listObject = commonDAO.getDataPostgres(recentRecordQuery);
            srList = new Gson().fromJson(Utility.ObjectToJson(listObject), new TypeToken<List<TBLRecentRecordModelSR>>() {
            }.getType());
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        model.put("areaList", areaList);
        model.put("srTypeList", srTypeList);
        model.put("srSubAreaList", srSubAreaList);
        model.put("statusList", statusList);
        model.put("srList", srList);
        return "ticket/searchSR";
    }

    @RequestMapping(value = "/listofticket", method = RequestMethod.GET)
    public String ListTicketsController(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        titleModel = new TitleModel("ECRM", "Complaint Management", "SR List", "", "SR Creation");
        model.put("title", titleModel);
        try {
            String query = "SELECT U.ID, U.NAME, U.LOGIN_NAME, U.EMAIL, U. USER_GROUP_ID, U.USER_GROUP_NAME, U.PRIMARY_RESP_ID, U.PRIMARY_RESP_NAME, U.POSITION_ID, U.WORK_PHONE, UD.SOURCE_ID, UD.SOURCE_LOCATION_ID, UD.POSITION_ORGANIZATION_ID, UD.POSITION_ORGANIZATION_NAME from MD_USER U LEFT JOIN MD_USER_DETAILS UD on U.ID=UD.USER_ID where U.ID=" + Utility.getUserId(request);
            Object object = commonDAO.getDataPostgres(query);
            List<UserModelSR> userModelSR = new Gson().fromJson(Utility.ObjectToJson(object), new TypeToken<List<UserModelSR>>() {
            }.getType());
            model.put("loginUser", userModelSR.get(0));
            if (model.containsAttribute("srCustomSearchModel") && model.get("srCustomSearchModel") != null)
                model.put("srCustomSearchModel", new JSONObject(model.get("srCustomSearchModel")));
            else {
                SRCustomSearchModel srCustomSearchModel = new SRCustomSearchModel();
                srCustomSearchModel.setSrNum("");
                model.put("srCustomSearchModel", new JSONObject(srCustomSearchModel));
            }

            if (model.containsAttribute("addTicketByMsisdn") && model.get("addTicketByMsisdn") != null)
                model.put("addTicketByMsisdn", model.getAttribute("addTicketByMsisdn"));
            else {
                model.put("addTicketByMsisdn", false);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            e.printStackTrace();
        }
        return "ticket/listofsr";
    }

    @PostMapping(value = "/listofticket")
    public String listOfTicketPost(ModelMap model, HttpServletRequest request, SRCustomSearchModel srCustomSearchModel, RedirectAttributes redirectAttributes) {
        try {
            redirectAttributes.addFlashAttribute("srCustomSearchModel", srCustomSearchModel);
            System.out.println("Custom search model: " + (new JSONObject(srCustomSearchModel)));
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            e.printStackTrace();
        }
        return "redirect:/sr/management/listofticket";
    }

    @GetMapping(value = "/listofticketBySRNum")
    public String listofticketBySRNum(RedirectAttributes redirectAttributes,
                                      @RequestParam("srNumber") String srNumber, @RequestParam(value = "msisdn", required = false) String msisdn,
                                      HttpServletRequest request) {
        try {
            SRCustomSearchModel srCustomSearchModel = new SRCustomSearchModel();
            srCustomSearchModel.setSrNum(srNumber);
            if (msisdn != null && !msisdn.isEmpty()) {
                srCustomSearchModel.setMsisdn(msisdn);
                SessionManager.saveAttribute(SessionConstants.SR_LAST_QUERY_MSISDN.name(), msisdn, request);
            }
            redirectAttributes.addFlashAttribute("srCustomSearchModel", srCustomSearchModel);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            e.printStackTrace();
        }
        return "redirect:/sr/management/listofticket";
    }

    @GetMapping(value = "/addTicketByMsisdn")
    public String addTicketByMsisdn(RedirectAttributes redirectAttributes,
                                    @RequestParam(value = "msisdn") String msisdn, HttpServletRequest request) {
        try {
            SRCustomSearchModel srCustomSearchModel = new SRCustomSearchModel();
            if (msisdn != null && !msisdn.isEmpty()) {
                srCustomSearchModel.setMsisdn(msisdn);
                SessionManager.saveAttribute(SessionConstants.SR_LAST_QUERY_MSISDN.name(), msisdn, request);
            }
            redirectAttributes.addFlashAttribute("srCustomSearchModel", srCustomSearchModel);
            redirectAttributes.addFlashAttribute("addTicketByMsisdn", true);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            e.printStackTrace();
        }
        return "redirect:/sr/management/listofticket";
    }

    @GetMapping(value = "/listofticketByCriteria")
    public String listofticketByCriteria(RedirectAttributes redirectAttributes,
                                         @RequestParam("viewCriteria") String viewCriteria) {
        try {
            redirectAttributes.addFlashAttribute("viewCriteria", viewCriteria);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            e.printStackTrace();
        }
        return "redirect:/sr/management/listofticket";
    }


    @RequestMapping(value = "/viewsrdetails", method = RequestMethod.GET)
    public String ViewSRDetails(ModelMap modelMap, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(modelMap, request);
        modelMap.put("title", "View SR Details");
        return "ticket/viewsrdetails";
    }

    @RequestMapping(value = "/openticket", method = RequestMethod.GET)
    public String OpenTicketsController(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Open Ticket");
        return "ticket/viewopenticket";
    }

    @RequestMapping(value = "/mycomplaint", method = RequestMethod.GET)
    public String MyComplaintController(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "My Complaints");
        return "ticket/MyComplaint";
    }

    @RequestMapping(value = "/allcomplaint", method = RequestMethod.GET)
    public String AllComplaintController(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        titleModel = new TitleModel("ECRM", "Complaint Management", "All Service Requests", "", "All Service Requests");
        model.put("title", titleModel);
        return "ticket/allcomplaint";
    }

    @RequestMapping(value = "/createticket", method = RequestMethod.GET)
    public String CreateTicketsController(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Create Ticket");
        return "ticket/createTicket";
    }

    @RequestMapping(value = "/createbatchticket", method = RequestMethod.GET)
    public String CreateBatchTicketsController(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Batch Ticket Creation");
        return "ticket/createTicket";
    }


    @RequestMapping(value = "/msisdndetails", method = RequestMethod.GET)
    public String msisdnDetailsController(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "MSISDN Details");
        return "ticket/msisdndetails";
    }

    /*************Submit SR Start******************/
    @RequestMapping(value = "/CreateSR", method = RequestMethod.POST)
    public String CreateSR(CreateSRModel csr) {
        srdao.createSR(csr);
        return "redirect:listofticket";
//        return "sr/management/listofticket";
    }

    /*************Submit SR End******************/

    @RequestMapping(value = "/getSRDetails", method = RequestMethod.GET)
    public String getSRDetailsView(Model model, HttpServletRequest request, @RequestParam(value = "srNumber") String srNumber) {
        model.addAttribute("srNumber", srNumber);

        List<SMSTemplete> cls;
        List<KDMModel> KDMDetails;
        String operator = "";
        String msisdn = "";
        try {
            operator = MS.getOperator(srNumber);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }

        try {
            cls = MS.getSMSTemplateForSR(operator);
//            msisdn = MS.getKDMMSISDN(srNumber);
//            KDMDetails = MS.getKDM(msisdn);
            model.addAttribute("lovData", cls);
//            model.addAttribute("kdmDetails", KDMDetails);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }

        return "ticket/includefile/SRDetails";
    }

    @RequestMapping(value = "/getSRAttachmentBlock", method = RequestMethod.GET)
    public String getSRAttachmentBlockView(Model model, HttpServletRequest request,
                                           @RequestParam(value = "srNumber") String srNumber,
                                           @RequestParam(value = "page") String page) {
        model.addAttribute("srNumber", srNumber);
        model.addAttribute("page", page);
        return "ticket/includefile/SRAttachmentView";
    }

    @RequestMapping(value = "/getSRBulkBlock", method = RequestMethod.GET)
    public String getSRBulkBlockView(Model model, HttpServletRequest request,
                                     @RequestParam(value = "srNumber") String srNumber,
                                     @RequestParam(value = "page") String page) {
        model.addAttribute("srNumber", srNumber);
        model.addAttribute("page", page);
        return "ticket/includefile/SRAttachmentView";
    }

    @RequestMapping(value = "/getNoteListView", method = RequestMethod.GET)
    public String getNoteListView(Model model, HttpServletRequest request, @RequestParam(value = "srNum") String srNum) {
        model.addAttribute("srNumber", srNum);
        return "ticket/includefile/noteList";
    }

    @RequestMapping(value = "/getAuditTrailView", method = RequestMethod.GET)
    public String getAuditTrailView(Model model, HttpServletRequest request, @RequestParam(value = "srNum") String srNum) {
        model.addAttribute("srNumber", srNum);
        List<TBLSRActionModel> list = new ArrayList<>();
        try {
//            Map<String, Object> searchData = new HashMap<String, Object>();
//            Map<String, Object> whereSearchType = new HashMap<String, Object>();
//            searchData.put("SR_NUM", srNum);
//            whereSearchType.put("SR_NUM", "AND");
            String query = "SELECT * FROM " + Utility.tbl_sr_actions + " WHERE SR_NUM='" + srNum + "' ORDER BY ID";
            Object listObject = commonDAO.getDataPostgres(query);
            list = new Gson().fromJson(Utility.ObjectToJson(listObject), new TypeToken<List<TBLSRActionModel>>() {
            }.getType());
            model.addAttribute("auditTrailList", list);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return "ticket/includefile/auditTrail";
    }

    @RequestMapping(value = "/getActivityView", method = RequestMethod.GET)
    public String getActivityView(ModelMap model, HttpServletRequest request, @RequestParam(value = "srNum") String srNum) {
        model.addAttribute("srNumber", srNum);
        return "ticket/includefile/activityView";
    }

    @RequestMapping(value = "/getSRSmartScriptBlock", method = RequestMethod.POST)
    public String getSRSmartScriptBlock(Model model, HttpServletRequest request,
                                        @RequestParam(value = "srNumber") String srNumber,
                                        @RequestParam(value = "page") String page,
                                        @RequestParam(value = "msisdn") String customerMsisdn,
                                        @RequestParam(value = "subarea") String subarea) {
        model.addAttribute("srNumber", srNumber);
        model.addAttribute("page", page);
        model.addAttribute("customerMsisdn", customerMsisdn);
        model.addAttribute("subarea", subarea);

        logger.info("fetching Smart Script Data ");
        String final_input_text = "";

        /* checking data is already submitted or not */

        List<SrSmartScriptQuesAnsList> SrSmartScriptQuesAnsData = new ArrayList<>();
        try {
            String qry_ans = "SELECT ID,SR_SUB_AREA_ID,SR_NUM,QUESTION_NAME,MSISDN,SR_QUES_ID,SR_QUES_TEXT,ANS_INPUT_TYPE,ANS_TEXT,ANS_TYPE_NAME,IS_MANDATORY,QUES_SEQUENCE FROM " + Utility.tbl_sr_ques_ans + " where SR_NUM=" + srNumber + " AND MSISDN=" + customerMsisdn + " AND SR_SUB_AREA_ID=" + subarea + " Order by ID ASC";
            logger.info("Query :" + qry_ans);
            Object SrQuesAnswerList = commonDAO.getDataPostgres(qry_ans);
            SrSmartScriptQuesAnsData = new Gson().fromJson(Utility.ObjectToJson(SrQuesAnswerList), new TypeToken<List<SrSmartScriptQuesAnsList>>() {
            }.getType());
        } catch (Exception ex) {
            ex.printStackTrace();
            logger.error(ex.getMessage(), ex);
        }

        System.out.println("Already Submitted SS data:" + Utility.ObjectToJson(SrSmartScriptQuesAnsData));
        logger.info("Already Submitted SS data:" + Utility.ObjectToJson(SrSmartScriptQuesAnsData));

        if (SrSmartScriptQuesAnsData.size() > 0) {
            for (SrSmartScriptQuesAnsList each_ans_row : SrSmartScriptQuesAnsData) {
                String required_level = "";
                if (each_ans_row.getIS_MANDATORY() == 1) {
                    required_level = " <span class='red-dark-2'>*</span>";
                } else {
                    required_level = "";
                }

                final_input_text = final_input_text + "<tr><td class='sr-num-title text-right' style='width: 350px'><span class='font-blod6'>" + each_ans_row.getSR_QUES_TEXT() + required_level + "</span></td>";
                final_input_text = final_input_text + "<td><input type='text' class='form-control-new'  value='" + each_ans_row.getANS_TEXT() + "' readonly></td></tr>";
            }
            model.addAttribute("quesList", Utility.ObjectToJson(SrSmartScriptQuesAnsData));
        } else {

            List<MDSmartScriptQuesListModel> MDSmartScriptQuesListModels = new ArrayList<>();
            try {
                String qry = "SELECT QAM.ID AS ID,QAM.SR_SUB_AREA_ID AS SR_SUB_AREA_ID,QAM.SR_QUES_ID AS SR_QUES_ID,QAM.QUES_SEQUENCE AS QUES_SEQUENCE,QAM.IS_MANDATORY AS IS_MANDATORY,Q.ANS_TYPE_ID,Q.ANS_TYPE_NAME,Q.HAS_CHILD_QUES,Q.CHILD_QUESTION_ID,Q.INPUT_OPTIONS,Q.ANS_INPUT_TYPE,Q.NAME,Q.QUESTION,Q.CHILD_QUESTION FROM MD_SR_SUBAREA_QUES_MAP QAM LEFT JOIN MD_SR_QUES Q ON Q.ID=QAM.SR_QUES_ID WHERE QAM.SR_SUB_AREA_ID=" + subarea + "  ORDER BY QAM.QUES_SEQUENCE,QAM.ID ASC";
                logger.info("Query :" + qry);
                Object SrQuesList = commonDAO.getDataPostgres(qry);
                MDSmartScriptQuesListModels = new Gson().fromJson(Utility.ObjectToJson(SrQuesList), new TypeToken<List<MDSmartScriptQuesListModel>>() {
                }.getType());
            } catch (Exception ex) {
                ex.printStackTrace();
                logger.error(ex.getMessage(), ex);
            }
            logger.info(Utility.ObjectToJson(MDSmartScriptQuesListModels));
            System.out.println(Utility.ObjectToJson(MDSmartScriptQuesListModels));
            logger.info("Returning smartscript ques list for sr sub area with data: " + MDSmartScriptQuesListModels.size());
            System.out.println(Utility.ObjectToJson(MDSmartScriptQuesListModels));
            model.addAttribute("quesList", Utility.ObjectToJson(MDSmartScriptQuesListModels));


            /* generating ques : start */


            for (MDSmartScriptQuesListModel data : MDSmartScriptQuesListModels) {
                String final_each_input = "";
                String final_each_input2 = "";
                String required_level = "";
                String req = "";
                if (data.getIS_MANDATORY() == 1) {
                    req = "required";
                    required_level = " <span class='red-dark-2'>*</span>";
                } else {
                    req = "";
                    required_level = "";
                }

                String final_each_input1 = "<tr><td class='sr-num-title text-right' style='width: 350px'><span class='font-blod6'>" + data.getQUESTION() + required_level + "</span></td>";
                System.out.println(data.getANS_TYPE_NAME());
                if (data.getANS_TYPE_NAME().equals("MSISDN") || data.getANS_TYPE_NAME().equals("Number_or_digit") || data.getANS_TYPE_NAME().equals("String_or_text")) {
                    // final_each_input2="<td><input type='"+data.getANS_INPUT_TYPE()+"' class='form-control-new' name='"+data.getSR_QUES_ID()+"' id='"+data.getSR_QUES_ID()+"' "+ req +"></td>";
                    final_each_input2 = "<td><input type='text' class='form-control-new' name='" + data.getSR_QUES_ID() + "' id='" + data.getSR_QUES_ID() + "' " + req + "></td>";
                } else if (data.getANS_TYPE_NAME().equals("Textarea")) {
                    final_each_input2 = "<td><textarea class='form-control-new' id='" + data.getSR_QUES_ID() + "' name='" + data.getSR_QUES_ID() + "' " + req + "></textarea></td>";
                } else if (data.getANS_TYPE_NAME().equals("Dropdown")) {
                    final_each_input2 = "";
                    final_each_input2 = final_each_input2 + "<td><select  class='form-control form-control-new select2' name='" + data.getSR_QUES_ID() + "' id='" + data.getSR_QUES_ID() + "' " + req + ">";
                    final_each_input2 = final_each_input2 + "<option value=''></option>";

                    if (!data.getINPUT_OPTIONS().isEmpty()) {
                        String[] split = data.getINPUT_OPTIONS().split("//");
                        for (String op_data : split) {
                            final_each_input2 = final_each_input2 + "<option value='" + op_data + "'>" + op_data + "</option>";
                        }
                    }
                    final_each_input2 = final_each_input2 + "</select></td>";
                } else if (data.getANS_TYPE_NAME().equals("Radio_button")) {
                    final_each_input2 = "";
                    final_each_input2 = final_each_input2 + "<td><div class='row'>";
                    Integer radio_num = 1;
                    if (!data.getINPUT_OPTIONS().isEmpty()) {
                        String[] split = data.getINPUT_OPTIONS().split("//");
                        for (String op_data : split) {
                            //final_each_input2=final_each_input2+"<div class='col-md-2 mt-15'><div class='custom-control custom-radio'><input type='radio' value='"+op_data+"' id='"+data.getSR_QUES_ID()+"_"+radio_num+"'   name='"+data.getSR_QUES_ID()+"' class='custom-control-input'><label class='custom-control-label' for='"+data.getSR_QUES_ID()+"_"+radio_num+"'>"+op_data+"</label></div></div>";
                            final_each_input2 = final_each_input2 + "<div class='col-md-2 mt-15'><div class='custom-control custom-radio'><input type='radio' value='" + op_data + "' id='" + "id_" + data.getSR_QUES_ID() + "_" + radio_num + "'   name='" + "name_" + data.getSR_QUES_ID() + "' class='custom-control-input' required><label class='custom-control-label' for='" + "id_" + data.getSR_QUES_ID() + "_" + radio_num + "'>" + op_data + "</label></div></div>";
                            radio_num++;
                        }

                    }
                    final_each_input2 = final_each_input2 + "</div></td>";
                } else if (data.getANS_TYPE_NAME().equals("Date_and_Time")) {
                    //  final_each_input2="<td><div class='form-group form-group-custom-ticket' style='width: 40%;'><div class='input-group date date-activity'><input type='text' "+req+" id='"+data.getSR_QUES_ID()+"' name='"+data.getSR_QUES_ID()+"' class='form-control' placeholder='YYYY-MM-DD HH:mm:ss' style='height: 30px'/><div class='input-group-addon input-group-append'><div class='input-group-text'><i class='glyphicon glyphicon-calendar fa fa-calendar'></i></div></div></div></div></td>";
                    final_each_input2 = "<td><input type='text' class='form-control-new' name='" + data.getSR_QUES_ID() + "' placeholder='YYYY-MM-DD HH:mm:ss'  id='" + data.getSR_QUES_ID() + "' " + req + "></td>";
                } else if (data.getANS_TYPE_NAME().equals("Date")) {
                    // final_each_input2="<td><div class='form-group form-group-custom-ticket' style='width: 40%;'><div class='input-group date date-picker-b4'><input type='text' "+req+" id='"+data.getSR_QUES_ID()+"' name='"+data.getSR_QUES_ID()+"' class='form-control SSSubmissionDate' placeholder='YYYY-MM-DD'  style='height: 30px'/><div class='input-group-addon input-group-append'><div class='input-group-text'><i class='glyphicon glyphicon-calendar fa fa-calendar'></i></div></div></div></div></td>";
                    final_each_input2 = "<td><input type='text' class='form-control-new' name='" + data.getSR_QUES_ID() + "' placeholder='YYYY-MM-DD'  id='" + data.getSR_QUES_ID() + "' " + req + "></td>";
                } else if (data.getANS_TYPE_NAME().equals("Checkbox")) {
                    final_each_input2 = "";
                    final_each_input2 = final_each_input2 + "<td><div class='row'>";
                    Integer checkbox_num = 1;
                    if (!data.getINPUT_OPTIONS().isEmpty()) {
                        String[] split = data.getINPUT_OPTIONS().split("//");
                        for (String op_data : split) {
                            final_each_input2 = final_each_input2 + "<div class='col-md-2 mt-15'><div class='custom-control custom-checkbox checkbox-teal'><input type='checkbox' class='custom-control-input' value='" + op_data + "' id='" + data.getSR_QUES_ID() + "_" + checkbox_num + "' name='" + data.getSR_QUES_ID() + "_" + checkbox_num + "'><label class='custom-control-label' for='" + data.getSR_QUES_ID() + "_" + checkbox_num + "'>" + op_data + "</label></div></div>";
                            checkbox_num++;
                        }
                    }
                    final_each_input2 = final_each_input2 + "</div></td>";
                }
                String final_each_input3 = "</tr>";
                final_each_input = final_each_input1 + final_each_input2 + final_each_input3;

                final_input_text = final_input_text + final_each_input;
            }

        }

        model.addAttribute("final_input_text", final_input_text);
        model.addAttribute("final_ans_size", SrSmartScriptQuesAnsData.size());
        /* generating ques : end */
        System.out.println(final_input_text);

        return "ticket/includefile/ssCreateView";
    }

}
