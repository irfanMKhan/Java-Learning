package com.reddot.ecrm.controller.approval.approval_flow;

import com.reddot.ecrm.entity.approval.ApprovalFlowEntity;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.repository.approval.ApprovalFlowRepo;
import com.reddot.ecrm.service.approval.ApprovalFlowService;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("approval/flow/rest")
public class ApprovalFlowRestController {
    @Autowired
    ApprovalFlowService approvalFlowService;

    @Autowired
    ApprovalFlowRepo approvalFlowRepo;

    @GetMapping("/get/allFlowData")
    List<ApprovalFlowEntity> getAllFlowDataWithOutHasRule(HttpServletRequest request) {
        Long tenantId = Utility.loggedInTenantId(request);
        return approvalFlowRepo.findAllByTenantId(tenantId);
    }


//    @GetMapping("/getAllFlowData")
//    List<ApprovalFlowEntity> getAllFlowData() {
//        return (List<ApprovalFlowEntity>) approvalFlowService.getAllApprovalFlowData().getData();
//    }

    @PostMapping("/getSingleData")
    public CommonRestResponse getSingleData(@RequestBody Long id) {
        return approvalFlowService.getSingleData(id);
    }

    @PostMapping("/add")
    public CommonRestResponse addFlow(@RequestBody ApprovalFlowEntity approvalFlowEntity, HttpServletRequest request) {
        return approvalFlowService.addApprovalFlow(approvalFlowEntity, request);
    }

    @PostMapping("/update")
    public CommonRestResponse updateData(@RequestBody ApprovalFlowEntity approvalFlowEntity, HttpServletRequest request) {
        return approvalFlowService.updateData(approvalFlowEntity, request);
    }

    @PostMapping("/delete")
    public CommonRestResponse deleteData(@RequestBody Long id) {
        return approvalFlowService.deleteData(id);
    }

    @GetMapping("/getAll/unitData")
    public CommonRestResponse getAllUnitData() {
        return approvalFlowService.getAllUnitData();
    }
}
