package com.reddot.ecrm.delayPayment;

import com.reddot.ecrm.delayPayment.rest.dto.GetAllPromiseToPayByAccountCode;
import com.reddot.ecrm.delayPayment.rest.dto.GetAllPromiseToPayDetailByPromiseToPayId;
import com.reddot.ecrm.entity.attachment.AttachmentEntity;
import com.reddot.ecrm.enum_config.bulk.BulkProcessFileTypeEnum;
import com.reddot.ecrm.service.attachment.AttachmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@RestController
public class PromiseToPayRestController {
    @Autowired
    private PromiseToPayService promiseToPayService;
    @Autowired
    private AttachmentService attachmentService;

    @RequestMapping(value = "/promise-to-pay/add", method = RequestMethod.POST)
    public ResponseEntity<?> addPromiseToPay(HttpServletRequest httpServletRequest, @RequestBody PromiseToPayAddReqBody reqBody) {
        System.out.println(reqBody);
        return promiseToPayService.addPromiseToPay(httpServletRequest, reqBody);
    }

    @ResponseBody
    @GetMapping("/promise-to-pay/add/list/add/get/attachments")
    public List<AttachmentEntity> getAttachmentsList(String moduleId) {
        if (Objects.equals(moduleId, ""))
            return new ArrayList<AttachmentEntity>();
        else {
            return attachmentService.findAllByModuleIdAndModuleName(Long.valueOf(moduleId), BulkProcessFileTypeEnum.Delay_payment.getKey());
        }
    }

    @RequestMapping(value = "/promise-to-pay/get-all", method = RequestMethod.GET)
    public ResponseEntity<?> getAllFromPromiseToPay(HttpServletRequest httpServletRequest) {
        return promiseToPayService.getAllFromPromiseToPay(httpServletRequest);
    }

    @RequestMapping(value = "/promise-to-pay/get-all/{id}", method = RequestMethod.GET)
    public ResponseEntity<?> getAllFromPromiseToPayByPromiseId(HttpServletRequest httpServletRequest, @PathVariable("id") String promiseToPayId) {
        return promiseToPayService.getAllFromPromiseToPayByPromiseId(httpServletRequest, promiseToPayId);
    }

//    @RequestMapping(value = "/promise-to-pay/get-all/{id}", method = RequestMethod.GET)
//    public ResponseEntity<?> getAllFromPromiseToPayByPromiseId(HttpServletRequest httpServletRequest, GetAllPromiseToPayDetailByPromiseToPayId req) {
//        return promiseToPayService.getAllFromPromiseToPayByPromiseId(httpServletRequest, req.getPromiseToPayId());
//    }

    @RequestMapping(value = "/promise-to-pay/get-all-by-account-code", method = RequestMethod.POST)
    public ResponseEntity<?> getAllPromiseToPayByAccountCode(HttpServletRequest httpServletRequest, @RequestBody GetAllPromiseToPayByAccountCode reqBody) {
        return promiseToPayService.getAllPromiseToPayByAccountCode(httpServletRequest, reqBody);
    }

//    @RequestMapping(value = "/promise-to-pay/get-all-by-account-code", method = RequestMethod.POST)
//    public ResponseEntity<?> getAllPromiseToPayDetailByPromiseToPayId(HttpServletRequest httpServletRequest, @RequestBody GetAllPromiseToPayDetailByPromiseToPayId reqBody) {
//        return promiseToPayService.getAllPromiseToPayDetailByPromiseToPayId(httpServletRequest, reqBody);
//    }
}
