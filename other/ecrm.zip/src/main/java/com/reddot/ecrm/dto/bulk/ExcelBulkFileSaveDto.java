package com.reddot.ecrm.dto.bulk;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExcelBulkFileSaveDto {
    private MultipartFile file;
    private Long companyId;
    private String companyName;
    private LocalDate processDateValue;
    private String bulkProcessFileTypeEnum;
    private String bulkProcessFileTypeId;
    private String fileLocation;
}
