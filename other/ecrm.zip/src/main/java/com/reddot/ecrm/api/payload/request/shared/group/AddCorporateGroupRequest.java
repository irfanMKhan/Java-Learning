package com.reddot.ecrm.api.payload.request.shared.group;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.lang.String;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AddCorporateGroupRequest implements Serializable {
  private AddMemberInfo AddMemberInfo;

  private ReqHeader ReqHeader;

  private String CustomerId;

  private String GroupId;

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class AddMemberInfo implements Serializable {
    private String HybridFlag;

    private String MemberServiceNum;

    private String MemberType;

    private String DepartmentName;

    private String text;

    private String DepartmentID;

    private String OperateType;
  }

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class ReqHeader implements Serializable {
    private String ReqTime;

    private String Version;

    private String BusinessCode;

    private String Channel;

    private String AccessPassword;

    private String PartnerId;

    private String TransactionId;

    private String AccessUser;
  }
}
