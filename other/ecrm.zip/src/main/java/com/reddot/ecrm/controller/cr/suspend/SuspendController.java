package com.reddot.ecrm.controller.cr.suspend;

import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.spring_config.session.SessionManager;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequiredArgsConstructor
@RequestMapping(value = "/cr/suspend", method = RequestMethod.GET)
public class SuspendController {

    @GetMapping("")
    public String viewSuspend() {
        return "redirect:/cr/suspend/list";
    }

    @GetMapping("/list")
    String viewSuspendList(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Suspend");
        return "cr/suspend/suspend_list";
    }

    @GetMapping("/add")
    String viewSuspendAdd(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Suspend");

        MDUserModel user = SessionManager.getUserDetails(request);

        model.put("login_name", user.getLOGIN_NAME());
        model.put("name", user.getNAME());
        model.put("logged_in_id", user.getID());

        return "cr/suspend/suspend_add";
    }
}
