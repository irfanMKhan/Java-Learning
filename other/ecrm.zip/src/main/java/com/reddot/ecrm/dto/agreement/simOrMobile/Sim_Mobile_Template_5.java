package com.reddot.ecrm.dto.agreement.simOrMobile;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class Sim_Mobile_Template_5 {
    private Integer no;
    private String phoneNumber;
    private String plan;
    private String creditLimit;
    private String contractTerm;
    private String startingDate;
    private String internationalRoaming;
}
