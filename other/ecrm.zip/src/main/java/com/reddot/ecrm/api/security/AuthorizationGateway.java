package com.reddot.ecrm.api.security;

import com.google.gson.Gson;
import com.reddot.ecrm.api.exception.ApiRequestException;
import com.reddot.ecrm.api.exception.ConnectionResetException;
import com.reddot.ecrm.api.exception.InvalidClientCredentialException;
import com.reddot.ecrm.api.payload.response.shared.auth.AuthErrorResponse;
import com.reddot.ecrm.api.payload.response.shared.auth.AuthSuccessResponse;
import com.reddot.ecrm.api.utility.CommonConstant;
import com.reddot.ecrm.api.utility.HttpClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.FormBody;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthorizationGateway {

    private final HttpClient httpClient;
    private final Gson gson;
    

    @Value("${smart.egw.base.url}")
    String baseUrlEGW;
    @Value("${smart.egw.token}")
    String tokenEGW;
    @Value("${smart.igw.base.url}")
    String baseUrlIGW;
    @Value("${smart.igw.token}")
    String tokenIGW;

    @Retryable(value = { ConnectionResetException.class }, maxAttemptsExpression = "${retry.socket.maxAttempts}" , backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public AuthSuccessResponse getTokenIGW() {
        String apiUrl = baseUrlIGW + "/token";

        RequestBody formBody = new FormBody.Builder()
                .add("grant_type", "client_credentials")
                .build();

        Map<String, String> headers = new HashMap<>() {{
            put("Authorization", "Basic " + tokenIGW);
            put("Accept", "application/json");
            put("Content-Type", "application/x-www-form-urlencoded");
        }};

        try (Response response = httpClient.post(formBody, apiUrl, headers)) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), AuthSuccessResponse.class);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()){
                AuthErrorResponse errorResponse = gson.fromJson(response.body().string(), AuthErrorResponse.class);
                throw new InvalidClientCredentialException(errorResponse.getError_description());
            } else {
                AuthErrorResponse errorResponse = gson.fromJson(response.body().string(), AuthErrorResponse.class);
                throw new ApiRequestException(errorResponse.getError_description());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.error("Authorization Gateway Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidClientCredentialException) {
                log.error("Authorization Gateway Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("Authorization Gateway Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = { ConnectionResetException.class }, maxAttemptsExpression = "${retry.socket.maxAttempts}" , backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public AuthSuccessResponse getTokenEGW() {
        String apiUrl = baseUrlEGW + "/token";

        RequestBody formBody = new FormBody.Builder()
                .add("grant_type", "client_credentials")
                .build();

        Map<String, String> headers = new HashMap<>() {{
            put("Authorization", "Basic " + tokenEGW);
            put("Accept", "application/json");
            put("Content-Type", "application/x-www-form-urlencoded");
        }};

        try (Response response = httpClient.post(formBody, apiUrl, headers)) {
            assert response.body() != null;

            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), AuthSuccessResponse.class);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()){
                AuthErrorResponse errorResponse = gson.fromJson(response.body().string(), AuthErrorResponse.class);
                throw new InvalidClientCredentialException(errorResponse.getError_description());
            } else {
                AuthErrorResponse errorResponse = gson.fromJson(response.body().string(), AuthErrorResponse.class);
                throw new ApiRequestException(errorResponse.getError_description());
            }

        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.error("Authorization Gateway Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidClientCredentialException) {
                log.error("Authorization Gateway Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("Authorization Gateway Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

}
