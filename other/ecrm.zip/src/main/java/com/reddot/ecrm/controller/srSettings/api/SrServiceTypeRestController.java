package com.reddot.ecrm.controller.srSettings.api;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.model.srSettings.SrServiceTypeModel;
import com.reddot.ecrm.service.srsettings.SrServiceTypeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequestMapping(value = "/api/srServiceType", method = RequestMethod.GET)
public class SrServiceTypeRestController {

    private final Logger logger = LoggerFactory.getLogger("SR Service Type Logger");

    @Autowired
    private SrServiceTypeService service;

    @GetMapping("/all")
    public Object getAllServiceType() {
        return service.getAllServiceType();
    }

    @GetMapping("/DTData")
    public DataTablesOutput<SrServiceTypeModel> DTInteractionType(@Valid DataTablesInput input, HttpServletRequest request,
                                                                  @RequestParam(value = "searchText", required = false) String customQuery,
                                                                  @RequestParam(value = "customSearchCriteria", required = false) String customSearchCriteria) {
        return service.DTSrServiceType(input, request, customSearchCriteria, customQuery);
    }

    @PostMapping("/add")
    public CommonRestResponse srServiceTypeAdd(@RequestBody String srServiceType, HttpServletRequest request) {
        SrServiceTypeModel srServiceTypeModel = new Gson().fromJson(srServiceType, new TypeToken<SrServiceTypeModel>() {
        }.getType());
//        SrStatusModel SrStatusModel = new Gson().fromJson(srPriority, SrStatusModel.class);
        System.err.println(srServiceType);
        System.err.println(srServiceTypeModel);
        return service.addSrServiceTypeFunction(srServiceTypeModel, request);
    }

    @GetMapping("/item")
    public CommonRestResponse getServiceTypeItemById(@RequestParam("item") String id, HttpServletRequest request) {
        String serviceTypeId = new Gson().fromJson(id, String.class);
        return service.getServiceTypeItemById(serviceTypeId);
    }

    @PostMapping("/update")
    public CommonRestResponse updateServiceTypeFunction(@RequestBody String serviceTypeData, HttpServletRequest request) {
//        SrStatusModel SrStatusModel = new Gson().fromJson(priorityData,SrStatusModel.class);
        SrServiceTypeModel srServiceTypeModel = new Gson().fromJson(serviceTypeData, new TypeToken<SrServiceTypeModel>() {
        }.getType());
        System.err.println(serviceTypeData);
        System.err.println(srServiceTypeModel);
        return service.updateServiceTypeFunction(srServiceTypeModel, request);
    }
}
