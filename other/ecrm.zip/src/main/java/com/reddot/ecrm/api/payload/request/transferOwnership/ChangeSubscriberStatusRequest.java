package com.reddot.ecrm.api.payload.request.transferOwnership;

import lombok.Data;

import java.io.Serializable;

@Data
public class ChangeSubscriberStatusRequest implements Serializable {

    private BssInfo bss_info;

    private ChangeStatus change_status;

    private String transaction_id;

    private String channel_id;

    @Data
    public static class BssInfo implements Serializable {

        private String username;

        private String password;

        private String operator_id;
    }

    @Data
    public static class ChangeStatus implements Serializable {


        private String operation_type;

        private String reason_code;
    }

 /*   public ReqHeader ReqHeader;

    public AccessInfo AccessInfo;

    public Integer OperateType;

    public Integer ReasonCode;


    @Data
    public static class AccessInfo implements Serializable {

        public Integer ObjectIdType;

        public Integer ObjectId;

    }

    @Data
    public static class ReqHeader implements Serializable {

        public Integer Version;

        public Long BusinessCode;

        public String TransactionId;

        public Integer Channel;

        public Integer PartnerId;

        public Long ReqTime;

        public String AccessUser;

        public String AccessPassword;

    }*/
}
