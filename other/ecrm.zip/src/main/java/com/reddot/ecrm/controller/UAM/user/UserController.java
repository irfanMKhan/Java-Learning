package com.reddot.ecrm.controller.UAM.user;

import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.service.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping(value = "/users", method = RequestMethod.GET)
public class UserController {

    @Autowired
    private UserService service;

    @GetMapping("")
    public String getUsersPage(){
        return "redirect:/users/list";
    }

    @GetMapping({"/list"})
    public String getUsersListView(ModelMap model, HttpServletRequest request){
        new MenuViewer().setupSideMenu(model, request);
        model.addAttribute("title", "Users");
        model.addAttribute("breadcrumb", "Users");
        return "user/user_list";
    }

    @GetMapping({"/add"})
    public String getUsersAddView(ModelMap model, HttpServletRequest request){
        new MenuViewer().setupSideMenu(model, request);
        model.addAttribute("title", "Add User");
        model.addAttribute("breadcrumb", "Add");
        return "user/user_add";
    }

    @GetMapping({"/{id}"})
    public String getUsersUpdateView(@PathVariable("id") String id, ModelMap model, HttpServletRequest request){
        new MenuViewer().setupSideMenu(model, request);
        model.addAttribute("title", "Update User");
        model.addAttribute("breadcrumb", "Update");
        model.addAttribute("id", id);
        return "user/user_update";
    }
}
