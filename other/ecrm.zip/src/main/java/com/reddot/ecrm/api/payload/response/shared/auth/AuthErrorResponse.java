package com.reddot.ecrm.api.payload.response.shared.auth;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.lang.String;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuthErrorResponse implements Serializable {
  private String error_description;

  private String error;
}
