package com.reddot.ecrm.delayPayment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

@Service
public class SubGroupService {
    @Autowired
    private SubGroupRepo subGroupRepo;

    public ResponseEntity<?> getAllAccountCode(HttpServletRequest httpServletRequest) {
        return new ResponseEntity<>(subGroupRepo.findAll(), HttpStatus.OK);
    }
}
