package com.reddot.ecrm.controller.lead;

import com.reddot.ecrm.dto.lead.LeadContactDto;
import com.reddot.ecrm.service.lead.LeadContactService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/leadContact")
public class LeadContactRestController {
    
    private final Logger logger = LoggerFactory.getLogger(LeadRestController.class);
    
    @Autowired
    private LeadContactService leadContactService;
    
    @GetMapping("/byLead")
    public List<LeadContactDto> getAllByLeadId(@RequestParam("leadId") Long leadId) {
        return leadContactService.getAllLeadContactByLeadId(leadId);
    }

    @PostMapping("/idList")
    public ResponseEntity<?> getAllByLeadIdList(@RequestBody Long[] leadIds) {
        List<LeadContactDto> leadContactDtoList = leadContactService.getALlLeadContactByLeadIdList(leadIds);
        if(leadContactDtoList.isEmpty()){
            return new ResponseEntity<>("Empty PIC list for selected leads", HttpStatus.NO_CONTENT);
        }
        else return new ResponseEntity<>(leadContactDtoList, HttpStatus.OK);
    }
    
}