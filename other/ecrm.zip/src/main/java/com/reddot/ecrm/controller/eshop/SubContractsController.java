package com.reddot.ecrm.controller.eshop;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.entity.eshop.Product;
import com.reddot.ecrm.entity.eshop.SubContractsEntity;
import com.reddot.ecrm.enum_config.subContract.DiscountTypeEnum;
import com.reddot.ecrm.enum_config.subContract.PaymentTermTypeEnum;
import com.reddot.ecrm.enum_config.subContract.PaymentTypeEnum;
import com.reddot.ecrm.enum_config.subContract.SpecialOfferEnum;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.ProductModel;
import com.reddot.ecrm.model.User.UserModel;

import com.reddot.ecrm.service.company.CompanyService;
import com.reddot.ecrm.service.eshop.ProductService;
import com.reddot.ecrm.service.eshop.SubContractsService;
import com.reddot.ecrm.service.user.UserService;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Controller
@RequestMapping("/crm/eShop")
public class SubContractsController {
    @Autowired
    private SubContractsService subContractsService;

    @Autowired
    private ProductService productService;

    @Autowired
    private CompanyService companyService;

    @Autowired
    private UserService userService;

    @RequestMapping(value = "/subContract", method = RequestMethod.GET)
    public String viewSubContract(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.addAttribute("subcontract", subContractsService.getAllSubContracts());
        model.addAttribute("title", "Sub-Contract");
        model.addAttribute("breadcrumb", "SubContract");
        return "subContract/subContractsList";
    }

    @RequestMapping(value = "/addSubContract", method = RequestMethod.GET)
    public String addSubContract(ModelMap model, HttpServletRequest request, Principal principal) {

        new MenuViewer().setupSideMenu(model, request);
        List<UserModel> userData = new ArrayList<>();
        userData = new Gson().fromJson(Utility.ObjectToJson(userService.getUserByUserName(principal.getName())), new TypeToken<List<UserModel>>() {
        }.getType());

        List<CompanyEntity> listOfCompany = companyService.getAllCompany();
        List<Product> listOfProduct = productService.getAllProducts();

        model.addAttribute("userData", userData.get(0));
        model.put("title", "Sub Contract");
        model.put("listOfCompany", listOfCompany);
        model.put("listOfProduct", listOfProduct);
        model.put("PaymentTypeEnum", PaymentTypeEnum.values());
        model.put("SpecialOfferEnum", SpecialOfferEnum.values());

        model.put("paymentTermTypeEnum", PaymentTermTypeEnum.values());
        model.put("discountTypeEnum", DiscountTypeEnum.values());

        return "subContract/addEditSubContracts";
    }

    @RequestMapping(value = "/editSubContract/{id}", method = RequestMethod.GET)
    public String editSubContract(ModelMap model, HttpServletRequest request, Principal principal, @PathVariable(name = "id") Long id) {

        new MenuViewer().setupSideMenu(model, request);

        SubContractsEntity subContractData = subContractsService.getSubContractsById(id);
        List<CompanyEntity> listOfCompany = companyService.getAllCompany();
        List<Product> listOfProduct = productService.getAllProducts();
        List<String> selectedSpecialOfferData=Arrays.asList(subContractData.getSpecialOffer().split(","));
        model.put("title", "Sub Contract");
        model.put("subContractData", subContractData);
        model.put("listOfCompany", listOfCompany);
        model.put("selectedCompany", subContractData.getCompany());
        model.put("listOfProduct", listOfProduct);
        model.put("selectedProduct", subContractData.getProduct());
        model.put("PaymentTypeEnum", PaymentTypeEnum.values());
        model.put("selectedPaymentType", subContractData.getPaymentType());
        model.put("paymentTermTypeEnum", PaymentTermTypeEnum.values());

        model.put("SpecialOfferEnum", SpecialOfferEnum.values());
        //need to work
        model.put("selectedSpecialOfferEnum", selectedSpecialOfferData);

        //model.put("selectedPaymentTermType", subContractData.getPaymentTermType());
        model.put("discountTypeEnum", DiscountTypeEnum.values());
        //model.put("selectedDiscountType", subContractData.getDiscountType());
        model.put("selectedExpiryDate", subContractData.getExpiryDate());
        return "subContract/addEditSubContracts";
    }

    @RequestMapping(value ="/deleteSubContract/{id}", method = RequestMethod.GET)
    public String deleteSubContract(ModelMap model, HttpServletRequest request, Principal principal,@PathVariable(name = "id") Long id) {
        subContractsService.deleteSubContractsById(id);
        return "subContract/subContractsList";

    }

}
