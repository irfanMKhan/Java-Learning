//package com.reddot.ecrm.controller.GlobalSettingsController;
//
//import com.google.gson.Gson;
//import com.google.gson.reflect.TypeToken;
//import com.robi.dcrm.config.QueryBuilder;
//import com.robi.dcrm.config.Utility;
//import com.robi.dcrm.config.menu.MenuViewer;
//import com.robi.dcrm.model.GlobalSettings.AccountClass.MDAccountClassModel;
//import com.robi.dcrm.model.GlobalSettings.AccountClass.QueryMDAccountClassModel;
//import com.robi.dcrm.model.GlobalSettings.AccountType.MDAccountTypeModel;
//import com.robi.dcrm.model.GlobalSettings.AccountType.QueryMDAccountTypeModel;
//import com.robi.dcrm.model.GlobalSettings.District.MDDistrictModel;
//import com.robi.dcrm.model.GlobalSettings.District.QueryMDDistrictModel;
//import com.robi.dcrm.model.GlobalSettings.Division.MDDivisionModel;
//import com.robi.dcrm.model.GlobalSettings.Division.QueryMDDivisionModel;
//import com.robi.dcrm.model.GlobalSettings.Menu.MDMenuModel;
//import com.robi.dcrm.model.GlobalSettings.Menu.QueryMDMenuModel;
//import com.robi.dcrm.model.GlobalSettings.Responsibility.MDResponsibilityModel;
//import com.robi.dcrm.model.GlobalSettings.Responsibility.QueryMDResponsibilityModel;
//import com.robi.dcrm.model.GlobalSettings.SourceList.MDSourceListModel;
//import com.robi.dcrm.model.GlobalSettings.SourceList.QueryMDSourceListModel;
//import com.robi.dcrm.model.GlobalSettings.SourceLocation.MDSourceLocationModel;
//import com.robi.dcrm.model.GlobalSettings.SourceLocation.QueryMDSourceLocationModel;
//import com.robi.dcrm.model.GlobalSettings.Upazila.MDUpazilaModel;
//import com.robi.dcrm.model.GlobalSettings.Upazila.QueryMDUpazilaModel;
//import com.robi.dcrm.model.GlobalSettings.User.MDUserModel;
//import com.robi.dcrm.model.GlobalSettings.User.QueryMDUserModel;
//import com.robi.dcrm.model.GlobalSettings.UserGroup.MDUserGroupModel;
//import com.robi.dcrm.model.GlobalSettings.UserGroup.QueryMDUserGroupModel;
//import com.robi.dcrm.model.GlobalSettings.UserPosition.MDUserPositionModel;
//import com.robi.dcrm.model.GlobalSettings.UserPosition.QueryMDUserPositionModel;
//import com.robi.dcrm.model.GlobalSettings.position.MDUserPosition;
//import com.robi.dcrm.model.SrSettings.TBLDataShowModel;
//import com.robi.dcrm.model.TitleModel;
//import com.robi.dcrm.model.bulk.PostData;
//import com.robi.dcrm.pool_repository.CommonRepository;
//import com.robi.dcrm.pool_repository.GlobalSettingsRepository;
//import com.robi.dcrm.pool_repository.UsersRepository;
//import com.robi.dcrm.service.GlobalSettings.UserManagementService;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.ModelMap;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.multipart.MultipartFile;
//import org.springframework.web.servlet.mvc.support.RedirectAttributes;
//
//import javax.servlet.http.HttpServletRequest;
//import java.util.*;
//
//
//@Controller
//@RequestMapping("/settings/global")
//public class GlobalSettingsController {
//    private final Logger logger = LoggerFactory.getLogger("GlobalSettingsLogger");
////    ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
////    GlobalSettingsDOA globalSettingsDOA = (GlobalSettingsDOA) context.getBean("GlobalSettingsDOA");
//    //CommonDAO commonDAO = (CommonDAO) context.getBean("CommonDAO");
//    //UsersDAO usersDAO = (UsersDAO) context.getBean("UsersDAO");
//    TitleModel titleModel = new TitleModel();
//
//    @Autowired
//    private GlobalSettingsRepository globalSettingsDOA;
//
//    @Autowired
//    private CommonRepository commonDAO;
//
//    @Autowired
//    private UsersRepository usersDAO;
//
//    @Autowired
//    private UserManagementService userManagementService;
//
//    /********************************Account Type : Start*************************************/
//    @RequestMapping(value = "/account_type", method = RequestMethod.GET)
//    public String accountTypeIndex(ModelMap model, HttpServletRequest request) {
//        new MenuViewer().setupSideMenu(model, request);
//        QueryMDAccountTypeModel empList = new QueryMDAccountTypeModel();
//        titleModel = new TitleModel("DCRM@@home", "Settings", "Global Settings", "", "Account Type");
//
//        try {
//            Map<String, Object> SearchData = new HashMap<String, Object>();
//            Map<String, Object> whereSearchType = new HashMap<String, Object>();
//            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_acc_type, SearchData, whereSearchType);
//            logger.info(iiQStr);
//            int ii = commonDAO.CommoNumberOfRow(iiQStr);
//
//            String listQStr = QueryBuilder.getWherQueryPagination(Utility.md_acc_type, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
//            Object srslist = commonDAO.CommoGetData(listQStr);
//            logger.info(listQStr);
//
//            List<MDAccountTypeModel> accountclassList = new Gson().fromJson(Utility.ObjectToJson(srslist), new TypeToken<List<MDAccountTypeModel>>() {
//            }.getType());
//            empList = new QueryMDAccountTypeModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), accountclassList);
//        } catch (Exception e) {
//            // System.out.println("Error in GB accountClassIndex: " + e.getMessage());
//            logger.error(e.getMessage());
//        }
//        model.addAttribute("viewDataModel", empList);
//        model.addAttribute("title", titleModel);
//        return "globalsettings/AccountTypeView";
//    }
//
//    @PostMapping(value = "/saveAccountType")
//    public String saveTicketType(MDAccountTypeModel MDAccountTypeModel, @RequestParam(defaultValue = "false") boolean checkbox, RedirectAttributes attributes, HttpServletRequest request) {
//        long current_ts = Utility.getCurrentTimestamp();
//        MDAccountTypeModel.setCREATED_BY(Utility.getUserId(request));
//        MDAccountTypeModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));
//
//        if (checkbox) {
//            MDAccountTypeModel.setACTIVE(1);
//        } else {
//            MDAccountTypeModel.setACTIVE(2);
//        }
//
//        if (MDAccountTypeModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Account Type"));
//            return "redirect:" + "account_type";
//        }
//
//
//        Map<String, Object> searchData = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//        searchData.put("NAME", MDAccountTypeModel.getNAME());
//        whereSearchType.put("NAME", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_acc_type, searchData, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Account Type"));
//            return "redirect:" + "account_type";
//        }
//
//        Map<String, Object> insertData = new HashMap<String, Object>();
//        insertData.put("NAME", MDAccountTypeModel.getNAME());
//        insertData.put("CREATED_BY", Utility.getUserId(request));
//        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
//        insertData.put("CREATED_AT", current_ts);
//        insertData.put("ACTIVE", MDAccountTypeModel.getACTIVE());
//        insertData.put("UPDATED_BY", Utility.getUserId(request));
//        insertData.put("UPDATED_AT", current_ts);
//        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//
//
//        boolean h = commonDAO.CommoInsert(Utility.md_acc_type, insertData, logger);
//        if (h) {
//
//            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "Account Type"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "Account Type"));
//        }
//        return "redirect:" + "account_type";
//    }
//
//    @PostMapping(value = "/UpdateAccountType")
//    public String UpdateTicketType(MDAccountTypeModel MDAccountTypeModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox, HttpServletRequest request) {
//        if (MDAccountTypeModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Account Type"));
//            return "redirect:" + "account_class";
//        }
//
//        if (MDAccountTypeModel.getID() <= 0) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Account Type"));
//            return "redirect:" + "account_class";
//        }
//
//        long current_ts = Utility.getCurrentTimestamp();
//        MDAccountTypeModel.setNAME(MDAccountTypeModel.getNAME());
//        MDAccountTypeModel.setUPDATED_BY(Utility.getUserId(request));
//        MDAccountTypeModel.setUPDATED_AT(current_ts);
//        MDAccountTypeModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
//        if (checkbox) {
//            MDAccountTypeModel.setACTIVE(1);
//        } else {
//            MDAccountTypeModel.setACTIVE(2);
//        }
//
//
//        Map<String, Object> search = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//        search.put("ID!", MDAccountTypeModel.getID());
//        search.put("NAME", MDAccountTypeModel.getNAME());
//
//        whereSearchType.put("ID!", "AND");
//        whereSearchType.put("NAME", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_acc_type, search, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Account Type"));
//            return "redirect:" + "account_class";
//        }
//
//        Map<String, Object> updateData = new HashMap<String, Object>();
//        updateData.put("NAME", MDAccountTypeModel.getNAME());
//        updateData.put("ACTIVE", MDAccountTypeModel.getACTIVE());
//        updateData.put("UPDATED_BY", Utility.getUserId(request));
//        updateData.put("UPDATED_AT", current_ts);
//        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//
//        Map<String, Object> whereData = new HashMap<String, Object>();
//        whereData.put("ID", MDAccountTypeModel.getID());
//
//        boolean h = commonDAO.CommoUpdate(Utility.md_acc_type, updateData, whereData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "Account Type"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "Account Type"));
//        }
//
//        return "redirect:" + "account_type";
//    }
//
//    /********************************Account Type : End*************************************/
//
//    /********************************Account Class : Start*************************************/
//
//    @RequestMapping(value = "/account_class", method = RequestMethod.GET)
//    public String accountClassIndex(ModelMap model, HttpServletRequest request) {
//        new MenuViewer().setupSideMenu(model, request);
//        QueryMDAccountClassModel empList = new QueryMDAccountClassModel();
//        titleModel = new TitleModel("DCRM", "Settings", "Global Settings", "", "Account Class");
//        try {
//            Map<String, Object> SearchData = new HashMap<String, Object>();
//            Map<String, Object> whereSearchType = new HashMap<String, Object>();
//            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_acc_class, new HashMap<String, Object>(), whereSearchType);
//            logger.info(iiQStr);
//            int ii = commonDAO.CommoNumberOfRow(iiQStr);
//
//            String listQStr = QueryBuilder.getWherQueryPagination(Utility.md_acc_class, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
//            Object srslist = commonDAO.CommoGetData(listQStr);
//            logger.info(listQStr);
//
//            List<MDAccountClassModel> accountclassList = new Gson().fromJson(Utility.ObjectToJson(srslist), new TypeToken<List<MDAccountClassModel>>() {
//            }.getType());
//            empList = new QueryMDAccountClassModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), accountclassList);
//        } catch (Exception e) {
//            // System.out.println("Error in GB accountClassIndex: " + e.getMessage());
//            logger.error(e.getMessage());
//        }
//        model.addAttribute("viewDataModel", empList);
//        model.addAttribute("title", titleModel);
//        return "globalsettings/AccountClassView";
//    }
//
//    @PostMapping(value = "/saveAccountClass")
//    public String saveAccountClass(MDAccountClassModel MDAccountClassModel, @RequestParam(defaultValue = "false") boolean checkbox, RedirectAttributes attributes, HttpServletRequest request) {
//        long current_ts = Utility.getCurrentTimestamp();
//        MDAccountClassModel.setCREATED_BY(Utility.getUserId(request));
//        MDAccountClassModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));
//
//        if (checkbox) {
//            MDAccountClassModel.setACTIVE(1);
//        } else {
//            MDAccountClassModel.setACTIVE(2);
//        }
//
//        if (MDAccountClassModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Account Class"));
//            return "redirect:" + "account_class";
//        }
//
//
//        Map<String, Object> searchData = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//        searchData.put("NAME", MDAccountClassModel.getNAME());
//        whereSearchType.put("NAME", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_acc_class, searchData, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Account Class"));
//            return "redirect:" + "account_class";
//        }
//
//        Map<String, Object> insertData = new HashMap<String, Object>();
//        insertData.put("NAME", MDAccountClassModel.getNAME());
//        insertData.put("CREATED_BY", Utility.getUserId(request));
//        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
//        insertData.put("CREATED_AT", current_ts);
//        insertData.put("ACTIVE", MDAccountClassModel.getACTIVE());
//        insertData.put("UPDATED_BY", Utility.getUserId(request));
//        insertData.put("UPDATED_AT", current_ts);
//        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//
//
//        boolean h = commonDAO.CommoInsert(Utility.md_acc_class, insertData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "Account Class"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "Account Class"));
//        }
//        return "redirect:" + "account_class";
//    }
//
//    @PostMapping(value = "/UpdateAccountClass")
//    public String UpdateAccountClass(MDAccountClassModel MDAccountClassModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox, HttpServletRequest request) {
//        if (MDAccountClassModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Account Class"));
//            return "redirect:" + "account_class";
//        }
//
//        if (MDAccountClassModel.getID() <= 0) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Account Class"));
//            return "redirect:" + "account_class";
//        }
//
//        long current_ts = Utility.getCurrentTimestamp();
//        MDAccountClassModel.setNAME(MDAccountClassModel.getNAME());
//        MDAccountClassModel.setUPDATED_BY(Utility.getUserId(request));
//        MDAccountClassModel.setUPDATED_AT(current_ts);
//        MDAccountClassModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
//        if (checkbox) {
//            MDAccountClassModel.setACTIVE(1);
//        } else {
//            MDAccountClassModel.setACTIVE(2);
//        }
//
//
//        Map<String, Object> search = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//        search.put("ID!", MDAccountClassModel.getID());
//        search.put("NAME", MDAccountClassModel.getNAME());
//        whereSearchType.put("ID!", "AND");
//        whereSearchType.put("NAME", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_acc_class, search, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Account Class"));
//            return "redirect:" + "account_class";
//        }
//
//        Map<String, Object> updateData = new HashMap<String, Object>();
//        updateData.put("NAME", MDAccountClassModel.getNAME());
//        updateData.put("ACTIVE", MDAccountClassModel.getACTIVE());
//        updateData.put("UPDATED_BY", Utility.getUserId(request));
//        updateData.put("UPDATED_AT", current_ts);
//        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//
//        Map<String, Object> whereData = new HashMap<String, Object>();
//        whereData.put("ID", MDAccountClassModel.getID());
//
//        boolean h = commonDAO.CommoUpdate(Utility.md_acc_class, updateData, whereData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "Account Class"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "Account Class"));
//        }
//
//        return "redirect:" + "account_class";
//    }
//    /********************************Account Class : End*************************************/
//
//    /********************************Source List : Start*************************************/
//
//    @RequestMapping(value = "/source_list", method = RequestMethod.GET)
//    public String sourceListIndex(ModelMap model, HttpServletRequest request) {
//        new MenuViewer().setupSideMenu(model, request);
//        QueryMDSourceListModel empList = new QueryMDSourceListModel();
//        titleModel = new TitleModel("DCRM", "Settings", "Global Settings", "", "Source");
//        try {
//            Map<String, Object> SearchData = new HashMap<String, Object>();
//            Map<String, Object> whereSearchType = new HashMap<String, Object>();
//            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_src, new HashMap<String, Object>(), whereSearchType);
//            logger.info(iiQStr);
//            int ii = commonDAO.CommoNumberOfRow(iiQStr);
//
//            String listQStr = QueryBuilder.getWherQueryPagination(Utility.md_src, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
//            Object srslist = commonDAO.CommoGetData(listQStr);
//            logger.info(listQStr);
//
//            List<MDSourceListModel> accountclassList = new Gson().fromJson(Utility.ObjectToJson(srslist), new TypeToken<List<MDSourceListModel>>() {
//            }.getType());
//            empList = new QueryMDSourceListModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), accountclassList);
//        } catch (Exception e) {
//            // System.out.println("Error in GB accountClassIndex: " + e.getMessage());
//            logger.error(e.getMessage());
//        }
//        model.addAttribute("viewDataModel", empList);
//        model.addAttribute("title", titleModel);
//        return "globalsettings/SourceListView";
//    }
//
//    @PostMapping(value = "/saveSourceList")
//    public String saveSourceList(MDSourceListModel MDSourceListModel, @RequestParam(defaultValue = "false") boolean checkbox, RedirectAttributes attributes, HttpServletRequest request) {
//        long current_ts = Utility.getCurrentTimestamp();
//        MDSourceListModel.setCREATED_BY(Utility.getUserId(request));
//        MDSourceListModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));
//
//        if (checkbox) {
//            MDSourceListModel.setACTIVE(1);
//        } else {
//            MDSourceListModel.setACTIVE(2);
//        }
//
//        if (MDSourceListModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Source"));
//            return "redirect:" + "source_list";
//        }
//
//
//        Map<String, Object> searchData = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//
//        searchData.put("NAME", MDSourceListModel.getNAME());
//        whereSearchType.put("NAME", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_src, searchData, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Source"));
//            return "redirect:" + "source_list";
//        }
//
//        Map<String, Object> insertData = new HashMap<String, Object>();
//        insertData.put("NAME", MDSourceListModel.getNAME());
//        insertData.put("CREATED_BY", Utility.getUserId(request));
//        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
//        insertData.put("CREATED_AT", current_ts);
//        insertData.put("ACTIVE", MDSourceListModel.getACTIVE());
//        insertData.put("UPDATED_BY", Utility.getUserId(request));
//        insertData.put("UPDATED_AT", current_ts);
//        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//
//
//        boolean h = commonDAO.CommoInsert(Utility.md_src, insertData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "Source"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "Source"));
//        }
//
//        return "redirect:" + "source_list";
//    }
//
//
//    @PostMapping(value = "/UpdateSourceList")
//    public String UpdateSourceList(MDSourceListModel MDSourceListModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox, HttpServletRequest request) {
//        if (MDSourceListModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Source"));
//            return "redirect:" + "source_list";
//        }
//
//        if (MDSourceListModel.getID() <= 0) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Source"));
//            return "redirect:" + "source_list";
//        }
//
//        long current_ts = Utility.getCurrentTimestamp();
//        MDSourceListModel.setNAME(MDSourceListModel.getNAME());
//        MDSourceListModel.setUPDATED_BY(Utility.getUserId(request));
//        MDSourceListModel.setUPDATED_AT(current_ts);
//        MDSourceListModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
//        if (checkbox) {
//            MDSourceListModel.setACTIVE(1);
//        } else {
//            MDSourceListModel.setACTIVE(2);
//        }
//
//
//        Map<String, Object> search = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//        search.put("ID!", MDSourceListModel.getID());
//        search.put("NAME", MDSourceListModel.getNAME());
//
//        whereSearchType.put("ID!", "AND");
//        whereSearchType.put("NAME", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_src, search, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Source"));
//            return "redirect:" + "source_list";
//        }
//
//        Map<String, Object> updateData = new HashMap<String, Object>();
//        updateData.put("NAME", MDSourceListModel.getNAME());
//        updateData.put("ACTIVE", MDSourceListModel.getACTIVE());
//        updateData.put("UPDATED_BY", Utility.getUserId(request));
//        updateData.put("UPDATED_AT", current_ts);
//        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//
//        Map<String, Object> whereData = new HashMap<String, Object>();
//        whereData.put("ID", MDSourceListModel.getID());
//
//        boolean h = commonDAO.CommoUpdate(Utility.md_src, updateData, whereData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "Source"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "Source"));
//        }
//
//
//        /* update source location : start */
//
//        Map<String, Object> updateSrcData = new HashMap<String, Object>();
//        updateSrcData.put("SRC_NAME", MDSourceListModel.getNAME());
//        updateSrcData.put("ACTIVE", MDSourceListModel.getACTIVE());
//        updateSrcData.put("UPDATED_BY", Utility.getUserId(request));
//        updateSrcData.put("UPDATED_AT", current_ts);
//        updateSrcData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//
//        Map<String, Object> whereSrcData = new HashMap<String, Object>();
//        whereSrcData.put("SRC_ID", MDSourceListModel.getID());
//
//        boolean src_h = commonDAO.CommoUpdate(Utility.md_src_location, updateSrcData, whereSrcData, logger);
//
//        /* update source location : end */
//
//
//        return "redirect:" + "source_list";
//    }
//
//    /********************************Source List : End*************************************/
//
//    /******************************** Source Location : Start*************************************/
//
//    @RequestMapping(value = "/source_location", method = RequestMethod.GET)
//    public String sourceLocationIndex(ModelMap model, HttpServletRequest request) {
//        new MenuViewer().setupSideMenu(model, request);
//        QueryMDSourceLocationModel empList = new QueryMDSourceLocationModel();
//        List<MDSourceLocationModel> sourceList = new ArrayList<MDSourceLocationModel>();
//        titleModel = new TitleModel("DCRM", "Settings", "Global Settings", "", "Source Location");
//        try {
//            Map<String, Object> SearchData = new HashMap<String, Object>();
//            Map<String, Object> SourceData = new HashMap<String, Object>();
//            Map<String, Object> whereSearchType = new HashMap<String, Object>();
//
//            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_src_location, new HashMap<String, Object>(), whereSearchType);
//            int ii = commonDAO.CommoNumberOfRow(iiQStr);
//            logger.info(iiQStr);
//
//            String listQStr = QueryBuilder.getWherQueryPagination(Utility.md_src_location, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
//            logger.info(listQStr);
//            Object srslist = commonDAO.CommoGetData(listQStr);
//            List<MDSourceLocationModel> resList = new Gson().fromJson(Utility.ObjectToJson(srslist), new TypeToken<List<MDSourceLocationModel>>() {
//            }.getType());
//            empList = new QueryMDSourceLocationModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), resList);
//
//            Object srclist = globalSettingsDOA.getActiveSourceList();
//            sourceList = new Gson().fromJson(Utility.ObjectToJson(srclist), new TypeToken<List<MDSourceListModel>>() {
//            }.getType());
//        } catch (Exception e) {
//            //System.out.println("Error in GB sourceListIndex: " + e.getMessage());
//            logger.error(e.getMessage());
//        }
//        model.addAttribute("SourceList", sourceList);
//        model.addAttribute("viewDataModel", empList);
//        model.addAttribute("title", titleModel);
//        return "globalsettings/SourceLocationView";
//    }
//
//    @PostMapping(value = "/saveSourceLocation")
//    public String saveSourceLocation(MDSourceLocationModel MDSourceLocationModel, @RequestParam(defaultValue = "false") boolean checkbox, RedirectAttributes attributes, HttpServletRequest request) {
//        long current_ts = Utility.getCurrentTimestamp();
//        MDSourceLocationModel.setCREATED_BY(Utility.getUserId(request));
//        MDSourceLocationModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));
//
//        if (checkbox) {
//            MDSourceLocationModel.setACTIVE(1);
//        } else {
//            MDSourceLocationModel.setACTIVE(2);
//        }
//
//        if (MDSourceLocationModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Source Location"));
//            return "redirect:" + "source_location";
//        }
//        List<String> selectedSource = Arrays.asList(MDSourceLocationModel.getSRC_NAME().split("/"));
//        MDSourceLocationModel.setSRC_ID(Long.parseLong(selectedSource.get(0)));
//        MDSourceLocationModel.setSRC_NAME(selectedSource.get(1));
//
//        Map<String, Object> searchData = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//
//        searchData.put("NAME", MDSourceLocationModel.getNAME());
//        whereSearchType.put("NAME", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_src_location, searchData, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Source Location"));
//            return "redirect:" + "source_location";
//        }
//
//        Map<String, Object> insertData = new HashMap<String, Object>();
//        insertData.put("NAME", MDSourceLocationModel.getNAME());
//        insertData.put("CREATED_BY", Utility.getUserId(request));
//        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
//        insertData.put("CREATED_AT", current_ts);
//        insertData.put("ACTIVE", MDSourceLocationModel.getACTIVE());
//        insertData.put("UPDATED_BY", Utility.getUserId(request));
//        insertData.put("UPDATED_AT", current_ts);
//        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//        insertData.put("SRC_ID", MDSourceLocationModel.getSRC_ID());
//        insertData.put("SRC_NAME", MDSourceLocationModel.getSRC_NAME());
//
//        boolean h = commonDAO.CommoInsert(Utility.md_src_location, insertData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "Source Location"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "Source Location"));
//        }
//        return "redirect:" + "source_location";
//    }
//
//    @PostMapping(value = "/updateSourceLocation")
//    public String UpdateSourceLocation(MDSourceLocationModel MDSourceLocationModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox, HttpServletRequest request) {
//        if (MDSourceLocationModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Source Location"));
//            return "redirect:" + "source_location";
//        }
//
//        if (MDSourceLocationModel.getID() <= 0) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Source Location"));
//            return "redirect:" + "source_location";
//        }
//
//        long current_ts = Utility.getCurrentTimestamp();
//        MDSourceLocationModel.setNAME(MDSourceLocationModel.getNAME());
//        MDSourceLocationModel.setUPDATED_BY(Utility.getUserId(request));
//        MDSourceLocationModel.setUPDATED_AT(current_ts);
//        MDSourceLocationModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
//        if (checkbox) {
//            MDSourceLocationModel.setACTIVE(1);
//        } else {
//            MDSourceLocationModel.setACTIVE(2);
//        }
//        List<String> selectedSource = Arrays.asList(MDSourceLocationModel.getSRC_NAME().split("/"));
//        MDSourceLocationModel.setSRC_ID(Long.parseLong(selectedSource.get(0)));
//        MDSourceLocationModel.setSRC_NAME(selectedSource.get(1));
//
//
//        Map<String, Object> search = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//
//        search.put("ID!", MDSourceLocationModel.getID());
//        search.put("NAME", MDSourceLocationModel.getNAME());
//
//        whereSearchType.put("ID!", "AND");
//        whereSearchType.put("NAME", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_src_location, search, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Source Location"));
//            return "redirect:" + "source_location";
//        }
//
//        Map<String, Object> updateData = new HashMap<String, Object>();
//        updateData.put("NAME", MDSourceLocationModel.getNAME());
//        updateData.put("ACTIVE", MDSourceLocationModel.getACTIVE());
//        updateData.put("UPDATED_BY", Utility.getUserId(request));
//        updateData.put("UPDATED_AT", current_ts);
//        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//        updateData.put("SRC_ID", MDSourceLocationModel.getSRC_ID());
//        updateData.put("SRC_NAME", MDSourceLocationModel.getSRC_NAME());
//
//        Map<String, Object> whereData = new HashMap<String, Object>();
//        whereData.put("ID", MDSourceLocationModel.getID());
//
//        boolean h = commonDAO.CommoUpdate(Utility.md_src_location, updateData, whereData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "Source Location"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "Source Location"));
//        }
//
//        return "redirect:" + "source_location";
//    }
//
//    /******************************** Source Location : End*************************************/
//
//    /********************************* User Group: Start **************************************** */
//    @RequestMapping(value = "/user_group", method = RequestMethod.GET)
//    public String userGroupIndex(ModelMap model, HttpServletRequest request) {
//        new MenuViewer().setupSideMenu(model, request);
//        QueryMDUserGroupModel empList = new QueryMDUserGroupModel();
//        List<MDUserGroupModel> parentList = new ArrayList<MDUserGroupModel>();
//        Map<Integer, String> pdic = new HashMap<Integer, String>();
//        titleModel = new TitleModel("DCRM", "Settings", "Global Settings", "", "User Group");
//        try {
//            Map<String, Object> SearchData = new HashMap<String, Object>();
//            Map<String, Object> whereSearchType = new HashMap<String, Object>();
//            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_user_group, new HashMap<String, Object>(), whereSearchType);
//            logger.info(iiQStr);
//            int ii = commonDAO.CommoNumberOfRow(iiQStr);
//
//            String listQStr = QueryBuilder.getWherQueryPagination(Utility.md_user_group, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
//            Object srslist = commonDAO.CommoGetData(listQStr);
//            logger.info(listQStr);
//
//            List<MDUserGroupModel> accountclassList = new Gson().fromJson(Utility.ObjectToJson(srslist), new TypeToken<List<MDUserGroupModel>>() {
//            }.getType());
//            empList = new QueryMDUserGroupModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), accountclassList);
//            parentList = globalSettingsDOA.getActiveUserGroup();
//
//            for (MDUserGroupModel item : parentList
//            ) {
//                pdic.put(item.getID(), item.getNAME());
//            }
//            //parentList = new Gson().fromJson(Utility.ObjectToJson(reslist), new TypeToken<List<MDUserGroupModel>>() {
//            //}.getType());
//        } catch (Exception e) {
//            // System.out.println("Error in GB accountClassIndex: " + e.getMessage());
//            logger.error(e.getMessage());
//        }
//        model.addAttribute("viewDataModel", empList);
//        model.addAttribute("parentList", parentList);
//        model.addAttribute("pList", pdic);
//        model.addAttribute("title", titleModel);
//        return "globalsettings/UserGroupView";
//    }
//
//    @PostMapping(value = "/saveUserGroup")
//    public String saveUserGroup(MDUserGroupModel MDUserGroupModel, @RequestParam(defaultValue = "false") boolean checkbox, @RequestParam(defaultValue = "false") boolean isParent, RedirectAttributes attributes, HttpServletRequest request) {
//        long current_ts = Utility.getCurrentTimestamp();
//        MDUserGroupModel.setCREATED_BY(Utility.getUserId(request));
//        MDUserGroupModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));
//
//        if (checkbox) {
//            MDUserGroupModel.setACTIVE(1);
//        } else {
//            MDUserGroupModel.setACTIVE(2);
//        }
//
//        if (MDUserGroupModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Source Location"));
//            return "redirect:" + "user_group";
//        }
//
//        Map<String, Object> searchData = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//        searchData.put("NAME", MDUserGroupModel.getNAME());
//        whereSearchType.put("NAME", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_user_group, searchData, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "User Group"));
//            return "redirect:" + "user_group";
//        }
//
//        Map<String, Object> insertData = new HashMap<String, Object>();
//        insertData.put("NAME", MDUserGroupModel.getNAME());
//        insertData.put("CREATED_BY", Utility.getUserId(request));
//        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
//        insertData.put("CREATED_AT", current_ts);
//        insertData.put("ACTIVE", MDUserGroupModel.getACTIVE());
//        insertData.put("UPDATED_BY", Utility.getUserId(request));
//        insertData.put("UPDATED_AT", current_ts);
//        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//        insertData.put("GROUP_EMAIL", MDUserGroupModel.getGROUP_EMAIL());
//        if (isParent) {
//            insertData.put("PARENT_ID", MDUserGroupModel.getPARENT_ID());
//        } else {
//            insertData.put("PARENT_ID", 0);
//        }
//
//
//        boolean h = commonDAO.CommoInsert(Utility.md_user_group, insertData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "User Group"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "User Group"));
//        }
//        return "redirect:" + "user_group";
//    }
//
//    @PostMapping(value = "/updateUserGroup")
//    public String updateUserGroup(MDUserGroupModel MDUserGroupModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox, @RequestParam(defaultValue = "false") boolean isParent, HttpServletRequest request) {
//        if (MDUserGroupModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "User Group"));
//            return "redirect:" + "user_group";
//        }
//
//        if (MDUserGroupModel.getID() <= 0) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "User Group"));
//            return "redirect:" + "user_group";
//        }
//
//        long current_ts = Utility.getCurrentTimestamp();
//        MDUserGroupModel.setNAME(MDUserGroupModel.getNAME());
//        MDUserGroupModel.setUPDATED_BY(Utility.getUserId(request));
//        MDUserGroupModel.setUPDATED_AT(current_ts);
//        MDUserGroupModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
//        if (checkbox) {
//            MDUserGroupModel.setACTIVE(1);
//        } else {
//            MDUserGroupModel.setACTIVE(2);
//        }
//        Map<String, Object> search = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//
//        search.put("ID!", MDUserGroupModel.getID());
//        search.put("NAME", MDUserGroupModel.getNAME());
//
//        whereSearchType.put("ID!", "AND");
//        whereSearchType.put("NAME", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_user_group, search, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "User Group"));
//            return "redirect:" + "user_group";
//        }
//
//        Map<String, Object> updateData = new HashMap<String, Object>();
//        updateData.put("NAME", MDUserGroupModel.getNAME());
//        updateData.put("ACTIVE", MDUserGroupModel.getACTIVE());
//        updateData.put("UPDATED_BY", Utility.getUserId(request));
//        updateData.put("UPDATED_AT", current_ts);
//        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//        if (isParent) {
//            updateData.put("PARENT_ID", MDUserGroupModel.getPARENT_ID());
//        } else {
//            updateData.put("PARENT_ID", 0);
//        }
//
//        Map<String, Object> whereData = new HashMap<String, Object>();
//
//        whereData.put("ID", MDUserGroupModel.getID());
//
//        boolean h = commonDAO.CommoUpdate(Utility.md_user_group, updateData, whereData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "User Group"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "User Group"));
//        }
//
//        return "redirect:" + "user_group";
//    }
//
//    /********************************* User Group: End **************************************** */
//
//
//    /********************************* User Management: Start **************************************** */
//    @RequestMapping(value = "/user", method = RequestMethod.GET)
//    public String usersIndex(ModelMap model, HttpServletRequest request) {
//        new MenuViewer().setupSideMenu(model, request);
//        QueryMDUserModel userList = new QueryMDUserModel();
//        List<MDSourceListModel> sourceList = new ArrayList<>();
//        List<MDUserPosition> positionList = new ArrayList<>();
//        List<MDUserGroupModel> groupList = new ArrayList<>();
//        List<MDSourceLocationModel> sourceLocationList = new ArrayList<>();
//        List<MDResponsibilityModel> userResponsibilityList = new ArrayList<>();
//
//        titleModel = new TitleModel("DCRM", "Settings", "Global Settings", "", "User");
//
//        try {
//            Map<String, Object> SearchData = new HashMap<String, Object>();
//            Map<String, Object> whereSearchType = new HashMap<String, Object>();
//            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_user, new HashMap<String, Object>(), whereSearchType);
//            logger.info(iiQStr);
//            int ii = commonDAO.CommoNumberOfRow(iiQStr);
//
//            String listQStr = QueryBuilder.getWherQueryPagination(Utility.md_user, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
//            Object objUserlist = commonDAO.CommoGetData(listQStr);
//            logger.info(listQStr);
//
//            List<MDUserModel> users = new Gson().fromJson(Utility.ObjectToJson(objUserlist), new TypeToken<List<MDUserModel>>() {
//            }.getType());
//            userList = new QueryMDUserModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), users);
//
//            SearchData.clear();
//            whereSearchType.clear();
//            SearchData.put("ACTIVE", "1");
//            whereSearchType.put("ACTIVE", "AND");
//            String sourceListQuery = QueryBuilder.getSelectWhereQuery(Utility.md_src, SearchData, whereSearchType);
//            Object sourceListObject = commonDAO.CommoGetData(sourceListQuery);
//            sourceList = new Gson().fromJson(Utility.ObjectToJson(sourceListObject), new TypeToken<List<MDSourceListModel>>() {
//            }.getType());
//
//            SearchData.clear();
//            whereSearchType.clear();
//            SearchData.put("ACTIVE", "1");
//            whereSearchType.put("ACTIVE", "AND");
//            String positionListQuery = QueryBuilder.getSelectWhereQuery(Utility.md_user_position, SearchData, whereSearchType);
//            Object positionListObject = commonDAO.CommoGetData(positionListQuery);
//            positionList = new Gson().fromJson(Utility.ObjectToJson(positionListObject), new TypeToken<List<MDUserPosition>>() {
//            }.getType());
//
//            SearchData.clear();
//            whereSearchType.clear();
//            SearchData.put("ACTIVE", "1");
//            whereSearchType.put("ACTIVE", "AND");
//            String groupListQuery = QueryBuilder.getSelectWhereQuery(Utility.md_user_group, SearchData, whereSearchType);
//            Object groupListObject = commonDAO.CommoGetData(groupListQuery);
//            groupList = new Gson().fromJson(Utility.ObjectToJson(groupListObject), new TypeToken<List<MDUserGroupModel>>() {
//            }.getType());
//
//            SearchData.clear();
//            whereSearchType.clear();
//            SearchData.put("ACTIVE", "1");
//            whereSearchType.put("ACTIVE", "AND");
//            String sourceLocationListQuery = QueryBuilder.getSelectWhereQuery(Utility.md_src_location, SearchData, whereSearchType);
//            Object sourceLocationListObject = commonDAO.CommoGetData(sourceLocationListQuery);
//            sourceLocationList = new Gson().fromJson(Utility.ObjectToJson(sourceLocationListObject), new TypeToken<List<MDSourceLocationModel>>() {
//            }.getType());
//
//            SearchData.clear();
//            whereSearchType.clear();
//            SearchData.put("ACTIVE", "1");
//            whereSearchType.put("ACTIVE", "AND");
//            String userResponsibilityListQuery = QueryBuilder.getSelectWhereQuery(Utility.md_responsibility, SearchData, whereSearchType);
//            Object userResponsibilityListObject = commonDAO.CommoGetData(userResponsibilityListQuery);
//            userResponsibilityList = new Gson().fromJson(Utility.ObjectToJson(userResponsibilityListObject), new TypeToken<List<MDResponsibilityModel>>() {
//            }.getType());
//
//        } catch (Exception e) {
//            logger.error(e.getMessage());
//        }
//
//
//        model.addAttribute("viewDataModel", userList);
//        model.addAttribute("title", titleModel);
//        model.addAttribute("nameTitles", Utility.getNameTitles());
//        model.addAttribute("sourceList", sourceList);
//        model.addAttribute("positionList", positionList);
//        model.addAttribute("groupList", groupList);
//        model.addAttribute("sourceLocationList", sourceLocationList);
//        model.addAttribute("userResponsibilityList", userResponsibilityList);
//        return "globalsettings/User";
//    }
//
//    //------------------- bulk add and deactivate user----------------------//
//    @RequestMapping(value = "/bulkUpload", method = RequestMethod.POST)
//    public String DoCreationBulkController(@RequestParam("file") MultipartFile file, PostData DATA,
//                                           RedirectAttributes attributes,
//                                           HttpServletRequest Request) {
//        String type = DATA.getType();
//        if (file.isEmpty() || type.equals("0")) {
//            attributes.addFlashAttribute("error", "Please select the type and a file to upload");
//            return "redirect:user";
//        }
//
//        String bulkUpload = userManagementService.bulkUpload(type, file, Request);
//        if(bulkUpload.equals("success")){
//            attributes.addFlashAttribute("success", "File upload successful");
//        }else {
//            attributes.addFlashAttribute("error", bulkUpload);
//        };
//
//        return "redirect:user";
//    }
//
//    /********************************* User Management: end **************************************** */
//
//
//    /********************************* Menu : Start**************************************** */
//    @RequestMapping(value = "/menu", method = RequestMethod.GET)
//    public String menuIndex(ModelMap model, HttpServletRequest request) {
//        new MenuViewer().setupSideMenu(model, request);
//        QueryMDMenuModel empList = new QueryMDMenuModel();
//        List<MDMenuModel> parentList = new ArrayList<MDMenuModel>();
//        Map<Integer, String> pdic = new HashMap<Integer, String>();
//        titleModel = new TitleModel("DCRM", "Settings", "Global Settings", "", "Menu");
//        try {
//            Map<String, Object> SearchData = new HashMap<String, Object>();
//            Map<String, Object> whereSearchType = new HashMap<String, Object>();
//            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_menu, new HashMap<String, Object>(), whereSearchType);
//            logger.info(iiQStr);
//            int ii = commonDAO.CommoNumberOfRow(iiQStr);
//
//            String listQStr = QueryBuilder.getWherQueryPagination(Utility.md_menu, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
//            Object srslist = commonDAO.CommoGetData(listQStr);
//            logger.info(listQStr);
//
//            List<MDMenuModel> accountclassList = new Gson().fromJson(Utility.ObjectToJson(srslist), new TypeToken<List<MDMenuModel>>() {
//            }.getType());
//            empList = new QueryMDMenuModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), accountclassList);
//            parentList = globalSettingsDOA.getActiveMenu();
//
//            for (MDMenuModel item : parentList
//            ) {
//                pdic.put(item.getID(), item.getNAME());
//            }
//            //parentList = new Gson().fromJson(Utility.ObjectToJson(reslist), new TypeToken<List<MDUserGroupModel>>() {
//            //}.getType());
//        } catch (Exception e) {
//            // System.out.println("Error in GB accountClassIndex: " + e.getMessage());
//            logger.error(e.getMessage());
//        }
//        model.addAttribute("viewDataModel", empList);
//        model.addAttribute("parentList", parentList);
//        model.addAttribute("pList", pdic);
//        model.addAttribute("title", titleModel);
//        return "globalsettings/MenuView";
//    }
//
//    @PostMapping(value = "/saveMenu")
//    public String saveMenu(MDMenuModel MDMenuModel, @RequestParam(defaultValue = "false") boolean checkbox, @RequestParam(defaultValue = "false") boolean has_parent, @RequestParam(defaultValue = "false") boolean is_parent, @RequestParam(defaultValue = "false") boolean hasLink, @RequestParam(defaultValue = "false") boolean api_parent, @RequestParam(defaultValue = "false") boolean IS_SIDEBAR_MENU, RedirectAttributes attributes, HttpServletRequest request) {
//        long current_ts = Utility.getCurrentTimestamp();
//        MDMenuModel.setCREATED_BY(Utility.getUserId(request));
//        MDMenuModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));
//
//
//        if (MDMenuModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Menu"));
//            return "redirect:" + "menu";
//        }
//
//        Map<String, Object> searchData = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//        searchData.put("NAME", MDMenuModel.getNAME());
//        whereSearchType.put("NAME", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_menu, searchData, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Menu"));
//            return "redirect:" + "menu";
//        }
//
//        Map<String, Object> insertData = new HashMap<String, Object>();
//        insertData.put("NAME", MDMenuModel.getNAME());
//        insertData.put("MENU_URL", MDMenuModel.getMENU_URL());
//        insertData.put("DESCRIPTION", MDMenuModel.getDESCRIPTION());
//        insertData.put("ICON_CLASS", MDMenuModel.getICON_CLASS());
//        insertData.put("API_PARENT", api_parent ? 1 : 0);
//        insertData.put("IS_PARENT", is_parent ? 1 : 0);
//        insertData.put("HAS_LINK", hasLink ? 1 : 0);
//        insertData.put("CHECK_FULL_PATH", 1);
//        insertData.put("PRIORITY", MDMenuModel.getPRIORITY());
//        insertData.put("IS_SIDEBAR_MENU", IS_SIDEBAR_MENU ? 1 : 0);
//        insertData.put("CREATED_BY", Utility.getUserId(request));
//        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
//        insertData.put("CREATED_AT", current_ts);
//        insertData.put("ACTIVE", checkbox ? 1 : 2);
//        insertData.put("UPDATED_BY", Utility.getUserId(request));
//        insertData.put("UPDATED_AT", current_ts);
//        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//        if (has_parent) {
//            insertData.put("PARENT_ID", MDMenuModel.getPARENT_ID());
//        } else {
//            insertData.put("PARENT_ID", 0);
//        }
//
//        boolean h = commonDAO.CommoInsert(Utility.md_menu, insertData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "Menu"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "Menu"));
//        }
//        return "redirect:" + "menu";
//    }
//
//    @PostMapping(value = "/updateMenu")
//    public String updateMenu(MDMenuModel MDMenuModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox, @RequestParam(defaultValue = "false") boolean has_parent, @RequestParam(defaultValue = "false") boolean is_parent, @RequestParam(defaultValue = "false") boolean hasLink, @RequestParam(defaultValue = "false") boolean api_parent, @RequestParam(defaultValue = "false") boolean IS_SIDEBAR_MENU, HttpServletRequest request) {
//        if (MDMenuModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Menu"));
//            return "redirect:" + "menu";
//        }
//
//        if (MDMenuModel.getID() <= 0) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Menu"));
//            return "redirect:" + "menu";
//        }
//
//        long current_ts = Utility.getCurrentTimestamp();
//        MDMenuModel.setNAME(MDMenuModel.getNAME());
//        MDMenuModel.setUPDATED_BY(Utility.getUserId(request));
//        MDMenuModel.setUPDATED_AT(current_ts);
//        MDMenuModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
//
//        Map<String, Object> search = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//
//        search.put("ID!", MDMenuModel.getID());
//        search.put("NAME", MDMenuModel.getNAME());
//
//        whereSearchType.put("ID!", "AND");
//        whereSearchType.put("NAME", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_menu, search, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Menu"));
//            return "redirect:" + "menu";
//        }
//
//        Map<String, Object> updateData = new HashMap<String, Object>();
//        updateData.put("NAME", MDMenuModel.getNAME());
//        updateData.put("MENU_URL", MDMenuModel.getMENU_URL());
//        updateData.put("DESCRIPTION", MDMenuModel.getDESCRIPTION());
//        updateData.put("ICON_CLASS", MDMenuModel.getICON_CLASS());
//        updateData.put("API_PARENT", api_parent? 1 : 0);
//        updateData.put("IS_PARENT", is_parent? 1 : 0);
//        updateData.put("HAS_LINK", hasLink ? 1 : 0);
//        updateData.put("CHECK_FULL_PATH", 1);
//        updateData.put("PRIORITY", MDMenuModel.getPRIORITY());
//        updateData.put("IS_SIDEBAR_MENU", IS_SIDEBAR_MENU ? 1 : 0);
//        updateData.put("ACTIVE", checkbox ? 1 : 2);
//        updateData.put("UPDATED_BY", Utility.getUserId(request));
//        updateData.put("UPDATED_AT", current_ts);
//        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//        if (has_parent) {
//            updateData.put("PARENT_ID", MDMenuModel.getPARENT_ID());
//        } else {
//            updateData.put("PARENT_ID", 0);
//        }
//
//        Map<String, Object> whereData = new HashMap<String, Object>();
//
//        whereData.put("ID", MDMenuModel.getID());
//
//        boolean h = commonDAO.CommoUpdate(Utility.md_menu, updateData, whereData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "Menu"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "Menu"));
//        }
//
//        return "redirect:" + "menu";
//    }
//
//
//    /********************************* Menu : End**************************************** */
//
//    /********************************* Responsibility : Start**************************************** */
//    @RequestMapping(value = "/responsibility", method = RequestMethod.GET)
//    public String responsibilityIndex(ModelMap model, HttpServletRequest request) {
//        new MenuViewer().setupSideMenu(model, request);
//        QueryMDResponsibilityModel empList = new QueryMDResponsibilityModel();
//        List<MDResponsibilityModel> parentList = new ArrayList<MDResponsibilityModel>();
//        Map<Integer, String> pdic = new HashMap<Integer, String>();
//        titleModel = new TitleModel("DCRM", "Settings", "Global Settings", "", "Responsibility");
//        try {
//            Map<String, Object> SearchData = new HashMap<String, Object>();
//            Map<String, Object> whereSearchType = new HashMap<String, Object>();
//            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_responsibility, new HashMap<String, Object>(), whereSearchType);
//            logger.info(iiQStr);
//            int ii = commonDAO.CommoNumberOfRow(iiQStr);
//
//            String listQStr = QueryBuilder.getWherQueryPagination(Utility.md_responsibility, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
//            Object srslist = commonDAO.CommoGetData(listQStr);
//            logger.info(listQStr);
//
//            List<MDResponsibilityModel> accountclassList = new Gson().fromJson(Utility.ObjectToJson(srslist), new TypeToken<List<MDMenuModel>>() {
//            }.getType());
//            empList = new QueryMDResponsibilityModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), accountclassList);
//
//        } catch (Exception e) {
//            // System.out.println("Error in GB accountClassIndex: " + e.getMessage());
//            logger.error(e.getMessage());
//        }
//        model.addAttribute("viewDataModel", empList);
//        model.addAttribute("title", titleModel);
//        return "globalsettings/ResponsibilityView";
//    }
//
//    @PostMapping(value = "/saveResponsibility")
//    public String saveResponsibility(MDResponsibilityModel MDResponsibilityModel, @RequestParam(defaultValue = "false") boolean checkbox, RedirectAttributes attributes, HttpServletRequest request) {
//        long current_ts = Utility.getCurrentTimestamp();
//        MDResponsibilityModel.setCREATED_BY(Utility.getUserId(request));
//        MDResponsibilityModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));
//
//        if (checkbox) {
//            MDResponsibilityModel.setACTIVE(1);
//        } else {
//            MDResponsibilityModel.setACTIVE(2);
//        }
//
//        if (MDResponsibilityModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Responsibility"));
//            return "redirect:" + "responsibility";
//        }
//
//
//        Map<String, Object> searchData = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//
//        searchData.put("NAME", MDResponsibilityModel.getNAME());
//        whereSearchType.put("NAME", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_responsibility, searchData, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Responsibility"));
//            return "redirect:" + "responsibility";
//        }
//
//        Map<String, Object> insertData = new HashMap<String, Object>();
//        insertData.put("NAME", MDResponsibilityModel.getNAME());
//        insertData.put("DESCRIPTION", MDResponsibilityModel.getDESCRIPTION());
//        insertData.put("CREATED_BY", Utility.getUserId(request));
//        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
//        insertData.put("CREATED_AT", current_ts);
//        insertData.put("ACTIVE", MDResponsibilityModel.getACTIVE());
//        insertData.put("UPDATED_BY", Utility.getUserId(request));
//        insertData.put("UPDATED_AT", current_ts);
//        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//
//
//        boolean h = commonDAO.CommoInsert(Utility.md_responsibility, insertData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "Responsibility"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "Responsibility"));
//        }
//
//        return "redirect:" + "responsibility";
//    }
//
//    @PostMapping(value = "/UpdateResponsibility")
//    public String UpdateResponsibility(MDResponsibilityModel MDResponsibilityModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox, HttpServletRequest request) {
//        if (MDResponsibilityModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Responsibility"));
//            return "redirect:" + "responsibility";
//        }
//
//        if (MDResponsibilityModel.getID() <= 0) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Responsibility"));
//            return "redirect:" + "responsibility";
//        }
//
//        long current_ts = Utility.getCurrentTimestamp();
//        MDResponsibilityModel.setNAME(MDResponsibilityModel.getNAME());
//        MDResponsibilityModel.setUPDATED_BY(Utility.getUserId(request));
//        MDResponsibilityModel.setUPDATED_AT(current_ts);
//        MDResponsibilityModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
//        if (checkbox) {
//            MDResponsibilityModel.setACTIVE(1);
//        } else {
//            MDResponsibilityModel.setACTIVE(2);
//        }
//
//
//        Map<String, Object> search = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//        search.put("ID!", MDResponsibilityModel.getID());
//        search.put("NAME", MDResponsibilityModel.getNAME());
//
//        whereSearchType.put("ID!", "AND");
//        whereSearchType.put("NAME", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_responsibility, search, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Responsibility"));
//            return "redirect:" + "responsibility";
//        }
//
//        Map<String, Object> updateData = new HashMap<String, Object>();
//        updateData.put("NAME", MDResponsibilityModel.getNAME());
//        updateData.put("DESCRIPTION", MDResponsibilityModel.getDESCRIPTION());
//        updateData.put("ACTIVE", MDResponsibilityModel.getACTIVE());
//        updateData.put("UPDATED_BY", Utility.getUserId(request));
//        updateData.put("UPDATED_AT", current_ts);
//        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//
//        Map<String, Object> whereData = new HashMap<String, Object>();
//        whereData.put("ID", MDResponsibilityModel.getID());
//
//        boolean h = commonDAO.CommoUpdate(Utility.md_responsibility, updateData, whereData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "Responsibility"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "Responsibility"));
//        }
//
//
//        return "redirect:" + "responsibility";
//    }
//
//
//    /********************************* Responsibility : End**************************************** */
//
//    /********************************* Division : Start**************************************** */
//    @RequestMapping(value = "/division", method = RequestMethod.GET)
//    public String divisionIndex(ModelMap model, HttpServletRequest request) {
//        new MenuViewer().setupSideMenu(model, request);
//        QueryMDDivisionModel empList = new QueryMDDivisionModel();
//        List<MDDivisionModel> parentList = new ArrayList<MDDivisionModel>();
//        Map<Integer, String> pdic = new HashMap<Integer, String>();
//        titleModel = new TitleModel("DCRM", "Settings", "Global Settings", "", "Division");
//        try {
//            Map<String, Object> SearchData = new HashMap<String, Object>();
//            Map<String, Object> whereSearchType = new HashMap<String, Object>();
//            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_division, new HashMap<String, Object>(), whereSearchType);
//            logger.info(iiQStr);
//            int ii = commonDAO.CommoNumberOfRow(iiQStr);
//
//            String listQStr = QueryBuilder.getWherQueryPagination(Utility.md_division, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
//            Object srslist = commonDAO.CommoGetData(listQStr);
//            logger.info(listQStr);
//
//            List<MDDivisionModel> accountclassList = new Gson().fromJson(Utility.ObjectToJson(srslist), new TypeToken<List<MDDivisionModel>>() {
//            }.getType());
//            empList = new QueryMDDivisionModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), accountclassList);
//
//        } catch (Exception e) {
//            // System.out.println("Error in GB accountClassIndex: " + e.getMessage());
//            logger.error(e.getMessage());
//        }
//        model.addAttribute("viewDataModel", empList);
//        model.addAttribute("title", titleModel);
//        return "globalsettings/DivisionView";
//    }
//
//    @PostMapping(value = "/saveDivision")
//    public String saveDivision(MDDivisionModel MDDivisionModel, @RequestParam(defaultValue = "false") boolean checkbox, RedirectAttributes attributes, HttpServletRequest request) {
//        long current_ts = Utility.getCurrentTimestamp();
//        MDDivisionModel.setCREATED_BY(Utility.getUserId(request));
//        MDDivisionModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));
//
//        if (checkbox) {
//            MDDivisionModel.setACTIVE(1);
//        } else {
//            MDDivisionModel.setACTIVE(2);
//        }
//
//        if (MDDivisionModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Division"));
//            return "redirect:" + "division";
//        }
//
//
//        Map<String, Object> searchData = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//
//        searchData.put("NAME", MDDivisionModel.getNAME());
//        whereSearchType.put("NAME", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_division, searchData, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Division"));
//            return "redirect:" + "division";
//        }
//
//        Map<String, Object> insertData = new HashMap<String, Object>();
//        insertData.put("NAME", MDDivisionModel.getNAME());
//        insertData.put("COUNTRY_ID", Utility.country_id);
//        insertData.put("COUNTRY_NAME", Utility.country_name);
//        insertData.put("CREATED_BY", Utility.getUserId(request));
//        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
//        insertData.put("CREATED_AT", current_ts);
//        insertData.put("ACTIVE", MDDivisionModel.getACTIVE());
//        insertData.put("UPDATED_BY", Utility.getUserId(request));
//        insertData.put("UPDATED_AT", current_ts);
//        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//
//
//        boolean h = commonDAO.CommoInsert(Utility.md_division, insertData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "Division"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "Division"));
//        }
//
//
//        return "redirect:" + "division";
//    }
//
//    @PostMapping(value = "/UpdateDivision")
//    public String UpdateDivision(MDDivisionModel MDDivisionModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox, HttpServletRequest request) {
//        if (MDDivisionModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Division"));
//            return "redirect:" + "division";
//        }
//
//        if (MDDivisionModel.getID() <= 0) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Division"));
//            return "redirect:" + "division";
//        }
//
//        long current_ts = Utility.getCurrentTimestamp();
//        MDDivisionModel.setNAME(MDDivisionModel.getNAME());
//        MDDivisionModel.setUPDATED_BY(Utility.getUserId(request));
//        MDDivisionModel.setUPDATED_AT(current_ts);
//        MDDivisionModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
//        if (checkbox) {
//            MDDivisionModel.setACTIVE(1);
//        } else {
//            MDDivisionModel.setACTIVE(2);
//        }
//
//
//        Map<String, Object> search = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//        search.put("ID!", MDDivisionModel.getID());
//        search.put("NAME", MDDivisionModel.getNAME());
//
//        whereSearchType.put("ID!", "AND");
//        whereSearchType.put("NAME", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_division, search, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Division"));
//            return "redirect:" + "division";
//        }
//
//        Map<String, Object> updateData = new HashMap<String, Object>();
//        updateData.put("NAME", MDDivisionModel.getNAME());
//        updateData.put("COUNTRY_ID", Utility.country_id);
//        updateData.put("COUNTRY_NAME", Utility.country_name);
//        updateData.put("ACTIVE", MDDivisionModel.getACTIVE());
//        updateData.put("UPDATED_BY", Utility.getUserId(request));
//        updateData.put("UPDATED_AT", current_ts);
//        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//
//        Map<String, Object> whereData = new HashMap<String, Object>();
//        whereData.put("ID", MDDivisionModel.getID());
//
//        boolean h = commonDAO.CommoUpdate(Utility.md_division, updateData, whereData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "Division"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "Division"));
//        }
//
//
//        // update District
//        Map<String, Object> upDistrictData = new HashMap<String, Object>();
//        upDistrictData.put("DIVISION_NAME", MDDivisionModel.getNAME());
//
//        Map<String, Object> whereDistData = new HashMap<String, Object>();
//        whereDistData.put("DIVISION_ID", MDDivisionModel.getID());
//
//        boolean area_h = commonDAO.CommoUpdate(Utility.md_district, upDistrictData, whereDistData, logger);
//
//        // update Upazila
//
//        Map<String, Object> upUpazilaData = new HashMap<String, Object>();
//        upUpazilaData.put("DIVISION_NAME", MDDivisionModel.getNAME());
//
//        Map<String, Object> whereUpazilaData = new HashMap<String, Object>();
//        whereUpazilaData.put("DIVISION_ID", MDDivisionModel.getID());
//
//        boolean sub_area_h = commonDAO.CommoUpdate(Utility.md_upazila, upUpazilaData, whereUpazilaData, logger);
//
//
//        return "redirect:" + "division";
//    }
//
//    /********************************* Division : End**************************************** */
//    /********************************* District : Start **************************************** */
//
//    @RequestMapping(value = "/district", method = RequestMethod.GET)
//    public String districtIndex(ModelMap model, HttpServletRequest request) {
//        new MenuViewer().setupSideMenu(model, request);
//        QueryMDDistrictModel empList = new QueryMDDistrictModel();
//        List<MDDivisionModel> divisionList = new ArrayList<MDDivisionModel>();
//        titleModel = new TitleModel("DCRM", "Settings", "Global Settings", "", "District");
//        try {
//            Map<String, Object> SearchData = new HashMap<String, Object>();
//            Map<String, Object> SourceData = new HashMap<String, Object>();
//            Map<String, Object> whereSearchType = new HashMap<String, Object>();
//
//            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_district, new HashMap<String, Object>(), whereSearchType);
//            int ii = commonDAO.CommoNumberOfRow(iiQStr);
//            logger.info(iiQStr);
//
//            String listQStr = QueryBuilder.getWherQueryPagination(Utility.md_district, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
//            logger.info(listQStr);
//            Object srslist = commonDAO.CommoGetData(listQStr);
//            List<MDDistrictModel> resList = new Gson().fromJson(Utility.ObjectToJson(srslist), new TypeToken<List<MDDistrictModel>>() {
//            }.getType());
//            empList = new QueryMDDistrictModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), resList);
//
//            Object divlst = globalSettingsDOA.getActiveDivision();
//            divisionList = new Gson().fromJson(Utility.ObjectToJson(divlst), new TypeToken<List<MDDivisionModel>>() {
//            }.getType());
//        } catch (Exception e) {
//            //System.out.println("Error in GB sourceListIndex: " + e.getMessage());
//            logger.error(e.getMessage());
//        }
//        model.addAttribute("SourceList", divisionList);
//        model.addAttribute("viewDataModel", empList);
//        model.addAttribute("title", titleModel);
//        return "globalsettings/DistrictView";
//    }
//
//    @PostMapping(value = "/saveDistrict")
//    public String saveDistrict(MDDistrictModel MDDistrictModel, @RequestParam(defaultValue = "false") boolean checkbox, RedirectAttributes attributes, HttpServletRequest request) {
//        long current_ts = Utility.getCurrentTimestamp();
//        MDDistrictModel.setCREATED_BY(Utility.getUserId(request));
//        MDDistrictModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));
//
//        if (checkbox) {
//            MDDistrictModel.setACTIVE(1);
//        } else {
//            MDDistrictModel.setACTIVE(2);
//        }
//
//        if (MDDistrictModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "District"));
//            return "redirect:" + "district";
//        }
//        List<String> selectedSource = Arrays.asList(MDDistrictModel.getDIVISION_NAME().split("/"));
//        MDDistrictModel.setDIVISION_ID(Integer.parseInt(selectedSource.get(0)));
//        MDDistrictModel.setDIVISION_NAME(selectedSource.get(1));
//
//        Map<String, Object> searchData = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//
//        searchData.put("NAME", MDDistrictModel.getNAME());
//        searchData.put("DIVISION_ID", MDDistrictModel.getDIVISION_ID());
//        whereSearchType.put("NAME", "AND");
//        whereSearchType.put("DIVISION_ID", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_district, searchData, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "District"));
//            return "redirect:" + "district";
//        }
//
//        Map<String, Object> insertData = new HashMap<String, Object>();
//        insertData.put("NAME", MDDistrictModel.getNAME());
//        insertData.put("CREATED_BY", Utility.getUserId(request));
//        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
//        insertData.put("CREATED_AT", current_ts);
//        insertData.put("ACTIVE", MDDistrictModel.getACTIVE());
//        insertData.put("UPDATED_BY", Utility.getUserId(request));
//        insertData.put("UPDATED_AT", current_ts);
//        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//        insertData.put("DIVISION_ID", MDDistrictModel.getDIVISION_ID());
//        insertData.put("DIVISION_NAME", MDDistrictModel.getDIVISION_NAME());
//
//        boolean h = commonDAO.CommoInsert(Utility.md_district, insertData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "District"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "District"));
//        }
//        return "redirect:" + "district";
//    }
//
//    @PostMapping(value = "/update_district")
//    public String UpdateDistrict(MDDistrictModel MDDistrictModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox, HttpServletRequest request) {
//        if (MDDistrictModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "District"));
//            return "redirect:" + "district";
//        }
//
//        if (MDDistrictModel.getID() <= 0) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "District"));
//            return "redirect:" + "district";
//        }
//
//        long current_ts = Utility.getCurrentTimestamp();
//        MDDistrictModel.setNAME(MDDistrictModel.getNAME());
//        MDDistrictModel.setUPDATED_BY(Utility.getUserId(request));
//        MDDistrictModel.setUPDATED_AT(current_ts);
//        MDDistrictModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
//        if (checkbox) {
//            MDDistrictModel.setACTIVE(1);
//        } else {
//            MDDistrictModel.setACTIVE(2);
//        }
//
//        List<String> selectedSource = Arrays.asList(MDDistrictModel.getDIVISION_NAME().split("/"));
//        MDDistrictModel.setDIVISION_ID(Integer.parseInt(selectedSource.get(0)));
//        MDDistrictModel.setDIVISION_NAME(selectedSource.get(1));
//
//
//        Map<String, Object> search = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//
//        search.put("ID!", MDDistrictModel.getID());
//        search.put("NAME", MDDistrictModel.getNAME());
//        search.put("DIVISION_ID", MDDistrictModel.getDIVISION_ID());
//
//        whereSearchType.put("ID!", "AND");
//        whereSearchType.put("NAME", "AND");
//        whereSearchType.put("DIVISION_ID", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_district, search, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "District"));
//            return "redirect:" + "district";
//        }
//
//        Map<String, Object> updateData = new HashMap<String, Object>();
//        updateData.put("NAME", MDDistrictModel.getNAME());
//        updateData.put("ACTIVE", MDDistrictModel.getACTIVE());
//        updateData.put("UPDATED_BY", Utility.getUserId(request));
//        updateData.put("UPDATED_AT", current_ts);
//        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//        updateData.put("DIVISION_ID", MDDistrictModel.getDIVISION_ID());
//        updateData.put("DIVISION_NAME", MDDistrictModel.getDIVISION_NAME());
//
//        Map<String, Object> whereData = new HashMap<String, Object>();
//        whereData.put("ID", MDDistrictModel.getID());
//
//        boolean h = commonDAO.CommoUpdate(Utility.md_district, updateData, whereData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "District"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "District"));
//        }
//
//
//        // update Upazila
//
//        Map<String, Object> upUpazilaData = new HashMap<String, Object>();
//        upUpazilaData.put("DISTRICT_NAME", MDDistrictModel.getNAME());
//
//        Map<String, Object> whereUpazilaData = new HashMap<String, Object>();
//        whereUpazilaData.put("DISTRICT_ID", MDDistrictModel.getID());
//
//        boolean sub_area_h = commonDAO.CommoUpdate(Utility.md_upazila, upUpazilaData, whereUpazilaData, logger);
//
//
//        return "redirect:" + "district";
//    }
//
//    /********************************* District : End **************************************** */
//
//
//    /********************************* Upazila : Start **************************************** */
//
//    @RequestMapping(value = "/upazila", method = RequestMethod.GET)
//    public String upazilaIndex(ModelMap model, HttpServletRequest request) {
//        new MenuViewer().setupSideMenu(model, request);
//        QueryMDUpazilaModel empList = new QueryMDUpazilaModel();
//        List<MDDistrictModel> districtList = new ArrayList<MDDistrictModel>();
//        List<MDDivisionModel> divisionList = new ArrayList<MDDivisionModel>();
//        titleModel = new TitleModel("DCRM", "Settings", "Global Settings", "", "Upazila");
//        try {
//            Map<String, Object> SearchData = new HashMap<String, Object>();
//            Map<String, Object> SourceData = new HashMap<String, Object>();
//            Map<String, Object> whereSearchType = new HashMap<String, Object>();
//
//            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_upazila, new HashMap<String, Object>(), whereSearchType);
//            int ii = commonDAO.CommoNumberOfRow(iiQStr);
//            logger.info(iiQStr);
//
//            String listQStr = QueryBuilder.getWherQueryPagination(Utility.md_upazila, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
//            logger.info(listQStr);
//            Object srslist = commonDAO.CommoGetData(listQStr);
//            List<MDUpazilaModel> resList = new Gson().fromJson(Utility.ObjectToJson(srslist), new TypeToken<List<MDUpazilaModel>>() {
//            }.getType());
//            empList = new QueryMDUpazilaModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), resList);
//
//            Object divlst = globalSettingsDOA.getActiveDivision();
//            divisionList = new Gson().fromJson(Utility.ObjectToJson(divlst), new TypeToken<List<MDDivisionModel>>() {
//            }.getType());
//
//            Object dislst = globalSettingsDOA.getActiveDistrict();
//            districtList = new Gson().fromJson(Utility.ObjectToJson(dislst), new TypeToken<List<MDDistrictModel>>() {
//            }.getType());
//
//        } catch (Exception e) {
//            //System.out.println("Error in GB sourceListIndex: " + e.getMessage());
//            logger.error(e.getMessage());
//        }
//        model.addAttribute("divisionList", divisionList);
//        model.addAttribute("districtList", districtList);
//        model.addAttribute("viewDataModel", empList);
//        model.addAttribute("title", titleModel);
//        return "globalsettings/UpazilaView";
//    }
//
//    @PostMapping(value = "/save_upazila")
//    public String saveDistrict(MDUpazilaModel MDUpazilaModel, @RequestParam(defaultValue = "false") boolean checkbox, RedirectAttributes attributes, HttpServletRequest request) {
//        long current_ts = Utility.getCurrentTimestamp();
//        MDUpazilaModel.setCREATED_BY(Utility.getUserId(request));
//        MDUpazilaModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));
//
//        if (checkbox) {
//            MDUpazilaModel.setACTIVE(1);
//        } else {
//            MDUpazilaModel.setACTIVE(2);
//        }
//
//        if (MDUpazilaModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Upazila"));
//            return "redirect:" + "upazila";
//        }
//        List<String> selectedDivision = Arrays.asList(MDUpazilaModel.getDIVISION_NAME().split("/"));
//        MDUpazilaModel.setDIVISION_ID(Integer.parseInt(selectedDivision.get(0)));
//        MDUpazilaModel.setDIVISION_NAME(selectedDivision.get(1));
//
//        List<String> selectedDistrict = Arrays.asList(MDUpazilaModel.getDISTRICT_NAME().split("/"));
//        MDUpazilaModel.setDISTRICT_ID(Integer.parseInt(selectedDistrict.get(0)));
//        MDUpazilaModel.setDISTRICT_NAME(selectedDistrict.get(1));
//
//        Map<String, Object> searchData = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//
//        searchData.put("NAME", MDUpazilaModel.getNAME());
//        searchData.put("DIVISION_ID", MDUpazilaModel.getDIVISION_ID());
//        searchData.put("DISTRICT_ID", MDUpazilaModel.getDISTRICT_ID());
//        whereSearchType.put("NAME", "AND");
//        whereSearchType.put("DIVISION_ID", "AND");
//        whereSearchType.put("DISTRICT_ID", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_upazila, searchData, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Upazila"));
//            return "redirect:" + "upazila";
//        }
//
//        Map<String, Object> insertData = new HashMap<String, Object>();
//        insertData.put("NAME", MDUpazilaModel.getNAME());
//        insertData.put("CREATED_BY", Utility.getUserId(request));
//        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
//        insertData.put("CREATED_AT", current_ts);
//        insertData.put("ACTIVE", MDUpazilaModel.getACTIVE());
//        insertData.put("UPDATED_BY", Utility.getUserId(request));
//        insertData.put("UPDATED_AT", current_ts);
//        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//        insertData.put("DIVISION_ID", MDUpazilaModel.getDIVISION_ID());
//        insertData.put("DIVISION_NAME", MDUpazilaModel.getDIVISION_NAME());
//        insertData.put("DISTRICT_ID", MDUpazilaModel.getDISTRICT_ID());
//        insertData.put("DISTRICT_NAME", MDUpazilaModel.getDISTRICT_NAME());
//
//        boolean h = commonDAO.CommoInsert(Utility.md_upazila, insertData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "Upazila"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "Upazila"));
//        }
//        return "redirect:" + "upazila";
//    }
//
//    @PostMapping(value = "/update_upazila")
//    public String UpdateDistrict(MDUpazilaModel MDUpazilaModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox, HttpServletRequest request) {
//        if (MDUpazilaModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Upazila"));
//            return "redirect:" + "upazila";
//        }
//
//        if (MDUpazilaModel.getID() <= 0) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Upazila"));
//            return "redirect:" + "upazila";
//        }
//
//        long current_ts = Utility.getCurrentTimestamp();
//        MDUpazilaModel.setNAME(MDUpazilaModel.getNAME());
//        MDUpazilaModel.setUPDATED_BY(Utility.getUserId(request));
//        MDUpazilaModel.setUPDATED_AT(current_ts);
//        MDUpazilaModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
//        if (checkbox) {
//            MDUpazilaModel.setACTIVE(1);
//        } else {
//            MDUpazilaModel.setACTIVE(2);
//        }
//
//        List<String> selectedDivision = Arrays.asList(MDUpazilaModel.getDIVISION_NAME().split("/"));
//        MDUpazilaModel.setDIVISION_ID(Integer.parseInt(selectedDivision.get(0)));
//        MDUpazilaModel.setDIVISION_NAME(selectedDivision.get(1));
//
//        List<String> selectedDistrict = Arrays.asList(MDUpazilaModel.getDISTRICT_NAME().split("/"));
//        MDUpazilaModel.setDISTRICT_ID(Integer.parseInt(selectedDistrict.get(0)));
//        MDUpazilaModel.setDISTRICT_NAME(selectedDistrict.get(1));
//
//
//        Map<String, Object> search = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//
//        search.put("ID!", MDUpazilaModel.getID());
//        search.put("NAME", MDUpazilaModel.getNAME());
//        search.put("DIVISION_ID", MDUpazilaModel.getDIVISION_ID());
//        search.put("DISTRICT_ID", MDUpazilaModel.getDISTRICT_ID());
//
//        whereSearchType.put("ID!", "AND");
//        whereSearchType.put("NAME", "AND");
//        whereSearchType.put("DIVISION_ID", "AND");
//        whereSearchType.put("DISTRICT_ID", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_upazila, search, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Upazila"));
//            return "redirect:" + "upazila";
//        }
//
//        Map<String, Object> updateData = new HashMap<String, Object>();
//        updateData.put("NAME", MDUpazilaModel.getNAME());
//        updateData.put("ACTIVE", MDUpazilaModel.getACTIVE());
//        updateData.put("UPDATED_BY", Utility.getUserId(request));
//        updateData.put("UPDATED_AT", current_ts);
//        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//        updateData.put("DIVISION_ID", MDUpazilaModel.getDIVISION_ID());
//        updateData.put("DIVISION_NAME", MDUpazilaModel.getDIVISION_NAME());
//        updateData.put("DISTRICT_ID", MDUpazilaModel.getDISTRICT_ID());
//        updateData.put("DISTRICT_NAME", MDUpazilaModel.getDISTRICT_NAME());
//
//        Map<String, Object> whereData = new HashMap<String, Object>();
//        whereData.put("ID", MDUpazilaModel.getID());
//
//        boolean h = commonDAO.CommoUpdate(Utility.md_upazila, updateData, whereData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "Upazila"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "Upazila"));
//        }
//
//        return "redirect:" + "upazila";
//    }
//
//    /********************************* Upazila : Start **************************************** */
//
//    /*********************************User Position : Start **************************************** */
//    @RequestMapping(value = "/user_position", method = RequestMethod.GET)
//    public String userPositionIndex(ModelMap model, HttpServletRequest request) {
//        new MenuViewer().setupSideMenu(model, request);
//        QueryMDUserPositionModel empList = new QueryMDUserPositionModel();
//        List<MDUserPositionModel> parentList = new ArrayList<MDUserPositionModel>();
//        Map<Integer, String> pdic = new HashMap<Integer, String>();
//        titleModel = new TitleModel("DCRM", "Settings", "Global Settings", "", "User Position");
//        try {
//            Map<String, Object> SearchData = new HashMap<String, Object>();
//            Map<String, Object> whereSearchType = new HashMap<String, Object>();
//            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_user_position, new HashMap<String, Object>(), whereSearchType);
//            logger.info(iiQStr);
//            int ii = commonDAO.CommoNumberOfRow(iiQStr);
//
//            String listQStr = QueryBuilder.getWherQueryPagination(Utility.md_user_position, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
//            Object srslist = commonDAO.CommoGetData(listQStr);
//            logger.info(listQStr);
//
//            List<MDUserPositionModel> accountclassList = new Gson().fromJson(Utility.ObjectToJson(srslist), new TypeToken<List<MDUserPositionModel>>() {
//            }.getType());
//            empList = new QueryMDUserPositionModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), accountclassList);
////            parentList = globalSettingsDOA.getActiveUserGroup();
////
////            for (MDUserGroupModel item : parentList
////            ) {
////                pdic.put(item.getID(), item.getNAME());
////            }
//            //parentList = new Gson().fromJson(Utility.ObjectToJson(reslist), new TypeToken<List<MDUserGroupModel>>() {
//            //}.getType());
//        } catch (Exception e) {
//            // System.out.println("Error in GB accountClassIndex: " + e.getMessage());
//            logger.error(e.getMessage());
//        }
//        model.addAttribute("viewDataModel", empList);
//        //model.addAttribute("parentList", parentList);
//        // model.addAttribute("pList", pdic);
//        model.addAttribute("title", titleModel);
//        return "globalsettings/UserPositionView";
//    }
//
//    @PostMapping(value = "/saveUserPosition")
//    public String saveUserPosition(MDUserPositionModel MDUserPositionModel, @RequestParam(defaultValue = "false") boolean checkbox, @RequestParam(defaultValue = "false") boolean isParent, RedirectAttributes attributes, HttpServletRequest request) {
//        long current_ts = Utility.getCurrentTimestamp();
//        MDUserPositionModel.setCREATED_BY(Utility.getUserId(request));
//
//        MDUserPositionModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));
//        List<MDUserModel> resUser=usersDAO.findUserByLoginName(MDUserPositionModel.getOWNER_NAME());
//
//        if (checkbox) {
//            MDUserPositionModel.setACTIVE(1);
//        } else {
//            MDUserPositionModel.setACTIVE(2);
//        }
//        if (resUser.size()<1) {
//            attributes.addFlashAttribute("error", "No Owner User Found!");
//            return "redirect:" + "user_position";
//        }
//
//        if (MDUserPositionModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "User Position"));
//            return "redirect:" + "user_position";
//        }
//
//        Map<String, Object> searchData = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//        searchData.put("NAME", MDUserPositionModel.getNAME());
//        whereSearchType.put("NAME", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_user_position, searchData, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "User Position"));
//            return "redirect:" + "user_position";
//        }
//
//        Map<String, Object> insertData = new HashMap<String, Object>();
//        insertData.put("NAME", MDUserPositionModel.getNAME());
//        insertData.put("CREATED_BY", Utility.getUserId(request));
//        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
//        insertData.put("CREATED_AT", current_ts);
//        insertData.put("ACTIVE", MDUserPositionModel.getACTIVE());
//        insertData.put("UPDATED_BY", Utility.getUserId(request));
//        insertData.put("UPDATED_AT", current_ts);
//        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//        insertData.put("GROUP_EMAIL", MDUserPositionModel.getGROUP_EMAIL());
//        if (resUser.size()>=1) {
//
//            insertData.put("OWNER_ID", resUser.get(0).getID());
//            insertData.put("OWNER_EMAIL", resUser.get(0).getEMAIL());
//        }
//
//        insertData.put("OWNER_NAME", MDUserPositionModel.getOWNER_NAME());
//
//
//
//        boolean h = commonDAO.CommoInsert(Utility.md_user_position, insertData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "User Position"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "User Position"));
//        }
//        return "redirect:" + "user_position";
//    }
//
//    @PostMapping(value = "/updateUserPosition")
//    public String updateUserPosition(MDUserPositionModel MDUserPositionModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox, @RequestParam(defaultValue = "false") boolean isParent, HttpServletRequest request) {
//        List<MDUserModel> resUser=usersDAO.findUserByLoginName(MDUserPositionModel.getOWNER_NAME());
//        if (MDUserPositionModel.getNAME().equals("")) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "User Position"));
//            return "redirect:" + "user_position";
//        }
//        if (resUser.size()<1) {
//            attributes.addFlashAttribute("error", "No Owner User Found!");
//            return "redirect:" + "user_position";
//        }
//
//        if (MDUserPositionModel.getID() <= 0) {
//            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "User Position"));
//            return "redirect:" + "user_position";
//        }
//
//        long current_ts = Utility.getCurrentTimestamp();
//        MDUserPositionModel.setNAME(MDUserPositionModel.getNAME());
//        MDUserPositionModel.setUPDATED_BY(Utility.getUserId(request));
//        MDUserPositionModel.setUPDATED_AT(current_ts);
//        MDUserPositionModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
//        if (checkbox) {
//            MDUserPositionModel.setACTIVE(1);
//        } else {
//            MDUserPositionModel.setACTIVE(2);
//        }
//        Map<String, Object> search = new HashMap<String, Object>();
//        Map<String, Object> whereSearchType = new HashMap<String, Object>();
//
//        search.put("ID!", MDUserPositionModel.getID());
//        search.put("NAME", MDUserPositionModel.getNAME());
//
//        whereSearchType.put("ID!", "AND");
//        whereSearchType.put("NAME", "AND");
//
//        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_user_position, search, whereSearchType);
//        logger.info(duplicateQry);
//        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
//
//        if (TotalRows > 0) {
//            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "User Position"));
//            return "redirect:" + "user_position";
//        }
//
//        Map<String, Object> updateData = new HashMap<String, Object>();
//        updateData.put("NAME", MDUserPositionModel.getNAME());
//        updateData.put("ACTIVE", MDUserPositionModel.getACTIVE());
//        updateData.put("UPDATED_BY", Utility.getUserId(request));
//        updateData.put("UPDATED_AT", current_ts);
//        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//        updateData.put("OWNER_NAME", MDUserPositionModel.getOWNER_NAME());
//        if (resUser.size()>=1) {
//
//            updateData.put("OWNER_ID", resUser.get(0).getID());
//            updateData.put("OWNER_EMAIL", resUser.get(0).getEMAIL());
//        }
//
//        Map<String, Object> whereData = new HashMap<String, Object>();
//
//        whereData.put("ID", MDUserPositionModel.getID());
//
//        boolean h = commonDAO.CommoUpdate(Utility.md_user_position, updateData, whereData, logger);
//        if (h) {
//            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "User Position"));
//        } else {
//            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "User Position"));
//        }
//
//        return "redirect:" + "user_position";
//    }
//}
//
///*********************************User Position : End **************************************** */
