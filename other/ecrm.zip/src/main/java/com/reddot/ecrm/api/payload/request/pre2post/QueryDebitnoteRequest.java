package com.reddot.ecrm.api.payload.request.pre2post;

public class QueryDebitnoteRequest {

}
