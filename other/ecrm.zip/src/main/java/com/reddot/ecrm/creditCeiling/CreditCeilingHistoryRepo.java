package com.reddot.ecrm.creditCeiling;

import com.reddot.ecrm.module.primaryOffering.PrimaryOffering;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CreditCeilingHistoryRepo extends JpaRepository<CreditCeilingHistory, Long>, JpaSpecificationExecutor<CreditCeilingHistory> {
    List<CreditCeilingHistory> findAllByCreditCeiling(String creditCeiling);

    List<CreditCeilingHistory> findAllByCompanyIdOrderByIdDesc(String companyId);
}
