package com.reddot.ecrm.dao;

import com.reddot.ecrm.dao.CommonDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import java.util.Map;

public class CommonImpl extends JdbcDaoSupport implements CommonDAO {
    private final Logger responseTrackerLogger = LoggerFactory.getLogger("responseTrackerLogger");

    @Override
    public Object CommoPagination(String sql) {
        System.out.println(sql);
        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        try {
            getJdbcTemplate().query(sql, new RowCallbackHandler() {
                public void processRow(ResultSet resultSet) throws SQLException {
                    Map<String, Object> temp = new HashMap<>();
                    ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
                    for (int i=1; i<=resultSetMetaData.getColumnCount(); i++) {
                        temp.put(resultSetMetaData.getColumnName(i), resultSet.getObject(i));
                    }
                    list.add(temp);
                }
            });
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return list;
    }

    @Override
    public Object CommoGetData(String sql) {
        System.out.println("CommoGetData --" + sql);
        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        try {
            long startTime = System.currentTimeMillis();
            getJdbcTemplate().query(sql, new RowCallbackHandler() {
                public void processRow(ResultSet resultSet) throws SQLException {
                    Map<String, Object> temp = new HashMap<>();
                    ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
                    for (int i=1; i<=resultSetMetaData.getColumnCount(); i++) {
                        temp.put(resultSetMetaData.getColumnName(i), resultSet.getObject(i));
                    }
                    list.add(temp);
                }
            });
            responseTrackerLogger.info("QUERY: " + sql + ", RESPONSE_TIME: " + (System.currentTimeMillis() - startTime) + "ms");
            System.out.println("QUERY: " + sql + ", RESPONSE_TIME: " + (System.currentTimeMillis() - startTime) + "ms");
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return list;
    }

    @Override
    public int CommoNumberOfRow(String sql) {
        logger.info(sql);
        int count = 0;
        try {
            count = getJdbcTemplate().queryForObject(sql, Integer.class);

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            System.out.println("Count Error: " + e.getMessage());
        }

        return count;
    }
}
