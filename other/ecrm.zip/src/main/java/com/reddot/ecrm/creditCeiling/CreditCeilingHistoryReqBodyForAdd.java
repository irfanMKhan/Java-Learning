package com.reddot.ecrm.creditCeiling;

import com.reddot.ecrm.dto.attachment.AttachmentDTO;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class CreditCeilingHistoryReqBodyForAdd {
    private String companyId;
    private String companyName;
    private String creditCeiling;
    private String creditLimit;
    private String typeId;
    private String typeName;
    private String statusId;
    private String statusName;
    private Long referenceId;
    private String referenceName;
    private Double amount;
    private Double newCC;
    private String expirationDate;
    private String attachment;
    private List<AttachmentDTO> attachmentList;
}
