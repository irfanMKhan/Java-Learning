package com.reddot.ecrm.controller.lead.settings;

import com.reddot.ecrm.dto.lead.settings.CityProvinceDto;
import com.reddot.ecrm.entity.lead.settings.CityProvince;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.lead.settings.CityProvinceService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("lead/cityProvince")
public class CityProvinceRestController {
    
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    
    @Autowired
    private CityProvinceService cityProvinceService;
    
    @GetMapping("/dt/all")
    public DataTablesOutput<CityProvinceDto> dtCityProvince(@Valid DataTablesInput input,
                                                            HttpServletRequest request,
                                                            @RequestParam(value = "searchText", required = false) String searchText, @RequestParam(value = "searchCol", required = false) String searchCol) {
        return cityProvinceService.getDTCityProvince(input, request, searchText, searchCol);
    }

    @GetMapping("/all")
    public ResponseEntity<?> getAllCityProvince(){
        List<CityProvince> cityProvinces = cityProvinceService.getAllCityProvince();
        if(cityProvinces.isEmpty()){
            return new ResponseEntity<>("No data found!", HttpStatus.NO_CONTENT);
        }
        else return new ResponseEntity<>(cityProvinces, HttpStatus.OK);
    }
    
    @PostMapping("/add")
    public CommonRestResponse addCityProvince(HttpServletRequest request, @RequestBody CityProvinceDto cityProvinceDto) {
        return cityProvinceService.addCityProvince(request, cityProvinceDto);
    }
    
    @GetMapping("/details")
    public CommonRestResponse getCityProvinceById(@RequestParam("id") Long id) {
        return cityProvinceService.getCityProvinceById(id);
    }
    
    @PostMapping("/update")
    public CommonRestResponse updateCityProvince(HttpServletRequest request,
                                                @RequestBody CityProvinceDto cityProvinceDto) {
        return cityProvinceService.updateCityProvince(request, cityProvinceDto);
    }
    
    @GetMapping("/byCountry")
    public List<CityProvinceDto> getAllByCountryId(@RequestParam("countryId") Long countryId) {
        return cityProvinceService.getAllCityProvincesWhereIsActiveByCountryId(countryId);
    }
    
}