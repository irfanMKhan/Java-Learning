package com.reddot.ecrm.api.payload.request.shared.group;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AddGroupCUGRequest implements Serializable {
    @Valid
    @NotNull(message = "AddCUGGroupMemberReq is required.")
    private AddCUGGroupMemberReq AddCUGGroupMemberReq;
    @NotNull(message = "transaction_id is required.")
    @NotEmpty(message = "transaction_id is required.")
    private String transaction_id;
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class AddCUGGroupMemberReq implements Serializable {
        @Valid
        @NotNull(message = "AddMemberInfo is required.")
        private AddMemberInfo AddMemberInfo;
        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class AddMemberInfo implements Serializable {
            @NotNull(message = "MemberServiceNum is required.")
            @NotEmpty(message = "MemberServiceNum is required.")
            private String MemberServiceNum;
        }
    }
}
