package com.reddot.ecrm.controller.survey;

import com.reddot.ecrm.entity.survey.SurveyEntity;
import com.reddot.ecrm.enum_config.survey.SurveyTypeEnum;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.survey.SurveyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/survey")
public class SurveyController {
    @Autowired
    private SurveyService surveyService;

    @GetMapping
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        SurveyTypeEnum[] surveyTypeList = SurveyTypeEnum.values();

        model.put("surveyTypes", surveyTypeList);
        model.put("title", "Survey Details");
        return "survey/surveyAdd";
    }

    @GetMapping("/activeSurvey/list")
    public String viewSurveyListPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        CommonRestResponse commonRestResponse = surveyService.getSurveyActiveList();
        List<SurveyEntity> activeSurveyList = (List<SurveyEntity>) commonRestResponse.getData();

        model.put("activeSurvey", activeSurveyList);
        model.put("title", "Survey List");
        model.addAttribute("breadcrumb", "Survey Details");
        return "survey/activeSurveyDashBoard";
    }


    @GetMapping("/surveyResponse/list")
    public String viewSurveyResponseListPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        CommonRestResponse commonRestResponse = surveyService.getSurveyList();
        List<SurveyEntity> activeSurveyList = (List<SurveyEntity>) commonRestResponse.getData();

        model.put("activeSurvey", activeSurveyList);
        model.put("title", "Survey Response List");
        model.addAttribute("breadcrumb", "Survey Response Details");
        return "survey/surveyResponseDashboard";
    }
}
