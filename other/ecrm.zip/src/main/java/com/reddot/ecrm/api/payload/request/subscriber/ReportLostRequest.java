package com.reddot.ecrm.api.payload.request.subscriber;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportLostRequest implements Serializable {

    private bss_info bss_info;

    private report_lost report_lost;
    private String transaction_id;
    private Integer channel_id;

    @Data
    @AllArgsConstructor
    public static class bss_info implements Serializable {
        private String username;

        private String password;

        private String operator_id;
    }

    @Data
    @AllArgsConstructor
    public static class report_lost implements Serializable {
        private Integer reason_code;
    }

}
