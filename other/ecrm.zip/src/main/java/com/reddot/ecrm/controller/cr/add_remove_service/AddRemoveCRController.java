package com.reddot.ecrm.controller.cr.add_remove_service;

import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.enum_config.cr.add_new_number.PaymentTerm;
import com.reddot.ecrm.enum_config.cr.add_new_number.ReservationStatus;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.repository.company.CompanyRepository;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Controller
@RequestMapping("/cr/addRemoveService")
public class AddRemoveCRController {
    @Autowired
    CompanyRepository companyRepository;

    @GetMapping
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        ReservationStatus[] reservationStatus = ReservationStatus.values();
        PaymentTerm[] paymentTerms = PaymentTerm.values();

        List<CompanyEntity> companyList = companyRepository.findAllByActiveAndContractStatus(true, 2);

        Boolean isPIC = false;
        MDUserModel mdUserModel = Utility.CheckPICAndReturnUserDetails(request);
        Long companyId = null;
        String companyName = null;

        if (mdUserModel != null) {
            isPIC = true;
            companyId = mdUserModel.getCOMPANY_ID();
            companyName = mdUserModel.getCOMPANY_NAME();
        }


        model.addAttribute("breadcrumb", "Add Remove Service Summary");
        model.put("reservation_status", reservationStatus);
        model.put("payment_terms", paymentTerms);
        model.put("company_list", companyList);
        model.put("title", "Add Remove Service");
        model.put("isPIC", isPIC);
        model.put("companyId", companyId);
        model.put("companyName", companyName);

        return "cr/add_remove_service/add_remove_service";
    }


    @GetMapping("/summary")
    public String viewPageSummary(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        ReservationStatus[] reservationStatus = ReservationStatus.values();
        PaymentTerm[] paymentTerms = PaymentTerm.values();
        List<CompanyEntity> companyList = companyRepository.findAllByActiveAndContractStatus(true, 2);

        model.put("reservation_status", reservationStatus);
        model.put("payment_terms", paymentTerms);
        model.put("company_list", companyList);
        model.addAttribute("breadcrumb", "Add Remove Service Summary");
        model.put("title", "Add Remove Service Summary");
        return "cr/add_remove_service/add_remove_summary";
    }
}
