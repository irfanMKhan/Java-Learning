package com.reddot.ecrm.dto.account;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountDetailsDTO {

    private Long id;
    private String tempNO;
    private String contractNumber;
    private String[] productOfInterest;
    private String productOfInterestName;
    private String productOfInterestString;
    private String followUpDate;
    private String latitude;
    private String longitude;
    private String location;
    private String vatId;
    private String currentProductText;
    private String currentProductString;
    private String currentExpiryDate;
    private String numberOfLine;
    private String monthlyFee;
    private String contractDuration;
    private String estimatedRevenue;
    private String discount;
    private String phoneNumber;
    private String emailAddress;
    private Boolean isDeposit;
    private Boolean hasGuaranteeLetter;
    private Boolean hasWaiver;
    private Boolean hasPrePayment;

    private String corporateType;
    private String corporateTypeApiValue;
    private String corporateTypeText;
    private String certificationType;
    private String certificationTypeApiValue;
    private String certificationTypeText;

    private String mocRegistrationDate;
    private String mocNumber;
    private String[] billType;
    private String billTypeString;
    private Double specialOffer;
    private Double amount;
    private Double depositAmount;
    private Double financialAdjustment;
    private String remarks;
    private String subIndustry;
    private String subIndustryName;
    private String subIndustryApiValue;
    private String industry;
    private String industryApiValue;
    private String industryName;
    private String numberOfEmployee;
    private String numberOfEmployeeName;
    private String sizeOfEnterprise;
    private String sizeOfEnterpriseName;
    private String annualRevenue;
    private String annualRevenueName;
    private String originOfEnterprise;
    private String originOfEnterpriseText;
    private String houseNumber;
    private String street;
    private String sangkatCommune;
    private String sangkatCommuneName;
    private String khanDistrict;
    private String khanDistrictName;
    private String cityProvince;
    private String cityProvinceName;
    private String villageGroup;
    private String postcode;
    private String country;
    private String countryName;
    private String website;
    private String specialEvent;

    private String sangkatCommuneApiValue;
    private String khanDistrictApiValue;
    private String cityProvinceApiValue;
    private String countryApiValue;
}
