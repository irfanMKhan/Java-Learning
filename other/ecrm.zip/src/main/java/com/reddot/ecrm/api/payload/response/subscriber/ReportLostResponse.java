package com.reddot.ecrm.api.payload.response.subscriber;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.lang.Integer;
import java.lang.String;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReportLostResponse implements Serializable {
  private String transaction_id;

  private bss_info bss_info;

  private report_lost report_lost;

  private Integer channel_id;

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class bss_info implements Serializable {
    private String operator_id;

    private String username;
  }

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class report_lost implements Serializable {
    private Integer reason_code;
  }
}
