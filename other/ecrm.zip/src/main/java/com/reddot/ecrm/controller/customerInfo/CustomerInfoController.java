package com.reddot.ecrm.controller.customerInfo;

import com.reddot.ecrm.dto.cdr.CDRSearchDTO;
import com.reddot.ecrm.dto.customerReport.CustomerReportSearchDTO;
import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.service.customerInfo.CustomerInfoService;
import com.reddot.ecrm.spring_config.session.SessionManager;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/CustomerInfo/Report")
public class CustomerInfoController {

    private final CustomerInfoService customerInfoService;
    @GetMapping
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        List<CompanyEntity> listOfCompany = customerInfoService.getAllCompany();
        MDUserModel mdUserModel = SessionManager.getUserDetails(request);
        model.put("title", "Customer Info");
        model.addAttribute("listOfCompany", listOfCompany);
        model.put("userType", mdUserModel.getUSER_TYPE().toUpperCase().toString());

        return "customerInfo/index";
    }

    @RequestMapping(value = "/download", method = RequestMethod.POST)
    @ResponseBody
    public void download(HttpServletRequest request, HttpServletResponse response, @RequestBody CustomerReportSearchDTO customerReportSearchDTO) throws Exception {
        System.out.println(customerReportSearchDTO);
        customerInfoService.generateCustomerInformationReport(response,customerReportSearchDTO);
    }

}
