package com.reddot.ecrm.controller.home;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.deposit.DepositService;
import com.reddot.ecrm.entity.company.CompanyAccountEntity;
import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.entity.contract.ContractEntity;
import com.reddot.ecrm.entity.contract.ProductDetailsContractAnnexEntity;
import com.reddot.ecrm.entity.msisdn.MsisdnEntity;
import com.reddot.ecrm.enum_config.CommonStatusEnum;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.model.utility.DashboardPerformanceReportModel;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.repository.company.CompanyAccountRepo;
import com.reddot.ecrm.service.company.CompanyService;
import com.reddot.ecrm.service.contract.ContractService;
import com.reddot.ecrm.service.msisdn.MsisdnService;
import com.reddot.ecrm.service.productDetailsContractAnnex.ProductDetailsContractAnnexService;
import com.reddot.ecrm.spring_config.session.SessionManager;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/dashboard")
public class DashboardRestController {
    private final CommonRepository commonRepository;
    private final CompanyService companyService;
    private final DepositService depositService;
    private final MsisdnService msisdnService;
    private final CompanyAccountRepo companyAccountRepo;
    private final ProductDetailsContractAnnexService contractAnnexService;
    private final ContractService contractService;
    private final ModelMapper mapper;

    private final Logger logger = LoggerFactory.getLogger(DashboardRestController.class);

    @RequestMapping(value = "/user-login-history", method = RequestMethod.GET)
    public ResponseEntity<?> userLoginHistory(HttpServletRequest request) {
        MDUserModel userModel = SessionManager.getUserDetails(request);

        if( userModel != null && !userModel.getLOGIN_NAME().isEmpty() ){
            List<Map<String, Object>> dataList = commonRepository.getLoginHistory(userModel.getLOGIN_NAME());
            return new ResponseEntity<>(dataList, HttpStatus.OK);
        }

        return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @GetMapping("/report")
    public ResponseEntity<?> getLocReportForDashboard(HttpServletRequest request){
        Map<String, Object> result = new HashMap<>();
        MDUserModel userModel = SessionManager.getUserDetails(request);
        if(userModel.getCOMPANY_ID()==null){
            Map<String, Object> locReport = commonRepository.locReportForKam(userModel.getID());
            result.put("loc", locReport);
        } else{
            result.put("loc", null);
        }
        if(userModel.getCOMPANY_ID()==null){
            List<DashboardPerformanceReportModel> performanceReport = commonRepository.performanceReportForKAM(userModel.getID());
            result.put("performance", performanceReport);
        } else{
            result.put("performance", null);
        }
        return new ResponseEntity<>(result, HttpStatus.OK );
    }

    @PostMapping("/overview")
    public ResponseEntity<?> getOverviewData(@RequestBody Long companyId, HttpServletRequest request){
        MDUserModel userModel = SessionManager.getUserDetails(request);

        CompanyEntity company = companyService.getCompanyById(String.valueOf(companyId));
        List<MsisdnEntity> msisdn = msisdnService.findAllByCompanyId(String.valueOf(companyId));
        List<ContractEntity> contractEntityList = contractService.getActiveContractsByCompany(company.getName());
        List<CompanyAccountEntity> groupList = companyAccountRepo.findAllByCompanyIdAndIsParentAndActive(companyId, Boolean.FALSE, Boolean.TRUE);

        Map<String, Object> result = new HashMap<>();
        result.put("overview", company);
        result.put("msisdn", msisdn);
        result.put("contracts", contractEntityList);
        result.put("groupList", groupList);
        result.put("contractStatus", CommonStatusEnum.values());
        result.put("depositAmount", depositService.getDepositBalance(companyId, request));
//        result.put("depositAmount", "100");

        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @PostMapping("/contracts")
    public DataTablesOutput<ProductDetailsContractAnnexEntity> contractsForCompany(@RequestBody Map<String, Object> searchData) throws JsonProcessingException {
        DataTablesInput input = new Gson().fromJson(Utility.ObjectToJson(searchData.get("input")), new TypeToken<DataTablesInput>(){}.getType());
        ObjectMapper mapper = new ObjectMapper();
        ProductDetailsContractAnnexEntity reqData = mapper.readValue(searchData.get("searchData").toString(), ProductDetailsContractAnnexEntity.class);
        return contractAnnexService.productContractAnnexDataTable(input, reqData);
    }

    @PostMapping("/msisdn")
    public DataTablesOutput<MsisdnEntity> msisdnForCompany(@RequestBody Map<String, Object> searchData) throws JsonProcessingException {
        DataTablesInput input = new Gson().fromJson(Utility.ObjectToJson(searchData.get("input")), new TypeToken<DataTablesInput>(){}.getType());
        ObjectMapper mapper = new ObjectMapper();
        MsisdnEntity reqData = mapper.readValue(searchData.get("searchData").toString(), MsisdnEntity.class);
        return msisdnService.msisdnDataTable(input, reqData);
    }
}
