package com.reddot.ecrm.api.payload.response.subscriber;

import lombok.Data;

import java.io.Serializable;

@Data
public class ResetNetworkResponse implements Serializable {
  private String transaction_id;

  private String code;

  private String message;
}
