package com.reddot.ecrm.dto.agreement.sponsored;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class StandardPackageTable {
    private String items;
    private String descriptions;
}
