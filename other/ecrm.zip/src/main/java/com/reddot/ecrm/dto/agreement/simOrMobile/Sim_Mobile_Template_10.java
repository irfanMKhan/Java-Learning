package com.reddot.ecrm.dto.agreement.simOrMobile;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class Sim_Mobile_Template_10 {
    private String contactDetail;
    private String responsibility;
    private String timesOfSupport;
}
