package com.reddot.ecrm.api.payload.response.opportunity;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class QueryInventoryMSISDNResponse implements Serializable {
  private Integer code;

  private Data data;

  private String message;

  private Integer timestamp;

  @lombok.Data
  public static class Data implements Serializable {
    private Pagination pagination;

    private List<Msisdns> msisdns;

    @lombok.Data
    public static class Pagination implements Serializable {
      private Boolean is_next_page_available;

      private Integer current_page;
    }

    @lombok.Data
    public static class Msisdns implements Serializable {
      private Charging charging;

      private String msisdn;

      private Category category;

      private String status;

      @lombok.Data
      public static class Charging implements Serializable {
        private Integer original_price;

        private Integer discount_price;

        private Integer discount_rate;

        private Integer sale_price;
      }

      @lombok.Data
      public static class Category implements Serializable {
        private String category_name;

        private Integer category_id;
      }
    }
  }
}
