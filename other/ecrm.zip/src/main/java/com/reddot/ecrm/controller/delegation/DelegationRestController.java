package com.reddot.ecrm.controller.delegation;

import com.reddot.ecrm.entity.delegation.DelegationEntity;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.repository.delegation.DelegationRepo;
import com.reddot.ecrm.service.delegation.DelegationService;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/delegation/rest")
public class DelegationRestController {
    @Autowired
    DelegationRepo delegationRepo;
    @Autowired
    DelegationService delegationService;

    @PostMapping("/addData")
    public CommonRestResponse addData(@RequestBody DelegationEntity delegation, HttpServletRequest request) {
        return delegationService.addData(delegation, request);
    }

    @PostMapping("/updateData")
    public CommonRestResponse updateData(@RequestBody DelegationEntity delegation, HttpServletRequest request) {
        return delegationService.updateData(delegation, request);
    }

    @PostMapping("/deleteData")
    public CommonRestResponse updateData(@RequestBody Long id, HttpServletRequest request) {
        return delegationService.deleteData(id, request);
    }

    @GetMapping("/getData")
    public List<DelegationEntity> getAllDataByDelegatorID(HttpServletRequest request) {
        return delegationRepo.findAllByDelegatorIdAndEndDateGreaterThanEqual(Utility.loggedInId(request), LocalDate.now());
    }


}
