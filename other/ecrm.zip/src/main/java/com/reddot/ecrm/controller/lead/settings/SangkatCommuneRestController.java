package com.reddot.ecrm.controller.lead.settings;

import com.reddot.ecrm.dto.lead.settings.SangkatCommuneDto;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.lead.settings.SangkatCommuneService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("lead/sangkatCommune")
public class SangkatCommuneRestController {
    
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    
    @Autowired
    private SangkatCommuneService sangkatCommuneService;
    
    @GetMapping("/dt/all")
    public DataTablesOutput<SangkatCommuneDto> dtSangkatCommune(HttpServletRequest request,
                                                                DataTablesInput input,
                                                                @RequestParam(value = "countryName", required = false, defaultValue = "") String countryName,
                                                                @RequestParam(value = "cityProvinceName", required = false, defaultValue = "") String cityProvinceName,
                                                                @RequestParam(value = "khanDistrictName", required = false, defaultValue = "") String khanDistrictName,
                                                                @RequestParam(value = "sangkatCommuneName", required = false, defaultValue = "") String sangkatCommuneName,
                                                                @RequestParam(value = "ngbssCommuneId", required = false, defaultValue = "") String ngbssCommuneId,
                                                                @RequestParam(value = "isActive", required = false, defaultValue = "") String isActive) {
        return sangkatCommuneService.getDTSangkatCommune(
                request,
                input,
                countryName,
                cityProvinceName,
                khanDistrictName,
                sangkatCommuneName,
                ngbssCommuneId,
                isActive);
    }
    
    @GetMapping("/all")
    public ResponseEntity<?> getAllSangkatCommunes(){
        List<SangkatCommuneDto> sangkatCommunes = sangkatCommuneService.getAllSangkatCommunesWhereIsActive();
        if(sangkatCommunes.isEmpty()){
            return new ResponseEntity<>("No data found!", HttpStatus.NO_CONTENT);
        }
        else return new ResponseEntity<>(sangkatCommunes, HttpStatus.OK);
    }
    
    @PostMapping("/add")
    public CommonRestResponse addSangkatCommune(HttpServletRequest request,
                                                @RequestBody SangkatCommuneDto sangkatCommuneDto) {
        return sangkatCommuneService.addSangkatCommune(request, sangkatCommuneDto);
    }
    
    @GetMapping("/details")
    public CommonRestResponse getSangkatCommuneById(@RequestParam("id") Long id) {
        return sangkatCommuneService.getSangkatCommuneById(id);
    }
    
    @PostMapping("/update")
    public CommonRestResponse updateSangkatCommune(HttpServletRequest request,
                                                   @RequestBody SangkatCommuneDto sangkatCommuneDto) {
        return sangkatCommuneService.updateSangkatCommune(request, sangkatCommuneDto);
    }
    
    @GetMapping("/byKhanDistrict")
    public List<SangkatCommuneDto> getAllByKhanDistrictId(@RequestParam("khanDistrictId") Long khanDistrictId) {
        return sangkatCommuneService.getAllSangkatCommunesWhereIsActiveByKhanDistrictId(khanDistrictId);
    }
    
}