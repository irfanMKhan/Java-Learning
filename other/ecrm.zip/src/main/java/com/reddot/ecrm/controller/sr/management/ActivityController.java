package com.reddot.ecrm.controller.sr.management;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.dto.GlobalSettings.User.UserModelSR;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.TitleModel;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.util.Utility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
public class ActivityController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    //ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

    TitleModel titleModel = new TitleModel();
    /*CommonDAO commonDAO = (CommonDAO) context.getBean("CommonDAO");*/

    @Autowired
    private CommonRepository commonDAO;

    @GetMapping(value = "/sr/activity/listOfActivity")
    public String listOfActivity(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        titleModel = new TitleModel("DCRM", "Actvity Management", "Activity List", "", "Activity List");
        model.put("title", titleModel);
        try {
            String query = "SELECT U.ID, U.NAME, U.LOGIN_NAME, U.EMAIL, U. USER_GROUP_ID, U.USER_GROUP_NAME, U.PRIMARY_RESP_ID, U.PRIMARY_RESP_NAME, U.POSITION_ID, U.WORK_PHONE, UD.SOURCE_ID, UD.SOURCE_LOCATION_ID, UD.POSITION_ORGANIZATION_ID, UD.POSITION_ORGANIZATION_NAME from MD_USER U LEFT JOIN MD_USER_DETAILS UD on U.ID=UD.USER_ID where U.ID=" + Utility.getUserId(request);
            Object object = commonDAO.CommoGetData(query);
            List<UserModelSR> userModelSR = new Gson().fromJson(Utility.ObjectToJson(object), new TypeToken<List<UserModelSR>>() {
            }.getType());
            model.put("loginUser", userModelSR.get(0));
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            e.printStackTrace();
        }
        return "ticket/activity/listOfActivity";
    }
}
