package com.reddot.ecrm.controller.cdr;

import com.reddot.ecrm.dto.cdr.CDRSearchDTO;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.service.cdr.CDRService;
import com.reddot.ecrm.service.pdfAndHotBill.HotBillService;
import com.reddot.ecrm.spring_config.ThreadPool.SingletonThreadPool;
import com.reddot.ecrm.spring_config.session.SessionManager;
import lombok.RequiredArgsConstructor;
import net.sf.jasperreports.engine.JRException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Controller
@RequiredArgsConstructor
@RequestMapping("/CDR/Report")
public class CDRController {

    private final CDRService cdrService;
    @Lazy
    private final ThreadPoolTaskExecutor threadPoolTaskExecutor = SingletonThreadPool.getInstance();
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    @Value("${CDR.day}")
    String day;
    @GetMapping
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        MDUserModel mdUserModel = SessionManager.getUserDetails(request);

        model.put("title", "CDR Report");
        model.put("userType", mdUserModel.getUSER_TYPE().toUpperCase().toString());
        model.put("currentDate", new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
        model.put("day", day);
        return "CDR/index";
    }

    @RequestMapping(value = "/download", method = RequestMethod.POST)
    @ResponseBody
    public void download(HttpServletRequest request, HttpServletResponse response, @RequestBody CDRSearchDTO searchDTO) throws UnsupportedEncodingException, ExecutionException, InterruptedException {
        CompletableFuture<Void> completableFuture = CompletableFuture.supplyAsync(() -> {
            System.out.println("Thread Name: " + Thread.currentThread().getName());
            try {
                cdrService.download(request, response, searchDTO);
            } catch (JRException e) {
                logger.error("CDRController: download:{0} " + e.getMessage());
                throw new RuntimeException(e);

            }
            return null;
        }, threadPoolTaskExecutor);
        completableFuture.get();
        //cdrService.download(request, response, searchDTO);
    }
}
