package com.reddot.ecrm.dto.agreement.simOrMobile;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SimOrMobileDTO {
    private String subscriberName;
    private String subscriberPosition;
    private String subscriberDate;

    private String uniqueNumber;
    private String templateName;
}
