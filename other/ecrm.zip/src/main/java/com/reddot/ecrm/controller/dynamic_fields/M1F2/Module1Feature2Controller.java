package com.reddot.ecrm.controller.dynamic_fields.M1F2;

public class Module1Feature2Controller {
}
