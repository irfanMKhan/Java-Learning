package com.reddot.ecrm.controller.approval.approval_flow;

import com.reddot.ecrm.entity.approval.ApprovalFlowEntity;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.repository.approval.ApprovalFlowRepo;
import com.reddot.ecrm.service.approval.ApprovalFlowService;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/approval")
public class ApprovalFlowController {
    @Autowired
    ApprovalFlowService approvalFlowService;

    @Autowired
    ApprovalFlowRepo approvalFlowRepo;

    @GetMapping("/flow")
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Approval Flow");
        model.addAttribute("breadcrumb", "Approval Flow");
        return "approval/approval_flow";
    }
}
