package com.reddot.ecrm.delayPayment;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PromiseToPayRepo extends JpaRepository<PromiseToPay, Long>, JpaSpecificationExecutor<PromiseToPay> {

    List<PromiseToPay> findAllByAccountCode(String accountCode);
}
