package com.reddot.ecrm.api.payload.response.shared.account;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SmartErrorResponse implements Serializable {
    private Error error;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Error implements Serializable {
        private String exception;

        private String code;

        private String detail;

        private String message;
    }
}
