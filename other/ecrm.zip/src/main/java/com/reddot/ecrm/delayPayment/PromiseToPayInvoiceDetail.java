package com.reddot.ecrm.delayPayment;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PromiseToPayInvoiceDetail {
//    private String invoiceID;
//    private String serviceCategory;
//    private String chargeCode;
//    private String chargeAmount;
}
