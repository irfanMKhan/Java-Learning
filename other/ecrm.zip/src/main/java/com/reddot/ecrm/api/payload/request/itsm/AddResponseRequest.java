package com.reddot.ecrm.api.payload.request.itsm;

import lombok.Data;

import java.io.Serializable;
import java.lang.Integer;
import java.lang.String;

@Data
public class AddResponseRequest implements Serializable {
  private Threads threads;

  @Data
  public static class Threads implements Serializable {
    private EntryType entryType;

    private String text;

    private EntryType contentType;

    @Data
    public static class EntryType implements Serializable {
      private Integer id;
    }
  }
}
