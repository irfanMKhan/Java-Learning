package com.reddot.ecrm.api;

import com.reddot.ecrm.api.gateway.CommonGateway;
import com.reddot.ecrm.api.gateway.contract.ContractGateway;
import com.reddot.ecrm.api.gateway.itsm.ITSMGateway;
import com.reddot.ecrm.api.gateway.lead.LeadGateway;
import com.reddot.ecrm.api.gateway.payment.PaymentGateway;
import com.reddot.ecrm.api.gateway.plan.PlanGateway;
import com.reddot.ecrm.api.gateway.post2pre.PostpaidToPrepaidGateway;
import com.reddot.ecrm.api.gateway.pre2post.PrepaidToPostpaidGateway;
import com.reddot.ecrm.api.gateway.subscriber.SubscriberGateway;
import com.reddot.ecrm.api.gateway.transferOwnership.TransferOwnershipGateway;
import com.reddot.ecrm.api.payload.request.contract.account.CreateCorporateAccountRequest;
import com.reddot.ecrm.api.payload.request.contract.branch.ChangeCorporateGroupMemberInfoRequest;
import com.reddot.ecrm.api.payload.request.contract.customer.CreateCorporateCustomerRequest;
import com.reddot.ecrm.api.payload.request.contract.group.CreateCUGGroupRequest;
import com.reddot.ecrm.api.payload.request.contract.group.QueryGroupMemberRequest;
import com.reddot.ecrm.api.payload.request.contract.order.CreateOrderRequest;
import com.reddot.ecrm.api.payload.request.contract.payment.ChangeCorporateAccountPaymentRelationRequest;
import com.reddot.ecrm.api.payload.request.contract.subscriber.CreateCorporateSubscriberRequest;
import com.reddot.ecrm.api.payload.request.itsm.*;
import com.reddot.ecrm.api.payload.request.opportunity.ReserveListMSISDNRequest;
import com.reddot.ecrm.api.payload.request.opportunity.ReserveRequest;
import com.reddot.ecrm.api.payload.request.payment.CreatePAMultiInvoiceRequest;
import com.reddot.ecrm.api.payload.request.payment.CreatePARequestReq;
import com.reddot.ecrm.api.payload.request.payment.QueryInvoiceAPIRequest;
import com.reddot.ecrm.api.payload.request.plan.ChangePrimaryOfferingRequest;
import com.reddot.ecrm.api.payload.request.post2pre.PostpaidToPrepaidRequest;
import com.reddot.ecrm.api.payload.request.pre2post.BssSubscribersPrepaidToPostpaidRequest;
import com.reddot.ecrm.api.payload.request.shared.account.*;
import com.reddot.ecrm.api.payload.request.shared.group.AddCorporateGroupRequest;
import com.reddot.ecrm.api.payload.request.shared.group.AddGroupCUGRequest;
import com.reddot.ecrm.api.payload.request.shared.group.DeleteCorporateGroupMemberRequest;
import com.reddot.ecrm.api.payload.request.shared.offering.ChangeSupplementaryOfferingRequest;
import com.reddot.ecrm.api.payload.request.subscriber.ChangeSubscriberMSISDNRequest;
import com.reddot.ecrm.api.payload.request.subscriber.ChangeSubscriberSIMRequest;
import com.reddot.ecrm.api.payload.request.subscriber.ReportLostRequest;
import com.reddot.ecrm.api.payload.request.subscriber.ResetNetworkRequest;
import com.reddot.ecrm.api.payload.request.transferOwnership.ChangeSubscriberStatusRequest;
import com.reddot.ecrm.api.payload.response.branch.ChangeCorporateGroupMemberInfoResponse;
import com.reddot.ecrm.api.payload.response.contract.account.CreateCorporateAccountResponse;
import com.reddot.ecrm.api.payload.response.contract.account.QueryAccountInformationResponse;
import com.reddot.ecrm.api.payload.response.contract.account.QueryBalanceResponse;
import com.reddot.ecrm.api.payload.response.contract.account.QueryPurchasedSupplementaryOfferingResponse;
import com.reddot.ecrm.api.payload.response.contract.customer.*;
import com.reddot.ecrm.api.payload.response.contract.group.CreateCUGGroupResponse;
import com.reddot.ecrm.api.payload.response.contract.group.QueryGroupMemberResponse;
import com.reddot.ecrm.api.payload.response.contract.order.CreateOrderResponse;
import com.reddot.ecrm.api.payload.response.contract.payment.ChangeCorporateAccountPaymentRelationResponse;
import com.reddot.ecrm.api.payload.response.contract.subscriber.CreateCorporateSubscriberResponse;
import com.reddot.ecrm.api.payload.response.itsm.*;
import com.reddot.ecrm.api.payload.response.lead.CheckCoverageResponse;
import com.reddot.ecrm.api.payload.response.opportunity.*;
import com.reddot.ecrm.api.payload.response.payment.CreatePAResponse;
import com.reddot.ecrm.api.payload.response.payment.QueryDepositAmountResponse;
import com.reddot.ecrm.api.payload.response.payment.QueryInvoiceResponse;
import com.reddot.ecrm.api.payload.response.plan.ChangePrimaryOfferingResponse;
import com.reddot.ecrm.api.payload.response.post2pre.PostpaidToPrepaidResponse;
import com.reddot.ecrm.api.payload.response.pre2post.PrepaidToPostpaidResponse;
import com.reddot.ecrm.api.payload.response.pre2post.QueryDebitnoteResponse;
import com.reddot.ecrm.api.payload.response.shared.account.ChangeAccountCreditLimitResponse;
import com.reddot.ecrm.api.payload.response.shared.account.ChangeAccountInformationCommonResponse;
import com.reddot.ecrm.api.payload.response.shared.account.CreditNoteResponse;
import com.reddot.ecrm.api.payload.response.shared.account.DebitNoteResponse;
import com.reddot.ecrm.api.payload.response.shared.group.*;
import com.reddot.ecrm.api.payload.response.shared.offering.ChangeSupplementaryOfferingResponse;
import com.reddot.ecrm.api.payload.response.shared.subscriber.SubscriberInfoResponse;
import com.reddot.ecrm.api.payload.response.shared.subscriber.SubscriberLifeCycleResponse;
import com.reddot.ecrm.api.payload.response.shared.subscriber.SubscriberStatusResponse;
import com.reddot.ecrm.api.payload.response.subscriber.ChangeSubscriberMSISDNResponse;
import com.reddot.ecrm.api.payload.response.subscriber.ChangeSubscriberSIMResponse;
import com.reddot.ecrm.api.payload.response.subscriber.ReportLostResponse;
import com.reddot.ecrm.api.payload.response.subscriber.ResetNetworkResponse;
import com.reddot.ecrm.api.payload.response.transferOwnership.ChangeSubscriberStatusResponse;
import com.reddot.ecrm.model.itsm.CreateServiceRequestResponseModel;
import com.reddot.ecrm.service.SequenceGeneratorService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.util.List;

@Service
@RequiredArgsConstructor
public class SmartAxiataAPI {
    private final LeadGateway leadGateway;
    private final ContractGateway contractGateway;
    private final CommonGateway commonGateway;
    private final PaymentGateway paymentGateway;
    private final SubscriberGateway subscriberGateway;
    private final PrepaidToPostpaidGateway prepaidToPostpaidGateway;
    private final PostpaidToPrepaidGateway postpaidToPrepaidGateway;
    private final TransferOwnershipGateway transferOwnershipGateway;
    private final PlanGateway planGateway;
    private final ITSMGateway itsmGateway;

    @Value("${smart.bss.username}")
    String smart_bss_username;
    @Value("${smart.bss.password}")
    String smart_bss_password;
    @Value("${smart.query.supplementary.offering.partnerId}")
    String smart_partnerId;
    @Value("${smart.query.supplementary.offering.transactionId}")
    String smart_transactionId;
    @Value("${smart.query.supplementary.offering.channel}")
    String smart_channel;

    public ReserveResponse reserve(String msisdn, ReserveRequest reserveRequest) {
        return commonGateway.reserve(msisdn, reserveRequest);
    }

    public UnReserveMSISDNResponse unReserve(String msisdn, ReserveRequest unReserve) {
        return commonGateway.unReserve(msisdn, unReserve);
    }

    public ReserveListMSISDNResponse reserveListMSISDN(ReserveListMSISDNRequest reserveListMSISDNRequest) {
        return commonGateway.reserveListMSISDN(reserveListMSISDNRequest);
    }

    public QueryInventoryMSISDNResponse queryInventoryMSISDN(String page, String pageSize, String categoryId, String prefix, String msisdn) throws UnsupportedEncodingException {
        return commonGateway.queryInventoryMSISDN(page, pageSize, categoryId, prefix, msisdn);
    }

    public CRMInventoryResponse crmInventory(String deptId, String status, String category, String prefix, String startRow, String endRow, String MSISDNPattern, String startRange, String endRange) {
        return commonGateway.crmInventory(deptId, status, category, prefix, startRow, endRow, MSISDNPattern, startRange, endRange);
    }

    public SearchInventoryByListMSISDNResponse searchInventoryByListMSISDN(String bssUsername, String bssPassword, String departmentId, String status, String msisdnList, String startRow, String totalRow, String fetchRow) {
        return commonGateway.searchInventoryByListMSISDN(bssUsername, bssPassword, departmentId, status, msisdnList, startRow, totalRow, fetchRow);
    }

    public CheckCoverageResponse checkCoverage(String latitude, String longitude) {
        return leadGateway.checkCoverage(latitude, longitude);
    }

    public QueryPurchasedSupplementaryOfferingResponse queryPurchasedSupplementaryOffering(String objectIdType, String objectId) throws UnsupportedEncodingException {
        String requestTime = SequenceGeneratorService.generateSequenceNumberAsDateTime();
        return contractGateway.queryPurchasedSupplementaryOffering(smart_partnerId, smart_transactionId, requestTime, smart_channel, smart_bss_username, smart_bss_password, objectIdType, objectId);
    }

    public CBSBCCustomerResponse cbsbcCustomer(String msisdn) throws UnsupportedEncodingException {
        return contractGateway.cbsbcCustomer(msisdn, smart_bss_username, smart_bss_password);
    }

    public CreateCorporateCustomerResponse createCorporateCustomer(CreateCorporateCustomerRequest createCorporateCustomerRequest) {
        return contractGateway.createCorporateCustomer(createCorporateCustomerRequest);
    }


    public CreateCorporateAccountResponse createCorporateAccount(CreateCorporateAccountRequest accountReq) {
        return contractGateway.createCorporateAccount(accountReq);
    }


    public ChangeAccountCreditLimitResponse changeAccountCreditLimit(ChangeAccountCreditLimitRequest creditLimitRequest) {
        return commonGateway.changeAccountCreditLimit(creditLimitRequest);
    }


    public ChangeSupplementaryOfferingResponse changeSupplementaryOffering(ChangeSupplementaryOfferingRequest offeringRequest) {
        return commonGateway.changeSupplementaryOffering(offeringRequest);
    }


    public AddCorporateGroupResponse addCorporateGroup(AddCorporateGroupRequest groupReq) {
        return commonGateway.addCorporateGroup(groupReq);
    }

    public DebitNoteResponse debitNote(String accAccessCodeAccCode, DebitNoteRequest debitNoteRequest) {
        return commonGateway.debitNote(accAccessCodeAccCode, debitNoteRequest);
    }


    public CreditNoteResponse creditNote(String accAccessCodeAccCode, CreditNoteRequest creditNoteRequest) {
        return commonGateway.creditNote(accAccessCodeAccCode, creditNoteRequest);
    }

    public CreditNoteResponse creditNoteV2(String accAccessCodeAccCode, CreditNoteReqV2 creditNoteReqV2) {
        return commonGateway.creditNoteV2(accAccessCodeAccCode, creditNoteReqV2);
    }

    public ChangeAccountInformationCommonResponse changeAccountInformation(String accountId, ChangeAccountInformationRequest accountInformationRequest) {
        return commonGateway.changeAccountInformation(accountId, accountInformationRequest);
    }


    public AddCUGGrpCommonResponse addGroupCUG(AddGroupCUGRequest addGroupCUGRequest, String memberId) {
        AddCUGGrpCommonResponse response = new AddCUGGrpCommonResponse();
        try {
            AddGroupCUGResponse addGroupCUGResponse = commonGateway.addGroupCUG(addGroupCUGRequest, memberId);
            response.setIsSuccess(true);
            response.setCode("0000");
            response.setMessage(addGroupCUGResponse.getTransaction_status());
        } catch (Exception e) {
            response.setIsSuccess(false);
            response.setCode("400");
            response.setMessage(e.getMessage());
        }
        return response;
    }

    public List<QueryDebitnoteResponse> queryDebitNote(String extTransId) {
        return commonGateway.queryDebitNote(extTransId);
    }


//    public CreateCorporateAccountSubResponse createCorporateAccountSub(CreateCorporateAccountSubRequest accountSubReq) {
//        return contractGateway.createCorporateAccountSub(accountSubReq);
//    }

    public QryCorporateEntityIdsResponse queryCorporateEntityIds(String objectType, String custName) throws UnsupportedEncodingException {
        return contractGateway.qryCorporateEntityIds(objectType, custName);
    }

    public QryEntityIdsResponseIGW qryCorporateEntityIdsNewIGW(String custName) throws UnsupportedEncodingException {
        return contractGateway.qryCorporateEntityIdsNewIGW(custName);
    }


    public QueryCorporateCustResponse queryCorporateCustomer(String version,
                                                             String partnerId,
                                                             String businessCode,
                                                             String transactionId,
                                                             String reqTime,
                                                             String channel,
                                                             String accessUser,
                                                             String accessPassword,
                                                             String corporateName) throws UnsupportedEncodingException {
        return contractGateway.queryCorporateCustomer(version,
                partnerId,
                businessCode,
                transactionId,
                reqTime,
                channel,
                accessUser,
                accessPassword,
                corporateName);
    }


    public QueryAccountInformationResponse queryAccountInformation(String version,
                                                                   String partnerId,
                                                                   String transactionId,
                                                                   String reqTime,
                                                                   String channel,
                                                                   String accessUser,
                                                                   String accessPassword,
                                                                   String objectIdType,
                                                                   String objectId) throws UnsupportedEncodingException {
        return contractGateway.queryAccountInformation(version,
                partnerId,
                transactionId,
                reqTime,
                channel,
                accessUser,
                accessPassword,
                objectIdType,
                objectId);
    }


    public QueryBalanceResponse queryBalance(String version, String businessCode, String transactionId, String reqTime, String channel, String accessUser, String accessPassword, String objectIdType, String objectId) throws UnsupportedEncodingException {
        return contractGateway.queryBalance(version, businessCode, transactionId, reqTime, channel, accessUser, accessPassword, objectIdType, objectId);
    }


    public CreateOrderResponse createOrder(CreateOrderRequest orderReq) {
        return contractGateway.createOrder(orderReq);
    }


    public QueryGroupMemberResponse queryGroupMember(QueryGroupMemberRequest groupMemberReq) {
        return contractGateway.queryGroupMember(groupMemberReq);
    }


    public CreateCorporateSubscriberResponse createCorporateSubscriber(CreateCorporateSubscriberRequest subscriberReq) {
        return contractGateway.createCorporateSubscriber(subscriberReq);
    }


//    public CreateCorporateSubscriberSubResponse createCorporateSubscriberSub(CreateCorporateSubscriberSubRequest subscriberSubReq) {
//        return contractGateway.createCorporateSubscriberSub(subscriberSubReq);
//    }


    public CreateCUGGroupResponse createCUGGroup(CreateCUGGroupRequest cugGroupRequest) {
        return contractGateway.createCUGGroup(cugGroupRequest);
    }


    public ChangeCorporateAccountPaymentRelationResponse changeCorporateAccountPaymentRelation(ChangeCorporateAccountPaymentRelationRequest paymentRelationRequest) {
        return contractGateway.changeCorporateAccountPaymentRelation(paymentRelationRequest);
    }

    public QueryInvoiceResponse queryInvoice(QueryInvoiceAPIRequest queryInvoiceRequest) {
        return paymentGateway.queryInvoice(queryInvoiceRequest);
    }

    public CreatePAResponse createPA(CreatePARequestReq createPARequestReq) {
        return paymentGateway.createPA(createPARequestReq);
    }

    public CreatePAResponse createPAMultipleInvoice(CreatePAMultiInvoiceRequest createPAMultiInvoiceRequest) {
        return paymentGateway.createPAMultipleInvoice(createPAMultiInvoiceRequest);
    }

    public ChangeSubscriberStatusResponse changeSubscriberStatus(String subscriberId, ChangeSubscriberStatusRequest request) {
        return transferOwnershipGateway.changeSubscriberStatus(subscriberId, request);
    }

    public QueryDepositAmountResponse queryDepositAmount(String accountCode, String tranId) {
        return paymentGateway.queryDepositAmount(accountCode, tranId);
    }

    public PrepaidToPostpaidResponse bssSubscribersPrepaidToPostpaid(String subscriberId, BssSubscribersPrepaidToPostpaidRequest bssSubscribersPrepaidToPostpaidRequest) {
        return prepaidToPostpaidGateway.bssSubscribersPrepaidToPostpaid(subscriberId, bssSubscribersPrepaidToPostpaidRequest);

    }


    public DebitNoteResponse apiDebitNote(String accAccessCodeAccCode, DebitNoteRequest debitNoteRequest) {
        return commonGateway.debitNote(accAccessCodeAccCode, debitNoteRequest);
    }


//    public List<QueryDebitnoteResponse> queryDebitNote(String extTransId) {
//        return commonGateway.queryDebitNote(extTransId);
//    }


    public CreditNoteResponse apiCreditNote(String accAccessCodeAccCode, CreditNoteRequest creditNoteRequest) {
        return commonGateway.creditNote(accAccessCodeAccCode, creditNoteRequest);
    }


    public QueryPurchasedSupplementaryOfferingResponse queryPurchasedSupplementaryOffering(String partnerId, String transactionId, String reqTime, String channel, String accessUser, String accessPassword, String objectIdType, String objectId) throws UnsupportedEncodingException {
        return commonGateway.queryPurchasedSupplementaryOffering(partnerId, transactionId, reqTime, channel, accessUser, accessPassword, objectIdType, objectId);
    }


//    public ChangeSupplementaryOfferingResponse changeSupplementaryOffering(ChangeSupplementaryOfferingRequest offeringRequest) {
//        return commonGateway.changeSupplementaryOffering(offeringRequest);
//    }


//    public BssSubscribersPrepaidToPostpaidResponse bssSubscribersPrepaidToPostpaid(String subscriberId,BssSubscribersPrepaidToPostpaidRequest bssSubscribersPrepaidToPostpaidRequest) {
//        return prepaidToPostpaidGateway.bssSubscribersPrepaidToPostpaid(subscriberId,bssSubscribersPrepaidToPostpaidRequest);
//
//    }


//    public ChangeAccountCreditLimitResponse changeAccountCreditLimit(ChangeAccountCreditLimitRequest creditLimitRequest) {
//        return commonGateway.changeAccountCreditLimit(creditLimitRequest);
//    }
//
//
//    public AddCorporateGroupResponse addCorporateGroup(AddCorporateGroupRequest groupReq) {
//        return commonGateway.addCorporateGroup(groupReq);
//    }
//
//
//    public AddGroupCUGResponse addGroupCUG(AddGroupCUGRequest addGroupCUGRequest, String groupId) {
//        return commonGateway.addGroupCUG(addGroupCUGRequest,groupId);
//    }
//
//
//    public ChangeAccountInformationResponse changeAccountInformation(String accountId, ChangeAccountInformationRequest accountInformationRequest) {
//        return commonGateway.changeAccountInformation(accountId, accountInformationRequest);
//    }


    public ReportLostResponse reportLost(String subscriberId, ReportLostRequest lostRequest) {
        return subscriberGateway.reportLost(subscriberId, lostRequest);
    }

    public ReportLostResponse cancelLost(String subscriberId, ReportLostRequest lostRequest) {
        return subscriberGateway.cancelLost(subscriberId, lostRequest);
    }

    public ChangeSubscriberMSISDNResponse changeSubscriberMSISDN(String subscriberId, ChangeSubscriberMSISDNRequest subscriberMSISDNRequest) {
        return subscriberGateway.changeSubscriberMSISDN(subscriberId, subscriberMSISDNRequest);
    }

    public ChangeSubscriberSIMResponse changeSubscriberSIM(String subscriberId, ChangeSubscriberSIMRequest subscriberSIMRequest) {
        return subscriberGateway.changeSubscriberSIM(subscriberId, subscriberSIMRequest);
    }

    public SubscriberInfoResponse subscriberInfo(String subscriberId, String bssUsername, String bssPassword) throws UnsupportedEncodingException {
        return subscriberGateway.subscriberInfo(subscriberId, bssUsername, bssPassword);
    }

    public SubscriberLifeCycleResponse subscriberLifeCycle(String subscriberId, String bssUsername, String bssPassword) throws UnsupportedEncodingException {
        return subscriberGateway.subscriberLifeCycle(subscriberId, bssUsername, bssPassword);
    }

    public SubscriberStatusResponse subscriberStatus(String subscriberId, String bssUsername, String bssPassword) throws UnsupportedEncodingException {
        return subscriberGateway.subscriberStatus(subscriberId, bssUsername, bssPassword);
    }

    public ResetNetworkResponse resetNetwork(String subscriberId, ResetNetworkRequest resetNetworkRequest) {
        return subscriberGateway.resetNetwork(subscriberId, resetNetworkRequest);
    }


    public DeleteCorporateGroupMemberResponse deleteCorporateGroupMember(DeleteCorporateGroupMemberRequest groupMemberRequest) {
        return commonGateway.deleteCorporateGroupMember(groupMemberRequest);
    }


    public DeleteCUGGroupMemberResponse deleteCUGGroupMember(String groupId, String idType, String memberId, String transaction_id) throws UnsupportedEncodingException {
        return commonGateway.deleteCUGGroupMember(groupId, idType, memberId, transaction_id);
    }


    public PostpaidToPrepaidResponse postpaidToPrepaid(String subscriberId, PostpaidToPrepaidRequest postpaidToPrepaidRequest) {
        return postpaidToPrepaidGateway.postpaidToPrepaid(subscriberId, postpaidToPrepaidRequest);
    }

    public ChangePrimaryOfferingResponse changePrimaryOffering(ChangePrimaryOfferingRequest primaryOfferingRequest) {
        return planGateway.changePrimaryOffering(primaryOfferingRequest);
    }

    public FetchContactIdByEmailResponse fetchContactIdByEmail(String email) {
        return itsmGateway.fetchContactIdByEmail(email);
    }

    public FetchContactIdByEmailResponse fetchContactId() {
        return itsmGateway.fetchContactId();
    }


    public String addNewCategory(AddNewCategoryRequest addNewCategoryRequest) {
        return itsmGateway.addNewCategory(addNewCategoryRequest);
    }


    public String addResponse(String incidentId, AddResponseRequest addResponseRequest) {
        return itsmGateway.addResponse(incidentId, addResponseRequest);
    }


    public FetchServiceRequestDetailsResponse fetchServiceRequestDetails(String incidentId) {
        return itsmGateway.fetchServiceRequestDetails(incidentId);
    }


    public UploadFileAttachmentResponse uploadFileAttachment(String incidentId, UploadFileAttachmentRequest uploadFileAttachmentRequest) {
        return itsmGateway.uploadFileAttachment(incidentId, uploadFileAttachmentRequest);
    }


    public GetFileAttachmentsResponse fileAttachmentsResponse(String incidentId) {
        return itsmGateway.fileAttachmentsResponse(incidentId);
    }


    public DownloadFileAttachmentResponseData downloadFileAttachmentData(String incidentId, String attachmentId) {
        return itsmGateway.downloadFileAttachmentData(incidentId, attachmentId);
    }

    public DownloadFileAttachmentResponse downloadFileAttachmentResponse(String incidentId, String attachmentId) {
        return itsmGateway.downloadFileAttachmentResponse(incidentId, attachmentId);
    }


    public String deleteFileAttachment(String incidentId, String attachmentId) {
        return itsmGateway.deleteFileAttachment(incidentId, attachmentId);
    }


    public CreateServiceRequestResponseModel createServiceRequest(CreateServiceRequest createServiceRequest) {
        return itsmGateway.createServiceRequest(createServiceRequest);
    }


    public CreateServiceRequestResponseModel changePostpaidToPrepaid(ChangePostpaidToPrepaidRequest changePostpaidToPrepaidRequest) {
        return itsmGateway.changePostpaidToPrepaid(changePostpaidToPrepaidRequest);
    }

    public ChangeCorporateGroupMemberInfoResponse changeCorporateGroupMemberInfo(ChangeCorporateGroupMemberInfoRequest groupMemberInfoRequest) {
        return contractGateway.changeCorporateGroupMemberInfo(groupMemberInfoRequest);
    }
}
