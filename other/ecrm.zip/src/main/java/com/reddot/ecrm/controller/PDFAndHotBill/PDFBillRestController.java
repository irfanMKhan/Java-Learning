package com.reddot.ecrm.controller.PDFAndHotBill;

import com.reddot.ecrm.api.payload.request.notification.SendSMSRequest;
import com.reddot.ecrm.dto.PDFAndHotBill.PDFCustomSearchDTO;
import com.reddot.ecrm.dto.PDFAndHotBill.PDFFileDTO;
import com.reddot.ecrm.dto.PDFAndHotBill.SendEmailDTO;
import com.reddot.ecrm.entity.company.CompanyAccountEntity;
import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.service.pdfAndHotBill.PDFBillService;
import com.reddot.ecrm.service.sendSMS.SendSMSService;
import com.reddot.ecrm.spring_config.session.SessionManager;
import freemarker.template.TemplateException;
import lombok.RequiredArgsConstructor;
import org.apache.catalina.User;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/PDFBill/Report")
public class PDFBillRestController {

    private final PDFBillService pdfBillService;
    private final SendSMSService sendSMSService;


    @PostMapping(value = "/search", consumes = MediaType.APPLICATION_JSON_VALUE)
    public List<PDFFileDTO> search(@Valid @RequestBody PDFCustomSearchDTO searchPDFAndHotBillDTO, @Valid DataTablesInput input, HttpServletRequest request) throws IllegalAccessException {
        return pdfBillService.getPDFAndHotBillQueryData(request, input, searchPDFAndHotBillDTO);
    }

    /*@RequestMapping(value = "/getCompany", method = RequestMethod.GET)
    public List<CompanyEntity> getCompany(HttpServletRequest request) {
        return pdfBillService.getAllCompany();
    }*/
    @RequestMapping(value = "/getCompany", method = RequestMethod.GET)
    public List<CompanyEntity> getCompany(HttpServletRequest request) {
        return pdfBillService.GetAllCompanyNameWithContactTablePICMapped(request);
    }

    @RequestMapping(value = "/getAccountCode", method = RequestMethod.GET)
    public List<CompanyAccountEntity> getAccountCode(@RequestParam("companyId") Long companyId) {
        return pdfBillService.getAllAccountCode(companyId);
    }

    @PostMapping(value = "/sendEmail", consumes = MediaType.APPLICATION_JSON_VALUE)
    public String sendEmail(HttpServletRequest request, @Valid @RequestBody SendEmailDTO sendEmailDTO) throws MessagingException, TemplateException, IOException {
        return pdfBillService.sendMail(sendEmailDTO.getDefaultEmail(), sendEmailDTO.getAlterEmail(), sendEmailDTO.getFileName(), request);
    }

    //for SMS API Testing
    /*@PostMapping(value = "/sendEmail", consumes = MediaType.APPLICATION_JSON_VALUE)
    public String sendEmail(HttpServletRequest request, @Valid @RequestBody SendEmailDTO sendEmailDTO) throws MessagingException, TemplateException, IOException {
        List<String> address=new ArrayList<>();
        address.add("tel:+85510202606");

        SendSMSRequest sendSMSRequest = new SendSMSRequest();

        SendSMSRequest.OutboundSMSMessageRequest outboundSMSMessageRequest = new SendSMSRequest.OutboundSMSMessageRequest();
        SendSMSRequest.OutboundSMSMessageRequest.ReceiptRequest receiptRequest=new SendSMSRequest.OutboundSMSMessageRequest.ReceiptRequest();
        SendSMSRequest.OutboundSMSMessageRequest.OutboundSMSTextMessage outboundSMSTextMessage=new SendSMSRequest.OutboundSMSMessageRequest.OutboundSMSTextMessage();

        outboundSMSMessageRequest.setSenderAddress("tel:888");
        outboundSMSMessageRequest.setSenderName("Smart");
        outboundSMSMessageRequest.setAddress(address);
        outboundSMSMessageRequest.setClientCorrelator("ECRM:SMS123456BB898");

        receiptRequest.setCallbackData("");
        receiptRequest.setNotifyURL("");
        outboundSMSTextMessage.setMessage("This is the message from Teng 1");

        outboundSMSMessageRequest.setReceiptRequest(receiptRequest);
        outboundSMSMessageRequest.setOutboundSMSTextMessage(outboundSMSTextMessage);

        sendSMSRequest.setOutboundSMSMessageRequest(outboundSMSMessageRequest);
        sendSMSService.sendSMS(sendSMSRequest);
        return "Success";
    }*/
}
