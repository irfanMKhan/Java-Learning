package com.reddot.ecrm.api.payload.response.lead;

import lombok.Data;

import java.io.Serializable;

@Data
public class CheckCoverageErrorResponse implements Serializable {
  private Fault fault;

  @Data
  public static class Fault implements Serializable {
    private Integer code;

    private String description;

    private String message;
  }

}
