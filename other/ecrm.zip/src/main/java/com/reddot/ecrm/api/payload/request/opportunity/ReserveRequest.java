package com.reddot.ecrm.api.payload.request.opportunity;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
public class ReserveRequest implements Serializable {

    private Metadata metadata;

    private String correlation_id;

    private Reservation reservation;

    @Data
    @AllArgsConstructor
    public static class Metadata implements Serializable {
        private Integer store_id;

        private Integer channel_id;
    }

    @Data
    @AllArgsConstructor
    public static class Reservation implements Serializable {
        private String description;

        private String release_time;
    }
}
