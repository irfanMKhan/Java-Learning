package com.reddot.ecrm.controller.sr.management;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.dto.GlobalSettings.AccountClass.MDAccountClassModel;
import com.reddot.ecrm.dto.GlobalSettings.AccountType.MDAccountTypeModel;
import com.reddot.ecrm.dto.GlobalSettings.SourceList.MDSourceListModel;
import com.reddot.ecrm.dto.GlobalSettings.SourceLocation.MDSourceLocationModel;
import com.reddot.ecrm.dto.GlobalSettings.position.MDUserPosition;
import com.reddot.ecrm.dto.sr.management.*;
import com.reddot.ecrm.dto.srsettings.Area.MDSrAreaModel;
import com.reddot.ecrm.dto.srsettings.Priority.MDSrPriorityModel;
import com.reddot.ecrm.dto.srsettings.RootCause.MDSrRootCauseModel;
import com.reddot.ecrm.dto.srsettings.RoutingGroup.SRRoutingGroupModel;
import com.reddot.ecrm.dto.srsettings.ServiceType.MDSrServiceTypeModel;
import com.reddot.ecrm.dto.srsettings.Severity.MDSrSeverityModel;
import com.reddot.ecrm.dto.srsettings.Status.MDSrStatusModel;
import com.reddot.ecrm.dto.srsettings.Type.SRTypeModel;
import com.reddot.ecrm.dto.srsettings.subarea.*;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.model.creation.DemographicInformationModel;
import com.reddot.ecrm.model.lov.CommonLovModel;
import com.reddot.ecrm.repository.AccountServiceRepository;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.service.manageservice.ManageService;
import com.reddot.ecrm.session.SessionConstants;
import com.reddot.ecrm.spring_config.session.SessionManager;
import com.reddot.ecrm.util.GenerateCSV;
import com.reddot.ecrm.util.QueryBuilder;
import com.reddot.ecrm.util.Utility;
import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class SRManagementQueryService {

    //    ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
    Logger logger = LoggerFactory.getLogger("SRSettingsLogger");
//    AccountServiceDAO accountserviceDAO = (AccountServiceDAO) context.getBean("AccountServiceDAO");

    private final Logger responseTrackerLogger = LoggerFactory.getLogger("responseTrackerLogger");

    @Autowired
    private AccountServiceRepository accountserviceDAO;

    @Autowired
    private CommonRepository commonDAO;

    @Autowired
    private ManageService manageService;

    public SRLoadDataQueryModel getSRTypeList(HttpServletRequest request) {

        List<CommonLovModel> srTypeList = new ArrayList<>();
        List<SRRoutingGroupModel> mdRoutingList = new ArrayList<SRRoutingGroupModel>();
        List<MDSrSeverityModel> srserList = new ArrayList<MDSrSeverityModel>();
        List<MDSrRootCauseModel> causeList = new ArrayList<MDSrRootCauseModel>();
        List<MDSourceListModel> SourceList = new ArrayList<MDSourceListModel>();
        List<MDSourceLocationModel> sourceLocList = new ArrayList<MDSourceLocationModel>();
        List<MDSrStatusModel> statusList = new ArrayList<>();
        String nextId = "";
        String lastQueriedMsisdn = "";
        try {
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            SearchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");

            // Type
            Object objects = commonDAO.getDataPostgres("SELECT NAME,ID, ACTIVE, SR_SERVICE_TYPE_NAME, SR_SERVICE_TYPE_ID FROM (SELECT SR_TYPE_NAME AS NAME, SR_TYPE_ID AS ID, ACTIVE, SR_SERVICE_TYPE_NAME, SR_SERVICE_TYPE_ID,  ROW_NUMBER() OVER(PARTITION BY SR_TYPE_NAME ORDER BY SR_TYPE_NAME) rn FROM " + Utility.md_sr_sub_area + " where active=1) t WHERE rn = 1 order by NAME");
            srTypeList = new Gson().fromJson(Utility.ObjectToJson(objects), new TypeToken<List<CommonLovModel>>() {
            }.getType());

            Object mdRouting = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_routing_group, SearchData, "ID,NAME,OWNER_NAME,OWNER_ID", whereSearchType));
            mdRoutingList = new Gson().fromJson(Utility.ObjectToJson(mdRouting), new TypeToken<List<SRRoutingGroupModel>>() {
            }.getType());

            // Severity
            Object ssl = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_severity, SearchData, "ID,NAME", whereSearchType));
            srserList = new Gson().fromJson(Utility.ObjectToJson(ssl), new TypeToken<List<MDSrSeverityModel>>() {
            }.getType());

            // root cause
            Object rc = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_root_cause, SearchData, "ID,NAME", whereSearchType));
            causeList = new Gson().fromJson(Utility.ObjectToJson(rc), new TypeToken<List<MDSrRootCauseModel>>() {
            }.getType());

            // source
            Object srclist = commonDAO.getDataPostgres("SELECT ID,NAME FROM MD_SRC WHERE ACTIVE=1 ORDER BY ORDER_BY,NAME ASC");
            SourceList = new Gson().fromJson(Utility.ObjectToJson(srclist), new TypeToken<List<MDSourceListModel>>() {
            }.getType());

            // source location
            Object srcloclistData = commonDAO.getDataPostgres("SELECT ID,NAME FROM MD_SRC_LOCATION WHERE ACTIVE=1 ORDER BY ORDER_BY,NAME ASC");
            sourceLocList = new Gson().fromJson(Utility.ObjectToJson(srcloclistData), new TypeToken<List<MDSourceListModel>>() {
            }.getType());


            SearchData.put("CREATION_STATUS", "1");
            whereSearchType.put("CREATION_STATUS", "AND");
            Object statusListObject = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_status, SearchData, "ID,NAME", whereSearchType));
            statusList = new Gson().fromJson(Utility.ObjectToJson(statusListObject), new TypeToken<List<MDSrStatusModel>>() {
            }.getType());

            nextId = commonDAO.getNextIdPostgres(Utility.seq_name_tbl_sr);

            try {
                long startTime = System.currentTimeMillis();
                lastQueriedMsisdn = SessionManager.getAttribute(SessionConstants.SR_LAST_QUERY_MSISDN.name(), request).toString();
                responseTrackerLogger.info("REDIS GET QUERY,     RESPONSE_TIME: " + (System.currentTimeMillis() - startTime) + "ms");
            } catch (Exception e) {
                e.printStackTrace();
                logger.error(e.getMessage(), e);
            }

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            e.printStackTrace();
        }
        return new SRLoadDataQueryModel(srTypeList, mdRoutingList, srserList, causeList, SourceList, Utility.generateSRNumber(nextId), statusList, lastQueriedMsisdn, sourceLocList);
    }

    public List<CommonLovModel> getSRAreaList(String searchType) {

        List<CommonLovModel> areaList = new ArrayList<>();
        try {
            Object objects = commonDAO.getDataPostgres("SELECT NAME,ID, ACTIVE, SR_SERVICE_TYPE_NAME, SR_SERVICE_TYPE_ID, SR_TYPE_ID, SR_TYPE_NAME FROM (SELECT SR_AREA_NAME AS NAME, SR_AREA_ID AS ID, ACTIVE, SR_SERVICE_TYPE_NAME, SR_SERVICE_TYPE_ID, SR_TYPE_ID, SR_TYPE_NAME,  ROW_NUMBER() OVER(PARTITION BY SR_AREA_NAME ORDER BY SR_AREA_NAME) rn FROM " + Utility.md_sr_sub_area + " where sr_type_name='" + searchType + "' AND active=1) t WHERE rn = 1 order by NAME");
            areaList = new Gson().fromJson(Utility.ObjectToJson(objects), new TypeToken<List<CommonLovModel>>() {
            }.getType());
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return areaList;
    }

    public List<MDSrSubAreaModel> getSRSubAreaList(String srTypeName,
                                                   String srAreaName) {

        List<MDSrSubAreaModel> serviceList = new ArrayList<MDSrSubAreaModel>();
        try {
            String qry_service = "SELECT *  FROM " + Utility.md_sr_sub_area + " WHERE ACTIVE=1 AND SR_TYPE_NAME='" + srTypeName + "' AND SR_AREA_NAME='" + srAreaName + "' ORDER BY NAME";
            logger.info(qry_service);
            Object srslist = commonDAO.getDataPostgres(qry_service);
            serviceList = new Gson().fromJson(Utility.ObjectToJson(srslist), new TypeToken<List<MDSrSubAreaModel>>() {
            }.getType());
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return serviceList;
    }

    public MDSubAreaUpdateViewModel getSRSubAreaDetails(String ID, String accountType, String accountClass) {

        List<MDSrSubAreaModel> serviceList = new ArrayList<MDSrSubAreaModel>();
        List<MDSrSLAModel> mdSrSLAModels = new ArrayList<MDSrSLAModel>();
        List<MDSrNotify> mdSrNotifies = new ArrayList<MDSrNotify>();
        List<MDSrescaModel> mdSrescaModels = new ArrayList<MDSrescaModel>();
        try {
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            SearchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");
            SearchData.put("ID", ID);
            whereSearchType.put("ID", "AND");

            String qry_service = QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_sub_area, SearchData, "*", whereSearchType);
            logger.info(qry_service);
            Object srslist = commonDAO.getDataPostgres(qry_service);
            serviceList = new Gson().fromJson(Utility.ObjectToJson(srslist), new TypeToken<List<MDSrSubAreaModel>>() {
            }.getType());

            if (serviceList.size() > 0) {
                Map<String, Object> SearchSRDetails = new HashMap<String, Object>();
                Map<String, Object> whereSearchTypeDetails = new HashMap<String, Object>();

                SearchSRDetails.put("SR_SUB_AREA_ID", ID);
                whereSearchTypeDetails.put("SR_SUB_AREA_ID", "AND");

                SearchSRDetails.put("UNIQUE_ID", serviceList.get(0).getUNIQUE_ID());
                whereSearchTypeDetails.put("UNIQUE_ID", "AND");

                SearchSRDetails.put("ACTIVE", "1");
                whereSearchTypeDetails.put("ACTIVE", "AND");

                SearchSRDetails.put("ACC_CLASS_NAME", accountClass);
                whereSearchTypeDetails.put("ACC_CLASS_NAME", "AND");

                SearchSRDetails.put("ACC_TYPE_NAME", accountType);
                whereSearchTypeDetails.put("ACC_TYPE_NAME", "AND");

                Object sla = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_sla, SearchSRDetails, "*", whereSearchTypeDetails));
                mdSrSLAModels = new Gson().fromJson(Utility.ObjectToJson(sla), new TypeToken<List<MDSrSLAModel>>() {
                }.getType());

            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return new MDSubAreaUpdateViewModel(serviceList, mdSrSLAModels, mdSrNotifies, mdSrescaModels);
    }

    public void downloadSrInFile(HttpServletResponse response, HttpServletRequest request, String fileType, String rowSpec,
                                 String srNum) {

        List<Map<String, Object>> mapList = new ArrayList<>();
        List<TBLSRModel> srLists = new ArrayList<>();
        int maxDownloadLimit = 15000;

        try {
            String countQuery = "SELECT COUNT(*) AS CNT FROM " + Utility.md_user_responsibility_map + " WHERE USER_ID=" + Utility.getUserId(request) + "  AND RESPONSIBILITY_ID=541";
            logger.info(countQuery);
            //System.out.println(countQuery);
            int count = commonDAO.CommoNumberOfRow(countQuery);
            if (count >= 1) {
                maxDownloadLimit = 50000;
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }

        try {
            String query = "SELECT * FROM " + Utility.tbl_sr + " " + SessionManager.getAttribute(SessionConstants.SR_LAST_QUERY.name(), request) + " OFFSET 0 ROWS FETCH NEXT " + maxDownloadLimit + " ROWS ONLY";// + SessionManager.getAttribute(SessionConstants.SR_LAST_QUERY_PAGINATION.name(), request);
            if (rowSpec != null && !rowSpec.isEmpty() && rowSpec.equalsIgnoreCase("onlyCurrentRow") && srNum != null && !srNum.isEmpty()) {
                query = "SELECT * FROM " + Utility.tbl_sr + " WHERE SR_NUM=" + srNum;
            } else if (rowSpec != null && !rowSpec.isEmpty() && rowSpec.equalsIgnoreCase("onlyVisibleRow") && srNum != null && !srNum.isEmpty()) {
                query = "SELECT * FROM " + Utility.tbl_sr + " " + SessionManager.getAttribute(SessionConstants.SR_LAST_QUERY.name(), request) + SessionManager.getAttribute(SessionConstants.SR_LAST_QUERY_PAGINATION.name(), request);
            }
//            String query = "SELECT TBL_SR.*, KDM.KDM, KDM.KCP  FROM " + Utility.tbl_sr + " LEFT JOIN "+ Utility.tbl_KDM_MSISDN +" KDM " +
//                    "ON TBL_SR.MSISDN = KDM.MSISDN "+ SessionManager.getAttribute(SessionConstants.SR_LAST_QUERY.name(), request) + " OFFSET 0 ROWS FETCH NEXT " + maxDownloadLimit + " ROWS ONLY";// + SessionManager.getAttribute(SessionConstants.SR_LAST_QUERY_PAGINATION.name(), request);
//            if (rowSpec != null && !rowSpec.isEmpty() && rowSpec.equalsIgnoreCase("onlyCurrentRow") && srNum != null && !srNum.isEmpty()) {
//                query ="SELECT TBL_SR.*, KDM.KDM, KDM.KCP  FROM " + Utility.tbl_sr + " LEFT JOIN "+ Utility.tbl_KDM_MSISDN +" KDM " +
//                        "ON TBL_SR.MSISDN = KDM.MSISDN " +" WHERE SR_NUM=" + srNum;
//            } else if (rowSpec != null && !rowSpec.isEmpty() && rowSpec.equalsIgnoreCase("onlyVisibleRow") && srNum != null && !srNum.isEmpty()) {
//                query = "SELECT TBL_SR.*, KDM.KDM, KDM.KCP  FROM " + Utility.tbl_sr + " LEFT JOIN "+ Utility.tbl_KDM_MSISDN +" KDM " +
//                        "ON TBL_SR.MSISDN = KDM.MSISDN " + SessionManager.getAttribute(SessionConstants.SR_LAST_QUERY.name(), request) + SessionManager.getAttribute(SessionConstants.SR_LAST_QUERY_PAGINATION.name(), request);
//            }
            logger.info("Export query: " + query);
            Object listObject = commonDAO.getDataPostgres(query);
            srLists = new Gson().fromJson(Utility.ObjectToJson(listObject), new TypeToken<List<TBLSRModel>>() {
            }.getType());

            String[] columnTitles = {"SR #", "MSISDN", "Account", "Interaction Type", "Type",
                    "Area", "Sub Area", "Owner", "Owner Group", "Status", "Sub - status",
                    "Severity", "Priority", "Master Issue", "Master Issue #", "Summary", "Description", "Root Cause", "Root Cause Detail",
                    "Address", "Account Class", "Account Type", "Accepted By", "Accepted Date", "Problem Since", "Cell Name",
                    "Source", "Source Location", "SLA(Hrs)", "Duration(Hrs)", "First Call Resolution", "Created By", "Log Date", "Modified Date", "Escalated Date",
                    "Resolved Date", "Resolved By", "Closed By", "Closed Date", "KeepInView Date", "Remedy Incident No", "Reopen Date", "Reopen By", "Submitted Date", "Commit Time",
                    "Full Address", "Reopened", "Feedback Type", "Feedback Received", "Complaint Resolution / Solution", "Escalation / Cancel Reason", "Brand Name", "Division",
                    "District", "Thana", "Reference Complaint #", "Reference Complaint Count", "Reference Resolution Notes", "ICE Feedback Received", "ICE Feedback", "Historical Resolution Notes","Alternative Number","Visit Frequency"};

            String[] headers = {"SR_NUM", "MSISDN", "ACCOUNT_NAME", "SR_SERVICE_TYPE_NAME", "SR_TYPE_NAME",
                    "SR_AREA_NAME", "SR_SUB_AREA_NAME", "OWNER_NAME", "OWNER_GROUP_NAME", "SR_STATUS_NAME", "SR_SUB_STATUS_NAME",
                    "SEVERITY_NAME", "PRIORITY_NAME", "MASTER_ISSUE", "PAR_SR_NUM", "SUMMARY", "DESCRIPTION", "ROOT_CAUSE_NAME", "ROOT_CAUSE_DETAIL",
                    "ADDRESS", "ACC_CLASS_NAME", "ACC_TYPE_NAME", "ACCEPTED_BY", "ACCEPTED_AT", "PROBLEM_SINCE", "CELL_NAME",
                    "SRC_NAME", "SRC_LOCATION_NAME", "SLA_HR", "DURATION", "FIRST_CALL_RESOLVED", "CREATED_BY", "LOG_AT", "UPDATED_AT", "ESCALATED_AT",
                    "RESOLVED_AT", "RESOLVED_BY_NAME", "CLOSED_BY", "CLOSED_AT", "KEEPINVIEW_DATE", "REMEDY_INCIDENT_NO", "REOPEN_AT", "REOPEN_BY_NAME", "SUBMITTED_AT", "COMMITED_AT",
                    "FULL_ADDRESS", "IS_REOPENED", "FEEDBACK_TYPE", "IS_FEEDBACK_RECEIVED", "RESOLUTION_SOLUTION", "ESC_CANCEL_REASON", "BRAND_NAME", "DIVISION", "DISTRICT", "THANA",
                    "REFERENCE_COMPLAINT", "REFERENCE_COMPLAINT_COUNT", "REF_SR_NOTES", "LONGITUDE", "LATITUDE", "EX_RESOLUTION","ALTERNATIVE_NUMBER","VISIT_FREQUENCY_TYPE"};

            //Map<String, String> kdmModelList = manageService.getAllKDM();
            String corporateInfo;

            for (TBLSRModel tblsrModel : srLists) {
                //Long mili  =  System.currentTimeMillis();
                //System.out.println("kdmModelList " +kdmModelList.toString());
               /* if(!kdmModelList.isEmpty()) {
                   corporateInfo = kdmModelList.get(tblsrModel.getMSISDN());
                }*/
                /*corporateInfo = "";

                if(tblsrModel.getKDM() != null){
                    corporateInfo = "KDM";
                }else if(tblsrModel.getKCP() != null){
                    corporateInfo = "KCP";
                }*/
                //System.out.println("END "+ (System.currentTimeMillis()- mili));

                HashMap<String, Object> hashMap = new HashMap<>();
                hashMap.put("SR_NUM", tblsrModel.getSR_NUM());
                hashMap.put("MSISDN", tblsrModel.getMSISDN());
                hashMap.put("ACCOUNT_NAME", tblsrModel.getACCOUNT_NAME());
                hashMap.put("SR_SERVICE_TYPE_NAME", tblsrModel.getSR_SERVICE_TYPE_NAME());
                hashMap.put("SR_TYPE_NAME", tblsrModel.getSR_TYPE_NAME());
                hashMap.put("SR_AREA_NAME", tblsrModel.getSR_AREA_NAME());
                hashMap.put("SR_SUB_AREA_NAME", tblsrModel.getSR_SUB_AREA_NAME());
                hashMap.put("OWNER_NAME", tblsrModel.getOWNER_NAME());
                hashMap.put("OWNER_GROUP_NAME", tblsrModel.getOWNER_GROUP_NAME());
                hashMap.put("SR_STATUS_NAME", tblsrModel.getSR_STATUS_NAME());
                hashMap.put("SR_SUB_STATUS_NAME", tblsrModel.getSR_SUB_STATUS_NAME());
                hashMap.put("SEVERITY_NAME", tblsrModel.getSEVERITY_NAME());
                hashMap.put("PRIORITY_NAME", tblsrModel.getPRIORITY_NAME());
                hashMap.put("MASTER_ISSUE", getFormattedYesNo(tblsrModel.getMASTER_ISSUE()));
                hashMap.put("PAR_SR_NUM", tblsrModel.getPAR_SR_NUM());
                hashMap.put("SUMMARY", tblsrModel.getSUMMARY());
                hashMap.put("DESCRIPTION", tblsrModel.getDESCRIPTION());
                hashMap.put("ROOT_CAUSE_NAME", tblsrModel.getROOT_CAUSE_NAME());
                hashMap.put("ROOT_CAUSE_DETAIL", tblsrModel.getROOT_CAUSE_DETAIL());
                hashMap.put("ADDRESS", tblsrModel.getADDRESS());
                hashMap.put("ACC_CLASS_NAME", tblsrModel.getACC_CLASS_NAME());
                hashMap.put("ACC_TYPE_NAME", tblsrModel.getACC_TYPE_NAME());
                hashMap.put("ACCEPTED_BY", tblsrModel.getACCEPTED_BY_NAME());
                hashMap.put("ACCEPTED_AT", Utility.convertTimestampToDateTime(tblsrModel.getACCEPTED_AT(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("PROBLEM_SINCE", Utility.convertTimestampToDateTime(tblsrModel.getPROBLEM_SINCE(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("CELL_NAME", tblsrModel.getCELL_NAME());
                hashMap.put("SRC_NAME", tblsrModel.getSRC_NAME());
                hashMap.put("SRC_LOCATION_NAME", tblsrModel.getSRC_LOCATION_NAME());
                hashMap.put("SLA_HR", tblsrModel.getSLA_HR());
                hashMap.put("DURATION", getDuration(tblsrModel));
                hashMap.put("FIRST_CALL_RESOLVED", getFormattedYesNo(tblsrModel.getFIRST_CALL_RESOLVED()));
                hashMap.put("CREATED_BY", tblsrModel.getCREATED_BY_USERNAME());
                hashMap.put("LOG_AT", Utility.convertTimestampToDateTime(tblsrModel.getLOG_AT(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("UPDATED_AT", Utility.convertTimestampToDateTime(tblsrModel.getUPDATED_AT(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("ESCALATED_AT", Utility.convertTimestampToDateTime(tblsrModel.getESCALATED_AT(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("RESOLVED_AT", Utility.convertTimestampToDateTime(tblsrModel.getRESOLVED_AT(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("RESOLVED_BY_NAME", tblsrModel.getRESOLVED_BY_NAME());
                hashMap.put("CLOSED_BY", tblsrModel.getCLOSED_BY_NAME());
                hashMap.put("CLOSED_AT", Utility.convertTimestampToDateTime(tblsrModel.getCLOSED_AT(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("KEEPINVIEW_DATE", Utility.convertTimestampToDateTime(tblsrModel.getKEEPINVIEW_DATE(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("REMEDY_INCIDENT_NO", tblsrModel.getREMEDY_INCIDENT_NO());
                hashMap.put("REOPEN_AT", Utility.convertTimestampToDateTime(tblsrModel.getREOPEN_AT(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("REOPEN_BY_NAME", tblsrModel.getREOPEN_BY_NAME());
                hashMap.put("SUBMITTED_AT", Utility.convertTimestampToDateTime(tblsrModel.getSUBMITTED_AT(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("COMMITED_AT", Utility.convertTimestampToDateTime(tblsrModel.getCOMMITED_AT(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("FULL_ADDRESS", tblsrModel.getFULL_ADDRESS());
                hashMap.put("IS_REOPENED", getFormattedYesNo(tblsrModel.getIS_REOPENED()));
                hashMap.put("FEEDBACK_TYPE", tblsrModel.getFEEDBACK_TYPE());
                hashMap.put("IS_FEEDBACK_RECEIVED", getFormattedYesNo(tblsrModel.getIS_FEEDBACK_RECEIVED()));
                hashMap.put("RESOLUTION_SOLUTION", tblsrModel.getRESOLUTION_SOLUTION());
                hashMap.put("ESC_CANCEL_REASON", tblsrModel.getESC_CANCEL_REASON());
                hashMap.put("BRAND_NAME", tblsrModel.getBRAND_NAME());
                hashMap.put("DIVISION", tblsrModel.getDIVISION());
                hashMap.put("DISTRICT", tblsrModel.getDISTRICT());
                hashMap.put("THANA", tblsrModel.getTHANA());
                hashMap.put("REFERENCE_COMPLAINT", tblsrModel.getREFERENCE_COMPLAINT());
                hashMap.put("REFERENCE_COMPLAINT_COUNT", tblsrModel.getREFERENCE_COMPLAINT_COUNT());
                hashMap.put("REF_SR_NOTES", tblsrModel.getREF_SR_NOTES());
                hashMap.put("LONGITUDE", tblsrModel.getLONGITUDE());
                hashMap.put("LATITUDE", tblsrModel.getLATITUDE());
                hashMap.put("EX_RESOLUTION", tblsrModel.getEX_RESOLUTION());
//                hashMap.put("CORPORATE_TAG",corporateInfo);
                hashMap.put("ALTERNATIVE_NUMBER",tblsrModel.getALTERNATIVE_NUMBER());
                hashMap.put("VISIT_FREQUENCY_TYPE",tblsrModel.getVISIT_FREQUENCY_TYPE());
                mapList.add(hashMap);
            }
            if (fileType.equalsIgnoreCase("csv")) {
                generateSRListCSV(response, mapList, headers, columnTitles);
            } else if (fileType.equalsIgnoreCase("excel")) {
                generateSRListExcel(headers, mapList, response, columnTitles);
            }

            headers = null;
            columnTitles = null;
            srLists.clear();
            listObject = null;

        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        } finally {
            mapList.clear();
        }
    }

    private void generateSRListExcel(String[] headers, List<Map<String, Object>> mapList, HttpServletResponse response, String[] columnTitles) {
        try {
            response.setContentType("application/octet-stream");
            SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyyHHmmss");
            String filename = "SR_LIST_" + dateFormat.format(new Date()) + ".xlsx";
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");


            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("SR List");

            Row row = sheet.createRow(0);
            CellStyle headerCellStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerCellStyle.setFont(headerFont);
            DataFormat dataFormat = workbook.createDataFormat();
            headerCellStyle.setDataFormat(dataFormat.getFormat("@"));
            for (int i = 0; i < columnTitles.length; i++) {
                Cell cell = row.createCell(i);
                cell.setCellValue(columnTitles[i]);
                cell.setCellStyle(headerCellStyle);
                sheet.autoSizeColumn(i);
            }

            CellStyle childCellStyle = workbook.createCellStyle();
            childCellStyle.setDataFormat(dataFormat.getFormat("@"));
            for (int i = 0; i < mapList.size(); i++) {
                Row cellRow = sheet.createRow(i + 1);
                for (int j = 0; j < headers.length; j++) {
                    Cell cell = cellRow.createCell(j);
                    Object cellValue = mapList.get(i).get(headers[j]);
                    if (cellValue != null && !cellValue.toString().isEmpty()) {
                        cell.setCellValue(mapList.get(i).get(headers[j]).toString());
                    }
                    cell.setCellStyle(childCellStyle);
                    sheet.autoSizeColumn(j);
                }
            }

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            ByteArrayInputStream stream = new ByteArrayInputStream(outputStream.toByteArray());
            IOUtils.copy(stream, response.getOutputStream());
            workbook.close();
            outputStream.close();
            stream.close();
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
    }

    private void generateSRListCSV(HttpServletResponse response, List<Map<String, Object>> mapList, String[] headers, String[] columnTitles) {
        try {

            SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyyHHmmss");
            String filename = "SR_LIST_" + dateFormat.format(new Date()) + ".csv";
            response.setContentType("text/csv");
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");
            GenerateCSV.writeApacheCSVtoResponse(response.getWriter(), mapList, logger, headers, columnTitles);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
    }

    private String getDuration(TBLSRModel tblsrModel) {
        String duration = "";
        double hourFrac = 0;
        DecimalFormat df = new DecimalFormat("#.##");
        try {
            if (tblsrModel.getSUBMITTED_AT() == null || tblsrModel.getSUBMITTED_AT() <= 0) {
                return duration;
            } else if (tblsrModel.getSLA_STOP_TIME() != null && tblsrModel.getSLA_STOP_TIME() > 0) {
                hourFrac = (tblsrModel.getSLA_STOP_TIME() - tblsrModel.getSUBMITTED_AT()) / 3600000.0;
                duration = df.format(hourFrac);
            } else {
                hourFrac = (System.currentTimeMillis() - tblsrModel.getSUBMITTED_AT()) / 3600000.0;
                duration = df.format(hourFrac);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return duration;
    }

    private String getFormattedYesNo(Integer value) {
        if (value != null && value == 1) {
            return "Y";
        } else {
            return "N";
        }
    }

    public SRCustomQueryLovModel getCustomQueryLovList() {
        SRCustomQueryLovModel srCustomQueryLovModel = new SRCustomQueryLovModel();

        List<MDSrServiceTypeModel> serviceTypeList = new ArrayList<>();
        List<SRTypeModel> typeList = new ArrayList<>();
        List<MDSrAreaModel> areaList = new ArrayList<>();
        List<MDSrSubAreaModel> subAreaList = new ArrayList<>();
        List<MDSrStatusModel> statusList = new ArrayList<>();
        List<MDSrSeverityModel> severityList = new ArrayList<>();
        List<MDSrPriorityModel> priorityList = new ArrayList<>();
        List<MDUserPosition> positionList = new ArrayList<>();
        List<MDAccountClassModel> accountClassList = new ArrayList<>();
        List<MDAccountTypeModel> accountTypeList = new ArrayList<>();
        List<CommonLovModel> sourceLocationList = new ArrayList<>();
        List<CommonLovModel> rootCauseList = new ArrayList<>();
        List<CommonLovModel> srcList = new ArrayList<>();
        Map<String, Object> searchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        try {
            searchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");

            Object objectList;
            objectList = commonDAO.getDataPostgres("SELECT NAME,ID, ACTIVE FROM " + Utility.md_sr_service_type + " where active=1 order by NAME desc");
            serviceTypeList = new Gson().fromJson(Utility.ObjectToJson(objectList), new TypeToken<List<MDSrServiceTypeModel>>() {
            }.getType());
            srCustomQueryLovModel.setInteractionTypeList(serviceTypeList);

            objectList = commonDAO.getDataPostgres("SELECT NAME,ID, ACTIVE, SR_SERVICE_TYPE_NAME, SR_SERVICE_TYPE_ID FROM (SELECT SR_TYPE_NAME AS NAME, SR_TYPE_ID AS ID, ACTIVE, SR_SERVICE_TYPE_NAME, SR_SERVICE_TYPE_ID,  ROW_NUMBER() OVER(PARTITION BY SR_TYPE_NAME ORDER BY SR_TYPE_NAME) rn FROM " + Utility.md_sr_sub_area + " where active=1) t WHERE rn = 1 order by NAME");
            typeList = new Gson().fromJson(Utility.ObjectToJson(objectList), new TypeToken<List<CommonLovModel>>() {
            }.getType());
            srCustomQueryLovModel.setTypeList(typeList);

            objectList = commonDAO.getDataPostgres("SELECT NAME,ID, ACTIVE, SR_SERVICE_TYPE_NAME, SR_SERVICE_TYPE_ID, SR_TYPE_ID, SR_TYPE_NAME FROM (SELECT SR_AREA_NAME AS NAME, SR_AREA_ID AS ID, ACTIVE, SR_SERVICE_TYPE_NAME, SR_SERVICE_TYPE_ID, SR_TYPE_ID, SR_TYPE_NAME,  ROW_NUMBER() OVER(PARTITION BY SR_AREA_NAME ORDER BY SR_AREA_NAME) rn FROM " + Utility.md_sr_sub_area + " where active=1) t WHERE rn = 1 order by NAME");
            areaList = new Gson().fromJson(Utility.ObjectToJson(objectList), new TypeToken<List<MDSrAreaModel>>() {
            }.getType());
            srCustomQueryLovModel.setAreaList(areaList);

            objectList = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_sub_area, searchData, "ID,NAME", whereSearchType));
            subAreaList = new Gson().fromJson(Utility.ObjectToJson(objectList), new TypeToken<List<MDSrSubAreaModel>>() {
            }.getType());
            srCustomQueryLovModel.setSubAreaList(subAreaList);

            objectList = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_status, searchData, "ID,NAME", whereSearchType));
            statusList = new Gson().fromJson(Utility.ObjectToJson(objectList), new TypeToken<List<MDSrStatusModel>>() {
            }.getType());
            srCustomQueryLovModel.setStatusList(statusList);

            objectList = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_severity, searchData, "ID,NAME", whereSearchType));
            severityList = new Gson().fromJson(Utility.ObjectToJson(objectList), new TypeToken<List<MDSrSeverityModel>>() {
            }.getType());
            srCustomQueryLovModel.setSeverityList(severityList);

            objectList = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_priority, searchData, "ID,NAME", whereSearchType));
            priorityList = new Gson().fromJson(Utility.ObjectToJson(objectList), new TypeToken<List<MDSrPriorityModel>>() {
            }.getType());
            srCustomQueryLovModel.setPriorityList(priorityList);

            objectList = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_user_position, searchData, "ID,NAME", whereSearchType));
            positionList = new Gson().fromJson(Utility.ObjectToJson(objectList), new TypeToken<List<MDUserPosition>>() {
            }.getType());
            srCustomQueryLovModel.setPositionList(positionList);

            objectList = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_acc_class, searchData, "ID,NAME", whereSearchType));
            accountClassList = new Gson().fromJson(Utility.ObjectToJson(objectList), new TypeToken<List<MDAccountClassModel>>() {
            }.getType());
            srCustomQueryLovModel.setAccountClassList(accountClassList);

            objectList = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_acc_type, searchData, "ID,NAME", whereSearchType));
            accountTypeList = new Gson().fromJson(Utility.ObjectToJson(objectList), new TypeToken<List<MDAccountTypeModel>>() {
            }.getType());
            srCustomQueryLovModel.setAccountTypeList(accountTypeList);

            objectList = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_src_location, searchData, "ID,NAME", whereSearchType));
            sourceLocationList = new Gson().fromJson(Utility.ObjectToJson(objectList), new TypeToken<List<CommonLovModel>>() {
            }.getType());
            srCustomQueryLovModel.setSourceLocationList(sourceLocationList);

            objectList = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_root_cause, searchData, "ID,NAME", whereSearchType));
            rootCauseList = new Gson().fromJson(Utility.ObjectToJson(objectList), new TypeToken<List<CommonLovModel>>() {
            }.getType());
            srCustomQueryLovModel.setRootCauseList(rootCauseList);

            objectList = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_src, searchData, "ID,NAME", whereSearchType));
            srcList = new Gson().fromJson(Utility.ObjectToJson(objectList), new TypeToken<List<CommonLovModel>>() {
            }.getType());
            srCustomQueryLovModel.setSrcList(srcList);

            searchData.clear();
            whereSearchType.clear();

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            searchData.clear();
            whereSearchType.clear();
        }
        return srCustomQueryLovModel;
    }

    public List<MDSourceLocationModel> getSourceLocation(String searchType) {
        List<MDSourceLocationModel> srcList = new ArrayList<MDSourceLocationModel>();

        Map<String, Object> SearchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        try {
            SearchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");
            SearchData.put("SRC_ID", searchType);
            whereSearchType.put("SRC_ID", "AND");

            String qry_service = QueryBuilder.getSelectWhereFieldsQuery(Utility.md_src_location, SearchData, "ID,NAME", whereSearchType);
            logger.info(qry_service);
            Object srslist = commonDAO.getDataPostgres(qry_service);
            srcList = new Gson().fromJson(Utility.ObjectToJson(srslist), new TypeToken<List<MDSrSubAreaModel>>() {
            }.getType());

        } catch (Exception e) {
            logger.error(e.getMessage());
        } finally {
            SearchData.clear();
            whereSearchType.clear();
        }
        return srcList;
    }

    public SRMsisdnInfo getMsisdnInfo(String msisdn) {

        SRMsisdnInfo srMsisdnInfo = new SRMsisdnInfo();
        try {
            List<DemographicInformationModel> demographicInfo = new ArrayList<DemographicInformationModel>();
            demographicInfo = accountserviceDAO.GetDemoInfo(msisdn);
            if (demographicInfo.size() > 0) {
                srMsisdnInfo.setAccountName(demographicInfo.get(0).getACCOUNT_NAME());
                if (demographicInfo.get(0).getLAST_NAME() != null && demographicInfo.get(0).getLAST_NAME().length() > 0) {
                    srMsisdnInfo.setContactName(demographicInfo.get(0).getFIRST_NAME() + " " + demographicInfo.get(0).getLAST_NAME());
                } else {
                    srMsisdnInfo.setContactName(demographicInfo.get(0).getFIRST_NAME());
                }

                srMsisdnInfo.setAccountClass(demographicInfo.get(0).getACCOUNT_CLASS());
                srMsisdnInfo.setAccountType(demographicInfo.get(0).getACCOUNT_TYPE());
                srMsisdnInfo.setMSISDN(demographicInfo.get(0).getMOBILE_NO());
                srMsisdnInfo.setACTIVE_CALL(demographicInfo.get(0).getACTIVE_CALL());
                srMsisdnInfo.setACTIVE_EMAIL(demographicInfo.get(0).getACTIVE_EMAIL());
                srMsisdnInfo.setACTIVE_SMS(demographicInfo.get(0).getACTIVE_SMS());
                srMsisdnInfo.setEMAIL(demographicInfo.get(0).getEMAIL());
                srMsisdnInfo.setCONTACT_MOBILE_PHONE(demographicInfo.get(0).getCONTACT_MOBILE_PHONE());

                if (demographicInfo.get(0).getACCOUNT_CLASS() != null && demographicInfo.get(0).getACCOUNT_CLASS().length() > 0) {
                    List<LovListModel> accClassListData = new ArrayList<LovListModel>();
                    Map<String, Object> SearchData = new HashMap<String, Object>();
                    Map<String, Object> whereSearchType = new HashMap<String, Object>();
                    SearchData.put("ACTIVE", "1");
                    whereSearchType.put("ACTIVE", "AND");
                    SearchData.put("NAME", demographicInfo.get(0).getACCOUNT_CLASS());
                    whereSearchType.put("NAME", "AND");

                    String qry_service = QueryBuilder.getSelectWhereFieldsQuery(Utility.md_acc_class, SearchData, "ID,NAME", whereSearchType);
                    logger.info(qry_service);
                    Object accClassList = commonDAO.getDataPostgres(qry_service);
                    logger.info("accClassList: {}", accClassList);
                    accClassListData = new Gson().fromJson(Utility.ObjectToJson(accClassList), new TypeToken<List<LovListModel>>() {
                    }.getType());

                    srMsisdnInfo.setAccountClass_id(accClassListData.get(0).getID());
                    SearchData.clear();
                    whereSearchType.clear();
                }


                if (demographicInfo.get(0).getACCOUNT_TYPE() != null && demographicInfo.get(0).getACCOUNT_TYPE().length() > 0) {
                    List<LovListModel> accTypeListData = new ArrayList<LovListModel>();
                    Map<String, Object> SearchData = new HashMap<String, Object>();
                    Map<String, Object> whereSearchType = new HashMap<String, Object>();
                    SearchData.put("ACTIVE", "1");
                    whereSearchType.put("ACTIVE", "AND");
                    SearchData.put("NAME", demographicInfo.get(0).getACCOUNT_TYPE());
                    whereSearchType.put("NAME", "AND");

                    String qry_service = QueryBuilder.getSelectWhereFieldsQuery(Utility.md_acc_type, SearchData, "ID,NAME", whereSearchType);
                    logger.info(qry_service);
                    Object accTypeList = commonDAO.getDataPostgres(qry_service);
                    accTypeListData = new Gson().fromJson(Utility.ObjectToJson(accTypeList), new TypeToken<List<LovListModel>>() {
                    }.getType());

                    srMsisdnInfo.setAccountType_id(accTypeListData.get(0).getID());
                    SearchData.clear();
                    whereSearchType.clear();
                }


            }

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return srMsisdnInfo;
    }

    public TBLSRModel getSRBySRNUM(String srNum, HttpServletRequest request) {

        TBLSRModel tblsrModel = new TBLSRModel();
        try {
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            SearchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");
            SearchData.put("SR_NUM", srNum);
            whereSearchType.put("SR_NUM", "AND");

            String query = QueryBuilder.getSelectWhereQuery(Utility.tbl_sr, SearchData, whereSearchType);
            Object objects = commonDAO.getDataPostgres(query);
            List<TBLSRModel> tblsrModelList = new Gson().fromJson(Utility.ObjectToJson(objects), new TypeToken<List<TBLSRModel>>() {
            }.getType());
            if (tblsrModelList.size() > 0) {
                tblsrModel = tblsrModelList.get(0);
                insertRecentRecords(tblsrModel.getSR_NUM(), tblsrModel.getMSISDN(), tblsrModel.getACCOUNT_NAME(), request);

                String countQuery = "SELECT COUNT(*) AS CNT FROM " + Utility.md_user_responsibility_map + " WHERE USER_ID=" + Utility.getUserId(request) + "  AND RESPONSIBILITY_ID=240";
                logger.info(countQuery);
                System.out.println(countQuery);
                int count = commonDAO.CommoNumberOfRow(countQuery);
                tblsrModel.setReopenPermitted(count == 1);

                tblsrModel.setDURATION_IN_HR(getDuration(tblsrModel));
                tblsrModel.setFEEDBACK_TYPE((tblsrModel.getFEEDBACK_TYPE() == null || tblsrModel.getFEEDBACK_TYPE().isEmpty()) ? "No" : tblsrModel.getFEEDBACK_TYPE());
            }
            SearchData.clear();
            whereSearchType.clear();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return tblsrModel;
    }

    public void insertRecentRecords(String srNumber, String msisdn, String accountName, HttpServletRequest request) {

        try {
            Map<String, Object> insertData = new HashMap<String, Object>();
            insertData.put("SR_NUM", srNumber);
            insertData.put("MSISDN", msisdn);
            insertData.put("ACCOUNT_NAME", accountName);
            insertData.put("USER_ID", Utility.getUserId(request));
            insertData.put("USER_NAME", Utility.getLoginName(request));
            insertData.put("VIEW_NAME", "sr");
//            commonDAO.CommoInsert(Utility.tbl_recent_records, insertData, logger);
            insertData.clear();
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
    }

    public List<MDSrStatusModel> getSRStatusDependent(Integer statusId) {

        List<MDSrStatusModel> statusList = new ArrayList<>();
        try {
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            Object statusListObject;
            SearchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");
            if (statusId == 3) {
                SearchData.put("ACCEPTED_STATUS", "1");
                whereSearchType.put("ACCEPTED_STATUS", "AND");
            } else if (statusId == 5) {
                SearchData.put("COMPLETED_STATUS", "1");
                whereSearchType.put("COMPLETED_STATUS", "AND");
            } else if (statusId == 4) {
                SearchData.put("KEEPINVIEW_STATUS", "1");
                whereSearchType.put("KEEPINVIEW_STATUS", "AND");
            }
            statusListObject = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_status, SearchData, "ID,NAME", whereSearchType));
            statusList = new Gson().fromJson(Utility.ObjectToJson(statusListObject), new TypeToken<List<MDSrStatusModel>>() {
            }.getType());
            SearchData.clear();
            whereSearchType.clear();
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return statusList;
    }

    public CommonRestResponse getSrBulkUpdateCheck(String rowSpec, HttpServletRequest request) {

        CommonRestResponse commonRestResponse = new CommonRestResponse();
        try {
            String query = "SELECT ID AS CNT FROM " + Utility.tbl_sr + " " + SessionManager.getAttribute(SessionConstants.SR_LAST_QUERY.name(), request) + " OFFSET 0 ROWS FETCH NEXT 1000 ROWS ONLY";// + SessionManager.getAttribute(SessionConstants.SR_LAST_QUERY_PAGINATION.name(), request);
            if (rowSpec != null && !rowSpec.isEmpty() && rowSpec.equalsIgnoreCase("onlyVisibleRow")) {
                query = "SELECT ID AS CNT FROM " + Utility.tbl_sr + " " + SessionManager.getAttribute(SessionConstants.SR_LAST_QUERY.name(), request) + SessionManager.getAttribute(SessionConstants.SR_LAST_QUERY_PAGINATION.name(), request);
            }
            logger.info(query);
            Object listObject = commonDAO.getDataPostgres(query);
            List<CommonLovModel> srList = new Gson().fromJson(Utility.ObjectToJson(listObject), new TypeToken<List<CommonLovModel>>() {
            }.getType());

            if (srList.size() > 0) {
                commonRestResponse.setCode(201);
                commonRestResponse.setMessage("Be careful: " + srList.size() + " SRs will be updated after your submission. And this action cannot be undone.");
            } else {
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("Unable to validate query. Please reload/research again.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Error Occurred to validate query! Please reload/research again.");
        }
        return commonRestResponse;
    }

    public ResponseEntity<Resource> downloadFileById(Long id, HttpServletResponse response) throws IOException {
        try {

            TBLSRAttachmentModel tblsrAttachmentModel = new TBLSRAttachmentModel();
            Map<String, Object> searchData = new HashMap<>();
            Map<String, Object> whereSearchType = new HashMap<>();
            searchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");
            searchData.put("ID", id);
            whereSearchType.put("ID", "AND");

            String query = QueryBuilder.getSelectWhereQuery(Utility.tbl_sr_attachment, searchData, whereSearchType);
            Object objects = commonDAO.getDataPostgres(query);
            List<TBLSRAttachmentModel> list = new Gson().fromJson(Utility.ObjectToJson(objects), new TypeToken<List<TBLSRAttachmentModel>>() {
            }.getType());
            if (list.size() > 0) {
                tblsrAttachmentModel = list.get(0);
                if (tblsrAttachmentModel.getUPLOAD_TYPE() == 1) {
                    URL url = new URL(tblsrAttachmentModel.getDOWNLOAD_URL());
                    String tDir = "/data/dcrm_temp/";
                    String fPath = tDir + tblsrAttachmentModel.getSR_NUM() + "_" + Utility.getCurrentTimestamp() + "_" + tblsrAttachmentModel.getFILE_NAME().replaceAll(" ", "_");
                    File file = new File(fPath);
                    FileUtils.copyURLToFile(url, file);

                    HttpHeaders header = new HttpHeaders();
                    header.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + tblsrAttachmentModel.getFILE_NAME());
                    Path path = Paths.get(file.getAbsolutePath());
                    ByteArrayResource resource = new ByteArrayResource(Files.readAllBytes(path));

                    return ResponseEntity.ok()
                            .headers(header)
                            .contentLength(file.length())
                            .contentType(MediaType.parseMediaType("application/octet-stream"))
                            .body(resource);
                } else {
                    ByteArrayResource resource = new ByteArrayResource(("<a href='" + tblsrAttachmentModel.getFILE_PATH() + "'>" + tblsrAttachmentModel.getFILE_PATH() + "</a>").getBytes());
                    return ResponseEntity.ok()
                            .body(resource);
                }
            } else {
                ByteArrayResource resource = new ByteArrayResource("Error occurred. Please try later".getBytes());
                return ResponseEntity
                        .status(HttpStatus.FORBIDDEN)
                        .body(resource);
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
            ByteArrayResource resource = new ByteArrayResource("Error occurred. Please try later".getBytes());
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(resource);
        }
    }

    public void downloadActivityInFile(HttpServletResponse response, HttpServletRequest request, String fileType, String rowSpec,
                                       String activityNumber) {
        List<TBLSRActivityModel> activityList = new ArrayList<>();

        try {
            String query = "SELECT * FROM " + Utility.tbl_sr_activity + " " + SessionManager.getAttribute(SessionConstants.ACTIVITY_LAST_QUERY.name(), request) + " OFFSET 0 ROWS FETCH NEXT 10000 ROWS ONLY";
            /*if (rowSpec != null && !rowSpec.isEmpty() && rowSpec.equalsIgnoreCase("onlyCurrentRow") && activityNumber != null && !activityNumber.isEmpty()) {
                query = "SELECT * FROM " + Utility.tbl_sr_activity + " WHERE AND ACTIVITY_NUM='" + activityNumber + "'";
            } else */
            if (rowSpec != null && !rowSpec.isEmpty() && rowSpec.equalsIgnoreCase("onlyVisibleRow")) {
                query = "SELECT * FROM " + Utility.tbl_sr_activity + " " + SessionManager.getAttribute(SessionConstants.ACTIVITY_LAST_QUERY.name(), request) + SessionManager.getAttribute(SessionConstants.ACTIVITY_LAST_QUERY_PAGINATION.name(), request);
            }
            logger.info("Export query: " + query);
            Object listObject = commonDAO.getDataPostgres(query);
            activityList = new Gson().fromJson(Utility.ObjectToJson(listObject), new TypeToken<List<TBLSRActivityModel>>() {
            }.getType());

            String[] columnTitles = {"SR#", "Sequence", "Activity#", "Type", "Description",
                    "Owner", "Owner Group Name", "Status", "Comments", "Outbound Call",
                    "Planned Start", "Planned End", "Actual Start", "Completed Date", "Due", "Priority", "Escalated",
                    "Call Duration", "Change Request#", "Complete(%)", "Repeat"};

            String[] headers = {"SR_NUM", "SEQUENCE", "ACTIVITY_NUM", "ACTIVITY_TYPE_NAME", "DESCRIPTION",
                    "OWNER_NAME", "OWNER_GROUP_NAME", "STATUS_NAME", "COMMENTS", "OUTBOUND_CALL_STATUS_NAME",
                    "PLAN_START", "PLAN_END", "ACTUAL_START", "COMPLETED_AT", "DUE_AT", "PRIORITY_NAME", "IS_ESCALATED",
                    "CALL_DURATION", "CHANGE_REQUEST", "PERCENT_COMPLETE", "IS_REPEAT"};

            List<Map<String, Object>> mapList = new ArrayList<>();
            for (TBLSRActivityModel tblsrActivityModel : activityList) {
                HashMap<String, Object> hashMap = new HashMap<>();
                hashMap.put("SR_NUM", tblsrActivityModel.getSR_NUM());
                hashMap.put("SEQUENCE", tblsrActivityModel.getSEQUENCE());
                hashMap.put("ACTIVITY_NUM", tblsrActivityModel.getACTIVITY_NUM());
                hashMap.put("ACTIVITY_TYPE_NAME", tblsrActivityModel.getACTIVITY_TYPE_NAME());
                hashMap.put("DESCRIPTION", tblsrActivityModel.getDESCRIPTION());
                hashMap.put("OWNER_NAME", tblsrActivityModel.getOWNER_NAME());
                hashMap.put("OWNER_GROUP_NAME", tblsrActivityModel.getOWNER_GROUP_NAME());
                hashMap.put("STATUS_NAME", tblsrActivityModel.getSTATUS_NAME());
                hashMap.put("COMMENTS", tblsrActivityModel.getCOMMENTS());
                hashMap.put("OUTBOUND_CALL_STATUS_NAME", tblsrActivityModel.getOUTBOUND_CALL_STATUS_NAME());
                hashMap.put("PLAN_START", tblsrActivityModel.getPLAN_START_FT());
                hashMap.put("PLAN_END", tblsrActivityModel.getPLAN_END_FT());
                hashMap.put("ACTUAL_START", tblsrActivityModel.getACTUAL_START_FT());
                hashMap.put("COMPLETED_AT", tblsrActivityModel.getCOMPLETED_AT_FT());
                hashMap.put("DUE_AT", tblsrActivityModel.getDUE_AT_FT());
                hashMap.put("PRIORITY_NAME", tblsrActivityModel.getPRIORITY_NAME());
                hashMap.put("IS_ESCALATED", tblsrActivityModel.getIS_ESCALATED());
                hashMap.put("CALL_DURATION", tblsrActivityModel.getCALL_DURATION());
                hashMap.put("CHANGE_REQUEST", tblsrActivityModel.getCHANGE_REQUEST());
                hashMap.put("PERCENT_COMPLETE", tblsrActivityModel.getPERCENT_COMPLETE());
                hashMap.put("IS_REPEAT", tblsrActivityModel.getIS_REPEAT());
                mapList.add(hashMap);
            }

            if (fileType.equalsIgnoreCase("csv")) {
                generateActivityListCSV(response, mapList, headers, columnTitles);
            } else if (fileType.equalsIgnoreCase("excel")) {
                generateActivityListExcel(headers, mapList, response, columnTitles);
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
    }

    private void generateActivityListExcel(String[] headers, List<Map<String, Object>> mapList, HttpServletResponse response, String[] columnTitles) {
        try {
            response.setContentType("application/octet-stream");
            SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyyHHmmss");
            String filename = "ACTIVITY_LIST_" + dateFormat.format(new Date()) + ".xlsx";
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");


            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("Activity List");

            Row row = sheet.createRow(0);
            CellStyle headerCellStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerCellStyle.setFont(headerFont);
            DataFormat dataFormat = workbook.createDataFormat();
            headerCellStyle.setDataFormat(dataFormat.getFormat("@"));
            for (int i = 0; i < columnTitles.length; i++) {
                Cell cell = row.createCell(i);
                cell.setCellValue(columnTitles[i]);
                cell.setCellStyle(headerCellStyle);
                sheet.autoSizeColumn(i);
            }

            CellStyle childCellStyle = workbook.createCellStyle();
            childCellStyle.setDataFormat(dataFormat.getFormat("@"));
            for (int i = 0; i < mapList.size(); i++) {
                Row cellRow = sheet.createRow(i + 1);
                for (int j = 0; j < headers.length; j++) {
                    Cell cell = cellRow.createCell(j);
                    Object cellValue = mapList.get(i).get(headers[j]);
                    if (cellValue != null && !cellValue.toString().isEmpty()) {
                        cell.setCellValue(mapList.get(i).get(headers[j]).toString());
                    }
                    cell.setCellStyle(childCellStyle);
                    sheet.autoSizeColumn(j);
                }
            }

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            ByteArrayInputStream stream = new ByteArrayInputStream(outputStream.toByteArray());
            IOUtils.copy(stream, response.getOutputStream());
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
    }

    private void generateActivityListCSV(HttpServletResponse response, List<Map<String, Object>> mapList, String[] headers, String[] columnTitles) {
        try {

            SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyyHHmmss");
            String filename = "ACTIVITY_LIST_" + dateFormat.format(new Date()) + ".csv";
            response.setContentType("text/csv");
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");

            GenerateCSV.writeApacheCSVtoResponse(response.getWriter(), mapList, logger, headers, columnTitles);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
    }
}
