package com.reddot.ecrm.controller.PDFAndHotBill;

import com.reddot.ecrm.dto.PDFAndHotBill.HotBillSearchDTO;
import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.entity.cr.CRMasterEntity;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.model.User.UserModel;
import com.reddot.ecrm.service.pdfAndHotBill.HotBillService;
import com.reddot.ecrm.spring_config.session.SessionManager;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/HotBill/Report")
public class HotBillController {

    private final HotBillService hotBillService;

    @GetMapping
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        MDUserModel mdUserModel = SessionManager.getUserDetails(request);

        model.put("title", "Hot Bill");
        model.put("userType", mdUserModel.getUSER_TYPE().toUpperCase().toString());
        return "PDFAndHotBill/hotBillIndex";
    }

    @RequestMapping(value = "/Create", method = RequestMethod.GET)
    public String Create(ModelMap model, HttpServletRequest request, Principal principal) {
        new MenuViewer().setupSideMenu(model, request);
        MDUserModel mdUserModel = SessionManager.getUserDetails(request);

        model.put("userType", mdUserModel.getUSER_TYPE().toUpperCase().toString());
        return "PDFAndHotBill/hotBillCreate";
    }

    @RequestMapping(value = "/view/{transactionID}", method = RequestMethod.GET)
    public String view(ModelMap model, HttpServletRequest request, Principal principal, @PathVariable(name = "transactionID") String transactionID) {
        new MenuViewer().setupSideMenu(model, request);
        List<CompanyEntity> listOfCompany = hotBillService.getAllCompany();
        CRMasterEntity crMasterEntityData = hotBillService.getCRMasterEntityData(transactionID);
        HotBillSearchDTO hotBillSearchDTO = hotBillService.getCRMasterEntityDataToHotBillSearchDTO(transactionID);
        model.addAttribute("listOfCompany", listOfCompany);
        model.put("selectedCompany", crMasterEntityData.getCompanyName());
        model.put("hotBillSearchDTO", hotBillSearchDTO);

        return "PDFAndHotBill/hotBillView";

    }

    @RequestMapping(value = "/pdfDownload", method = RequestMethod.POST)
    @ResponseBody
    public void pdfDownload(HttpServletRequest request, HttpServletResponse response, @RequestParam(value = "fileName", required = true) String fileName) throws Exception {
        hotBillService.pdfDownload(request, response, fileName);
    }

}
