package com.reddot.ecrm.api.payload.response.cdr;

import lombok.Data;

import java.io.Serializable;

@Data
public class CDRDetailsErrorResponse implements Serializable {

    private String code;

    private String message;

    private String variables;
}
