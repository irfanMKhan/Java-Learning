package com.reddot.ecrm.controller.UAM.userRole;

import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.model.userRole.UserRoleDTO;
import com.reddot.ecrm.service.useRole.UserRoleService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/user-roles", method = RequestMethod.GET)
@RequiredArgsConstructor
public class UserRoleRestController {
    private final UserRoleService userRoleService;

    @GetMapping("/list")
    public CommonRestResponse getAllUseRoles(){
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error Occurred!", null);
        List<UserRoleDTO> resultList = userRoleService.getAllUserRoles();
        if(resultList.size() > 0){
            commonRestResponse.setCode(200);
            commonRestResponse.setMessage("All roles");
            commonRestResponse.setData(resultList);
        }
        else{
            commonRestResponse.setCode(404);
            commonRestResponse.setMessage("No roles found");
            commonRestResponse.setData(resultList);
        }
        return commonRestResponse;
    }

    @GetMapping("/{id}")
    public CommonRestResponse getUserRoleById(@PathVariable("id") String id){
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error Occurred!", null);
        UserRoleDTO userRoleDTO = userRoleService.getUserRoleById(id);
        if(userRoleDTO==null){
            commonRestResponse.setCode(404);
            commonRestResponse.setMessage("Role not found!");
            commonRestResponse.setData(null);
        }
        else{
            commonRestResponse.setCode(200);
            commonRestResponse.setMessage("Role found");
            commonRestResponse.setData(userRoleDTO);
        }
        return commonRestResponse;
    }

    @PostMapping("/add")
    public CommonRestResponse createUserRole(@RequestBody UserRoleDTO userRoleDTO){
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error Occurred!", null);
        UserRoleDTO result = userRoleService.createUserRole(userRoleDTO);
        if(result!=null){
            commonRestResponse.setCode(201);
            commonRestResponse.setMessage("Role created successfully");
            commonRestResponse.setData(result);
        }
        else{
            commonRestResponse.setMessage("Failed to create new role");
        }
        return commonRestResponse;
    }

    @PatchMapping("/update")
    public CommonRestResponse updateUserRole(@RequestBody UserRoleDTO userRoleDTO){
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error Occurred!", null);
        UserRoleDTO result = userRoleService.updateUserRole(userRoleDTO);
        if(result!=null){
            commonRestResponse.setCode(201);
            commonRestResponse.setMessage("Role updated successfully");
            commonRestResponse.setData(result);
        }
        else{
            commonRestResponse.setMessage("Failed to update new role");
        }
        return commonRestResponse;
    }
}
