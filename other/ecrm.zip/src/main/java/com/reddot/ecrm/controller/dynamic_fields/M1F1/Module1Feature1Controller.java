package com.reddot.ecrm.controller.dynamic_fields.M1F1;

import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.repository.CommonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/dynamic/m1f1")
public class Module1Feature1Controller {
    @Autowired
    private CommonRepository commonRepository;


    @GetMapping
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        String sql = String.format("select label_en, label_km , is_mandatory from tbl_dynamic_data  where module_name='%s' and feature_name='%s' and is_visible=true", "MODULE_A", "FEATURE_A");
        //System.out.println(dynamicFieldRepository.findAllByIsVisibleModuleAndFeature("MODULE_A","FEATURE_A"));

        List<Map<String, Object>> dynamicFieldEntities = (List<Map<String, Object>>) commonRepository.CommoGetData(sql);


        model.put("dynamicfield",dynamicFieldEntities);

        return "dynamicfiled/Module1Feature1";
    }


}
