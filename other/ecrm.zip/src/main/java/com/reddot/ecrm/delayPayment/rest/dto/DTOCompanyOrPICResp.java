package com.reddot.ecrm.delayPayment.rest.dto;

import com.reddot.ecrm.entity.company.CompanyEntity;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class DTOCompanyOrPICResp {
    private String keyword;
    private List<CompanyEntity> list;
}
