package com.reddot.ecrm.controller.survey.survey_question;

import com.reddot.ecrm.entity.survey.SurveyEntity;
import com.reddot.ecrm.enum_config.survey.survey_question.QuestionEnum;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.repository.survey.SurveyRepository;
import com.reddot.ecrm.service.survey.survey_question.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/question")
public class QuestionController {
    @Autowired
    private QuestionService questionService;

    @Autowired
    private SurveyRepository surveyRepository;

    @Autowired
    private CommonRepository commonRepository;

    @GetMapping
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        List<SurveyEntity> surveyEntityList = surveyRepository.findAll();
        System.out.println(surveyEntityList);
        QuestionEnum[] questionOptionTypeEnums = QuestionEnum.values();

        model.put("questionOptionType", questionOptionTypeEnums);
        model.put("surveyList", surveyEntityList);
        model.addAttribute("breadcrumb", "Survey Details");
        model.put("title", "Add Question");
        return "survey/addSurveyQuestion/addSurveyQuestion";
    }

    @GetMapping("/questionList")
    public String viewDashboardPage( ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        List<SurveyEntity> surveyEntityList = surveyRepository.findAll();

     //   System.out.println(questionService.getAllSurveyByID(7L));
        QuestionEnum[] questionOptionTypeEnums = QuestionEnum.values();

        model.put("questionOptionType", questionOptionTypeEnums);
        model.put("surveyList", surveyEntityList);
        model.put("title", "Question List");
        model.addAttribute("breadcrumb", "Survey Details");
        return "survey/addSurveyQuestion/surveyQuestionDashboard";
    }
}
