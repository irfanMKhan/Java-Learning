package com.reddot.ecrm.api.payload.response.contract;public class CreateCorporateCustomerResponse {
}
