package com.reddot.ecrm.controller.lead.settings;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.UserModel;
import com.reddot.ecrm.service.lead.settings.ProductInterestService;
import com.reddot.ecrm.service.user.UserService;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/lead/productInterest")
public class ProductInterestController {
    
    @Autowired
    private ProductInterestService productInterestService;
    
    @Autowired
    private UserService userService;
    
    @RequestMapping(value = "", method = RequestMethod.GET)
    public String viewProductInterests(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        
        model.addAttribute("title", "Product Interests");
        model.addAttribute("breadcrumb", "Product Interests");
        
        return "lead/settings/product_interest_list";
    }
    
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public String addProductInterest(ModelMap model, HttpServletRequest request, Principal principal) {
        new MenuViewer().setupSideMenu(model, request);
        
        List<UserModel> userData = new ArrayList<>();
        userData = new Gson().fromJson(Utility.ObjectToJson(userService.getUserByUserName(principal.getName())), new TypeToken<List<UserModel>>(){}
                .getType());
        
        model.addAttribute("userData", userData.get(0));
        model.addAttribute("title", "Add Product Interest");
        model.addAttribute("breadcrumb", "Add");
        
        return "lead/settings/product_interest_add";
    }
    
}