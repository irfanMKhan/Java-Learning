package com.reddot.ecrm.api.payload.request.shared.offering;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
public class ChangeSupplementaryOfferingRequest implements Serializable {
    private ReqHeader ReqHeader;

    private AccessInfo AccessInfo;

    private List<AddOffering> AddOffering;

    private List<DeleteOffering> DeleteOffering;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ReqHeader implements Serializable {
        private String ReqTime;

        private String Version;

        private String BusinessCode;

        private String Channel;

        private String AccessPassword;

        private String PartnerId;

        private String TransactionId;

        private String AccessUser;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class AccessInfo implements Serializable {
        private String ObjectId;

        private String ObjectIdType;
    }

    @Data
    public static class AddOffering implements Serializable {
        private EffectiveMode EffectiveMode;

        private OfferingId OfferingId;

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class EffectiveMode implements Serializable {
            private String Mode;
        }

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class OfferingId implements Serializable {
            private String OfferingId;
        }
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class DeleteOffering {
        private ExpireMode ExpireMode;

        private OfferingId OfferingId;

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class ExpireMode implements Serializable {
            private String Mode;
        }

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class OfferingId implements Serializable {
            private String OfferingId;
        }
    }
}
