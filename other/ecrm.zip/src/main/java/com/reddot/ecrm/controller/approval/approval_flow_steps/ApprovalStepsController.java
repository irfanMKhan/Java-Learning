package com.reddot.ecrm.controller.approval.approval_flow_steps;


import com.reddot.ecrm.entity.approval.ApprovalFlowEntity;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.userRole.RoleEntity;
import com.reddot.ecrm.model.userRole.UserRoleDTO;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.repository.approval.ApprovalFlowRepo;
import com.reddot.ecrm.repository.approval.ApprovalRulesRepo;
import com.reddot.ecrm.service.useRole.UserRoleService;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;


@Controller
@RequestMapping("/approval")
public class ApprovalStepsController {

    @Autowired
    ApprovalFlowRepo approvalFlowRepo;
    @Autowired
    ApprovalRulesRepo approvalRulesRepo;

    @Autowired
    CommonRepository commonRepository;

    @Autowired
    UserRoleService userRoleService;

    @GetMapping("/flow/steps")
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        Long tenantId = Utility.loggedInTenantId(request);
        List<ApprovalFlowEntity> approvalFlowEntityList = approvalFlowRepo.findAllByTenantId(tenantId);

        List<UserRoleDTO> userPositionList = userRoleService.getAllUserRoles();

        model.put("userPositionList", userPositionList);
        model.put("flowList", approvalFlowEntityList);
        model.addAttribute("breadcrumb", "Approval Flow");
        model.put("title", "Approval Flow Step");
        return "approval/approval_flow_steps";
    }
}


