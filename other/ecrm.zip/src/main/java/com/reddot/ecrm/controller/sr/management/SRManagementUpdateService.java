package com.reddot.ecrm.controller.sr.management;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.controller.sr.notificationMatrix.SRStatusNotifyExecutor;
import com.reddot.ecrm.dto.GlobalSettings.Address.MDAddressModel;
import com.reddot.ecrm.dto.sr.management.TBLSRActionModel;
import com.reddot.ecrm.dto.sr.management.TBLSRModel;
import com.reddot.ecrm.dto.sr.management.TBLSRModelDT;
import com.reddot.ecrm.dto.srsettings.Status.MDSrRemedyStatusModel;
import com.reddot.ecrm.dto.srsettings.subarea.MDSrSubAreaModel;
import com.reddot.ecrm.entity.SREntity;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.model.CustomerQueryInfoModel;
import com.reddot.ecrm.remedy.RemedyHelper;
import com.reddot.ecrm.repository.AccountServiceRepository;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.util.JsonIterator;
import com.reddot.ecrm.util.QueryBuilder;
import com.reddot.ecrm.util.SendMessage;
import com.reddot.ecrm.util.Utility;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.Column;
import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.lang.reflect.Field;
import java.net.FileNameMap;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SRManagementUpdateService {

    private final Logger responseTrackerLogger = LoggerFactory.getLogger("responseTrackerLogger");
    //  @Value("${soam.staticTocken}")
    String staticTocken = "";
    // @Value("${soam.customerinfo}")
    String customerinfo = "";
    Logger logger = LoggerFactory.getLogger("SRSettingsLogger");
    @Autowired
    private AccountServiceRepository accountserviceDAO;
    @Autowired
    private CommonRepository commonDAO;
    @Autowired
    private SRStatusNotifyExecutor srStatusNotifyExecutor;
    @Autowired
    private RemedyHelper remedyHelper;

    public CommonRestResponse addNewSR(HttpServletRequest request, String newSRData) {

        long currentTimeStamp = Utility.getCurrentTimestamp();
        Map<String, Object> insertData = new HashMap<>();
        CommonRestResponse commonRestResponse = new CommonRestResponse();
        try {

            TBLSRModelDT newSR = new Gson().fromJson(newSRData, new TypeToken<TBLSRModelDT>() {
            }.getType());

            String nonBlockingDuplicateQry = "Select SR_NUM, SR_STATUS_NAME from " + Utility.tbl_sr + " where MSISDN = '" + newSR.getMsisdn()
                    + "' AND SR_AREA_ID = '" + newSR.getSrAreaId() + "' AND SR_SUB_AREA_ID = '" + newSR.getSrSubAreaId() + "' AND SR_TYPE_ID = '"
                    + newSR.getSrTypeId() + "' AND SR_STATUS_ID IN (2,6) ORDER BY ID desc FETCH first 1 rows only";

            Object nonBlockingObject = commonDAO.getDataPostgres(nonBlockingDuplicateQry);
            List<TBLSRModel> nonBlockingSrList = new Gson().fromJson(Utility.ObjectToJson(nonBlockingObject), new TypeToken<List<TBLSRModel>>() {
            }.getType());

            MDSrSubAreaModel mdSrSubAreaModel = new MDSrSubAreaModel();
            Object subareaObject = commonDAO.getDataPostgres("SELECT * FROM " + Utility.md_sr_sub_area + " WHERE ID='" + newSR.getSrSubAreaId() + "'");
            List<MDSrSubAreaModel> subAreaList = new Gson().fromJson(Utility.ObjectToJson(subareaObject), new TypeToken<List<MDSrSubAreaModel>>() {
            }.getType());

            if (subAreaList.size() > 0) {
                mdSrSubAreaModel = subAreaList.get(0);
            }

            if (newSR.getSrNum() != null) {
                insertData.put("SR_NUM", newSR.getSrNum());
            } else {
                String nextId = commonDAO.getNextIdPostgres(Utility.seq_name_tbl_sr);
                insertData.put("SR_NUM", Utility.generateSRNumber(nextId));
            }

            insertData.put("ACCOUNT_NAME", newSR.getAccountName());
            insertData.put("CONTACT_NAME", newSR.getContactName());
            insertData.put("MSISDN", newSR.getMsisdn());
            insertData.put("SR_SERVICE_TYPE_ID", mdSrSubAreaModel.getSR_SERVICE_TYPE_ID());
            insertData.put("SR_SERVICE_TYPE_NAME", mdSrSubAreaModel.getSR_SERVICE_TYPE_NAME());
            insertData.put("SR_TYPE_ID", mdSrSubAreaModel.getSR_TYPE_ID());
            insertData.put("SR_TYPE_NAME", mdSrSubAreaModel.getSR_TYPE_NAME());
            insertData.put("SR_AREA_ID", mdSrSubAreaModel.getSR_AREA_ID());
            insertData.put("SR_AREA_NAME", mdSrSubAreaModel.getSR_AREA_NAME());
            insertData.put("SR_SUB_AREA_ID", mdSrSubAreaModel.getID());
            insertData.put("SR_SUB_AREA_NAME", mdSrSubAreaModel.getNAME());
            insertData.put("SLA_HR", newSR.getSlaHr());
            insertData.put("SRC_ID", newSR.getSrcId());
            insertData.put("SRC_NAME", newSR.getSrcName());
            insertData.put("SRC_LOCATION_ID", newSR.getSrcLocationId());
            insertData.put("SRC_LOCATION_NAME", newSR.getSrcLocationName());
            insertData.put("FIRST_CALL_RESOLVED", newSR.getFirstCallResolved());
            insertData.put("CELL_NAME", newSR.getCellName());
            insertData.put("ACC_TYPE_ID", newSR.getAccTypeId());
            insertData.put("ACC_TYPE_NAME", newSR.getAccTypeName());
            insertData.put("PRIORITY_ID", newSR.getPriorityId());
            insertData.put("PRIORITY_NAME", newSR.getPriorityName());
            insertData.put("SEVERITY_ID", newSR.getSeverityId());
            insertData.put("SEVERITY_NAME", newSR.getSeverityName());

            insertData.put("LOG_BY", Utility.getUserId(request));
            insertData.put("LOG_BY_NAME", Utility.getLoginName(request));
            insertData.put("COMMITED_BY", Utility.getUserId(request));
            insertData.put("COMMITED_BY_NAME", Utility.getLoginName(request));

            insertData.put("PAR_SR_NUM", newSR.getParSrNum());
//            insertData.put("REFERENCE_COMPLAINT", newSR.getReferenceComplaint());
            insertData.put("MASTER_ISSUE", newSR.getMasterIssue());
            insertData.put("SR_STATUS_ID", newSR.getSrStatusId());
            insertData.put("SR_STATUS_NAME", newSR.getSrStatusName());

            insertData.put("SR_SUB_STATUS_ID", newSR.getSrSubStatusId());
            if (newSR.getSrSubStatusId() == null) {
                insertData.put("SR_SUB_STATUS_NAME", null);
            } else {
                insertData.put("SR_SUB_STATUS_NAME", newSR.getSrSubStatusName());
            }

            insertData.put("OWNER_GROUP_ID", newSR.getOwnerGroupId());
            insertData.put("OWNER_GROUP_NAME", newSR.getOwnerGroupName());
            insertData.put("OWNER_ID", newSR.getOwnerId());
            insertData.put("OWNER_NAME", newSR.getOwnerName());
            insertData.put("ADDRESS_ID", newSR.getAddressId());

            insertData.put("FULL_ADDRESS", newSR.getFullAddress());
            insertData.put("SUMMARY", newSR.getSummary());
            insertData.put("DESCRIPTION", newSR.getDescription());

            insertData.put("ROOT_CAUSE_ID", newSR.getRootCauseId());
            if (newSR.getRootCauseId() == null) {
                insertData.put("ROOT_CAUSE_NAME", null);
            } else {
                insertData.put("ROOT_CAUSE_NAME", newSR.getRootCauseName());
            }

            insertData.put("ROOT_CAUSE_DETAIL", newSR.getRootCauseDetail());
            insertData.put("RESOLUTION_SOLUTION", newSR.getResolutionSolution());
            insertData.put("ESC_CANCEL_REASON", newSR.getEscCancelReason());
            insertData.put("ADDRESS", newSR.getAddress());

            insertData.put("ACC_CLASS_ID", newSR.getAccClassId());
            insertData.put("ACC_CLASS_NAME", newSR.getAccClassName());

            insertData.put("SUBMITTED_BY", Utility.getUserId(request));
            insertData.put("SUBMITTED_BY_NAME", Utility.getLoginName(request));

            insertData.put("CON_MOBILE_PHONE", newSR.getConMobilePhone());
            insertData.put("CON_EMAIL", newSR.getConEmail());
            insertData.put("IS_ESCALATED", newSR.getIsEscalated());
            insertData.put("IS_FEEDBACK_RECEIVED", newSR.getIsFeedbackReceived());

            insertData.put("FEEDBACK_TYPE", newSR.getFeedbackType());
            insertData.put("IS_WRONG_CLASSIFICATION", newSR.getIsWrongClassification());
            insertData.put("IS_REOPENED", newSR.getIsReopened());
            insertData.put("ACTIVE", 1);
            insertData.put("CREATED_BY", Utility.getUserId(request));
            insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
            insertData.put("CREATED_AT", currentTimeStamp);
            insertData.put("UPDATED_BY", Utility.getUserId(request));
            insertData.put("UPDATED_AT", currentTimeStamp);
            insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
            insertData.put("APPOINTMENT_DT", newSR.getAppointmentDt());
            insertData.put("LOG_AT", newSR.getLogAt());

            if (newSR.getSlaHr() != null && newSR.getSlaHr() > 0) {
                long committedTime = currentTimeStamp + (newSR.getSlaHr() * 60 * 60 * 1000);
                insertData.put("COMMITED_AT", committedTime);
            }

            insertData.put("SUBMITTED_AT", currentTimeStamp);
            insertData.put("PROBLEM_SINCE", newSR.getProblemSince());
            insertData.put("PROBLEM_TILL", newSR.getProblemTill());
            insertData.put("ADDRESS_REQUIRED", newSR.getAddressRequired());
            insertData.put("HAS_SMART_SCRIPT", newSR.getHasSmartScript());
            insertData.put("NEED_CUSTOMER_CONFIRMED", newSR.getNeedCustomerConfirmed());
            insertData.put("IS_NETWORK", newSR.getIsNetwork());

            insertData.put("ALTERNATIVE_NUMBER", newSR.getCustomerAlternativeNumber()); // added by suman roy
            insertData.put("VISIT_FREQUENCY_TYPE", newSR.getVisitFrequencyType()); // added by suman roy

            if (newSR.getSrStatusId() != null && newSR.getSrStatusId() == 2) {
                if (newSR.getEscCancelReason() == null || newSR.getEscCancelReason().isEmpty()) {
                    commonRestResponse.setCode(500);
                    commonRestResponse.setMessage("Cancel Reason is mandatory when complaint status is Cancel.");
                    return commonRestResponse;
                }
            }

            if (newSR.getSrStatusId() != null && ((newSR.getSrStatusId() == 4) || (newSR.getSrStatusId() == 5) || (newSR.getSrStatusId() == 6))) {
                if (newSR.getResolutionSolution() == null || newSR.getResolutionSolution().isEmpty()) {
                    commonRestResponse.setCode(500);
                    commonRestResponse.setMessage("Solution is mandatory when complaint status is Closed or Completed or Keep In View.");
                    return commonRestResponse;
                }
            }

            //Brand Name Block
            try {
                if (newSR.getMsisdn().toString().startsWith("88016")) {
                    insertData.put("BRAND_NAME", "Airtel");
                } else if (newSR.getMsisdn().toString().startsWith("88018")) {
                    insertData.put("BRAND_NAME", "Robi");
                } else {

                    CustomerQueryInfoModel customerQueryInfoModel = accountserviceDAO.findCustomerProductAll(customerinfo + newSR.getMsisdn(), staticTocken);
                    insertData.put("BRAND_NAME", getBrandName(customerQueryInfoModel.getIndividualInfo().getBrand()));
                }

            } catch (Exception e) {
                e.printStackTrace();
                logger.error(e.getMessage());
            }

            //Address Block
            MDAddressModel mdAddressModel = new MDAddressModel();
            if (newSR.getAddressId() != null && !String.valueOf(newSR.getAddressId()).isEmpty()) {
                try {
                    Map<String, Object> searchAddr = new HashMap<>();
                    Map<String, Object> whereSearchAddr = new HashMap<String, Object>();
                    searchAddr.put("ID", newSR.getAddressId());
                    whereSearchAddr.put("ID", "AND");

                    String query = QueryBuilder.getSelectWhereQuery(Utility.tbl_address, searchAddr, whereSearchAddr);
                    Object queryObject = commonDAO.getDataPostgres(query);
                    List<MDAddressModel> addressModelList = new Gson().fromJson(Utility.ObjectToJson(queryObject), new TypeToken<List<MDAddressModel>>() {
                    }.getType());
                    if (addressModelList.size() > 0) {
                        mdAddressModel = addressModelList.get(0);
                    }
                    if (mdAddressModel != null) {
                        insertData.put("DIVISION", mdAddressModel.getDIVISION_NAME());
                        insertData.put("DISTRICT", mdAddressModel.getDISTRICT_NAME());
                        insertData.put("THANA", mdAddressModel.getUPAZILA_PS_NAME());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    logger.error(e.getMessage(), e);
                }
            }

            //New Requirement Reference Complaint implementation
            try {
                StringBuilder refComplaint = new StringBuilder();
                StringBuilder refComplaintNote = new StringBuilder();
                if (mdAddressModel.getDISTRICT_NAME() != null && !mdAddressModel.getDISTRICT_NAME().isEmpty() && mdAddressModel.getUPAZILA_PS_NAME() != null && !mdAddressModel.getUPAZILA_PS_NAME().isEmpty()) {
                    String refComplaintQuery = "SELECT SR_NUM, RESOLUTION_SOLUTION, ESC_CANCEL_REASON, LOG_AT FROM " + Utility.tbl_sr + " WHERE MSISDN='" + newSR.getMsisdn() + "' AND EVENT_DATE>=DATE_TRUNC('month', CURRENT_DATE - INTERVAL '12 month') AND SR_AREA_NAME='" + mdSrSubAreaModel.getSR_AREA_NAME() + "' AND DISTRICT ILIKE '" + mdAddressModel.getDISTRICT_NAME() + "' AND THANA ILIKE '" + mdAddressModel.getUPAZILA_PS_NAME() + "' ORDER BY ID DESC";
                    Object refComplaintObject = commonDAO.getDataPostgres(refComplaintQuery);
                    List<TBLSRModel> refComplaintList = new Gson().fromJson(Utility.ObjectToJson(refComplaintObject), new TypeToken<List<TBLSRModel>>() {
                    }.getType());
                    if (!refComplaintList.isEmpty()) {
                        insertData.put("REFERENCE_COMPLAINT_COUNT", refComplaintList.size());
                        for (int i = 0; i < refComplaintList.size(); i++) {
                            if (i == 0) {
                                refComplaint = new StringBuilder(refComplaintList.get(i).getSR_NUM());
                                refComplaintNote = new StringBuilder(getReferenceNote(refComplaintList.get(i)));
                            } else if (i >= 5) {
                                break;
                            } else {
                                refComplaint.append(", ").append(refComplaintList.get(i).getSR_NUM());
                                refComplaintNote.append(";\n").append(getReferenceNote(refComplaintList.get(i)));
                            }
                        }
                    }
                }
                insertData.put("REFERENCE_COMPLAINT", refComplaint.toString());
                insertData.put("REF_SR_NOTES", refComplaintNote.toString());
            } catch (Exception e) {
                e.printStackTrace();
                logger.error(e.getMessage(), e);
            }

            try {
                if (newSR.getIsNetwork() != null && newSR.getIsNetwork().equals("1")) {
                    if (newSR.getFirstCallResolved() != null && newSR.getFirstCallResolved() == 1) {
                        newSR.setSrStatusName("Closed");
                    }

                    JSONObject jsonObject = remedyHelper.submitTroubleTicket(logger, newSR, mdAddressModel);
                    if (jsonObject != null && new JsonIterator().getFirstOccurrence(jsonObject, "StatusCode") != null && new JsonIterator().getFirstOccurrence(jsonObject, "StatusCode").toString().equalsIgnoreCase("Successful")) {
                        insertData.put("REMEDY_INCIDENT_NO", new JsonIterator().getFirstOccurrence(jsonObject, "RemedyIncidentNo"));
                    }
                    if (jsonObject != null && new JsonIterator().getFirstOccurrence(jsonObject, "RemedyIncidentStatus") != null) {
                        String remedyStatus = new JsonIterator().getFirstOccurrence(jsonObject, "RemedyIncidentStatus").toString();
                        Map<String, Object> searchStatus = new HashMap<String, Object>();
                        Map<String, Object> whereSearchStatus = new HashMap<String, Object>();
                        searchStatus.put("REMEDY_STATUS_NAME", remedyStatus);
                        whereSearchStatus.put("REMEDY_STATUS_NAME", "AND");

                        String query = QueryBuilder.getSelectWhereQuery(Utility.md_sr_remedy_status, searchStatus, whereSearchStatus);
                        Object queryObject = commonDAO.getDataPostgres(query);
                        List<MDSrRemedyStatusModel> remedyStatusModels = new Gson().fromJson(Utility.ObjectToJson(queryObject), new TypeToken<List<MDSrRemedyStatusModel>>() {
                        }.getType());
                        if (remedyStatusModels.size() > 0) {
                            insertData.put("SR_STATUS_ID", remedyStatusModels.get(0).getDCRM_STATUS_ID());
                            insertData.put("SR_STATUS_NAME", remedyStatusModels.get(0).getDCRM_STATUS_NAME());
                        }

                    }
                    logger.info("Remedy Response: " + jsonObject.toString());
                }
            } catch (Exception e) {
                e.printStackTrace();
                logger.error(e.getMessage(), e);
            }

            boolean isFirstCallResolved = (newSR.getFirstCallResolved() != null && newSR.getFirstCallResolved() == 1);

            if (isFirstCallResolved) {
                insertData.put("CLOSED_BY", Utility.getUserId(request));
                insertData.put("CLOSED_BY_NAME", Utility.getLoginName(request));
                insertData.put("CLOSED_AT", currentTimeStamp);
                insertData.put("SR_STATUS_ID", 6);
                insertData.put("SR_STATUS_NAME", "Closed");
                insertData.put("SLA_STOP_TIME", currentTimeStamp);
                insertData.put("DURATION_IN_HR", "0");
                insertData.put("IS_WITHIN_SLA", 1);
            }


            // modify the value to SREntity objects data type
            // that way we can insert to db
//            Field[] fields = SREntity.class.getDeclaredFields();

//            System.out.println("fields => " + Arrays.toString(fields));

//            for (Map.Entry<String, Object> entry : insertData.entrySet()) {
//                String key = entry.getKey();
//                Object value = entry.getValue();
//                for (Field field : fields) {
//                    try {
//                        String columnName = field.getAnnotation(Column.class).name();
//                        if (columnName.equalsIgnoreCase(key)) {
//                            Class<?> type = field.getType();
//                            Object underlyingType = type.cast(value);
//                            insertData.put(key, underlyingType);
//                        }
//                    } catch (Exception e) {
//                        logger.error(e.getLocalizedMessage(), e);
//                    }
//                }
//            }

//            for (Field field : fields) {
//
//                field.getType();
//            }
            // save sr
            // wrapper to update db
//            SREntity srEntity = getSREntity(insertData);

//            SREntity savedEntity = srRepository.save(srEntity);

            if (commonDAO.CommoInsert(Utility.tbl_sr, insertData, logger)) {
                commonRestResponse.setCode(200);
                if (nonBlockingSrList != null && !nonBlockingSrList.isEmpty()) {
                    commonRestResponse.setCode(202);
                    commonRestResponse.setMessage("An existing Service Request found with SR Number: " + nonBlockingSrList.get(0).getSR_NUM() + ", Status: " + nonBlockingSrList.get(0).getSR_STATUS_NAME() +
                            ".\n New Service Request has been created successfully. SR Number: " + newSR.getSrNum());
                } else {
                    commonRestResponse.setMessage("Service Request has been created successfully. SR Number: " + newSR.getSrNum());
                }
                if (!isFirstCallResolved && mdSrSubAreaModel.getREQUIRED_CUSTOMER_NOTIFICATION() != null && mdSrSubAreaModel.getREQUIRED_CUSTOMER_NOTIFICATION() == 1) {
                    System.out.println("Sending SMS");
//                    new SendMessage().send(String.valueOf(newSR.getMsisdn()), getSRSubmissionMessage(insertData.get("SR_NUM").toString(), newSR.getSrServiceTypeName()), "SR", request);
                }
                TBLSRActionModel tblsrActionModel = new TBLSRActionModel();
                tblsrActionModel.setSR_NUM(String.valueOf(newSR.getSrNum()));
                tblsrActionModel.setMSISDN(String.valueOf(newSR.getMsisdn()));
                tblsrActionModel.setSR_ACTION_TYPE_NAME("SR Created");
                tblsrActionModel.setREMARKS("SR created");
                insertSrAction(tblsrActionModel, request);

                if (!isFirstCallResolved && mdSrSubAreaModel.getREQUIRED_OWNER_NOTIFICATION() != null && mdSrSubAreaModel.getREQUIRED_OWNER_NOTIFICATION() == 1) {
//                    srStatusNotifyExecutor.notifyOwnerOverEmail(String.valueOf(newSR.getSrNum()), mdSrSubAreaModel, logger);
                    System.out.println("Email");
                }
            } else {
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("SR Creation failed");
            }

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Error Occurred. Please try later");
        } finally {
            insertData.clear();
        }
        return commonRestResponse;
    }

    private String getReferenceNote(TBLSRModel tblsrModel) {
        String result = "";
        int maxLength = 200;
        try {
            result = Utility.convertTimestampToDateTime(tblsrModel.getLOG_AT(), "yyyy-MM-dd HH:mm:ss") + ": ";
            if (tblsrModel.getRESOLUTION_SOLUTION() != null && !tblsrModel.getRESOLUTION_SOLUTION().isEmpty()) {
                result = result + tblsrModel.getRESOLUTION_SOLUTION();
                if (result.length() > maxLength) {
                    result = result.substring(0, (maxLength - 3)) + "...";
                }
            } else if (tblsrModel.getESC_CANCEL_REASON() != null && !tblsrModel.getESC_CANCEL_REASON().isEmpty()) {
                result = result + tblsrModel.getESC_CANCEL_REASON();
                if (result.length() > maxLength) {
                    result = result.substring(0, (maxLength - 3)) + "...";
                }
            } else {
                result = result + "N/A";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    private String getBrandName(String brandCode) {
        String brandName = "";
        switch (brandCode) {
            case "102":
            case "103":
            case "104":
            case "105":
            case "301":
                brandName = "Robi";
                break;
            case "106":
            case "201":
            case "302":
                brandName = "Airtel";
                break;
        }
        return brandName;
    }

    void insertSrAction(TBLSRActionModel tblsrActionModel, HttpServletRequest request) {
        Map<String, Object> insertData = new HashMap<String, Object>();
        try {
            insertData.put("SR_NUM", tblsrActionModel.getSR_NUM());
            insertData.put("MSISDN", tblsrActionModel.getMSISDN());
            insertData.put("REMARKS", tblsrActionModel.getREMARKS());
            insertData.put("SR_ACTION_TYPE_NAME", tblsrActionModel.getSR_ACTION_TYPE_NAME());
            insertData.put("OLD_DATA", tblsrActionModel.getOLD_DATA());
            insertData.put("NEW_DATA", tblsrActionModel.getNEW_DATA());
            insertData.put("CREATED_BY", Utility.getUserId(request));
            insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
            insertData.put("CREATED_AT", Utility.getCurrentTimestamp());
            insertData.put("CREATED_AT_DT", Timestamp.valueOf(LocalDateTime.now()));
            commonDAO.CommoInsert(Utility.tbl_sr_actions, insertData, logger);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        } finally {
            insertData.clear();
        }
    }

    public CommonRestResponse updateSR(HttpServletRequest request, String srData) {

        CommonRestResponse commonRestResponse = new CommonRestResponse();
        long timeStamp = Utility.getCurrentTimestamp();
        TBLSRActionModel tblsrActionModel = new TBLSRActionModel();
        try {

            TBLSRModelDT srModel = new Gson().fromJson(srData, new TypeToken<TBLSRModelDT>() {
            }.getType());

            TBLSRModel oldSr = getSRBySRNUM(String.valueOf(srModel.getSrNum()));

            Map<String, Object> updateData = new HashMap<>();
            updateData.put("SR_STATUS_ID", srModel.getSrStatusId());
            updateData.put("SR_STATUS_NAME", srModel.getSrStatusName());
            updateData.put("SUMMARY", srModel.getSummary());
            updateData.put("DESCRIPTION", srModel.getDescription());
            updateData.put("UPDATED_BY", Utility.getUserId(request));
            updateData.put("UPDATED_AT", timeStamp);
            updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
            updateData.put("MASTER_ISSUE", srModel.getMasterIssue());
            updateData.put("PAR_SR_NUM", srModel.getParSrNum());
            updateData.put("ROOT_CAUSE_ID", srModel.getRootCauseId());
            updateData.put("ROOT_CAUSE_NAME", srModel.getRootCauseName());
            updateData.put("ROOT_CAUSE_DETAIL", srModel.getRootCauseDetail());
            updateData.put("RESOLUTION_SOLUTION", srModel.getResolutionSolution());
            updateData.put("ADDRESS", srModel.getAddress());
            updateData.put("ADDRESS_ID", srModel.getAddressId());
            updateData.put("FULL_ADDRESS", srModel.getFullAddress());
            updateData.put("PROBLEM_SINCE", srModel.getProblemSince());
            updateData.put("PROBLEM_TILL", srModel.getProblemTill());
            updateData.put("IS_FEEDBACK_RECEIVED", srModel.getIsFeedbackReceived());
            updateData.put("FEEDBACK_TYPE", srModel.getFeedbackType());
            updateData.put("ESC_CANCEL_REASON", srModel.getEscCancelReason());
            updateData.put("CELL_NAME", srModel.getCellName());

            if (srModel.getIsEscalated() != null && srModel.getIsEscalated() == 1 && oldSr.getIS_ESCALATED() == 0) {
                updateData.put("IS_ESCALATED", srModel.getIsEscalated());
                updateData.put("ESCALATED_BY", Utility.getUserId(request));
                updateData.put("ESCALATED_BY_NAME", Utility.getLoginName(request));
                updateData.put("ESCALATED_AT", timeStamp);
            }

            if (srModel.getSrStatusId() != null && srModel.getSrStatusId() == 2) {
                if (srModel.getEscCancelReason() == null || srModel.getEscCancelReason().isEmpty()) {
                    commonRestResponse.setCode(500);
                    commonRestResponse.setMessage("Cancel Reason is mandatory when complaint status is Cancel.");
                    return commonRestResponse;
                }
                updateData.put("SLA_STOP_TIME", timeStamp);
            }

            if (srModel.getSrStatusId() != null && ((srModel.getSrStatusId() == 4) || (srModel.getSrStatusId() == 5) || (srModel.getSrStatusId() == 6))) {
                if (srModel.getResolutionSolution() == null || srModel.getResolutionSolution().isEmpty()) {
                    commonRestResponse.setCode(500);
                    commonRestResponse.setMessage("Solution is mandatory when complaint status is Closed or Completed or Keep In View.");
                    return commonRestResponse;
                }
            }

            boolean isReopened = false;

            if (srModel.getSrStatusId() != null && !srModel.getSrStatusId().equals(oldSr.getSR_STATUS_ID())) {
                if (srModel.getSrStatusId() != null && srModel.getSrStatusId() == 4) {
                    updateData.put("SLA_STOP_TIME", timeStamp);
                    updateData.put("KEEPINVIEW_DATE", timeStamp);
                    try {
                        long durationInHour = Math.round((System.currentTimeMillis() - oldSr.getSUBMITTED_AT()) / (1000.0 * 60 * 60));
                        updateData.put("DURATION_IN_HR", durationInHour);
                        if (durationInHour <= srModel.getSlaHr()) {
                            updateData.put("IS_WITHIN_SLA", 1);
                        } else if (durationInHour > srModel.getSlaHr()) {
                            updateData.put("IS_WITHIN_SLA", 2);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        logger.error(e.getMessage(), e);
                    }
                }

                if (srModel.getSrStatusId() != null && srModel.getSrStatusId() == 5) {
                    String countQuery = "SELECT COUNT(ID) AS ACTIVE_ACTIVITY_NUM FROM TBL_SR_ACTIVITY WHERE SR_NUM='" + srModel.getSrNum() + "' AND STATUS_ID NOT IN ('61', '302', '269')";
                    logger.info(countQuery);
                    int count = commonDAO.CommoNumberOfRow(countQuery);
                    if (count > 0) {
                        commonRestResponse.setCode(500);
                        commonRestResponse.setMessage(count + " Activity is in Open/In-Progress. Please Complete them before completing the Service Request");
                        return commonRestResponse;
                    }

                    updateData.put("RESOLVED_BY", Utility.getUserId(request));
                    updateData.put("RESOLVED_BY_NAME", Utility.getLoginName(request));
                    updateData.put("RESOLVED_AT", timeStamp);
//                    updateData.put("SLA_STOP_TIME", timeStamp);
                    try {
                        if (oldSr.getSLA_STOP_TIME() != null && oldSr.getSLA_STOP_TIME() >= 0) {
                            long durationInHour = Math.round((oldSr.getSLA_STOP_TIME() - oldSr.getSUBMITTED_AT()) / (1000.0 * 60 * 60));
                            updateData.put("DURATION_IN_HR", durationInHour);
                            if (durationInHour <= oldSr.getSLA_HR()) {
                                updateData.put("IS_WITHIN_SLA", 1);
                            } else if (durationInHour > oldSr.getSLA_HR()) {
                                updateData.put("IS_WITHIN_SLA", 2);
                            }
                        } else {
                            updateData.put("SLA_STOP_TIME", timeStamp);
                            long durationInHour = Math.round((System.currentTimeMillis() - oldSr.getSUBMITTED_AT()) / (1000.0 * 60 * 60));
                            updateData.put("DURATION_IN_HR", durationInHour);
                            if (durationInHour <= oldSr.getSLA_HR()) {
                                updateData.put("IS_WITHIN_SLA", 1);
                            } else if (durationInHour > oldSr.getSLA_HR()) {
                                updateData.put("IS_WITHIN_SLA", 2);
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        logger.error(e.getMessage(), e);
                    }
                }

                if (srModel.getSrStatusId() != null && srModel.getSrStatusId() == 6) {
                    String countQuery = "SELECT COUNT(ID) AS ACTIVE_ACTIVITY_NUM FROM TBL_SR_ACTIVITY WHERE SR_NUM='" + srModel.getSrNum() + "' AND STATUS_ID NOT IN ('61', '302', '269')";
                    logger.info(countQuery);
                    int count = commonDAO.CommoNumberOfRow(countQuery);
                    if (count > 0) {
                        commonRestResponse.setCode(500);
                        commonRestResponse.setMessage(count + " Activity is in Open/In-Progress. Please Complete them before closing the Service Request");
                        return commonRestResponse;
                    }

                    updateData.put("CLOSED_BY", Utility.getUserId(request));
                    updateData.put("CLOSED_BY_NAME", Utility.getLoginName(request));
                    updateData.put("CLOSED_AT", timeStamp);
                }

                if (srModel.getSrStatusId() != null && srModel.getSrStatusId() == 3) {
                    isReopened = true;
                    updateData.put("SLA_STOP_TIME", null);
                    updateData.put("DURATION_IN_HR", null);
                    updateData.put("IS_WITHIN_SLA", 0);
                    updateData.put("RESOLVED_BY", null);
                    updateData.put("RESOLVED_BY_NAME", null);
                    updateData.put("RESOLVED_AT", null);
                    updateData.put("IS_REOPENED", 1);
                    updateData.put("REOPEN_AT", timeStamp);
                    updateData.put("REOPEN_BY", Utility.getUserId(request));
                    updateData.put("REOPEN_BY_NAME", Utility.getLoginName(request));
                    updateData.put("EX_RESOLUTION", getExResolution(oldSr));
                }
                tblsrActionModel.setOLD_DATA(oldSr.getSR_STATUS_NAME());
                tblsrActionModel.setNEW_DATA(srModel.getSrStatusName());
                tblsrActionModel.setSR_ACTION_TYPE_NAME("Status Changed");
                tblsrActionModel.setREMARKS("Status Changed");
            }

            try {
                if (oldSr.getREMEDY_INCIDENT_NO() != null && !oldSr.getREMEDY_INCIDENT_NO().isEmpty() /*&& srModel.getSrStatusId() != null && srModel.getSrStatusId() != 6*/) {
                    JSONObject jsonObject = null;
                    if (isReopened) {
                        jsonObject = remedyHelper.updateReOpenedTroubleTicket(logger, srModel);
                    } else {
                        jsonObject = remedyHelper.updateTroubleTicket(logger, srModel);
                    }
                    if (jsonObject != null && new JsonIterator().getFirstOccurrence(jsonObject, "StatusCode") != null && new JsonIterator().getFirstOccurrence(jsonObject, "StatusCode").toString().equalsIgnoreCase("0")) {
                        System.out.println("Remedy Update successful");
                        System.out.println("Remedy Response: " + jsonObject.toString());
                    }
                    logger.info("Remedy Update Response: " + jsonObject.toString());
                }
            } catch (Exception e) {
                e.printStackTrace();
                logger.error(e.getMessage(), e);
            }

            Map<String, Object> whereData = new HashMap<>();
            whereData.put("SR_NUM", srModel.getSrNum());

            // update sr
//            SREntity srEntity = getSREntity(whereData);
//            SREntity updatedSrEntity = srRepository.save(srEntity);

            //
            if (commonDAO.CommoUpdate(Utility.tbl_sr, updateData, whereData, logger)) {
                commonRestResponse.setCode(200);
                commonRestResponse.setMessage("Update Successful!");
                srStatusNotifyExecutor.execute(String.valueOf(srModel.getSrNum()), request);
                tblsrActionModel.setSR_NUM(String.valueOf(srModel.getSrNum()));
                tblsrActionModel.setMSISDN(String.valueOf(srModel.getMsisdn()));
                if (isReopened) {
                    tblsrActionModel.setSR_ACTION_TYPE_NAME("Re-opened");
                    tblsrActionModel.setREMARKS("Re-opened");
                } else {
                    if (tblsrActionModel.getSR_ACTION_TYPE_NAME() != null && !tblsrActionModel.getSR_ACTION_TYPE_NAME().isEmpty()) {
                        tblsrActionModel.setSR_ACTION_TYPE_NAME("SR Updated");
                    }
                    if (tblsrActionModel.getREMARKS() != null && !tblsrActionModel.getREMARKS().isEmpty()) {
                        tblsrActionModel.setREMARKS("SR Updated");
                    }
                }
                insertSrAction(tblsrActionModel, request);
            } else {
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("Update Failed!");
            }

            whereData.clear();
            updateData.clear();

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Error Occurred. Please try later");
        }

        return commonRestResponse;
    }

    private String getExResolution(TBLSRModel oldSR) {
        StringBuilder sbExResolution = new StringBuilder();
        int maxLength = 3500;
        try {
            if (oldSR.getEX_RESOLUTION() != null) {
                sbExResolution = new StringBuilder(oldSR.getEX_RESOLUTION());
            }
            if (oldSR.getRESOLUTION_SOLUTION() != null && !oldSR.getRESOLUTION_SOLUTION().isEmpty()) {
                sbExResolution.append("** ").append(Utility.convertTimestampToDateTime(oldSR.getRESOLVED_AT(), "yyyy-MM-dd HH:mm:ss"))
                        .append("[resolved by ").append(oldSR.getRESOLVED_BY_NAME()).append("] : ")
                        .append(oldSR.getRESOLUTION_SOLUTION().trim()).append(";\n");
            }
            if (sbExResolution.toString().length() > maxLength) {
                sbExResolution = new StringBuilder(sbExResolution.substring(0, (maxLength - 3)) + "...");
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return sbExResolution.toString();
    }

    private String getSRSubmissionMessage(String srNo, String interactionType) {
        String message = "";
        switch (interactionType) {
            case "Complaint":
                message = "প্রিয় গ্রাহক, আপনার অভিযোগ নং " + srNo + " গ্রহণ করা হয়েছে যা দ্রুত সমাধানের চেষ্টা করা হবে, ধন্যবাদ।";
                break;
            case "Request":
                message = "প্রিয় গ্রাহক, আপনার অনুরোধ নং " + srNo + " গ্রহণ করা হয়েছে যা দ্রুত কার্যকর করার চেষ্টা করা হবে, ধন্যবাদ।";
                break;
            case "Feedback":
                message = "প্রিয় গ্রাহক, আপনার পরার্মশটি সাদরে গ্রহণ করা হয়েছে, ধন্যবাদ।";
                break;
            default:
                message = "আপনার সার্ভিস রিকোয়েস্ট নম্বর হচ্ছে " + srNo + " যা দ্রুত সমাধানের চেষ্টা করা হবে।";
        }
        return message;
    }

    private TBLSRModel getSRBySRNUM(String srNum) {

        TBLSRModel tblsrModel = new TBLSRModel();
        Map<String, Object> searchData = new HashMap<>();
        Map<String, Object> whereSearchType = new HashMap<>();
        try {

            searchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");
            searchData.put("SR_NUM", srNum);
            whereSearchType.put("SR_NUM", "AND");

            String query = QueryBuilder.getSelectWhereQuery(Utility.tbl_sr, searchData, whereSearchType);
            Object objects = commonDAO.getDataPostgres(query);
            List<TBLSRModel> tblsrModelList = new Gson().fromJson(Utility.ObjectToJson(objects), new TypeToken<List<TBLSRModel>>() {
            }.getType());
            if (tblsrModelList.size() > 0) {
                tblsrModel = tblsrModelList.get(0);
            }
            searchData.clear();
            whereSearchType.clear();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            searchData.clear();
            whereSearchType.clear();
        }
        return tblsrModel;
    }

    public CommonRestResponse sendSMS(String msisdn, String message, HttpServletRequest request) {
        CommonRestResponse commonRestResponse = new CommonRestResponse();
        try {
            if (new SendMessage().send(msisdn, message, "SR", request)) {
                commonRestResponse.setCode(200);
                commonRestResponse.setMessage("Message Sent Successfully!");
            } else {
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("Message Sending Failed!");
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Message Sending Failed!");
        }
        return commonRestResponse;
    }

    public CommonRestResponse acceptTicket(HttpServletRequest request, String srNum) {

        CommonRestResponse commonRestResponse = new CommonRestResponse();
        try {
            if (srNum.isEmpty()) {
                commonRestResponse.setCode(404);
                commonRestResponse.setMessage("Invalid SR Number!");
                return commonRestResponse;
            }
            Map<String, Object> updateData = new HashMap<>();
            updateData.put("SR_STATUS_ID", 3);
            updateData.put("SR_STATUS_NAME", "In Progress");
            updateData.put("SR_SUB_STATUS_ID", 2);
            updateData.put("SR_SUB_STATUS_NAME", "Assigned");
            updateData.put("UPDATED_BY", Utility.getUserId(request));
            updateData.put("UPDATED_AT", Utility.getCurrentTimestamp());
            updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
            updateData.put("ACCEPTED_BY", Utility.getUserId(request));
            updateData.put("ACCEPTED_AT", Utility.getCurrentTimestamp());
            updateData.put("ACCEPTED_BY_NAME", Utility.getLoginName(request));
            Map<String, Object> whereData = new HashMap<>();
            whereData.put("SR_NUM", Long.parseLong(srNum));

            TBLSRModel oldSR = getSRBySRNUM(srNum);

            if (commonDAO.CommoUpdate(Utility.tbl_sr, updateData, whereData, logger)) {
                commonRestResponse.setCode(200);
                commonRestResponse.setMessage("Accepted Done!");
                srStatusNotifyExecutor.execute(srNum, request);
                TBLSRActionModel tblsrActionModel = new TBLSRActionModel();
                tblsrActionModel.setSR_NUM(srNum);
                tblsrActionModel.setMSISDN(oldSR.getMSISDN());
                tblsrActionModel.setOLD_DATA("Open");
                tblsrActionModel.setNEW_DATA("In Progress");
                tblsrActionModel.setSR_ACTION_TYPE_NAME("SR Accepted");
                tblsrActionModel.setREMARKS("SR Accepted");
                insertSrAction(tblsrActionModel, request);
            } else {
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("Accept Failed!");
            }
            updateData.clear();
            whereData.clear();
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Error Occurred. Please try later!");
        }
        return commonRestResponse;
    }

    public CommonRestResponse attachmentFileUpload(MultipartFile file,
                                                   String comments,
                                                   String srNum,
                                                   String msisdn,
                                                   HttpServletRequest request) {

        CommonRestResponse commonRestResponse = new CommonRestResponse();
        String uploadDirRoot = "/data/tomcat/apache-tomcat-9.0.69/webapps/ROOT/srAttachment";
//        String uploadDirRoot = "E:\\";
        try {
            if (request.getLocalAddr().equals("10.101.2.116")) {
                uploadDirRoot = "/data/tomcat/apache-tomcat-9.0.69/webapps/ROOT/srAttachment";
            }
            if (file.isEmpty()) {
                commonRestResponse.setCode(400);
                commonRestResponse.setMessage("Invalid File!");
                return commonRestResponse;
            }
            String orgName = StringUtils.cleanPath(file.getOriginalFilename());
            if (orgName.contains("..")) {
                commonRestResponse.setCode(400);
                commonRestResponse.setMessage("Invalid File name!");
                return commonRestResponse;
            }

            String fileName = srNum + "_" + Utility.getCurrentTimestamp() + "_" + orgName.replaceAll(" ", "_");
            String dstFilePath = uploadDirRoot + "/" + fileName;
            String downloadUrl = "";


            byte[] bytes = file.getBytes();
            Path path = Paths.get(dstFilePath);

            FileNameMap fileNameMap = URLConnection.getFileNameMap();
            String mimeType = fileNameMap.getContentTypeFor(fileName);
            if (mimeType == null || (!mimeType.startsWith("image/") && !mimeType.equalsIgnoreCase("application/pdf"))) {
                commonRestResponse.setCode(400);
                commonRestResponse.setMessage("Invalid File type!");
                return commonRestResponse;
            }

            Files.write(path, bytes);
            Map<String, Object> insertData = new HashMap<String, Object>();
            insertData.put("SR_NUM", srNum);
            insertData.put("MSISDN", msisdn);
            insertData.put("UPLOAD_TYPE", 1);
            insertData.put("FILE_NAME", orgName);
            insertData.put("FILE_PATH", dstFilePath);
            insertData.put("UPLOADED_SERVER_IP", request.getLocalAddr());
            insertData.put("ACTIVE", 1);
            insertData.put("CREATED_BY", Utility.getUserId(request));
            insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
            insertData.put("CREATED_AT", Utility.getCurrentTimestamp());
            insertData.put("CREATED_AT_DT", new Date());
            insertData.put("UPDATED_BY", Utility.getUserId(request));
            insertData.put("UPDATED_AT", Utility.getCurrentTimestamp());
            insertData.put("UPDATED_AT_DT", new Date());
            insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
            insertData.put("COMMENTS", Utility.sanitizeInput(comments));
            insertData.put("DOWNLOAD_URL", downloadUrl);

            File fileObj = new File(dstFilePath);
            String fileSizeReadable = FileUtils.byteCountToDisplaySize(fileObj.length());

            insertData.put("FILE_SIZE", fileSizeReadable);
            insertData.put("FILE_TYPE", FilenameUtils.getExtension(fileName));

            if (commonDAO.CommoInsert(Utility.tbl_sr_attachment, insertData, logger)) {
                commonRestResponse.setCode(200);
                commonRestResponse.setMessage("Upload successful!");

                TBLSRActionModel tblsrActionModel = new TBLSRActionModel();
                tblsrActionModel.setSR_NUM(srNum);
                tblsrActionModel.setMSISDN(msisdn);
                tblsrActionModel.setSR_ACTION_TYPE_NAME("Attachment Uploaded");
                tblsrActionModel.setREMARKS(fileName + " Uploaded");
                insertSrAction(tblsrActionModel, request);

            } else {
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("Upload failed");
            }

        } catch (Exception e) {
            e.printStackTrace();
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Error Occurred. Please try later!");
            logger.error(e.getMessage(), e);
        }
        return commonRestResponse;
    }

    public CommonRestResponse attachmentURLUpload(String url,
                                                  String comments,
                                                  String srNum,
                                                  String msisdn,
                                                  HttpServletRequest request) {

        CommonRestResponse commonRestResponse = new CommonRestResponse();
        try {
            if (url.isEmpty()) {
                commonRestResponse.setCode(400);
                commonRestResponse.setMessage("Invalid URL!");
                return commonRestResponse;
            }

            Map<String, Object> insertData = new HashMap<>();
            insertData.put("SR_NUM", srNum);
            insertData.put("MSISDN", msisdn);
            insertData.put("UPLOAD_TYPE", 2);
            insertData.put("FILE_NAME", url);
            insertData.put("FILE_PATH", url);
            insertData.put("FILE_TYPE", "URL");
            insertData.put("UPLOADED_SERVER_IP", request.getRemoteHost());
            insertData.put("ACTIVE", 1);
            insertData.put("CREATED_BY", Utility.getUserId(request));
            insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
            long currentTimestamp = Utility.getCurrentTimestamp();
            insertData.put("CREATED_AT", currentTimestamp);
            insertData.put("CREATED_AT_DT", Timestamp.valueOf(LocalDateTime.now()));
            insertData.put("UPDATED_BY", Utility.getUserId(request));
            insertData.put("UPDATED_AT", currentTimestamp);
            insertData.put("UPDATED_AT_DT", Timestamp.valueOf(LocalDateTime.now()));
            insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
            insertData.put("COMMENTS", Utility.sanitizeInput(comments));

            if (commonDAO.CommoInsert(Utility.tbl_sr_attachment, insertData, logger)) {
                commonRestResponse.setCode(200);
                commonRestResponse.setMessage("Upload successful!");
            } else {
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("Upload failed");
            }
            TBLSRActionModel tblsrActionModel = new TBLSRActionModel();
            tblsrActionModel.setSR_NUM(srNum);
            tblsrActionModel.setMSISDN(msisdn);
            tblsrActionModel.setSR_ACTION_TYPE_NAME("URL attachment included");
            tblsrActionModel.setREMARKS(url + " Included");
            insertSrAction(tblsrActionModel, request);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Error Occurred. Please try later!");
        }
        return commonRestResponse;
    }

    private SREntity getSREntity(Map<String, Object> map) {
        Field[] fields = SREntity.class.getDeclaredFields();
        SREntity srEntity = new SREntity();
        for (Field field : fields) {
            try {
                String columnName = field.getAnnotation(Column.class).name();
                if (map.containsKey(columnName.toUpperCase())) {
                    field.setAccessible(true);
                    field.set(srEntity, map.get(columnName.toUpperCase()));
                }
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
        }
        return srEntity;
    }
}
