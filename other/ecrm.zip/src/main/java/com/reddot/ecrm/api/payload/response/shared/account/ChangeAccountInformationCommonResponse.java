package com.reddot.ecrm.api.payload.response.shared.account;

import lombok.Data;

@Data
public class ChangeAccountInformationCommonResponse {
    private Boolean isSuccess;
    private String code;
    private String message;
}
