package com.reddot.ecrm.controller.lead.settings;

import com.reddot.ecrm.dto.lead.settings.LeadRevenueDto;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.lead.settings.LeadRevenueService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequestMapping("lead/revenue")
public class LeadRevenueRestController {
    
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    
    @Autowired
    private LeadRevenueService leadRevenueService;
    
    @GetMapping("/dt/all")
    public DataTablesOutput<LeadRevenueDto> dtLeadRevenue(@Valid DataTablesInput input, HttpServletRequest request,
                                                    @RequestParam(value = "searchText", required = false) String searchText, @RequestParam(value = "searchCol", required = false) String searchCol) {
        return leadRevenueService.getDTLeadRevenue(input, request, searchText, searchCol);
    }
    
    @PostMapping("/add")
    public CommonRestResponse addLeadRevenue(HttpServletRequest request, @RequestBody LeadRevenueDto leadRevenueDto) {
        return leadRevenueService.addLeadRevenue(request, leadRevenueDto);
    }
    
    @GetMapping("/details")
    public CommonRestResponse getLeadRevenueById(@RequestParam("id") Long id) {
        return leadRevenueService.getLeadRevenueById(id);
    }
    
    @PostMapping("/update")
    public CommonRestResponse updateLeadRevenue(HttpServletRequest request,
                                             @RequestBody LeadRevenueDto leadRevenueDto) {
        return leadRevenueService.updateLeadRevenue(request, leadRevenueDto);
    }
    
}