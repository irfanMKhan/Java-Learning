package com.reddot.ecrm.dto.cdr;

import lombok.*;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SampleDummyData {
    private Integer Id;
    private String date;
    private String time;
    private String destination;
    private String durationOrAmount;
    private String calledNumber;
    private String amountUSD;
}
