package com.reddot.ecrm.dto.approval;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApprovalDetailsRequestDataDTO {
    private String approvalFlowName;
    private String approvalReqFor;
    private Long approvalReqMasterId;
}
