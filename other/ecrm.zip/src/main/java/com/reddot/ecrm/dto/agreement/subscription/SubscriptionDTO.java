package com.reddot.ecrm.dto.agreement.subscription;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SubscriptionDTO {
    private String contractNo;

    private String agreementNo;
    private String agreementDate;
    private String indvCustomerFullName;
    private String indvCustomerIdOrPassport;
    private String indvCustomerAddress;
    private String indvCustomerOccupation;
    private String indvCustomerPhone;
    private String indvCustomerEmail;

    private String corporateCustomerCompanyName;
    private String corporateCustomerRegNo;
    private String corporateCustomerAddress;
    private String corporateCustomerContactPerson;
    private String corporateCustomerPhone;
    private String corporateCustomerEmail;
    private String remarks;


}
