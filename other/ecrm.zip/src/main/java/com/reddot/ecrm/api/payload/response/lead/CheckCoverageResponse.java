package com.reddot.ecrm.api.payload.response.lead;

import lombok.Data;

@Data
public class CheckCoverageResponse {

    private Integer coverage_state;

}
