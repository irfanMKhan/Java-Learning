package com.reddot.ecrm.controller.lead.settings;

import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.service.lead.settings.CountryService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping(value = "/lead/address", method = RequestMethod.GET)
@RequiredArgsConstructor
public class AddressController {

    @Autowired
    CountryService countryService;

    @GetMapping("")
    public String viewLeadAddress(){
        return "redirect:/lead/address/list";
    }

    @GetMapping("/list")
    public String viewLeadAddressList(HttpServletRequest request, ModelMap model){
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Lead Address");

        model.addAttribute("countries", countryService.getAllCountriesWhereIsActive());
        return "lead/address/lead_address_list";
    }

    @GetMapping("/viewCountry")
    public String viewCountryPartial(HttpServletRequest request, ModelMap model){
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Lead Country");

        model.addAttribute("countries", countryService.getAllCountriesWhereIsActive());
        return "lead/address/countries_partial";
    }
    @GetMapping("/viewCityProvince")
    public String viewCityProvincePartial(HttpServletRequest request, ModelMap model){
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "City/Province");

        model.addAttribute("countries", countryService.getAllCountriesWhereIsActive());
        return "lead/address/city_province_partial";
    }
    @GetMapping("/viewKhanDistrict")
    public String viewKhanDistrictPartial(HttpServletRequest request, ModelMap model){
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Khan/District");

        model.addAttribute("countries", countryService.getAllCountriesWhereIsActive());
        return "lead/address/khan_district_partial";
    }
    @GetMapping("/viewSangkatCommune")
    public String viewSangkatCommunePartial(HttpServletRequest request, ModelMap model){
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Sangkat/Commune");

        model.addAttribute("countries", countryService.getAllCountriesWhereIsActive());
        return "lead/address/sangkat_commune_partial";
    }
}
