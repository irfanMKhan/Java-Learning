package com.reddot.ecrm.controller.tempo;

import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.service.tempo.TempPicService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping(value = "/temp-pic", method = RequestMethod.GET)
public class TempPicController {


    @GetMapping(value = "")
    public String TempPicPage(ModelMap model, HttpServletRequest request)
    {
        new MenuViewer().setupSideMenu(model, request);

        model.put("title", "PIC");
        model.addAttribute("moduleName", "PIC");
        model.addAttribute("title", "PIC");
        model.addAttribute("breadcrumb", "PIC");
        return "tempo/pic_list";
    }

}
