package com.reddot.ecrm.controller.swapSim;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.dto.swap.SwapSearchDTO;
import com.reddot.ecrm.dto.swap.SwapSimDTO;
import com.reddot.ecrm.entity.company.CompanyAccountEntity;
import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.entity.company.dto.CompanySearchReqDTO;
import com.reddot.ecrm.entity.msisdn.MsisdnEntity;
import com.reddot.ecrm.entity.swap.SwapSim;
import com.reddot.ecrm.module.commonConfig.CommonConfig;
import com.reddot.ecrm.service.swapSim.SwapSimService;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/swapSim/swap")
public class SwapSimRestController {

    private final SwapSimService swapSimService;
    private final Gson gson;


    @PostMapping(value = "/search", consumes = MediaType.APPLICATION_JSON_VALUE)
    public List<MsisdnEntity> search(HttpServletRequest request, @Valid DataTablesInput input, @Valid @RequestBody SwapSearchDTO swapSearchDTO) throws IllegalAccessException {
        return swapSimService.getSearchData(request, input, swapSearchDTO);
    }


    @PostMapping(value = "/view", consumes = MediaType.APPLICATION_JSON_VALUE)
    public DataTablesOutput<SwapSim> view(@RequestBody Map<String, Object> data) throws IllegalAccessException, JsonProcessingException {
        DataTablesInput input = new Gson().fromJson(Utility.ObjectToJson(data.get("input")), new TypeToken<DataTablesInput>(){}.getType());

        ObjectMapper mapper = new ObjectMapper();
        SwapSearchDTO swapSearchDTO = mapper.readValue(data.get("swapSearchDTO").toString(), SwapSearchDTO.class);
        HttpServletRequest request;
        return swapSimService.getSwapData( input, swapSearchDTO);

    }



    @PostMapping(value = "/singleDataView", consumes = MediaType.APPLICATION_JSON_VALUE)
    public SwapSim singleDataView(HttpServletRequest request, @Valid DataTablesInput input, @Valid @RequestBody SwapSearchDTO swapSearchDTO) throws IllegalAccessException {
        return swapSimService.getSingleData(swapSearchDTO.getId());
    }

    @PostMapping(value = "/activate")
    public String addSubContract(HttpServletRequest request, @RequestParam(value="file",required = false) MultipartFile file, @RequestParam("objectData") String objectData) {
        SwapSimDTO swapSimDTO = gson.fromJson(objectData, SwapSimDTO.class);
        return swapSimService.swap(swapSimDTO, file,request);
    }

    @RequestMapping(value = "/getCompany", method = RequestMethod.GET)
    public List<CompanyEntity> getCompany(HttpServletRequest request) {
        return swapSimService.GetAllCompanyNameWithContactTablePICMapped(request);
    }

    @RequestMapping(value = "/getAccountCode", method = RequestMethod.GET)
    public List<CompanyAccountEntity> getAccountCode(@RequestParam("companyId") Long companyId) {
        return swapSimService.getAllAccountCode(companyId);
    }

    @RequestMapping(value = "/getMsisdn", method = RequestMethod.GET)
    public List<MsisdnEntity> getMsisdn(@RequestParam("accountCode") String accountCode) {
        return swapSimService.getAllMsisdn(accountCode);
    }

    @RequestMapping(value = "/getIccId", method = RequestMethod.GET)
    public List<MsisdnEntity> getIccId(@RequestParam("accountCode") String accountCode) {
        return swapSimService.getAllIccId(accountCode);
    }

    @RequestMapping(value = "/getSwapType", method = RequestMethod.GET)
    public List<CommonConfig> getSwapType() {
        return swapSimService.getSwapType();
    }

    @RequestMapping(value = "/getEffectiveMode", method = RequestMethod.GET)
    public List<CommonConfig> getEffectiveMode() {
        return swapSimService.getEffectiveMode();
    }

}
