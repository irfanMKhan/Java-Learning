package com.reddot.ecrm.api.gateway.lead;


import com.google.gson.Gson;
import com.reddot.ecrm.api.exception.ApiRequestException;
import com.reddot.ecrm.api.exception.InvalidAccessTokenException;
import com.reddot.ecrm.api.exception.InvalidClientCredentialException;
import com.reddot.ecrm.api.payload.response.lead.CheckCoverageErrorResponse;
import com.reddot.ecrm.api.payload.response.lead.CheckCoverageResponse;
import com.reddot.ecrm.api.security.AuthorizationGateway;
import com.reddot.ecrm.api.utility.CommonConstant;
import com.reddot.ecrm.api.utility.HttpClient;
import com.reddot.ecrm.exception.CommonException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class LeadGateway {

    private final HttpClient httpClient;
    private final Gson gson;
    private final AuthorizationGateway authorizationGateway;
    @Value("${smart.igw.base.url}")
    String baseUrlIGW;

    public CheckCoverageResponse checkCoverage(String latitude, String longitude) {
        String apiUrl = baseUrlIGW + "/fwbb/v1.1/booking/checkCoverage?latitude=" + latitude + "&longitude=" + longitude;
        log.info("Class: LeadGateway -> requesting for checkCoverage -> " + apiUrl);

        try (Response response = httpClient.get(apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {

                String resBody = response.body().string();
                log.info("Class: LeadGateway -> response received for checkCoverage -> " + resBody);

                CheckCoverageResponse coverageResponse = gson.fromJson(resBody, CheckCoverageResponse.class);
                return coverageResponse;
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found for checkCoverage :: " + apiUrl);
                throw new CommonException("Url Not Found for checkCoverage :: " + apiUrl);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                log.debug("UNAUTHORIZED for checkCoverage :: " + apiUrl);
                throw new InvalidAccessTokenException();
            } else {
                CheckCoverageErrorResponse errorResponse = gson.fromJson(response.body().string(), CheckCoverageErrorResponse.class);
                log.error("ERROR Response for checkCoverage :: " + response.body().string());
                throw new ApiRequestException(
                        errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("CheckCoverage Api Request Error: {}", e.getMessage());
                throw new CommonException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("CheckCoverage Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("CheckCoverage Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            } else if (e instanceof CommonException) {
                log.debug("Url Not Found for checkCoverage :: " + apiUrl);
                throw new CommonException(e.getMessage());
            }
            log.error("CheckCoverage Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    private Map<String, String> getIGWHeaders() {
        String bearerToken = authorizationGateway.getTokenIGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }
}
