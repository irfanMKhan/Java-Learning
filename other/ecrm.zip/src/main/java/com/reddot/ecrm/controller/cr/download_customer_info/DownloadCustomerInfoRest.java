package com.reddot.ecrm.controller.cr.download_customer_info;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/cr/downloadCustomerInfo")
public class DownloadCustomerInfoRest {
}
