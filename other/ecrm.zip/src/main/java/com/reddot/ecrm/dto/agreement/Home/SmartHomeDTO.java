package com.reddot.ecrm.dto.agreement.Home;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SmartHomeDTO {
    private String contractNo;
    private String customerName;
    private String customerIdNo;
    private String customerIssuedDate;
    private String customerAddress;
    private String customerContactPerson;
    private String customerPhone;
    private String customerEmail;
    private String productName;
    private String productModel;
    private String deposit;
    private String paymentTerm;
    private String uniqueNumber;
    private String templateName;
}
