package com.reddot.ecrm.api.payload.response.transferOwnership;

import lombok.Data;

import java.io.Serializable;

@Data
public class ChangeCustProfileErrorResponse implements Serializable {
    private Error error;

    @Data
    public static class Error implements Serializable {
        private String exception;

        private String code;

        private String detail;

        private String message;
    }
}
