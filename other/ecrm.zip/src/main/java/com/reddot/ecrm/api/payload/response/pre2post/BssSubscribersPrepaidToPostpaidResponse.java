package com.reddot.ecrm.api.payload.response.pre2post;

import com.reddot.ecrm.api.payload.response.contract.subscriber.ChangePrepaidToPostpaidResponse;
import lombok.Data;

import java.io.Serializable;

@Data
public class BssSubscribersPrepaidToPostpaidResponse implements Serializable {
    private String transaction_id;

    private String transaction_status;

    private ChangePrepaidToPostpaidResponse.Metadata metadata;

    private Object data;

    @Data
    public static class Metadata implements Serializable {
        private String operator_id;

        private String channel_id;
    }
}
