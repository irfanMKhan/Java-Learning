package com.reddot.ecrm.controller.sendSMS;

import com.reddot.ecrm.api.payload.request.notification.SendSMSRequest;
import com.reddot.ecrm.api.payload.response.notification.SendSMSResponse;
import com.reddot.ecrm.dto.PDFAndHotBill.HotBillCreateDTO;
import com.reddot.ecrm.dto.PDFAndHotBill.HotBillSearchDTO;
import com.reddot.ecrm.entity.cr.CRMasterEntity;
import com.reddot.ecrm.service.pdfAndHotBill.HotBillService;
import com.reddot.ecrm.service.sendSMS.SendSMSService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/sendSMS")
public class SendSMSRestController {
    private final SendSMSService sendSMSService;

    @PostMapping(value = "/send", consumes = MediaType.APPLICATION_JSON_VALUE)
    public SendSMSResponse send(HttpServletRequest request, @RequestBody SendSMSRequest sendSMSRequest) {
        return sendSMSService.sendSMS( sendSMSRequest);
    }
}
