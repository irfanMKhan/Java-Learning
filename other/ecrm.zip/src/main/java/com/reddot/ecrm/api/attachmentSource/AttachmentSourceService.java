package com.reddot.ecrm.api.attachmentSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AttachmentSourceService {
    @Autowired
    private AttachmentSourceRepo attachmentSourceRepo;
}
