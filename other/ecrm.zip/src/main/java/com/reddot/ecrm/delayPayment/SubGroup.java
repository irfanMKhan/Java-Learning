package com.reddot.ecrm.delayPayment;

import lombok.*;

import javax.persistence.*;

@Entity
@Table(name = "tbl_subgroup", schema = "ecrm")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class SubGroup {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "account_code", unique = true)
    private String accountCode;
}
