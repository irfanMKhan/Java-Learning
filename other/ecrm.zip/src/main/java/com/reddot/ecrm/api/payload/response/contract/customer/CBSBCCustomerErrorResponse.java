package com.reddot.ecrm.api.payload.response.contract.customer;

import lombok.Data;

import java.io.Serializable;

@Data
public class CBSBCCustomerErrorResponse implements Serializable {
    private String code;

    private String variables;

    private String message;
}
