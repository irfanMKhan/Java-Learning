package com.reddot.ecrm.controller.opportunity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.api.payload.response.contract.account.QueryPurchasedSupplementaryOfferingResponse;
import com.reddot.ecrm.api.payload.response.contract.customer.CBSBCCustomerResponse;
import com.reddot.ecrm.dto.contact.ContactDTO;
import com.reddot.ecrm.dto.lead.LeadDto;
import com.reddot.ecrm.dto.opportunity.OpportunityDTO;
import com.reddot.ecrm.dto.opportunity.OpportunitySearchDTO;
import com.reddot.ecrm.dto.product.ProductDetailsDTO;
import com.reddot.ecrm.entity.account.AccountDetailsEntity;
import com.reddot.ecrm.entity.attachment.AttachmentEntity;
import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.entity.contact.ContactEntity;
import com.reddot.ecrm.entity.event.EventEntity;
import com.reddot.ecrm.entity.inventory.InventoryEntity;
import com.reddot.ecrm.entity.opportunity.OpportunityEntity;
import com.reddot.ecrm.entity.special_offer.SpecialOfferEntity;
import com.reddot.ecrm.enum_config.feature.RequestTypeEnum;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.service.account.AccountDetailsService;
import com.reddot.ecrm.service.attachment.AttachmentService;
import com.reddot.ecrm.service.company.CompanyService;
import com.reddot.ecrm.service.contact.ContactService;
import com.reddot.ecrm.service.contract.ContractService;
import com.reddot.ecrm.service.event.EventService;
import com.reddot.ecrm.service.lead.LeadService;
import com.reddot.ecrm.service.opportunity.OpportunityService;
import com.reddot.ecrm.service.opportunity.implementation.OpportunityServiceImplementation;
import com.reddot.ecrm.service.product.ProductDetailsService;
import com.reddot.ecrm.service.special_offer.SpecialOfferService;
import com.reddot.ecrm.spring_config.session.SessionManager;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Controller
@RequiredArgsConstructor
@RequestMapping(value = "/opportunity")
public class OpportunityViewController {

    private final OpportunityService opportunityService;
    private final ProductDetailsService productDetailsService;
    private final AttachmentService attachmentService;
    private final ContactService contactService;
    private final AccountDetailsService accountDetailsService;
    private final EventService eventService;
    private final SpecialOfferService specialOfferService;
    private final LeadService leadService;
    private final ContractService contractService;
    private final CompanyService companyService;
    
    @Value("${app.base_url}")
    private String baseUrl;

    @GetMapping
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Opportunity List");
        return "/opportunity/index";
    }

    @ResponseBody
    @GetMapping("/list")
    public List<OpportunityEntity> getOpportunityList() {
        return opportunityService.getAllOpportunity();
    }

    @ResponseBody
    @RequestMapping(value = "/list/search-dt", method = RequestMethod.POST)
    public DataTablesOutput<OpportunityEntity> getOpportunityListDT(@RequestBody Map<String, Object> data) throws JsonProcessingException {

        DataTablesInput input = new Gson().fromJson(
                Utility.ObjectToJson(data.get("dtInput")),
                new TypeToken<DataTablesInput>() {
                }.getType()
        );

        ObjectMapper mapper = new ObjectMapper();
        OpportunitySearchDTO opportunitySearchDTO = mapper.readValue(data.get("searchData").toString(), OpportunitySearchDTO.class);

        return opportunityService.searchDataTable(input, opportunitySearchDTO);
    }

    @ResponseBody
    @PostMapping("/list/search")
    public List<OpportunityEntity> searchOnOpportunityList(@Valid @RequestBody OpportunitySearchDTO searchDTO) {
        return opportunityService.searchOnAllOpportunity(searchDTO);
    }

    @GetMapping("/add")
    String viewOpportunityAdd(@RequestParam(value = "lead_number", required = false) String lead_number, ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        MDUserModel user = SessionManager.getUserDetails(request);

        String unique_id = "";

        model.put("title", "Add New Opportunity");
        model.put("login_name", user.getLOGIN_NAME());
        model.put("name", user.getNAME());
        model.put("logged_in_id", user.getID());
        model.put("unique_id", unique_id);
        model.put("lead_number", lead_number);

        return "/opportunity/add";
    }

    @GetMapping("/view")
    String viewOpportunityDetails(Long id, ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        MDUserModel user = SessionManager.getUserDetails(request);

        model.put("title", "View Opportunity");
        model.put("login_name", user.getLOGIN_NAME());
        model.put("name", user.getNAME());
        model.put("logged_in_id", user.getID());
        model.put("unique_id", opportunityService.findOpportunityById(id).getOpportunityNumber());
        model.put("requestTypeKey", RequestTypeEnum.Opportunity.getKey());
        model.put("requestTypeValue", RequestTypeEnum.Opportunity.getValue());

        return "/opportunity/view";
    }

    @ResponseBody
    @GetMapping(value = "/load/lead-details", consumes = MediaType.APPLICATION_JSON_VALUE)
    public LeadDto loadLeadDetails(String leadNumber) {
        return leadService.getLeadByLeadNumber(leadNumber);
    }

    @ResponseBody
    @GetMapping(value = "/add/check_customer_name", consumes = MediaType.APPLICATION_JSON_VALUE)
    public CompanyEntity checkCustomer(String customerName) {
        return opportunityService.getCompnayByCustomerName(customerName);
    }

    @ResponseBody
    @GetMapping(value = "/add/get-contract-info", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getContractInformation(String contractNumber) {
        CommonRestResponse response = contractService.getContractDetailsDataById(null, null, contractNumber);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @ResponseBody
    @PostMapping(value = "/add/submit", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> addOpportunity(@Valid @RequestBody OpportunityDTO opportunityDTO, HttpServletRequest request) throws JsonProcessingException {
        opportunityService.saveOpportunity(opportunityDTO, request);
        return new ResponseEntity<>("Success", HttpStatus.OK);
    }

    @ResponseBody
    @GetMapping("/list/add/check-coverage")
    public Boolean checkCoverage(String latitude, String longitude) {
        return opportunityService.CheckCoverage(latitude, longitude);
    }

    @ResponseBody
    @GetMapping("/list/add/cbs-bc-customer")
    public CBSBCCustomerResponse check_CBS_BC_Customer(String msisdn) throws UnsupportedEncodingException {
        return opportunityService.cbsbcCustomer(msisdn);
    }

    @ResponseBody
    @GetMapping("/list/add/query-purchased-supplementaryOffering")
    public QueryPurchasedSupplementaryOfferingResponse queryPurchasedSupplementaryOffering(String msisdn) throws UnsupportedEncodingException {
        return opportunityService.queryPurchasedSupplementaryOffering(msisdn);
    }

    @ResponseBody
    @GetMapping("/list/add/get/attachments")
    public List<AttachmentEntity> getAttachmentsList(String opportunityNumber) {
        if (Objects.equals(opportunityNumber, ""))
            return new ArrayList<AttachmentEntity>();
        else
            return attachmentService.findAllByOpportunityNumber(opportunityNumber);
    }

    @ResponseBody
    @GetMapping("/list/add/get/attachments-by-lead")
    public List<AttachmentEntity> getAttachmentsListByLead(String leadNumber) {
        if (Objects.equals(leadNumber, ""))
            return new ArrayList<AttachmentEntity>();
        else
            return attachmentService.findAllByLeadNumberAndIsFinalSaveTrue(leadNumber);
    }

    @ResponseBody
    @GetMapping("/list/add/get/contacts")
    public List<ContactEntity> getContactsList(String opportunityNumber) {
        if (Objects.equals(opportunityNumber, ""))
            return new ArrayList<ContactEntity>();
        else
            return contactService.findAllbyOpportunityNumber(opportunityNumber);
    }

    @ResponseBody
    @GetMapping("/list/add/get/contacts-dto")
    public List<ContactDTO> getContactDTOList(String opportunityNumber) {
        if (Objects.equals(opportunityNumber, ""))
            return new ArrayList<ContactDTO>();
        else
            return contactService.findAllDTObyOpportunityNumber(opportunityNumber);
    }

    @ResponseBody
    @GetMapping("/list/add/get/contacts-by-lead")
    public List<ContactEntity> getContactsListBylead(String leadId) {
        if (Objects.equals(leadId, ""))
            return new ArrayList<ContactEntity>();
        else
            return contactService.findAllByLeadIdFromLeadContact(leadId);
    }

    @ResponseBody
    @GetMapping("/list/add/get/events")
    public List<EventEntity> getEventsList(String opportunityNumber) {
        if (Objects.equals(opportunityNumber, ""))
            return new ArrayList<EventEntity>();
        else
            return eventService.findAllByOpportunityNumber(opportunityNumber);
    }

    @ResponseBody
    @GetMapping("/list/add/get/special-offers")
    public List<SpecialOfferEntity> getSpecialOffersList(String opportunityNumber) {
        if (Objects.equals(opportunityNumber, ""))
            return new ArrayList<SpecialOfferEntity>();
        else
            return specialOfferService.findAllSpecialOfferByOpportunityNumber(opportunityNumber);
    }

    @ResponseBody
    @GetMapping("/list/add/get/product_details")
    public List<ProductDetailsDTO> getProductDetailsList(String opportunityNumber) {
        if (Objects.equals(opportunityNumber, ""))
            return new ArrayList<ProductDetailsDTO>();
        else
            return productDetailsService.findAllbyOpportunityNumber(opportunityNumber);
    }

    @ResponseBody
    @GetMapping(value = "/add/check_msisdn_exist", consumes = MediaType.APPLICATION_JSON_VALUE)
    public boolean checkDuplicateMSISDN(String msisdn) {
        return opportunityService.CheckDuplicateMSISDN(msisdn);
    }

    @ResponseBody
    @GetMapping(value = "/add/check_msisdn_exist_message", consumes = MediaType.APPLICATION_JSON_VALUE)
    public String getDuplicateMSISDNMessage(String msisdn) throws JsonProcessingException {

        return opportunityService.queryMSISDN(msisdn);
//        return opportunityService.getDuplicateMSISDNMessage(msisdn);
    }

    @ResponseBody
    @GetMapping(value = "/add/check_iccid_exist_message", consumes = MediaType.APPLICATION_JSON_VALUE)
    public String validateIccid(String iccid) {
        return opportunityService.validateIccid(iccid);
    }

    @GetMapping("/edit")
    String viewOpportunityEdit(Long id, ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        MDUserModel user = SessionManager.getUserDetails(request);

        OpportunityEntity entity = opportunityService.findOpportunityById(id);

        if (Objects.equals(entity.getStatusName(), "Converted")) {
            return "redirect:/opportunity";
        }

        CompanyEntity companyEntity = companyService.findCompanyByName(entity.getCustomerName()).get();

        model.put("title", "Edit Opportunity");
        model.put("login_name", user.getLOGIN_NAME());
        model.put("name", user.getNAME());
        model.put("logged_in_id", user.getID());
        model.put("oppId", entity.getId());
        model.put("unique_id", entity.getOpportunityNumber());
        model.put("is_converted", entity.getIsConvertedToContract());

        model.put("requestTypeKey", RequestTypeEnum.Opportunity.getKey());
        model.put("requestTypeValue", RequestTypeEnum.Opportunity.getValue());


        model.put("company_id", companyEntity.getId());
        
        model.addAttribute("baseUrl", baseUrl);

        return "/opportunity/edit";
    }

    @ResponseBody
    @GetMapping("/edit/get/details")
    public OpportunityEntity getOpportunityDetails(String opportunityNumber) {
        return opportunityService.findOpportunityByOpportunityNumber(opportunityNumber);
    }

    @ResponseBody
    @GetMapping("/edit/get/account-details")
    public AccountDetailsEntity getOpportunityAccountDetails(String opportunityNumber) {
        return accountDetailsService.getAccountDetailsByOpportunityNumber(opportunityNumber);
    }

    @ResponseBody
    @PostMapping(value = "/edit/submit", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> editOpportunity(@Valid @RequestBody OpportunityDTO opportunityDTO, HttpServletRequest request) throws JsonProcessingException {
        opportunityService.editOpportunity(opportunityDTO, request);
        return new ResponseEntity<>("Success", HttpStatus.CREATED);
    }

    @ResponseBody
    @PostMapping(value = "/add/check_msisdn_exist/getMsisdn", consumes = MediaType.APPLICATION_JSON_VALUE)
    public InventoryEntity checkDuplicateMSISDNReturnMsisdn(@RequestBody String msisdn) {
        return opportunityService.CheckDuplicateMSISDNAndReturnMsisdn(msisdn);
    }

    @ResponseBody
    @PostMapping(value = "/add/check_msisdn_exist/getMsisdn/Unused", consumes = MediaType.APPLICATION_JSON_VALUE)
    public void ReservedMsisdnMarkUnused(@RequestBody List<String> msisdnList) {
        if (msisdnList != null) {
            for (String msisdn : msisdnList) {
                opportunityService.ReservedMsisdnMarkUnused(msisdn);
            }
        }
    }
}
