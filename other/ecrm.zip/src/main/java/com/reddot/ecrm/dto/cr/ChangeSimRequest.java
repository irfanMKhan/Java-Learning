package com.reddot.ecrm.dto.cr;

import com.reddot.ecrm.dto.attachment.AttachmentDTO;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class ChangeSimRequest {
    private String companyId;
    private String companyName;
    private List<NewRequestDTO> newRequestDTOList;
    private List<AttachmentDTO> attachmentList;
}
