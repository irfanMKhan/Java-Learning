package com.reddot.ecrm.delayPayment.rest.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PromiseToPayInvoiceMappingReqDTO {
//    private String acctKey;
//    private String custKey;
//    private String subKey;
//    private String primaryIdentity;
//    private String transType;
//    private String invoiceID;
//    private String invoiceNo;
//    private String billCycleID;
//    private String billCycleBeginTime;
//    private String billCycleEndTime;
//    private String invoiceAmount;
//    private String openAmount;
//    private String disputeAmount;
//    private String currencyId;
//    private String invoiceDate;
//    private String dueDate;
//    private String status;
//    private String invoiceDetailInvoiceID;
//    private String serviceCategory;
//    private String chargeCode;
//    private String chargeAmount;
//    private String agreedAmount;

//    @JsonProperty("AcctKey")
//    private String AcctKey;
//    @JsonProperty("CustKey")
//    private String CustKey;
//    @JsonProperty("SubKey")
//    private String SubKey;
//    @JsonProperty("PrimaryIdentity")
//    private String PrimaryIdentity;
//    @JsonProperty("TransType")
//    private String TransType;
//    @JsonProperty("InvoiceID")
//    private String InvoiceID;
//    @JsonProperty("InvoiceNo")
//    private String InvoiceNo;
//    @JsonProperty("BillCycleID")
//    private String BillCycleID;
//    @JsonProperty("BillCycleBeginTime")
//    private String BillCycleBeginTime;
//    @JsonProperty("BillCycleEndTime")
//    private String BillCycleEndTime;
//    @JsonProperty("InvoiceAmount")
//    private String InvoiceAmount;
//    @JsonProperty("OpenAmount")
//    private String OpenAmount;
//    @JsonProperty("DisputeAmount")
//    private String DisputeAmount;
//    @JsonProperty("CurrencyID")
//    private String CurrencyID;
//    @JsonProperty("InvoiceDate")
//    private String InvoiceDate;
//    @JsonProperty("DueDate")
//    private String DueDate;
//    @JsonProperty("Status")
//    private String Status;
//    @JsonProperty("InvoiceDetail")
//    private PromiseToPayInvoiceDetail InvoiceDetail;


    private String acctKey;
    private String custKey;
    private String subKey;
    private String primaryIdentity;
    private String transType;
    private String invoiceID;
    private String invoiceNo;
    private String billCycleID;
    private String billCycleBeginTime;
    private String billCycleEndTime;
    private String invoiceAmount;
    private String openAmount;
    private String disputeAmount;
    private String currencyId;
    private String invoiceDate;
    private String dueDate;
    private String status;

    private String agreedAmount;

    private String invoiceDetailInvoiceID;
    private String serviceCategory;
    private String chargeCode;
    private String chargeAmount;


//    private String agreedPaidDate;
//    private String agreedPaidAmt;
//    private String remark;
//    private String attachment;
    //private PromiseToPayInvoiceDetail invoiceDetail;
}
