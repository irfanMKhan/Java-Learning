package com.reddot.ecrm.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CommonAdvanceSearchDTO {
    // private Map<String, String> keyValueMap;

    private Boolean searchType;  //exact match or partial match
    private List<String> searchKeys;
    private List<String> searchValue;
    private List<String> dateKeys;  // table column name same for start date and end date
    private List<String> startDate;
    private List<String> endDate;
    private List<String> amountKeys; // table column name same for start amount and end amount
    private List<String> startAmount;
    private List<String> endAmount;
}
