package com.reddot.ecrm.api.payload.response.opportunity;

import lombok.Data;

import java.io.Serializable;

@Data
public class SearchInventoryByListMSISDNErrorResponse implements Serializable {
  private String variables;

  private String code;

  private String message;
}
