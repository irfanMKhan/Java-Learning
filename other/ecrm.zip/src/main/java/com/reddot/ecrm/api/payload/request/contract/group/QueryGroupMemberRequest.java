package com.reddot.ecrm.api.payload.request.contract.group;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.lang.String;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class QueryGroupMemberRequest implements Serializable {
  private String IncludePaymentRelation;

  private ReqHeader ReqHeader;

  private String GroupId;

  @Data
  @AllArgsConstructor
  @NoArgsConstructor

  public static class ReqHeader implements Serializable {
    private String ReqTime;

    private String Version;

    private String Channel;

    private String AccessPassword;

    private String PartnerId;

    private String TransactionId;

    private String AccessUser;
  }
}
