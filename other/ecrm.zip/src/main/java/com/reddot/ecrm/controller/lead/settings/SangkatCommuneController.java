package com.reddot.ecrm.controller.lead.settings;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.UserModel;
import com.reddot.ecrm.service.lead.settings.CityProvinceService;
import com.reddot.ecrm.service.lead.settings.CountryService;
import com.reddot.ecrm.service.lead.settings.KhanDistrictService;
import com.reddot.ecrm.service.lead.settings.SangkatCommuneService;
import com.reddot.ecrm.service.user.UserService;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/lead/sangkatCommune")
public class SangkatCommuneController {
    
    @Autowired
    private SangkatCommuneService sangkatCommuneService;
    
    @Autowired
    private KhanDistrictService khanDistrictService;
    
    @Autowired
    private CityProvinceService cityProvinceService;
    
    @Autowired
    private CountryService countryService;
    
    @Autowired
    private UserService userService;
    
    @RequestMapping(value = "", method = RequestMethod.GET)
    public String viewSangkatCommunes(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        
        model.addAttribute("title", "Sangkats/Communes");
        model.addAttribute("countries", countryService.getAllCountriesWhereIsActive());
        model.addAttribute("cityProvinces", cityProvinceService.getAllCityProvincesWhereIsActive());
        model.addAttribute("khanDistricts", khanDistrictService.getAllKhanDistrictsWhereIsActive());
        model.addAttribute("breadcrumb", "Sangkats/Communes");
        
        return "lead/settings/sangkat_commune_list";
    }
    
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public String addSangkatCommune(ModelMap model, HttpServletRequest request, Principal principal) {
        new MenuViewer().setupSideMenu(model, request);
        
        model.addAttribute("title", "Add Sangkat/Commune");
        model.addAttribute("countries", countryService.getAllCountriesWhereIsActive());
        model.addAttribute("breadcrumb", "Add");
        
        return "lead/settings/sangkat_commune_add";
    }
    
}