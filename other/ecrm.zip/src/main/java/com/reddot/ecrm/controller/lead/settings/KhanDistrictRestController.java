package com.reddot.ecrm.controller.lead.settings;

import com.reddot.ecrm.dto.lead.settings.KhanDistrictDto;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.lead.settings.KhanDistrictService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("lead/khanDistrict")
public class KhanDistrictRestController {
    
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    
    @Autowired
    private KhanDistrictService khanDistrictService;
    
    @GetMapping("/dt/all")
    public DataTablesOutput<KhanDistrictDto> dtKhanDistrict(HttpServletRequest request,
                                                            DataTablesInput input,
                                                            @RequestParam(value = "countryName", required = false, defaultValue = "") String countryName,
                                                            @RequestParam(value = "cityProvinceName", required = false, defaultValue = "") String cityProvinceName,
                                                            @RequestParam(value = "khanDistrictName", required = false, defaultValue = "") String khanDistrictName,
                                                            @RequestParam(value = "ngbssDistrictId", required = false, defaultValue = "") String ngbssDistrictId,
                                                            @RequestParam(value = "isActive", required = false, defaultValue = "") String isActive) {
        return khanDistrictService.getDTKhanDistrict(
                request,
                input,
                countryName,
                cityProvinceName,
                khanDistrictName,
                ngbssDistrictId,
                isActive);
    }
    
    @GetMapping("/all")
    public ResponseEntity<?> getAllKhanDistricts(){
        List<KhanDistrictDto> khanDistricts = khanDistrictService.getAllKhanDistrictsWhereIsActive();
        if(khanDistricts.isEmpty()){
            return new ResponseEntity<>("No data found!", HttpStatus.NO_CONTENT);
        }
        else return new ResponseEntity<>(khanDistricts, HttpStatus.OK);
    }
    
    @PostMapping("/add")
    public CommonRestResponse addKhanDistrict(HttpServletRequest request,
                                              @RequestBody KhanDistrictDto khanDistrictDto) {
        return khanDistrictService.addKhanDistrict(request, khanDistrictDto);
    }
    
    @GetMapping("/details")
    public CommonRestResponse getKhanDistrictById(@RequestParam("id") Long id) {
        return khanDistrictService.getKhanDistrictById(id);
    }
    
    @PostMapping("/update")
    public CommonRestResponse updateKhanDistrict(HttpServletRequest request,
                                                 @RequestBody KhanDistrictDto khanDistrictDto) {
        return khanDistrictService.updateKhanDistrict(request, khanDistrictDto);
    }
    
    @GetMapping("/byCityProvince")
    public List<KhanDistrictDto> getAllByCityProvinceId(@RequestParam("cityProvinceId") Long cityProvinceId) {
        return khanDistrictService.getAllKhanDistrictsWhereIsActiveByCityProvinceId(cityProvinceId);
    }
    
}