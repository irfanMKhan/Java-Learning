package com.reddot.ecrm.delayPayment;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;

@Getter
@Setter
public class PromiseToPayListEntireListResponseObj {
    private String dueAmount;
    private String statusId;
    private String statusName;
    private String remarks;
    private String dateOfAgreedPayment;
    private String effectiveDate;
    private String attachment;

    private Long id;
    private Long promiseToPayId;
    private String acctKey;
    private String custKey;
    private String primaryIdentity;
    private String invoiceID;
    private String invoiceNo;
    private String billCycleID;
    private String billCycleBeginTime;
    private String billCycleEndTime;
    private String invoiceAmount;
    private String openAmount;
    private String disputeAmount;
    private String invoiceDate;
    private String dueDate;
}
