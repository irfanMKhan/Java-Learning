package com.reddot.ecrm.api.payload.request.transferOwnership;

import lombok.Data;

import java.io.Serializable;

@Data
public class ChangeCustProfileRequest implements Serializable {


    public ReqHeader ReqHeader;

    public Customer Customer;


    @Data
    public static class Customer implements Serializable {

        public String CustId;

        public Name Name;

    }

    @Data
    public static class Name implements Serializable {


        public String FirstName;

        public String MiddleName;

        public String LastName;

    }

    @Data
    public static class ReqHeader implements Serializable {

        public String Version;

        public String PartnerId;

        public String BusinessCode;

        public String TransactionId;

        public String ReqTime;

        public String Channel;

        public String AccessUser;

        public String AccessPassword;

    }
}
