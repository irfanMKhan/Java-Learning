package com.reddot.ecrm.controller.sendToBo;

import com.reddot.ecrm.dto.sendToBo.SendToBoEmailDto;
import com.reddot.ecrm.service.lead.LeadEmailDto;
import com.reddot.ecrm.service.sendToBo.SendToBoService;
import freemarker.template.TemplateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.IOException;

@RestController
@RequestMapping("/back-office")
public class SendToBoRestController {
    
    @Autowired
    private SendToBoService sendToBoService;
    
    @PostMapping("/sendMail")
    public ResponseEntity<?> sendMail(HttpServletRequest request, @Valid @RequestBody SendToBoEmailDto sendToBoEmailDto) throws MessagingException, TemplateException, IOException {
        if (sendToBoService.sendMailToBo(sendToBoEmailDto, request)) {
            return new ResponseEntity<>("Email has been sent successfully!", HttpStatus.OK);
        } else return new ResponseEntity<>("Failed to send email!", HttpStatus.BAD_REQUEST);
    }
    
}
