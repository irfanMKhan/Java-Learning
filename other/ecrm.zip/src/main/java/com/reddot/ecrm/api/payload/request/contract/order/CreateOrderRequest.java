package com.reddot.ecrm.api.payload.request.contract.order;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateOrderRequest implements Serializable {
    private Order Order;

    private List<Account> Account;

    private Customer Customer;

    private Subscriber Subscriber;

    private ReqHeader ReqHeader;

    private PrimaryOffering PrimaryOffering;

    private List<SupplementaryOffering> SupplementaryOffering;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Order implements Serializable {
        private String OrderType;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Account implements Serializable {
        private NewAccount NewAccount;

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class NewAccount implements Serializable {
            private String AcctName;

            private List<Address> Address;

            private String Currency;

            private List<CreditLimit> CreditLimit;

            private List<BillMedium> BillMedium;

            private String PaymentType;

            private String Title;

            private List<AdditionalProperty> AdditionalProperty;

            private Name Name;

            @Data
            @AllArgsConstructor
            @NoArgsConstructor

            public static class Address implements Serializable {
                private String Address7;

                private String Address11;

                private String Address5;

                private String Address2;

                private String Address3;

                private String Address1;

                private String AddressType;
            }

            @Data
            @AllArgsConstructor
            @NoArgsConstructor
            public static class CreditLimit implements Serializable {
                private String LimitType;

                private String LimitValue;
            }

            @Data
            @AllArgsConstructor
            @NoArgsConstructor
            public static class BillMedium implements Serializable {
                private String BillMediumId;

                private String BillMediumCode;

                private String BillContentType;
            }

            @Data
            @AllArgsConstructor
            @NoArgsConstructor
            public static class AdditionalProperty implements Serializable {
                private String Value;

                private String Code;
            }

            @Data
            @AllArgsConstructor
            @NoArgsConstructor
            public static class Name implements Serializable {
                private String FirstName;

                private String LastName;

                private String MiddleName;
            }
        }
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Customer implements Serializable {
        private NewCustomer NewCustomer;

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class NewCustomer implements Serializable {
            private String CustLevel;

            private List<Account.NewAccount.Address> Address;

            private String Title;

            private List<Account.NewAccount.AdditionalProperty> AdditionalProperty;

            private Account.NewAccount.Name Name;

            private Certificate Certificate;

            private List<Contact> Contact;

            @Data
            @AllArgsConstructor
            @NoArgsConstructor
            public static class Certificate implements Serializable {
                private String IdNum;

                private String IdType;
            }

            @Data
            @AllArgsConstructor
            @NoArgsConstructor
            public static class Contact implements Serializable {
                private String ContactType;

                private String Email;

                private String Priority;

                private String Title;

                private String MobilePhone;

                private Account.NewAccount.Name Name;
            }
        }
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Subscriber implements Serializable {
        private String ICCID;

        private String ServiceNum;

        private String Language;

        private String WrittenLanguage;

        private String Password;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ReqHeader implements Serializable {
        private String ReqTime;

        private String Version;

        private String Channel;

        private String AccessPassword;

        private String PartnerId;

        private String TransactionId;

        private String AccessUser;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class SupplementaryOffering implements Serializable {
        private EffectiveMode EffectiveMode;

        private String ExpirationDate;

        private ActiveMode ActiveMode;

        private String OfferingId;

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class EffectiveMode implements Serializable {
            private String Mode;

            private String EffectiveDate;
        }
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class PrimaryOffering implements Serializable {
        private OfferingId OfferingId;
        private Contract Contract;

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class OfferingId implements Serializable {
            private String OfferingId;
        }

        @Data
        @AllArgsConstructor
        public static class Contract {
            private String AgreementId;
            private String DurationUnit;
            private String DurationValue;
        }
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ActiveMode implements Serializable {
        private String Mode;
        private String ActiveDate;
    }
}
