package com.reddot.ecrm.api.payload.response.pre2post;

import lombok.Data;

@Data
public class PrepaidToPostpaidResponse {
    private boolean isSuccess;
    private String code;
    private String message;
}
