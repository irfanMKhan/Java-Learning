package com.reddot.ecrm.api.attachmentSource;

import lombok.*;

import javax.persistence.*;

@Entity
@Table(name = "tbl_attachment_source", schema = "ecrm")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class AttachmentSource {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "module")
    private String module;

    @Column(name = "deposit_id")
    private Long depositId;

    @Column(name = "url")
    private String url;
}
