package com.reddot.ecrm.api.payload.response.payment;

import lombok.Data;

import java.io.Serializable;

@Data
public class QueryInvoiceErrorResponse implements Serializable {
  private Fault Fault;

  @Data
  public static class Fault implements Serializable {
    private Integer faultcode;

    private String faultstring;
  }
}
