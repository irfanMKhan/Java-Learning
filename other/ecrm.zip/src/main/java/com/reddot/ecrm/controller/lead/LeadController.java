package com.reddot.ecrm.controller.lead;

import com.google.gson.Gson;
import com.reddot.ecrm.dto.lead.LeadDto;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.module.commonConfig.CommonConfig;
import com.reddot.ecrm.module.commonConfig.CommonConfigService;
import com.reddot.ecrm.module.commonConfig.dto.GetDropDownsReqDTO;
import com.reddot.ecrm.service.attachment.AttachmentService;
import com.reddot.ecrm.service.lead.LeadContactService;
import com.reddot.ecrm.service.lead.LeadService;
import com.reddot.ecrm.service.lead.settings.*;
import com.reddot.ecrm.service.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/lead")
public class LeadController {

    @Autowired
    private LeadService leadService;

    @Autowired
    private LeadStatusService leadStatusService;

    @Autowired
    private LeadOppPercentageService leadOppPercentageService;

    @Autowired
    private ProductInterestService productInterestService;

    @Autowired
    private CurrentProdServService currentProdServService;

    @Autowired
    private IndustryService industryService;

    @Autowired
    private IndustryMappingService subIndustryService;

    @Autowired
    private NumberOfEmployeesService numberOfEmployeesService;

    @Autowired
    private LeadRevenueService leadRevenueService;

    @Autowired
    private CountryService countryService;

    @Autowired
    private CommonConfigService commonConfigService;

    @Autowired
    private LeadContactService leadContactService;

    @Autowired
    private AttachmentService attachmentService;

    @Autowired
    private UserService userService;
    
    @Value("${app.base_url}")
    private String baseUrl;

    @RequestMapping(value = "", method = RequestMethod.GET)
    public String viewLeads(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        model.addAttribute("title", "Leads");
        model.addAttribute("breadcrumb", "Leads");

        model.addAttribute("kams", userService.getAllUsers().getData());

        return "lead/lead_list";
    }

    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public String addLead(ModelMap model, HttpServletRequest request, Principal principal) {
        new MenuViewer().setupSideMenu(model, request);

        model.addAttribute("title", "Add Lead");
        model.addAttribute("breadcrumb", "Add");

        GetDropDownsReqDTO prodInterests = new GetDropDownsReqDTO(31L, 66L, null, null);
        List<CommonConfig> productInterests = commonConfigService.commonConfigListByTypeIdAndSubtypeId(prodInterests);

        model.addAttribute("productInterests", productInterests);

        model.addAttribute("numberOfEmployeesList", numberOfEmployeesService.getAllNumberOfEmployeesWhereIsActive());
        model.addAttribute("countries", countryService.getAllCountriesWhereIsActive());

        return "lead/lead_add";
    }

    @RequestMapping(value = "/edit/{leadNumber}", method = RequestMethod.GET)
    public String editLead(ModelMap model, HttpServletRequest request, Principal principal,
                           @PathVariable("leadNumber") String leadNumber) {
        new MenuViewer().setupSideMenu(model, request);
        
        LeadDto lead = leadService.getLeadByLeadNumber(leadNumber);

        if (lead != null) {
            model.addAttribute("lead", lead);

            model.addAttribute("title", "Edit Lead");
            model.addAttribute("breadcrumb", "Add");

            model.addAttribute("productInterests", leadService.getLeadByLeadNumber(leadNumber).getProductInterestIds());

            model.addAttribute("numberOfEmployeesList", numberOfEmployeesService.getAllNumberOfEmployeesWhereIsActive());
            model.addAttribute("countries", countryService.getAllCountriesWhereIsActive());
            model.addAttribute("leadContactDtos", new Gson().toJson(leadContactService.getAllLeadContactByLeadId(lead.getId())));
            
            model.addAttribute("baseUrl", baseUrl);
            return "lead/lead_edit";
        } else {
            return null;
        }
    }

}