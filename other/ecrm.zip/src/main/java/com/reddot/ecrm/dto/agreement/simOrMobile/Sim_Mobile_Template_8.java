package com.reddot.ecrm.dto.agreement.simOrMobile;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class Sim_Mobile_Template_8 {
    private String monthlyFee_Value_3;
    private String monthlyFee_Value_5;
    private String monthlyFee_Value_8;
    private String monthlyFee_Value_18;

    private String monthlyCommitment_Value_3;
    private String monthlyCommitment_Value_5;
    private String monthlyCommitment_Value_8;
    private String monthlyCommitment_Value_18;

    private String connectionFee_all;

    private String minimumLinesForCug_all;

    private String benefitsFreeCallsWithinSmartNetworkPerDay_Value_3;
    private String benefitsFreeCallsWithinSmartNetworkPerDay_Value_5;
    private String benefitsFreeCallsWithinSmartNetworkPerDay_Value_8;
    private String benefitsFreeCallsWithinSmartNetworkPerDay_Value_18;

    private String benefitsFreeCUGCallsPerDay_Value_3;
    private String benefitsFreeCUGCallsPerDay_Value_5_8_18;

    private String StandardRateCloseUserGroupCalls_Value_3;
    private String StandardRateCloseUserGroupCalls_Value_5_8_18;

    private String StandardRateCallsWithinSmartNetwork_all;
    private String StandardRateCallsWithinOtherNetwork_all;

    private String StandardRateSMSWithinSmartNetwork_all;
    private String StandardRateSMSWithinOtherNetwork_all;
    private String StandardRateSMSToOtherCountriesInTheWorld_all;
    private String StandardRateMMSWithinSmartNetwork_all;
    private String StandardRateMMSWithinOtherNetwork_all;
    private String StandardRateMMSToOtherCountriesInTheWorld_all;

    private String StandardRateMobileInternetPAYU_all;
    private String StandardRateCLIRActivation_2_USD_all;
    private String StandardRateSOCLIRActivation_2_USD_all;
    private String StandardRateMissedCallAlert_all;
    private String StandardRateVAS_all;
    private String StandardRateCallToTheWorld_all;
    private String StandardRateRoaming_all;


    private String AddOnPackages_1000SMS_PackageWithinSmartNetwork_all;
    private String AddOnPackagesMobileInternet_1_GB_Package_all;
    private String AddOnPackagesMobileInternet_4_GB_Package_all;
    private String AddOnPackagesMobileInternet_8_GB_Package_all;
    private String AddOnPackagesMobileInternet_17_GB_Package_all;
    private String AddOnPackagesMobileInternet_26_GB_Package_all;
    private String AddOnPackagesMobileInternet_45_GB_Package_all;


    private String AddOnPackages4GLTEService_all;

    private String AddOnPackagesCUGUnlimitedPackage_value_3;
    private String AddOnPackagesCUGUnlimitedPackage_value_5_8_18;

    private String DepositLocalInternationalCalls_all;
    private String DepositLocalInternationalRoaming_all;

    private String ContractTerm_all;

}
