package com.reddot.ecrm.api.payload.response.contract.account;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.lang.Integer;
import java.lang.Long;
import java.lang.String;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class QueryAccountInformationResponse implements Serializable {
  private QueryAcctInfoRspMsg QueryAcctInfoRspMsg;

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class QueryAcctInfoRspMsg implements Serializable {
    private Account Account;

    private RspHeader RspHeader;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Account implements Serializable {
      private Long AcctId;

      private Address Address;

      private Long CustId;

      private String BillCycleType;

      private CreditLimit CreditLimit;

      private Integer AcctPayMethod;

      private BillMedium BillMedium;

      private Integer PaymentType;

      private Integer Title;

      private Integer BillLanguage;

      private Name Name;

      @Data
      @AllArgsConstructor
      @NoArgsConstructor
      public static class Address implements Serializable {
        private String Address7;

        private Integer Address11;

        private String Address5;

        private Integer Address2;

        private Integer Address3;

        private Integer Address1;

        private Integer AddressType;

        private Long AddressId;
      }

      @Data
      @AllArgsConstructor
      @NoArgsConstructor
      public static class CreditLimit implements Serializable {
        private Integer LimitType;
      }

      @Data
      @AllArgsConstructor
      @NoArgsConstructor
      public static class BillMedium implements Serializable {
        private Integer BillMediumId;

        private Integer BillMediumCode;

        private Integer BillContentType;

        private String BillMediumInfo;
      }

      @Data
      @AllArgsConstructor
      @NoArgsConstructor
      public static class Name implements Serializable {
        private String FirstName;

        private String LastName;
      }
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class RspHeader implements Serializable {
      private Long RspTime;

      private String ReturnCode;

      private String ReturnMsg;

      private Integer Version;
    }
  }
}
