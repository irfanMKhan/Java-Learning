package com.reddot.ecrm.dto.contract;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SearchContractDTO {
    private String kam = null;
    private String assignedTo = null;
    private String productOfInterest = null;
    private String status = null;
    private String contractNumber = null;
    private String customerNumber = null;
    private String toDate = null;
    private String fromDate = null;
    private Boolean hasAdvanceSearch = false;
    private String searchKeyword = null;
    private String msisdn = null;
}
