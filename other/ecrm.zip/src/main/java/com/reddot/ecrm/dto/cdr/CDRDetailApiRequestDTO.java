package com.reddot.ecrm.dto.cdr;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class CDRDetailApiRequestDTO {
    private String bss_username;
    private String bss_password;
    private String start_time;
    private String end_time;
    private String startRow;
    private String totalRow;
    private String fetchRow;
    private String msisdn;

}
