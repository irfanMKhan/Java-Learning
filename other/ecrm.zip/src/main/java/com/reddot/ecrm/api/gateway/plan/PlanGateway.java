package com.reddot.ecrm.api.gateway.plan;


import com.reddot.ecrm.api.payload.request.plan.ChangePrimaryOfferingRequest;
import com.reddot.ecrm.api.payload.response.plan.ChangePrimaryOfferingResponse;
import com.google.gson.Gson;
import com.reddot.ecrm.api.exception.ApiRequestException;
import com.reddot.ecrm.api.exception.InvalidAccessTokenException;
import com.reddot.ecrm.api.exception.InvalidClientCredentialException;
import com.reddot.ecrm.api.payload.response.ErrorResponse;
import com.reddot.ecrm.api.security.AuthorizationGateway;
import com.reddot.ecrm.api.utility.CommonConstant;
import com.reddot.ecrm.api.utility.HttpClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor
public class PlanGateway {

    @Value("${smart.egw.base.url}")
    String baseUrlEGW;
    private final HttpClient httpClient;
    private final Gson gson;
    private final AuthorizationGateway authorizationGateway;

    public ChangePrimaryOfferingResponse changePrimaryOffering(ChangePrimaryOfferingRequest primaryOfferingRequest) {
        String apiUrl = baseUrlEGW + "/offering/changePrimaryOffering/V1.0";
        String json = gson.toJson(primaryOfferingRequest);

        try (Response response = httpClient.put(json, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), ChangePrimaryOfferingResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("ChangePrimaryOffering Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("ChangePrimaryOffering Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            }  else if (e instanceof InvalidClientCredentialException) {
                log.debug("ChangePrimaryOffering Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("ChangePrimaryOffering Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    private Map<String, String> getHeaders() {
        String bearerToken = authorizationGateway.getTokenEGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }
}
