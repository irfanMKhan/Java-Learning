package com.reddot.ecrm.delayPayment;

import com.reddot.ecrm.api.SmartAxiataAPI;
import com.reddot.ecrm.api.payload.request.payment.QueryInvoiceAPIRequest;
import com.reddot.ecrm.api.payload.response.payment.QueryInvoiceResponse;
import com.reddot.ecrm.feature.dto.GetQueryInvoiceListReqBody;
import com.reddot.ecrm.feature.model.DataToHitThirdPartyAPI;
import com.reddot.ecrm.feature.repo.DataToHitThirdPartyAPIRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

@Service
public class QueryInvoiceListService {
    @Autowired
    private SmartAxiataAPI smartAxiataAPI;

    @Autowired
    private DataToHitThirdPartyAPIRepo dataToHitThirdPartyAPIRepo;

    @Value("${smart.egw.version}")
    private String version;

    @Value("${smart.egw.businessCode}")
    private String businessCode;

    @Value("${smart.egw.messageSeq}")
    private String messageSeq;

    @Value("${smart.bss.username}")
    private String loginSystemCode;

    @Value("${smart.bss.password}")
    private String password;

    @Value("${smart.egw.beid}")
    private String beid;

    public ResponseEntity<?> getAllInvoice(HttpServletRequest httpServletRequest, QueryInvoiceListReqBody reqBody) {

        /////////////////////////////////////////////////////////////////////////////////////////////
        QueryInvoiceAPIRequest queryInvoiceAPIRequest = new QueryInvoiceAPIRequest();
        //
        QueryInvoiceAPIRequest.RequestHeader requestHeader = new QueryInvoiceAPIRequest.RequestHeader();

        DataToHitThirdPartyAPI data;

        // requestHeader.setVersion("1");
        // data = dataToHitThirdPartyAPIRepo.findByModuleAndAttribute("queryInvoice", "version");
        requestHeader.setVersion(version);

        // requestHeader.setBusinessCode("1");
        // data = dataToHitThirdPartyAPIRepo.findByModuleAndAttribute("queryInvoice", "businessCode");
        requestHeader.setBusinessCode(businessCode);

        // requestHeader.setMessageSeq("20230608113000");
        // data = dataToHitThirdPartyAPIRepo.findByModuleAndAttribute("queryInvoice", "messageSeq");
        requestHeader.setMessageSeq(messageSeq);

        QueryInvoiceAPIRequest.RequestHeader.AccessSecurity accessSecurity = new QueryInvoiceAPIRequest.RequestHeader.AccessSecurity();
        //accessSecurity.setLoginSystemCode("REDDOT.ECRM.TB");
        //accessSecurity.setPassword("YMGPWrsNu6P7CFLhI1YEgQ==");

        // data = dataToHitThirdPartyAPIRepo.findByModuleAndAttribute("queryInvoice", "loginSystemCode");
        accessSecurity.setLoginSystemCode(loginSystemCode);
        // data = dataToHitThirdPartyAPIRepo.findByModuleAndAttribute("queryInvoice", "password");
        accessSecurity.setPassword(password);

        requestHeader.setAccessSecurity(accessSecurity);

        QueryInvoiceAPIRequest.RequestHeader.OwnershipInfo ownershipInfo = new QueryInvoiceAPIRequest.RequestHeader.OwnershipInfo();
        // ownershipInfo.setBEID("101");

        // data = dataToHitThirdPartyAPIRepo.findByModuleAndAttribute("queryInvoice", "beid");
        ownershipInfo.setBEID(beid);

        requestHeader.setOwnershipInfo(ownershipInfo);

        queryInvoiceAPIRequest.setRequestHeader(requestHeader);
        //

        //
        QueryInvoiceAPIRequest.QueryInvoiceRequest queryInvoiceRequest = new QueryInvoiceAPIRequest.QueryInvoiceRequest();
        // commenting out only for test purpose
        queryInvoiceRequest.setNumberOfBillCycle(reqBody.getNumberOfBillCycle());
        //queryInvoiceRequest.setNumberOfBillCycle("3");

        QueryInvoiceAPIRequest.QueryInvoiceRequest.AcctAccessCode acctAccessCode = new QueryInvoiceAPIRequest.QueryInvoiceRequest.AcctAccessCode();
        // commenting out only for test purpose
        // acctAccessCode.setAccountCode(reqBody.getAccountCode());
        // this account-code is for DNT (company level)

        // for real
        acctAccessCode.setAccountCode(reqBody.getAccountCode());

        // for test
        // acctAccessCode.setAccountCode("1.3221176");

        queryInvoiceRequest.setAcctAccessCode(acctAccessCode);

        queryInvoiceAPIRequest.setQueryInvoiceRequest(queryInvoiceRequest);
        //

        System.out.println(queryInvoiceAPIRequest);

        QueryInvoiceResponse queryInvoiceResponse = smartAxiataAPI.queryInvoice(queryInvoiceAPIRequest);
        /////////////////////////////////////////////////////////////////////////////////////////////

        List<QueryInvoiceResponse.QueryInvoiceResultMsg.QueryInvoiceResult.InvoiceInfo> invoiceInfoList = queryInvoiceResponse.getQueryInvoiceResultMsg().getQueryInvoiceResult().getInvoiceInfo();

        List<QueryInvoiceListResponseObject> responseObjectList = new ArrayList<>();
        QueryInvoiceListResponseObject queryInvoiceListResponseObject;
        for (com.reddot.ecrm.api.payload.response.payment.QueryInvoiceResponse.QueryInvoiceResultMsg.QueryInvoiceResult.InvoiceInfo invoiceInfo : invoiceInfoList) {

            if (invoiceInfo.getStatus().equals("O")) {
                queryInvoiceListResponseObject = new QueryInvoiceListResponseObject();
                queryInvoiceListResponseObject.setAcctKey(String.valueOf(invoiceInfo.getAcctKey()));
                queryInvoiceListResponseObject.setCustKey(String.valueOf(invoiceInfo.getCustKey()));
                queryInvoiceListResponseObject.setSubKey(String.valueOf(invoiceInfo.getSubKey()));

                queryInvoiceListResponseObject.setPrimaryIdentity(String.valueOf(invoiceInfo.getPrimaryIdentity()));
                queryInvoiceListResponseObject.setTransType(invoiceInfo.getTransType());

                queryInvoiceListResponseObject.setInvoiceID(String.valueOf(invoiceInfo.getInvoiceID()));
                queryInvoiceListResponseObject.setInvoiceNo(String.valueOf(invoiceInfo.getInvoiceNo()));
                queryInvoiceListResponseObject.setBillCycleID(String.valueOf(invoiceInfo.getBillCycleID()));
                queryInvoiceListResponseObject.setBillCycleBeginTime(String.valueOf(invoiceInfo.getBillCycleBeginTime()));
                queryInvoiceListResponseObject.setBillCycleEndTime(String.valueOf(invoiceInfo.getBillCycleEndTime()));
                queryInvoiceListResponseObject.setInvoiceAmount(String.valueOf(invoiceInfo.getInvoiceAmount()));
                queryInvoiceListResponseObject.setOpenAmount(String.valueOf(invoiceInfo.getOpenAmount()));
                queryInvoiceListResponseObject.setDisputeAmount(String.valueOf(invoiceInfo.getDisputeAmount()));
                queryInvoiceListResponseObject.setCurrencyId(String.valueOf(invoiceInfo.getCurrencyID()));
                queryInvoiceListResponseObject.setInvoiceDate(String.valueOf(invoiceInfo.getInvoiceDate()));
                queryInvoiceListResponseObject.setDueDate(String.valueOf(invoiceInfo.getDueDate()));
                queryInvoiceListResponseObject.setStatus(invoiceInfo.getStatus());
                queryInvoiceListResponseObject.setInvoiceDetailInvoiceID(String.valueOf(invoiceInfo.getInvoiceDetail().getInvoiceID()));
                queryInvoiceListResponseObject.setServiceCategory(invoiceInfo.getInvoiceDetail().getServiceCategory());
                queryInvoiceListResponseObject.setChargeCode(invoiceInfo.getInvoiceDetail().getChargeCode());
                queryInvoiceListResponseObject.setChargeAmount(String.valueOf(invoiceInfo.getInvoiceDetail().getChargeAmount()));

                responseObjectList.add(queryInvoiceListResponseObject);
            }

        }

        return new ResponseEntity<>(responseObjectList, HttpStatus.OK);
    }
}
