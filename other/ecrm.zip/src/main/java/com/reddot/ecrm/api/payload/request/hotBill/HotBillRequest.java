package com.reddot.ecrm.api.payload.request.hotBill;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;
@Setter
@Getter
@Data
public class HotBillRequest implements Serializable {
    private String CorpAcctCode;
    private String ServiceType;
    private List<MembersInfo> MembersInfo;
    @Data
    public static class MembersInfo implements Serializable{
        private String AcctCode;
        private String ServiceNum;
    }
}
