package com.reddot.ecrm.dao;

public interface CommonDAO {
    Object CommoPagination(String sql);
    Object CommoGetData(String sql);
    public int CommoNumberOfRow(String sql);
}
