package com.reddot.ecrm.api.payload.request.contract.payment;

import lombok.Data;

import java.io.Serializable;
import java.lang.String;
import java.util.List;

@Data
public class ChangeCorporateAccountPaymentRelationRequest implements Serializable {
  private String AcctId;

  private String ServiceNum;

  private ReqHeader ReqHeader;

  private List<PaymentRelation> PaymentRelation;

  @Data
  public static class ReqHeader implements Serializable {
    private String ReqTime;

    private String Version;

    private String Channel;

    private String AccessPassword;

    private String PartnerId;

    private String OperatorId;

    private String TransactionId;

    private String AccessUser;
  }

  @Data
  public static class PaymentRelation implements Serializable {
    private String ActionType;

    private String ServiceType;

    private PaymentLimit PaymentLimit;

    @Data
    public static class PaymentLimit implements Serializable {
      private String LimitUnit;

      private String LimitMeasureUnit;

      private String LimitPattern;

      private String LimitValue;
    }
  }
}
