package com.reddot.ecrm.api.payload.request.shared.group;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;
import java.lang.String;

@Data
public class DeleteCorporateGroupMemberRequest implements Serializable {
  private ReqHeader ReqHeader;

  private AccessInfo AccessInfo;

  private String GroupId;

  @Data
  public static class ReqHeader implements Serializable {
    private String ReqTime;

    private String Version;

    private String BusinessCode;

    private String Channel;

    private String AccessPassword;

    private String PartnerId;

    private String TransactionId;

    private String AccessUser;
  }

  @Data
  @AllArgsConstructor
  public static class AccessInfo implements Serializable {
    private String ObjectId;

    private String ObjectIdType;
  }
}
