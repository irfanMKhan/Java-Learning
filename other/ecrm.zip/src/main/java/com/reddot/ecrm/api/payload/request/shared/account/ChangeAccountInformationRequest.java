package com.reddot.ecrm.api.payload.request.shared.account;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.lang.String;
import java.util.List;

@Data
public class ChangeAccountInformationRequest implements Serializable {
  private ChangeAcctInfoReq ChangeAcctInfoReq;

  @Data
  public static class ChangeAcctInfoReq implements Serializable {
    private Account Account;

    @Data
    public static class Account implements Serializable {
      private String BillLanguage;

      private Name Name;

      private List<Address> Address;

      private String BillCycleType;

      private String AcctPayMethod;

      private List<AdditionalProperty> AdditionalProperty;

      @Data
      public static class Address implements Serializable {
        private String ActionType;

        private String Address11;

        private String Address2;

        private String Address3;

        private String Address1;

        private String AddressType;
      }

      @Data
      @AllArgsConstructor
      @NoArgsConstructor
      public static class AdditionalProperty implements Serializable {
        private String Code;

        private String Value;
      }

      @Data
      @AllArgsConstructor
      @NoArgsConstructor
      public static class Name implements Serializable {
        private String FirstName;

        private String LastName;
      }
    }
  }

  private String transaction_id;
}
