package com.reddot.ecrm.api.gateway.post2pre;

import com.reddot.ecrm.api.exception.ApiRequestException;
import com.reddot.ecrm.api.exception.InvalidAccessTokenException;
import com.reddot.ecrm.api.exception.InvalidClientCredentialException;
import com.reddot.ecrm.api.payload.request.post2pre.PostpaidToPrepaidRequest;
import com.reddot.ecrm.api.payload.response.post2pre.PostpaidToPrepaidResponse;
import com.reddot.ecrm.api.security.AuthorizationGateway;
import com.reddot.ecrm.api.utility.CommonConstant;
import com.reddot.ecrm.api.utility.HttpClient;
import com.google.gson.Gson;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor
public class PostpaidToPrepaidGateway {

    @Value("${smart.egw.base.url}")
    String baseUrlEGW;
    private final HttpClient httpClient;
    private final Gson gson;
    private final AuthorizationGateway authorizationGateway;


    public PostpaidToPrepaidResponse postpaidToPrepaid(String subscriberId, PostpaidToPrepaidRequest postpaidToPrepaidRequest) {
        String apiUrl = baseUrlEGW + "/api/hwbss/posttopre/v1.0/"+subscriberId;
        String json = gson.toJson(postpaidToPrepaidRequest);

        try (Response response = httpClient.post(json, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.CREATED.value()) {
                return gson.fromJson(response.body().string(), PostpaidToPrepaidResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                PostpaidToPrepaidResponse errorResponse = gson.fromJson(response.body().string(), PostpaidToPrepaidResponse.class);
                throw new ApiRequestException(errorResponse.getReturnMsg());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("PostpaidToPrepaid Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("PostpaidToPrepaid Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            }  else if (e instanceof InvalidClientCredentialException) {
                log.debug("PostpaidToPrepaid Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("PostpaidToPrepaid Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    private Map<String, String> getHeaders() {
        String bearerToken = authorizationGateway.getTokenEGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }
}
