package com.reddot.ecrm.api.payload.request.payment;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class CreatePAMultiInvoiceRequest implements Serializable {
  private String transaction_id;

  private CreatePARequest CreatePARequest;

  @Data
  public static class CreatePARequest implements Serializable {
    private String PAExternalID;

    private String PAReminderFlag;

    private Integer PAType;

    private String TotalPAAmount;

    private List<PAInvoiceInfo> PAInvoiceInfo;

    private AcctAccessCode AcctAccessCode;

    private List<PADetailInfo> PADetailInfo;

    @Data
    public static class PAInvoiceInfo implements Serializable {
      private String InvoiceNo;

      public String getInvoiceNo() {
        return this.InvoiceNo;
      }

      public void setInvoiceNo(String InvoiceNo) {
        this.InvoiceNo = InvoiceNo;
      }
    }

    @Data
    public static class AcctAccessCode implements Serializable {
      private String PrimaryIdentity;
    }

    @Data
    public static class PADetailInfo implements Serializable {
      private String AgreedPaidAmt;

      private String AgreedPaidDate;

      private String CurrencyId;

      private String Remark;
    }
  }
}
