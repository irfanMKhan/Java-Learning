package com.reddot.ecrm.controller.billMediumConfig;

import com.reddot.ecrm.dto.billMediumConfig.BillMediumConfigDto;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.billMediumConfig.BillMediumConfigService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("bill-medium")
public class BillMediumConfigRestController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    private BillMediumConfigService billMediumConfigService;

    @GetMapping("/get/all")
    public List<BillMediumConfigDto> getAllBillMediumList(HttpServletRequest request) {
        return billMediumConfigService.getAllBillMediumConfigsWhereIsActive(request);
    }

    @GetMapping("/dt/all")
    public DataTablesOutput<BillMediumConfigDto> dtLeadStatus(@Valid DataTablesInput input, HttpServletRequest request,
                                                              @RequestParam(value = "searchText", required = false) String searchText, @RequestParam(value = "searchCol", required = false) String searchCol) {
        return billMediumConfigService.getDTBillMediumConfig(input, request, searchText, searchCol);
    }

    @GetMapping("/check-exists")
    public CommonRestResponse existsByServiceTypeName(@RequestParam String serviceTypeName) {
        return billMediumConfigService.existsByServiceTypeName(serviceTypeName);
    }

    @PostMapping("/add")
    public CommonRestResponse addBillMediumConfig(HttpServletRequest request, @RequestBody BillMediumConfigDto billMediumConfigDto) {
        return billMediumConfigService.addBillMediumConfig(request, billMediumConfigDto);
    }

    @PostMapping("/update")
    public CommonRestResponse updateBillMediumConfig(HttpServletRequest request,
                                                     @RequestBody BillMediumConfigDto billMediumConfigDto) {
        return billMediumConfigService.updateBillMediumConfig(request, billMediumConfigDto);
    }

    @GetMapping("/get/getByName")
    public CommonRestResponse getBillMediumConfigByName(@RequestParam String name) {
        return billMediumConfigService.getBillMediumConfigByName(name);
    }
}
