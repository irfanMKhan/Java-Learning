package com.reddot.ecrm.controller.inventory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.dto.inventory.InventoryDTO;
import com.reddot.ecrm.dto.inventory.InventorySearchDTO;
import com.reddot.ecrm.entity.inventory.InventoryEntity;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.model.userRole.RoleEntity;
import com.reddot.ecrm.service.DropDownService;
import com.reddot.ecrm.service.inventory.InventoryService;
import com.reddot.ecrm.spring_config.session.SessionManager;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

@Controller
@RequiredArgsConstructor
@RequestMapping(value = "/inventory")
public class InventoryViewController {

    private final InventoryService inventoryService;
    private final DropDownService dropDownService;

    @GetMapping
    public String viewPage(@RequestParam(value = "requestTypeKey", required = false) String requestTypeKey,
                           @RequestParam(value = "requestTypeValue", required = false) String requestTypeValue,
                           @RequestParam(value = "oppId", required = false) String oppId,
                           @RequestParam(value = "conId", required = false) String conId,
                           @RequestParam(value = "comId", required = false) String comId,
                           @RequestParam(value = "createBy", required = false) String createBy,
                           ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        MDUserModel user = SessionManager.getUserDetails(request);

        model.put("login_name", user.getLOGIN_NAME());
        model.put("name", user.getNAME());
        model.put("logged_in_id", user.getID());
        model.put("userType", user.getUSER_TYPE());

        model.put("title", "Reserve MSISDN List");
        model.put("requestTypeKey", requestTypeKey);
        model.put("requestTypeValue", requestTypeValue);
        model.put("oppId", oppId);
        model.put("conId", conId);
        model.put("comId", comId);
        model.put("createBy", createBy);
        return "/inventory/index";
    }

    @ResponseBody
    @GetMapping("/list/un-reserve")
    public ResponseEntity<?> unreserved_msisdn(String id) throws JsonProcessingException {
        Boolean result = inventoryService.releaseMSISDN(id);
        return new ResponseEntity<>("Created", HttpStatus.OK);
    }

    @ResponseBody
    @GetMapping("/list")
    public List<InventoryDTO> getInventoryList() {
        return inventoryService.getAllMSISDN();
    }

    @ResponseBody
    @RequestMapping(value = "/list/search-dt", method = RequestMethod.POST)
    public DataTablesOutput<InventoryEntity> getOpportunityListDT(@RequestBody Map<String, Object> data, HttpServletRequest request) throws JsonProcessingException {

        DataTablesInput input = new Gson().fromJson(
                Utility.ObjectToJson(data.get("dtInput")), new TypeToken<DataTablesInput>() {
                }.getType()
        );
        MDUserModel user = SessionManager.getUserDetails(request);
        List<RoleEntity> roleEntityList = user.getRoleEntityList();
        Boolean isAdmin = false;
        for (RoleEntity role : roleEntityList) {
            if (Objects.equals(role.getName(), "ADMIN")) {
                isAdmin = true;
                break;
            }
        }

        ObjectMapper mapper = new ObjectMapper();
        InventorySearchDTO inventorySearchDTO = mapper.readValue(data.get("searchData").toString(), InventorySearchDTO.class);

        /*if( !isAdmin ) {
            inventorySearchDTO.setCreateBy(user.getID().toString());
            inventorySearchDTO.setCreateByName(user.getLOGIN_NAME());
        }*/

        return inventoryService.searchDataTable(input, inventorySearchDTO, isAdmin);
    }

    @ResponseBody
    @PostMapping("/list/search")
    public List<InventoryDTO> getFilteredInventoryList(@Valid @RequestBody InventorySearchDTO inventorySearchDTO) {
        return inventoryService.searchInMSISDN(inventorySearchDTO);
    }

    @GetMapping("/add")
    public String viewOpportunityAdd(@RequestParam(value = "requestTypeKey", required = false) String requestTypeKey,
                                     @RequestParam(value = "requestTypeValue", required = false) String requestTypeValue,
                                     @RequestParam(value = "oppId", required = false) String oppId,
                                     @RequestParam(value = "conId", required = false) String conId,
                                     @RequestParam(value = "comId", required = false) String comId,
                                     ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        MDUserModel user = SessionManager.getUserDetails(request);

        String unique_id = "";

        model.put("title", "Add New MSISDN To Inventory");

        model.put("login_name", user.getLOGIN_NAME());
        model.put("name", user.getNAME());
        model.put("logged_in_id", user.getID());
        model.put("userType", user.getUSER_TYPE());

        model.put("unique_id", unique_id);
        model.put("requestTypeKey", requestTypeKey);
        model.put("requestTypeValue", requestTypeValue);
        model.put("oppId", oppId);
        model.put("conId", conId);
        model.put("comId", comId);

        return "/inventory/add";
    }

    @ResponseBody
    @GetMapping(value = "/get_msisdn", consumes = MediaType.APPLICATION_JSON_VALUE)
    public List<InventoryDTO> getMSISDNFromCOMBODIA(
            Long numberOfLine,
            String categoryId,
            String prefix,
            String msisdn,
            String startRow,
            String endRow,
            String startRange,
            String endRange
    ) throws ExecutionException, InterruptedException, UnsupportedEncodingException, JsonProcessingException {
        return inventoryService.getMSISDNFromCOMBODIA(numberOfLine, categoryId, prefix, msisdn, startRow, endRow, startRange, endRange);
    }

    @ResponseBody
    @GetMapping(value = "/get_msisdn_list", consumes = MediaType.APPLICATION_JSON_VALUE)
    public List<InventoryDTO> getMSISDNFromCOMBODIAByList(Long numberOfLine,
                                                          String categoryId,
                                                          String prefix,
                                                          String msisdn,
                                                          String startRow,
                                                          String endRow,
                                                          String startRange,
                                                          String endRange) throws ExecutionException, InterruptedException, UnsupportedEncodingException, JsonProcessingException {
        return inventoryService.getMSISDNFromCOMBODIAByList(msisdn, startRow);
    }

    @ResponseBody
    @GetMapping("/add/list")
    public List<InventoryEntity> getAddInventoryList() {
        return new ArrayList<InventoryEntity>();
    }

    @ResponseBody
    @PostMapping(value = "/add/submit", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> addInventory(@Valid @RequestBody InventoryDTO inventoryDTO, HttpServletRequest request) {
        inventoryService.threadSave(inventoryDTO, request);
        return new ResponseEntity<>("Created", HttpStatus.OK);
    }

}
