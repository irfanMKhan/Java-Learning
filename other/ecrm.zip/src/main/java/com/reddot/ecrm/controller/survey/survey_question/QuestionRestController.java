package com.reddot.ecrm.controller.survey.survey_question;

import com.reddot.ecrm.entity.survey.survey_question.QuestionDTO;
import com.reddot.ecrm.entity.survey.survey_question.QuestionEntity;
import com.reddot.ecrm.entity.survey.survey_question.QuestionOptionEntity;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.survey.survey_question.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("/question/rest")
public class QuestionRestController {
    @Autowired
    private QuestionService questionService;

    @PostMapping("/addQuestionData")
    public CommonRestResponse addQuestionData(@RequestBody QuestionDTO questionDTO, HttpServletRequest request) {
        return questionService.addQuestionData(questionDTO, request);
    }

    @PostMapping("/getAllQuestion")
    public List<QuestionEntity> getAllQuestionBYSurveyID(@RequestBody Long surveyID, HttpServletRequest request) {

        System.out.println(questionService.getAllQuestionBySurveyID(surveyID));
        return questionService.getAllQuestionBySurveyID(surveyID);
    }

    @PostMapping("/getAllOption")
    public List<QuestionOptionEntity> getAllOptionBYQuestionID(@RequestBody Long questionID, HttpServletRequest request) {

        System.out.println(questionService.getAllQuestionOptionByQuestionID(questionID));
        return questionService.getAllQuestionOptionByQuestionID(questionID);
    }

    @PostMapping("/updateQuestionData")
    public CommonRestResponse updateQuestionData(@RequestBody QuestionDTO questionDTO, HttpServletRequest request) {

        return questionService.updateQuestionData(questionDTO, request);
    }

    @PostMapping("/deleteQuestion")
    public CommonRestResponse deleteQuestionBYID(@RequestBody QuestionEntity questionEntity, HttpServletRequest request) {

        return questionService.deleteQuestionByID(questionEntity);
    }

    @PostMapping("/deleteQuestionOption")
    public CommonRestResponse deleteQuestionOptionBYID(@RequestBody QuestionOptionEntity questionOption, HttpServletRequest request) {
        return questionService.deleteQuestionOptionByID(questionOption);
    }
}
