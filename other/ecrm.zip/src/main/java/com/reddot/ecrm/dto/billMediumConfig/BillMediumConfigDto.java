package com.reddot.ecrm.dto.billMediumConfig;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class BillMediumConfigDto {
    
    private Long id;
    private String name;
    private Long serviceTypeId;
    private String serviceTypeName;
    private String billMediumId;
    private Long billMediumCodeId;
    private String billMediumCodeApiValue;
    private String billMediumCodeName;
    private Long billContentTypeId;
    private String billContentTypeApiValue;
    private String billContentTypeName;
    private Boolean isDefault;
    private Boolean isActive;
    
}
