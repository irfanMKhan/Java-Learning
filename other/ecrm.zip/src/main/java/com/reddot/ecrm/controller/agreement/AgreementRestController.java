//package com.reddot.ecrm.controller.agreement;
//
//import com.reddot.ecrm.dto.PDFAndHotBill.SendEmailDTO;
//import com.reddot.ecrm.dto.agreement.AgreementDTO;
//import com.reddot.ecrm.entity.company.CompanyEntity;
//import com.reddot.ecrm.model.User.MDUserModel;
//import com.reddot.ecrm.service.ContractAgreementReportService;
//import com.reddot.ecrm.service.cdr.CDRService;
//import com.reddot.ecrm.spring_config.session.SessionManager;
//import freemarker.template.TemplateException;
//import lombok.RequiredArgsConstructor;
//import net.sf.jasperreports.engine.JRException;
//import org.springframework.http.MediaType;
//import org.springframework.web.bind.annotation.*;
//
//import javax.mail.MessagingException;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.validation.Valid;
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.List;
//@RestController
//@RequiredArgsConstructor
//@RequestMapping("/agreement/report")
//public class AgreementRestController {
//
//    private final ContractAgreementReportService contractAgreementReportService;
//
//    @RequestMapping(value = "/getCompany", method = RequestMethod.GET)
//    public List<CompanyEntity> getCompany() {
//        return contractAgreementReportService.GetAllCompany();
//    }
//
//    @RequestMapping(value = "/email", method = RequestMethod.POST)
//    public String emailOrDownload(@Valid @RequestBody AgreementDTO agreementDTO,HttpServletRequest request,HttpServletResponse response) throws MessagingException, TemplateException, IOException, JRException {
//        contractAgreementReportService.emailOrDownloadContractAgreement(request,response,agreementDTO.getFileType(),agreementDTO.getCompanyName(),agreementDTO.getButtonName());
//        return "Success";
//    }
//
//}
