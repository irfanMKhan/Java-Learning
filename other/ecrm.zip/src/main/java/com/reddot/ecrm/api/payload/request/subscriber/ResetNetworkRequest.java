package com.reddot.ecrm.api.payload.request.subscriber;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResetNetworkRequest implements Serializable {
    private String transaction_id;

    private ChangeNetworkSettingReqMsg ChangeNetworkSettingReqMsg;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ChangeNetworkSettingReqMsg implements Serializable {
        private NetworkSettingList NetworkSettingList;

        @Data
        @AllArgsConstructor
        public static class NetworkSettingList implements Serializable {
            private Integer ProductId;

            private Integer SelectFlag;
        }
    }
}
