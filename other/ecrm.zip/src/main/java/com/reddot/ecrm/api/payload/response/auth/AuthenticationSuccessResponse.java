package com.reddot.ecrm.api.payload.response.auth;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuthenticationSuccessResponse implements Serializable {

    private String access_token;

    private String scope;

    private String token_type;

    private Integer expires_in;

}
