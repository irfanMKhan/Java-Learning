package com.reddot.ecrm.api.advice;


import lombok.Data;

import java.util.Date;
import java.util.Map;

@Data
public class CustomExceptionResponse {
    private final Integer code;
    private final String message;
    private final Map<String, String> errors;
    private final Date timestamp;
}
