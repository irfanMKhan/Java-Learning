package com.reddot.ecrm.controller.sr.notificationMatrix;

public class notificationMTConstants {
    public static final int NOTIFICATION_TO_CUSTOMER_ID = 1;
    public static final int NOTIFICATION_TO_MANAGER_ID = 2;
    public static final int NOTIFICATION_TO_OWNER_ID = 3;
    public static final int NOTIFICATION_TO_SUPERVISOR_ID = 4;
}
