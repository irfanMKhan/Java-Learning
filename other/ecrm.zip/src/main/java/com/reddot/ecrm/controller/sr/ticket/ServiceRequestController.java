package com.reddot.ecrm.controller.sr.ticket;

import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.service.itsm.ServiceRequestService;
import com.reddot.ecrm.service.user.UserService;
import com.reddot.ecrm.spring_config.session.SessionManager;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

@Controller
@RequestMapping(value = "/tickets", method = RequestMethod.GET)
@RequiredArgsConstructor
public class ServiceRequestController {

    private final ServiceRequestService service;
    private final UserService userService;

    @GetMapping("")
    public String getSRPage(ModelMap model, HttpServletRequest request){
        return "redirect:/tickets/list";
    }

    @GetMapping({"/list"})
    public String getSRListView(ModelMap model, HttpServletRequest request){
        AtomicBoolean is_kam = new AtomicBoolean(false);
        new MenuViewer().setupSideMenu(model, request);
        model.addAttribute("title", "Tickets");
        model.addAttribute("breadcrumb", "Tickets");
        MDUserModel userModel = SessionManager.getUserDetails(request);
        userModel.getRoleEntityList().forEach(item -> {
            if(item.getName().equals("KAM")){
                is_kam.set(true);
            }
        });
        model.addAttribute("is_kam", is_kam.get());

        return "sr/sr_list";
    }
    @GetMapping("/add")
    public String getSRAddView(@RequestParam(name = "type", required = false) String type,
                               @RequestParam(name = "autoSendToBO", required = false) Integer autoSendToBO,
                               ModelMap model,
                               HttpServletRequest request){
        new MenuViewer().setupSideMenu(model, request);
        model.addAttribute("title", "Tickets");
        model.addAttribute("breadcrumb", "Add");
        if (type!=null){
            model.addAttribute("type", type.toLowerCase());
        }
        else{
            model.addAttribute("type", "no_type");
        }
        model.addAttribute("autoSendToBO", autoSendToBO != null ? autoSendToBO : "0");

        AtomicBoolean is_kam = new AtomicBoolean(false);
        MDUserModel userModel = SessionManager.getUserDetails(request);
        userModel.getRoleEntityList().forEach(item -> {
            if(item.getName().equals("KAM")){
                is_kam.set(true);
            }
        });
        model.addAttribute("is_kam", is_kam.get());
        return "sr/sr_add";
    }

    @GetMapping({"/{ticket_number}"})
    public String getSRDetailsView(@PathVariable("ticket_number") String ticketNumber, ModelMap model, HttpServletRequest request){
        if(service.checkTicketExist(ticketNumber)){
            new MenuViewer().setupSideMenu(model, request);
            model.addAttribute("title", "Tickets");
            model.addAttribute("breadcrumb", "Details");
            model.addAttribute("ticket_number", ticketNumber);

            AtomicBoolean is_kam = new AtomicBoolean(false);
            MDUserModel userModel = SessionManager.getUserDetails(request);
            userModel.getRoleEntityList().forEach(item -> {
                if(item.getName().equals("KAM")){
                    is_kam.set(true);
                }
            });
            model.addAttribute("is_kam", is_kam.get());

            return "sr/sr_view";
        }
        else{
            return null;
        }
    }
}
