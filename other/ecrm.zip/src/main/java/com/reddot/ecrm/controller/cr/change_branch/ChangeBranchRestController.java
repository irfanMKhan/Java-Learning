package com.reddot.ecrm.controller.cr.change_branch;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.reddot.ecrm.dto.cr.CRSummarySearchDTO;
import com.reddot.ecrm.dto.cr.change_branch.ChangeBranchDTO;
import com.reddot.ecrm.dto.cr.change_branch.GetBranchesDTO;
import com.reddot.ecrm.entity.cr.CRMasterEntity;
import com.reddot.ecrm.entity.cr.CRMsisdnDetailsEntity;
import com.reddot.ecrm.enum_config.feature.RequestTypeEnum;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.contract.CreateRequestEntityForContractAPI;
import com.reddot.ecrm.service.cr.change_branch.ChangeBranchService;
import com.reddot.ecrm.util.LocalDateTypeAdapter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.IOException;
import java.time.LocalDate;

@RestController
@RequestMapping("/cr/change-branch/rest")
@RequiredArgsConstructor
@Slf4j
public class ChangeBranchRestController {
    private final ChangeBranchService changeBranchService;
    private final CreateRequestEntityForContractAPI createRequestEntityForContractAPI;
    @GetMapping("/numberListByCompanyID")
    public CommonRestResponse getNumberListByCompanyId(@RequestParam String companyId) {
        return this.changeBranchService.getAllNumberByCompanyID(companyId);
    }
    @PostMapping("/branches")
    public CommonRestResponse getAllBranchesByCompanyId(@Valid @RequestBody GetBranchesDTO branchesDTO) {
        return this.changeBranchService.getAllBranchesByCompanyIdAndServiceType(branchesDTO.getCompanyId(), branchesDTO.getServiceType());
    }
    @PostMapping("/changeBranch")
    public CommonRestResponse changeBranch(@Valid @RequestBody ChangeBranchDTO changeBranch, HttpServletRequest request) {
        System.out.println(changeBranch);
        return this.changeBranchService.changeBranch(changeBranch, request);
    }

    @GetMapping("/summary/getAllData")
    public DataTablesOutput<CRMsisdnDetailsEntity> getAllSummaryData(
            HttpServletRequest request,
            @Valid DataTablesInput input,
            @RequestParam(value = "searchDto", required = false) String searchDtoJson
    ) {
        CRSummarySearchDTO searchDTO = null;
        if (searchDtoJson != null) {
            try {
                Gson gson = new GsonBuilder()
                        .registerTypeAdapter(LocalDate.class, new LocalDateTypeAdapter())
                        .create();
                searchDTO = gson.fromJson(searchDtoJson, CRSummarySearchDTO.class);

            } catch (Exception e) {
                System.out.println(e.getMessage());
                log.error("ChangeBranch getAllSummaryData Error: {}", e.getMessage());
            }
        }
        return changeBranchService.getSummaryQueryDataCommon(request, input, searchDTO, RequestTypeEnum.Change_Branch);
    }

    @GetMapping("/summary/getAllQueryData")
    public DataTablesOutput<CRMasterEntity> getAllApprovalLogDetailsData(
            HttpServletRequest request,
            @Valid DataTablesInput input,
            @RequestParam(value = "searchDto", required = false) String searchDtoJson
    ) {
        CRSummarySearchDTO searchDTO = null;
        if (searchDtoJson != null) {
            try {
                Gson gson = new GsonBuilder()
                        .registerTypeAdapter(LocalDate.class, new LocalDateTypeAdapter())
                        .create();
                searchDTO = gson.fromJson(searchDtoJson, CRSummarySearchDTO.class);

            } catch (Exception e) {
                System.out.println(e.getMessage());
                // Handle the exception or log the error
            }
        }
        return changeBranchService.getSummaryQueryData(request, input, searchDTO);
    }

    @PostMapping("/summary/single/details")
    public CommonRestResponse getSingleReqSummaryData(@RequestBody Long reqSummaryId, HttpServletRequest request) {
        return changeBranchService.getSingleReqSummaryData(reqSummaryId, request);
    }

    @PostMapping("/upload/changeBranch")
    public CommonRestResponse bulkUpload(HttpServletRequest request, @RequestParam("file") MultipartFile file,
                                         @RequestParam("processNow") String processNow, @RequestParam("companyName") String companyName,
                                         @RequestParam("processDate") String processDate, @RequestParam("companyId") String companyId
    ) throws ServletException, IOException {
        return changeBranchService.bulkUpload(request, file, processDate, processNow, companyId, companyName);
    }
}
