package com.reddot.ecrm.controller.special_offer;

import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.module.commonConfig.CommonConfig;
import com.reddot.ecrm.module.commonConfig.CommonConfigRepo;
import com.reddot.ecrm.repository.company.CompanyRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/special-offer")
@RequiredArgsConstructor
public class SpecialOfferController {
    @Autowired
    CompanyRepository companyRepository;
    @Autowired
    CommonConfigRepo commonConfigRepo;


    @GetMapping("/add")
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);


        List<CompanyEntity> companyEntityList = companyRepository.findAllByActive(true);

        //type: add new number and sub-type: special offer type
        List<CommonConfig> specialOfferType = commonConfigRepo.findAllByTypeIdAndSubTypeId(17L, 39L);
        //type: add new number and sub-type: special offer level
        List<CommonConfig> specialOfferLevel = commonConfigRepo.findAllByTypeIdAndSubTypeId(17L, 40L);


        model.addAttribute("breadcrumb", "Special Offer");
        model.put("company_list", companyEntityList);
        model.put("specialOfferType", specialOfferType);
        model.put("specialOfferLevel", specialOfferLevel);
        model.put("title", "Special Offer");

        return "special_offer/special_offer_add";
    }
}
