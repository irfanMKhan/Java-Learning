package com.reddot.ecrm.deposit;

import lombok.Data;

@Data
public class GetAmountFromThirdPartyResp {
    private String currentDepositAmount;
}
