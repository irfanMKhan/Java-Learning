package com.reddot.ecrm.controller.sr.management;


import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.dto.sr.management.BulkSRObjectModel;
import com.reddot.ecrm.dto.sr.management.BulkSRPostModel;
import com.reddot.ecrm.dto.sr.management.TBLSRActionModel;
import com.reddot.ecrm.dto.sr.management.TBLSRModel;
import com.reddot.ecrm.dto.srsettings.RootCause.MDSrRootCauseModel;
import com.reddot.ecrm.dto.srsettings.RoutingGroup.SRRoutingGroupModel;
import com.reddot.ecrm.dto.srsettings.Status.MDSrStatusModel;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.remedy.RemedyHelper;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.session.SessionConstants;
import com.reddot.ecrm.spring_config.session.SessionManager;
import com.reddot.ecrm.util.JsonIterator;
import com.reddot.ecrm.util.SendMessage;
import com.reddot.ecrm.util.Utility;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

@Service
public class SrBulkUpdateService {

    private final Logger logger = LoggerFactory.getLogger("SRSettingsLogger");

    @Autowired
    private CommonRepository commonDAO;
    @Autowired
    private RemedyHelper remedyHelper;

    public CommonRestResponse updateSrInBulk(HttpServletRequest request, BulkSRPostModel bulkSRPostModel) {
        CommonRestResponse commonRestResponse = new CommonRestResponse();
        int successUpdateCount = 0;
        int failedUpdateCount = 0;
        int openActivityCount = 0;

        try {
            Map<String, Object> updateData = new HashMap<String, Object>();
            long timeStamp = Utility.getCurrentTimestamp();
            Long positionId = SessionManager.getUserDetails(request).getPOSITION_ID();
            if (positionId == null || positionId == 0) {
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("You are not assigned to a valid Owner Group. Please contact with your superior.");
                return commonRestResponse;
            }

            String modStatus = "";
            String modRootCause = "";
            String modSummary = "";
            String modDescription = "";
            String modRootCauseDetails = "";
            String modSolution = "";
            String modCancelReason = "";
            String modOwnerName = "";

            if (bulkSRPostModel.getEditItems().isEmpty()) {
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("No update items found. Please try with valid filed inputs.");
                return commonRestResponse;
            } else {
                for (BulkSRObjectModel bulkSRObjectModel : bulkSRPostModel.getEditItems()) {
                    switch (bulkSRObjectModel.getItemId()) {
                        case "1":
                            modStatus = bulkSRObjectModel.getItemValue();
                            break;
                        case "2":
                            modRootCause = bulkSRObjectModel.getItemValue();
                            break;
                        case "7":
                            modSummary = bulkSRObjectModel.getItemValue();
                            break;
                        case "8":
                            modDescription = bulkSRObjectModel.getItemValue();
                            break;
                        case "3":
                            modRootCauseDetails = bulkSRObjectModel.getItemValue();
                            break;
                        case "4":
                            modSolution = bulkSRObjectModel.getItemValue();
                            break;
                        case "5":
                            modCancelReason = bulkSRObjectModel.getItemValue();
                            break;
                        case "6":
                            modOwnerName = bulkSRObjectModel.getItemValue();
                            break;

                    }
                }
            }

            if (modStatus.isEmpty() && modRootCause.isEmpty() && modSummary.isEmpty() && modDescription.isEmpty() && modRootCauseDetails.isEmpty()
                    && modSolution.isEmpty() && modCancelReason.isEmpty() && modOwnerName.isEmpty()) {
                commonRestResponse.setCode(404);
                commonRestResponse.setMessage("No update items found. Please try with valid filed inputs.");
                return commonRestResponse;
            }

            String query = "SELECT * FROM " + Utility.tbl_sr + " " + SessionManager.getAttribute(SessionConstants.SR_LAST_QUERY.name(), request) + " OFFSET 0 ROWS FETCH NEXT 500 ROWS ONLY";// + SessionManager.getAttribute(SessionConstants.SR_LAST_QUERY_PAGINATION.name(), request);
            if (bulkSRPostModel.getRowSpec() != null && !bulkSRPostModel.getRowSpec().isEmpty() && bulkSRPostModel.getRowSpec().equalsIgnoreCase("onlyVisibleRow")) {
                query = "SELECT * FROM " + Utility.tbl_sr + " " + SessionManager.getAttribute(SessionConstants.SR_LAST_QUERY.name(), request) + SessionManager.getAttribute(SessionConstants.SR_LAST_QUERY_PAGINATION.name(), request);
            }
            logger.info("Bulk query: " + query);
            Object listObject = commonDAO.getDataPostgres(query);
            List<TBLSRModel> srList = new Gson().fromJson(Utility.ObjectToJson(listObject), new TypeToken<List<TBLSRModel>>() {
            }.getType());

            if (srList.isEmpty()) {
                commonRestResponse.setCode(404);
                commonRestResponse.setMessage("No service request found");
                return commonRestResponse;
            }

            String ownerGroupName = srList.get(0).getOWNER_GROUP_NAME();
            Long ownerGroupId = srList.get(0).getOWNER_GROUP_ID();
            Long oldStatusId = srList.get(0).getSR_STATUS_ID();
            Long newStatusId = 0L;
            boolean statusDifferent = false;
            boolean ownerDifferent = false;
            for (TBLSRModel tblsrModel : srList) {
                if (!oldStatusId.equals(tblsrModel.getSR_STATUS_ID())) {
                    statusDifferent = true;
                    break;
                } else if (!ownerGroupName.equals(tblsrModel.getOWNER_GROUP_NAME())) {
                    ownerDifferent = true;
                    break;
                }
            }

            //Restriction for cancelled and closed SR
            if (oldStatusId != null && (oldStatusId == 2 || oldStatusId == 6)) {
                commonRestResponse.setCode(401);
                commonRestResponse.setMessage("Cancelled and Closed SR cannot be updated.");
                return commonRestResponse;
            }

            boolean hasReopen = hasReopenPermission(request, oldStatusId);

            if (modOwnerName != null && !modOwnerName.isEmpty() && (oldStatusId == 1L || oldStatusId == 3L)) {
                return proceedToChangeOwner(modOwnerName, request, srList);
            }

            if (statusDifferent) {
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("Different type of status are not allowed to update in bulk!");
                return commonRestResponse;
            } else if (!hasReopen && ownerDifferent) {
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("Service request of different type of owner are not allowed to update in bulk!");
                return commonRestResponse;
            }

            if (!hasReopen && !ownerGroupId.equals(positionId)) {
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("Service request of different type of owner are not allowed to update in bulk!");
                return commonRestResponse;
            }

            if (!modStatus.isEmpty()) {
                String statusQuery = "SELECT * FROM MD_SR_STATUS WHERE NAME='" + modStatus + "' AND ACTIVE=1";
                Object statusObject = commonDAO.getDataPostgres(statusQuery);
                List<MDSrStatusModel> statusModelList = new Gson().fromJson(Utility.ObjectToJson(statusObject), new TypeToken<List<MDSrStatusModel>>() {
                }.getType());

                if (statusModelList.isEmpty()) {
                    commonRestResponse.setCode(500);
                    commonRestResponse.setMessage("Status name is invalid. Please try with valid status");
                    return commonRestResponse;
                }
                newStatusId = (long) statusModelList.get(0).getID();
            }


            //Restriction for Keep In View SR
            if (!validateKeepInViewUpdate(oldStatusId, newStatusId)) {
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("Illegal Status Update.");
                return commonRestResponse;
            }

            if (newStatusId == 2) {
                if (modCancelReason == null || modCancelReason.isEmpty()) {
                    commonRestResponse.setCode(500);
                    commonRestResponse.setMessage("Cancel Reason is mandatory when complaint status is Cancel.");
                    return commonRestResponse;
                }
            }

            if (newStatusId == 5) {
                if (modSolution.isEmpty()) {
                    commonRestResponse.setCode(500);
                    commonRestResponse.setMessage("Solution is mandatory when complaint status is Completed.");
                    return commonRestResponse;
                }
            }

            for (TBLSRModel tblsrModel : srList) {
                boolean isReopened = false;
                TBLSRActionModel tblsrActionModel = new TBLSRActionModel();
                try {
                    updateData.clear();
                    if (modStatus != null && !modStatus.isEmpty()) {
                        updateData.put("SR_STATUS_ID", newStatusId);
                        updateData.put("SR_STATUS_NAME", modStatus);
                        tblsrModel.setSR_STATUS_NAME(modStatus);
                    }

                    if (modSummary != null && !modSummary.isEmpty()) {
                        updateData.put("SUMMARY", modSummary);
                    }

                    if (modDescription != null && !modDescription.isEmpty()) {
                        updateData.put("DESCRIPTION", modDescription);
                    }

                    if (modRootCauseDetails != null && !modRootCauseDetails.isEmpty()) {
                        updateData.put("ROOT_CAUSE_DETAIL", modRootCauseDetails);
                        tblsrModel.setROOT_CAUSE_DETAIL(modRootCauseDetails);
                    }

                    if (modSolution != null && !modSolution.isEmpty()) {
                        updateData.put("RESOLUTION_SOLUTION", modSolution);
                        tblsrModel.setRESOLUTION_SOLUTION(modSolution);
                    }

                    if (modCancelReason != null && !modCancelReason.isEmpty()) {
                        updateData.put("ESC_CANCEL_REASON", modCancelReason);
                        updateData.put("SLA_STOP_TIME", timeStamp);
                    }

                    if (modRootCause != null && !modRootCause.isEmpty()) {
                        String rootCauseQuery = "SELECT ID, NAME FROM MD_SR_ROOT_CAUSE WHERE NAME='" + modRootCause + "' AND ACTIVE=1";
                        Object rootCauseObject = commonDAO.getDataPostgres(rootCauseQuery);
                        List<MDSrRootCauseModel> rootCauseModelList = new Gson().fromJson(Utility.ObjectToJson(rootCauseObject), new TypeToken<List<MDSrRootCauseModel>>() {
                        }.getType());

                        if (!rootCauseModelList.isEmpty()) {
                            updateData.put("ROOT_CAUSE_ID", rootCauseModelList.get(0).getID());
                            updateData.put("ROOT_CAUSE_NAME", rootCauseModelList.get(0).getNAME());
                            tblsrModel.setROOT_CAUSE_NAME(modRootCause);
                        }
                    }

                    updateData.put("UPDATED_BY", Utility.getUserId(request));
                    updateData.put("UPDATED_AT", timeStamp);
                    updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));

                    updateData.put("REMARKS", "Bulk SR Update. TimeStamp: " + timeStamp + ", User: " + Utility.getLoginName(request));

                    if (newStatusId != null && newStatusId > 0 && !newStatusId.equals(tblsrModel.getSR_STATUS_ID())) {
                        if (newStatusId == 4) {
                            updateData.put("SLA_STOP_TIME", timeStamp);
                            updateData.put("KEEPINVIEW_DATE", timeStamp);
                            try {
                                long durationInHour = Math.round((System.currentTimeMillis() - tblsrModel.getSUBMITTED_AT()) / (1000.0 * 60 * 60));
                                updateData.put("DURATION_IN_HR", durationInHour);
                                if (durationInHour <= tblsrModel.getSLA_HR()) {
                                    updateData.put("IS_WITHIN_SLA", 1);
                                } else if (durationInHour > tblsrModel.getSLA_HR()) {
                                    updateData.put("IS_WITHIN_SLA", 2);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                logger.error(e.getMessage(), e);
                            }
                        }

                        if (newStatusId == 5) {
                            String countQuery = "SELECT COUNT(ID) AS ACTIVE_ACTIVITY_NUM FROM TBL_SR_ACTIVITY WHERE SR_NUM='" + srList.get(0).getSR_NUM() + "' AND STATUS_ID NOT IN ('61', '302', '269')";
                            logger.info(countQuery);
                            int count = commonDAO.CommoNumberOfRow(countQuery);
                            if (count > 0) {
                                openActivityCount++;
                                continue;
                            }

                            updateData.put("RESOLVED_BY", Utility.getUserId(request));
                            updateData.put("RESOLVED_BY_NAME", Utility.getLoginName(request));
                            updateData.put("RESOLVED_AT", timeStamp);
//                            updateData.put("SLA_STOP_TIME", timeStamp);
                            try {
                                if (tblsrModel.getSLA_STOP_TIME() != null && tblsrModel.getSLA_STOP_TIME() >= 0) {
                                    long durationInHour = Math.round((tblsrModel.getSLA_STOP_TIME() - tblsrModel.getSUBMITTED_AT()) / (1000.0 * 60 * 60));
                                    updateData.put("DURATION_IN_HR", durationInHour);
                                    if (durationInHour <= tblsrModel.getSLA_HR()) {
                                        updateData.put("IS_WITHIN_SLA", 1);
                                    } else if (durationInHour > tblsrModel.getSLA_HR()) {
                                        updateData.put("IS_WITHIN_SLA", 2);
                                    }
                                } else {
                                    updateData.put("SLA_STOP_TIME", timeStamp);
                                    long durationInHour = Math.round((System.currentTimeMillis() - tblsrModel.getSUBMITTED_AT()) / (1000.0 * 60 * 60));
                                    updateData.put("DURATION_IN_HR", durationInHour);
                                    if (durationInHour <= tblsrModel.getSLA_HR()) {
                                        updateData.put("IS_WITHIN_SLA", 1);
                                    } else if (durationInHour > tblsrModel.getSLA_HR()) {
                                        updateData.put("IS_WITHIN_SLA", 2);
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                logger.error(e.getMessage(), e);
                            }
                        }

                        if (newStatusId == 6) {
                            String countQuery = "SELECT COUNT(ID) AS ACTIVE_ACTIVITY_NUM FROM TBL_SR_ACTIVITY WHERE SR_NUM='" + srList.get(0).getSR_NUM() + "' AND STATUS_ID NOT IN ('61', '302', '269')";
                            logger.info(countQuery);
                            int count = commonDAO.CommoNumberOfRow(countQuery);
                            if (count > 0) {
                                openActivityCount++;
                                continue;
                            }

                            updateData.put("CLOSED_BY", Utility.getUserId(request));
                            updateData.put("CLOSED_BY_NAME", Utility.getLoginName(request));
                            updateData.put("CLOSED_AT", timeStamp);

                            try {
                                if (tblsrModel.getSLA_STOP_TIME() != null && tblsrModel.getSLA_STOP_TIME() >= 0) {
                                    long durationInHour = Math.round((tblsrModel.getSLA_STOP_TIME() - tblsrModel.getSUBMITTED_AT()) / (1000.0 * 60 * 60));
                                    updateData.put("DURATION_IN_HR", durationInHour);
                                    if (durationInHour <= tblsrModel.getSLA_HR()) {
                                        updateData.put("IS_WITHIN_SLA", 1);
                                    } else if (durationInHour > tblsrModel.getSLA_HR()) {
                                        updateData.put("IS_WITHIN_SLA", 2);
                                    }
                                } else {
                                    updateData.put("SLA_STOP_TIME", timeStamp);
                                    long durationInHour = Math.round((System.currentTimeMillis() - tblsrModel.getSUBMITTED_AT()) / (1000.0 * 60 * 60));
                                    updateData.put("DURATION_IN_HR", durationInHour);
                                    if (durationInHour <= tblsrModel.getSLA_HR()) {
                                        updateData.put("IS_WITHIN_SLA", 1);
                                    } else if (durationInHour > tblsrModel.getSLA_HR()) {
                                        updateData.put("IS_WITHIN_SLA", 2);
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                logger.error(e.getMessage(), e);
                            }

                        }

                        if (newStatusId == 3 && tblsrModel.getSR_STATUS_ID() == 5) {
                            isReopened = true;
                            updateData.put("SLA_STOP_TIME", null);
                            updateData.put("DURATION_IN_HR", null);
                            updateData.put("IS_WITHIN_SLA", 0);
                            updateData.put("RESOLVED_BY", null);
                            updateData.put("RESOLVED_BY_NAME", null);
                            updateData.put("RESOLVED_AT", null);
                            updateData.put("IS_REOPENED", 1);
                            updateData.put("REOPEN_AT", timeStamp);
                            updateData.put("REOPEN_BY", Utility.getUserId(request));
                            updateData.put("REOPEN_BY_NAME", Utility.getLoginName(request));
                        }
                        tblsrActionModel.setOLD_DATA(tblsrModel.getSR_STATUS_NAME());
                        tblsrActionModel.setNEW_DATA(modStatus);
                        tblsrActionModel.setSR_ACTION_TYPE_NAME("Status Changed");
                        tblsrActionModel.setREMARKS("Status Changed");
                    }

                    try {
                        if (tblsrModel.getREMEDY_INCIDENT_NO() != null && !tblsrModel.getREMEDY_INCIDENT_NO().isEmpty()) {
                            JSONObject jsonObject = null;
                            if (isReopened) {
                                jsonObject = remedyHelper.updateReOpenedTroubleTicketSRModel(logger, tblsrModel);
                            } else {
                                jsonObject = remedyHelper.updateTroubleTicketSRModel(logger, tblsrModel);
                            }

                            if (jsonObject != null && new JsonIterator().getFirstOccurrence(jsonObject, "StatusCode") != null && new JsonIterator().getFirstOccurrence(jsonObject, "StatusCode").toString().equalsIgnoreCase("0")) {
                                System.out.println("Remedy Update successful");
                                System.out.println("Remedy Response: " + jsonObject.toString());
                            }
                            logger.info("Remedy Update Response: " + jsonObject.toString());
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        logger.error(e.getMessage(), e);
                    }

                    Map<String, Object> whereData = new HashMap<>();
                    whereData.put("SR_NUM", Long.parseLong(tblsrModel.getSR_NUM()));
                    if (commonDAO.CommoUpdate(Utility.tbl_sr, updateData, whereData, logger)) {
                        successUpdateCount++;


                        if (newStatusId == 6) {
                            String message = "প্রিয় গ্রাহক, \nআপনার সার্ভিস রিকোয়েস্ট  " + tblsrModel.getSR_NUM() + " সমাধান করা হয়েছে। ধন্যবাদ";
                            new SendMessage().send(tblsrModel.getMSISDN(), message, "SR", request);
                        }

                        tblsrActionModel.setSR_NUM(tblsrModel.getSR_NUM());
                        tblsrActionModel.setMSISDN(tblsrModel.getMSISDN());
                        if (isReopened) {
                            tblsrActionModel.setSR_ACTION_TYPE_NAME("Re-opened");
                            tblsrActionModel.setREMARKS("Re-opened");
                        } else {
                            if (tblsrActionModel.getSR_ACTION_TYPE_NAME() != null && !tblsrActionModel.getSR_ACTION_TYPE_NAME().isEmpty()) {
                                tblsrActionModel.setSR_ACTION_TYPE_NAME("SR Updated");
                            }
                            if (tblsrActionModel.getREMARKS() != null && !tblsrActionModel.getREMARKS().isEmpty()) {
                                tblsrActionModel.setREMARKS("SR Updated");
                            }
                        }
                        insertSrAction(tblsrActionModel, request);

                    } else {
                        failedUpdateCount++;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    logger.error(e.getMessage(), e);
                    failedUpdateCount++;
                }
            }

            commonRestResponse.setCode(200);
            commonRestResponse.setMessage(successUpdateCount + " SR Updated successfully.\n" +
                    failedUpdateCount + " SR Failed to update.\n" +
                    openActivityCount + " SR Failed to updated due activity was open.");
            return commonRestResponse;

        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Error occurred. Please try later.");
        }
        return commonRestResponse;
    }

    void insertSrAction(TBLSRActionModel tblsrActionModel, HttpServletRequest request) {
        try {
            Map<String, Object> insertData = new HashMap<String, Object>();
            insertData.put("SR_NUM", tblsrActionModel.getSR_NUM());
            insertData.put("MSISDN", tblsrActionModel.getMSISDN());
            insertData.put("REMARKS", tblsrActionModel.getREMARKS());
            insertData.put("SR_ACTION_TYPE_NAME", tblsrActionModel.getSR_ACTION_TYPE_NAME());
            insertData.put("OLD_DATA", tblsrActionModel.getOLD_DATA());
            insertData.put("NEW_DATA", tblsrActionModel.getNEW_DATA());
            insertData.put("CREATED_BY", Utility.getUserId(request));
            insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
            insertData.put("CREATED_AT", Utility.getCurrentTimestamp());
            insertData.put("CREATED_AT_DT", new Date());
            commonDAO.CommoInsert(Utility.tbl_sr_actions, insertData, logger);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
    }

    private CommonRestResponse proceedToChangeOwner(String newOwner, HttpServletRequest request, List<TBLSRModel> srList) {
        CommonRestResponse commonRestResponse = new CommonRestResponse();
        List<SRRoutingGroupModel> list = new ArrayList<>();
        int updateSuccessCount = 0;
        int updateFailedCount = 0;
        try {
            String query = "SELECT * FROM " + Utility.md_user_position + " WHERE IS_SR_OWNER=1 AND (NAME='" + newOwner + "' OR OWNER_NAME='" + newOwner + "')";
            Object listObject = commonDAO.getDataPostgres(query);
            list = new Gson().fromJson(Utility.ObjectToJson(listObject), new TypeToken<List<SRRoutingGroupModel>>() {
            }.getType());

            if (list.isEmpty()) {
                commonRestResponse.setCode(404);
                commonRestResponse.setMessage("Invalid owner information.");
                return commonRestResponse;
            } else {
                SRRoutingGroupModel owner = list.get(0);
                Map<String, Object> updateData = new HashMap<String, Object>();
                updateData.put("OWNER_GROUP_ID", owner.getID());
                updateData.put("OWNER_GROUP_NAME", owner.getNAME());
                updateData.put("OWNER_ID", owner.getOWNER_ID());
                updateData.put("OWNER_NAME", owner.getOWNER_NAME());
                updateData.put("OWNER_EMAIL", owner.getOWNER_EMAIL());
                updateData.put("UPDATED_BY", Utility.getUserId(request));
                updateData.put("UPDATED_AT", Utility.getCurrentTimestamp());
                updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
                Map<String, Object> whereData = new HashMap<String, Object>();
                for (TBLSRModel tblsrModel : srList) {
                    try {
                        whereData.clear();
                        whereData.put("SR_NUM", Long.parseLong(tblsrModel.getSR_NUM()));
                        if (commonDAO.CommoUpdate(Utility.tbl_sr, updateData, whereData, logger)) {
                            updateSuccessCount++;
                            try {
                                Map<String, Object> insertData = new HashMap<String, Object>();
                                insertData.put("SR_NUM", Long.parseLong(tblsrModel.getSR_NUM()));
                                insertData.put("MSISDN", tblsrModel.getMSISDN());
                                insertData.put("OLD_DATA", tblsrModel.getOWNER_GROUP_NAME());
                                insertData.put("NEW_DATA", owner.getNAME());
                                String remarks = "Bulk change owner";
                                insertData.put("REMARKS", remarks);
                                insertData.put("SR_ACTION_TYPE_NAME", "Owner Changed");
                                insertData.put("CREATED_BY", Utility.getUserId(request));
                                insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
                                insertData.put("CREATED_AT", Utility.getCurrentTimestamp());
                                insertData.put("CREATED_AT_DT", new Date());
                                commonDAO.CommoInsert(Utility.tbl_sr_actions, insertData, logger);
                            } catch (Exception e) {
                                e.printStackTrace();
                                logger.error(e.getMessage(), e);
                            }
                        } else {
                            updateFailedCount++;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        updateFailedCount++;
                    }
                }
            }
            commonRestResponse.setCode(200);
            commonRestResponse.setMessage("Owner updated. Successful=" + updateSuccessCount + ", Failed=" + updateFailedCount);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Error occurred during owner change.");
        }
        return commonRestResponse;
    }

    private boolean hasReopenPermission(HttpServletRequest request, Long statusId) {
        String countQuery = "SELECT COUNT(*) AS CNT FROM " + Utility.md_user_responsibility_map + " WHERE USER_ID=" + Utility.getUserId(request) + "  AND RESPONSIBILITY_ID=240";
        logger.info(countQuery);
        int count = commonDAO.CommoNumberOfRow(countQuery);
        return count >= 1 && (statusId == 4 || statusId == 5);
    }

    private boolean validateKeepInViewUpdate(Long oldStatusId, Long newStatusId) {
        boolean validKeepInView = true;
        if (oldStatusId != null && oldStatusId == 4 && newStatusId != null && newStatusId > 0L) {
            switch (newStatusId + "") {
                case "1":
                case "2":
                case "3":
//                case "5":
                    validKeepInView = false;
                    break;
            }
        }
        return validKeepInView;
    }

}