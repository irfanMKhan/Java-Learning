package com.reddot.ecrm.controller.PDFAndHotBill;

import com.reddot.ecrm.dto.PDFAndHotBill.*;
import com.reddot.ecrm.entity.company.CompanyAccountEntity;
import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.entity.cr.CRMasterEntity;
import com.reddot.ecrm.entity.cr.CRMsisdnDetailsEntity;
import com.reddot.ecrm.entity.msisdn.MsisdnEntity;
import com.reddot.ecrm.service.pdfAndHotBill.HotBillService;
import freemarker.template.TemplateException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/HotBill/Report")
public class HotBillRestController {

    private final HotBillService hotBillService;

    @PostMapping(value = "/search", consumes = MediaType.APPLICATION_JSON_VALUE)
    public List<CRMasterEntity> search(HttpServletRequest request, @Valid DataTablesInput input, @Valid @RequestBody HotBillSearchDTO hotBillSearchDTO) throws IllegalAccessException {
        return hotBillService.getSearchData(request, input, hotBillSearchDTO);
    }

    @PostMapping(value = "/view", consumes = MediaType.APPLICATION_JSON_VALUE)
    public List<CRMsisdnDetailsEntity> view(HttpServletRequest request, @Valid DataTablesInput input, @Valid @RequestBody HotBillSearchDTO hotBillSearchDTO) throws IllegalAccessException {
        return hotBillService.getViewData(request, input, hotBillSearchDTO);
    }

    @PostMapping(value = "/createPageSearch", consumes = MediaType.APPLICATION_JSON_VALUE)
    public List<MsisdnEntity> createPageSearch(HttpServletRequest request, @Valid DataTablesInput input, @Valid @RequestBody HotBillSearchDTO hotBillSearchDTO) throws IllegalAccessException {
        return hotBillService.getCompanyMSISDNMapModelData(request, input, hotBillSearchDTO);
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String add(HttpServletRequest httpServletRequest, @RequestBody HotBillCreateDTO hotBillCreateDTO) {
        return hotBillService.add(httpServletRequest, hotBillCreateDTO);
    }

    /*@RequestMapping(value = "/getCompany", method = RequestMethod.GET)
    public List<CompanyEntity> getCompany() {
        return hotBillService.getAllCompany();
    }*/

    @RequestMapping(value = "/getCompany", method = RequestMethod.GET)
    public List<CompanyEntity> getCompany(HttpServletRequest request) {
        return hotBillService.GetAllCompanyNameWithContactTablePICMapped(request);
    }

    @RequestMapping(value = "/getAccountCode", method = RequestMethod.GET)
    public List<CompanyAccountEntity> getAccountCode(@RequestParam("companyId") Long companyId) {
        return hotBillService.getAllAccountCode(companyId);
    }

    @RequestMapping(value = "/getAllMsisdn", method = RequestMethod.GET)
    public List<MsisdnEntity> getAllMsisdn(@RequestParam("accountCode") String accountCode) {
        return hotBillService.getAllMsisdn(accountCode);
    }

    @PostMapping(value = "/sendEmail", consumes = MediaType.APPLICATION_JSON_VALUE)
    public String sendEmail(HttpServletRequest request,@Valid  @RequestBody SendEmailDTO sendEmailDTO) throws MessagingException, TemplateException, IOException {
        return hotBillService.sendMail(sendEmailDTO.getDefaultEmail(),sendEmailDTO.getAlterEmail(),sendEmailDTO.getFileName(),request);
    }

}
