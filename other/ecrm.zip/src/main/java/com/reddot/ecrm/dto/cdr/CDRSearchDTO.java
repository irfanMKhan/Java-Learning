package com.reddot.ecrm.dto.cdr;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
@Getter
@Setter
public class CDRSearchDTO {
    private String companyName;
    private String accountCode;
    private String msisdn;
    private String status;
    private Long companyId;
    private String startDate;
    private String usageType;
    private String fileType;
    private String endDate;
    private Boolean isAdvanceSearch;
}
