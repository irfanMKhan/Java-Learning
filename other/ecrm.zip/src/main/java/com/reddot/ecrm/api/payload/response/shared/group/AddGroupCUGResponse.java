package com.reddot.ecrm.api.payload.response.shared.group;


import com.reddot.ecrm.api.payload.response.contract.group.CreateCUGGroupResponse;
import lombok.Data;

import java.io.Serializable;

@Data
public class AddGroupCUGResponse implements Serializable {
    private String transaction_id;

    private String transaction_status;

    private CreateCUGGroupResponse.Metadata metadata;

    private CreateCUGGroupResponse.Data data;

    @lombok.Data
    public static class Metadata implements Serializable {
        private String operator_id;

        private String channel_id;
    }

    @lombok.Data
    public static class Data implements Serializable {

    }
}
