package com.reddot.ecrm.api.payload.response.post2pre;

import lombok.Data;

import java.io.Serializable;

@Data
public class PostpaidToPrepaidResponse implements Serializable {
    private String RspTime;

    private String ReturnCode;

    private String ReturnMsg;
}