package com.reddot.ecrm.controller.customerInfo;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.dto.cdr.CDRSearchDTO;
import com.reddot.ecrm.dto.customerReport.CustomerReportSearchDTO;
import com.reddot.ecrm.entity.company.CompanyAccountEntity;
import com.reddot.ecrm.entity.msisdn.MsisdnEntity;
import com.reddot.ecrm.module.commonConfig.CommonConfig;
import com.reddot.ecrm.service.customerInfo.CustomerInfoService;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/CustomerInfo/Report")
public class CustomerInfoRestController {
    private final CustomerInfoService customerInfoService;

    @PostMapping(value = "/search", consumes = MediaType.APPLICATION_JSON_VALUE)
    public DataTablesOutput<MsisdnEntity> search(@RequestBody Map<String, Object> data) throws IllegalAccessException, JsonProcessingException {
        DataTablesInput input = new Gson().fromJson(Utility.ObjectToJson(data.get("input")), new TypeToken<DataTablesInput>(){}.getType());

        ObjectMapper mapper = new ObjectMapper();
        CustomerReportSearchDTO customerReportSearchDTO = mapper.readValue(data.get("customerReportSearchDTO").toString(), CustomerReportSearchDTO.class);

        return customerInfoService.getCustomerInfoData( input, customerReportSearchDTO);

    }

    @RequestMapping(value = "/getAllFileType", method = RequestMethod.GET)
    public List<CommonConfig> getAllFileType() {
        return customerInfoService.getAllFileType();
    }

    @RequestMapping(value = "/getAllFilterType", method = RequestMethod.GET)
    public List<CommonConfig> getAllFilterType() {
        return customerInfoService.getAllFilterType();
    }

    @RequestMapping(value = "/getAccountCode", method = RequestMethod.GET)
    public List<CompanyAccountEntity> getAccountCode(@RequestParam("companyId") Long companyId) {
        return customerInfoService.getAllAccountCode(companyId);
    }
}
