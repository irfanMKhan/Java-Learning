package com.reddot.ecrm.controller.cr.suspend;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SuspendSearchReqDto {
    private String companyId;
    private String requestType;
    private String transactionID;
    private String effectiveDate;
}
