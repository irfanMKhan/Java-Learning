package com.reddot.ecrm.api.gateway.contract;


import com.google.gson.Gson;
import com.reddot.ecrm.api.exception.*;
import com.reddot.ecrm.api.payload.request.contract.account.CreateCorporateAccountRequest;
import com.reddot.ecrm.api.payload.request.contract.branch.ChangeCorporateGroupMemberInfoRequest;
import com.reddot.ecrm.api.payload.request.contract.customer.CreateCorporateCustomerRequest;
import com.reddot.ecrm.api.payload.request.contract.group.CreateCUGGroupRequest;
import com.reddot.ecrm.api.payload.request.contract.group.QueryGroupMemberRequest;
import com.reddot.ecrm.api.payload.request.contract.order.CreateOrderRequest;
import com.reddot.ecrm.api.payload.request.contract.payment.ChangeCorporateAccountPaymentRelationRequest;
import com.reddot.ecrm.api.payload.request.contract.subscriber.CreateCorporateSubscriberRequest;
import com.reddot.ecrm.api.payload.response.ErrorResponse;
import com.reddot.ecrm.api.payload.response.branch.ChangeCorporateGroupMemberInfoResponse;
import com.reddot.ecrm.api.payload.response.contract.account.CreateCorporateAccountResponse;
import com.reddot.ecrm.api.payload.response.contract.account.QueryAccountInformationResponse;
import com.reddot.ecrm.api.payload.response.contract.account.QueryBalanceResponse;
import com.reddot.ecrm.api.payload.response.contract.account.QueryPurchasedSupplementaryOfferingResponse;
import com.reddot.ecrm.api.payload.response.contract.customer.*;
import com.reddot.ecrm.api.payload.response.contract.group.CreateCUGGroupErrorResponse;
import com.reddot.ecrm.api.payload.response.contract.group.CreateCUGGroupResponse;
import com.reddot.ecrm.api.payload.response.contract.group.QueryGroupMemberResponse;
import com.reddot.ecrm.api.payload.response.contract.order.CreateOrderResponse;
import com.reddot.ecrm.api.payload.response.contract.payment.ChangeCorporateAccountPaymentRelationResponse;
import com.reddot.ecrm.api.payload.response.contract.subscriber.CreateCorporateSubscriberResponse;
import com.reddot.ecrm.api.security.AuthorizationGateway;
import com.reddot.ecrm.api.utility.CommonConstant;
import com.reddot.ecrm.api.utility.HttpClient;
import com.reddot.ecrm.api.utility.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.FormBody;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.io.UnsupportedEncodingException;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class ContractGateway {

    private final HttpClient httpClient;
    private final Gson gson;
    private final AuthorizationGateway authorizationGateway;

    @Value("${smart.egw.base.url}")
    String baseUrlEGW;
    @Value("${smart.igw.base.url}")
    String baseUrlIGW;

    // EGW Gateway
    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public CreateCorporateCustomerResponse createCorporateCustomer(CreateCorporateCustomerRequest customerReq) {
        String apiUrl = baseUrlEGW + "/corporate/createCorporateCustomer/v1.0";
        String json = gson.toJson(customerReq);

        try (Response response = httpClient.put(json, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), CreateCorporateCustomerResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("Create Corporate Cust Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("Create Corporate Cust Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("Create Corporate Cust Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("Create Corporate Cust Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("Create Corporate Cust Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }


    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public QryCorporateEntityIdsResponse qryCorporateEntityIds(String objectType, String custName) throws UnsupportedEncodingException {
        String apiUrl = baseUrlEGW + "/corporate/qryCorporateEntityIds/v1.0";
        RequestBody formBody = new FormBody.Builder().add("ObjectType", objectType).add("Custname", custName).build();

        try (Response response = httpClient.post(formBody, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), QryCorporateEntityIdsResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("QryCorporateEntity Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("QryCorporateEntity Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("QryCorporateEntity Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("QryCorporateEntity Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("QryCorporateEntity Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public QryEntityIdsResponseIGW qryCorporateEntityIdsNewIGW(String custName) throws UnsupportedEncodingException {
        String apiUrl = baseUrlIGW + "/api/CorpEntityId/v2";
        RequestBody formBody = new FormBody.Builder().add("CustName", custName).build();

        try (Response response = httpClient.post(formBody, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), QryEntityIdsResponseIGW.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("QryCorporateEntityIdsNewIGW Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("QryCorporateEntityIdsNewIGW Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("QryCorporateEntityIdsNewIGW Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("QryCorporateEntityIdsNewIGW Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("QryCorporateEntityIdsNewIGW Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public QueryCorporateCustResponse queryCorporateCustomer(String version, String partnerId, String businessCode, String transactionId, String reqTime, String channel, String accessUser, String accessPassword, String corporateName) throws UnsupportedEncodingException {
        String apiUrl = baseUrlEGW + "/corporate/queryCorporateCustomer/v1.0?version=" + version + "&" + "partnerId=" + partnerId + "&" + "businessCode=" + businessCode + "&" + "transactionId=" + transactionId + "&" + "reqTime=" + reqTime + "&" + "channel=" + channel + "&" + "accessUser=" + accessUser + "&" + "accessPassword=" + Utils.urlEncode(accessPassword) + "&" + "corporateName=" + corporateName;


        try (Response response = httpClient.get(apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), QueryCorporateCustResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("Query Corporate Cust Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("Query Corporate Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("Query Corporate Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("Query Corporate Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("Query Corporate Cust Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }


    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public CreateCorporateAccountResponse createCorporateAccount(CreateCorporateAccountRequest accountReq) {
        String apiUrl = baseUrlEGW + "/corporate/createCorporateAccount/v1.0";
        String json = gson.toJson(accountReq);

        try (Response response = httpClient.put(json, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), CreateCorporateAccountResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("Create Corporate Acc Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("Create Corporate Acc Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("Create Corporate Acc Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("Create Corporate Acc Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("Create Corporate Acc Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }


//    public CreateCorporateAccountSubResponse createCorporateAccountSub(CreateCorporateAccountSubRequest accountSubReq) {
////        String apiUrl = baseUrlEGW + "/createCorporateAccountSub";
////        String json = gson.toJson(accountSubReq);
////
////        String bearerToken = getAuthKey().getToken();
////        Map<String, String> headers = new HashMap<String, String>() {{
////            put("Authorization", "Bearer " + bearerToken);
////        }};
//
//        return new CreateCorporateAccountSubResponse();
//
////        try (Response response = httpClient.post(json, apiUrl, headers)) {
////            assert response.body() != null;
////            if (response.code() == HttpStatus.OK.value()) {
////                return gson.fromJson(response.body().string(), CreateCorporateAccountSubRes.class);
////            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
////                log.debug("Url Not Found: " + apiUrl);
////                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
////            } else {
////                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
////            }
////        } catch (Exception e) {
////            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
////        }
//    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public QueryAccountInformationResponse queryAccountInformation(String version, String partnerId, String transactionId,
                                                                   String reqTime, String channel, String accessUser,
                                                                   String accessPassword, String objectIdType, String objectId) throws UnsupportedEncodingException {
        String apiUrl = baseUrlEGW + "/account/queryAccountInformation/v1.1?version=" + version + "&" + "partnerId=" + partnerId + "&" + "transactionId=" + transactionId + "&" + "reqTime=" + reqTime + "&" + "channel=" + channel + "&" + "accessUser=" + accessUser + "&" + "accessPassword=" + Utils.urlEncode(accessPassword) + "&" + "objectIdType=" + objectIdType + "&" + "objectId=" + objectId;

        try (Response response = httpClient.get(apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), QueryAccountInformationResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("Query Acc Info Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("Query Acc Info Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("Query Acc Info Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("Query Acc Info Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("Query Corporate Cust Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public QueryBalanceResponse queryBalance(String version, String businessCode, String transactionId, String reqTime, String channel, String accessUser, String accessPassword, String objectIdType, String objectId) throws UnsupportedEncodingException {
        String apiUrl = baseUrlEGW + "/account/queryBalance/V1.0?version=" + version + "&" + "businessCode=" + businessCode + "&" + "transactionId=" + transactionId + "&" + "reqTime=" + reqTime + "&" + "channel=" + channel + "&" + "accessUser=" + accessUser + "&" + "accessPassword=" + Utils.urlEncode(accessPassword) + "&" + "objectIdType=" + objectIdType + "&" + "objectId=" + objectId;

        try (Response response = httpClient.get(apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), QueryBalanceResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("QueryBalance Info Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("QueryBalance Info Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("QueryBalance Info Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("QueryBalance Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("QueryBalance Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public QueryPurchasedSupplementaryOfferingResponse queryPurchasedSupplementaryOffering(String partnerId, String transactionId, String reqTime, String channel, String accessUser, String accessPassword, String objectIdType, String objectId) throws UnsupportedEncodingException {
        String apiUrl = baseUrlEGW + "/offering/queryPurchasedSupplementaryOffering/V1.0?partnerId=" + partnerId + "&" + "transactionId=" + transactionId + "&" + "reqTime=" + reqTime + "&" + "channel=" + channel + "&" + "accessUser=" + accessUser + "&" + "accessPassword=" + Utils.urlEncode(accessPassword) + "&" + "objectIdType=" + objectIdType + "&" + "objectId=" + objectId;
        log.info("Request -> queryPurchasedSupplementaryOffering :: " + apiUrl);

        try (Response response = httpClient.get(apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                String responseStr = response.body().string();
                log.info("Response -> queryPurchasedSupplementaryOffering :: " + responseStr);
                JSONObject jsonObject = new JSONObject(responseStr);

                if (jsonObject.has("QueryPurchasedSupplementaryOfferingRspMsg")) {
                    JSONObject QueryPurchasedSupplementaryOfferingRspMsg = jsonObject.getJSONObject("QueryPurchasedSupplementaryOfferingRspMsg");

                    if (QueryPurchasedSupplementaryOfferingRspMsg.has("SupplementaryOffering")) {
                        if (QueryPurchasedSupplementaryOfferingRspMsg.get("SupplementaryOffering").getClass().getName().contains("org.json.JSONObject")) {
                            JSONObject SupplementaryOfferingObject = QueryPurchasedSupplementaryOfferingRspMsg.getJSONObject("SupplementaryOffering");
                            JSONArray SupplementaryOfferingJsonArray = Utils.convertJsonObjectToArray(SupplementaryOfferingObject);
                            QueryPurchasedSupplementaryOfferingRspMsg.put("SupplementaryOffering", SupplementaryOfferingJsonArray);
                        }
                    }
                }

                return gson.fromJson(String.valueOf(jsonObject), QueryPurchasedSupplementaryOfferingResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("SupplementaryOffering Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("SupplementaryOffering Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("SupplementaryOffering Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("SupplementaryOffering Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("SupplementaryOffering Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }
//    public QueryPurchasedSupplementaryOfferingResponse queryPurchasedSupplementaryOffering(String partnerId, String transactionId, String reqTime, String channel, String accessUser, String accessPassword, String objectIdType, String objectId) throws UnsupportedEncodingException {
//        String apiUrl = baseUrlEGW + "/offering/queryPurchasedSupplementaryOffering/V1.0?partnerId=" + partnerId + "&" + "transactionId=" + transactionId + "&" + "reqTime=" + reqTime + "&" + "channel=" + channel + "&" + "accessUser=" + accessUser + "&" + "accessPassword=" + Utils.urlEncode(accessPassword) + "&" + "objectIdType=" + objectIdType + "&" + "objectId=" + objectId;
//
//        try (Response response = httpClient.get(apiUrl, getHeaders())) {
//            assert response.body() != null;
//            if (response.code() == HttpStatus.OK.value()) {
//                return gson.fromJson(response.body().string(), QueryPurchasedSupplementaryOfferingResponse.class);
//            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
//                log.debug("Url Not Found: " + apiUrl);
//                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
//            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
//                throw new InvalidAccessTokenException();
//            } else {
//                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
//                throw new ApiRequestException(errorResponse.getFault().getMessage());
//            }
//        } catch (Exception e) {
//            if (e instanceof ApiRequestException) {
//                log.debug("SupplementaryOffering Api Request Error: {}", e.getMessage());
//                throw new ApiRequestException(e.getMessage());
//            } else if (e instanceof InvalidAccessTokenException) {
//                log.debug("SupplementaryOffering Access Token Error: {}", e.getMessage());
//                throw new InvalidAccessTokenException();
//            } else if (e instanceof InvalidClientCredentialException) {
//                log.debug("SupplementaryOffering Credentials Error: {}", e.getMessage());
//                throw new InvalidClientCredentialException(e.getMessage());
//            }
//            log.error("SupplementaryOffering Error: {}", e.getMessage(), e.getCause());
//            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
//        }
//    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public CreateOrderResponse createOrder(CreateOrderRequest orderReq) {
        String apiUrl = baseUrlEGW + "/order/createOrder/v1.0";
        String json = gson.toJson(orderReq);

        try (Response response = httpClient.put(json, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), CreateOrderResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("Create Order Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("Create Order Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("Create Order Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("Create Order Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("Create Order Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public ChangeCorporateAccountPaymentRelationResponse changeCorporateAccountPaymentRelation(ChangeCorporateAccountPaymentRelationRequest paymentRelationRequest) {
        String apiUrl = baseUrlEGW + "/HWCRM/ChangeCorporatePaymentRelation/v1.0";
        String json = gson.toJson(paymentRelationRequest);

        try (Response response = httpClient.post(json, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), ChangeCorporateAccountPaymentRelationResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ChangeCorporateAccountPaymentRelationResponse errorResponse = gson.fromJson(response.body().string(), ChangeCorporateAccountPaymentRelationResponse.class);
                throw new ApiRequestException(errorResponse.getChangeCorporatePaymentRelationRspMsg().getRspHeader().getReturnMsg());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("ChangeCorporateAccountPaymentRelation Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("ChangeCorporateAccountPaymentRelation Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("ChangeCorporateAccountPaymentRelation Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("ChangeCorporateAccountPaymentRelation Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("ChangeCorporateAccountPaymentRelation Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }


    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public QueryGroupMemberResponse queryGroupMember(QueryGroupMemberRequest groupMemberReq) {
        String apiUrl = baseUrlEGW + "/HWCRM/Corporate/QueryGroupMember/v1.0";
        String json = gson.toJson(groupMemberReq);

        try (Response response = httpClient.post(json, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                String responseStr = response.body().string();
                JSONObject jsonObject = new JSONObject(responseStr);

                if (jsonObject.has("QueryGroupMemberRspMsg")) {
                    JSONObject QueryGroupMemberRspMsg = jsonObject.getJSONObject("QueryGroupMemberRspMsg");

                    if (QueryGroupMemberRspMsg.has("GroupInfo")) {
                        JSONObject GroupInfo = QueryGroupMemberRspMsg.getJSONObject("GroupInfo");

                        if (GroupInfo.has("GroupMember")) {
                            if (GroupInfo.get("GroupMember").getClass().getName().contains("org.json.JSONObject")) {
                                String GroupMemberStr = "[" + GroupInfo.get("GroupMember").toString() + "]";
                                JSONArray GroupMemberJsonArray = new JSONArray(GroupMemberStr);
                                GroupInfo.put("GroupMember", GroupMemberJsonArray);
                            }
                        }
                    }
                }

                return gson.fromJson(String.valueOf(jsonObject), QueryGroupMemberResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("Query Group Member Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("Query Group Member Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("Query Group Member Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("uery Group Member Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("Query Group Member Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public CreateCorporateSubscriberResponse createCorporateSubscriber(CreateCorporateSubscriberRequest subscriberReq) {
        String apiUrl = baseUrlEGW + "/corporate/createCorporateSubscriber/v1.0";
        String json = gson.toJson(subscriberReq);

        try (Response response = httpClient.put(json, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), CreateCorporateSubscriberResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("Create Corporate Subs Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("Create Corporate Subs Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("Create Corporate Subs Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("Create Corporate Subs Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("Create Corporate Subs Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }


//    public CreateCorporateSubscriberSubResponse createCorporateSubscriberSub(CreateCorporateSubscriberSubRequest subscriberSubReq) {
////        String apiUrl = baseUrlEGW + "/createCorporateSubscriberSub";
////        String json = gson.toJson(subscriberSubReq);
////
////        String bearerToken = getAuthKey().getToken();
////        Map<String, String> headers = new HashMap<String, String>() {{
////            put("Authorization", "Bearer " + bearerToken);
////        }};
//
//        return new CreateCorporateSubscriberSubResponse();
//
////        try (Response response = httpClient.post(json, apiUrl, headers)) {
////            assert response.body() != null;
////            if (response.code() == HttpStatus.OK.value()) {
////                return gson.fromJson(response.body().string(), CreateCorporateSubscriberSubRes.class);
////            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
////                log.debug("Url Not Found: " + apiUrl);
////                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
////            } else {
////                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
////            }
////        } catch (Exception e) {
////            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
////        }
//    }


    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public CreateCUGGroupResponse createCUGGroup(CreateCUGGroupRequest cugGroupRequest) {
        String apiUrl = baseUrlIGW + "/api/bss/cug/v2/groups";
        String json = gson.toJson(cugGroupRequest);

        try (Response response = httpClient.post(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.CREATED.value()) {
                return gson.fromJson(response.body().string(), CreateCUGGroupResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                CreateCUGGroupErrorResponse errorResponse = gson.fromJson(response.body().string(), CreateCUGGroupErrorResponse.class);
                throw new ApiRequestException(errorResponse.getError().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("CreateCUGGroup Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("CreateCUGGroup Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("CreateCUGGroup Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("CreateCUGGroup Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("CreateCUGGroup Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.socket.maxAttempts}", backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public CBSBCCustomerResponse cbsbcCustomer(String msisdn, String bssUsername, String bssPassword) throws UnsupportedEncodingException {
        String apiUrl = baseUrlIGW + "/api/cbsbc/customers/v1/" + msisdn + "?id_type=msisdn&bss_username=" + bssUsername + "&bss_password=" + Utils.urlEncode(bssPassword);
        log.info("Class: ContractGateway -> requesting for cbsbcCustomer -> " + baseUrlIGW + "/api/cbsbc/customers/v1/" + msisdn + "?id_type=msisdn&bss_username=" + "bssUsername" + "&bss_password=" + "Encoded_bssPassword)");

        try (Response response = httpClient.get(apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {

                String responseStr = response.body().string();
                log.info("Class: ContractGateway -> response received for cbsbcCustomer -> " + responseStr);
                JSONObject jsonObject = new JSONObject(responseStr);

                if (jsonObject.has("QueryCustomerInfoResult")) {
                    JSONObject QueryCustomerInfoResult = jsonObject.getJSONObject("QueryCustomerInfoResult");

                    if (QueryCustomerInfoResult.has("Subscriber")) {
                        JSONObject Subscriber = QueryCustomerInfoResult.getJSONObject("Subscriber");

                        if (Subscriber.has("SupplementaryOffering")) {
                            if (Subscriber.get("SupplementaryOffering").getClass().getName().contains("org.json.JSONObject")) {
                                JSONObject SupplementaryOfferingObject = Subscriber.getJSONObject("SupplementaryOffering");
                                JSONArray SupplementaryOfferingJsonArray = Utils.convertJsonObjectToArray(SupplementaryOfferingObject);
                                Subscriber.put("SupplementaryOffering", SupplementaryOfferingJsonArray);
                            }
                        }
                    }

                    if (QueryCustomerInfoResult.has("Subscriber")) {
                        JSONObject Subscriber = QueryCustomerInfoResult.getJSONObject("Subscriber");

                        if (Subscriber.has("SubscriberInfo")) {
                            JSONObject SubscriberInfo = Subscriber.getJSONObject("SubscriberInfo");

                            if (SubscriberInfo.has("UserCustomer")) {
                                JSONObject UserCustomer = SubscriberInfo.getJSONObject("UserCustomer");

                                if (UserCustomer.has("IndividualInfo")) {
                                    JSONObject IndividualInfo = UserCustomer.getJSONObject("IndividualInfo");

                                    if (IndividualInfo.get("IndividualProperty").getClass().getName().contains("org.json.JSONObject")) {
                                        JSONObject IndividualPropertyObject = IndividualInfo.getJSONObject("IndividualProperty");
                                        JSONArray IndividualPropertyJsonArray = Utils.convertJsonObjectToArray(IndividualPropertyObject);
                                        IndividualInfo.put("IndividualProperty", IndividualPropertyJsonArray);
                                    }
                                }
                            }
                        }
                    }
                    if (QueryCustomerInfoResult.has("Account")) {
                        JSONObject Account = QueryCustomerInfoResult.getJSONObject("Account");

                        if (Account.has("AcctInfo")) {
                            JSONObject AcctInfo = Account.getJSONObject("AcctInfo");

                            if (AcctInfo.has("UserCustomer")) {
                                JSONObject UserCustomer = AcctInfo.getJSONObject("UserCustomer");

                                if (UserCustomer.has("IndividualInfo")) {
                                    JSONObject IndividualInfo = UserCustomer.getJSONObject("IndividualInfo");

                                    if (IndividualInfo.get("IndividualProperty").getClass().getName().contains("org.json.JSONObject")) {
                                        JSONObject IndividualPropertyObject = IndividualInfo.getJSONObject("IndividualProperty");
                                        JSONArray IndividualPropertyJsonArray = Utils.convertJsonObjectToArray(IndividualPropertyObject);
                                        IndividualInfo.put("IndividualProperty", IndividualPropertyJsonArray);
                                    }
                                }
                            }
                        }
                    }

                    if (QueryCustomerInfoResult.has("Customer")) {
                        JSONObject Customer = QueryCustomerInfoResult.getJSONObject("Customer");

                        if (Customer.has("IndividualInfo")) {
                            JSONObject IndividualInfo = Customer.getJSONObject("IndividualInfo");

                            if (IndividualInfo.get("IndividualProperty").getClass().getName().contains("org.json.JSONObject")) {
                                JSONObject IndividualPropertyObject = IndividualInfo.getJSONObject("IndividualProperty");
                                JSONArray IndividualPropertyJsonArray = Utils.convertJsonObjectToArray(IndividualPropertyObject);
                                IndividualInfo.put("IndividualProperty", IndividualPropertyJsonArray);
                            }
                        }
                    }

                }

                return gson.fromJson(String.valueOf(jsonObject), CBSBCCustomerResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found for cbsbcCustomer :: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                log.debug("UNAUTHORIZED for cbsbcCustomer :: " + apiUrl);
                throw new InvalidAccessTokenException();
            } else {
                String body = response.body().string();
                CBSBCCustomerErrorResponse errorResponse = gson.fromJson(body, CBSBCCustomerErrorResponse.class);
                log.error("ERROR Response for cbsbcCustomer :: " + body);
                throw new ApiRequestException(errorResponse.getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("CBSBCCustomer Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("CBSBCCustomer Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("CBSBCCustomer Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("CBSBCCustomer Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }
            log.error("CBSBCCustomer Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    @Retryable(value = { PendingBusinessOrderException.class }, include = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.maxAttempts}" , backoff = @Backoff(delayExpression = "${retry.maxDelay}"))
    public ChangeCorporateGroupMemberInfoResponse changeCorporateGroupMemberInfo(ChangeCorporateGroupMemberInfoRequest groupMemberInfoRequest) {
        String apiUrl = baseUrlEGW + "/HWCRM/ChangeCorporateGroupMemberInformation/v1.0";
        String json = gson.toJson(groupMemberInfoRequest);
        log.debug("ChangeCorporateGroupMemberInfo Request: {} for MSISDN: {}", gson.toJson(groupMemberInfoRequest), groupMemberInfoRequest.getAccessInfo().getObjectId());

        try (Response response = httpClient.post(json, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                ChangeCorporateGroupMemberInfoResponse changeCorporateGroupMemberInfoResponse = gson.fromJson(response.body().string(), ChangeCorporateGroupMemberInfoResponse.class);
                log.debug("ChangeCorporateGroupMemberInfo Response: {} for MSISDN: {}", gson.toJson(changeCorporateGroupMemberInfoResponse), groupMemberInfoRequest.getAccessInfo().getObjectId());

                if (!ObjectUtils.isEmpty(changeCorporateGroupMemberInfoResponse) && changeCorporateGroupMemberInfoResponse.getChangeCorporateGroupMemberInfoRspMsg().getRspHeader().getReturnCode().equals("1211000472")) {
                    throw new PendingBusinessOrderException(changeCorporateGroupMemberInfoResponse.getChangeCorporateGroupMemberInfoRspMsg().getRspHeader().getReturnMsg());
                } else if (!ObjectUtils.isEmpty(changeCorporateGroupMemberInfoResponse) && changeCorporateGroupMemberInfoResponse.getChangeCorporateGroupMemberInfoRspMsg().getRspHeader().getReturnCode().equals("0000")) {
                    return changeCorporateGroupMemberInfoResponse;
                } else {
                    throw new ApiRequestException(changeCorporateGroupMemberInfoResponse.getChangeCorporateGroupMemberInfoRspMsg().getRspHeader().getReturnMsg());
                }
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                log.debug("ChangeCorporateGroupMemberInfo errorResponse: {}", gson.toJson(errorResponse));
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("ChangeCorporateGroupMemberInfo Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("ChangeCorporateGroupMemberInfo Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("ChangeCorporateGroupMemberInfo Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("ChangeCorporateGroupMemberInfo Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            } else if (e instanceof PendingBusinessOrderException) {
                log.debug("ChangeCorporateGroupMemberInfo Pending Business Order for MSISDN: {}", groupMemberInfoRequest.getAccessInfo().getObjectId());
                throw new PendingBusinessOrderException(e.getMessage());
            } else {
                log.error("ChangeCorporateGroupMemberInfo Error: {}", e.getMessage(), e.getCause());
                throw new ApiRequestException(e.getMessage(), e.getCause());
            }
        }
    }


//    public CBSBCCustomerResponse cbsbcCustomer(String msisdn, String bssUsername, String bssPassword) throws UnsupportedEncodingException {
//        String apiUrl = baseUrlIGW + "/api/cbsbc/customers/v1/" + msisdn + "?id_type=msisdn&bss_username=" + bssUsername + "&bss_password=" + Utils.urlEncode(bssPassword);
//
//        try (Response response = httpClient.get(apiUrl, getIGWHeaders())) {
//            assert response.body() != null;
//            if (response.code() == HttpStatus.OK.value()) {
//
//                String responseStr = response.body().string();
//                JSONObject jsonObject = new JSONObject(responseStr);
//
//                if (jsonObject.has("QueryCustomerInfoResult")) {
//                    JSONObject QueryCustomerInfoResult = jsonObject.getJSONObject("QueryCustomerInfoResult");
//
//                    if (QueryCustomerInfoResult.has("Subscriber")) {
//                        JSONObject Subscriber = QueryCustomerInfoResult.getJSONObject("Subscriber");
//
//                        if (Subscriber.has("SupplementaryOffering")) {
//                            if (Subscriber.get("SupplementaryOffering").getClass().getName().contains("org.json.JSONObject")) {
//                                JSONObject SupplementaryOfferingObject = Subscriber.getJSONObject("SupplementaryOffering");
//                                JSONArray SupplementaryOfferingJsonArray = Utils.convertJsonObjectToArray(SupplementaryOfferingObject);
//                                Subscriber.put("SupplementaryOffering", SupplementaryOfferingJsonArray);
//                            }
//                        }
//                    }
//                }
//
//                return gson.fromJson(String.valueOf(jsonObject), CBSBCCustomerResponse.class);
//            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
//                log.debug("Url Not Found: " + apiUrl);
//                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
//            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
//                throw new InvalidAccessTokenException();
//            } else {
//                CBSBCCustomerErrorResponse errorResponse = gson.fromJson(response.body().string(), CBSBCCustomerErrorResponse.class);
//                throw new ApiRequestException(errorResponse.getMessage());
//            }
//        } catch (Exception e) {
//            if (e instanceof ApiRequestException) {
//                log.debug("CBSBCCustomer Api Request Error: {}", e.getMessage());
//                throw new ApiRequestException(e.getMessage());
//            } else if (e instanceof InvalidAccessTokenException) {
//                log.debug("CBSBCCustomer Access Token Error: {}", e.getMessage());
//                throw new InvalidAccessTokenException();
//            } else if (e instanceof InvalidClientCredentialException) {
//                log.debug("CBSBCCustomer Credentials Error: {}", e.getMessage());
//                throw new InvalidClientCredentialException(e.getMessage());
//            }
//            log.error("CBSBCCustomer Error: {}", e.getMessage(), e.getCause());
//            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
//        }
//    }

//    public CBSBCCustomerResponse cbsbcCustomer(String msisdn, String bssUsername, String bssPassword) throws UnsupportedEncodingException {
//        String apiUrl = baseUrlIGW + "/api/cbsbc/customers/v1/"+msisdn+"?id_type=msisdn&bss_username=" + bssUsername + "&bss_password=" + Utils.urlEncode(bssPassword);
//
//        try (Response response = httpClient.get(apiUrl, getIGWHeaders())) {
//            assert response.body() != null;
//            if (response.code() == HttpStatus.OK.value()) {
//                return gson.fromJson(response.body().string(), CBSBCCustomerResponse.class);
//            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
//                log.debug("Url Not Found: " + apiUrl);
//                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
//            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
//                throw new InvalidAccessTokenException();
//            } else {
//                CBSBCCustomerErrorResponse errorResponse = gson.fromJson(response.body().string(), CBSBCCustomerErrorResponse.class);
//                throw new ApiRequestException(errorResponse.getMessage());
//            }
//        } catch (Exception e) {
//            if (e instanceof ApiRequestException) {
//                log.debug("CBSBCCustomer Api Request Error: {}", e.getMessage());
//                throw new ApiRequestException(e.getMessage());
//            } else if (e instanceof InvalidAccessTokenException) {
//                log.debug("CBSBCCustomer Access Token Error: {}", e.getMessage());
//                throw new InvalidAccessTokenException();
//            } else if (e instanceof InvalidClientCredentialException) {
//                log.debug("CBSBCCustomer Credentials Error: {}", e.getMessage());
//                throw new InvalidClientCredentialException(e.getMessage());
//            }
//            log.error("CBSBCCustomer Error: {}", e.getMessage(), e.getCause());
//            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
//        }
//    }

    // Headers
    private Map<String, String> getHeaders() {
        String bearerToken = authorizationGateway.getTokenEGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }

    private Map<String, String> getIGWHeaders() {
        String bearerToken = authorizationGateway.getTokenIGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }
}
