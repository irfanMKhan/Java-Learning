package com.reddot.ecrm.api.payload.response.shared.auth;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.lang.Integer;
import java.lang.String;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuthSuccessResponse implements Serializable {
  private String access_token;

  private String scope;

  private String token_type;

  private Integer expires_in;
}
