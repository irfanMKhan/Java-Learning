package com.reddot.ecrm.dto.agreement.simOrMobile;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;
@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class Sim_Mobile_Template_7 {
    private String monthlyFeeForCorporate_20;
    private String monthlyFeeForCorporate_30;
    private String monthlyFeeForCorporate_50;


    private String freeMonthlyCreditForCorporate_20;
    private String freeMonthlyCreditForCorporate_30;
    private String freeMonthlyCreditForCorporate_50;

    //for all benefit
    private String benefitsOfDataForCorporate_20;
    private String benefitsOfDataForCorporate_30;
    private String benefitsOfDataForCorporate_50;


    private String benefitsOfFreeCallsInSmartMonthlyForCorporate_all;


    private String benefitsOfFreeSMSInSmartMonthlyForCorporate_all;

    private String benefitsOfFreeCUGCallsPerDay;

    private String benefitsOfFreeSpecialNumberForCorporate_20;
    private String benefitsOfFreeSpecialNumberForCorporate_30;
    private String benefitsOfFreeSpecialNumberForCorporate_50;

    private String benefitsOfVASServiceForCorporate_all;

    //for all standards
    private String standardRatesOfClosedUserGroupCallForCorporate_all;

    private String standardRatesOfCallsWithinSmartNetworkForCorporate_all;

    private String standardRatesOfCallsToOtherNetworkForCorporate_all;

    private String standardRatesOfSMSWithinSmartNetworkForCorporate_all;

    private String standardRatesOfSMSToOtherNetworkForCorporate_all;

    private String standardRatesOfSMSToOtherCountriesInTheWorldForCorporate_all;
    private String standardRatesOfMobileNetworkPayuForCorporate_all;

    //for all add on
    private String addOnPackagesMobileInternet_1_GB_packageForCorporate_all;
    private String addOnPackagesMobileInternet_4_GB_packageForCorporate_all;
    private String addOnPackagesMobileInternet_8_GB_packageForCorporate_all;
    private String addOnPackagesMobileInternet_17_GB_packageForCorporate_all;
    private String addOnPackagesMobileInternet_26_GB_packageForCorporate_all;
    private String addOnPackagesMobileInternet_45_GB_packageForCorporate_all;


    //for all add on
    private String depositOfLocalAndInternationalCallsForCorporate_all;
    private String depositOfInternationalRoamingForCorporate_all;

    private String contractTerm;

    private String otherRatesVAS;
    private String otherRatesCallToTheWorld;
    private String contractRoaming;

}
