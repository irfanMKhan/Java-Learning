package com.reddot.ecrm.controller.sr.management;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.controller.sr.notificationMatrix.SRStatusNotifyExecutor;
import com.reddot.ecrm.dto.GlobalSettings.SourceLocation.MDSourceLocationModel;
import com.reddot.ecrm.dto.GlobalSettings.UserPosition.MDUserPositionModel;
import com.reddot.ecrm.dto.GlobalSettings.UserPosition.UserPositionModel;
import com.reddot.ecrm.dto.sr.management.*;
import com.reddot.ecrm.dto.srsettings.QuesMgt.MDSmartScriptQuesListModel;
import com.reddot.ecrm.dto.srsettings.QuesMgt.SrSmartScriptQuesAnsList;
import com.reddot.ecrm.dto.srsettings.QuesMgt.SrSmartSctiptList;
import com.reddot.ecrm.dto.srsettings.RootCause.MDSrRootCauseModel;
import com.reddot.ecrm.dto.srsettings.RoutingGroup.SRRoutingGroupModel;
import com.reddot.ecrm.dto.srsettings.Status.MDSrStatusModel;
import com.reddot.ecrm.dto.srsettings.subarea.MDSrSubAreaModel;
import com.reddot.ecrm.dto.srsettings.subarea.MDSubAreaUpdateViewModel;
import com.reddot.ecrm.exporter.fileExport.GenerateCSV;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.model.lov.CommonLovModel;
import com.reddot.ecrm.remedy.RemedyHelper;
import com.reddot.ecrm.repository.AccountServiceRepository;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.repository.SrTypeRepository;
import com.reddot.ecrm.service.CustomSRDTQueryService;
import com.reddot.ecrm.service.EmailSenderService;
import com.reddot.ecrm.util.QueryBuilder;
import com.reddot.ecrm.util.SendMessage;
import com.reddot.ecrm.util.Utility;
import freemarker.template.Template;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.data.jpa.datatables.mapping.Column;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;

@RestController
//@RequestMapping("sr/management/api")
public class SRManagementAjxController {
    private final Logger logger = LoggerFactory.getLogger("SRSettingsLogger");
    //    ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
    //SrTypeDAO srtypeDAO = (SrTypeDAO) context.getBean("SrTypeDAO");
//    AccountServiceDAO accountserviceDAO = (AccountServiceDAO) context.getBean("AccountServiceDAO");
//    @Value("${soam.customerinfo}")
    String customerinfoUrl;
    //    @Value("${soam.staticTocken}")
    String staticTocken;

    @Autowired
    private AccountServiceRepository accountserviceDAO;

    @Autowired
    private SrTypeRepository srtypeDAO;

    @Autowired
    private SRStatusNotifyExecutor srStatusNotifyExecutor;

    @Autowired
    private FreeMarkerConfigurer freemarkerConfigurer;

    @Autowired
    private EmailSenderService emailSenderService;

    @Autowired
    private RemedyHelper remedyHelper;

    @Autowired
    private SrBulkUpdateService srBulkUpdateService;

    @Autowired
    private SRManagementUpdateService srManagementUpdateService;

    @Autowired
    private SRManagementQueryService srManagementQueryService;

    @Autowired
    private CustomSRDTQueryService customSRDTQueryService;

    @Autowired
    private CommonRepository commonDAO;

    @RequestMapping(value = "/getSRTypeList", method = RequestMethod.GET)
    public SRLoadDataQueryModel getSRTypeList(HttpServletRequest request) {
        return srManagementQueryService.getSRTypeList(request);
    }

    @RequestMapping(value = "/getSRAreaList", method = RequestMethod.POST)
    public List<CommonLovModel> getSRAreaList(@RequestParam("typeID") String searchType) {
        return srManagementQueryService.getSRAreaList(searchType);
    }

    @RequestMapping(value = "/getSRSubAreaList", method = RequestMethod.POST)
    public List<MDSrSubAreaModel> getSRSubAreaList(@RequestParam("srTypeName") String srTypeName,
                                                   @RequestParam("srAreaName") String srAreaName) {
        return srManagementQueryService.getSRSubAreaList(srTypeName, srAreaName);
    }

    @RequestMapping(value = "/getSRSubAreaDetails", method = RequestMethod.POST)
    public MDSubAreaUpdateViewModel getSRSubAreaDetails(@RequestParam("ID") String ID, @RequestParam("accountType") String accountType, @RequestParam("accountClass") String accountClass) {
        return srManagementQueryService.getSRSubAreaDetails(ID, accountType, accountClass);
    }

    @RequestMapping(value = "/getSourceLocation", method = RequestMethod.POST)
    public List<MDSourceLocationModel> getSourceLocation(@RequestParam("SRCID") String searchType) {
        return srManagementQueryService.getSourceLocation(searchType);
    }

    @RequestMapping(value = "/srmanagement/getMsisdnInfo", method = RequestMethod.POST)
    public SRMsisdnInfo getMsisdnInfo(@RequestParam("msisdn") String msisdn) {
        return srManagementQueryService.getMsisdnInfo(msisdn);
    }

    @RequestMapping(value = "/dt/srmanagement/srlist", method = RequestMethod.GET)
    public DataTablesOutput<TBLSRModelDT> getSDPServiceList(@Valid DataTablesInput input, @RequestParam(value = "customQuery", required = false) String customQuery, HttpServletRequest request,
                                                            @RequestParam(value = "customSearchCriteria", required = false) String customSearchCriteria) {
        System.out.println("customQuery Query: " + customQuery);
        System.out.println("customQuery Query Criteria: " + customSearchCriteria);
        if (isColumnSpecificSearch(input.getColumnsAsMap())) {
            customQuery = "";
        }
        if (customSearchCriteria == null) {
            customSearchCriteria = "";
        }
        DataTablesOutput<TBLSRModelDT> srList = customSRDTQueryService.findSrList(input, customQuery, request, logger, customSearchCriteria);
        logger.info("srList: {}", srList);
        return srList;
    }

    @RequestMapping(value = "/dt/srmanagement/srlist", method = RequestMethod.POST)
    public DataTablesOutput<TBLSRModelDT> getSDPServiceListPost(@Valid DataTablesInput input, @RequestParam(value = "customQuery", required = false) String customQuery, HttpServletRequest request,
                                                                @RequestParam(value = "customSearchCriteria", required = false) String customSearchCriteria) {
        if (isColumnSpecificSearch(input.getColumnsAsMap())) {
            customQuery = "";
        }
        if (customSearchCriteria == null) {
            customSearchCriteria = "";
        }
        return customSRDTQueryService.findSrList(input, customQuery, request, logger, customSearchCriteria);
    }

    private boolean isColumnSpecificSearch(Map<String, Column> columnMap) {
        try {
            for (String key : columnMap.keySet()) {
                if (columnMap.get(key).getSearch().getValue() != null && !columnMap.get(key).getSearch().getValue().trim().isEmpty()) {
                    return true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return false;
    }

    @RequestMapping(value = "/sr/createNewSR", method = RequestMethod.POST)
    public CommonRestResponse addNewSR(HttpServletRequest request, @RequestParam("newSRData") String newSRData) {
        return srManagementUpdateService.addNewSR(request, newSRData);
    }

    @RequestMapping(value = "/sms/sendSMS", method = RequestMethod.POST)
    public CommonRestResponse sendSMS(@RequestParam("msisdn") String msisdn, @RequestParam("message") String message, HttpServletRequest request) {
        return srManagementUpdateService.sendSMS(msisdn, message, request);
    }

    @RequestMapping(value = "/sr/getSRBySRNUM", method = RequestMethod.POST)
    public TBLSRModel getSRBySRNUM(@RequestParam("srNum") String srNum, HttpServletRequest request) {
        return srManagementQueryService.getSRBySRNUM(srNum, request);
    }

    private TBLSRModel getSRBySRNUM(String srNum) {

        TBLSRModel tblsrModel = new TBLSRModel();
        try {
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            SearchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");
            SearchData.put("SR_NUM", srNum);
            whereSearchType.put("SR_NUM", "AND");

            String query = QueryBuilder.getSelectWhereQuery(Utility.tbl_sr, SearchData, whereSearchType);
            Object objects = commonDAO.getDataPostgres(query);
            List<TBLSRModel> tblsrModelList = new Gson().fromJson(Utility.ObjectToJson(objects), new TypeToken<List<TBLSRModel>>() {
            }.getType());
            if (tblsrModelList.size() > 0) {
                tblsrModel = tblsrModelList.get(0);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return tblsrModel;
    }

    @RequestMapping(value = "/sr/acceptSR", method = RequestMethod.POST)
    public CommonRestResponse acceptTicket(HttpServletRequest request, @RequestParam("srNum") String srNum) {
        return srManagementUpdateService.acceptTicket(request, srNum);
    }

    @RequestMapping(value = "/sr/getStatusByStatusId", method = RequestMethod.POST)
    public List<MDSrStatusModel> getSRStatusDependent(@RequestParam("statusId") Integer statusId) {
        return srManagementQueryService.getSRStatusDependent(statusId);
    }

    @RequestMapping(value = "/sr/updateSR", method = RequestMethod.POST)
    public CommonRestResponse updateSR(HttpServletRequest request, @RequestParam("srData") String srData) {
        return srManagementUpdateService.updateSR(request, srData);
    }


    @RequestMapping(value = "/sr/getOwnerGroupList", method = RequestMethod.GET)
    public List<SRRoutingGroupModel> getOwnerGroupList() {

        List<SRRoutingGroupModel> list = new ArrayList<>();
        try {
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            SearchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");
            Object listObject = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_routing_group, SearchData, "ID,NAME,OWNER_NAME,OWNER_ID,OWNER_EMAIL", whereSearchType));
            list = new Gson().fromJson(Utility.ObjectToJson(listObject), new TypeToken<List<SRRoutingGroupModel>>() {
            }.getType());
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return list;
    }

    @RequestMapping(value = "/sr/changeOwner", method = RequestMethod.POST)
    public CommonRestResponse changeOwner(@RequestParam("ownerId") Long ownerId,
                                          @RequestParam("srNumber") String srNumber,
                                          @RequestParam("ownerName") String ownerName,
                                          @RequestParam("ownerEmail") String ownerEmail,
                                          @RequestParam("ownerGroupId") Long ownerGroupId,
                                          @RequestParam("ownerGroupName") String ownerGroupName,
                                          @RequestParam("preOwnerId") Long preOwnerId,
                                          @RequestParam("preOwnerName") String preOwnerName,
                                          @RequestParam("preOwnerGroupId") String preOwnerGroupId,
                                          @RequestParam("preOwnerGroupName") String preOwnerGroupName,
                                          @RequestParam("reasonCode") String reasonCode,
                                          @RequestParam("reasonText") String reasonText,
                                          HttpServletRequest request) {
        CommonRestResponse commonRestResponse = new CommonRestResponse();
        try {

            if (ownerGroupId != null && !ownerGroupName.isEmpty() && !reasonCode.isEmpty() && !reasonText.isEmpty()) {
                Map<String, Object> updateData = new HashMap<String, Object>();
                updateData.put("OWNER_GROUP_ID", ownerGroupId);
                updateData.put("OWNER_GROUP_NAME", ownerGroupName);
                updateData.put("OWNER_ID", ownerId);
                updateData.put("OWNER_NAME", ownerName);
                updateData.put("OWNER_EMAIL", ownerEmail);
                updateData.put("UPDATED_BY", Utility.getUserId(request));
                updateData.put("UPDATED_AT", Utility.getCurrentTimestamp());
                updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
                Map<String, Object> whereData = new HashMap<>();
                whereData.put("SR_NUM", Long.parseLong(srNumber));
                TBLSRModel oldSR = getSRBySRNUM(srNumber);
                if (commonDAO.CommoUpdate(Utility.tbl_sr, updateData, whereData, logger)) {
                    commonRestResponse.setCode(200);
                    commonRestResponse.setMessage("Owner Change Successful!");

                    try {
                        Map<String, Object> insertData = new HashMap<>();
                        insertData.put("SR_NUM", srNumber);
                        insertData.put("MSISDN", oldSR.getMSISDN());
                        insertData.put("PRE_OWNER_ID", preOwnerId);
                        insertData.put("PRE_OWNER_NAME", preOwnerName);
                        insertData.put("POST_OWNER_ID", ownerId);
                        insertData.put("POST_OWNER_NAME", ownerName);
//                        insertData.put("PRE_STATUS_ID", preOwnerGroupId);
                        insertData.put("PRE_STATUS_NAME", preOwnerGroupName);
                        insertData.put("POST_STATUS_ID", ownerGroupId);
                        insertData.put("POST_STATUS_NAME", ownerGroupName);
                        insertData.put("OLD_DATA", preOwnerGroupName);
                        insertData.put("NEW_DATA", ownerGroupName);
                        String remarks = "Reason Code :" + reasonCode + ", Reason Text: " + reasonText + ", Owner :" + ownerGroupName;
                        insertData.put("REMARKS", remarks);
                        insertData.put("SR_ACTION_TYPE_NAME", "Owner Changed");
                        insertData.put("CREATED_BY", Utility.getUserId(request));
                        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
                        insertData.put("CREATED_AT", Utility.getCurrentTimestamp());
                        insertData.put("CREATED_AT_DT", Timestamp.valueOf(LocalDateTime.now()));
                        commonDAO.CommoInsert(Utility.tbl_sr_actions, insertData, logger);

                        srStatusNotifyExecutor.notifyChangeOwner(srNumber, logger, ownerId, request);

                    } catch (Exception e) {
                        logger.error(e.getMessage(), e);
                    }
                } else {
                    commonRestResponse.setCode(500);
                    commonRestResponse.setMessage("Owner Change Failed!");
                }
            } else {
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("Owner Change failed!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Error Occurred. Please try later!");
        }
        return commonRestResponse;
    }

    @RequestMapping(value = "/sr/attachmentFileUpload", method = RequestMethod.POST)
    public CommonRestResponse attachmentFileUpload(@RequestParam("file") MultipartFile file,
                                                   @RequestParam("comments") String comments,
                                                   @RequestParam("srNum") String srNum,
                                                   @RequestParam("msisdn") String msisdn,
                                                   HttpServletRequest request) {
        return srManagementUpdateService.attachmentFileUpload(file, comments, srNum, msisdn, request);
    }

    @RequestMapping(value = "/sr/attachmentURLUpload", method = RequestMethod.POST)
    public CommonRestResponse attachmentURLUpload(@RequestParam("url") String url,
                                                  @RequestParam("comments") String comments,
                                                  @RequestParam("srNum") String srNum,
                                                  @RequestParam("msisdn") String msisdn,
                                                  HttpServletRequest request) {
        return srManagementUpdateService.attachmentURLUpload(url, comments, srNum, msisdn, request);
    }

    @RequestMapping(value = "/sr/getAttachmentListForSRNum", method = RequestMethod.GET)
    public List<TBLSRAttachmentModel> getAttachmentListForSRNum(@RequestParam("srNum") String srNum) {

        List<TBLSRAttachmentModel> list = new ArrayList<>();
        try {
            Map<String, Object> searchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            searchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");
            searchData.put("SR_NUM", srNum);
            whereSearchType.put("SR_NUM", "AND");
            Object listObject = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereQuery(Utility.tbl_sr_attachment, searchData, whereSearchType));
            list = new Gson().fromJson(Utility.ObjectToJson(listObject), new TypeToken<List<TBLSRAttachmentModel>>() {
            }.getType());
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return list;
    }

    @RequestMapping(path = "/sr/downloadFileById", method = RequestMethod.GET)
    public ResponseEntity<Resource> downloadFileById(@RequestParam("id") Long id, HttpServletResponse response) throws IOException {
        return srManagementQueryService.downloadFileById(id, response);
    }

    @RequestMapping(value = "/sr/addNote", method = RequestMethod.POST)
    public CommonRestResponse addNote(@RequestParam("noteTypeId") Long noteTypeId,
                                      @RequestParam("noteTypeName") String noteTypeName,
                                      @RequestParam("notes") String notes,
                                      @RequestParam("srNum") String srNum,
                                      @RequestParam("msisdn") String msisdn,
                                      @RequestParam("isNetworkTicket") Integer isNetworkTicket,
                                      HttpServletRequest request) {

        CommonRestResponse commonRestResponse = new CommonRestResponse();
        try {
            Map<String, Object> insertData = new HashMap<String, Object>();
            insertData.put("SR_NUM", srNum);
            insertData.put("MSISDN", msisdn);
            insertData.put("NOTE_TYPE_ID", noteTypeId);
            insertData.put("NOTE_TYPE_NAME", noteTypeName);
            insertData.put("NOTES", Utility.sanitizeInput(notes));
            insertData.put("IS_NETWORK", isNetworkTicket);
            insertData.put("ACTIVE", 1);
            insertData.put("CREATED_BY", Utility.getUserId(request));
            insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
            insertData.put("CREATED_AT", Utility.getCurrentTimestamp());
            insertData.put("CREATED_AT_DT", new Date());
            insertData.put("UPDATED_BY", Utility.getUserId(request));
            insertData.put("UPDATED_AT", Utility.getCurrentTimestamp());
            insertData.put("UPDATED_AT_DT", new Date());
            insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));

            if (commonDAO.CommoInsert(Utility.tbl_sr_notes, insertData, logger)) {
                commonRestResponse.setCode(200);
                commonRestResponse.setMessage("Note addition successful!");
            } else {
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("Note addition failed");
            }
            TBLSRActionModel tblsrActionModel = new TBLSRActionModel();
            tblsrActionModel.setSR_NUM(srNum);
            tblsrActionModel.setMSISDN(msisdn);
            tblsrActionModel.setSR_ACTION_TYPE_NAME("Notes added");
            tblsrActionModel.setREMARKS("Note: " + notes);
            insertSrAction(tblsrActionModel, request);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Error Occurred. Please try later!");
        }
        return commonRestResponse;
    }

    @RequestMapping(value = "/sr/getNoteTypeList", method = RequestMethod.GET)
    public List<TBLSRNotesLovModel> getNoteTypeList() {

        List<TBLSRNotesLovModel> list = new ArrayList<>();
        try {
            Map<String, Object> searchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            searchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");
            searchData.put("TYPE_ID", "1");
            whereSearchType.put("TYPE_ID", "AND");
            Object listObject = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.tbl_sr_notes_lov, searchData, "ID,NAME", whereSearchType));
            list = new Gson().fromJson(Utility.ObjectToJson(listObject), new TypeToken<List<TBLSRNotesLovModel>>() {
            }.getType());
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return list;
    }

    @RequestMapping(value = "/sr/getNoteListForSRNum", method = RequestMethod.GET)
    public List<TBLSRNotesModel> getNoteListForSRNum(@RequestParam("srNum") String srNum) {

        List<TBLSRNotesModel> list = new ArrayList<>();
        try {
            Map<String, Object> searchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            searchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");
            searchData.put("SR_NUM", srNum);
            whereSearchType.put("SR_NUM", "AND");
            Object listObject = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereQuery(Utility.tbl_sr_notes, searchData, whereSearchType));
            list = new Gson().fromJson(Utility.ObjectToJson(listObject), new TypeToken<List<TBLSRNotesModel>>() {
            }.getType());
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return list;
    }

    @RequestMapping(value = "/sr/getActionListForSRNum", method = RequestMethod.GET)
    public List<TBLSRActionModel> getActionListForSRNum(@RequestParam("srNum") String srNum) {

        List<TBLSRActionModel> list = new ArrayList<>();
        try {
            Map<String, Object> searchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            searchData.put("SR_NUM", srNum);
            whereSearchType.put("SR_NUM", "AND");
            Object listObject = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereQuery(Utility.tbl_sr_actions, searchData, whereSearchType));
            list = new Gson().fromJson(Utility.ObjectToJson(listObject), new TypeToken<List<TBLSRActionModel>>() {
            }.getType());
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return list;
    }


    void insertSrAction(TBLSRActionModel tblsrActionModel, HttpServletRequest request) {

        try {
            Map<String, Object> insertData = new HashMap<String, Object>();
            insertData.put("SR_NUM", tblsrActionModel.getSR_NUM());
            insertData.put("MSISDN", tblsrActionModel.getMSISDN());
            insertData.put("REMARKS", tblsrActionModel.getREMARKS());
            insertData.put("SR_ACTION_TYPE_NAME", tblsrActionModel.getSR_ACTION_TYPE_NAME());
            insertData.put("OLD_DATA", tblsrActionModel.getOLD_DATA());
            insertData.put("NEW_DATA", tblsrActionModel.getNEW_DATA());
            insertData.put("CREATED_BY", Utility.getUserId(request));
            insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
            insertData.put("CREATED_AT", Utility.getCurrentTimestamp());
            insertData.put("CREATED_AT_DT", new Date());
            commonDAO.CommoInsert(Utility.tbl_sr_actions, insertData, logger);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
    }


    @RequestMapping(value = "/getSRActivityLov", method = RequestMethod.GET)
    public SRActivityLovQueryModel getSRActivityLov(HttpServletRequest request, @RequestParam("p_id") Integer p_id) {

        List<TBLSRActivityLovModel> srActivityTypeList = new ArrayList<TBLSRActivityLovModel>();
        List<TBLSRActivityLovModel> srActivityPriorityList = new ArrayList<TBLSRActivityLovModel>();
        List<TBLSRActivityLovModel> srActivityStatusList = new ArrayList<TBLSRActivityLovModel>();
        List<TBLSRActivityLovModel> srActivityOutboundList = new ArrayList<TBLSRActivityLovModel>();
        List<TBLSRActivityLovModel> srActivityDisplayList = new ArrayList<TBLSRActivityLovModel>();
        List<TBLSRActivityLovModel> srActivityDurationList = new ArrayList<TBLSRActivityLovModel>();
        List<MDUserPositionModel> srUserPositionList = new ArrayList<MDUserPositionModel>();
        List<UserPositionModel> allUserPositionList = new ArrayList<UserPositionModel>();

        try {
            Map<String, Object> SearchTypeData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            SearchTypeData.put("ACTIVE", "1");
            SearchTypeData.put("TYPE_ID", "1");
            whereSearchType.put("ACTIVE", "AND");
            whereSearchType.put("TYPE_ID", "AND");

            System.out.println(QueryBuilder.getSelectWhereFieldsQuery(Utility.tbl_sr_activity_lov, SearchTypeData, "ID,NAME", whereSearchType));
            Object srActivityType = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.tbl_sr_activity_lov, SearchTypeData, "ID,NAME", whereSearchType));
            srActivityTypeList = new Gson().fromJson(Utility.ObjectToJson(srActivityType), new TypeToken<List<TBLSRActivityLovModel>>() {
            }.getType());


            Map<String, Object> SearchPriorityData = new HashMap<String, Object>();
            SearchPriorityData.put("ACTIVE", 1);
            SearchPriorityData.put("TYPE_ID", 2);

            Object srActivityPriority = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.tbl_sr_activity_lov, SearchPriorityData, "ID,NAME", whereSearchType));
            srActivityPriorityList = new Gson().fromJson(Utility.ObjectToJson(srActivityPriority), new TypeToken<List<TBLSRActivityLovModel>>() {
            }.getType());


            Map<String, Object> SearchStatusData = new HashMap<String, Object>();
            SearchStatusData.put("ACTIVE", 1);
            SearchStatusData.put("TYPE_ID", 3);

            Object srActivityStatus = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.tbl_sr_activity_lov, SearchStatusData, "ID,NAME", whereSearchType));
            srActivityStatusList = new Gson().fromJson(Utility.ObjectToJson(srActivityStatus), new TypeToken<List<TBLSRActivityLovModel>>() {
            }.getType());


            Map<String, Object> SearchOutboundData = new HashMap<String, Object>();
            SearchOutboundData.put("ACTIVE", 1);
            SearchOutboundData.put("TYPE_ID", 4);

            Object srActivityOutbound = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.tbl_sr_activity_lov, SearchOutboundData, "ID,NAME", whereSearchType));
            srActivityOutboundList = new Gson().fromJson(Utility.ObjectToJson(srActivityOutbound), new TypeToken<List<TBLSRActivityLovModel>>() {
            }.getType());

            Map<String, Object> SearchDisplayData = new HashMap<String, Object>();
            SearchDisplayData.put("ACTIVE", 1);
            SearchDisplayData.put("TYPE_ID", 5);

            Object srActivityDisplay = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.tbl_sr_activity_lov, SearchDisplayData, "ID,NAME", whereSearchType));
            srActivityDisplayList = new Gson().fromJson(Utility.ObjectToJson(srActivityDisplay), new TypeToken<List<TBLSRActivityLovModel>>() {
            }.getType());

            Map<String, Object> SearchDurationData = new HashMap<String, Object>();
            SearchDurationData.put("ACTIVE", 1);
            SearchDurationData.put("TYPE_ID", 6);

            Object srActivityDuration = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.tbl_sr_activity_lov, SearchDurationData, "ID,NAME", whereSearchType));
            srActivityDurationList = new Gson().fromJson(Utility.ObjectToJson(srActivityDuration), new TypeToken<List<TBLSRActivityLovModel>>() {
            }.getType());

            Map<String, Object> SearchPositionData = new HashMap<String, Object>();
            Map<String, Object> wherePositionType = new HashMap<String, Object>();
            SearchPositionData.put("ID", p_id);
            SearchPositionData.put("ACTIVE", "1");

            wherePositionType.put("ID", "AND");
            wherePositionType.put("ACTIVE", "AND");

            Object srUserPosition = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_user_position, SearchPositionData, "ID,NAME,GROUP_EMAIL,OWNER_ID,OWNER_NAME,OWNER_EMAIL", wherePositionType));
            srUserPositionList = new Gson().fromJson(Utility.ObjectToJson(srUserPosition), new TypeToken<List<MDUserPositionModel>>() {
            }.getType());


//            String qry = "SELECT  U.ID AS USER_ID,U.LOGIN_NAME,U.EMAIL,U.NAME,U.WORK_PHONE,P.ID AS OWNER_GROUP_ID,P.NAME AS OWNER_GROUP_NAME,P.GROUP_EMAIL AS OWNER_GROUP_EMAIL,P.OWNER_ID,P.OWNER_NAME,P.OWNER_EMAIL FROM MD_USER U LEFT JOIN MD_USER_POSITION P ON U.POSITION_ID=P.ID WHERE POSITION_ID IS NOT NULL";
//            String qry = "SELECT  U.ID AS USER_ID,U.LOGIN_NAME,'' AS EMAIL, U.NAME,U.WORK_PHONE,P.ID AS OWNER_GROUP_ID,P.NAME AS OWNER_GROUP_NAME,P.OWNER_ID,P.OWNER_NAME FROM MD_USER U LEFT JOIN MD_USER_POSITION P ON U.POSITION_ID=P.ID WHERE POSITION_ID IS NOT NULL";
            String qry = "SELECT  U.ID AS USER_ID,U.LOGIN_NAME,'' AS EMAIL, U.NAME,U.WORK_PHONE,P.ID AS OWNER_GROUP_ID,P.NAME AS OWNER_GROUP_NAME,P.OWNER_ID,P.OWNER_NAME FROM MD_USER U LEFT JOIN MD_USER_POSITION P ON U.POSITION_ID=P.ID WHERE U.POSITION_ID IS NOT NULL AND U.CAN_ASSIGN_ACTIVITY=1";
            logger.info(qry);
            System.out.println(qry);

            Object allUserPosition = commonDAO.getDataPostgres(qry);
            allUserPositionList = new Gson().fromJson(Utility.ObjectToJson(allUserPosition), new TypeToken<List<UserPositionModel>>() {
            }.getType());


        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return new SRActivityLovQueryModel(srActivityTypeList, srActivityPriorityList, srActivityStatusList, srActivityOutboundList, srActivityDisplayList, srActivityDurationList, srUserPositionList, allUserPositionList);
    }


    @RequestMapping(value = "/sr/createNewActivity", method = RequestMethod.POST)
    public CommonRestResponse addNewActivity(HttpServletRequest request, @RequestParam("newSRActivityData") String newSRActivityData) {
        System.out.println("New SR Activity data posted: " + newSRActivityData);

        CommonRestResponse commonRestResponse = new CommonRestResponse();
        try {

            TBLSRActivityModel newSR = new Gson().fromJson(newSRActivityData, new TypeToken<TBLSRActivityModel>() {
            }.getType());

            System.out.println("MSISDN: " + newSR.getMSISDN());
            Long curTimeST = Utility.getCurrentTimestamp();

            String activityNumber = commonDAO.getNextIdPostgres(Utility.seq_name_tbl_activity);

            Map<String, Object> insertData = new HashMap<>();
            insertData.put("SR_ID", newSR.getSR_ID());
            insertData.put("SR_NUM", newSR.getSR_NUM());

            insertData.put("MSISDN", newSR.getMSISDN());
            insertData.put("SEQUENCE", newSR.getSEQUENCE());
            insertData.put("ACTIVITY_NUM", activityNumber);

            insertData.put("ACTIVITY_TYPE_ID", newSR.getACTIVITY_TYPE_ID());
            insertData.put("ACTIVITY_TYPE_NAME", newSR.getACTIVITY_TYPE_NAME());
            insertData.put("DESCRIPTION", newSR.getDESCRIPTION());
            insertData.put("OWNER_ID", newSR.getOWNER_ID());
            insertData.put("OWNER_NAME", newSR.getOWNER_NAME());
            insertData.put("OWNER_GROUP_ID", newSR.getOWNER_GROUP_ID());
            insertData.put("OWNER_GROUP_NAME", newSR.getOWNER_GROUP_NAME());
            insertData.put("STATUS_ID", newSR.getSTATUS_ID());
            insertData.put("STATUS_NAME", newSR.getSTATUS_NAME());
            insertData.put("COMMENTS", newSR.getCOMMENTS());

            insertData.put("OUTBOUND_CALL_STATUS_ID", newSR.getOUTBOUND_CALL_STATUS_ID());
            insertData.put("OUTBOUND_CALL_STATUS_NAME", newSR.getOUTBOUND_CALL_STATUS_NAME());
            insertData.put("DURATION", newSR.getDURATION());
            insertData.put("PRIORITY_ID", newSR.getPRIORITY_ID());
            insertData.put("PRIORITY_NAME", newSR.getPRIORITY_NAME());
            insertData.put("IS_ESCALATED", newSR.getIS_ESCALATED());
            insertData.put("CALL_DURATION", newSR.getCALL_DURATION());
            insertData.put("CHANGE_REQUEST", newSR.getCHANGE_REQUEST());
            insertData.put("PERCENT_COMPLETE", newSR.getPERCENT_COMPLETE());
            insertData.put("IS_REPEAT", newSR.getIS_REPEAT());
            insertData.put("ACTIVE", 1);


            insertData.put("CREATED_BY", Utility.getUserId(request));
            insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
            insertData.put("UPDATED_BY", Utility.getUserId(request));
            insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
            insertData.put("PLAN_START", newSR.getPLAN_START());
            insertData.put("PLAN_END", newSR.getPLAN_END());
            insertData.put("DUE_AT", newSR.getDUE_AT());
            insertData.put("CREATED_AT", curTimeST);
            insertData.put("UPDATED_AT", curTimeST);
            insertData.put("ACTUAL_START", curTimeST);

            Timestamp timestamp = Timestamp.valueOf(LocalDateTime.now());
            insertData.put("DUE_DT", newSR.getDUE_DT());
            insertData.put("CREATED_AT_DT", timestamp);
            insertData.put("UPDATED_AT_DT", timestamp);
            insertData.put("DISPLAYIN_ID", newSR.getDISPLAYIN_ID());
            insertData.put("DISPLAYIN_NAME", newSR.getDISPLAYIN_NAME());
            insertData.put("OPPORTUNITY", newSR.getOPPORTUNITY());


            if (commonDAO.CommoInsert(Utility.tbl_sr_activity, insertData, logger)) {
                //srStatusNotifyExecutor.execute(newSR);
                commonRestResponse.setCode(200);
                commonRestResponse.setMessage("Activity Created Successfully");

                try {
                    String severity = "";
                    TBLSRModel tblsrModel = getSRBySRNUM(newSR.getSR_NUM());
                    if (tblsrModel.getSEVERITY_NAME() != null && !tblsrModel.getSEVERITY_NAME().isEmpty()) {
                        severity = "\nSeverity: " + tblsrModel.getSEVERITY_NAME() + "\n";
                    }
                    if (newSR.getOWNER_MSISDN() != null && !newSR.getOWNER_MSISDN().isEmpty()) {
                        new SendMessage().send(newSR.getOWNER_MSISDN(),
                                "Dear " + (newSR.getOWNER_NAME() == null ? "Sir/Madam" : newSR.getOWNER_NAME()) + ", \nGreetings from Robi. Activity no. is " + activityNumber + " " +
                                        severity +
                                        "is assigned to you, request you to please look into it.", "SR", request);
                    }

                    try {
                        String emailQuery = "SELECT ID, EMAIL AS NAME FROM " + Utility.md_user + " WHERE LOGIN_NAME='" + newSR.getOWNER_NAME() + "'";
                        Object ownerObjects = commonDAO.getDataPostgres(emailQuery);
                        List<CommonLovModel> emails = new Gson().fromJson(Utility.ObjectToJson(ownerObjects), new TypeToken<List<CommonLovModel>>() {
                        }.getType());
                        if (!emails.isEmpty()) {
                            newSR.setOWNER_EMAIL(emails.get(0).getNAME());
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        logger.error(e.getMessage(), e);
                    }

                    if (newSR.getOWNER_EMAIL() != null && !newSR.getOWNER_EMAIL().isEmpty()) {
                        Map<String, Object> templateModel = new HashMap<>();
                        templateModel.put("userFullName", newSR.getOWNER_NAME() == null ? "" : newSR.getOWNER_NAME());
                        templateModel.put("activityNum", activityNumber);
                        templateModel.put("activityDescription", newSR.getDESCRIPTION() == null ? "" : newSR.getDESCRIPTION());
                        templateModel.put("loginName", newSR.getOWNER_NAME() == null ? "" : newSR.getOWNER_NAME());
                        templateModel.put("ownerGroupName", newSR.getOWNER_GROUP_NAME() == null ? "" : newSR.getOWNER_GROUP_NAME());
                        templateModel.put("activityType", newSR.getACTIVITY_TYPE_NAME() == null ? "" : newSR.getACTIVITY_TYPE_NAME());
                        templateModel.put("activityStatus", newSR.getSTATUS_NAME() == null ? "" : newSR.getSTATUS_NAME());
                        templateModel.put("completedDate", newSR.getCOMPLETED_AT() == null ? "" : newSR.getCOMPLETED_AT_FT());
                        templateModel.put("srNumber", newSR.getSR_NUM() == null ? "" : newSR.getSR_NUM());
                        templateModel.put("comments", newSR.getCOMMENTS() == null ? "" : newSR.getCOMMENTS());
                        templateModel.put("severityName", tblsrModel.getSEVERITY_NAME() == null ? "" : tblsrModel.getSEVERITY_NAME());

                        Template freemarkerTemplate = freemarkerConfigurer.createConfiguration()
                                .getTemplate("activityEmail.ftl");
                        String htmlBody = FreeMarkerTemplateUtils.processTemplateIntoString(freemarkerTemplate, templateModel);
                        emailSenderService.sendEmail(newSR.getOWNER_EMAIL(), htmlBody, "Activity no. " + activityNumber + " assigned to you");
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    logger.error(e.getMessage(), e);
                }

                TBLSRActionModel tblsrActionModel = new TBLSRActionModel();
                tblsrActionModel.setSR_NUM(newSR.getSR_NUM());
                tblsrActionModel.setMSISDN(newSR.getMSISDN().toString());
                tblsrActionModel.setSR_ACTION_TYPE_NAME("Activity Created");
                tblsrActionModel.setREMARKS("Activity Created");
                insertSrAction(tblsrActionModel, request);
            } else {
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("Activity Creation failed");
            }

        } catch (Exception e) {
            e.printStackTrace();
            logger.error("addNewAddress Error");
            logger.error(e.getMessage(), e);
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Error Occurred. Please try later");
        }

        return commonRestResponse;
    }

    @RequestMapping(value = "/sr/getActivityListForSRNum", method = RequestMethod.GET)
    public List<TBLSRActivityModel> getActivityListForSRNum(@RequestParam("srNum") String srNum) {

        List<TBLSRActivityModel> list = new ArrayList<>();
        System.out.println("srNum::" + srNum);
        try {
            Map<String, Object> searchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            searchData.put("SR_NUM", srNum);
            whereSearchType.put("SR_NUM", "AND");
            Object listObject = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereQuery(Utility.tbl_sr_activity, searchData, whereSearchType));
            list = new Gson().fromJson(Utility.ObjectToJson(listObject), new TypeToken<List<TBLSRActivityModel>>() {
            }.getType());

            System.out.println("list::" + list);
            System.out.println(QueryBuilder.getSelectWhereQuery(Utility.tbl_sr_activity, searchData, whereSearchType));

        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return list;
    }

    @RequestMapping(value = "/sr/getSRActivityID", method = RequestMethod.POST)
    public TBLSRActivityModel getSRActivityID(@RequestParam("srNum") String srNum,
                                              @RequestParam("activityId") Long activityId,
                                              HttpServletRequest request) {

        TBLSRActivityModel tblActivityModel = new TBLSRActivityModel();
        Long srNumVal = Long.valueOf(srNum);
        try {
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            SearchData.put("ID", activityId);
            whereSearchType.put("ID", "AND");
            SearchData.put("SR_NUM", srNumVal);
            whereSearchType.put("SR_NUM", "AND");

            String query = QueryBuilder.getSelectWhereQuery(Utility.tbl_sr_activity, SearchData, whereSearchType);
            Object objects = commonDAO.getDataPostgres(query);
            List<TBLSRActivityModel> tblActivityModelList = new Gson().fromJson(Utility.ObjectToJson(objects), new TypeToken<List<TBLSRActivityModel>>() {
            }.getType());
            if (tblActivityModelList.size() > 0) {
                tblActivityModel = tblActivityModelList.get(0);
            }

            String srSelectQuery = "SELECT ID, SR_NUM, SR_STATUS_ID, SR_STATUS_NAME FROM " + Utility.tbl_sr + " WHERE SR_NUM='" + srNum + "'";
            Object srObjects = commonDAO.getDataPostgres(srSelectQuery);
            List<TBLSRModel> srList = new Gson().fromJson(Utility.ObjectToJson(srObjects), new TypeToken<List<TBLSRModel>>() {
            }.getType());
            if (srList.size() > 0) {
                tblActivityModel.setSR_STATUS_ID(srList.get(0).getSR_STATUS_ID());
                tblActivityModel.setSR_STATUS_TEXT(srList.get(0).getSR_STATUS_NAME());
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return tblActivityModel;
    }


    @RequestMapping(value = "/sr/updateActivity", method = RequestMethod.POST)
    public CommonRestResponse updateActivity(HttpServletRequest request, @RequestParam("activityData") String activityData) {
        System.out.println("Up Activity body: " + activityData);

        CommonRestResponse commonRestResponse = new CommonRestResponse();
        try {
            TBLSRActivityModel newSR = new Gson().fromJson(activityData, new TypeToken<TBLSRActivityModel>() {
            }.getType());

            Map<String, Object> updateData = new HashMap<String, Object>();

            Long curTimeSt = Utility.getCurrentTimestamp();
            Long srNumVal = Long.valueOf(newSR.getSR_NUM());
            System.out.println("getSR_NUM: " + newSR.getSR_NUM());
            System.out.println("srNumVal: " + srNumVal);
            updateData.put("SEQUENCE", newSR.getSEQUENCE());
            updateData.put("ACTIVITY_TYPE_ID", newSR.getACTIVITY_TYPE_ID());
            updateData.put("ACTIVITY_TYPE_NAME", newSR.getACTIVITY_TYPE_NAME());
            updateData.put("DESCRIPTION", newSR.getDESCRIPTION());
            updateData.put("OWNER_ID", newSR.getOWNER_ID());
            updateData.put("OWNER_NAME", newSR.getOWNER_NAME());
            updateData.put("OWNER_GROUP_ID", newSR.getOWNER_GROUP_ID());
            updateData.put("OWNER_GROUP_NAME", newSR.getOWNER_GROUP_NAME());
            updateData.put("STATUS_ID", newSR.getSTATUS_ID());
            updateData.put("STATUS_NAME", newSR.getSTATUS_NAME());
            updateData.put("COMMENTS", newSR.getCOMMENTS());

            updateData.put("OUTBOUND_CALL_STATUS_ID", newSR.getOUTBOUND_CALL_STATUS_ID());
            updateData.put("OUTBOUND_CALL_STATUS_NAME", newSR.getOUTBOUND_CALL_STATUS_NAME());
            updateData.put("DURATION", newSR.getDURATION());
            updateData.put("PRIORITY_ID", newSR.getPRIORITY_ID());
            updateData.put("PRIORITY_NAME", newSR.getPRIORITY_NAME());
            updateData.put("IS_ESCALATED", newSR.getIS_ESCALATED());
            updateData.put("CALL_DURATION", newSR.getCALL_DURATION());
            updateData.put("CHANGE_REQUEST", newSR.getCHANGE_REQUEST());
            updateData.put("PERCENT_COMPLETE", newSR.getPERCENT_COMPLETE());
            updateData.put("IS_REPEAT", newSR.getIS_REPEAT());
            updateData.put("ACTIVE", 1);

            updateData.put("UPDATED_BY", Utility.getUserId(request));
            updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
            updateData.put("PLAN_START", newSR.getPLAN_START());
            updateData.put("PLAN_END", newSR.getPLAN_END());
            updateData.put("DUE_AT", newSR.getDUE_AT());
            updateData.put("UPDATED_AT", curTimeSt);

            updateData.put("DUE_DT", newSR.getDUE_DT());
            updateData.put("UPDATED_AT_DT", new Date());
            updateData.put("DISPLAYIN_ID", newSR.getDISPLAYIN_ID());
            updateData.put("DISPLAYIN_NAME", newSR.getDISPLAYIN_NAME());
            updateData.put("OPPORTUNITY", newSR.getOPPORTUNITY());

            if (newSR.getSTATUS_ID() != null && newSR.getSTATUS_ID() == 61) {
                updateData.put("COMPLETED_AT", curTimeSt);
                updateData.put("COMPLETED_DT", new Date());
                updateData.put("SOLVED_BY_USERNAME", Utility.getLoginName(request));
                updateData.put("SOLVED_AT", curTimeSt);
                updateData.put("SOLVED_AT_DT", new Date());
            }


            Map<String, Object> whereData = new HashMap<String, Object>();
            whereData.put("ID", newSR.getID());

            if (commonDAO.CommoUpdate(Utility.tbl_sr_activity, updateData, whereData, logger)) {
                commonRestResponse.setCode(200);
                commonRestResponse.setMessage("Update Successful!");
            } else {
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("Update Failed!");
            }

            if (newSR.getSTATUS_ID() != null && newSR.getSTATUS_ID() == 61) {
                TBLSRActionModel tblsrActionModel = new TBLSRActionModel();
                tblsrActionModel.setSR_NUM(newSR.getSR_NUM());
                tblsrActionModel.setMSISDN(newSR.getMSISDN().toString());
                tblsrActionModel.setSR_ACTION_TYPE_NAME("Updated");
                tblsrActionModel.setREMARKS("Activity Completed");
                insertSrAction(tblsrActionModel, request);
            } else {
                TBLSRActionModel tblsrActionModel = new TBLSRActionModel();
                tblsrActionModel.setSR_NUM(newSR.getSR_NUM());
                tblsrActionModel.setMSISDN(newSR.getMSISDN().toString());
                tblsrActionModel.setSR_ACTION_TYPE_NAME("Activity Updated");
                tblsrActionModel.setREMARKS("Activity Updated");
                insertSrAction(tblsrActionModel, request);
            }


        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Error Occurred. Please try later");
        }

        return commonRestResponse;
    }

    @RequestMapping(value = "/downloadSRInFile", method = RequestMethod.GET)
    public void getServiceTypeListCsv(HttpServletResponse response, HttpServletRequest request, @RequestParam("fileType") String fileType, @RequestParam("rowSpec") String rowSpec,
                                      @RequestParam("srNum") String srNum) {
        srManagementQueryService.downloadSrInFile(response, request, fileType, rowSpec, srNum);
    }

    private String getDuration(TBLSRModel tblsrModel) {
        String duration = "";
        double hourFrac = 0;
        DecimalFormat df = new DecimalFormat("#.##");
        try {
            if (tblsrModel.getSUBMITTED_AT() == null || tblsrModel.getSUBMITTED_AT() <= 0) {
                return duration;
            } else if (tblsrModel.getSLA_STOP_TIME() != null && tblsrModel.getSLA_STOP_TIME() > 0) {
                hourFrac = (tblsrModel.getSLA_STOP_TIME() - tblsrModel.getSUBMITTED_AT()) / 3600000.0;
                duration = df.format(hourFrac);
            } else {
                hourFrac = (System.currentTimeMillis() - tblsrModel.getSUBMITTED_AT()) / 3600000.0;
                duration = df.format(hourFrac);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return duration;
    }

    private String getFormattedYesNo(Integer value) {
        if (value != null && value == 1) {
            return "Y";
        } else {
            return "N";
        }
    }

    @GetMapping("/testOwnerEmail")
    public String testOwnerEmail() {
        MDSrSubAreaModel mdSrSubAreaModel = new MDSrSubAreaModel();
        mdSrSubAreaModel.setOWNER_NAME("SAMIM.REZA");
        mdSrSubAreaModel.setOWNER_EMAIL("samim.reza@smart.com.kh");
        srStatusNotifyExecutor.notifyOwnerOverEmail("", mdSrSubAreaModel, logger);
        return "success";
    }

    private void generateSRListExcel(String[] headers, List<Map<String, Object>> mapList, HttpServletResponse response, String[] columnTitles) {
        try {
            response.setContentType("application/octet-stream");
            SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyyHHmmss");
            String filename = "SR_LIST_" + dateFormat.format(new Date()) + ".xlsx";
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");


            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("SR List");

            Row row = sheet.createRow(0);
            CellStyle headerCellStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerCellStyle.setFont(headerFont);
            DataFormat dataFormat = workbook.createDataFormat();
            headerCellStyle.setDataFormat(dataFormat.getFormat("@"));
            for (int i = 0; i < columnTitles.length; i++) {
                Cell cell = row.createCell(i);
                cell.setCellValue(columnTitles[i]);
                cell.setCellStyle(headerCellStyle);
                sheet.autoSizeColumn(i);
            }

            CellStyle childCellStyle = workbook.createCellStyle();
            childCellStyle.setDataFormat(dataFormat.getFormat("@"));
            for (int i = 0; i < mapList.size(); i++) {
                Row cellRow = sheet.createRow(i + 1);
                for (int j = 0; j < headers.length; j++) {
                    Cell cell = cellRow.createCell(j);
                    Object cellValue = mapList.get(i).get(headers[j]);
                    if (cellValue != null && !cellValue.toString().isEmpty()) {
                        cell.setCellValue(mapList.get(i).get(headers[j]).toString());
                    }
                    cell.setCellStyle(childCellStyle);
                    sheet.autoSizeColumn(j);
                }
            }

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            ByteArrayInputStream stream = new ByteArrayInputStream(outputStream.toByteArray());
            IOUtils.copy(stream, response.getOutputStream());
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
    }

    private void generateActivityListExcel(String[] headers, List<Map<String, Object>> mapList, HttpServletResponse response, String[] columnTitles) {
        try {
            response.setContentType("application/octet-stream");
            SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyyHHmmss");
            String filename = "ACTIVITY_LIST_" + dateFormat.format(new Date()) + ".xlsx";
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");


            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("Activity List");

            Row row = sheet.createRow(0);
            CellStyle headerCellStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerCellStyle.setFont(headerFont);
            DataFormat dataFormat = workbook.createDataFormat();
            headerCellStyle.setDataFormat(dataFormat.getFormat("@"));
            for (int i = 0; i < columnTitles.length; i++) {
                Cell cell = row.createCell(i);
                cell.setCellValue(columnTitles[i]);
                cell.setCellStyle(headerCellStyle);
                sheet.autoSizeColumn(i);
            }

            CellStyle childCellStyle = workbook.createCellStyle();
            childCellStyle.setDataFormat(dataFormat.getFormat("@"));
            for (int i = 0; i < mapList.size(); i++) {
                Row cellRow = sheet.createRow(i + 1);
                for (int j = 0; j < headers.length; j++) {
                    Cell cell = cellRow.createCell(j);
                    Object cellValue = mapList.get(i).get(headers[j]);
                    if (cellValue != null && !cellValue.toString().isEmpty()) {
                        cell.setCellValue(mapList.get(i).get(headers[j]).toString());
                    }
                    cell.setCellStyle(childCellStyle);
                    sheet.autoSizeColumn(j);
                }
            }

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            ByteArrayInputStream stream = new ByteArrayInputStream(outputStream.toByteArray());
            IOUtils.copy(stream, response.getOutputStream());
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
    }

    private void generateSRListCSV(HttpServletResponse response, List<Map<String, Object>> mapList, String[] headers, String[] columnTitles) {
        try {

            SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyyHHmmss");
            String filename = "SR_LIST_" + dateFormat.format(new Date()) + ".csv";
            response.setContentType("text/csv");
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");
            GenerateCSV.writeApacheCSVtoResponse(response.getWriter(), mapList, logger, headers, columnTitles);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
    }

    private void generateActivityListCSV(HttpServletResponse response, List<Map<String, Object>> mapList, String[] headers, String[] columnTitles) {
        try {

            SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyyHHmmss");
            String filename = "ACTIVITY_LIST_" + dateFormat.format(new Date()) + ".csv";
            response.setContentType("text/csv");
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");

            GenerateCSV.writeCSVtoResponse(response.getWriter(), mapList, logger, headers, columnTitles);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
    }

    @RequestMapping(value = "/downloadActivityInFile", method = RequestMethod.GET)
    public void downloadActivityInFile(HttpServletResponse response, HttpServletRequest request, @RequestParam("fileType") String fileType, @RequestParam("rowSpec") String rowSpec,
                                       @RequestParam("activityNumber") String activityNumber) {
//        List<TBLSRActivityModel> activityList = new ArrayList<>();
//        
        try {
            /*String query = "SELECT * FROM " + Utility.tbl_sr_activity + " " + SessionManager.getAttribute(SessionConstants.ACTIVITY_LAST_QUERY.name(), request) + " OFFSET 0 ROWS FETCH NEXT 10000 ROWS ONLY";
             *//*if (rowSpec != null && !rowSpec.isEmpty() && rowSpec.equalsIgnoreCase("onlyCurrentRow") && activityNumber != null && !activityNumber.isEmpty()) {
                query = "SELECT * FROM " + Utility.tbl_sr_activity + " WHERE AND ACTIVITY_NUM='" + activityNumber + "'";
            } else *//*
            if (rowSpec != null && !rowSpec.isEmpty() && rowSpec.equalsIgnoreCase("onlyVisibleRow")) {
                query = "SELECT * FROM " + Utility.tbl_sr_activity + " " + SessionManager.getAttribute(SessionConstants.ACTIVITY_LAST_QUERY.name(), request) + SessionManager.getAttribute(SessionConstants.ACTIVITY_LAST_QUERY_PAGINATION.name(), request);
            }
            logger.info("Export query: " + query);
            Object listObject = commonDAO.getDataPostgres(query);
            activityList = new Gson().fromJson(Utility.ObjectToJson(listObject), new TypeToken<List<TBLSRActivityModel>>() {
            }.getType());

            String[] columnTitles = {"SR#", "Sequence", "Activity#", "Type", "Description",
                    "Owner", "Owner Group Name", "Status", "Comments", "Outbound Call",
                    "Planned Start", "Planned End", "Actual Start", "Completed Date", "Due", "Priority", "Escalated",
                    "Call Duration", "Change Request#", "Complete(%)", "Repeat"};

            String[] headers = {"SR_NUM", "SEQUENCE", "ACTIVITY_NUM", "ACTIVITY_TYPE_NAME", "DESCRIPTION",
                    "OWNER_NAME", "OWNER_GROUP_NAME", "STATUS_NAME", "COMMENTS", "OUTBOUND_CALL_STATUS_NAME",
                    "PLAN_START", "PLAN_END", "ACTUAL_START", "COMPLETED_AT", "DUE_AT", "PRIORITY_NAME", "IS_ESCALATED",
                    "CALL_DURATION", "CHANGE_REQUEST", "PERCENT_COMPLETE", "IS_REPEAT"};

            List<Map<String, Object>> mapList = new ArrayList<>();
            for (TBLSRActivityModel tblsrActivityModel : activityList) {
                HashMap<String, Object> hashMap = new HashMap<>();
                hashMap.put("SR_NUM", tblsrActivityModel.getSR_NUM());
                hashMap.put("SEQUENCE", tblsrActivityModel.getSEQUENCE());
                hashMap.put("ACTIVITY_NUM", tblsrActivityModel.getACTIVITY_NUM());
                hashMap.put("ACTIVITY_TYPE_NAME", tblsrActivityModel.getACTIVITY_TYPE_NAME());
                hashMap.put("DESCRIPTION", tblsrActivityModel.getDESCRIPTION());
                hashMap.put("OWNER_NAME", tblsrActivityModel.getOWNER_NAME());
                hashMap.put("OWNER_GROUP_NAME", tblsrActivityModel.getOWNER_GROUP_NAME());
                hashMap.put("STATUS_NAME", tblsrActivityModel.getSTATUS_NAME());
                hashMap.put("COMMENTS", tblsrActivityModel.getCOMMENTS());
                hashMap.put("OUTBOUND_CALL_STATUS_NAME", tblsrActivityModel.getOUTBOUND_CALL_STATUS_NAME());
                hashMap.put("PLAN_START", tblsrActivityModel.getPLAN_START_FT());
                hashMap.put("PLAN_END", tblsrActivityModel.getPLAN_END_FT());
                hashMap.put("ACTUAL_START", tblsrActivityModel.getACTUAL_START_FT());
                hashMap.put("COMPLETED_AT", tblsrActivityModel.getCOMPLETED_AT_FT());
                hashMap.put("DUE_AT", tblsrActivityModel.getDUE_AT_FT());
                hashMap.put("PRIORITY_NAME", tblsrActivityModel.getPRIORITY_NAME());
                hashMap.put("IS_ESCALATED", tblsrActivityModel.getIS_ESCALATED());
                hashMap.put("CALL_DURATION", tblsrActivityModel.getCALL_DURATION());
                hashMap.put("CHANGE_REQUEST", tblsrActivityModel.getCHANGE_REQUEST());
                hashMap.put("PERCENT_COMPLETE", tblsrActivityModel.getPERCENT_COMPLETE());
                hashMap.put("IS_REPEAT", tblsrActivityModel.getIS_REPEAT());
                mapList.add(hashMap);
            }

            if (fileType.equalsIgnoreCase("csv"))
                generateActivityListCSV(response, mapList, headers, columnTitles);
            else if (fileType.equalsIgnoreCase("excel"))
                generateActivityListExcel(headers, mapList, response, columnTitles);*/
            srManagementQueryService.downloadActivityInFile(response, request, fileType, rowSpec, activityNumber);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
    }

    @RequestMapping(value = "/getSRRootCauseList", method = RequestMethod.GET)
    public List<MDSrRootCauseModel> getSRRootCauseList() {
        List<MDSrRootCauseModel> causeList = new ArrayList<MDSrRootCauseModel>();

        try {
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            SearchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");
            String qry = QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_root_cause, SearchData, "ID,NAME", whereSearchType);
            logger.info(qry);
            System.out.println(qry);
            Object rc = commonDAO.getDataPostgres(qry);
            causeList = new Gson().fromJson(Utility.ObjectToJson(rc), new TypeToken<List<MDSrRootCauseModel>>() {
            }.getType());

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return causeList;
    }

    @RequestMapping(value = "/getCustomQueryLovList", method = RequestMethod.GET)
    public SRCustomQueryLovModel getCustomQueryLovList() {
        return srManagementQueryService.getCustomQueryLovList();
    }


    @RequestMapping(value = "/getChangeOwnerCodeList", method = RequestMethod.GET)
    public List<TBLSRNotesLovModel> getChangeOwnerCodeList() {

        List<TBLSRNotesLovModel> codeList = new ArrayList<TBLSRNotesLovModel>();
        try {
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            SearchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");
            SearchData.put("TYPE_ID", "2");
            whereSearchType.put("TYPE_ID", "AND");
            String qry = QueryBuilder.getSelectWhereFieldsQuery(Utility.tbl_sr_notes_lov, SearchData, "ID,NAME", whereSearchType);
            logger.info(qry);
            System.out.println(qry);
            Object rc = commonDAO.getDataPostgres(qry);
            codeList = new Gson().fromJson(Utility.ObjectToJson(rc), new TypeToken<List<TBLSRNotesLovModel>>() {
            }.getType());
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return codeList;
    }

    @RequestMapping(value = "/save_smart_script", method = RequestMethod.POST)
    public CommonRestResponse saveSmartScript(HttpServletRequest request, @RequestParam("formData") String formData, @RequestParam("srNumberforSS") String srNumberforSS, @RequestParam("msisdn") String customerMsisdn, @RequestParam("partDetection") String partDetection, @RequestParam("subarea") Integer subarea, @RequestParam("quesOriData") String quesOriData) {
        CommonRestResponse commonRestResponse = new CommonRestResponse();
        SrSmartSctiptList empList = new SrSmartSctiptList();
        List<SrSmartSctiptList> resList = new Gson().fromJson(formData, new TypeToken<List<SrSmartSctiptList>>() {
        }.getType());

        System.out.println("Form Data:" + Utility.ObjectToJson(resList));

        List<MDSmartScriptQuesListModel> quesOriList = new Gson().fromJson(quesOriData, new TypeToken<List<MDSmartScriptQuesListModel>>() {
        }.getType());

        System.out.println("Ques List:" + Utility.ObjectToJson(quesOriData));


        int action_by = Utility.getUserId(request).intValue();
        String action_by_username = Utility.getLoginName(request);
        long current_ts = Utility.getCurrentTimestamp();
        long subarea_id = new Long(subarea);
        Map<Long, Object> quesAnsList = new HashMap<Long, Object>();

        if (resList.size() > 0) {
            List<Object[]> batchArgsList = new ArrayList<Object[]>();

            try {
                for (SrSmartSctiptList row : resList) {
                    quesAnsList.put(new Long(row.getName()), row.getValue());
                }
                System.out.println("ss mapped data : " + Utility.ObjectToJson(quesAnsList));

                String final_response_msg = "";
                String required_level = "";


                for (MDSmartScriptQuesListModel each_data : quesOriList) {
                    Object[] objectArray = {
                            subarea_id,
                            Long.parseLong(srNumberforSS),
                            Long.parseLong(customerMsisdn),
                            each_data.getSR_QUES_ID(),
                            quesAnsList.get(each_data.getSR_QUES_ID()),
                            1,
                            current_ts,
                            action_by,
                            action_by_username,
                            each_data.getNAME(),
                            each_data.getQUESTION(),
                            each_data.getANS_INPUT_TYPE(),
                            each_data.getANS_TYPE_NAME(),
                            each_data.getIS_MANDATORY(),
                            each_data.getQUES_SEQUENCE()
                    };
                    batchArgsList.add(objectArray);

                    /*     Generate Message : Start */

                    if (each_data.getIS_MANDATORY() == 1) {
                        required_level = " <span class='red-dark-2'>*</span>";
                    } else {
                        required_level = "";
                    }
                    final_response_msg = final_response_msg + "<tr><td class='sr-num-title text-right' style='width: 350px'><span class='font-blod6'>" + each_data.getQUESTION() + required_level + "</span></td>";
                    final_response_msg = final_response_msg + "<td><input type='text' class='form-control'  value='" + quesAnsList.get(each_data.getSR_QUES_ID()) + "' readonly></td></tr>";
                    /*     Generate Message : End */
                }

                logger.info("SmartScript Final Insert Data : " + Utility.ObjectToJson(batchArgsList));
                System.out.println("SmartScript Final Insert Data : " + Utility.ObjectToJson(batchArgsList));
                System.out.println("final_response_msg : " + final_response_msg);

                boolean h = srtypeDAO.insertSmartScript(batchArgsList, logger);

                if (h) {
                    commonRestResponse.setCode(200);
                    commonRestResponse.setMessage(final_response_msg);
                } else {
                    commonRestResponse.setCode(500);
                    commonRestResponse.setMessage("Error Occurred. Please try later!");
                }

            } catch (Exception ex) {
                ex.printStackTrace();
                logger.error(ex.getMessage(), ex);
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("Error Occurred. Please try later!");
            }

        } else {
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Please try again with valid data set!");
        }
        return commonRestResponse;
    }


    @RequestMapping(value = "/get_smart_script_data", method = RequestMethod.POST)
    public CommonRestResponse getSmartScriptData(HttpServletRequest request, @RequestParam("srNumberforSS") String srNumberforSS, @RequestParam("msisdn") String customerMsisdn, @RequestParam("subarea") Integer subarea) {
        CommonRestResponse commonRestResponse = new CommonRestResponse();

        logger.info("fetching Smart Script Answer Data ");
        String final_input_text = "";

        /* checking data is already submitted or not */

        List<SrSmartScriptQuesAnsList> SrSmartScriptQuesAnsData = new ArrayList<>();
        try {
            String qry_ans = "SELECT ID,SR_SUB_AREA_ID,SR_NUM,QUESTION_NAME,MSISDN,SR_QUES_ID,SR_QUES_TEXT,ANS_INPUT_TYPE,ANS_TEXT,ANS_TYPE_NAME,IS_MANDATORY,QUES_SEQUENCE FROM " + Utility.tbl_sr_ques_ans + " where SR_NUM=" + srNumberforSS + " AND MSISDN=" + customerMsisdn + " AND SR_SUB_AREA_ID=" + subarea + " Order by ID ASC";
            logger.info("Query :" + qry_ans);
            Object SrQuesAnswerList = commonDAO.getDataPostgres(qry_ans);
            SrSmartScriptQuesAnsData = new Gson().fromJson(Utility.ObjectToJson(SrQuesAnswerList), new TypeToken<List<SrSmartScriptQuesAnsList>>() {
            }.getType());
        } catch (Exception ex) {
            ex.printStackTrace();
            logger.error(ex.getMessage(), ex);
        }

        System.out.println("Submitted SS data:" + Utility.ObjectToJson(SrSmartScriptQuesAnsData));
        logger.info("Submitted SS data:" + Utility.ObjectToJson(SrSmartScriptQuesAnsData));

        if (SrSmartScriptQuesAnsData.size() > 0) {
            for (SrSmartScriptQuesAnsList each_ans_row : SrSmartScriptQuesAnsData) {
                String required_level = "";
                if (each_ans_row.getIS_MANDATORY() == 1) {
                    required_level = " <span class='red-dark-2'>*</span>";
                } else {
                    required_level = "";
                }

                final_input_text = final_input_text + "<tr><td class='sr-num-title text-right' style='width: 350px'><span class='font-blod6'>" + each_ans_row.getSR_QUES_TEXT() + required_level + "</span></td>";
                final_input_text = final_input_text + "<td><input type='text' class='form-control'  value='" + each_ans_row.getANS_TEXT() + "' readonly></td></tr>";
            }

            commonRestResponse.setCode(200);
            commonRestResponse.setMessage("");
            commonRestResponse.setData(final_input_text);
        } else {
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Please Submit Smart Script Information");
        }


        return commonRestResponse;
    }

    @RequestMapping(value = "/bulk/srUpdate", method = RequestMethod.POST)
    public CommonRestResponse resolveSRInBulk(HttpServletRequest request, @RequestBody BulkSRPostModel bulkSRPostModel) {
        return srBulkUpdateService.updateSrInBulk(request, bulkSRPostModel);
    }

    @RequestMapping(value = "/bulk/srUpdateCheck", method = RequestMethod.GET)
    public CommonRestResponse srBulkUpdateCheck(HttpServletRequest request, @RequestParam("rowSpec") String rowSpec) {
        return srManagementQueryService.getSrBulkUpdateCheck(rowSpec, request);
    }
}
