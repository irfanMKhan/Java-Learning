package com.reddot.ecrm.creditCeiling;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreditCeilingGetByIdResponseObjDTO {
    private String id;
    private String companyName;
    private String creditCeiling;
    private String creditLimit;
    private String amount;
    private String newCC;
    private String expirationDate;
}
