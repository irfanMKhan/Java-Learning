package com.reddot.ecrm.controller.cr.delay_payment;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DelayPaymentSearchReqDto {
    private String custKey;
    private String invoiceNo;
    private String invoiceAmount;
    private String invoiceDate;
    private String billCycleBeginTime;
    private String billCycleEndTime;
    private String dueAmount;
    private String dueDate;
    private String disputeAmount;
    private String statusId;
    private String dateOfAgreedPayment;
    private String effectiveDate;
}
