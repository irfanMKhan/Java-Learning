package com.reddot.ecrm.controller.approval.approval_flow_steps;

import com.reddot.ecrm.entity.approval.ApprovalFlowStepsEntity;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.approval.ApprovalStepsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("approval/flow/steps/rest")
public class ApprovalStepsRest {

    @Autowired
    ApprovalStepsService approvalStepsService;

    @PostMapping("/getUsersByPositionID")
    public CommonRestResponse getUserByPositionID(@RequestBody Long id) {
        return approvalStepsService.getAllUserByPositionID(id);
    }

    @PostMapping("/getAllExistingStepsByFlowID")
    public CommonRestResponse getAllExistingStepsByFlowID(@RequestBody Long flowId, HttpServletRequest request) {
        return approvalStepsService.getAllExistingStepsByFlowID(flowId, request);
    }

    @PostMapping("/addStepsData")
    public CommonRestResponse addData(@RequestBody List<ApprovalFlowStepsEntity> approvalFlowStepsEntityList, HttpServletRequest request) {
        return approvalStepsService.addStepsData(approvalFlowStepsEntityList, request);
    }

    @PostMapping("/deleteStepDataByID")
    public CommonRestResponse deleteData(@RequestBody Long stepId) {
        return approvalStepsService.deleteData(stepId);
    }
}
