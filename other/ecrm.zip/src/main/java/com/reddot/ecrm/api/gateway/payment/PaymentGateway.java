package com.reddot.ecrm.api.gateway.payment;

import com.google.gson.Gson;
import com.reddot.ecrm.api.exception.ApiRequestException;
import com.reddot.ecrm.api.exception.InvalidAccessTokenException;
import com.reddot.ecrm.api.exception.InvalidClientCredentialException;
import com.reddot.ecrm.api.payload.request.payment.CreatePAMultiInvoiceRequest;
import com.reddot.ecrm.api.payload.request.payment.CreatePARequestReq;
import com.reddot.ecrm.api.payload.request.payment.QueryInvoiceAPIRequest;
import com.reddot.ecrm.api.payload.response.payment.*;
import com.reddot.ecrm.api.security.AuthorizationGateway;
import com.reddot.ecrm.api.utility.CommonConstant;
import com.reddot.ecrm.api.utility.HttpClient;
import com.reddot.ecrm.api.utility.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor
public class PaymentGateway {

    private final HttpClient httpClient;
    private final Gson gson;
    private final AuthorizationGateway authorizationGateway;
    @Value("${smart.egw.base.url}")
    String baseUrlEGW;
    @Value("${smart.igw.base.url}")
    String baseUrlIGW;

//    public QueryInvoiceResponse queryInvoice(QueryInvoiceAPIRequest queryInvoiceRequest) {
//        String apiUrl = baseUrlEGW + "/CBS/AR/QueryInvoice/v1.0";
//        String json = gson.toJson(queryInvoiceRequest);
//
//        try (Response response = httpClient.post(json, apiUrl, getHeaders())) {
//            assert response.body() != null;
//            if (response.code() == HttpStatus.OK.value()) {
//                String responseStr = response.body().string();
//                JSONObject jsonObject = new JSONObject(responseStr);
//
//                if (jsonObject.has("QueryInvoiceResultMsg")) {
//                    JSONObject QueryInvoiceResultMsg = jsonObject.getJSONObject("QueryInvoiceResultMsg");
//
//                    if (QueryInvoiceResultMsg.has("QueryInvoiceResult")) {
//                        JSONObject QueryInvoiceResult = QueryInvoiceResultMsg.getJSONObject("QueryInvoiceResult");
//
//                        if (QueryInvoiceResult.has("InvoiceInfo")) {
//                            if (QueryInvoiceResult.get("InvoiceInfo").getClass().getName().contains("org.json.JSONObject")) {
//                                JSONArray GroupMemberJsonArray = Utils.convertJsonObjectToArray(QueryInvoiceResult.getJSONObject("InvoiceInfo"));
//                                QueryInvoiceResult.put("InvoiceInfo", GroupMemberJsonArray);
//                            }
//                        }
//                    }
//                }
//
//                return gson.fromJson(String.valueOf(jsonObject), QueryInvoiceResponse.class);
//            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
//                log.debug("Url Not Found: " + apiUrl);
//                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
//            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
//                throw new InvalidAccessTokenException();
//            } else {
//                QueryInvoiceErrorResponse errorResponse = gson.fromJson(response.body().string(), QueryInvoiceErrorResponse.class);
//                throw new ApiRequestException(errorResponse.getFault().getFaultstring());
//            }
//        } catch (Exception e) {
//            if (e instanceof ApiRequestException) {
//                log.debug("QueryInvoice Api Request Error: {}", e.getMessage());
//                throw new ApiRequestException(e.getMessage());
//            } else if (e instanceof InvalidAccessTokenException) {
//                log.debug("QueryInvoice Access Token Error: {}", e.getMessage());
//                throw new InvalidAccessTokenException();
//            } else if (e instanceof InvalidClientCredentialException) {
//                log.debug("QueryInvoice Credentials Error: {}", e.getMessage());
//                throw new InvalidClientCredentialException(e.getMessage());
//            }
//            log.error("QueryInvoice Error: {}", e.getMessage(), e.getCause());
////            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
//            throw new ApiRequestException(e.getMessage());
//        }
//    }

    public QueryInvoiceResponse queryInvoice(QueryInvoiceAPIRequest queryInvoiceRequest) {
        String apiUrl = baseUrlEGW + "/CBS/AR/QueryInvoice/v1.0";
        String json = gson.toJson(queryInvoiceRequest);

        try (Response response = httpClient.post(json, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                String responseStr = response.body().string();
                JSONObject jsonObject = new JSONObject(responseStr);

                if (jsonObject.has("QueryInvoiceResultMsg")) {
                    JSONObject QueryInvoiceResultMsg = jsonObject.getJSONObject("QueryInvoiceResultMsg");

                    if (QueryInvoiceResultMsg.has("QueryInvoiceResult")) {
                        JSONObject QueryInvoiceResult = QueryInvoiceResultMsg.getJSONObject("QueryInvoiceResult");

                        if (QueryInvoiceResult.has("InvoiceInfo")) {
                            if (QueryInvoiceResult.get("InvoiceInfo").getClass().getName().contains("org.json.JSONObject")) {
                                JSONArray GroupMemberJsonArray = Utils.convertJsonObjectToArray(QueryInvoiceResult.getJSONObject("InvoiceInfo"));
                                QueryInvoiceResult.put("InvoiceInfo", GroupMemberJsonArray);
                            }
                        }
                    }
                }

                return gson.fromJson(String.valueOf(jsonObject), QueryInvoiceResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                QueryInvoiceErrorResponse errorResponse = gson.fromJson(response.body().string(), QueryInvoiceErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getFaultstring());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("QueryInvoice Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("QueryInvoice Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("QueryInvoice Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("QueryInvoice Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }


    public CreatePAResponse createPA(CreatePARequestReq createPARequestReq) {
        String apiUrl = baseUrlIGW + "/api/cbsdc/1201/pa/v2/create-pa";
        String json = gson.toJson(createPARequestReq);

        try (Response response = httpClient.post(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.CREATED.value()) {
                return gson.fromJson(response.body().string(), CreatePAResponse.class);
            } else if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), CreatePAResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                CreatePAErrorResponse errorResponse = gson.fromJson(response.body().string(), CreatePAErrorResponse.class);
                throw new ApiRequestException(errorResponse.getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("CreatePARequest Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("CreatePARequest Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("CreatePARequest Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("CreatePARequest Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    public CreatePAResponse createPAMultipleInvoice(CreatePAMultiInvoiceRequest createPAMultiInvoiceRequest) {
        String apiUrl = baseUrlIGW + "/api/cbsdc/1201/pa/v2/create-pa";
        String json = gson.toJson(createPAMultiInvoiceRequest);

        try (Response response = httpClient.post(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.CREATED.value()) {
                return gson.fromJson(response.body().string(), CreatePAResponse.class);
            } else if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), CreatePAResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                CreatePAErrorResponse errorResponse = gson.fromJson(response.body().string(), CreatePAErrorResponse.class);
                throw new ApiRequestException(errorResponse.getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("CreatePAMultipleInvoiceRequest Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("CreatePAMultipleInvoiceRequest Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("CreatePAMultipleInvoiceRequest Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("CreatePAMultipleInvoiceRequest Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    public QueryDepositAmountResponse queryDepositAmount(String accountCode, String tranId) {
        String apiUrl = baseUrlIGW + "/api/cbsar/1219/balance/v2.1/" + accountCode + "?AcctAcces" +
                "sCode=AccountCode&transaction_id=" + tranId;

        try (Response response = httpClient.get(apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {

                String responseStr = response.body().string();
                JSONObject jsonObject = new JSONObject(responseStr);

                if (jsonObject.has("data")) {
                    JSONObject data = jsonObject.getJSONObject("data");

                    if (data.has("QueryBalance")) {

                        if (!data.get("QueryBalance").getClass().getName().contains("org.json.JSONObject$Null")) {

                            JSONObject QueryBalance = data.getJSONObject("QueryBalance");

                            if (QueryBalance.has("AcctList")) {
                                JSONObject AcctList = QueryBalance.getJSONObject("AcctList");

                                if (AcctList.has("BalanceResult")) {
                                    if (AcctList.get("BalanceResult").getClass().getName().contains("org.json.JSONObject")) {
                                        String BalanceResultStr = "[" + AcctList.get("BalanceResult").toString() + "]";
                                        JSONArray BalanceResultJsonArray = new JSONArray(BalanceResultStr);

                                        for (int i = 0; i < BalanceResultJsonArray.length(); i++) {
                                            if (BalanceResultJsonArray.getJSONObject(i).has("BalanceDetail")) {
                                                if (BalanceResultJsonArray.getJSONObject(i).get("BalanceDetail").getClass().getName().contains("org.json.JSONObject")) {
                                                    JSONObject BalanceDetailsObject = BalanceResultJsonArray.getJSONObject(i).getJSONObject("BalanceDetail");
                                                    JSONArray BalanceDetailJsonArray = Utils.convertJsonObjectToArray(BalanceDetailsObject);
                                                    BalanceResultJsonArray.getJSONObject(i).put("BalanceDetail", BalanceDetailJsonArray);
                                                }
                                            }
                                        }

                                        AcctList.put("BalanceResult", BalanceResultJsonArray);
                                    } else if (AcctList.get("BalanceResult").getClass().getName().contains("org.json.JSONArray")) {
                                        JSONArray BalanceResultJsonArray = AcctList.getJSONArray("BalanceResult");

                                        for (int i = 0; i < BalanceResultJsonArray.length(); i++) {
                                            if (BalanceResultJsonArray.getJSONObject(i).has("BalanceDetail")) {
                                                if (BalanceResultJsonArray.getJSONObject(i).get("BalanceDetail").getClass().getName().contains("org.json.JSONObject")) {
                                                    JSONObject BalanceDetailsObject = BalanceResultJsonArray.getJSONObject(i).getJSONObject("BalanceDetail");
                                                    JSONArray BalanceDetailJsonArray = Utils.convertJsonObjectToArray(BalanceDetailsObject);
                                                    BalanceResultJsonArray.getJSONObject(i).put("BalanceDetail", BalanceDetailJsonArray);
                                                }
                                            }
                                        }

                                        AcctList.put("BalanceResult", BalanceResultJsonArray);
                                    }
                                }
                            }
                        }
                    }
                }

                return gson.fromJson(String.valueOf(jsonObject), QueryDepositAmountResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                QueryDepositAmountErrorResponse errorResponse = gson.fromJson(response.body().string(), QueryDepositAmountErrorResponse.class);
                throw new ApiRequestException(errorResponse.getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("QueryDepositAmount Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("QueryDepositAmount Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("QueryDepositAmount Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("QueryDepositAmount Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    private Map<String, String> getIGWHeaders() {
        String bearerToken = authorizationGateway.getTokenIGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }

    private Map<String, String> getHeaders() {
        String bearerToken = authorizationGateway.getTokenEGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }
}
