package com.reddot.ecrm.controller.UAM.responsibility;

import com.reddot.ecrm.menu.MenuViewer;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping(value = "/responsibility", method = RequestMethod.GET)
public class ResponsibilityController {

    @GetMapping("")
    public String getResponsibilityPage(ModelMap model, HttpServletRequest request){
        return "redirect:/responsibility/list";
    }

    @GetMapping({"/list"})
    public String getResponsibilityListPage(ModelMap model, HttpServletRequest request){
        new MenuViewer().setupSideMenu(model, request);
        model.addAttribute("title", "Responsibility");
        model.addAttribute("breadcrumb", "Responsibility");
        return "responsibility/responsibility_list";
    }
    @GetMapping("/add")
    public String getResponsibilityAddView(ModelMap model, HttpServletRequest request){
        new MenuViewer().setupSideMenu(model, request);
        model.addAttribute("title", "Add Responsibility");
        model.addAttribute("breadcrumb", "Responsibility");
        return "responsibility/responsibility_add";
    }

    @GetMapping("/{id}")
    public String getResponsibilityUpdateView(@PathVariable("id") String id, ModelMap model, HttpServletRequest request){
        new MenuViewer().setupSideMenu(model, request);
        model.addAttribute("title", "Update Responsibility");
        model.addAttribute("breadcrumb", "Responsibility");
        model.addAttribute("id", id);
        return "responsibility/responsibility_update";
    }
}
