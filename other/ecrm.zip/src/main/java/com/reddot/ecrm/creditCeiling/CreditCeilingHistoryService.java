package com.reddot.ecrm.creditCeiling;

import com.reddot.ecrm.dto.attachment.AttachmentDTO;
import com.reddot.ecrm.dto.httpServletRequest.HttpServletRequestDto;
import com.reddot.ecrm.entity.approval.ApprovalFlowEntity;
import com.reddot.ecrm.entity.approval.ApprovalRequestEntity;
import com.reddot.ecrm.entity.attachment.AttachmentEntity;
import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.enum_config.approval.ApprovalEnum;
import com.reddot.ecrm.enum_config.approval.ApprovalForEnum;
import com.reddot.ecrm.enum_config.bulk.BulkProcessFileTypeEnum;
import com.reddot.ecrm.enum_config.cr.CRStatusEnum;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.module.commonConfig.CommonConfig;
import com.reddot.ecrm.module.commonConfig.CommonConfigRepo;
import com.reddot.ecrm.repository.approval.ApprovalFlowRepo;
import com.reddot.ecrm.repository.attachment.AttachmentRepository;
import com.reddot.ecrm.repository.company.CompanyRepository;
import com.reddot.ecrm.service.approval.ApprovalRequestService;
import com.reddot.ecrm.service.attachment.AttachmentService;
import com.reddot.ecrm.spring_config.session.SessionManager;
import com.reddot.ecrm.util.Utility;
import com.reddot.ecrm.util.unique_id_generate.UniqueIDGenerator;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class CreditCeilingHistoryService {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    int min = Integer.MAX_VALUE;
    @Autowired
    private ApprovalFlowRepo approvalFlowRepo;
    
    @Autowired
    private ApprovalRequestService approvalRequestService;
    @Autowired
    private CreditCeilingHistoryRepo creditCeilingHistoryRepo;
    @Autowired
    private CommonConfigRepo commonConfigRepo;
    @Autowired
    private CompanyRepository companyRepository;
    @Autowired
    private AttachmentRepository attachmentRepository;
    
    @Autowired
    private AttachmentService attachmentService;
    
    private boolean doLessThanCheckForNewCC(CreditCeilingHistoryReqBodyForAdd reqBody) {
        List<CreditCeilingHistory> historyList = new ArrayList<>();
        historyList = creditCeilingHistoryRepo.findAllByCompanyIdOrderByIdDesc(reqBody.getCompanyId());
        
        Optional<CompanyEntity> company = companyRepository.findById(Long.valueOf(reqBody.getCompanyId()));
        CompanyEntity companyEntity = company.get();
        
        for (CreditCeilingHistory ceilingHistory : historyList) {
            if (!(ceilingHistory.getApprovalStatus().equals("Approved")) || !(ceilingHistory.getApprovalStatus().equals("Rejected"))) {
                if ((ceilingHistory.getNewCC() - Double.valueOf(reqBody.getAmount())) < companyEntity.getCreditLimit()) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public ResponseEntity<?> getAllCreditCeilingHistory() {
        List<CreditCeilingHistory> ceilingHistoryList = new ArrayList<>();
        ceilingHistoryList = creditCeilingHistoryRepo.findAll();
        return new ResponseEntity<>(ceilingHistoryList, HttpStatus.OK);
    }
    
    public DataTablesOutput<CreditCeilingHistory> searchDT(DataTablesInput input, CreditCeilingHistorySearchReqDTO reqBody) {
        int start = input.getStart();
        int length = input.getLength();
        int page = start / length;
        
        Pageable pageable = PageRequest.of(page, length, Sort.by("id").descending());
        DataTablesOutput<CreditCeilingHistory> output = new DataTablesOutput<>();
        Page<CreditCeilingHistory> responseData;
        
        responseData = creditCeilingHistoryRepo.findAll(new Specification<CreditCeilingHistory>() {
            @Override
            public Predicate toPredicate(Root<CreditCeilingHistory> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
                List<Predicate> predicates = new ArrayList<>();
                
                boolean companyIdIsNull = Objects.equals(null, reqBody.getCompanyId());
                boolean typeIdIsNull = Objects.equals(null, reqBody.getTypeId());
                boolean referenceIdIsNull = Objects.equals(null, reqBody.getReferenceId());
                
                if (!companyIdIsNull && !reqBody.getCompanyId().equals("")) {
                    //Optional<CommonConfig> configOptional = commonConfigRepo.findById(Long.valueOf(reqBody.getCompanyId()));
                    predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("companyId"), Long.valueOf(reqBody.getCompanyId()))));
                }
                if (!typeIdIsNull && !reqBody.getTypeId().equals("")) {
                    Optional<CommonConfig> configOptional = commonConfigRepo.findById(Long.valueOf(reqBody.getTypeId()));
                    predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("typeName"), configOptional.get().getName())));
                }
//                if (!reqBody.getStatusId().equals("")) {
//                    Optional<CommonConfig> configOptional = commonConfigRepo.findById(Long.valueOf(reqBody.getStatusId()));
//                    predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("statusName"), configOptional.get().getName())));
//                }
                if (!referenceIdIsNull && !reqBody.getReferenceId().equals("")) {
                    Optional<CommonConfig> configOptional = commonConfigRepo.findById(Long.valueOf(reqBody.getReferenceId()));
                    predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("referenceName"), configOptional.get().getName())));
                }
                if (!reqBody.getCreditCeiling().equals("")) {
                    predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("creditCeiling"), Integer.valueOf(reqBody.getCreditCeiling()))));
                }
                return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
            }
        }, pageable);
        
        output.setData(responseData.getContent());
        output.setRecordsFiltered(responseData.getTotalElements());
        output.setRecordsTotal(responseData.getTotalElements());
        
        output.setData(output.getData());
        output.setDraw(input.getDraw());
        
        return output;
    }
    
    public ResponseEntity<?> getAllCompany(HttpServletRequest httpServletRequest) {
        List<CompanyEntity> list = companyRepository.findAll();
        return new ResponseEntity<>(list, HttpStatus.OK);
    }
    
    public ResponseEntity<?> getCompanyById(HttpServletRequest httpServletRequest, String id) {
        Optional<CompanyEntity> company = companyRepository.findById(Long.valueOf(id));
        return new ResponseEntity<>(company.get(), HttpStatus.OK);
    }
    
    public ResponseEntity<?> addCC(HttpServletRequest httpServletRequest, CreditCeilingHistoryReqBodyForAdd reqBody) {
        CreditCeilingHistory creditCeilingHistory = new CreditCeilingHistory();

//        if (reqBody.getTypeName().equals("Decrease")) {
//            if (doLessThanCheckForNewCC(reqBody)) {
//                return new ResponseEntity<>("Message is yet to set", HttpStatus.OK);
//            }
//        }
        
        // findFirstByOrderByIdDesc
        // CreditCeilingHistory ceilingHistory = creditCeilingHistoryRepo.findFirstByOrderByIdDescAndCompanyIdAndApprovalStatusExcept(reqBody.getCompanyId(), "Accepted");
        
        creditCeilingHistory.setActive(true);
        creditCeilingHistory.setCompanyId(Long.valueOf(reqBody.getCompanyId()));
        creditCeilingHistory.setCompanyName(reqBody.getCompanyName());

//        creditCeilingHistory.setCreditCeiling(Integer.valueOf(reqBody.getCreditCeiling()));
//        creditCeilingHistory.setCreditLimit(Integer.valueOf(reqBody.getCreditLimit()));
        
        creditCeilingHistory.setCreditCeiling(Double.valueOf(reqBody.getCreditCeiling()));
        creditCeilingHistory.setCreditLimit(Double.valueOf(reqBody.getCreditLimit()));
        
        creditCeilingHistory.setTypeId(Long.valueOf(reqBody.getTypeId()));
        creditCeilingHistory.setTypeName(reqBody.getTypeName());
        //creditCeilingHistory.setStatusId(Long.valueOf(reqBody.getStatusId()));
        //creditCeilingHistory.setStatusName(reqBody.getStatusName());
        creditCeilingHistory.setReferenceId(reqBody.getReferenceId());
        creditCeilingHistory.setReferenceName(reqBody.getReferenceName());

//        creditCeilingHistory.setAmount(Integer.valueOf(reqBody.getAmount()));
//        creditCeilingHistory.setNewCC(Integer.valueOf(reqBody.getNewCC()));
        
        creditCeilingHistory.setAmount(reqBody.getAmount());
        creditCeilingHistory.setNewCC(reqBody.getNewCC());
        
        if (reqBody.getNewCC() < Double.valueOf(reqBody.getCreditLimit())) {
            return new ResponseEntity<>("Credit-Ceiling can not be less than Credit-Limit\nHere, " + reqBody.getNewCC() + " < " + reqBody.getCreditLimit(), HttpStatus.NOT_ACCEPTABLE);
        }
        
        creditCeilingHistory.setTransactionNo("cc-increase-" + System.currentTimeMillis());
        
        // for expirationDate
//        String myDate = reqBody.getExpirationDate() + " " + "00:00:00";
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        Date date = null;
//        try {
//            date = sdf.parse(myDate);
//        } catch (ParseException e) {
//            throw new RuntimeException(e);
//        }W
//        long millis = date.getTime();
        //
        
        //creditCeilingHistory.setExpirationDate(millis);
        //creditCeilingHistory.setAttachment(reqBody.getAttachment());
        
        creditCeilingHistory.setApprovalStatus(CRStatusEnum.Created.toString());
        
        creditCeilingHistory.setCreatedAt(System.currentTimeMillis());
        creditCeilingHistory.setCreatedAtDt(new Timestamp(System.currentTimeMillis()));
        creditCeilingHistory.setCreatedBy(Utility.loggedInId(httpServletRequest));
        creditCeilingHistory.setCreatedByUsername(Utility.getLoginName(httpServletRequest));
        
        creditCeilingHistoryRepo.save(creditCeilingHistory);
        
        //Attachment Save
        MDUserModel user = SessionManager.getUserDetails(httpServletRequest);
        ModelMapper mapper = new ModelMapper();
        List<AttachmentEntity> attachmentEntityList = new ArrayList<>();
        List<AttachmentDTO> attachmentDTOList = reqBody.getAttachmentList();
        for (AttachmentDTO attachmentDTO : attachmentDTOList) {
            
            AttachmentEntity attachment = new AttachmentEntity();
            mapper.map(attachmentDTO, attachment);
            attachment.setIsFinalSave(true);  //final save so make this true
            attachment.setCreateBy(user.getID().toString());
            attachment.setCreateByName(user.getLOGIN_NAME());
            attachment.setModulePrimaryId(creditCeilingHistory.getId());
            attachment.setModuleTableName(BulkProcessFileTypeEnum.Credit_Ceiling_history.getKey());
            attachmentEntityList.add(attachment);
        }
        
        if (attachmentEntityList.size() > 0) {
            attachmentRepository.saveAll(attachmentEntityList);
        }
        //Attachment Save End
        
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        
        Optional<CompanyEntity> optionalCompanyEntity = companyRepository.findById(Long.valueOf(reqBody.getCompanyId()));
        
        checkApproval(creditCeilingHistory, httpServletRequest);
        if (creditCeilingHistory.getApprovalStatus().equals(CRStatusEnum.Created.toString())) {
            optionalCompanyEntity.get().setCreditCeiling(reqBody.getNewCC());
            companyRepository.save(optionalCompanyEntity.get());
        }
//        Optional<CompanyEntity> optionalCompanyEntity = companyRepository.findById(Long.valueOf(reqBody.getCompanyId()));
//        if (optionalCompanyEntity.isPresent()) {
//            CompanyEntity company = optionalCompanyEntity.get();
//            company.setCreditCeiling(Integer.valueOf(reqBody.getNewCC()));
//            companyRepository.save(company);
//        }
        
        return new ResponseEntity<>("success", HttpStatus.OK);
    }
    
    private void checkApproval(CreditCeilingHistory creditCeilingHistory, HttpServletRequest httpServletRequest) {
        Boolean HasApproval = false;
        String transactionId = UniqueIDGenerator.getNextUniqueNumberOnly();
        Long tenantId = Utility.loggedInTenantId(httpServletRequest);
        try {
            ApprovalRequestEntity approvalRequestEntity = new ApprovalRequestEntity();
            Optional<ApprovalFlowEntity> approvalFlowEntity = approvalFlowRepo.findByNameAndTenantId(ApprovalEnum.CREDIT_CEILING.getKey(), tenantId);
            if (approvalFlowEntity.isPresent()) {
                approvalRequestEntity.setApprovalFlowId(approvalFlowEntity.get().getId());
                approvalRequestEntity.setApprovalFlowName(ApprovalEnum.CREDIT_CEILING.getKey());
                approvalRequestEntity.setHasRequestedAmount(true);
                approvalRequestEntity.setApprovalFor(ApprovalForEnum.CREDIT_CEILING.getKey());
                approvalRequestEntity.setIsCategoryType(false);
                approvalRequestEntity.setTransactionNumber(creditCeilingHistory.getTransactionNo());
                
                approvalRequestEntity.setRequestDetailsId(creditCeilingHistory.getId());
                // transactionId --> todo: check
                approvalRequestEntity.setRequestTransactionId(transactionId);
                approvalRequestEntity.setCompanyName(creditCeilingHistory.getCompanyName());
                
                String description = "";
                
                if (!Objects.isNull(creditCeilingHistory)) {
//                    approvalRequestEntity.setRequestedAmount(Double.valueOf(creditCeilingHistory.getNewCC()));
//                    HasApproval = true;
                    approvalRequestEntity.setRequestedAmount(creditCeilingHistory.getAmount());
                    HasApproval = true;
                }
                
                if (HasApproval) {
                    description = "Credit Ceiling " + creditCeilingHistory.getTypeName() + " Request" +
                            "\nCurrent Credit Ceiling: $" + creditCeilingHistory.getCreditCeiling() +
                            "\n" + creditCeilingHistory.getTypeName() + " Amount: $" + creditCeilingHistory.getAmount() +
                            "\nNew Credit Ceiling After Approval: $" + creditCeilingHistory.getNewCC();
                    approvalRequestEntity.setRequestDescription(description);
                    HttpServletRequestDto request = Utility.createHttpServletDTO(httpServletRequest);
                    HasApproval = (Boolean) approvalRequestService.addRequestData(approvalRequestEntity, request).getData();
                    creditCeilingHistory.setApprovalStatus(CRStatusEnum.Pending.toString());
                    creditCeilingHistoryRepo.saveAndFlush(creditCeilingHistory);
                }
                
            } else {
                logger.info("%s Approval Flow not exists.", ApprovalEnum.CREDIT_CEILING.getKey());
            }
            
        } catch (Exception e) {
            logger.error(String.format("Credit Ceiling Service:ApprovalCheckForCreditCeiling() Error: %s", e.getMessage()));
        }
    }
    
    public ResponseEntity<?> getCreditCeilingById(HttpServletRequest httpServletRequest, CreditCeilingHistoryReqBodyForGetById reqBody) {
        Optional<CreditCeilingHistory> ceilingHistoryOptional = creditCeilingHistoryRepo.findById(Long.valueOf(reqBody.getCcHistoryId()));
        
        CreditCeilingGetByIdResponseObjDTO response = new CreditCeilingGetByIdResponseObjDTO();
        
        response.setId(String.valueOf(ceilingHistoryOptional.get().getId()));
        response.setCompanyName(ceilingHistoryOptional.get().getCompanyName());
        response.setCreditLimit(String.valueOf(ceilingHistoryOptional.get().getCreditLimit()));
        response.setCreditCeiling(String.valueOf(ceilingHistoryOptional.get().getCreditCeiling()));
        response.setAmount(String.valueOf(ceilingHistoryOptional.get().getAmount()));
        response.setNewCC(String.valueOf(ceilingHistoryOptional.get().getNewCC()));
        
        // DateFormat obj = new SimpleDateFormat("yyyy-MM-dd");
        // Date res = new Date(ceilingHistoryOptional.get().getExpirationDate());
        // response.setExpirationDate(obj.format(res));
        
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    public ResponseEntity<?> updateCC(HttpServletRequest httpServletRequest, CreditCeilingHistoryReqBodyForUpdate reqBody) {
        
        Optional<CreditCeilingHistory> optionalCreditCeilingHistory = creditCeilingHistoryRepo.findById(Long.valueOf(reqBody.getId()));
        
        if (optionalCreditCeilingHistory.isPresent()) {
            
            CreditCeilingHistory creditCeilingHistory = optionalCreditCeilingHistory.get();
            
            creditCeilingHistory.setAmount(Integer.valueOf(reqBody.getAmount()));
            creditCeilingHistory.setNewCC(Integer.valueOf(reqBody.getNewCC()));
//            //
//            String myDate = reqBody.getExpirationDate() + " " + "00:00:00";
//            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//            Date date = null;
//            try {
//                date = sdf.parse(myDate);
//            } catch (ParseException e) {
//                throw new RuntimeException(e);
//            }
//            long millis = date.getTime();
//            //
//            creditCeilingHistory.setExpirationDate(millis);
            
            creditCeilingHistoryRepo.save(creditCeilingHistory);
        }
        
        return new ResponseEntity<>("success", HttpStatus.OK);
    }
    
    public List<AttachmentEntity> getAllCreditCeilingAttachment(HttpServletRequest httpServletRequest,
                                                                GetCreditCeilingRowByIdReqBody reqBody) {
        List<AttachmentEntity> attachmentEntityList = new ArrayList<>();
        attachmentEntityList = attachmentService.findAllByModuleIdAndModuleName(Long.valueOf(reqBody.getCreditCeilingRowID()), "Credit Ceiling History");
        if (!CollectionUtils.isEmpty(attachmentEntityList)) {
            return attachmentEntityList;
        }
        return attachmentEntityList;
    }
}
