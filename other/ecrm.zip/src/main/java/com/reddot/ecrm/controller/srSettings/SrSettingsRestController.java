package com.reddot.ecrm.controller.srSettings;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.controller.settings.ClassTypeRestController;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.model.settings.ClassTypeModel;
import com.reddot.ecrm.model.srSettings.SRStatusModel;
import com.reddot.ecrm.service.srsettings.SrStatusService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

//@RestController
//@RequestMapping("/settings/sr")
public class SrSettingsRestController {
    private final Logger logger = LoggerFactory.getLogger(ClassTypeRestController.class);
//    @Autowired
    private SrStatusService srStatusService;


    /*@GetMapping("/dt/classType")
    public DataTablesOutput<ClassTypeModel> dtClassType(@Valid DataTablesInput input, HttpServletRequest request, @RequestParam(value = "searchText", required = false) String searchText, @RequestParam(value = "searchCol", required = false) String searchCol) {
        return srStatusService.getDTClasType(input, request, searchText, searchCol);
    }*/

   /* @PostMapping("/status/add")
    public String addStatus(HttpServletRequest request, @RequestParam("statusData") String statusData) {
        try {
            SRStatusModel srStatusModel = new Gson().fromJson(statusData, new TypeToken<SRStatusModel>() {
            }.getType());
            if (srStatusModel.getName() == null || srStatusModel.getName().isEmpty()) {
                return "Please enter a status name!";
            }
//            TODO:
            return srStatusService.addSrStatusFunction(request,srStatusModel);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("SR Status Adding Error");
            logger.error(e.getMessage(), e);
            return "Failed! Try later.";
        }
    }*/


}
