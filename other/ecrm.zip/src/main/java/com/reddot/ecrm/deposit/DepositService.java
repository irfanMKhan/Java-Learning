package com.reddot.ecrm.deposit;

import com.reddot.ecrm.api.SmartAxiataAPI;
import com.reddot.ecrm.api.attachmentSource.AttachmentSourceService;
import com.reddot.ecrm.api.payload.response.payment.QueryDepositAmountResponse;
import com.reddot.ecrm.dto.attachment.AttachmentDTO;
import com.reddot.ecrm.dto.httpServletRequest.HttpServletRequestDto;
import com.reddot.ecrm.entity.approval.ApprovalFlowEntity;
import com.reddot.ecrm.entity.approval.ApprovalRequestEntity;
import com.reddot.ecrm.entity.attachment.AttachmentEntity;
import com.reddot.ecrm.entity.company.CompanyAccountEntity;
import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.enum_config.approval.ApprovalEnum;
import com.reddot.ecrm.enum_config.approval.ApprovalForEnum;
import com.reddot.ecrm.enum_config.bulk.BulkProcessFileTypeEnum;
import com.reddot.ecrm.enum_config.cr.CRStatusEnum;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.module.commonConfig.CommonConfigRepo;
import com.reddot.ecrm.repository.approval.ApprovalFlowRepo;
import com.reddot.ecrm.repository.attachment.AttachmentRepository;
import com.reddot.ecrm.repository.company.CompanyAccountRepo;
import com.reddot.ecrm.repository.company.CompanyRepository;
import com.reddot.ecrm.repository.cr.CRDetailsRepo;
import com.reddot.ecrm.service.SequenceGeneratorService;
import com.reddot.ecrm.service.approval.ApprovalRequestService;
import com.reddot.ecrm.service.attachment.AttachmentService;
import com.reddot.ecrm.spring_config.session.SessionManager;
import com.reddot.ecrm.util.Utility;
import com.reddot.ecrm.util.unique_id_generate.UniqueIDGenerator;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletRequest;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;

@Service
public class DepositService {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    private ApprovalFlowRepo approvalFlowRepo;

    @Autowired
    private ApprovalRequestService approvalRequestService;

    @Autowired
    private DepositRepo depositRepo;

    @Autowired
    private CompanyAccountRepo companyAccountRepo;

    @Autowired
    private CompanyRepository companyRepository;

    @Autowired
    private CommonConfigRepo commonConfigRepo;

    @Autowired
    private SmartAxiataAPI smartAxiataAPI;

    @Autowired
    private SequenceGeneratorService sequenceGeneratorService;

    @Autowired
    private AttachmentSourceService attachmentSourceService;

    @Autowired
    private CRDetailsRepo crDetailsRepo;

    @Autowired
    private AttachmentRepository attachmentRepository;

    @Autowired
    private AttachmentService attachmentService;

    public ResponseEntity<?> getAllDepositList() {
        return null;
    }

    public ResponseEntity<?> getAllCompany(HttpServletRequest httpServletRequest) {
        System.out.println(httpServletRequest.getSession().getId());
        List<CompanyEntity> list = companyRepository.findAll();
        return new ResponseEntity<>(list, HttpStatus.OK);
    }

    public String getDepositBalance(Long companyId, HttpServletRequest request) {
        AtomicReference<Long> totalBalance = new AtomicReference<>(0L);
        List<CompanyAccountEntity> companyAccountEntityList = companyAccountRepo.findAllByCompanyIdAndIsParentCorporateAccount(companyId, true);
        if (!CollectionUtils.isEmpty(companyAccountEntityList)) {
            companyAccountEntityList.forEach(data -> {
                ThirdPartyReqBody reqBody = new ThirdPartyReqBody();
                reqBody.setCompanyAccountCode(data.getAccountCode());
                GetAmountFromThirdPartyResp resp = getAmountFromTirdParty(reqBody);
                totalBalance.updateAndGet(v -> v + Long.parseLong(resp.getCurrentDepositAmount()));
            });
            return String.valueOf(totalBalance);
        }
        return String.valueOf(0);
    }

    public ResponseEntity<?> getAllMasterAccByCompanyId(HttpServletRequest httpServletRequest, GetAllMasterAccByCompanyIdReqBody reqBody) {
        List<CompanyAccountEntity> companyAccountEntityList = new ArrayList<>();
        companyAccountEntityList = companyAccountRepo.findAllByCompanyIdAndIsParentCorporateAccount(Long.valueOf(reqBody.getCompanyId()), true);
        return new ResponseEntity<>(companyAccountEntityList, HttpStatus.OK);
    }

    public ResponseEntity<?> getCompanyAccById(HttpServletRequest httpServletRequest, GetCompanyAccByIdReqBody reqBody) {
        CompanyAccountEntity companyAccountEntity = new CompanyAccountEntity();
        Optional<CompanyAccountEntity> companyAccountEntityOptional = companyAccountRepo.findById(Long.valueOf(reqBody.getId()));
        if (companyAccountEntityOptional.isPresent()) {
            companyAccountEntity = companyAccountEntityOptional.get();
        }
        return new ResponseEntity<>(companyAccountEntity, HttpStatus.OK);
    }

    public ResponseEntity<?> addDeposit(HttpServletRequest httpServletRequest, DepositAddReqBody reqBody) {
        Deposit deposit = new Deposit();
        /*
            public QueryDepositAmountResponse queryDepositAmount(String accountCode, String tranId) {
        return paymentGateway.queryDepositAmount(accountCode, tranId);
    }
         */

        //sequenceGeneratorService.generateSequenceNumberAsDateTime();

        // QueryDepositAmountResponse response = smartAxiataAPI.queryDepositAmount("reqBody.getCompanyAccountCode()", sequenceGeneratorService.generateSequenceNumberAsDateTime());

        deposit.setCompanyId(Long.valueOf(reqBody.getCompanyId()));
        deposit.setCompanyName(reqBody.getCompanyName());
        deposit.setActive(true);

        deposit.setCompanyAccountCode(reqBody.getCompanyAccountCode());

        deposit.setCurrentDepositAmount(Long.valueOf(reqBody.getCurrentDepositAmount()));
        deposit.setRequestedDepositAmount(Long.valueOf(reqBody.getRequestedDepositAmount()));
        deposit.setNewDepositAmount(Long.valueOf(reqBody.getNewDepositAmount()));

//        deposit.setStatusId(Long.valueOf(reqBody.getStatusId()));
//        deposit.setStatusName(reqBody.getStatusName());

        // String typeName = "Deposit";
        // String subtypeName = "Status";
        // String name = "Pending";

        // CommonConfig commonConfig = commonConfigRepo.findByTypeNameAndSubTypeNameAndName(typeName, subtypeName, name);

        // deposit.setStatusId(commonConfig.getId());
        // deposit.setStatusName(commonConfig.getName());

        deposit.setApprovalStatus(CRStatusEnum.Created.toString());
        deposit.setTransactionNo("deposit:" + System.currentTimeMillis());

        deposit.setCreatedAt(System.currentTimeMillis());
        deposit.setCreatedAtDt(new Timestamp(System.currentTimeMillis()));
        deposit.setCreatedBy(Utility.loggedInId(httpServletRequest));
        deposit.setCreatedByUsername(Utility.getLoginName(httpServletRequest));


        //
//        CRMasterEntity crMasterEntity = new CRMasterEntity();
//        crMasterEntity.setCompanyId(Long.valueOf(reqBody.getCompanyId()));
//        crMasterEntity.setCompanyName(reqBody.getCompanyName());
//        crMasterEntity.setRequestType("Deposit");
//        crMasterEntity.setTransactionID("depo" + System.currentTimeMillis());
//        crMasterEntity.setCreatedAt(System.currentTimeMillis());
//        crMasterEntity.setCreatedAtDt(new Timestamp(System.currentTimeMillis()));
//        crMasterEntity.setCreatedBy(Utility.loggedInId(httpServletRequest));
//        crMasterEntity.setCreatedUsername(Utility.getLoginName(httpServletRequest));
//        crMasterEntity.setRequestedDate(LocalDate.now());
//        crMasterEntity.setStatus(CRStatusEnum.Created.toString());
        //

        depositRepo.save(deposit);

        // Attachment Save
        MDUserModel user = SessionManager.getUserDetails(httpServletRequest);
        ModelMapper mapper = new ModelMapper();
        List<AttachmentEntity> attachmentEntityList = new ArrayList<>();
        List<AttachmentDTO> attachmentDTOList = reqBody.getAttachmentList();
        for (AttachmentDTO attachmentDTO : attachmentDTOList) {

            AttachmentEntity attachment = new AttachmentEntity();
            mapper.map(attachmentDTO, attachment);
            attachment.setIsFinalSave(true);  //final save so make this true
            attachment.setCreateBy(user.getID().toString());
            attachment.setCreateByName(user.getLOGIN_NAME());
            attachment.setModulePrimaryId(deposit.getId());
            attachment.setModuleTableName(BulkProcessFileTypeEnum.Deposit.getKey());
            attachmentEntityList.add(attachment);

        }

        if (attachmentEntityList.size() > 0) {
            attachmentRepository.saveAll(attachmentEntityList);
        }
        // Attachment Save End

        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        // about to remove
        checkApproval(deposit, httpServletRequest, attachmentDTOList);

        if (deposit.getApprovalStatus().equals(CRStatusEnum.Created.toString())) {
            Optional<CompanyAccountEntity> companyAccountEntity = companyAccountRepo.findByAccountCode(deposit.getCompanyAccountCode());
            if (companyAccountEntity.isPresent()) {
                companyAccountEntity.get().setDeposit(deposit.getNewDepositAmount());
                companyAccountRepo.saveAndFlush(companyAccountEntity.get());
            }
        }

        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        return new ResponseEntity<>("success", HttpStatus.OK);
    }


    private void checkApproval(Deposit deposit, HttpServletRequest httpServletRequest, List<AttachmentDTO> attachmentDTOList) {
        Boolean HasApproval = false;
        String transactionId = UniqueIDGenerator.getNextUniqueNumberOnly();
        Long tenantId = Utility.loggedInTenantId(httpServletRequest);
        try {
            ApprovalRequestEntity approvalRequestEntity = new ApprovalRequestEntity();
            Optional<ApprovalFlowEntity> approvalFlowEntity = approvalFlowRepo.findByNameAndTenantId(ApprovalEnum.Deposit_Approval.getKey(), tenantId);
            if (approvalFlowEntity.isPresent()) {
                approvalRequestEntity.setApprovalFlowId(approvalFlowEntity.get().getId());
                approvalRequestEntity.setApprovalFlowName(ApprovalEnum.Deposit_Approval.getKey());
                approvalRequestEntity.setHasRequestedAmount(false);
                approvalRequestEntity.setApprovalFor(ApprovalForEnum.Deposit_Approval.getKey());
                approvalRequestEntity.setIsCategoryType(false);
                approvalRequestEntity.setTransactionNumber(deposit.getTransactionNo());
                approvalRequestEntity.setRequestDetailsId(deposit.getId());
                approvalRequestEntity.setRequestTransactionId(transactionId);
                approvalRequestEntity.setCompanyName(deposit.getCompanyName());
                String description = "";

                if (!Objects.isNull(deposit)) {
                    approvalRequestEntity.setRequestedAmount(deposit.getRequestedDepositAmount().doubleValue());
                    HasApproval = true;
                }

                if (attachmentDTOList.size() > 0) {
                    approvalRequestEntity.setHasAttachment(true);
                }

                if (HasApproval) {
                    description = "Company Name: " + deposit.getCompanyName() +
                            "\nAccount Code: " + deposit.getCompanyAccountCode() +
                            "\nDeposit Amount: $" + deposit.getRequestedDepositAmount();
                    approvalRequestEntity.setRequestDescription(description);
                    HttpServletRequestDto request = Utility.createHttpServletDTO(httpServletRequest);
                    HasApproval = (Boolean) approvalRequestService.addRequestData(approvalRequestEntity, request).getData();
                    deposit.setApprovalStatus(CRStatusEnum.Pending.toString());
                    depositRepo.saveAndFlush(deposit);
                }

            } else {
                logger.info("%s Approval Flow not exists.", ApprovalEnum.Deposit_Approval.getKey());
            }

        } catch (Exception e) {
            logger.error(String.format("Deposit Service:ApprovalCheckForDeposit() Error: %s", e.getMessage()));
        }
    }

    public DataTablesOutput<Deposit> searchDT(DataTablesInput input, DepositSearchReqDTO reqBody) {
        int start = input.getStart();
        int length = input.getLength();
        int page = start / length;

        Pageable pageable = PageRequest.of(page, length, Sort.by("id").descending());
        DataTablesOutput<Deposit> output = new DataTablesOutput<>();
        Page<Deposit> responseData;

        responseData = depositRepo.findAll(new Specification<Deposit>() {
            @Override
            public Predicate toPredicate(Root<Deposit> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
                List<Predicate> predicates = new ArrayList<>();
//                if (!reqBody.getStatusId().equals("")) {
//                    Optional<CommonConfig> configOptional = commonConfigRepo.findById(Long.valueOf(reqBody.getStatusId()));
//                    predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("statusName"), configOptional.get().getName())));
//                }
//                if (!reqBody.getCompanyAccountCode().equals("")) {
//                    predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("companyAccountCode"), Long.valueOf(reqBody.getCompanyAccountCode()))));
//                }

                boolean isNull = Objects.equals(null, reqBody.getCompanyId());

//                if (!(reqBody.getCompanyId().equals(""))) {
                if (!isNull && !reqBody.getCompanyId().equals("")) {
                    predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("companyId"), Long.valueOf(reqBody.getCompanyId()))));
                }
//                if (!reqBody.getCompanyId().equals("") || !reqBody.getCompanyId().equals(null)) {
//                    predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("companyId"), Long.valueOf(reqBody.getCompanyId()))));
//                }
                if (!reqBody.getCompanyAccountCode().equals("")) {
                    predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("companyAccountCode"), reqBody.getCompanyAccountCode())));
                }
                if (!reqBody.getApprovalStatus().equals("")) {
                    predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("approvalStatus"), reqBody.getApprovalStatus())));
                }
                return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
            }
        }, pageable);

        output.setData(responseData.getContent());
        output.setRecordsFiltered(responseData.getTotalElements());
        output.setRecordsTotal(responseData.getTotalElements());

        output.setData(output.getData());
        output.setDraw(input.getDraw());

        return output;
    }

    private GetAmountFromThirdPartyResp getAmountFromTirdParty(ThirdPartyReqBody reqBody) {
        long total = 0;

        QueryDepositAmountResponse thirdPartyResponse = smartAxiataAPI.queryDepositAmount(reqBody.getCompanyAccountCode(), "DEP-" + SequenceGeneratorService.generateSequenceNumberAsDateTime());
        //QueryDepositAmountResponse thirdPartyResponse = smartAxiataAPI.queryDepositAmount("2.3222239", "Teng20230619135601");

        List<QueryDepositAmountResponse.Data.QueryBalance.AcctList.BalanceResult> balanceResultList;

        balanceResultList = thirdPartyResponse.getData().getQueryBalance().getAcctList().getBalanceResult();

        for (QueryDepositAmountResponse.Data.QueryBalance.AcctList.BalanceResult balanceResult : balanceResultList) {
            if (balanceResult.getBalanceType().equals("C_DEPOSIT_ACCOUNT")) {
                System.out.println(Long.valueOf(balanceResult.getTotalAmount()));
                total = total + Long.valueOf(balanceResult.getTotalAmount());
                total = (total / 100000000);
            }
        }

        GetAmountFromThirdPartyResp resp = new GetAmountFromThirdPartyResp();
        resp.setCurrentDepositAmount(String.valueOf(total));
        return resp;
    }

    public ResponseEntity<?> getThirdPartyData(HttpServletRequest httpServletRequest, ThirdPartyReqBody reqBody) {
        GetAmountFromThirdPartyResp resp = getAmountFromTirdParty(reqBody);
        return new ResponseEntity<>(resp, HttpStatus.OK);
    }

    public ResponseEntity<?> getDepositeRowByID(HttpServletRequest httpServletRequest, GetDepositeRowByIdReqBody reqBody) {
        Optional<Deposit> depositOptional = depositRepo.findById(Long.valueOf(reqBody.getDepositeRowID()));
        if (depositOptional.isPresent()) {
            Deposit deposit = depositOptional.get();
            return new ResponseEntity<>(deposit, HttpStatus.OK);
        }
        return new ResponseEntity<>(null, HttpStatus.OK);
    }

    public DataTablesOutput<Deposit> getAllDepositChildData(HttpServletRequest httpServletRequest, DataTablesInput input, GetDepositeRowByIdReqBody reqBody) {
        int start = input.getStart();
        int length = input.getLength();
        int page = start / length;

        Pageable pageable = PageRequest.of(page, length, Sort.by("id").descending());

        DataTablesOutput<Deposit> output = new DataTablesOutput<>();
        Page<Deposit> responseData = null;

        responseData = depositRepo.findById(Long.valueOf(reqBody.getDepositeRowID()), pageable);

        output.setData(responseData.getContent());

        return output;
    }

    public List<AttachmentEntity> getAllDepositAttachment(HttpServletRequest httpServletRequest, GetDepositeRowByIdReqBody reqBody) {
        List<AttachmentEntity> attachmentEntityList = new ArrayList<>();
        attachmentEntityList = attachmentService.findAllByModuleIdAndModuleName(Long.valueOf(reqBody.getDepositeRowID()), "Deposit");
        if (!CollectionUtils.isEmpty(attachmentEntityList)) {
            return attachmentEntityList;
        }
        return attachmentEntityList;
    }

}
