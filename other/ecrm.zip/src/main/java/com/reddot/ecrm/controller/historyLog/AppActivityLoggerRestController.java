package com.reddot.ecrm.controller.historyLog;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.entity.logger.APILogger;
import com.reddot.ecrm.entity.logger.ActivityLoggerDTO;
import com.reddot.ecrm.entity.logger.AppActivityLogger;
import com.reddot.ecrm.service.historyLog.AppActivityLoggerService;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/log/activity")
public class AppActivityLoggerRestController {
    private final AppActivityLoggerService service;

    @PostMapping("/DT")
    public DataTablesOutput<AppActivityLogger> activityDataTable(@RequestBody Map<String, Object> reqBody){
        DataTablesInput input = new Gson().fromJson(Utility.ObjectToJson(reqBody.get("input")), new TypeToken<DataTablesInput>(){}.getType());
        ActivityLoggerDTO appLogger = new Gson().fromJson(Utility.ObjectToJson(reqBody.get("appLogger")), new TypeToken<ActivityLoggerDTO>(){}.getType());

        return service.getAllDataTable(input, appLogger);
    }
}
