package com.reddot.ecrm.api.payload.response.transferOwnership;

import lombok.Data;

import java.io.Serializable;

@Data
public class ChangeSubscriberStatusErrorResponse implements Serializable {

    private String code;

    private String message;

    private String variables;
}
