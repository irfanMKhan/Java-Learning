package com.reddot.ecrm.controller.cr.increase_decrese_credit_limit;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.reddot.ecrm.dto.cr.CRSummarySearchDTO;
import com.reddot.ecrm.dto.cr.CRWithBillMediumDTO;
import com.reddot.ecrm.entity.cr.CRMsisdnDetailsEntity;
import com.reddot.ecrm.enum_config.bulk.BulkProcessFileTypeEnum;
import com.reddot.ecrm.enum_config.feature.RequestTypeEnum;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.attachment.implementation.AttachmentServiceImplementation;
import com.reddot.ecrm.service.cr.increase_decrease_CL.IncreaseDecreaseCLService;
import com.reddot.ecrm.service.cr.add_remove_service.AddRemoveService;
import com.reddot.ecrm.service.cr.change_plan.ChangePlanService;
import com.reddot.ecrm.util.LocalDateTypeAdapter;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.IOException;
import java.time.LocalDate;

@RestController
@RequestMapping("/cr/increaseDecrease/creditLimit/rest")
@RequiredArgsConstructor
public class IncreaseDecreaseCLRest {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    private final AttachmentServiceImplementation attachmentServiceImplementation;
    @Autowired
    AddRemoveService addRemoveService;
    @Autowired
    ChangePlanService changePlanService;

    @Autowired
    IncreaseDecreaseCLService increaseDecreaseCLService;
    @GetMapping("/summary/getAllData")
    public DataTablesOutput<CRMsisdnDetailsEntity> getAllSummaryData(
            HttpServletRequest request,
            @Valid DataTablesInput input,
            @RequestParam(value = "searchDto", required = false) String searchDtoJson
    ) {
        CRSummarySearchDTO searchDTO = null;
        if (searchDtoJson != null) {
            try {
                Gson gson = new GsonBuilder()
                        .registerTypeAdapter(LocalDate.class, new LocalDateTypeAdapter())
                        .create();
                searchDTO = gson.fromJson(searchDtoJson, CRSummarySearchDTO.class);

            } catch (Exception e) {
                System.out.println(e.getMessage());
                logger.error(String.format("IncreaseDecreaseCLRest:getAllSummaryData() Error: %s", e.getMessage()));
            }
        }
        return changePlanService.getSummaryQueryDataCommon(request, input, searchDTO, RequestTypeEnum.Increase_Decrease_Credit_Limit);
    }

    @PostMapping("/saveAllData")
    public CommonRestResponse saveAllData(@RequestBody CRWithBillMediumDTO dto, HttpServletRequest request) {
        return increaseDecreaseCLService.addCRDetailsData(dto, request, RequestTypeEnum.Increase_Decrease_Credit_Limit);
    }


    @PostMapping("/getCompany")
    public CommonRestResponse getCompanyByCompanyName(@RequestBody String companyName, HttpServletRequest request) {
        return increaseDecreaseCLService.getCompanyByCompanyName(companyName);
    }


    @PostMapping("/upload/bulkFile")
    public CommonRestResponse bulkUpload(HttpServletRequest request, @RequestParam("file") MultipartFile file,
                                         @RequestParam("processNow") String processNow, @RequestParam("companyName") String companyName,
                                         @RequestParam("processDate") String processDate, @RequestParam("companyId") String companyId
    ) throws ServletException, IOException {
        return increaseDecreaseCLService.addNewNumbersBulkUpload(request, file, processDate, processNow, companyId, companyName);
    }

    @PostMapping("/getAll/attachmentByMasterID")
    public CommonRestResponse getAllAttachmentByMasterID(@RequestBody Long crMasterID, HttpServletRequest request) {
        return attachmentServiceImplementation.getAllAttachmentByMasterID(crMasterID, BulkProcessFileTypeEnum.Increase_Decrease_Credit_Limit);
    }
}
