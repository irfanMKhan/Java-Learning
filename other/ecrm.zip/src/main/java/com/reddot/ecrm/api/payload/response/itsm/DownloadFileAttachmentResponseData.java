package com.reddot.ecrm.api.payload.response.itsm;

import lombok.Data;

@Data
public class DownloadFileAttachmentResponseData {
    private String data;
}
