package com.reddot.ecrm.api.payload.request.post2pre;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
public class PostpaidToPrepaidRequest implements Serializable {
    private NewPrimaryOffering NewPrimaryOffering;

    private ReqHeader ReqHeader;

    @Data
    @AllArgsConstructor
    public static class NewPrimaryOffering implements Serializable {
        private String OfferingId;
    }

    @Data
    public static class ReqHeader implements Serializable {
        private String ReqTime;

        private String Version;

        private String Channel;

        private String AccessPassword;

        private String PartnerId;

        private String TransactionId;

        private String AccessUser;
    }
}