package com.reddot.ecrm.controller.cr.increase_decrese_credit_limit;

import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.entity.cr.CRMsisdnDetailsEntity;
import com.reddot.ecrm.enum_config.cr.CRStatusEnum;
import com.reddot.ecrm.enum_config.feature.RequestTypeEnum;
import com.reddot.ecrm.enum_config.cr.add_new_number.PaymentTerm;
import com.reddot.ecrm.enum_config.cr.add_new_number.ReservationStatus;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.repository.company.CompanyRepository;
import com.reddot.ecrm.repository.cr.CRMSISDNDetailsRepo;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Controller
@RequestMapping("/cr/increaseDecrease/creditLimit")
public class IncreaseDecreaseCLController {
    @Autowired
    CompanyRepository companyRepository;
    @Autowired
    CRMSISDNDetailsRepo crmsisdnDetailsRepo;

    @GetMapping
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        ReservationStatus[] reservationStatus = ReservationStatus.values();
        PaymentTerm[] paymentTerms = PaymentTerm.values();

        String dateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        dateTime = dateTime.substring(1, dateTime.length());
        System.out.println(dateTime);

        dateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        dateTime = dateTime.substring(2, dateTime.length());
        System.out.println(dateTime);
        System.out.println(dateTime.length());

        List<CompanyEntity> companyList = companyRepository.findAllByActiveAndContractStatus(true, 2);

        Boolean isPIC = false;
        MDUserModel mdUserModel = Utility.CheckPICAndReturnUserDetails(request);
        Long companyId = null;
        String companyName = null;

        if (mdUserModel != null) {
            isPIC = true;
            companyId = mdUserModel.getCOMPANY_ID();
            companyName = mdUserModel.getCOMPANY_NAME();
        }


        LocalDate today = LocalDate.now();
        List<CRMsisdnDetailsEntity> list = crmsisdnDetailsRepo.findAllByRequestTypeAndStatusAndEffectiveDateLessThanEqual(
                RequestTypeEnum.Increase_Decrease_Credit_Limit.getKey(), CRStatusEnum.Created.toString(), today);

        model.addAttribute("breadcrumb", "Increase/Decrease Credit Limit Summary");
        model.put("reservation_status", reservationStatus);
        model.put("payment_terms", paymentTerms);
        model.put("company_list", companyList);
        model.put("title", "Increase/Decrease Credit Limit");
        model.put("isPIC", isPIC);
        model.put("companyId", companyId);
        model.put("companyName", companyName);
        return "cr/increase_decrease_credit_limit/increase_decrease_credit_limit";
    }

    @GetMapping("/summary")
    public String viewPageSummary(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        ReservationStatus[] reservationStatus = ReservationStatus.values();
        PaymentTerm[] paymentTerms = PaymentTerm.values();
        List<CompanyEntity> companyList = companyRepository.findAllByActiveAndContractStatus(true, 2);

        model.put("reservation_status", reservationStatus);
        model.put("payment_terms", paymentTerms);
        model.put("company_list", companyList);
        model.addAttribute("breadcrumb", "Increase/Decrease Credit Limit Summary");
        model.put("title", "Increase/Decrease Credit Limit Summary");
        return "cr/increase_decrease_credit_limit/inc_dec_cl_summary";
    }

}
