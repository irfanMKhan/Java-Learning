package com.reddot.ecrm.delayPayment;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PromiseToPayResponseDTO {
    private String id;
    private String accountCode;
    private String transType;
    private String transactionId;
    private String primaryIdentity;
    private String agreedPaidDate;
    private String agreedPaidAmt;
    private String remark;
}
