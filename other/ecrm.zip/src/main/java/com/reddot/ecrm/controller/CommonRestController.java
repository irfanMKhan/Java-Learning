package com.reddot.ecrm.controller;

import com.reddot.ecrm.dto.DropDownDTO;
import com.reddot.ecrm.entity.attachment.AttachmentEntity;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.repository.attachment.AttachmentRepository;
import com.reddot.ecrm.service.CommonService;
import com.reddot.ecrm.service.DropDownService;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

@RestController
@RequiredArgsConstructor
@RequestMapping("/common/rest")
@Slf4j
public class CommonRestController {

    private final CommonService commonService;

    private final DropDownService dropDownService;
    private final AttachmentRepository attachmentRepository;

    @GetMapping("/download/errorDetailsTextFile")
    public ResponseEntity<?> getErrorDetailsTextFile() throws IOException {
        InputStreamResource file = new InputStreamResource(new FileInputStream(Utility.error_details_text_file_full_path));
        String filename = Utility.getCurrentTimestamp() + "_" + Utility.cr_ad_new_number_error_details_file_name;
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
                .contentType(MediaType.parseMediaType("text/plain"))
                .body(file);
    }

    @GetMapping("/download/errorDetailsExcelFile")
    public ResponseEntity<?> getErrorDetailsExcelFile() throws IOException {
        InputStreamResource file = new InputStreamResource(new FileInputStream(Utility.error_details_excel_file_full_path));
        String filename = Utility.getCurrentTimestamp() + "_" + Utility.cr_ad_new_number_error_details_excel_file_name;
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
                .contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
                .body(file);
    }


    @PostMapping("/checkFileExists")
    public CommonRestResponse checkFileName(@RequestBody String fileName, HttpServletRequest request) {
        return commonService.checkFileExists(fileName);
    }

    @PostMapping("/upload/file")
    public CommonRestResponse bulkUpload(HttpServletRequest request, @RequestParam("file") MultipartFile file,
                                         @RequestParam("uuid") String uuid, @RequestParam("processType") String processType,
                                         @RequestParam("processTypeId") String processTypeId,
                                         @RequestParam(value = "companyId", required = false) Long companyId,
                                         @RequestParam("companyName") String companyName
    ) throws ServletException, IOException {

        return commonService.uploadFile(request, file, uuid, processType, processTypeId, companyId, companyName);
    }

    @DeleteMapping("/remove/file/{id}")
    public CommonRestResponse removeFile(@PathVariable("id") Long attachmentId) {
        return commonService.removeFile(attachmentId);
    }

    @PostMapping("/upload/file/attachment")
    public CommonRestResponse attachmentUpload(HttpServletRequest request, @RequestParam("file") MultipartFile file,
                                               @RequestParam("uuid") String uuid, @RequestParam("processType") String processType,
                                               @RequestParam(value = "companyId", required = false) Long companyId,
                                               @RequestParam(value = "companyName") String companyName

    ) throws ServletException, IOException {
        String processTypeId = null;
//        String processType = "";
        return commonService.uploadAttachmentFile(request, file, uuid, processType, processTypeId, companyId, companyName);
    }

    @GetMapping("/download/attachment")
    public ResponseEntity<?> downloadAttachmentFile(@RequestParam("id") Long id) throws IOException {
        Optional<AttachmentEntity> attachmentEntity = attachmentRepository.findById(id);
        if (attachmentEntity.isPresent()) {
            InputStreamResource file = new InputStreamResource(new FileInputStream(attachmentEntity.get().getFileLocation()));
            if (file.exists()) {
                String filename = attachmentEntity.get().getName();
                return ResponseEntity.ok()
                        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
                        .contentType(MediaType.parseMediaType("text/plain"))
                        .body(file);
            } else {
                log.info("downloadAttachmentFile() No file Found where id {}.", id);
                return ResponseEntity.status(HttpStatus.NO_CONTENT)
                        .body("downloadAttachmentFile() Error: No file Found.");
            }

        } else {
            log.info("downloadAttachmentFile() attachmentEntity not found where id {}.", id);
            return null;
        }
    }

    @PostMapping("/delete/file")
    public CommonRestResponse deleteFileById(HttpServletRequest request, @RequestBody Long id) {

        return commonService.deleteFileById(request, id);
    }

    @PostMapping("/delete/file/attachment")
    public CommonRestResponse deleteAttachmentFileById(HttpServletRequest request, @RequestBody Long id) {
        return commonService.deleteAttachmentFileById(id);
    }


    @ResponseBody
    @GetMapping(value = "/dropdown", consumes = MediaType.APPLICATION_JSON_VALUE)
    public List<DropDownDTO> getSelectListByFieldId(String fieldName, HttpServletRequest request) {
        return dropDownService.getDropDownValue(fieldName, request);
    }

    @ResponseBody
    @GetMapping(value = "/dropdown/depend", consumes = MediaType.APPLICATION_JSON_VALUE)
    public List<DropDownDTO> getSelectListByFieldIdDependentOnParentId(String fieldName, String parentFieldName, Long parentId) {
        return dropDownService.getDropDownValue(fieldName, parentFieldName, parentId);
    }
}


