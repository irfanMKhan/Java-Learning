package com.reddot.ecrm.controller.lead.settings;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.UserModel;
import com.reddot.ecrm.module.commonConfig.CommonConfigRepo;
import com.reddot.ecrm.repository.lead.settings.MappedSubIndustryRepository;
import com.reddot.ecrm.service.user.UserService;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("lead/industryMapping")
public class IndustryMappingController {

    @Autowired
    CommonConfigRepo commonConfigRepo;

    @Autowired
    MappedSubIndustryRepository mappedSubIndustryRepository;

    
    @Autowired
    private UserService userService;
    
    @RequestMapping(value = "", method = RequestMethod.GET)
    public String viewSubIndustries(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        
        model.addAttribute("title", "Industry Mapping");
        model.addAttribute("industries", commonConfigRepo.findAllByTypeIdAndSubTypeId(19l, 68l));
        model.addAttribute("breadcrumb", "Industry Mapping");
        
        return "lead/settings/industry_mapping_list";
    }
    
    @RequestMapping(value = "/manage", method = RequestMethod.GET)
    public String manageMapping(@RequestParam(name = "industryId", required = false) Long industryId,
                                ModelMap model,
                                HttpServletRequest request,
                                Principal principal) {
        new MenuViewer().setupSideMenu(model, request);
        
        List<UserModel> userData = new ArrayList<>();
        userData = new Gson().fromJson(Utility.ObjectToJson(userService.getUserByUserName(principal.getName())), new TypeToken<List<UserModel>>(){}
                .getType());
        
        model.addAttribute("userData", userData.get(0));
        model.addAttribute("title", "Manage Industry Mapping");
        model.addAttribute("industries", commonConfigRepo.findAllByTypeIdAndSubTypeId(19l, 68l));
        model.addAttribute("subIndustries", commonConfigRepo.findAllByTypeIdAndSubTypeId(19l, 69l));
        model.addAttribute("breadcrumb", "Manage");

        if( industryId != null && industryId > 0 ) {
            model.addAttribute("industryId", industryId);
            model.addAttribute("mappedData", mappedSubIndustryRepository.findAllByIndustryIdAndIsActive(industryId,Boolean.TRUE));
        } else {
            model.addAttribute("industryId", 0);
            model.addAttribute("mappedData", new ArrayList<>());
        }


        return "lead/settings/industry_mapping_manage";
    }
    
}