package com.reddot.ecrm.controller.lead.settings;

import com.reddot.ecrm.dto.lead.settings.LeadStatusDto;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.lead.settings.LeadStatusService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequestMapping("lead/status")
public class LeadStatusRestController {
    
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    
    @Autowired
    private LeadStatusService leadStatusService;
    
    @GetMapping("/dt/all")
    public DataTablesOutput<LeadStatusDto> dtLeadStatus(@Valid DataTablesInput input, HttpServletRequest request,
                                                         @RequestParam(value = "searchText", required = false) String searchText, @RequestParam(value = "searchCol", required = false) String searchCol) {
        return leadStatusService.getDTLeadStatus(input, request, searchText, searchCol);
    }
    
    @PostMapping("/add")
    public CommonRestResponse addLeadStatus(HttpServletRequest request, @RequestBody LeadStatusDto leadStatusDto) {
        return leadStatusService.addLeadStatus(request, leadStatusDto);
    }
    
    @GetMapping("/details")
    public CommonRestResponse getLeadStatusById(@RequestParam("id") Long id) {
        return leadStatusService.getLeadStatusById(id);
    }
    
    @PostMapping("/update")
    public CommonRestResponse updateLeadStatus(HttpServletRequest request,
                                                 @RequestBody LeadStatusDto leadStatusDto) {
        return leadStatusService.updateLeadStatus(request, leadStatusDto);
    }

}
