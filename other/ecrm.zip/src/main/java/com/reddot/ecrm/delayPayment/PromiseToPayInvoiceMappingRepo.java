package com.reddot.ecrm.delayPayment;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PromiseToPayInvoiceMappingRepo extends JpaRepository<PromiseToPayInvoiceMapping, Long> {
    List<PromiseToPayInvoiceMapping> findAllByPromiseToPayId(Long aLong);

    void deleteAllByPromiseToPayId(Long id);
}
