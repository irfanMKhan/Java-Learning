package com.reddot.ecrm.dto.company;

import com.reddot.ecrm.entity.company.CompanyAccountEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CompanyAccountDTO implements Serializable {
    private String companyName;
    private Long companyId;
    private String custId;
    private CompanyAccountEntity parentAccount;
    private CompanyAccountEntity cugAccount;
    private List<Map<String, ServiceLevelData>> serviceNameAndDetailsMapList;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ServiceLevelData {
        private CompanyAccountEntity serviceAccount;
        private CompanyAccountEntity serviceSubscriber;
        private List<Map<String, BranchLevelData>> branchNameAndDetailsMapList;

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class BranchLevelData {
            private CompanyAccountEntity branchAccount;
            private CompanyAccountEntity branchSubscriber;
        }
    }
}
