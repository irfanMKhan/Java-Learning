package com.reddot.ecrm.controller.settings;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.model.settings.ClassTypeModel;
import com.reddot.ecrm.service.settings.BankService;
import com.reddot.ecrm.service.settings.ClassTypeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequestMapping("/settings")
public class ClassTypeRestController {
    private final Logger logger = LoggerFactory.getLogger(ClassTypeRestController.class);
    @Autowired
    private ClassTypeService classTypeService;

    @Autowired
    private BankService bankService;

    @GetMapping("/dt/classType")
    public DataTablesOutput<ClassTypeModel> dtClassType(@Valid DataTablesInput input, HttpServletRequest request, @RequestParam(value = "searchText", required = false) String searchText, @RequestParam(value = "searchCol", required = false) String searchCol) {
        return classTypeService.getDTClasType(input, request, searchText, searchCol);
    }

    @PostMapping("/classType/add")
    public String addUsers(HttpServletRequest request, @RequestParam("classTypeData") String classTypeData) {
        try {
            ClassTypeModel classTypeModel = new Gson().fromJson(classTypeData, new TypeToken<ClassTypeModel>() {
            }.getType());
            if(classTypeModel.getNAME() == null || classTypeModel.getNAME().isEmpty()){
                return "Please enter a name!";
            }
            return classTypeService.addClassType(request, classTypeModel);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Class Type Adding Error");
            logger.error(e.getMessage(), e);
            return "Failed! Try later.";
        }
    }

    @RequestMapping(value = "/classType/update", method = RequestMethod.POST)
    public String updateUser(HttpServletRequest request, @RequestParam("classTypeData") String classTypeData) {
        try {
            ClassTypeModel classTypeModel = new Gson().fromJson(classTypeData, new TypeToken<ClassTypeModel>() {
            }.getType());

            if(classTypeModel.getNAME() == null || classTypeModel.getNAME().isEmpty()){
                return "Please enter a name!";
            }
            return classTypeService.updateClassType(classTypeModel, request);

        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Update Error");
            logger.error(e.getMessage(), e);
            return "Update Failed! Please Try later.";
        }
    }
}
