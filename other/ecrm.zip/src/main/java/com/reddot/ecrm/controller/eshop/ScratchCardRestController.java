package com.reddot.ecrm.controller.eshop;

import com.reddot.ecrm.entity.eshop.ScratchCard;
import com.reddot.ecrm.service.eshop.ScratchCardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.security.Principal;

@RestController
@RequestMapping("/crm/eShop")
public class ScratchCardRestController {

    @Autowired
    private ScratchCardService scratchCardService;

    @GetMapping("/dataTable/scratchCardData")
    public DataTablesOutput<ScratchCard> scratchCardData(@Valid DataTablesInput input, HttpServletRequest request, @RequestParam(value = "searchText", required = false) String searchText, @RequestParam(value = "searchCol", required = false) String searchCol, @RequestParam(value = "scratchCardPurchaseNo", required = false) String purchaseNo) {
        return scratchCardService.getDataTableScratchCard(input, request, searchText, searchCol, purchaseNo);
    }

    @GetMapping(value = "/deleteScratchCardData")
    public String deleteScratchCardData(ModelMap model, HttpServletRequest request, Principal principal, @RequestParam(value = "id", required = false) Long id) {
        return scratchCardService.deleteScratchCardById(id);
    }

    @PostMapping("/addScratchCard")
    public String addScratchCard(HttpServletRequest request, @RequestBody ScratchCard data) {
        return scratchCardService.addScratchCard(request, data);
    }
}
