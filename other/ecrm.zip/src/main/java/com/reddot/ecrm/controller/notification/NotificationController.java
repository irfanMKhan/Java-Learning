package com.reddot.ecrm.controller.notification;

import com.reddot.ecrm.entity.approval.ApprovalFlowEntity;
import com.reddot.ecrm.entity.notification.NotificationEntity;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.service.notification.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/notification")
public class NotificationController {

    @Autowired
    NotificationService notificationService;


    @GetMapping
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        model.put("title", "Notification");
        return "notification/notification_list";
    }

    @GetMapping("/details")
    public String singleViewPage(@RequestParam("id") Long id, ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        NotificationEntity notification = notificationService.getSingleNotificationDetails(request, id);

        model.addAttribute("notificationEntity", notification);
        model.put("title", "Notification");
        model.addAttribute("breadcrumb", "Notification");
        return "notification/single_notification_details";
    }
}
