package com.reddot.ecrm.controller.UserGroup;

import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.service.userGroup.UserGroupService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping(value = "/userGroup", method = RequestMethod.GET)
public class UserGroupController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private UserGroupService service;

    @GetMapping("")
    public String getUserGroupPage(ModelMap model, HttpServletRequest request)
    {
        return "redirect:/userGroup/list";
    }

    @GetMapping({"/list"})
    public String getMenuListView(ModelMap model, HttpServletRequest request){
        new MenuViewer().setupSideMenu(model, request);
        model.addAttribute("title", "User Group");
        model.addAttribute("breadcrumb", "User Group");
        return "user_group/user_group_list";
    }

    @GetMapping("/add")
    public String getMenuAddView(ModelMap model, HttpServletRequest request){
        new MenuViewer().setupSideMenu(model, request);
        model.addAttribute("title", " Add User Group");
        model.addAttribute("breadcrumb", "Add User Group");
        return "user_group/user_group_add";
    }
}
