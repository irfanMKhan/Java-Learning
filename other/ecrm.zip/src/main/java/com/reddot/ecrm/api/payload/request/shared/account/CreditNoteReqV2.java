package com.reddot.ecrm.api.payload.request.shared.account;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class CreditNoteReqV2 {
    private String transaction_id;

    private AdjustmentRequest AdjustmentRequest;

    @Data
    public static class AdjustmentRequest implements Serializable {
        private String AdjustmentSerialNo;

        private AdjustmentRequest.InvoiceInfo InvoiceInfo;

        private Integer OpType;

        private String AdjustmentReasonCode;

        @Data
        public static class InvoiceInfo implements Serializable {
            private String InvoiceNo;

            private Integer AdjustmentAmt;

            private Integer CurrencyID;

            private Integer AdjustmentType;

        }
    }
}
