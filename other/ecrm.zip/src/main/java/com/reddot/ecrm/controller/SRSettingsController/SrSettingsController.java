package com.reddot.ecrm.controller.SRSettingsController;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.dto.srsettings.ActType.MDSrActTypeModel;
import com.reddot.ecrm.dto.srsettings.ActType.QueryMDSrActTypeModel;
import com.reddot.ecrm.dto.srsettings.ActionType.MDSrActionTypeModel;
import com.reddot.ecrm.dto.srsettings.ActionType.QueryMDSrActionTypeModel;
import com.reddot.ecrm.dto.srsettings.AnsType.MDSrAnsTypeModel;
import com.reddot.ecrm.dto.srsettings.AnsType.QueryMDSrAnsTypeModel;
import com.reddot.ecrm.dto.srsettings.Area.MDSrAreaModel;
import com.reddot.ecrm.dto.srsettings.Area.QueryMDSrAreaModel;
import com.reddot.ecrm.dto.srsettings.Priority.MDSrPriorityModel;
import com.reddot.ecrm.dto.srsettings.Priority.QueryMDSrPriorityModel;
import com.reddot.ecrm.dto.srsettings.QuesMgt.MDSrQuesMgtModel;
import com.reddot.ecrm.dto.srsettings.QuesMgt.QueryMDSrQuesMgtModel;
import com.reddot.ecrm.dto.srsettings.RootCause.MDSrRootCauseModel;
import com.reddot.ecrm.dto.srsettings.RootCause.QueryMDSrRootCauseModel;
import com.reddot.ecrm.dto.srsettings.ServiceType.MDSrServiceTypeModel;
import com.reddot.ecrm.dto.srsettings.ServiceType.QueryMDSrServiceTypeModel;
import com.reddot.ecrm.dto.srsettings.Severity.MDSrSeverityModel;
import com.reddot.ecrm.dto.srsettings.Severity.QueryMDSrSeverityModel;
import com.reddot.ecrm.dto.srsettings.Status.MDSrStatusModel;
import com.reddot.ecrm.dto.srsettings.Status.QueryMDSrStatusModel;
import com.reddot.ecrm.dto.srsettings.TBLDataShowModel;
import com.reddot.ecrm.dto.srsettings.Type.QueryMDSrTypeModel;
import com.reddot.ecrm.dto.srsettings.Type.SRTypeModel;
import com.reddot.ecrm.dto.srsettings.subarea.*;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.TitleModel;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.repository.SrTypeRepository;
import com.reddot.ecrm.repository.redisrepo.srsettings.RedisDBSrSettings;
import com.reddot.ecrm.util.QueryBuilder;
import com.reddot.ecrm.util.Utility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/settings/sr")
public class SrSettingsController {
    private final Logger logger = LoggerFactory.getLogger("SRSettingsLogger");

    TitleModel titleModel = new TitleModel();

    @Autowired
    private SrTypeRepository srtypeDAO;

    @Autowired
    private CommonRepository commonDAO;

    @Autowired
    private RedisDBSrSettings redisDBSrSettings;

    @RequestMapping(value = "/service-type", method = RequestMethod.GET)
    public String serviceController(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        QueryMDSrServiceTypeModel empList = new QueryMDSrServiceTypeModel();
        titleModel = new TitleModel("ECRM", "Settings", "Service Request", "", "Service Type");


        try {
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            String count = QueryBuilder.getCountWhereQuery(Utility.md_sr_service_type, new HashMap<String, Object>(), whereSearchType);
            logger.info(count);
            int ii = commonDAO.CommoNumberOfRow(count);

            String qry_fetch = QueryBuilder.getWherQueryPagination(Utility.md_sr_service_type, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
            logger.info(qry_fetch);
            Object srslist = commonDAO.getDataPostgres(qry_fetch);

            List<MDSrServiceTypeModel> servicetypeList = new Gson().fromJson(Utility.ObjectToJson(srslist), new TypeToken<List<MDSrServiceTypeModel>>() {
            }.getType());
            empList = new QueryMDSrServiceTypeModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), servicetypeList);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        model.addAttribute("viewDataModel", empList);
        model.addAttribute("title", titleModel);
        return "srsettings/serviceType";
    }

    @PostMapping(value = "/save_service_type")
    public String saveTicketType(HttpServletRequest request, MDSrServiceTypeModel MDSrServiceTypeModel, @RequestParam(defaultValue = "false") boolean checkbox, RedirectAttributes attributes) {

        MDSrServiceTypeModel.setNAME(MDSrServiceTypeModel.getNAME());
        MDSrServiceTypeModel.setCREATED_BY(Utility.getUserId(request).intValue());
        MDSrServiceTypeModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));
        long current_ts = Utility.getCurrentTimestamp();

        if (checkbox) {
            MDSrServiceTypeModel.setACTIVE(1);
        } else {
            MDSrServiceTypeModel.setACTIVE(2);
        }

        if (MDSrServiceTypeModel.getNAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Service Type"));
            return "redirect:" + "service-type";
        }


        Map<String, Object> searchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        searchData.put("NAME", MDSrServiceTypeModel.getNAME());
        whereSearchType.put("NAME", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_service_type, searchData, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Service Type"));
            return "redirect:" + "service-type";
        }


        Map<String, Object> insertData = new HashMap<String, Object>();
        insertData.put("NAME", MDSrServiceTypeModel.getNAME());
        insertData.put("CREATED_BY", Utility.getUserId(request));
        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
        insertData.put("CREATED_AT", current_ts);
        insertData.put("ACTIVE", MDSrServiceTypeModel.getACTIVE());
        insertData.put("UPDATED_BY", Utility.getUserId(request));
        insertData.put("UPDATED_AT", current_ts);
        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));

        boolean h = commonDAO.CommoInsert(Utility.md_sr_service_type, insertData, logger);
        if (h) {
            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "Service Type"));

            //Insert data to redis
//            redisDBSrSettings.syncMDSrServiceType();
        } else {
            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "Service Type"));
        }
        return "redirect:" + "service-type";
    }

    @PostMapping(value = "/update_service_type")
    public String UpdateTicketType(HttpServletRequest request, MDSrServiceTypeModel MDSrServiceTypeModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox) {

        if (MDSrServiceTypeModel.getNAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Service Type"));
            return "redirect:" + "service-type";
        }

        if (MDSrServiceTypeModel.getID() <= 0) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Service Type"));
            return "redirect:" + "service-type";
        }

        long current_ts = Utility.getCurrentTimestamp();
        MDSrServiceTypeModel.setNAME(MDSrServiceTypeModel.getNAME());
        MDSrServiceTypeModel.setUPDATED_BY(Utility.getUserId(request).intValue());
        MDSrServiceTypeModel.setUPDATED_AT(current_ts);
        MDSrServiceTypeModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
        if (checkbox) {
            MDSrServiceTypeModel.setACTIVE(1);
        } else {
            MDSrServiceTypeModel.setACTIVE(2);
        }


        Map<String, Object> search = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();

        search.put("ID!", MDSrServiceTypeModel.getID());
        whereSearchType.put("ID!", "AND");
        search.put("NAME", MDSrServiceTypeModel.getNAME());
        whereSearchType.put("NAME", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_service_type, search, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Service Type"));
            return "redirect:" + "service-type";
        }

        Map<String, Object> updateData = new HashMap<String, Object>();
        updateData.put("NAME", MDSrServiceTypeModel.getNAME());
        updateData.put("ACTIVE", MDSrServiceTypeModel.getACTIVE());
        updateData.put("UPDATED_BY", Utility.getUserId(request));
        updateData.put("UPDATED_AT", current_ts);
        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));

        Map<String, Object> whereData = new HashMap<String, Object>();
        whereData.put("ID", MDSrServiceTypeModel.getID());

        boolean h = commonDAO.CommoUpdate(Utility.md_sr_service_type, updateData, whereData, logger);
        if (h) {
            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "Service Type"));

            //Update data to redis
            MDSrServiceTypeModel.setUPDATED_BY(Utility.getUserId(request).intValue());
            MDSrServiceTypeModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
            MDSrServiceTypeModel.setUPDATED_AT(current_ts);
//            redisDBSrSettings.saveServiceType(MDSrServiceTypeModel);
        } else {
            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "Service Type"));
        }

        // update Type

        Map<String, Object> updateTypeData = new HashMap<String, Object>();
        updateTypeData.put("SR_SERVICE_TYPE_NAME", MDSrServiceTypeModel.getNAME());

        Map<String, Object> whereTypeData = new HashMap<String, Object>();
        whereTypeData.put("SR_SERVICE_TYPE_ID", MDSrServiceTypeModel.getID());

        boolean type_h = commonDAO.CommoUpdate(Utility.md_sr_type, updateTypeData, whereTypeData, logger);

        // update area

        Map<String, Object> updateAreaData = new HashMap<String, Object>();
        updateAreaData.put("SR_SERVICE_TYPE_NAME", MDSrServiceTypeModel.getNAME());

        Map<String, Object> whereAreaData = new HashMap<String, Object>();
        whereAreaData.put("SR_SERVICE_TYPE_ID", MDSrServiceTypeModel.getID());

        boolean area_h = commonDAO.CommoUpdate(Utility.md_sr_area, updateAreaData, whereAreaData, logger);

        // update sub area


        Map<String, Object> updateSubAreaData = new HashMap<String, Object>();
        updateSubAreaData.put("SR_SERVICE_TYPE_NAME", MDSrServiceTypeModel.getNAME());

        Map<String, Object> whereSubAreaData = new HashMap<String, Object>();
        whereSubAreaData.put("SR_SERVICE_TYPE_ID", MDSrServiceTypeModel.getID());

        boolean sub_area_h = commonDAO.CommoUpdate(Utility.md_sr_sub_area, updateSubAreaData, whereSubAreaData, logger);


        return "redirect:" + "service-type";
    }


    /*******************************	SR Type: Start  *******************************************************************/

    @RequestMapping(value = "/type", method = RequestMethod.GET)
    public String srType(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        QueryMDSrTypeModel empList = new QueryMDSrTypeModel();
        List<MDSrServiceTypeModel> serviceList = new ArrayList<>();
        titleModel = new TitleModel("ECRM", "Settings", "Service Request", "", "Type");

        try {
            Map<String, Object> SearchData = new HashMap<>();
            Map<String, Object> SrServiceTypeData = new HashMap<>();
            Map<String, Object> whereSearchType = new HashMap<>();
            Map<String, Object> whereSrServiceTypeData = new HashMap<>();

            String count = QueryBuilder.getCountWhereQuery(Utility.md_sr_type, new HashMap<>(), whereSearchType);
            logger.info(count);
            int ii = commonDAO.CommoNumberOfRow(count);

            String qry_fetch = QueryBuilder.getWherQueryPagination(Utility.md_sr_type, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
            logger.info(qry_fetch);
            Object stslist = commonDAO.getDataPostgres(qry_fetch);

            List<SRTypeModel> servicetypeList = new Gson().fromJson(Utility.ObjectToJson(stslist), new TypeToken<List<SRTypeModel>>() {
            }.getType());
            empList = new QueryMDSrTypeModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), servicetypeList);


            SrServiceTypeData.put("ACTIVE", 1);
            whereSrServiceTypeData.put("ACTIVE", "AND");


//             serviceList = redisDBSrSettings.getAllActiveServiceType(1);
            Object serviceType = commonDAO.getDataPostgres("SELECT * FROM " + Utility.md_sr_service_type + " WHERE ACTIVE=1");

            serviceList = new Gson().fromJson(Utility.ObjectToJson(serviceType), new TypeToken<List<MDSrServiceTypeModel>>() {
            }.getType());

        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        model.addAttribute("viewDataModel", empList);
        model.addAttribute("srserviceList", serviceList);
        model.addAttribute("title", titleModel);
        return "srsettings/type";
    }


    @PostMapping(value = "/save_type")
    public String saveSRType(HttpServletRequest request, SRTypeModel srtypemodel, @RequestParam(defaultValue = "false") boolean checkbox, RedirectAttributes attributes) {


        srtypemodel.setCREATED_BY(Utility.getUserId(request));
        srtypemodel.setCREATED_BY_USERNAME(Utility.getLoginName(request));
        long current_ts = Utility.getCurrentTimestamp();

        if (checkbox) {
            srtypemodel.setACTIVE(1);
        } else {
            srtypemodel.setACTIVE(2);
        }

        if (srtypemodel.getNAME().trim().isEmpty()) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "SR Type"));
            return "redirect:" + "type";
        }

        if (srtypemodel.getSR_SERVICE_TYPE_NAME().trim().isEmpty()) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Service Type"));
            return "redirect:" + "type";
        }


        String[] srSName = srtypemodel.getSR_SERVICE_TYPE_NAME().trim().split("/");
        srtypemodel.setSR_SERVICE_TYPE_NAME(srSName[1]);
        srtypemodel.setSR_SERVICE_TYPE_ID(Integer.parseInt(srSName[0]));


        Map<String, Object> searchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        searchData.put("NAME", srtypemodel.getNAME());
        whereSearchType.put("NAME", "AND");
        searchData.put("SR_SERVICE_TYPE_ID", Integer.parseInt(srSName[0]));
        whereSearchType.put("SR_SERVICE_TYPE_ID", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_type, searchData, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "SR Type"));
            return "redirect:" + "type";
        }


        Map<String, Object> insertData = new HashMap<String, Object>();
        insertData.put("NAME", srtypemodel.getNAME());
        insertData.put("SR_SERVICE_TYPE_ID", Integer.parseInt(srSName[0]));
        insertData.put("SR_SERVICE_TYPE_NAME", srSName[1]);
        insertData.put("CREATED_BY", Utility.getUserId(request));
        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
        insertData.put("CREATED_AT", current_ts);
        insertData.put("ACTIVE", srtypemodel.getACTIVE());
        insertData.put("UPDATED_BY", Utility.getUserId(request));
        insertData.put("UPDATED_AT", current_ts);
        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));


        boolean h = commonDAO.CommoInsert(Utility.md_sr_type, insertData, logger);
        if (h) {
            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "SR Type"));
//            redisDBSrSettings.syncMdSRTypeModel();
        } else {
            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "SR Type"));
        }


        return "redirect:" + "type";
    }


    @PostMapping(value = "/update_type")
    public String UpdateSRType(HttpServletRequest request, SRTypeModel srtypeModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox) {

        if (srtypeModel.getNAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "SR Type"));
            return "redirect:" + "type";
        }

        if (srtypeModel.getID() <= 0) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "SR Type"));
            return "redirect:" + "type";
        }

        long current_ts = Utility.getCurrentTimestamp();
        srtypeModel.setNAME(srtypeModel.getNAME());
        srtypeModel.setUPDATED_BY(Utility.getUserId(request));
        srtypeModel.setUPDATED_AT(current_ts);
        srtypeModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
        if (checkbox) {
            srtypeModel.setACTIVE(1);
        } else {
            srtypeModel.setACTIVE(2);
        }


        if (srtypeModel.getSR_SERVICE_TYPE_NAME().trim().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "SR Type"));
            return "redirect:" + "type";
        }


        String[] srSName = srtypeModel.getSR_SERVICE_TYPE_NAME().trim().split("/");
        srtypeModel.setSR_SERVICE_TYPE_NAME(srSName[1]);
        srtypeModel.setSR_SERVICE_TYPE_ID(Integer.parseInt(srSName[0]));


        Map<String, Object> search = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();

        search.put("NAME", srtypeModel.getNAME());
        whereSearchType.put("NAME", "AND");
        search.put("ID!", srtypeModel.getID());
        whereSearchType.put("ID!", "AND");
        search.put("SR_SERVICE_TYPE_ID", srtypeModel.getSR_SERVICE_TYPE_ID());
        whereSearchType.put("SR_SERVICE_TYPE_ID", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_type, search, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "SR Type"));
            return "redirect:" + "type";
        }


        Map<String, Object> updateData = new HashMap<String, Object>();
        updateData.put("NAME", srtypeModel.getNAME());
        updateData.put("SR_SERVICE_TYPE_ID", srtypeModel.getSR_SERVICE_TYPE_ID());
        updateData.put("SR_SERVICE_TYPE_NAME", srtypeModel.getSR_SERVICE_TYPE_NAME());
        updateData.put("ACTIVE", srtypeModel.getACTIVE());
        updateData.put("UPDATED_BY", Utility.getUserId(request));
        updateData.put("UPDATED_AT", current_ts);
        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));

        Map<String, Object> whereData = new HashMap<String, Object>();
        whereData.put("ID", srtypeModel.getID());

        boolean h = commonDAO.CommoUpdate(Utility.md_sr_type, updateData, whereData, logger);
        if (h) {
            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "SR Type"));
//            redisDBSrSettings.syncMdSRTypeModel();
        } else {
            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "SR Type"));
        }

        // update area
        Map<String, Object> upAreaData = new HashMap<String, Object>();
        upAreaData.put("SR_TYPE_NAME", srtypeModel.getNAME());

        Map<String, Object> whereArData = new HashMap<String, Object>();
        whereArData.put("SR_TYPE_ID", srtypeModel.getID());

        boolean area_h = commonDAO.CommoUpdate(Utility.md_sr_area, upAreaData, whereArData, logger);

        // update sub area

        Map<String, Object> upSubAreaData = new HashMap<String, Object>();
        upSubAreaData.put("SR_TYPE_NAME", srtypeModel.getNAME());

        Map<String, Object> whereSubArData = new HashMap<String, Object>();
        whereSubArData.put("SR_TYPE_ID", srtypeModel.getID());

        boolean sub_area_h = commonDAO.CommoUpdate(Utility.md_sr_sub_area, upSubAreaData, whereSubArData, logger);

        return "redirect:" + "type";
    }


    /*******************************	SR Type: End  *******************************************************************/

    /*******************************	SR Area : Start  *******************************************************************/

    @RequestMapping(value = "/area", method = RequestMethod.GET)
    public String areaController(HttpServletRequest request, ModelMap model) {
        new MenuViewer().setupSideMenu(model, request);

        QueryMDSrAreaModel SRAreaList = new QueryMDSrAreaModel();
        List<SRTypeModel> srtypeList = new ArrayList<>();
        List<MDSrServiceTypeModel> mdSrServiceTypeModels = new ArrayList<>();

        titleModel = new TitleModel("ECRM", "Settings", "Service Request", "", "SR Area");
        try {
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> SrTypeData = new HashMap<String, Object>();
            Map<String, Object> ServiceTypeData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            String count = QueryBuilder.getCountWhereQuery(Utility.md_sr_area, new HashMap<>(), whereSearchType);
            logger.info(count);
            int ii = commonDAO.CommoNumberOfRow(count);

            String qry_pagi = QueryBuilder.getWherQueryPagination(Utility.md_sr_area, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
            logger.info(qry_pagi);
            Object i = commonDAO.getDataPaginationPostgres(qry_pagi);

            List<MDSrAreaModel> areaList = new Gson().fromJson(Utility.ObjectToJson(i), new TypeToken<List<MDSrAreaModel>>() {
            }.getType());
            SRAreaList = new QueryMDSrAreaModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), areaList);

            SrTypeData.put("ACTIVE", 1);
            ServiceTypeData.put("ACTIVE", 1);
            whereSearchType.put("ACTIVE", "AND");

            String qry_sr_type = QueryBuilder.getSelectWhereQuery(Utility.md_sr_type, SrTypeData, whereSearchType);
            logger.info(qry_sr_type);
            Object srslist = commonDAO.getDataPostgres(qry_sr_type);

            srtypeList = new Gson().fromJson(Utility.ObjectToJson(srslist), new TypeToken<List<SRTypeModel>>() {
            }.getType());


            // mdSrServiceTypeModels = redisDBSrSettings.getAllActiveServiceType(1);
            Object dataPostgres = commonDAO.getDataPostgres("SELECT * FROM " + Utility.md_sr_service_type + " WHERE ACTIVE=1");
            mdSrServiceTypeModels = new Gson().fromJson(Utility.ObjectToJson(dataPostgres), new TypeToken<List<MDSrServiceTypeModel>>() {
            }.getType());

        } catch (Exception e) {
            logger.error(e.getMessage());
        }


        model.addAttribute("viewDataModel", SRAreaList);
        model.addAttribute("srtypeList", srtypeList);
        model.addAttribute("srServiceTypeList", mdSrServiceTypeModels);
        model.addAttribute("title", titleModel);
        return "srsettings/srArea";
    }


    @RequestMapping(value = "/subcategory", method = RequestMethod.GET)
    public String SubcategoryController(HttpServletRequest request, ModelMap model) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Sub-Area");
        return "ticketmanagement/SubCategoryview";
    }


    @PostMapping(value = "/save_sr_area")
    public String saveSRArea(HttpServletRequest request, MDSrAreaModel mdSrAreaModel, @RequestParam(defaultValue = "false") boolean checkbox, RedirectAttributes attributes) {

        System.out.println("mdSrAreaModel " + mdSrAreaModel);
        try {
            mdSrAreaModel.setCREATED_BY(Utility.getUserId(request));
            mdSrAreaModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));

            if (checkbox) {
                mdSrAreaModel.setACTIVE(1);
            } else {
                mdSrAreaModel.setACTIVE(2);
            }

            if (mdSrAreaModel.getNAME().trim().isEmpty()) {
                attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "SR Area"));
                return "redirect:" + "area";
            }

            if (mdSrAreaModel.getSR_SERVICE_TYPE_NAME().trim().isEmpty()) {
                attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Service Type"));
                return "redirect:" + "area";
            }

            if (mdSrAreaModel.getSR_TYPE_NAME().trim().isEmpty()) {
                attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "SR Type"));
                return "redirect:" + "area";
            }

            String[] srServiceTypeName = mdSrAreaModel.getSR_SERVICE_TYPE_NAME().trim().split("/");
            mdSrAreaModel.setSR_SERVICE_TYPE_NAME(srServiceTypeName[1]);
            mdSrAreaModel.setSR_SERVICE_TYPE_ID(Integer.parseInt(srServiceTypeName[0]));

            String[] srSRTypeName = mdSrAreaModel.getSR_TYPE_NAME().trim().split("/");
            mdSrAreaModel.setSR_TYPE_NAME(srSRTypeName[1]);
            mdSrAreaModel.setSR_TYPE_ID(Integer.parseInt(srSRTypeName[0]));


            Map<String, Object> SrServiceTypeData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            SrServiceTypeData.put("NAME", mdSrAreaModel.getNAME());
            whereSearchType.put("NAME", "AND");
            SrServiceTypeData.put("SR_SERVICE_TYPE_ID", srServiceTypeName[0]);
            whereSearchType.put("SR_SERVICE_TYPE_ID", "AND");
            SrServiceTypeData.put("SR_TYPE_ID", srSRTypeName[0]);
            whereSearchType.put("SR_TYPE_ID", "AND");

            String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_area, SrServiceTypeData, whereSearchType);
            logger.info(duplicateQry);
            int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
            if (TotalRows > 0) {
                attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "SR Area"));
                return "redirect:" + "area";
            }


            long current_ts = Utility.getCurrentTimestamp();
            Map<String, Object> insertData = new HashMap<>();
            insertData.put("NAME", mdSrAreaModel.getNAME());
            insertData.put("SR_SERVICE_TYPE_ID", Integer.parseInt(srServiceTypeName[0]));
            insertData.put("SR_SERVICE_TYPE_NAME", srServiceTypeName[1]);
            insertData.put("SR_TYPE_ID", Integer.parseInt(srSRTypeName[0]));
            insertData.put("SR_TYPE_NAME", srSRTypeName[1]);
            insertData.put("CREATED_BY", Utility.getUserId(request));
            insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
            insertData.put("CREATED_AT", current_ts);
            insertData.put("ACTIVE", mdSrAreaModel.getACTIVE());
            insertData.put("UPDATED_BY", Utility.getUserId(request));
            insertData.put("UPDATED_AT", current_ts);
            insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));

            boolean h = commonDAO.CommoInsert(Utility.md_sr_area, insertData, logger);

            if (h) {
                attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "SR Area"));
//                redisDBSrSettings.syncMDSrArea();
            } else {
                attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "SR Area"));
            }

        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return "redirect:" + "area";
    }


    @PostMapping(value = "/update_sr_area")
    public String UpdateSRType(HttpServletRequest request, MDSrAreaModel mdSrAreaModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox) {

        System.out.println("mdSrAreaModel " + mdSrAreaModel);

        if (mdSrAreaModel.getNAME().trim().isEmpty()) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "SR Area"));
            return "redirect:" + "area";
        }

        if (mdSrAreaModel.getSR_SERVICE_TYPE_NAME().trim().isEmpty()) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Service Type"));
            return "redirect:" + "area";
        }

        if (mdSrAreaModel.getSR_TYPE_NAME().trim().isEmpty()) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "SR Type"));
            return "redirect:" + "area";
        }

        if (mdSrAreaModel.getID() <= 0) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "SR Type"));
            return "redirect:" + "area";
        }

        long current_ts = Utility.getCurrentTimestamp();
        mdSrAreaModel.setNAME(mdSrAreaModel.getNAME());
        mdSrAreaModel.setUPDATED_BY(Utility.getUserId(request));
        mdSrAreaModel.setUPDATED_AT(current_ts);
        mdSrAreaModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
        if (checkbox) {
            mdSrAreaModel.setACTIVE(1);
        } else {
            mdSrAreaModel.setACTIVE(2);
        }


        String[] srServiceTypeName = mdSrAreaModel.getSR_SERVICE_TYPE_NAME().trim().split("/");
        mdSrAreaModel.setSR_SERVICE_TYPE_NAME(srServiceTypeName[1]);
        mdSrAreaModel.setSR_SERVICE_TYPE_ID(Integer.parseInt(srServiceTypeName[0]));

        String[] srSRTypeName = mdSrAreaModel.getSR_TYPE_NAME().trim().split("/");
        mdSrAreaModel.setSR_TYPE_NAME(srSRTypeName[1]);
        mdSrAreaModel.setSR_TYPE_ID(Integer.parseInt(srSRTypeName[0]));


        Map<String, Object> search = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();

        search.put("NAME", mdSrAreaModel.getNAME());
        whereSearchType.put("NAME", "AND");

        search.put("ID!", mdSrAreaModel.getID());
        whereSearchType.put("ID!", "AND");
        search.put("SR_SERVICE_TYPE_ID", mdSrAreaModel.getSR_SERVICE_TYPE_ID());
        whereSearchType.put("SR_SERVICE_TYPE_ID", "AND");
        search.put("SR_TYPE_ID", mdSrAreaModel.getSR_TYPE_ID());
        whereSearchType.put("SR_TYPE_ID", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_area, search, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "SR Area"));
            return "redirect:" + "area";
        }


        Map<String, Object> updateData = new HashMap<String, Object>();
        updateData.put("NAME", mdSrAreaModel.getNAME());
        updateData.put("SR_TYPE_ID", mdSrAreaModel.getSR_TYPE_ID());
        updateData.put("SR_TYPE_NAME", mdSrAreaModel.getSR_TYPE_NAME());
        updateData.put("SR_SERVICE_TYPE_ID", mdSrAreaModel.getSR_SERVICE_TYPE_ID());
        updateData.put("SR_SERVICE_TYPE_NAME", mdSrAreaModel.getSR_SERVICE_TYPE_NAME());
        updateData.put("ACTIVE", mdSrAreaModel.getACTIVE());
        updateData.put("UPDATED_BY", Utility.getUserId(request));
        updateData.put("UPDATED_AT", current_ts);
        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));

        Map<String, Object> whereData = new HashMap<String, Object>();
        whereData.put("ID", mdSrAreaModel.getID());

        boolean h = commonDAO.CommoUpdate(Utility.md_sr_area, updateData, whereData, logger);
        if (h) {
            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "SR Area"));
            redisDBSrSettings.syncMDSrArea();
        } else {
            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "SR Area"));
        }


        // update sub area
        Map<String, Object> upSubArData = new HashMap<String, Object>();
        upSubArData.put("SR_AREA_NAME", mdSrAreaModel.getNAME());

        Map<String, Object> whereSubArData = new HashMap<String, Object>();
        whereSubArData.put("SR_AREA_ID", mdSrAreaModel.getID());

        boolean sub_area_h = commonDAO.CommoUpdate(Utility.md_sr_sub_area, upSubArData, whereSubArData, logger);

        return "redirect:" + "area";
    }


    /*******************************	SR Sub Area : Start  *******************************************************************/

    @RequestMapping(value = "/subArea", method = RequestMethod.GET)
    public String getSubAreaView(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        QueryMDSrSubAreaModel SRAreaList = new QueryMDSrSubAreaModel();

        titleModel = new TitleModel("ECRM", "Settings", "Service Request", "", "Sub Area");
        try {
            Map<String, Object> SearchData = new HashMap<>();
            Map<String, Object> whereSearchType = new HashMap<>();
            int ii = commonDAO.CommoNumberOfRow(QueryBuilder.getCountWhereQuery(Utility.md_sr_sub_area, new HashMap<String, Object>(), whereSearchType));
            Object i = commonDAO.getDataPaginationPostgres(QueryBuilder.getWherQueryPagination(Utility.md_sr_sub_area, SearchData, 0, Utility.perPageDataLoad, whereSearchType));
            List<MDSrSubAreaModel> areaList = new Gson().fromJson(Utility.ObjectToJson(i), new TypeToken<List<MDSrSubAreaModel>>() {
            }.getType());
            SRAreaList = new QueryMDSrSubAreaModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), areaList);


        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }


        model.addAttribute("SRAreaList", SRAreaList);
        model.addAttribute("title", titleModel);
        return "srsettings/srSubArea";
    }

    @PostMapping(value = "/saveSubArea")
    public String saveSubArea(MDSrSubAreaModel mdSrSubAreaModel, RedirectAttributes attributes,
                              @RequestParam("accountClass") List<String> myParams,
                              @RequestParam("slahr") List<String> number,
                              @RequestParam("mdSrPriorityModels") List<String> Priority,
                              @RequestParam("accountTypeModels") List<String> accountType,
                              @RequestParam("notify_name") List<String> notifyName,
                              @RequestParam("notify_type") List<String> notifyType,
                              @RequestParam("escalation_number") List<String> escalationnumber,
                              @RequestParam("group_name") List<String> group_name,
                              @RequestParam("user_group_name") List<String> user_group_name,
                              @RequestParam("use_mail") List<String> user_mail,
                              @RequestParam("submittype") String submittype, HttpServletRequest request) {


        long current_tss = Utility.getCurrentTimestamp();
        Long current_ts = current_tss;
        if (mdSrSubAreaModel.getNAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Sub Area"));
            return "redirect:subArea";
        }

        if (mdSrSubAreaModel.getSR_AREA_NAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Area"));
            return "redirect:subArea";
        }

        mdSrSubAreaModel.setSR_AREA_ID(Integer.parseInt(mdSrSubAreaModel.getSR_AREA_NAME().split("/")[0]));
        mdSrSubAreaModel.setSR_AREA_NAME(mdSrSubAreaModel.getSR_AREA_NAME().split("/")[1]);

        if (mdSrSubAreaModel.getSR_SERVICE_TYPE_NAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Service Type"));
            return "redirect:subArea";
        }

        mdSrSubAreaModel.setSR_SERVICE_TYPE_ID(Integer.parseInt(mdSrSubAreaModel.getSR_SERVICE_TYPE_NAME().split("/")[0]));
        mdSrSubAreaModel.setSR_SERVICE_TYPE_NAME(mdSrSubAreaModel.getSR_SERVICE_TYPE_NAME().split("/")[1]);

        if (mdSrSubAreaModel.getSR_TYPE_NAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "SR Type"));
            return "redirect:subArea";
        }

        mdSrSubAreaModel.setSR_TYPE_ID(Integer.parseInt(mdSrSubAreaModel.getSR_TYPE_NAME().split("/")[0]));
        mdSrSubAreaModel.setSR_TYPE_NAME(mdSrSubAreaModel.getSR_TYPE_NAME().split("/")[1]);

        if (mdSrSubAreaModel.getSEVERITY_NAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Sub Area"));
            return "redirect:subArea";
        }

        mdSrSubAreaModel.setSEVERITY_ID(Integer.parseInt(mdSrSubAreaModel.getSEVERITY_NAME().split("/")[0]));
        mdSrSubAreaModel.setSEVERITY_NAME(mdSrSubAreaModel.getSEVERITY_NAME().split("/")[1]);


        if (mdSrSubAreaModel.getPRIORITY_NAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Sub Area"));
            return "redirect:subArea";
        }

        mdSrSubAreaModel.setPRIORITY_ID(Integer.parseInt(mdSrSubAreaModel.getPRIORITY_NAME().split("/")[0]));
        mdSrSubAreaModel.setPRIORITY_NAME(mdSrSubAreaModel.getPRIORITY_NAME().split("/")[1]);


        System.out.println(submittype);


        Map<String, Object> searchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        searchData.put("NAME", mdSrSubAreaModel.getNAME());
        whereSearchType.put("NAME", "AND");
        searchData.put("SR_SERVICE_TYPE_ID", mdSrSubAreaModel.getSR_SERVICE_TYPE_ID());
        whereSearchType.put("SR_SERVICE_TYPE_ID", "AND");
        searchData.put("SR_TYPE_ID", mdSrSubAreaModel.getSR_TYPE_ID());
        whereSearchType.put("SR_TYPE_ID", "AND");
        searchData.put("SR_AREA_ID", mdSrSubAreaModel.getSR_AREA_ID());
        whereSearchType.put("SR_AREA_ID", "AND");
        if (!submittype.equals("1")) {
            searchData.put("UNIQUE_ID !", submittype);
            whereSearchType.put("UNIQUE_ID !", "AND");
        }

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_sub_area, searchData, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Sub Area"));
            return "redirect:subArea";
        }

        Map<String, Object> insertData = new HashMap<>();
        insertData.put("NAME", mdSrSubAreaModel.getNAME());
        insertData.put("SR_SERVICE_TYPE_NAME", mdSrSubAreaModel.getSR_SERVICE_TYPE_NAME());
        insertData.put("SR_SERVICE_TYPE_ID", mdSrSubAreaModel.getSR_SERVICE_TYPE_ID());
        insertData.put("SR_TYPE_NAME", mdSrSubAreaModel.getSR_TYPE_NAME());
        insertData.put("SEVERITY_NAME", mdSrSubAreaModel.getSEVERITY_NAME());
        insertData.put("SEVERITY_ID", mdSrSubAreaModel.getSEVERITY_ID());
        insertData.put("PRIORITY_NAME", mdSrSubAreaModel.getPRIORITY_NAME());
        insertData.put("PRIORITY_ID", mdSrSubAreaModel.getPRIORITY_ID());
        insertData.put("SLA_HR", mdSrSubAreaModel.getSLA_HR());
        insertData.put("SR_TYPE_ID", mdSrSubAreaModel.getSR_TYPE_ID());
        insertData.put("SR_AREA_NAME", mdSrSubAreaModel.getSR_AREA_NAME());
        insertData.put("SR_AREA_ID", mdSrSubAreaModel.getSR_AREA_ID());
        insertData.put("ADDRESS_REQUIRED", mdSrSubAreaModel.getADDRESS_REQUIRED() == null ? 0 : mdSrSubAreaModel.getADDRESS_REQUIRED());
        insertData.put("HAS_SMART_SCRIPT", mdSrSubAreaModel.getHAS_SMART_SCRIPT() == null ? 0 : mdSrSubAreaModel.getHAS_SMART_SCRIPT());
        insertData.put("OWNER_ID", Integer.parseInt(mdSrSubAreaModel.getOWNER_GROUP_NAME().split("/")[2]));
        insertData.put("OWNER_NAME", mdSrSubAreaModel.getOWNER_GROUP_NAME().split("/")[3]);
        insertData.put("OWNER_GROUP_ID", Integer.parseInt(mdSrSubAreaModel.getOWNER_GROUP_NAME().split("/")[0]));
        insertData.put("OWNER_GROUP_NAME", mdSrSubAreaModel.getOWNER_GROUP_NAME().split("/")[1]);
        insertData.put("NEED_CUSTOMER_CONFIRMED", mdSrSubAreaModel.getNEED_CUSTOMER_CONFIRMED() == null ? 0 : mdSrSubAreaModel.getNEED_CUSTOMER_CONFIRMED());
        insertData.put("CREATED_BY", Utility.getUserId(request));
        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
        insertData.put("CREATED_AT", current_ts);
//        insertData.put("ACTIVE", mdSrSubAreaModel.getACTIVE());
        insertData.put("ACTIVE", mdSrSubAreaModel.getACTIVE() == null ? 2 : mdSrSubAreaModel.getACTIVE());
        insertData.put("UPDATED_BY", Utility.getUserId(request));
        insertData.put("UPDATED_AT", current_ts);
        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
        if (submittype.equals("1")) {
            insertData.put("UNIQUE_ID", current_ts);
        }

        insertData.put("IS_NETWORK", mdSrSubAreaModel.getIS_NETWORK() == null ? 0 : mdSrSubAreaModel.getIS_NETWORK());
        try {
            boolean h = false;
            if (submittype.equals("1")) {
//                h = commonDAO.CommoInsert(Utility.md_sr_sub_area, insertData, logger);
                String generatedId = commonDAO.commonInsertGetReturn(Utility.md_sr_sub_area, insertData, logger, "id");
                if (generatedId != null && !generatedId.isEmpty()) {
                    h = true;
                    mdSrSubAreaModel.setID(Integer.parseInt(generatedId));
                }
            } else {
                Map<String, Object> updateData = new HashMap<>();
                updateData.put("UNIQUE_ID", submittype);
                h = commonDAO.CommoUpdate(Utility.md_sr_sub_area, insertData, updateData, logger);
            }

            if (h) {
                if (!submittype.equals("1")) {
                    Map<String, Object> deleteData = new HashMap<>();
                    deleteData.put("UNIQUE_ID", submittype);
                    current_ts = Long.valueOf(submittype);
                    commonDAO.CommoDelete(Utility.md_sr_esca_mt, deleteData, logger);
                    commonDAO.CommoDelete(Utility.md_sr_notify_mt, deleteData, logger);
                    commonDAO.CommoDelete(Utility.md_sr_sla, deleteData, logger);
                }
                List<MDSrSLAModel> mdSrSLAModels = new ArrayList<>();
                List<MDSrNotify> mdSrNotifies = new ArrayList<>();
                List<MDSrescaModel> mdSrescaModels = new ArrayList<>();
                try {
                    for (int i = 0; i < myParams.size(); i++) {
                        if (!myParams.get(i).isEmpty() && !number.get(i).isEmpty() && !Priority.get(i).isEmpty() && !accountType.get(i).isEmpty()) {
                            mdSrSLAModels.add(new MDSrSLAModel(mdSrSubAreaModel.getSR_SERVICE_TYPE_ID(), mdSrSubAreaModel.getSR_TYPE_ID(), mdSrSubAreaModel.getSR_AREA_ID(), myParams.get(i), number.get(i), Priority.get(i), accountType.get(i), current_ts + "", mdSrSubAreaModel.getID()));
                        }
                    }
                    if (mdSrSLAModels.size() > 0) {
                        srtypeDAO.insertSLRMatrix(mdSrSLAModels);
                    }

                    for (int ii = 0; ii < notifyName.size(); ii++) {
                        if (!notifyName.get(ii).isEmpty() && !notifyType.get(ii).isEmpty()) {
                            mdSrNotifies.add(new MDSrNotify(mdSrSubAreaModel.getSR_SERVICE_TYPE_ID(), mdSrSubAreaModel.getSR_TYPE_ID(), mdSrSubAreaModel.getSR_AREA_ID(), notifyName.get(ii), notifyType.get(ii), current_ts + "", mdSrSubAreaModel.getID()));
                        }
                    }
                    if (mdSrNotifies.size() > 0) {
                        srtypeDAO.insertNotifyMT(mdSrNotifies);
                    }

                    for (int iii = 0; iii < escalationnumber.size(); iii++) {
                        mdSrescaModels.add(new MDSrescaModel(mdSrSubAreaModel.getSR_SERVICE_TYPE_ID(), mdSrSubAreaModel.getSR_TYPE_ID(), mdSrSubAreaModel.getSR_AREA_ID(), escalationnumber.get(iii), group_name.get(iii), user_group_name.get(iii), user_mail.get(iii), current_ts + "", mdSrSubAreaModel.getID()));
                    }

                    if (mdSrescaModels.size() > 0) {
                        srtypeDAO.insertescaMT(mdSrescaModels);
                    }
//
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
                attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "Sub Area"));
            } else {
                attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "Sub Area"));
            } //
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        //redirect:subArea
        return "redirect:subArea";
    }


    /**********************************************  SR STATUS : START  ************************************/

    @RequestMapping(value = "/status", method = RequestMethod.GET)
    public String statusController(HttpServletRequest request, ModelMap model) {
        new MenuViewer().setupSideMenu(model, request);

        QueryMDSrStatusModel empList = new QueryMDSrStatusModel();
        titleModel = new TitleModel("ECRM", "Settings", "Service Request", "", "Status");

        try {
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            String count = QueryBuilder.getCountWhereQuery(Utility.md_sr_status, new HashMap<>(), whereSearchType);
            logger.info(count);
            int ii = commonDAO.CommoNumberOfRow(count);

            String qry_fetch = QueryBuilder.getWherQueryPagination(Utility.md_sr_status, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
            logger.info(qry_fetch);
            Object stslist = commonDAO.getDataPostgres(qry_fetch);

            List<MDSrStatusModel> statusList = new Gson().fromJson(Utility.ObjectToJson(stslist), new TypeToken<List<MDSrStatusModel>>() {
            }.getType());
            empList = new QueryMDSrStatusModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), statusList);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        model.addAttribute("viewDataModel", empList);
        model.addAttribute("title", titleModel);
        return "srsettings/status";
    }

    @PostMapping(value = "/savestatus")
    public String saveStatus(HttpServletRequest request, MDSrStatusModel MDSrStatusModel, @RequestParam(defaultValue = "false") boolean checkbox, RedirectAttributes attributes) {

        long current_ts = Utility.getCurrentTimestamp();
        MDSrStatusModel.setCREATED_BY(Utility.getUserId(request));
        MDSrStatusModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));

        if (checkbox) {
            MDSrStatusModel.setACTIVE(1);
        } else {
            MDSrStatusModel.setACTIVE(2);
        }

        if (MDSrStatusModel.getNAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Status Name"));
            return "redirect:" + "status";
        }


        Map<String, Object> searchData = new HashMap<>();
        Map<String, Object> whereSearchType = new HashMap<>();
        searchData.put("NAME", MDSrStatusModel.getNAME());
        whereSearchType.put("NAME", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_status, searchData, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Status Name"));
            return "redirect:" + "status";
        }

        Map<String, Object> insertData = new HashMap<>();
        insertData.put("NAME", MDSrStatusModel.getNAME());
        insertData.put("CREATED_BY", Utility.getUserId(request));
        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
        insertData.put("CREATED_AT", current_ts);
        insertData.put("ACTIVE", MDSrStatusModel.getACTIVE());
        insertData.put("UPDATED_BY", Utility.getUserId(request));
        insertData.put("UPDATED_AT", current_ts);
        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));


        boolean h = commonDAO.CommoInsert(Utility.md_sr_status, insertData, logger);
        if (h) {
            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "Status"));
        } else {
            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "Status"));
        }
        return "redirect:" + "status";
    }

    @PostMapping(value = "/updatestatus")
    public String updateStatus(HttpServletRequest request, MDSrStatusModel MDSrStatusModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox) {

        if (MDSrStatusModel.getNAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Status Name"));
            return "redirect:" + "status";
        }

        if (MDSrStatusModel.getID() <= 0) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Status Name"));
            return "redirect:" + "status";
        }

        long current_ts = Utility.getCurrentTimestamp();
        MDSrStatusModel.setNAME(MDSrStatusModel.getNAME());
        MDSrStatusModel.setUPDATED_BY(Utility.getUserId(request));
        MDSrStatusModel.setUPDATED_AT(current_ts);
        MDSrStatusModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
        if (checkbox) {
            MDSrStatusModel.setACTIVE(1);
        } else {
            MDSrStatusModel.setACTIVE(2);
        }


        Map<String, Object> search = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        search.put("ID!", MDSrStatusModel.getID());
        whereSearchType.put("ID!", "AND");
        search.put("NAME", MDSrStatusModel.getNAME());
        whereSearchType.put("NAME", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_status, search, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Status Name"));
            return "redirect:" + "status";
        }

        Map<String, Object> updateData = new HashMap<String, Object>();
        updateData.put("NAME", MDSrStatusModel.getNAME());
        updateData.put("ACTIVE", MDSrStatusModel.getACTIVE());
        updateData.put("UPDATED_BY", Utility.getUserId(request));
        updateData.put("UPDATED_AT", current_ts);
        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));

        Map<String, Object> whereData = new HashMap<String, Object>();
        whereData.put("ID", MDSrStatusModel.getID());

        boolean h = commonDAO.CommoUpdate(Utility.md_sr_status, updateData, whereData, logger);
        if (h) {
            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "Status name"));
        } else {
            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "Status name"));
        }

        return "redirect:" + "status";
    }


    /**********************************************  SR STATUS : END  ************************************/


    /**********************************************  SR Priority : START  ************************************/

    @RequestMapping(value = "/priority", method = RequestMethod.GET)
    public String priorityController(HttpServletRequest request, ModelMap model) {
        new MenuViewer().setupSideMenu(model, request);

        QueryMDSrPriorityModel empList = new QueryMDSrPriorityModel();
        titleModel = new TitleModel("ECRM", "Settings", "Service Request", "", "Priority");

        try {
            Map<String, Object> SearchData = new HashMap<>();
            Map<String, Object> whereSearchType = new HashMap<>();
            String count = QueryBuilder.getCountWhereQuery(Utility.md_sr_priority, new HashMap<>(), whereSearchType);
            logger.info(count);
            int ii = commonDAO.CommoNumberOfRow(count);

            String qry_fetch = QueryBuilder.getWherQueryPagination(Utility.md_sr_priority, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
            logger.info(qry_fetch);
            Object stslist = commonDAO.getDataPostgres(qry_fetch);

            List<MDSrPriorityModel> priorityList = new Gson().fromJson(Utility.ObjectToJson(stslist), new TypeToken<List<MDSrPriorityModel>>() {
            }.getType());
            empList = new QueryMDSrPriorityModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), priorityList);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        model.addAttribute("viewDataModel", empList);
        model.addAttribute("title", titleModel);
        return "srsettings/priority";
    }

    @PostMapping(value = "/savepriority")
    public String savePriority(HttpServletRequest request, MDSrPriorityModel MDSrPriorityModel, @RequestParam(defaultValue = "false") boolean checkbox, RedirectAttributes attributes) {

        long current_ts = Utility.getCurrentTimestamp();
        MDSrPriorityModel.setCREATED_BY(Utility.getUserId(request));
        MDSrPriorityModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));

        if (checkbox) {
            MDSrPriorityModel.setACTIVE(1);
        } else {
            MDSrPriorityModel.setACTIVE(2);
        }

        if (MDSrPriorityModel.getNAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Priority Name"));
            return "redirect:" + "priority";
        }


        Map<String, Object> searchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        searchData.put("NAME", MDSrPriorityModel.getNAME());
        whereSearchType.put("NAME", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_priority, searchData, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Priority Name"));
            return "redirect:" + "priority";
        }

        Map<String, Object> insertData = new HashMap<String, Object>();
        insertData.put("NAME", MDSrPriorityModel.getNAME());
        insertData.put("CREATED_BY", Utility.getUserId(request));
        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
        insertData.put("CREATED_AT", current_ts);
        insertData.put("ACTIVE", MDSrPriorityModel.getACTIVE());
        insertData.put("UPDATED_BY", Utility.getUserId(request));
        insertData.put("UPDATED_AT", current_ts);
        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));


        boolean h = commonDAO.CommoInsert(Utility.md_sr_priority, insertData, logger);
        if (h) {
            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "Priority"));
        } else {
            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "Priority"));
        }
        return "redirect:" + "priority";
    }

    @PostMapping(value = "/updatepriority")
    public String updatePriority(HttpServletRequest request, MDSrPriorityModel MDSrPriorityModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox) {

        if (MDSrPriorityModel.getNAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Priority Name"));
            return "redirect:" + "priority";
        }

        if (MDSrPriorityModel.getID() <= 0) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Priority Name"));
            return "redirect:" + "priority";
        }

        long current_ts = Utility.getCurrentTimestamp();
        MDSrPriorityModel.setNAME(MDSrPriorityModel.getNAME());
        MDSrPriorityModel.setUPDATED_BY(Utility.getUserId(request));
        MDSrPriorityModel.setUPDATED_AT(current_ts);
        MDSrPriorityModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
        if (checkbox) {
            MDSrPriorityModel.setACTIVE(1);
        } else {
            MDSrPriorityModel.setACTIVE(2);
        }


        Map<String, Object> search = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        search.put("ID!", MDSrPriorityModel.getID());
        search.put("NAME", MDSrPriorityModel.getNAME());

        whereSearchType.put("ID!", "AND");
        whereSearchType.put("NAME", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_priority, search, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Priority Name"));
            return "redirect:" + "priority";
        }

        Map<String, Object> updateData = new HashMap<String, Object>();
        updateData.put("NAME", MDSrPriorityModel.getNAME());
        updateData.put("ACTIVE", MDSrPriorityModel.getACTIVE());
        updateData.put("UPDATED_BY", Utility.getUserId(request));
        updateData.put("UPDATED_AT", current_ts);
        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));

        Map<String, Object> whereData = new HashMap<String, Object>();
        whereData.put("ID", MDSrPriorityModel.getID());

        boolean h = commonDAO.CommoUpdate(Utility.md_sr_priority, updateData, whereData, logger);
        if (h) {
            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "Priority name"));
        } else {
            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "Priority name"));
        }

        return "redirect:" + "priority";
    }

    /**********************************************  SR Priority : END  ************************************/


    /**********************************************  SR Severity : Start   ************************************/


    @RequestMapping(value = "/severity", method = RequestMethod.GET)
    public String severityController(HttpServletRequest request, ModelMap model) {
        new MenuViewer().setupSideMenu(model, request);

        QueryMDSrSeverityModel empList = new QueryMDSrSeverityModel();
        titleModel = new TitleModel("ECRM", "Settings", "Service Request", "", "Severity");

        try {
            Map<String, Object> SearchData = new HashMap<>();
            Map<String, Object> whereSearchType = new HashMap<>();
            String count = QueryBuilder.getCountWhereQuery(Utility.md_sr_severity, new HashMap<>(), whereSearchType);
            logger.info(count);
            int ii = commonDAO.CommoNumberOfRow(count);

            String qry_fetch = QueryBuilder.getWherQueryPagination(Utility.md_sr_severity, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
            logger.info(qry_fetch);
            Object stslist = commonDAO.getDataPostgres(qry_fetch);

            List<MDSrSeverityModel> severityList = new Gson().fromJson(Utility.ObjectToJson(stslist), new TypeToken<List<MDSrSeverityModel>>() {
            }.getType());
            empList = new QueryMDSrSeverityModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), severityList);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        model.addAttribute("viewDataModel", empList);
        model.addAttribute("title", titleModel);
        return "srsettings/severity";
    }

    @PostMapping(value = "/saveseverity")
    public String saveSeverity(HttpServletRequest request, MDSrSeverityModel MDSrSeverityModel, @RequestParam(defaultValue = "false") boolean checkbox, RedirectAttributes attributes) {

        long current_ts = Utility.getCurrentTimestamp();
        MDSrSeverityModel.setCREATED_BY(Utility.getUserId(request));
        MDSrSeverityModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));

        if (checkbox) {
            MDSrSeverityModel.setACTIVE(1);
        } else {
            MDSrSeverityModel.setACTIVE(2);
        }

        if (MDSrSeverityModel.getNAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Severity Name"));
            return "redirect:" + "severity";
        }


        Map<String, Object> searchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        searchData.put("NAME", MDSrSeverityModel.getNAME());
        whereSearchType.put("NAME", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_severity, searchData, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Severity Name"));
            return "redirect:" + "severity";
        }

        Map<String, Object> insertData = new HashMap<String, Object>();
        insertData.put("NAME", MDSrSeverityModel.getNAME());
        insertData.put("CREATED_BY", Utility.getUserId(request));
        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
        insertData.put("CREATED_AT", current_ts);
        insertData.put("ACTIVE", MDSrSeverityModel.getACTIVE());
        insertData.put("UPDATED_BY", Utility.getUserId(request));
        insertData.put("UPDATED_AT", current_ts);
        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));


        boolean h = commonDAO.CommoInsert(Utility.md_sr_severity, insertData, logger);
        if (h) {
            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "Severity"));
        } else {
            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "Severity"));
        }
        return "redirect:" + "severity";
    }

    @PostMapping(value = "/updateseverity")
    public String updateSeverity(HttpServletRequest request, MDSrSeverityModel MDSrSeverityModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox) {

        if (MDSrSeverityModel.getNAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Severity Name"));
            return "redirect:" + "severity";
        }

        if (MDSrSeverityModel.getID() <= 0) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Severity Name"));
            return "redirect:" + "severity";
        }

        long current_ts = Utility.getCurrentTimestamp();
        MDSrSeverityModel.setNAME(MDSrSeverityModel.getNAME());
        MDSrSeverityModel.setUPDATED_BY(Utility.getUserId(request));
        MDSrSeverityModel.setUPDATED_AT(current_ts);
        MDSrSeverityModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
        if (checkbox) {
            MDSrSeverityModel.setACTIVE(1);
        } else {
            MDSrSeverityModel.setACTIVE(2);
        }


        Map<String, Object> search = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        search.put("ID!", MDSrSeverityModel.getID());
        search.put("NAME", MDSrSeverityModel.getNAME());

        whereSearchType.put("ID!", "AND");
        whereSearchType.put("NAME", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_severity, search, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Severity Name"));
            return "redirect:" + "severity";
        }

        Map<String, Object> updateData = new HashMap<String, Object>();
        updateData.put("NAME", MDSrSeverityModel.getNAME());
        updateData.put("ACTIVE", MDSrSeverityModel.getACTIVE());
        updateData.put("UPDATED_BY", Utility.getUserId(request));
        updateData.put("UPDATED_AT", current_ts);
        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));

        Map<String, Object> whereData = new HashMap<String, Object>();
        whereData.put("ID", MDSrSeverityModel.getID());

        boolean h = commonDAO.CommoUpdate(Utility.md_sr_severity, updateData, whereData, logger);
        if (h) {
            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "Severity name"));
        } else {
            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "Severity name"));
        }

        return "redirect:" + "severity";
    }


    /**********************************************  SR Severity : End   ************************************/


    /**********************************************  SR RootCause : Start   ************************************/


    @RequestMapping(value = "/root-cause", method = RequestMethod.GET)
    public String rootCauseController(HttpServletRequest request, ModelMap model) {
        new MenuViewer().setupSideMenu(model, request);
        QueryMDSrRootCauseModel empList = new QueryMDSrRootCauseModel();
        titleModel = new TitleModel("ECRM", "Settings", "Service Request", "", "Root Cause");

        try {
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            String count = QueryBuilder.getCountWhereQuery(Utility.md_sr_root_cause, new HashMap<String, Object>(), whereSearchType);
            logger.info(count);
            int ii = commonDAO.CommoNumberOfRow(count);

            String qry_fetch = QueryBuilder.getWherQueryPagination(Utility.md_sr_root_cause, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
            logger.info(qry_fetch);
            Object stslist = commonDAO.getDataPostgres(qry_fetch);

            List<MDSrRootCauseModel> root_causeList = new Gson().fromJson(Utility.ObjectToJson(stslist), new TypeToken<List<MDSrRootCauseModel>>() {
            }.getType());
            empList = new QueryMDSrRootCauseModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), root_causeList);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        model.addAttribute("viewDataModel", empList);
        model.addAttribute("title", titleModel);
        return "srsettings/rootCause";
    }

    @PostMapping(value = "/save_root_cause")
    public String saveRootCause(HttpServletRequest request, MDSrRootCauseModel MDSrRootCauseModel, @RequestParam(defaultValue = "false") boolean checkbox, RedirectAttributes attributes) {

        long current_ts = Utility.getCurrentTimestamp();
        MDSrRootCauseModel.setCREATED_BY(Utility.getUserId(request));
        MDSrRootCauseModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));

        if (checkbox) {
            MDSrRootCauseModel.setACTIVE(1);
        } else {
            MDSrRootCauseModel.setACTIVE(2);
        }

        if (MDSrRootCauseModel.getNAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Root cause"));
            return "redirect:" + "root-cause";
        }


        Map<String, Object> searchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        searchData.put("NAME", MDSrRootCauseModel.getNAME());
        whereSearchType.put("NAME", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_root_cause, searchData, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Root cause"));
            return "redirect:" + "root-cause";
        }

        Map<String, Object> insertData = new HashMap<String, Object>();
        insertData.put("NAME", MDSrRootCauseModel.getNAME());
        insertData.put("CREATED_BY", Utility.getUserId(request));
        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
        insertData.put("CREATED_AT", current_ts);
        insertData.put("ACTIVE", MDSrRootCauseModel.getACTIVE());
        insertData.put("UPDATED_BY", Utility.getUserId(request));
        insertData.put("UPDATED_AT", current_ts);
        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));


        boolean h = commonDAO.CommoInsert(Utility.md_sr_root_cause, insertData, logger);
        if (h) {
            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "Root cause"));
        } else {
            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "Root cause"));
        }
        return "redirect:" + "root-cause";
    }

    @PostMapping(value = "/update_root_cause")
    public String updateRootCause(HttpServletRequest request, MDSrRootCauseModel MDSrRootCauseModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox) {

        if (MDSrRootCauseModel.getNAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Root cause"));
            return "redirect:" + "root-cause";
        }

        if (MDSrRootCauseModel.getID() <= 0) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Root cause"));
            return "redirect:" + "root-cause";
        }

        long current_ts = Utility.getCurrentTimestamp();
        MDSrRootCauseModel.setNAME(MDSrRootCauseModel.getNAME());
        MDSrRootCauseModel.setUPDATED_BY(Utility.getUserId(request));
        MDSrRootCauseModel.setUPDATED_AT(current_ts);
        MDSrRootCauseModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
        if (checkbox) {
            MDSrRootCauseModel.setACTIVE(1);
        } else {
            MDSrRootCauseModel.setACTIVE(2);
        }


        Map<String, Object> search = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();

        search.put("ID!", MDSrRootCauseModel.getID());
        search.put("NAME", MDSrRootCauseModel.getNAME());

        whereSearchType.put("ID!", "AND");
        whereSearchType.put("NAME", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_root_cause, search, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Root cause"));
            return "redirect:" + "root-cause";
        }

        Map<String, Object> updateData = new HashMap<String, Object>();
        updateData.put("NAME", MDSrRootCauseModel.getNAME());
        updateData.put("ACTIVE", MDSrRootCauseModel.getACTIVE());
        updateData.put("UPDATED_BY", Utility.getUserId(request));
        updateData.put("UPDATED_AT", current_ts);
        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));

        Map<String, Object> whereData = new HashMap<String, Object>();
        whereData.put("ID", MDSrRootCauseModel.getID());

        boolean h = commonDAO.CommoUpdate(Utility.md_sr_root_cause, updateData, whereData, logger);
        if (h) {
            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "Root cause"));
        } else {
            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "Root cause"));
        }

        return "redirect:" + "root-cause";
    }

    /**********************************************  SR RootCause : End   ************************************/


    /**********************************************  SR ActionType : Start   ************************************/


    @RequestMapping(value = "/action-type", method = RequestMethod.GET)
    public String actionTypeController(HttpServletRequest request, ModelMap model) {
        new MenuViewer().setupSideMenu(model, request);
        QueryMDSrActionTypeModel empList = new QueryMDSrActionTypeModel();
        titleModel = new TitleModel("ECRM", "Settings", "Service Request", "", "Action Type");

        try {
            Map<String, Object> SearchData = new HashMap<>();
            Map<String, Object> whereSearchType = new HashMap<>();
            String count = QueryBuilder.getCountWhereQuery(Utility.md_sr_action_type, new HashMap<>(), whereSearchType);
            logger.info(count);
            int ii = commonDAO.CommoNumberOfRow(count);

            String qry_fetch = QueryBuilder.getWherQueryPagination(Utility.md_sr_action_type, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
            logger.info(qry_fetch);
            Object stslist = commonDAO.getDataPostgres(qry_fetch);

            List<MDSrActionTypeModel> action_typeList = new Gson().fromJson(Utility.ObjectToJson(stslist), new TypeToken<List<MDSrActionTypeModel>>() {
            }.getType());
            empList = new QueryMDSrActionTypeModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), action_typeList);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        model.addAttribute("viewDataModel", empList);
        model.addAttribute("title", titleModel);
        return "srsettings/actionType";
    }

    @PostMapping(value = "/save_action_type")
    public String saveActionType(HttpServletRequest request, MDSrActionTypeModel MDSrActionTypeModel, @RequestParam(defaultValue = "false") boolean checkbox, RedirectAttributes attributes) {

        long current_ts = Utility.getCurrentTimestamp();
        MDSrActionTypeModel.setCREATED_BY(Utility.getUserId(request));
        MDSrActionTypeModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));

        if (checkbox) {
            MDSrActionTypeModel.setACTIVE(1);
        } else {
            MDSrActionTypeModel.setACTIVE(2);
        }

        if (MDSrActionTypeModel.getNAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Action type"));
            return "redirect:" + "action-type";
        }


        Map<String, Object> searchData = new HashMap<>();
        Map<String, Object> whereSearchType = new HashMap<>();

        searchData.put("NAME", MDSrActionTypeModel.getNAME());
        whereSearchType.put("NAME", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_action_type, searchData, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Action type"));
            return "redirect:" + "action-type";
        }

        Map<String, Object> insertData = new HashMap<String, Object>();
        insertData.put("NAME", MDSrActionTypeModel.getNAME());
        insertData.put("CREATED_BY", Utility.getUserId(request));
        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
        insertData.put("CREATED_AT", current_ts);
        insertData.put("ACTIVE", MDSrActionTypeModel.getACTIVE());
        insertData.put("UPDATED_BY", Utility.getUserId(request));
        insertData.put("UPDATED_AT", current_ts);
        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));


        boolean h = commonDAO.CommoInsert(Utility.md_sr_action_type, insertData, logger);
        if (h) {
            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "Action type"));
        } else {
            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "Action type"));
        }
        return "redirect:" + "action-type";
    }

    @PostMapping(value = "/update_action_type")
    public String updateActionType(HttpServletRequest request, MDSrActionTypeModel MDSrActionTypeModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox) {

        if (MDSrActionTypeModel.getNAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Action type"));
            return "redirect:" + "action-type";
        }

        if (MDSrActionTypeModel.getID() <= 0) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Action type"));
            return "redirect:" + "action-type";
        }

        long current_ts = Utility.getCurrentTimestamp();
        MDSrActionTypeModel.setNAME(MDSrActionTypeModel.getNAME());
        MDSrActionTypeModel.setUPDATED_BY(Utility.getUserId(request));
        MDSrActionTypeModel.setUPDATED_AT(current_ts);
        MDSrActionTypeModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
        if (checkbox) {
            MDSrActionTypeModel.setACTIVE(1);
        } else {
            MDSrActionTypeModel.setACTIVE(2);
        }


        Map<String, Object> search = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        search.put("ID!", MDSrActionTypeModel.getID());
        search.put("NAME", MDSrActionTypeModel.getNAME());

        whereSearchType.put("ID!", "AND");
        whereSearchType.put("NAME", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_action_type, search, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Action Type"));
            return "redirect:" + "action-type";
        }

        Map<String, Object> updateData = new HashMap<String, Object>();
        updateData.put("NAME", MDSrActionTypeModel.getNAME());
        updateData.put("ACTIVE", MDSrActionTypeModel.getACTIVE());
        updateData.put("UPDATED_BY", Utility.getUserId(request));
        updateData.put("UPDATED_AT", current_ts);
        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));

        Map<String, Object> whereData = new HashMap<String, Object>();
        whereData.put("ID", MDSrActionTypeModel.getID());

        boolean h = commonDAO.CommoUpdate(Utility.md_sr_action_type, updateData, whereData, logger);
        if (h) {
            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "Action type"));
        } else {
            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "Action type"));
        }

        return "redirect:" + "action-type";
    }


    /**********************************************  SR ActionType : End   ************************************/

    /**********************************************  SR AnsType : Start   ************************************/


    @RequestMapping(value = "/answer_type", method = RequestMethod.GET)
    public String ansTypeController(HttpServletRequest request, ModelMap model) {
        new MenuViewer().setupSideMenu(model, request);
        QueryMDSrAnsTypeModel empList = new QueryMDSrAnsTypeModel();
        titleModel = new TitleModel("ECRM", "Settings", "Service Request", "", "Answer Type");

        try {
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            String count = QueryBuilder.getCountWhereQuery(Utility.md_sr_ans_type, new HashMap<String, Object>(), whereSearchType);
            logger.info(count);
            int ii = commonDAO.CommoNumberOfRow(count);

            String qry_fetch = QueryBuilder.getWherQueryPagination(Utility.md_sr_ans_type, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
            logger.info(qry_fetch);
            Object stslist = commonDAO.getDataPostgres(qry_fetch);

            List<MDSrAnsTypeModel> ans_typeList = new Gson().fromJson(Utility.ObjectToJson(stslist), new TypeToken<List<MDSrAnsTypeModel>>() {
            }.getType());
            empList = new QueryMDSrAnsTypeModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), ans_typeList);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        model.addAttribute("viewDataModel", empList);
        model.addAttribute("title", titleModel);
        return "srsettings/ansType";
    }

    @PostMapping(value = "/save_answer_type")
    public String saveAnsType(HttpServletRequest request, MDSrAnsTypeModel MDSrAnsTypeModel, @RequestParam(defaultValue = "false") boolean checkbox, RedirectAttributes attributes) {

        long current_ts = Utility.getCurrentTimestamp();
        MDSrAnsTypeModel.setCREATED_BY(Utility.getUserId(request));
        MDSrAnsTypeModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));

        if (checkbox) {
            MDSrAnsTypeModel.setACTIVE(1);
        } else {
            MDSrAnsTypeModel.setACTIVE(2);
        }

        if (MDSrAnsTypeModel.getNAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Answer Type"));
            return "redirect:" + "answer_type";
        }


        Map<String, Object> searchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        searchData.put("NAME", MDSrAnsTypeModel.getNAME());
        whereSearchType.put("NAME", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_ans_type, searchData, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Answer Type"));
            return "redirect:" + "answer_type";
        }

        Map<String, Object> insertData = new HashMap<String, Object>();
        insertData.put("NAME", MDSrAnsTypeModel.getNAME());
        insertData.put("CREATED_BY", Utility.getUserId(request));
        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
        insertData.put("CREATED_AT", current_ts);
        insertData.put("ACTIVE", MDSrAnsTypeModel.getACTIVE());
        insertData.put("UPDATED_BY", Utility.getUserId(request));
        insertData.put("UPDATED_AT", current_ts);
        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));


        boolean h = commonDAO.CommoInsert(Utility.md_sr_ans_type, insertData, logger);
        if (h) {
            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "Answer Type"));
        } else {
            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "Answer Type"));
        }
        return "redirect:" + "answer_type";
    }

    @PostMapping(value = "/update_answer_type")
    public String updateAnsType(HttpServletRequest request, MDSrAnsTypeModel MDSrAnsTypeModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox) {

        if (MDSrAnsTypeModel.getNAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Answer Type"));
            return "redirect:" + "answer_type";
        }

        if (MDSrAnsTypeModel.getID() <= 0) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Answer Type"));
            return "redirect:" + "answer_type";
        }

        long current_ts = Utility.getCurrentTimestamp();
        MDSrAnsTypeModel.setNAME(MDSrAnsTypeModel.getNAME());
        MDSrAnsTypeModel.setUPDATED_BY(Utility.getUserId(request));
        MDSrAnsTypeModel.setUPDATED_AT(current_ts);
        MDSrAnsTypeModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
        if (checkbox) {
            MDSrAnsTypeModel.setACTIVE(1);
        } else {
            MDSrAnsTypeModel.setACTIVE(2);
        }


        Map<String, Object> search = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();

        search.put("ID!", MDSrAnsTypeModel.getID());
        search.put("NAME", MDSrAnsTypeModel.getNAME());

        whereSearchType.put("ID!", "AND");
        whereSearchType.put("NAME", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_ans_type, search, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Answer Type"));
            return "redirect:" + "answer_type";
        }

        Map<String, Object> updateData = new HashMap<String, Object>();
        updateData.put("NAME", MDSrAnsTypeModel.getNAME());
        updateData.put("ACTIVE", MDSrAnsTypeModel.getACTIVE());
        updateData.put("UPDATED_BY", Utility.getUserId(request));
        updateData.put("UPDATED_AT", current_ts);
        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));

        Map<String, Object> whereData = new HashMap<String, Object>();
        whereData.put("ID", MDSrAnsTypeModel.getID());

        boolean h = commonDAO.CommoUpdate(Utility.md_sr_ans_type, updateData, whereData, logger);
        if (h) {
            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "Answer Type"));
        } else {
            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "Answer Type"));
        }

        return "redirect:" + "answer_type";
    }

    /**********************************************  SR AnsType : End   ************************************/

    /**********************************************  SR Activity Type : Start   ************************************/


    @RequestMapping(value = "/act-type", method = RequestMethod.GET)
    public String actTypeController(HttpServletRequest request, ModelMap model) {
        new MenuViewer().setupSideMenu(model, request);
        QueryMDSrActTypeModel empList = new QueryMDSrActTypeModel();
        titleModel = new TitleModel("ECRM", "Settings", "Service Request", "", "Activity Type");

        try {
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            String count = QueryBuilder.getCountWhereQuery(Utility.md_sr_act_type, new HashMap<String, Object>(), whereSearchType);
            logger.info(count);
            int ii = commonDAO.CommoNumberOfRow(count);

            String qry_fetch = QueryBuilder.getWherQueryPagination(Utility.md_sr_act_type, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
            logger.info(qry_fetch);
            Object stslist = commonDAO.getDataPostgres(qry_fetch);

            List<MDSrActTypeModel> act_typeList = new Gson().fromJson(Utility.ObjectToJson(stslist), new TypeToken<List<MDSrActTypeModel>>() {
            }.getType());
            empList = new QueryMDSrActTypeModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), act_typeList);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        model.addAttribute("viewDataModel", empList);
        model.addAttribute("title", titleModel);
        return "srsettings/actType";
    }

    @PostMapping(value = "/save_act_type")
    public String saveActType(HttpServletRequest request, MDSrActTypeModel MDSrActTypeModel, @RequestParam(defaultValue = "false") boolean checkbox, RedirectAttributes attributes) {

        long current_ts = Utility.getCurrentTimestamp();
        MDSrActTypeModel.setCREATED_BY(Utility.getUserId(request));
        MDSrActTypeModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));

        if (checkbox) {
            MDSrActTypeModel.setACTIVE(1);
        } else {
            MDSrActTypeModel.setACTIVE(2);
        }

        if (MDSrActTypeModel.getNAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Activity Type"));
            return "redirect:" + "act_type";
        }


        Map<String, Object> searchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        searchData.put("NAME", MDSrActTypeModel.getNAME());
        whereSearchType.put("NAME", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_act_type, searchData, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Activity Type"));
            return "redirect:" + "act_type";
        }

        Map<String, Object> insertData = new HashMap<String, Object>();
        insertData.put("NAME", MDSrActTypeModel.getNAME());
        insertData.put("CREATED_BY", Utility.getUserId(request));
        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
        insertData.put("CREATED_AT", current_ts);
        insertData.put("ACTIVE", MDSrActTypeModel.getACTIVE());
        insertData.put("UPDATED_BY", Utility.getUserId(request));
        insertData.put("UPDATED_AT", current_ts);
        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));


        boolean h = commonDAO.CommoInsert(Utility.md_sr_act_type, insertData, logger);
        if (h) {
            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "Activity Type"));
        } else {
            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "Activity Type"));
        }
        return "redirect:" + "act_type";
    }

    @PostMapping(value = "/update_act_type")
    public String updateActType(HttpServletRequest request, MDSrActTypeModel MDSrActTypeModel, RedirectAttributes attributes, @RequestParam(defaultValue = "false") boolean checkbox) {

        if (MDSrActTypeModel.getNAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Activity Type"));
            return "redirect:" + "act_type";
        }

        if (MDSrActTypeModel.getID() <= 0) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Activity Type"));
            return "redirect:" + "act_type";
        }

        long current_ts = Utility.getCurrentTimestamp();
        MDSrActTypeModel.setNAME(MDSrActTypeModel.getNAME());
        MDSrActTypeModel.setUPDATED_BY(Utility.getUserId(request));
        MDSrActTypeModel.setUPDATED_AT(current_ts);
        MDSrActTypeModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
        if (checkbox) {
            MDSrActTypeModel.setACTIVE(1);
        } else {
            MDSrActTypeModel.setACTIVE(2);
        }


        Map<String, Object> search = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();

        search.put("ID!", MDSrActTypeModel.getID());
        search.put("NAME", MDSrActTypeModel.getNAME());

        whereSearchType.put("ID!", "AND");
        whereSearchType.put("NAME", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.md_sr_act_type, search, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Activity Type"));
            return "redirect:" + "act_type";
        }

        Map<String, Object> updateData = new HashMap<String, Object>();
        updateData.put("NAME", MDSrActTypeModel.getNAME());
        updateData.put("ACTIVE", MDSrActTypeModel.getACTIVE());
        updateData.put("UPDATED_BY", Utility.getUserId(request));
        updateData.put("UPDATED_AT", current_ts);
        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));

        Map<String, Object> whereData = new HashMap<String, Object>();
        whereData.put("ID", MDSrActTypeModel.getID());

        boolean h = commonDAO.CommoUpdate(Utility.md_sr_act_type, updateData, whereData, logger);
        if (h) {
            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "Activity Type"));
        } else {
            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "Activity Type"));
        }

        return "redirect:" + "act_type";
    }

    /**********************************************  SR Activity Type : End   ************************************/


    /**********************************************  SR Ques Management : Start   ************************************/


    @RequestMapping(value = "/question-mgt", method = RequestMethod.GET)
    public String questionMgtController(HttpServletRequest request, ModelMap model) {
        new MenuViewer().setupSideMenu(model, request);
        QueryMDSrQuesMgtModel quesList = new QueryMDSrQuesMgtModel();
        List<MDSrAnsTypeModel> ansTypeList = new ArrayList<>();
        List<MDSrQuesMgtModel> childQuesList = new ArrayList<>();
        titleModel = new TitleModel("ECRM", "Settings", "Service Request", "", "Question");

        try {
            Map<String, Object> SearchData = new HashMap<>();
            Map<String, Object> whereSearchType = new HashMap<>();
            String count = QueryBuilder.getCountWhereQuery(Utility.tbl_sr_ques, new HashMap<>(), whereSearchType);
            logger.info(count);
            int ii = commonDAO.CommoNumberOfRow(count);

            String qry_fetch = QueryBuilder.getWherQueryPagination(Utility.tbl_sr_ques, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
            logger.info(qry_fetch);
            Object stslist = commonDAO.getDataPostgres(qry_fetch);

            List<MDSrQuesMgtModel> ques_list = new Gson().fromJson(Utility.ObjectToJson(stslist), new TypeToken<List<MDSrQuesMgtModel>>() {
            }.getType());
            quesList = new QueryMDSrQuesMgtModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, 1, Utility.perPageDataLoad), ques_list);

            /* fetching AnsType*/
            Map<String, Object> SearchDataAns = new HashMap<String, Object>();
            Map<String, Object> whereSearchTypeAns = new HashMap<String, Object>();
            SearchDataAns.put("ACTIVE", 1);
            whereSearchTypeAns.put("ACTIVE", "AND");
            String qry_service_ans = QueryBuilder.getSelectWhereQuery(Utility.md_sr_ans_type, SearchDataAns, whereSearchTypeAns);
            logger.info(qry_service_ans);
            Object anslist = commonDAO.getDataPostgres(qry_service_ans);
            ansTypeList = new Gson().fromJson(Utility.ObjectToJson(anslist), new TypeToken<List<MDSrAnsTypeModel>>() {
            }.getType());

            /* fetching All Ques for child Ques */
            Map<String, Object> SearchDataChild = new HashMap<String, Object>();
            Map<String, Object> whereSearchTypeChild = new HashMap<String, Object>();
            SearchDataChild.put("ACTIVE", 1);
            whereSearchTypeChild.put("ACTIVE", "AND");
            SearchDataChild.put("HAS_CHILD_QUES", 0);
            whereSearchTypeChild.put("HAS_CHILD_QUES", "AND");

            String qry_service_ques = QueryBuilder.getSelectWhereQuery(Utility.tbl_sr_ques, SearchDataAns, whereSearchTypeAns);
            logger.info(qry_service_ques);
            Object childList = commonDAO.getDataPostgres(qry_service_ques);
            childQuesList = new Gson().fromJson(Utility.ObjectToJson(childList), new TypeToken<List<MDSrQuesMgtModel>>() {
            }.getType());

        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        model.addAttribute("viewDataModel", quesList);
        model.addAttribute("ansTypeList", ansTypeList);
        model.addAttribute("childQuesList", childQuesList);
        model.addAttribute("title", titleModel);
        return "srsettings/quesMgt";
    }

    @PostMapping(value = "/save_ques_mgt")
    public String saveQuesMgt(HttpServletRequest request, MDSrQuesMgtModel MDSrQuesMgtModel, @RequestParam(defaultValue = "false") boolean checkbox, @RequestParam(defaultValue = "false") boolean HAS_CHILD_QUES, RedirectAttributes attributes) {

        System.out.println("Heroe");
        long current_ts = Utility.getCurrentTimestamp();
        MDSrQuesMgtModel.setCREATED_BY(Utility.getUserId(request));
        MDSrQuesMgtModel.setCREATED_BY_USERNAME(Utility.getLoginName(request));

        if (checkbox) {
            MDSrQuesMgtModel.setACTIVE(1);
        } else {
            MDSrQuesMgtModel.setACTIVE(2);
        }

        if (MDSrQuesMgtModel.getNAME().trim().isEmpty()) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Question Name"));
            return "redirect:" + "question-mgt";
        }


        Map<String, Object> searchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        searchData.put("NAME", MDSrQuesMgtModel.getNAME().replace("'", "''"));
        whereSearchType.put("NAME", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.tbl_sr_ques, searchData, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Question Name"));
            return "redirect:" + "question-mgt";
        }

        /* checking options given or not */

        String[] srAnsType = MDSrQuesMgtModel.getANS_TYPE_NAME().trim().split("//");
        Integer srAnsTypeId = Integer.parseInt(srAnsType[0]);
        String srAnsTypeName = srAnsType[1];
        String srAnsTypeInputType = srAnsType[2];

        System.out.println(MDSrQuesMgtModel.getANS_TYPE_NAME().trim());
        System.out.println("ID:" + srAnsTypeId);
        System.out.println("Name:" + srAnsTypeName);
        System.out.println("Type:" + srAnsTypeInputType);

        if (srAnsTypeId == 5 || srAnsTypeId == 11 || srAnsTypeId == 12) {
            if (MDSrQuesMgtModel.getINPUT_OPTIONS().trim().isEmpty()) {
                attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Input Options"));
                return "redirect:" + "question-mgt";
            }

        }

        if (HAS_CHILD_QUES) {
            if (MDSrQuesMgtModel.getCHILD_QUESTION().trim().isEmpty()) {
                attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Child Question"));
                return "redirect:" + "question-mgt";
            }

        }

        Map<String, Object> insertData = new HashMap<String, Object>();

        insertData.put("ANS_TYPE_ID", srAnsTypeId);
        insertData.put("ANS_TYPE_NAME", srAnsTypeName);
        insertData.put("ANS_INPUT_TYPE", srAnsTypeInputType);
        insertData.put("ACTIVE", MDSrQuesMgtModel.getACTIVE());
        insertData.put("CREATED_BY", Utility.getUserId(request));
        insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
        insertData.put("CREATED_AT", current_ts);
        insertData.put("UPDATED_BY", Utility.getUserId(request));
        insertData.put("UPDATED_AT", current_ts);
        insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
        insertData.put("HAS_CHILD_QUES", HAS_CHILD_QUES ? 1 : 0);

        if (HAS_CHILD_QUES) {
            String[] srChildQues = MDSrQuesMgtModel.getCHILD_QUESTION().trim().replace("'", "''").split("//");
            Integer srChildQuesId = Integer.parseInt(srChildQues[0]);
            String srChildQuesName = srChildQues[1];
            insertData.put("CHILD_QUESTION_ID", srChildQuesId);
            insertData.put("CHILD_QUESTION", srChildQuesName);
        }

        if (srAnsTypeId == 5 || srAnsTypeId == 11 || srAnsTypeId == 12) {
            insertData.put("INPUT_OPTIONS", MDSrQuesMgtModel.getINPUT_OPTIONS().trim().replace("'", "''"));
        }

        insertData.put("NAME", MDSrQuesMgtModel.getNAME());
        insertData.put("QUESTION", MDSrQuesMgtModel.getQUESTION());
        insertData.put("DISPLAY_NAME", MDSrQuesMgtModel.getNAME());

        System.out.println(Utility.ObjectToJson(insertData));

        boolean h = false;
        Integer QuesInsertedId = 0;
        String generatedId = commonDAO.commonInsertGetReturn(Utility.tbl_sr_ques, insertData, logger, "id");
        if (generatedId != null && !generatedId.isEmpty()) {
            h = true;
            QuesInsertedId = Integer.parseInt(generatedId);
        }

        if (h) {
            if (srAnsTypeId == 5 || srAnsTypeId == 11 || srAnsTypeId == 12) {
                String[] srInputOptionsAr = MDSrQuesMgtModel.getINPUT_OPTIONS().trim().replace("'", "''").split("//");
                List<Object[]> batchArgsList = new ArrayList<Object[]>();

                if (srInputOptionsAr.length > 0) {
                    Integer action_by = Utility.getUserId(request).intValue();
                    String action_by_username = Utility.getLoginName(request);

                    try {
                        for (String row : srInputOptionsAr) {
                            Object[] objectArray = {
                                    QuesInsertedId,
                                    row,
                                    srAnsTypeId,
                                    srAnsTypeName,
                                    1,
                                    action_by,
                                    action_by_username,
                                    current_ts,
                                    row,
                                    row
                            };
                            batchArgsList.add(objectArray);
                        }

                        System.out.println("batchObject");
                        System.out.println(Utility.ObjectToJson(batchArgsList));

                        boolean h2 = srtypeDAO.insertQuesOptions(batchArgsList, logger);

                    } catch (Exception ex) {
                        ex.printStackTrace();
                        logger.error(ex.getMessage(), ex);
                    }

                }

            }

            attributes.addFlashAttribute("success", Utility.addSuccMsg.replace("#msg", "Question"));
        } else {
            attributes.addFlashAttribute("error", Utility.addFailMsg.replace("#msg", "Question"));
        }
        return "redirect:" + "question-mgt";
    }

    @PostMapping(value = "/update_ques_mgt")
    public String updateQuesMgt(HttpServletRequest request, MDSrQuesMgtModel MDSrQuesMgtModel, @RequestParam(defaultValue = "false") boolean checkbox, @RequestParam(defaultValue = "false") boolean HAS_CHILD_QUES, RedirectAttributes attributes) {

        /*
        if (MDSrActTypeModel.getNAME().equals("")) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Question Name"));
            return "redirect:" + "question_mgt";
        }

        if (MDSrActTypeModel.getID() <= 0) {
            attributes.addFlashAttribute("error", Utility.emptyMsg.replace("#msg", "Question Name"));
            return "redirect:" + "question_mgt";
        }

        long current_ts = Utility.getCurrentTimestamp();
        MDSrActTypeModel.setNAME(MDSrActTypeModel.getNAME());
        MDSrActTypeModel.setUPDATED_BY(Utility.getUserId(request));
        MDSrActTypeModel.setUPDATED_AT(current_ts);
        MDSrActTypeModel.setUPDATED_BY_USERNAME(Utility.getLoginName(request));
        if (checkbox) {
            MDSrActTypeModel.setACTIVE(1);
        } else {
            MDSrActTypeModel.setACTIVE(2);
        }


        Map<String, Object> search = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();

        search.put("ID!", MDSrActTypeModel.getID());
        search.put("NAME", MDSrActTypeModel.getNAME());
*/
        /*
        whereSearchType.put("ID!", "AND");
        whereSearchType.put("NAME", "AND");

        String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.tbl_sr_ques, search, whereSearchType);
        logger.info(duplicateQry);
        int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);

        if (TotalRows > 0) {
            attributes.addFlashAttribute("error", Utility.duplicateMsg.replace("#msg", "Question"));
            return "redirect:" + "question_mgt";
        }

        Map<String, Object> updateData = new HashMap<String, Object>();
        updateData.put("NAME", MDSrActTypeModel.getNAME());
        updateData.put("ACTIVE", MDSrActTypeModel.getACTIVE());
        updateData.put("UPDATED_BY", Utility.getUserId(request));
        updateData.put("UPDATED_AT", current_ts);
        updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));

        Map<String, Object> whereData = new HashMap<String, Object>();
        whereData.put("ID", MDSrActTypeModel.getID());

        boolean h = commonDAO.CommoUpdate(Utility.tbl_sr_ques, updateData, whereData, logger);
        if (h) {
            attributes.addFlashAttribute("success", Utility.updateSuccMsg.replace("#msg", "Question"));
        } else {
            attributes.addFlashAttribute("error", Utility.updateFailMsg.replace("#msg", "Question"));
        }
*/
        return "redirect:" + "question-mgt";
    }

    /**********************************************  SR Ques Management : End   ************************************/


}
