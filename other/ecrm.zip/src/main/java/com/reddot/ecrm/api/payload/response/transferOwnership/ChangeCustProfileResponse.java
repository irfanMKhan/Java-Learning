package com.reddot.ecrm.api.payload.response.transferOwnership;

import lombok.Data;

import java.io.Serializable;

@Data
public class ChangeCustProfileResponse implements Serializable {

    public ChangeCustProfileRspMsg ChangeCustProfileRspMsg;


    @Data
    public static class ChangeCustProfileRspMsg implements Serializable {

        public RspHeader RspHeader;

    }

    @Data
    public static class RspHeader implements Serializable {

        public Integer Version;

        public String ReturnCode;

        public String ReturnMsg;

        public Long RspTime;

    }

}
