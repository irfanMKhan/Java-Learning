package com.reddot.ecrm.api.payload.request.payment;

import lombok.Data;

import java.io.Serializable;

@Data
public class QueryInvoiceAPIRequest implements Serializable {
  private QueryInvoiceRequest QueryInvoiceRequest;

  private RequestHeader RequestHeader;

  @Data
  public static class QueryInvoiceRequest implements Serializable {
    private String NumberOfBillCycle;

    private AcctAccessCode AcctAccessCode;

    @Data
    public static class AcctAccessCode implements Serializable {
      private String AccountCode;
    }
  }

  @Data
  public static class RequestHeader implements Serializable {
    private String MessageSeq;

    private String Version;

    private AccessSecurity AccessSecurity;

    private String BusinessCode;

    private OwnershipInfo OwnershipInfo;

    @Data
    public static class AccessSecurity implements Serializable {
      private String LoginSystemCode;

      private String Password;
    }

    @Data
    public static class OwnershipInfo implements Serializable {
      private String BEID;
    }
  }
}
