package com.reddot.ecrm.controller.eshop;

import com.reddot.ecrm.entity.eshop.AddDeviceDescription;
import com.reddot.ecrm.entity.eshop.EtopUp;
import com.reddot.ecrm.service.eshop.AddDeviceDescriptionService;
import com.reddot.ecrm.service.eshop.EtopUpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.security.Principal;

@RestController
@RequestMapping("/crm/eShop")
public class AddDeviceDescriptionRestController {

    @Autowired
    private AddDeviceDescriptionService addDeviceDescriptionService;

    @GetMapping("/dataTable/deviceDescriptionData")
    public DataTablesOutput<AddDeviceDescription> deviceDescriptionData(@Valid DataTablesInput input, HttpServletRequest request, @RequestParam(value = "searchText", required = false) String searchText, @RequestParam(value = "searchCol", required = false) String searchCol, @RequestParam(value = "purchaseNo", required = false) String purchaseNo) {
        return addDeviceDescriptionService.getDataTableDeviceDescription(input, request, searchText, searchCol, purchaseNo);
    }


    @PostMapping("/addDeviceDescription")
    public String addDeviceDescription(HttpServletRequest request, @RequestBody AddDeviceDescription data) {
        return addDeviceDescriptionService.addDeviceDescription(request, data);
    }

    @GetMapping(value = "/deleteAddDeviceDescription")
    public String deleteAddDeviceDescription(ModelMap model, HttpServletRequest request, Principal principal, @RequestParam(value = "id", required = false) Long id) {
        return addDeviceDescriptionService.deleteaddDeviceDescriptionDataById(id);
    }
}
