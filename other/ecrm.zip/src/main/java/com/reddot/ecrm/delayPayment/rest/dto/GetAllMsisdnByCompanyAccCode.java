package com.reddot.ecrm.delayPayment.rest.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetAllMsisdnByCompanyAccCode {
    private String msisdnAccountCode;
}
