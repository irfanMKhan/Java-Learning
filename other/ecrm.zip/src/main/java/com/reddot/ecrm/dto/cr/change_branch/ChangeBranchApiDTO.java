package com.reddot.ecrm.dto.cr.change_branch;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ChangeBranchApiDTO {
    private String msisdn;
    private String departmentID;
    private String departmentName;
    private String custId;
    private String mainGrpId;
    private Boolean isBranchExist;
    private Boolean isMainGrpExist;
    private Long branchAccountId;
}
