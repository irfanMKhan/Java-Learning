package com.reddot.ecrm.controller.approval.approval_request;

import com.reddot.ecrm.dto.approval.ApprovalDetailsRequestDataDTO;
import com.reddot.ecrm.dto.httpServletRequest.HttpServletRequestDto;
import com.reddot.ecrm.entity.approval.ApprovalLogDetailsEntity;
import com.reddot.ecrm.entity.approval.ApprovalRequestEntity;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.repository.approval.ApprovalRequestRepo;
import com.reddot.ecrm.service.approval.ApprovalRequestService;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequestMapping("approval/flow/request/rest")
@RequiredArgsConstructor
public class ApprovalRequestRest {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    @Autowired
    ApprovalRequestService approvalRequestService;
    @Autowired
    ApprovalRequestRepo approvalRequestRepo;


    @PostMapping("/addRequestData")
    public CommonRestResponse addData(@RequestBody ApprovalRequestEntity approvalRequest, HttpServletRequest request) {
        HttpServletRequestDto httpServletRequestDto = Utility.createHttpServletDTO(request);
        return approvalRequestService.addRequestData(approvalRequest, httpServletRequestDto);
    }

    @GetMapping("/getAllRequestByUserID")
    public DataTablesOutput<ApprovalRequestEntity> getAllData(
            HttpServletRequest request,
            @Valid DataTablesInput input,
            @RequestParam(value = "searchText", required = false) String searchText,
            @RequestParam(value = "customQuery", required = false) String customQuery
    ) {


        if (customQuery.length() > 0) {
            JSONObject jsonObject = new JSONObject(customQuery);
        }
        return approvalRequestService.getAllRequestData(request, input, searchText, customQuery);
    }


    @GetMapping("/getAllRequestLogDetailsByUserID")
    public DataTablesOutput<ApprovalLogDetailsEntity> getAllApprovalLogDetailsData(
            HttpServletRequest request,
            @Valid DataTablesInput input,
            @RequestParam(value = "searchText", required = false) String searchText,
            @RequestParam(value = "customQuery", required = false) String customQuery
    ) {

        return approvalRequestService.getAllApprovalLogDetailsData(request, input, searchText, customQuery);
    }


    @PostMapping("/loadApprovalRequestDetailsData")
    public CommonRestResponse loadDataByFlowNameAndApprovalFlowForAndMasterId(@RequestBody ApprovalDetailsRequestDataDTO approvalRequestDto, HttpServletRequest request) {
        HttpServletRequestDto httpServletRequestDto = Utility.createHttpServletDTO(request);
        return approvalRequestService.loadDataByFlowNameAndApprovalFlowForAndMasterId(approvalRequestDto, httpServletRequestDto);
    }
}
