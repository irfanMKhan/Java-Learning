package com.reddot.ecrm.dto.agreement.pbx;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class Pbx_Template_5_params {

    private String MonthlyFeeBasic;
    private String MonthlyFeeStandard;
    private String MonthlyFeePremium;
    private String ChannelFeeBasic;
    private String ChannelFeeStandard;
    private String ChannelFeePremium;

    private String OnNetSmartNetwork;
    private String OffNetSmartNetwork;
    private String InternationalCalls;

    private String OnNetSms;
    private String OffNetSms;
    private String InternationalCallsForSMS;

    private String AdditionalMonthlyExpansionChannels;

    private String SIPOverLeasedLine;
    private String SIPOverInternet ;
    private String LocalAndInternationalCalls;
    private String Period;

}
