
package com.reddot.ecrm.api.payload.response.itsm;

import java.util.List;
import lombok.Data;

@Data
public class FetchContactIdByEmailResponse {
    private List<Item> items;

    private List<Link> links;

    @Data
    public static class Item {
        private List<String> columnNames;

        private Long count;

        private List<List<String>> rows;

        private String tableName;
    }

    @Data
    public static class Link {
        private String href;

        private String rel;
    }
}
