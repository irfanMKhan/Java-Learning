package com.reddot.ecrm.dto.bulk;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FileSaveDtoData {
    private MultipartFile file;
    private Long companyId;
    private String companyName;
    private String processType;
    private String processTypeId;
    private String uuid;
}
