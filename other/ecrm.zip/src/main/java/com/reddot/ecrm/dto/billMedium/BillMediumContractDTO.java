package com.reddot.ecrm.dto.billMedium;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BillMediumContractDTO {
    private Long id;
    private String tempNO;
    private Long companyId;
    private String companyName;
    private Long contractId;
    private String serviceTypeName;
    private String billMediumId;
    private String billMediumCodeValue;
    private String billMediumCodeType;
    private String billContentTypeValue;
    private String billContentType;
    private String billMediumInfo;
    private Boolean active;
    private Boolean isChanged;
    private Long crMasterId;
}
