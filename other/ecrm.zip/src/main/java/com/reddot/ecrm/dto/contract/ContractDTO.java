package com.reddot.ecrm.dto.contract;

import com.reddot.ecrm.dto.account.AccountDetailsDTO;
import com.reddot.ecrm.dto.attachment.AttachmentDTO;
import com.reddot.ecrm.dto.billMedium.BillMediumContractDTO;
import com.reddot.ecrm.dto.contact.ContactDTO;
import com.reddot.ecrm.dto.event.EventDTO;
import com.reddot.ecrm.dto.httpServletRequest.HttpServletRequestDto;
import com.reddot.ecrm.dto.product.ProductDetailsDTO;
import com.reddot.ecrm.dto.specialOffer.SpecialOfferDTO;
import com.reddot.ecrm.entity.contract.ContractEntity;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class ContractDTO {
    private Long id;
    private String customerLevel;
    private String contractNumber;
    private String opportunityNumber;
    private String customerName;
    private Long companyId;
    private String kam;
    private Long kamId;
    private String creatorName;
    private String status;
    private String saveType;
    private String uuidToken;
    private Long tenantId;
    private Long accountDetailsId;
    private Boolean isParentAccountInformation;

    private AccountDetailsDTO accountDetails;
    private List<ProductDetailsDTO> productDetailsList;
    private List<ContactDTO> contactDetailsList;
    private List<SpecialOfferDTO> specialOfferList;
    private List<AttachmentDTO> attachmentList;
    private List<EventDTO> eventList;
    private List<BillMediumContractDTO> billMediumList;

    private Boolean isCRContract;
    private String crType;
    private Long crMasterId;
    private Boolean isConvertedToContract;
    private Boolean isIndividual;
    private HttpServletRequestDto requestDTO;

    private Boolean isEventDtoChanged;
    private Boolean isProductDetailsChanged;
    private Boolean isAttachmentDtoChanged;
    private Boolean isContactDtoChanged;
    private Boolean isBillMediumDtoChanged;


    private String createBy;
    private String createByName;
    private LocalDateTime createDate;
    private LocalDate createdDateOnly;

    private Boolean isCreateMasterAccount;
    private String masterAccountName;

    private CompanyDetailsContractDTO companyDetailsContractDTO;
    private ContractEntity contractEntity;

}
