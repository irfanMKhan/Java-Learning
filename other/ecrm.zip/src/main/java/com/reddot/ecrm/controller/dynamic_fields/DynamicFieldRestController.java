package com.reddot.ecrm.controller.dynamic_fields;

import com.reddot.ecrm.entity.dynamicfield.DynamicFieldEntity;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.dynamicfield.DynamicFieldService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/dynamic/rest")
public class DynamicFieldRestController {

    @Autowired
    private DynamicFieldService dynamicFieldService;

    @GetMapping("/getAllDTData")
    public DataTablesOutput<DynamicFieldEntity> getAllData(@Valid DataTablesInput input, HttpServletRequest request,
                                                           @RequestParam(value = "searchText", required = false) String searchText,
                                                           @RequestParam(value = "searchCol", required = false) String searchCol) {
        return dynamicFieldService.getAllDTData(input, request, searchText, searchCol);
    }

    @PostMapping("/checkExistDynamicFieldDTData")
    public Boolean checkExistField(@RequestBody DynamicFieldEntity dynamicFieldEntities) {
        System.out.println(dynamicFieldEntities.toString());

        return true;
    }

    @PostMapping("/addDynamicFieldDTData")
    public CommonRestResponse addDynamicFieldDTData(@RequestBody List<DynamicFieldEntity> dynamicFieldEntities) {
        CommonRestResponse commonRestResponse = new CommonRestResponse();

        try {
            dynamicFieldService.addDataINDB(dynamicFieldEntities);
            commonRestResponse.setCode(201);
            commonRestResponse.setMessage("Successfully save the data");
        } catch (Exception e) {
            e.printStackTrace();
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Failed to save the data");
        }


        return commonRestResponse;
    }

    @PostMapping("/deleteRowData")
    public CommonRestResponse deleteDynamicRowData(@RequestBody Long id) {

        CommonRestResponse commonRestResponse = new CommonRestResponse();
        try {
            dynamicFieldService.deleteDataFromDB(id);
            commonRestResponse.setCode(201);
            commonRestResponse.setMessage("Successfully save the data");
        } catch (Exception e) {
            e.printStackTrace();
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Failed to save the data");
        }
        return commonRestResponse;
    }

    @PostMapping("/checkDynamicDataExits")
    public Boolean checkDynamicDataExits(@RequestBody DynamicFieldEntity dynamicFieldEntity) {
        return dynamicFieldService.checkDynamicDataExits(dynamicFieldEntity);
    }

}
