package com.reddot.ecrm.api.payload.response.contract.group;

import lombok.Data;

import java.io.Serializable;
import java.lang.String;

@Data
public class CreateCUGGroupResponse implements Serializable {
  private String transaction_id;

  private String transaction_status;

  private Metadata metadata;

  private Data data;


  @lombok.Data
  public static class Metadata implements Serializable {
    private String operator_id;

    private String channel_id;
  }

  @lombok.Data
  public static class Data implements Serializable {
    private String GroupName;

    private String GroupCode;
  }
}
