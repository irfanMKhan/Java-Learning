package com.reddot.ecrm.api.payload.response.contract.customer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.lang.Integer;
import java.lang.Long;
import java.lang.String;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class QueryCorporateCustResponse implements Serializable {
  private QueryCorporateCustRspMsg QueryCorporateCustRspMsg;

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class QueryCorporateCustRspMsg implements Serializable {
    private Customer Customer;

    private RspHeader RspHeader;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Customer implements Serializable {
      private Integer CustLevel;

      private Address Address;

      private Manager Manager;

      private CorporateInfo CorporateInfo;

      @Data
      @AllArgsConstructor
      @NoArgsConstructor
      public static class Address implements Serializable {
        private String Address7;

        private String Address5;

        private Integer Address2;

        private Integer Address3;

        private Integer Address1;

        private Integer AddressType;

        private Long AddressId;
      }

      @Data
      @AllArgsConstructor
      @NoArgsConstructor
      public static class Manager implements Serializable {
        private String Role;

        private Integer Status;

        private Integer CustManagerSeq;

        private String Email;

        private String ManagerName;

        private String OperatorId;

        private Long DepartmentId;
      }

      @Data
      @AllArgsConstructor
      @NoArgsConstructor
      public static class CorporateInfo implements Serializable {
        private Integer Industry;

        private Integer CustType;

        private String CustName;

        private String CustPhoneNumber;

        private Long RegisterDate;

        private String CustEmail;

        private Integer CustSize;

        private Integer RegisterCapital;

        private Certificate Certificate;

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class Certificate implements Serializable {
          private Long IdNum;

          private Integer IdType;
        }
      }
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class RspHeader implements Serializable {
      private Long RspTime;

      private String ReturnCode;

      private String ReturnMsg;

      private Integer Version;
    }
  }
}
