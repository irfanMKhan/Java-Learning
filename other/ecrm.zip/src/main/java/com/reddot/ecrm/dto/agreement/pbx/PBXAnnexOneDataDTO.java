package com.reddot.ecrm.dto.agreement.pbx;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class PBXAnnexOneDataDTO {
    private String no;
    private String number;
    private String monthlyPlan;
    private String monthlyFee;
    private String serviceDeposit;
    private String remark;

}
