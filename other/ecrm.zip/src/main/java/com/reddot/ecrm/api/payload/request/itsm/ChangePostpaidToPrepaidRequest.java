package com.reddot.ecrm.api.payload.request.itsm;

import lombok.Data;

import java.io.Serializable;
import java.lang.Integer;
import java.lang.String;
import java.util.List;

@Data
public class ChangePostpaidToPrepaidRequest implements Serializable {
  private Product product;

  private CustomFields customFields;

  private Product primaryContact;

  private StatusWithType statusWithType;

  private Product category;

  @Data
  public static class Product implements Serializable {
    private Integer id;
  }

  @Data
  public static class CustomFields implements Serializable {
    private C c;

    private ITSM ITSM;

    private CO CO;

    @Data
    public static class C implements Serializable {
      private Incident_type incident_type;

      private Integer urged_count;

      private Incident_type priority;

      @Data
      public static class Incident_type implements Serializable {
        private String lookupName;
      }
    }

    @Data
    public static class ITSM implements Serializable {
      private String BORefNumbers;
    }

    @Data
    public static class CO implements Serializable {
      private List<String> Issue;
    }
  }

  @Data
  public static class StatusWithType implements Serializable {
    private Product status;
  }
}
