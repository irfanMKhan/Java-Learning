package com.reddot.ecrm.controller.sr.notificationMatrix;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.dto.GlobalSettings.District.MDDistrictModel;
import com.reddot.ecrm.dto.GlobalSettings.Upazila.MDUpazilaModel;
import com.reddot.ecrm.dto.GlobalSettings.User.MDUserModel;
import com.reddot.ecrm.dto.sr.management.TBLSRModel;
import com.reddot.ecrm.dto.sr.management.TBLSRModelDT;
import com.reddot.ecrm.dto.srsettings.subarea.MDSrNotify;
import com.reddot.ecrm.dto.srsettings.subarea.MDSrSubAreaModel;
import com.reddot.ecrm.model.lov.CommonLovModel;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.service.EmailSenderService;
import com.reddot.ecrm.util.QueryBuilder;
import com.reddot.ecrm.util.SendMessage;
import com.reddot.ecrm.util.Utility;
import freemarker.template.Template;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SRStatusNotifyExecutor {

    private final Logger logger = LoggerFactory.getLogger("SRSettingsLogger");
//    ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
//    CommonDAO commonDAO = (CommonDAO) context.getBean("CommonDAO");

    @Autowired
    private CommonRepository commonDAO;

    @Autowired
    private FreeMarkerConfigurer freemarkerConfigurer;

    @Autowired
    private EmailSenderService emailSenderService;


    public void execute(TBLSRModelDT tblsrModelDT, HttpServletRequest request) {
        try {
            String query = "";
            Object objects;
            MDSrSubAreaModel mdSrSubAreaModel = new MDSrSubAreaModel();
            List<MDSrNotify> notifyList = new ArrayList<>();

            Map<String, Object> searchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            searchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");
            searchData.put("ID", tblsrModelDT.getSrSubAreaId());
            whereSearchType.put("ID", "AND");

            query = QueryBuilder.getSelectWhereQuery(Utility.md_sr_sub_area, searchData, whereSearchType);
            logger.info(query);
            objects = commonDAO.getDataPostgres(query);
            List<MDSrSubAreaModel> subAreaList = new Gson().fromJson(Utility.ObjectToJson(objects), new TypeToken<List<MDSrSubAreaModel>>() {
            }.getType());
            if (subAreaList.size() > 0) {
                mdSrSubAreaModel = subAreaList.get(0);
            } else {
                return;
            }

            searchData.clear();
            whereSearchType.clear();
            searchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");
            searchData.put("UNIQUE_ID", mdSrSubAreaModel.getUNIQUE_ID());
            whereSearchType.put("UNIQUE_ID", "AND");
            query = QueryBuilder.getSelectWhereQuery(Utility.md_sr_notify_mt, searchData, whereSearchType);
            logger.info(query);
            objects = commonDAO.getDataPostgres(query);
            notifyList = new Gson().fromJson(Utility.ObjectToJson(objects), new TypeToken<List<MDSrNotify>>() {
            }.getType());
            if (notifyList.size() == 0) {
                return;
            }

            for (MDSrNotify m : notifyList) {
                if (m.getSR_STATUS_NAME().equalsIgnoreCase(tblsrModelDT.getSrStatusName())) {
                    notifyUser(null, String.valueOf(tblsrModelDT.getSrNum()), tblsrModelDT.getSrStatusId(), tblsrModelDT.getSrStatusName(), m.getSR_NOTIFYTO_TYPE_NAME(), mdSrSubAreaModel, String.valueOf(tblsrModelDT.getMsisdn()), request);
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    //    @Async
    public void notifyOwnerOverEmail(String srNum, MDSrSubAreaModel mdSrSubAreaModel, Logger logger) {
        try {
            String emailQuery = "SELECT ID, OWNER_EMAIL AS NAME FROM " + Utility.md_user_position + " WHERE ID='" + mdSrSubAreaModel.getOWNER_GROUP_ID() + "'";
            Object ownerObjects = commonDAO.getDataPostgres(emailQuery);
            List<CommonLovModel> emails = new Gson().fromJson(Utility.ObjectToJson(ownerObjects), new TypeToken<List<CommonLovModel>>() {
            }.getType());
            if (emails.isEmpty()) {
                return;
            }
            String ownerEmail = emails.get(0).getNAME();

            if (ownerEmail == null || ownerEmail.isEmpty()) {
                return;
            }

            TBLSRModel tblsrModel;
            String query = "SELECT SR_NUM, SLA_HR, OWNER_NAME, MSISDN, SUBMITTED_AT, ACC_CLASS_NAME, SR_SERVICE_TYPE_NAME, COMMITED_AT, SR_TYPE_NAME, SRC_LOCATION_NAME, SR_AREA_NAME, IS_REOPENED, SR_SUB_AREA_NAME, MASTER_ISSUE, DESCRIPTION, SUMMARY, FULL_ADDRESS FROM " + Utility.tbl_sr + " WHERE SR_NUM='" + srNum + "'";
            Object objects = commonDAO.getDataPostgres(query);
            List<TBLSRModel> tblsrModelList = new Gson().fromJson(Utility.ObjectToJson(objects), new TypeToken<List<TBLSRModel>>() {
            }.getType());
            if (tblsrModelList.size() > 0) {
                tblsrModel = tblsrModelList.get(0);
            } else {
                return;
            }

            Map<String, Object> templateModel = new HashMap<>();
            templateModel.put("userFullName", mdSrSubAreaModel.getOWNER_NAME() == null ? "" : mdSrSubAreaModel.getOWNER_NAME());
            templateModel.put("srNum", tblsrModel.getSR_NUM());
            templateModel.put("slaHr", tblsrModel.getSLA_HR());
            templateModel.put("ownerName", mdSrSubAreaModel.getOWNER_NAME() == null ? "" : mdSrSubAreaModel.getOWNER_NAME());
            templateModel.put("msisdn", tblsrModel.getMSISDN());
            templateModel.put("submittedDate", Utility.convertTimestampToDateTime(tblsrModel.getSUBMITTED_AT(), "yyyy-MM-dd HH:mm:ss"));
            templateModel.put("accClass", tblsrModel.getACC_CLASS_NAME());
            templateModel.put("interactionType", tblsrModel.getSR_SERVICE_TYPE_NAME());
            templateModel.put("commitTime", Utility.convertTimestampToDateTime(tblsrModel.getCOMMITED_AT(), "yyyy-MM-dd HH:mm:ss"));
            templateModel.put("srType", tblsrModel.getSR_TYPE_NAME());
            templateModel.put("sourceLocationName", tblsrModel.getSRC_LOCATION_NAME());
            templateModel.put("areaName", tblsrModel.getSR_AREA_NAME());
            templateModel.put("isReopened", getFormattedYesNo(tblsrModel.getIS_REOPENED()));
            templateModel.put("subArea", tblsrModel.getSR_SUB_AREA_NAME());
            templateModel.put("masterIssue", getFormattedYesNo(tblsrModel.getMASTER_ISSUE()));
            templateModel.put("description", tblsrModel.getDESCRIPTION() == null ? "" : tblsrModel.getDESCRIPTION());
            templateModel.put("summary", tblsrModel.getSUMMARY() == null ? "" : tblsrModel.getSUMMARY());
            templateModel.put("fullAddress", tblsrModel.getFULL_ADDRESS() == null ? "" : tblsrModel.getFULL_ADDRESS());

            Template freemarkerTemplate = freemarkerConfigurer.createConfiguration()
                    .getTemplate("newSrMail.ftl");
            String htmlBody = FreeMarkerTemplateUtils.processTemplateIntoString(freemarkerTemplate, templateModel);
            emailSenderService.sendEmail(ownerEmail, htmlBody, "SR no. " + tblsrModel.getSR_NUM() + " has been created");
        } catch (
                Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }

    }

    //    @Async
    public void notifyChangeOwner(String srNum, Logger logger, Long ownerId, HttpServletRequest request) {
        try {
            String userQuery = "SELECT * FROM " + Utility.md_user + " WHERE ID='" + ownerId + "'";
            Object userObject = commonDAO.getDataPostgres(userQuery);
            List<MDUserModel> users = new Gson().fromJson(Utility.ObjectToJson(userObject), new TypeToken<List<MDUserModel>>() {
            }.getType());
            if (users.isEmpty()) {
                return;
            }
            MDUserModel mdUserModel = users.get(0);
            String ownerEmail = users.get(0).getEMAIL();

            if (ownerEmail == null || ownerEmail.isEmpty()) {
                return;
            }

            TBLSRModel tblsrModel;
            String query = "SELECT SR_NUM, SLA_HR, OWNER_NAME, MSISDN, SUBMITTED_AT, ACC_CLASS_NAME, SR_SERVICE_TYPE_NAME, COMMITED_AT, SR_TYPE_NAME, SRC_LOCATION_NAME, SR_AREA_NAME, IS_REOPENED, SR_SUB_AREA_NAME, MASTER_ISSUE, DESCRIPTION, SUMMARY, FULL_ADDRESS FROM " + Utility.tbl_sr + " WHERE SR_NUM='" + srNum + "'";
            Object objects = commonDAO.getDataPostgres(query);
            List<TBLSRModel> tblsrModelList = new Gson().fromJson(Utility.ObjectToJson(objects), new TypeToken<List<TBLSRModel>>() {
            }.getType());
            if (tblsrModelList.size() > 0) {
                tblsrModel = tblsrModelList.get(0);
            } else {
                return;
            }

            Map<String, Object> templateModel = new HashMap<>();
            templateModel.put("userFullName", mdUserModel.getLOGIN_NAME() == null ? "" : mdUserModel.getLOGIN_NAME());
            templateModel.put("srNum", tblsrModel.getSR_NUM());
            templateModel.put("slaHr", tblsrModel.getSLA_HR());
            templateModel.put("ownerName", mdUserModel.getLOGIN_NAME());
            templateModel.put("msisdn", tblsrModel.getMSISDN());
            templateModel.put("submittedDate", Utility.convertTimestampToDateTime(tblsrModel.getSUBMITTED_AT(), "yyyy-MM-dd HH:mm:ss"));
            templateModel.put("accClass", tblsrModel.getACC_CLASS_NAME());
            templateModel.put("interactionType", tblsrModel.getSR_SERVICE_TYPE_NAME());
            templateModel.put("commitTime", Utility.convertTimestampToDateTime(tblsrModel.getCOMMITED_AT(), "yyyy-MM-dd HH:mm:ss"));
            templateModel.put("srType", tblsrModel.getSR_TYPE_NAME());
            templateModel.put("sourceLocationName", tblsrModel.getSRC_LOCATION_NAME());
            templateModel.put("areaName", tblsrModel.getSR_AREA_NAME());
            templateModel.put("isReopened", getFormattedYesNo(tblsrModel.getIS_REOPENED()));
            templateModel.put("subArea", tblsrModel.getSR_SUB_AREA_NAME());
            templateModel.put("masterIssue", getFormattedYesNo(tblsrModel.getMASTER_ISSUE()));
            templateModel.put("description", tblsrModel.getDESCRIPTION() == null ? "" : tblsrModel.getDESCRIPTION());
            templateModel.put("summary", tblsrModel.getSUMMARY() == null ? "" : tblsrModel.getSUMMARY());
            templateModel.put("fullAddress", tblsrModel.getFULL_ADDRESS() == null ? "" : tblsrModel.getFULL_ADDRESS());

            Template freemarkerTemplate = freemarkerConfigurer.createConfiguration()
                    .getTemplate("newSrMail.ftl");
            String htmlBody = FreeMarkerTemplateUtils.processTemplateIntoString(freemarkerTemplate, templateModel);
            emailSenderService.sendEmail(ownerEmail, htmlBody, "SR no. " + tblsrModel.getSR_NUM() + " has been created");
            new SendMessage().send(mdUserModel.getWORK_PHONE(), "Dear " + mdUserModel.getLOGIN_NAME() + ",\n" +
                    "Greetings from Robi.\n" +
                    "Complaint no. " + srNum + " has been assigned to you to take action within the SLA (" + tblsrModel.getSLA_HR() + "Hr).", "SR", request);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }

    }

    private String getFormattedYesNo(Integer value) {
        if (value != null && value == 1) {
            return "Y";
        } else {
            return "N";
        }
    }

    // we use TBLSRModel only to get the thana and district name
    private void notifyUser(TBLSRModel tblsrModel, String srNum, Long srStatusId, String statusName, String notifyTo, MDSrSubAreaModel mdSrSubAreaModel, String customer, HttpServletRequest request) {
        try {
            String msisdn = "";
            String message = "The Service Request number " + srNum + " having status: " + statusName;

            String upazilaNameBn = null;
            String districtNameBn = null;
            if (tblsrModel.getTHANA() != null) {
                String queryForUpazila = "select * from " + Utility.md_upazila + " where name = '" + tblsrModel.getTHANA() + "' " + " and district_name = '" + tblsrModel.getDISTRICT() + "' ";
                logger.info(queryForUpazila);
                Object upazilaName = commonDAO.getDataPostgres(queryForUpazila);

                MDUpazilaModel mdUpazilaModel = null;
                MDDistrictModel mdDistrictModel = null;
                List<MDUpazilaModel> mdUpazilaModelList = new Gson().fromJson(Utility.ObjectToJson(upazilaName), new TypeToken<List<MDUpazilaModel>>() {
                }.getType());
                if (mdUpazilaModelList.size() > 0) {
                    mdUpazilaModel = mdUpazilaModelList.get(0);
                    upazilaNameBn = mdUpazilaModel.getNAME_BN();
                }

                String queryForDistrict = "select * from " + Utility.md_district + " where name = '" + tblsrModel.getDISTRICT() + "' ";
                logger.info(queryForDistrict);
                Object districtName = commonDAO.getDataPostgres(queryForDistrict);
                List<MDDistrictModel> mdDistrictModelList = new Gson().fromJson(Utility.ObjectToJson(districtName), new TypeToken<List<MDDistrictModel>>() {
                }.getType());
                if (mdDistrictModelList.size() > 0) {
                    mdDistrictModel = mdDistrictModelList.get(0);
                    districtNameBn = mdDistrictModel.getNAME_BN();
                }
            }

            String queryForSubArea = "SELECT * FROM " + Utility.md_sr_sub_area + " WHERE ID = '" + mdSrSubAreaModel.getID() + "' AND REQUIRED_LOCATION_SMS = '1'";
            logger.info(queryForSubArea);
            Object srSubAreaName = commonDAO.getDataPostgres(queryForSubArea);
            MDSrSubAreaModel tempMDSrSubAreaModel = null;
            List<MDSrSubAreaModel> mdSrSubAreaModelList = new Gson().fromJson(Utility.ObjectToJson(srSubAreaName), new TypeToken<List<MDSrSubAreaModel>>() {
            }.getType());
            if (mdSrSubAreaModelList.size() > 0) {
                tempMDSrSubAreaModel = mdSrSubAreaModelList.get(0);
            }
            if (srStatusId != null && srStatusId == 6) {
//                message = "Dear Customer, \nyour service request " + srNum + " has been resolved. Thank you.";
                // pass upazilaName and districtName in below method
                message = getSRClosingMessage(srNum, tblsrModel.getIS_NETWORK(), mdSrSubAreaModel.getSR_SERVICE_TYPE_NAME(), upazilaNameBn, districtNameBn, tempMDSrSubAreaModel);
            }
            switch (notifyTo) {
                case "Customer": {
                    msisdn = customer;
                    break;
                }
                case "Manager":
                case "Supervisor": {
                    break;
                }
                case "Owner": {
                    MDUserModel mdUserModel = new MDUserModel();
                    Map<String, Object> searchData = new HashMap<String, Object>();
                    Map<String, Object> whereSearchType = new HashMap<String, Object>();
                    searchData.put("ACTIVE", "1");
                    whereSearchType.put("ACTIVE", "AND");
                    searchData.put("ID", mdSrSubAreaModel.getOWNER_ID());
                    whereSearchType.put("ID", "AND");

                    String query = QueryBuilder.getSelectWhereQuery(Utility.md_user, searchData, whereSearchType);
                    logger.info(query);
                    Object objects = commonDAO.getDataPostgres(query);
                    List<MDUserModel> userList = new Gson().fromJson(Utility.ObjectToJson(objects), new TypeToken<List<MDUserModel>>() {
                    }.getType());
                    if (userList.size() > 0) {
                        mdUserModel = userList.get(0);
                        msisdn = mdUserModel.getWORK_PHONE();
                    } else {
                        return;
                    }
                    break;
                }
            }
            if (!message.isEmpty()) {
                new SendMessage().send(msisdn, message, "SR", request);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    private String getSRClosingMessage(String srNo, String isNetwork, String interactionType, String thanaNameBangla, String districtNameBangla, MDSrSubAreaModel mdSrSubAreaModel) {
        String message = "";

        switch (interactionType) {
            case "Complaint":
                if (thanaNameBangla != null && districtNameBangla != null && mdSrSubAreaModel != null) {
                    if (isNetwork != null && isNetwork == "1") {
                        message = "প্রিয় গ্রাহক, " + districtNameBangla + "-" + thanaNameBangla + " এলাকার জন্য আপনার নেটওয়ার্ক সংক্রান্ত অভিযোগ নং " + srNo + " সমাধান করা হয়েছে। আমাদের সাথে থাকার জন্য ধন্যবাদ।";
                        break;
                    } else {
                        message = "প্রিয় গ্রাহক, আপনার অভিযোগ নং " + srNo + " সমাধান করা হয়েছে। আমাদের সাথে থাকার জন্য ধন্যবাদ।";
                    }
                    break;
                } else {
                    if (isNetwork != null && isNetwork == "1") {
                        message = "প্রিয় গ্রাহক, আপনার নেটওয়ার্ক সংক্রান্ত অভিযোগ নং " + srNo + " সমাধান করা হয়েছে। আমাদের সাথে থাকার জন্য ধন্যবাদ।";
                        break;
                    } else {
                        message = "প্রিয় গ্রাহক, আপনার অভিযোগ নং " + srNo + " সমাধান করা হয়েছে। আমাদের সাথে থাকার জন্য ধন্যবাদ।";
                    }
                    break;
                }

            case "Request":
                message = "প্রিয় গ্রাহক, আপনার অনুরোধ নং " + srNo + " কার্যকর করা হয়েছে। আমাদের সাথে থাকার জন্য ধন্যবাদ।";
                break;

        }

        return message;
    }


    public void execute(String srNumber, HttpServletRequest request) {
        try {
            String query = "";
            Object objects;
            TBLSRModel tblsrModel = new TBLSRModel();
            Map<String, Object> searchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            searchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");
            searchData.put("SR_NUM", srNumber);
            whereSearchType.put("SR_NUM", "AND");

            query = QueryBuilder.getSelectWhereQuery(Utility.tbl_sr, searchData, whereSearchType);
            objects = commonDAO.getDataPostgres(query);
            List<TBLSRModel> tblsrModelList = new Gson().fromJson(Utility.ObjectToJson(objects), new TypeToken<List<TBLSRModel>>() {
            }.getType());
            if (tblsrModelList.size() > 0) {
                tblsrModel = tblsrModelList.get(0);
            } else {
                return;
            }

            MDSrSubAreaModel mdSrSubAreaModel = new MDSrSubAreaModel();
            List<MDSrNotify> notifyList = new ArrayList<>();

            searchData.clear();
            whereSearchType.clear();
            searchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");
            searchData.put("ID", tblsrModel.getSR_SUB_AREA_ID());
            whereSearchType.put("ID", "AND");

            query = QueryBuilder.getSelectWhereQuery(Utility.md_sr_sub_area, searchData, whereSearchType);
            logger.info(query);
            objects = commonDAO.getDataPostgres(query);
            List<MDSrSubAreaModel> subAreaList = new Gson().fromJson(Utility.ObjectToJson(objects), new TypeToken<List<MDSrSubAreaModel>>() {
            }.getType());
            if (subAreaList.size() > 0) {
                mdSrSubAreaModel = subAreaList.get(0);
            } else {
                return;
            }

            searchData.clear();
            whereSearchType.clear();
            searchData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");
            searchData.put("UNIQUE_ID", mdSrSubAreaModel.getUNIQUE_ID());
            whereSearchType.put("UNIQUE_ID", "AND");
            query = QueryBuilder.getSelectWhereQuery(Utility.md_sr_notify_mt, searchData, whereSearchType);
            logger.info(query);
            objects = commonDAO.getDataPostgres(query);
            notifyList = new Gson().fromJson(Utility.ObjectToJson(objects), new TypeToken<List<MDSrNotify>>() {
            }.getType());
            if (notifyList.size() == 0) {
                return;
            }

            for (MDSrNotify m : notifyList) {
                if (m.getSR_STATUS_ID().equals(tblsrModel.getSR_STATUS_ID() + "")) {
                    notifyUser(tblsrModel, tblsrModel.getSR_NUM(), tblsrModel.getSR_STATUS_ID(), tblsrModel.getSR_STATUS_NAME(), m.getSR_NOTIFYTO_TYPE_NAME(), mdSrSubAreaModel, tblsrModel.getMSISDN(), request);
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }
}
