package com.reddot.ecrm.api.exception;

public class ConnectionResetException extends RuntimeException {
    public ConnectionResetException(String message) {
        super(message);
    }

    public ConnectionResetException(String message, Throwable throwable) {
        super(message, throwable);
    }
}