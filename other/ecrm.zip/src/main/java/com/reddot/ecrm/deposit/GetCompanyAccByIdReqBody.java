package com.reddot.ecrm.deposit;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetCompanyAccByIdReqBody {
    private String id;
}
