package com.reddot.ecrm.controller.lead.quotation;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.UserModel;
import com.reddot.ecrm.service.lead.quotation.QuotationDefaultTermsAndConditionsService;
import com.reddot.ecrm.service.lead.settings.LeadStatusService;
import com.reddot.ecrm.service.user.UserService;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/quotation/terms-and-conditions")
public class QuotationDefaultTermsAndConditionsController {
    
    @Autowired
    private QuotationDefaultTermsAndConditionsService quotationDefaultTermsAndConditionsService;
    
    @Autowired
    private UserService userService;
    
    @RequestMapping(value = "", method = RequestMethod.GET)
    public String viewQuotationDefaultTermsAndConditionsList(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        
        model.addAttribute("title", "Default Terms and Conditions");
        model.addAttribute("breadcrumb", "Default Terms and Conditions");
        
        return "lead/quotation/default_terms_and_conditions_list";
    }
    
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public String addQuotationDefaultTermsAndConditions(ModelMap model, HttpServletRequest request, Principal principal) {
        new MenuViewer().setupSideMenu(model, request);
        
        model.addAttribute("title", "Add Lead Status");
        model.addAttribute("breadcrumb", "Add");
        
        return "lead/quotation/default_terms_and_conditions_add";
    }
    
}
