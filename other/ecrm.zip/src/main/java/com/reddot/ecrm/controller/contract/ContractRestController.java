//package com.reddot.ecrm.controller.contract;
//
//import com.google.gson.Gson;
//import com.google.gson.GsonBuilder;
//import com.reddot.ecrm.dto.contract.ContractDTO;
//import com.reddot.ecrm.dto.contract.ContractReqSingleDTO;
//import com.reddot.ecrm.entity.contract.ContractEntity;
//import com.reddot.ecrm.model.CommonRestResponse;
//import com.reddot.ecrm.service.contract.ContractService;
//import com.reddot.ecrm.util.LocalDateTypeAdapter;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//import javax.servlet.http.HttpServletRequest;
//import java.time.LocalDate;
//import java.util.List;
//
//@RestController
//@RequestMapping("/contract/rest")
//public class ContractRestController {
////    @Autowired
////    ContractService contractService;
////
////    @GetMapping("/getContractNumber")
////    CommonRestResponse getContractNo() {
////        return contractService.getContractNo();
////    }
////
////    @PostMapping("/add")
////    public List<ContractEntity> addContract(@RequestPart("contractDTO") String contractDTOJson,
////                                            HttpServletRequest request) {
////
////        Gson gson = new GsonBuilder()
////                .registerTypeAdapter(LocalDate.class, new LocalDateTypeAdapter())
////                .create();
////        ContractDTO dto = gson.fromJson(contractDTOJson, ContractDTO.class);
////        contractService.saveContract(dto, request);
////        return null;
////    }
////
////    @PostMapping("/load/singleContractData")
////    public CommonRestResponse loadContractByID(@RequestBody ContractReqSingleDTO contractReqSingleDTO, HttpServletRequest request) {
////
////        //        FieldChecker.checkFields(searchContractDTO);
////        System.out.println(contractReqSingleDTO);
////        CommonRestResponse commonRestResponse = new CommonRestResponse();
////        commonRestResponse.setData(contractReqSingleDTO);
////        return commonRestResponse;
////
////
////    }
//
//
//}
