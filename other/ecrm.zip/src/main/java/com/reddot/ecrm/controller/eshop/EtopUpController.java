package com.reddot.ecrm.controller.eshop;

import com.reddot.ecrm.service.eshop.EtopUpService;
import com.reddot.ecrm.service.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/crm/eShop")
public class EtopUpController {

    @Autowired
    private EtopUpService eTopUpService;

    @Autowired
    private UserService userService;

    //if we need later
}
