
package com.reddot.ecrm.api.payload.response.itsm;

import lombok.Data;

import java.util.List;

@Data
public class FetchServiceRequestDetailsResponse {
    private List<Item> items;

    private List<Link> links;

    @Data
    public static class Item {
        private List<String> columnNames;

        private Long count;

        private List<List<String>> rows;

        private String tableName;
    }

    @Data
    public static class Link {
        private String href;

        private String rel;

        private String mediaType;
    }
}
