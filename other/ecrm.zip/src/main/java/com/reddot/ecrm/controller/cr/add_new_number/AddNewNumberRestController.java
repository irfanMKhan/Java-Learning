package com.reddot.ecrm.controller.cr.add_new_number;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.reddot.ecrm.dto.cr.CRSummarySearchDTO;
import com.reddot.ecrm.dto.cr.CRWithBillMediumDTO;
import com.reddot.ecrm.dto.cr.MultipleMSISDNSearchDTO;
import com.reddot.ecrm.dto.httpServletRequest.HttpServletRequestDto;
import com.reddot.ecrm.entity.cr.CRMasterEntity;
import com.reddot.ecrm.entity.cr.CRMsisdnDetailsEntity;
import com.reddot.ecrm.enum_config.bulk.BulkProcessFileTypeEnum;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.company.CompanyAccountService;
import com.reddot.ecrm.service.contract.ContractService;
import com.reddot.ecrm.service.cr.add_new_number.AddNewNumberService;
import com.reddot.ecrm.service.cr.change_plan.ChangePlanService;
import com.reddot.ecrm.util.LocalDateTypeAdapter;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Set;

@RestController
@RequestMapping("/cr/add/rest")
@RequiredArgsConstructor
@Slf4j
public class AddNewNumberRestController {
    private final ContractService contractService;
    @Autowired
    AddNewNumberService addNewNumberService;
    @Autowired
    CompanyAccountService companyAccountService;

    @Autowired
    ChangePlanService changePlanService;

    @PostMapping("/getAllNumberDataByCompanyID")
    public CommonRestResponse getAllNumberDataByCompanyID(@RequestBody Long companyId) {
        return addNewNumberService.getAllDataByCompanyId(companyId);
    }

    @PostMapping("/getQueryNumberDataByCompanyID")
    public CommonRestResponse getQueryNumberDataByCompanyID(@RequestBody MultipleMSISDNSearchDTO multipleMSISDNSearchDTO) {
        return addNewNumberService.getSearchQueryAllDataByCompanyId(multipleMSISDNSearchDTO.getSearchQuery(), multipleMSISDNSearchDTO.getCompanyId());
    }

    @GetMapping("/getQueryNumberDataByCompanyID/serverside")
    public DataTablesOutput<CRMsisdnDetailsEntity> getQueryNumberDataByCompanyIDWithPagination(
            HttpServletRequest request,
            @Valid DataTablesInput input,
            @RequestParam(value = "searchDto", required = false) String searchDtoJson

    ) {
        MultipleMSISDNSearchDTO multipleMSISDNSearchDTO = new MultipleMSISDNSearchDTO();
        if (searchDtoJson != null) {
            try {
                Gson gson = new GsonBuilder()
                        .registerTypeAdapter(LocalDate.class, new LocalDateTypeAdapter())
                        .create();
                multipleMSISDNSearchDTO = gson.fromJson(searchDtoJson, MultipleMSISDNSearchDTO.class);

            } catch (Exception e) {
                log.error(e.getMessage());
                // Handle the exception or log the error
            }
        }
        return addNewNumberService.getSearchQueryAllDataByCompanyIdWithPagination(request, input, multipleMSISDNSearchDTO);
    }


    @PostMapping("/saveNewNumbers")
    public CommonRestResponse saveNewNumbers(@RequestBody CRWithBillMediumDTO crBillMediumDTO, HttpServletRequest request) {
        HttpServletRequestDto httpServletRequestDto = Utility.createHttpServletDTO(request);
        return addNewNumberService.addNewNumbers(crBillMediumDTO, httpServletRequestDto);
    }


    @PostMapping("/upload/bulkFileNewNumber")
    public CommonRestResponse bulkUpload(HttpServletRequest request, @RequestParam("file") MultipartFile file,
                                         @RequestParam("processNow") String processNow, @RequestParam("companyName") String companyName,
                                         @RequestParam("processDate") String processDate, @RequestParam("companyId") String companyId
    ) throws ServletException, IOException {
        return addNewNumberService.addNewNumbersBulkUpload(request, file, processDate, processNow, companyId, companyName);
    }

    @GetMapping("/download/bulkfile")
    public ResponseEntity<?> getFile() throws IOException {
        String fileLocation = Utility.cr_demo_bulk_file_location;
        InputStreamResource file = new InputStreamResource(new FileInputStream(fileLocation));
        String filename = Utility.cr_ad_new_number_demo_bulk_file_name;
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
                .contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
                .body(file);
    }


    @GetMapping("/download/bulkTemplatefile")
    public ResponseEntity<?> getBulkTemplateFileCommon(@RequestParam("bulkFileType") String bulkFileType) throws IOException {
        String fileLocation = Utility.cr_demo_bulk_file_location;
        InputStreamResource file = new InputStreamResource(new FileInputStream(fileLocation));
        String filename = Utility.cr_ad_new_number_demo_bulk_file_name;
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
                .contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
                .body(file);
    }


    @PostMapping("/getAllBulkFiles")
    public CommonRestResponse getAllBulkFiles(@RequestParam("companyId") Long companyId, @RequestParam("processId") Integer processId, HttpServletRequest request) {

        return addNewNumberService.getAllBulkFilesByCompanyIdAndUserID(companyId, request, processId);
    }

    @PostMapping("/getAllBulkFilesWithoutCompanyId")
    public CommonRestResponse getAllBulkFilesWithoutCompanyId(@RequestParam("processId") Integer processId, HttpServletRequest request) {

        return addNewNumberService.getAllBulkFilesByUserIDAndProcessID(request, processId);
    }

    @PostMapping("/getAllBulkFileDetails")
    public CommonRestResponse getAllBulkFileDetails(@RequestParam(value = "companyId") Long companyId, @RequestParam("fileId") Long fileId, @RequestParam("processId") Integer processId, HttpServletRequest request) {
        return addNewNumberService.getAllBulkFileDetailsByCompanyIdAndUserIDAndFileId(companyId, request, fileId, processId);
    }

    @PostMapping("/getAllBulkFileDetailsWithoutCompanyId")
    public CommonRestResponse getAllBulkFileDetailsWithOutCompanyId(@RequestParam("fileId") Long fileId, @RequestParam("processId") Integer processId, HttpServletRequest request) {
        return addNewNumberService.getAllBulkFileDetailsByUserIDAndFileId(request, fileId, processId);
    }

    @GetMapping("/summary/getAllData")
    public CommonRestResponse getAllSummaryData(HttpServletRequest request, @Valid DataTablesInput input) {
        return addNewNumberService.getAllSummaryData(request, input);
    }

    @PostMapping("/summary/single/details")
    public CommonRestResponse getSingleReqSummaryData(@RequestBody Long reqSummaryId, HttpServletRequest request) {
        return addNewNumberService.getSingleReqSummaryData(reqSummaryId, request);
    }

    @PostMapping("/summary/single/approval-detail")
    public CommonRestResponse getSingleReqSummaryApprovalData(@RequestBody Long reqSummaryId, HttpServletRequest request) {
        return addNewNumberService.getSingleReqSummaryApprovalData(reqSummaryId, request);
    }

    @GetMapping("/get/allPrimaryOfferingPlan")
    public CommonRestResponse getAllBundlePlan() {
        return addNewNumberService.getAllPrimaryOfferingPlan();
    }

    @GetMapping("/get/allSupplementaryOfferingPlan")
    public CommonRestResponse getAllSupplementaryBundlePlan() {
        return addNewNumberService.getAllSupplementaryOfferingPlan();
    }

    @PostMapping("/get/allPOAddon")
    public CommonRestResponse getAllPOAddON(@RequestBody String planName) {
        return addNewNumberService.getAllPrimaryOfferingAddONByName(planName);
    }

    @PostMapping("/get/allPOAddon/ngbssOfferingId")
    public CommonRestResponse getAllAddOnByNgbssOfferingId(@RequestBody Long ngbssOfferingId) {
        return addNewNumberService.getAllPrimaryOfferingAddONByNgbssOfferingID(ngbssOfferingId);
    }

    @GetMapping("/summary/getAllQueryData")
    public DataTablesOutput<CRMasterEntity> getAllApprovalLogDetailsData(
            HttpServletRequest request,
            @Valid DataTablesInput input,
            @RequestParam(value = "searchDto", required = false) String searchDtoJson
    ) {
        CRSummarySearchDTO searchDTO = null;
        if (searchDtoJson != null) {
            try {
                Gson gson = new GsonBuilder()
                        .registerTypeAdapter(LocalDate.class, new LocalDateTypeAdapter())
                        .create();
                searchDTO = gson.fromJson(searchDtoJson, CRSummarySearchDTO.class);

            } catch (Exception e) {
                log.error(e.getMessage());
                // Handle the exception or log the error
            }
        }
        return addNewNumberService.getSummaryQueryData(request, input, searchDTO);
    }

    @PostMapping("/get/allServiceByCompanyName")
    public Set<String> getAllServiceByCompanyName(@RequestBody String companyName) {
        return companyAccountService.getAllServiceByCompanyName(companyName, null);
    }

    @PostMapping("/get/checkAnyContractInProcessing")
    public Boolean checkAnyContractInProcessing(@RequestBody String companyName, HttpServletRequest request) {
        HttpServletRequestDto httpServletRequestDto = Utility.createHttpServletDTO(request);
        return contractService.checkContractDataIsInProcessing(companyName, httpServletRequestDto);
    }

    @PostMapping("/getAll/attachmentByMasterID")
    public CommonRestResponse getAllAttachmentByMasterID(@RequestBody Long crMasterID, HttpServletRequest request) {
        return changePlanService.getAllAttachmentByMasterID(crMasterID, BulkProcessFileTypeEnum.Add_New_Number);
    }
}
