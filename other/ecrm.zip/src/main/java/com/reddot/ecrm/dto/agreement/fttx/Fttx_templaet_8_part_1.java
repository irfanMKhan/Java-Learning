package com.reddot.ecrm.dto.agreement.fttx;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class Fttx_templaet_8_part_1 {
    private String item;
    private String smart;
    private String timesOfSupport;
}
