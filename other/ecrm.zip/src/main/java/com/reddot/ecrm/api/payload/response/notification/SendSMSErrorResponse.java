package com.reddot.ecrm.api.payload.response.notification;

import lombok.Data;

import java.io.Serializable;

@Data
public class SendSMSErrorResponse implements Serializable {
    private RequestError requestError;

    @Data
    public static class RequestError implements Serializable {
        private ServiceException serviceException;

        @Data
        public static class ServiceException implements Serializable {
            private String messageId;

            private String text;
        }
    }
}
