package com.reddot.ecrm.controller.lead.settings;

import com.reddot.ecrm.dto.lead.settings.LeadOppPercentageDto;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.lead.settings.LeadOppPercentageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequestMapping("lead/oppPercentage")
public class LeadOppPercentageRestController {
    
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    
    @Autowired
    private LeadOppPercentageService leadOppPercentageService;
    
    
    @GetMapping("/dt/all")
    public DataTablesOutput<LeadOppPercentageDto> dtLeadOppPercentage(@Valid DataTablesInput input,
                                                                    HttpServletRequest request,
                                                     @RequestParam(value = "searchText", required = false) String searchText, @RequestParam(value = "searchCol", required = false) String searchCol) {
        return leadOppPercentageService.getDTLeadOppPercentage(input, request, searchText, searchCol);
    }
    
    @PostMapping("/add")
    public CommonRestResponse addLeadOppPercentage(HttpServletRequest request,
                                    @RequestBody LeadOppPercentageDto leadOppPercentageDto) {
        return leadOppPercentageService.addLeadOppPercentage(request, leadOppPercentageDto);
    }
    
    @GetMapping("/details")
    public CommonRestResponse getLeadOppPercentageById(@RequestParam("id") Long id) {
        return leadOppPercentageService.getLeadOppPercentageById(id);
    }
    
    @PostMapping("/update")
    public CommonRestResponse updateLeadOppPercentage(HttpServletRequest request,
                                               @RequestBody LeadOppPercentageDto leadOppPercentageDto) {
        return leadOppPercentageService.updateLeadOppPercentage(request, leadOppPercentageDto);
    }

}