package com.reddot.ecrm.controller.lead.settings;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.UserModel;
import com.reddot.ecrm.service.lead.settings.IndustryService;
import com.reddot.ecrm.service.user.UserService;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/lead/industry")
public class IndustryController {
    
    @Autowired
    private IndustryService industryService;
    
    @Autowired
    private UserService userService;
    
    @RequestMapping(value = "", method = RequestMethod.GET)
    public String viewIndustries(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        
        model.addAttribute("title", "Industries");
        model.addAttribute("breadcrumb", "Industries");
        
        return "lead/settings/industry_list";
    }
    
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public String addIndustry(ModelMap model, HttpServletRequest request, Principal principal) {
        new MenuViewer().setupSideMenu(model, request);
        
        List<UserModel> userData = new ArrayList<>();
        userData = new Gson().fromJson(Utility.ObjectToJson(userService.getUserByUserName(principal.getName())), new TypeToken<List<UserModel>>(){}
                .getType());
        
        model.addAttribute("userData", userData.get(0));
        model.addAttribute("title", "Add Industry");
        model.addAttribute("breadcrumb", "Add");
        
        return "lead/settings/industry_add";
    }
    
}