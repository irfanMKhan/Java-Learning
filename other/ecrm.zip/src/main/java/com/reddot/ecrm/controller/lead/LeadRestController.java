package com.reddot.ecrm.controller.lead;

import com.reddot.ecrm.dto.lead.LeadDto;
import com.reddot.ecrm.entity.attachment.AttachmentEntity;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.attachment.AttachmentService;
import com.reddot.ecrm.service.lead.LeadEmailDto;
import com.reddot.ecrm.service.lead.LeadService;
import freemarker.template.TemplateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/lead")
public class LeadRestController {
    
    private final Logger logger = LoggerFactory.getLogger(LeadRestController.class);
    
    @Autowired
    private LeadService leadService;
    
    @Autowired
    private AttachmentService attachmentService;
    
    @GetMapping("/leadAttachmentsByLeadNumber/{lead_number}")
    public List<AttachmentEntity> leadAttachmentsByLeadNumber(@PathVariable(name = "lead_number") String leadNumber) {
        return attachmentService.findAllByLeadNumberAndIsFinalSaveTrue(leadNumber);
    }
    
    @GetMapping("/dt/all")
    public DataTablesOutput<LeadDto> dtLead(HttpServletRequest request,
                                            DataTablesInput input,
                                            @RequestParam(value = "keyword", required = false, defaultValue = "") String keyword,
                                            @RequestParam(value = "leadNumber", required = false, defaultValue = "") String leadNumber,
                                            @RequestParam(value = "customerName", required = false, defaultValue = "") String customerName,
                                            @RequestParam(value = "kamName", required = false, defaultValue = "") String kamName,
                                            @RequestParam(value = "statusName", required = false, defaultValue = "") String statusName,
                                            @RequestParam(value = "opportunityPercentageName", required = false, defaultValue = "") String opportunityPercentageName,
                                            @RequestParam(value = "productInterestId", required = false, defaultValue = "") String productInterestId,
                                            @RequestParam(value = "currentProdServName", required = false,
                                                    defaultValue = "") String currentProdServName,
                                            @RequestParam(value = "numOfLines", required = false, defaultValue = "") String numOfLines,
                                            @RequestParam(value = "monthlyFee", required = false, defaultValue = "") String monthlyFee,
                                            @RequestParam(value = "contractDuration", required = false, defaultValue = "") String contractDuration,
                                            @RequestParam(value = "estimatedRevenue", required = false, defaultValue = "") String estimatedRevenue,
                                            @RequestParam(value = "coverageAvailable", required = false, defaultValue = "") String coverageAvailable,
                                            @RequestParam(value = "industryName", required = false, defaultValue = "") String industryName,
                                            @RequestParam(value = "subIndustryName", required = false, defaultValue = "") String subIndustryName,
                                            @RequestParam(value = "revenueName", required = false, defaultValue = "") String revenueName,
                                            @RequestParam(value = "countryName", required = false, defaultValue = "") String countryName,
                                            @RequestParam(value = "cityProvinceName", required = false, defaultValue = "") String cityProvinceName,
                                            @RequestParam(value = "khanDistrictName", required = false, defaultValue = "") String khanDistrictName,
                                            @RequestParam(value = "sangkatCommuneName", required = false, defaultValue = "") String sangkatCommuneName,
                                            @RequestParam(value = "createdFromDateString", required = false, defaultValue = "") String createdFromDateString,
                                            @RequestParam(value = "createdToDateString", required = false, defaultValue = "") String createdToDateString,
                                            @RequestParam(value = "orderField", required = false, defaultValue = "createdAtDateString") String orderField,
                                            @RequestParam(value = "orderDirection", required = false, defaultValue = "desc") String orderDirection,
                                            @RequestParam(value = "isActive", required = false, defaultValue = "") String isActive) {
        return leadService.getDTLead(
                request,
                input,
                keyword,
                leadNumber,
                customerName,
                kamName,
                statusName,
                opportunityPercentageName,
                productInterestId,
                currentProdServName,
                numOfLines,
                monthlyFee,
                contractDuration,
                estimatedRevenue,
                coverageAvailable,
                industryName,
                subIndustryName,
                revenueName,
                countryName,
                cityProvinceName,
                khanDistrictName,
                sangkatCommuneName,
                createdFromDateString,
                createdToDateString,
                orderField,
                orderDirection,
                isActive);
    }
    
    @GetMapping("/all")
    public ResponseEntity<?> getAllLeads(){
        List<LeadDto> leads = leadService.getAllLeadsWhereIsActive();
        if(leads.isEmpty()){
            return new ResponseEntity<>("No data found!", HttpStatus.NO_CONTENT);
        }
        else return new ResponseEntity<>(leads, HttpStatus.OK);
    }
    
    @GetMapping("/get/{lead_number}")
    public CommonRestResponse getByLeadNumber(@PathVariable(name = "lead_number") String leadNumber) {
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error occurred! Please try again", null);
        LeadDto result = leadService.getLeadByLeadNumber(leadNumber);
        if (result.getId() != 0) {
            commonRestResponse.setData(200);
            commonRestResponse.setMessage("Lead found");
            commonRestResponse.setData(result);
        }
        return commonRestResponse;
    }
    
    @PostMapping("/add")
    public CommonRestResponse addLead(HttpServletRequest request, @RequestBody LeadDto leadDto) {
        return leadService.addLead(request, leadDto);
    }
    
    @PostMapping("/update")
    public CommonRestResponse updateLead(HttpServletRequest request, @RequestBody LeadDto leadDto) {
        return leadService.updateLead(request, leadDto);
    }
    
    @GetMapping("/getLeadEmail")
    public CommonRestResponse getLeadEmail(@RequestBody String leadNumber, HttpServletRequest request) {
        leadService.getLeadByLeadNumber(leadNumber);
        return new CommonRestResponse();
    }
    
    @PostMapping("/sendMail")
    public ResponseEntity<?> sendMail(HttpServletRequest request, @Valid @RequestBody LeadEmailDto leadEmailDto) throws MessagingException, TemplateException, IOException {
        if (leadService.sendMail(leadEmailDto, request)) {
            return new ResponseEntity<>("Email has been sent successfully!", HttpStatus.OK);
        } else return new ResponseEntity<>("Failed to send email!", HttpStatus.BAD_REQUEST);
    }
    
}