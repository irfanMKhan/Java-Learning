package com.reddot.ecrm.api.payload.response.opportunity;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class SearchInventoryByListMSISDNResponse implements Serializable {
  private QueryResources QueryResources;

  @Data
  public static class QueryResources implements Serializable {
    private String StartNum;

    private String PageNum;

    private List<ResInfoList> ResInfoList;

    private String TotalRowNum;

    @Data
    public static class ResInfoList implements Serializable {
      private String ResCode;

      private String Status;

      private String ResModeId;

      private String MNPStatus;

      private String IsLocked;

      private String Level;

      private String DeptId;

      private String TeleType;

      private String PaymentMode;
    }
  }
}
