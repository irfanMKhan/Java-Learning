package com.reddot.ecrm.deposit;

import lombok.*;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "tbl_deposit", schema = "ecrm")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class Deposit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "active")
    private boolean active;

//    @Column(name = "deposit_tracking_status")
//    private String depositTrackingStatus;

    @Column(name = "company_id")
    private Long companyId;

    @Column(name = "company_name")
    private String companyName;

    @Column(name = "company_account_code")
    private String companyAccountCode;

    @Column(name = "current_deposit_amount")
    private Long currentDepositAmount;

    @Column(name = "requested_deposit_amount")
    private Long requestedDepositAmount;

    @Column(name = "new_deposit_amount")
    private Long newDepositAmount;

    // @Column(name = "status_id")
    // private Long statusId;

    // @Column(name = "status_name")
    // private String statusName;

    @Column(name = "approval_status")
    private String approvalStatus;

    @Column(name = "transaction_no")
    private String transactionNo;

//    @Column(name = "attachment")
//    private String attachment;

    @Column(name = "created_at")
    private Long createdAt;

    @Column(name = "created_at_dt")
    private Timestamp createdAtDt;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_by_username")
    private String createdByUsername;

//    @Column(name = "updated_at")
//    private Long updatedAt;
//
//    @Column(name = "updated_at_dt")
//    private Timestamp updatedAtDt;
//
//    @Column(name = "updated_by")
//    private Long updatedBy;
//
//    @Column(name = "updated_by_username")
//    private String updatedByUsername;
}
