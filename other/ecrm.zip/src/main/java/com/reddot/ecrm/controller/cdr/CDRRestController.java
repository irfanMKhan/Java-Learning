package com.reddot.ecrm.controller.cdr;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.dto.PDFAndHotBill.SendEmailDTO;
import com.reddot.ecrm.dto.cdr.CDRSearchDTO;
import com.reddot.ecrm.dto.swap.SwapSearchDTO;
import com.reddot.ecrm.entity.msisdn.MsisdnEntity;
import com.reddot.ecrm.module.commonConfig.CommonConfig;
import com.reddot.ecrm.service.cdr.CDRService;
import com.reddot.ecrm.util.Utility;
import freemarker.template.TemplateException;
import lombok.RequiredArgsConstructor;
import net.sf.jasperreports.engine.JRException;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/CDR/Report")
public class CDRRestController {

    private final CDRService cdrService;

    @PostMapping(value = "/search", consumes = MediaType.APPLICATION_JSON_VALUE)
    public DataTablesOutput<MsisdnEntity> search(@RequestBody Map<String, Object> data) throws IllegalAccessException, JsonProcessingException {
        DataTablesInput input = new Gson().fromJson(Utility.ObjectToJson(data.get("input")), new TypeToken<DataTablesInput>(){}.getType());

        ObjectMapper mapper = new ObjectMapper();
        CDRSearchDTO cdrSearchDTO = mapper.readValue(data.get("searchDTO").toString(), CDRSearchDTO.class);

        return cdrService.getCDRData( input, cdrSearchDTO);

    }

    @RequestMapping(value = "/getAllUsageType", method = RequestMethod.GET)
    public List<CommonConfig> getAllUsageType() {
        return cdrService.getAllUsageType();
    }

    @RequestMapping(value = "/getAllFileType", method = RequestMethod.GET)
    public List<CommonConfig> getAllFileType() {
        return cdrService.getAllFileType();
    }

    @PostMapping(value = "/sendEmail", consumes = MediaType.APPLICATION_JSON_VALUE)
    public String sendEmail(HttpServletRequest request,HttpServletResponse response, @Valid  @RequestBody SendEmailDTO sendEmailDTO) throws MessagingException, TemplateException, IOException, JRException {
        cdrService.sendMail(sendEmailDTO,request, response);
        return "Success";

    }
}
