package com.reddot.ecrm.delayPayment.rest;

import com.reddot.ecrm.delayPayment.GetAllMsisdnByCompanyAccIdReqBody;
import com.reddot.ecrm.delayPayment.PromiseToPayService;
import com.reddot.ecrm.delayPayment.rest.dto.GetAllMsisdnByCompanyAccCode;
import com.reddot.ecrm.deposit.GetAllMasterAccByCompanyIdReqBody;
import com.reddot.ecrm.deposit.GetAllMasterAccByCompanyNameReqBody;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/delay-payment")
public class DelayPaymentREST {

    @Autowired
    PromiseToPayService promiseToPayService;

//    @RequestMapping(value = "/get-company-by-pic", method = RequestMethod.GET)
//    public ResponseEntity<?> getCompanyByPIC(HttpServletRequest httpServletRequest) {
//        return promiseToPayService.getCompanyByPIC(httpServletRequest);
//    }

    @RequestMapping(value = "/get-all-company", method = RequestMethod.GET)
    public ResponseEntity<?> getAllCompany(HttpServletRequest httpServletRequest) {
        return promiseToPayService.getAllCompany(httpServletRequest);
    }

    // DUserModel mdUserModel = SessionManager.getUserDetails(request);
    @RequestMapping(value = "/get-company-by-pic", method = RequestMethod.GET)
    public ResponseEntity<?> getCompanyByPIC(HttpServletRequest httpServletRequest) {
        return promiseToPayService.getCompanyByPIC(httpServletRequest);
    }

    // for company level
    // 132 Sep02-003
    // 205 206 207 208 209 --> for test82
    // 812 813 814 815 816 --> Sep02-003
    @RequestMapping(value = "/get-all-master-acc-by-company-id", method = RequestMethod.POST)
    public ResponseEntity<?> getAllMasterAccByCompanyId(HttpServletRequest httpServletRequest, @RequestBody GetAllMasterAccByCompanyIdReqBody reqBody) {
        return promiseToPayService.getAllMasterAccByCompanyId(httpServletRequest, reqBody);
    }

    @RequestMapping(value = "/get-all-master-acc-by-company-name", method = RequestMethod.POST)
    public ResponseEntity<?> getAllMasterAccByCompanyName(HttpServletRequest httpServletRequest, @RequestBody GetAllMasterAccByCompanyNameReqBody reqBody) {
        return promiseToPayService.getAllMasterAccByCompanyName(httpServletRequest, reqBody);
    }

    // for number level
    @RequestMapping(value = "/get-all-msisdn-by-company-id", method = RequestMethod.POST)
    public ResponseEntity<?> getAllMsisdnByCompanyId(HttpServletRequest httpServletRequest, @RequestBody GetAllMsisdnByCompanyAccIdReqBody reqBody) {
        return promiseToPayService.getAllMsisdnByCompanyId(httpServletRequest, reqBody);
    }

    @RequestMapping(value = "/get-all-msisdn-by-company-acc-code", method = RequestMethod.POST)
    public ResponseEntity<?> getAllMsisdnByCompanyAccCode(HttpServletRequest httpServletRequest, @RequestBody GetAllMsisdnByCompanyAccCode reqBody) {
        return promiseToPayService.getAllMsisdnByCompanyAccCode(httpServletRequest, reqBody);
    }
}
