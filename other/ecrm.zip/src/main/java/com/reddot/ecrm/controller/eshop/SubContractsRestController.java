package com.reddot.ecrm.controller.eshop;

import com.reddot.ecrm.dto.eshop.SubContractDto;
import com.reddot.ecrm.entity.eshop.SubContractsEntity;
import com.reddot.ecrm.service.eshop.ProductService;
import com.reddot.ecrm.service.eshop.SubContractsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequestMapping("/crm/eShop")
public class SubContractsRestController {

    @Autowired
    private SubContractsService subContractsService;

    @GetMapping("/dataTable/Data")
    public DataTablesOutput<SubContractsEntity> dtLead(@Valid DataTablesInput input, HttpServletRequest request, @RequestParam(value = "searchText", required = false) String searchText, @RequestParam(value = "searchCol", required = false) String searchCol) {
        return subContractsService.getDataTableSubContract(input, request, searchText, searchCol);
    }

    @PostMapping("/addSubContract")
    public String addSubContract(HttpServletRequest request,@Valid @RequestBody SubContractDto subContractDto) {
        if (subContractDto.getId() != null) {
            return subContractsService.updateSubContracts(subContractDto, request);
        }
        return subContractsService.addSubContracts(request, subContractDto);

    }

    @PostMapping("/updateSubContract")
    public String updateSubContract(HttpServletRequest request, @RequestBody SubContractDto subContractDto) {
        return subContractsService.updateSubContracts(subContractDto, request);
    }

    /*@PostMapping("/deleteSubContract/{id}")
    public String deleteSubContract(HttpServletRequest request, @PathVariable Long id,@RequestBody SubContractDto subContractDto) {
        return subContractsService.updateSubContracts(subContractDto, request);
    }*/

}
