package com.reddot.ecrm.api.gateway.hotBill;

import com.google.gson.Gson;
import com.reddot.ecrm.api.exception.ApiRequestException;
import com.reddot.ecrm.api.exception.InvalidAccessTokenException;
import com.reddot.ecrm.api.exception.InvalidClientCredentialException;
import com.reddot.ecrm.api.payload.request.hotBill.HotBillRequest;
import com.reddot.ecrm.api.payload.response.ErrorResponse;
import com.reddot.ecrm.api.payload.response.hotBill.HotBillResponse;
import com.reddot.ecrm.api.security.AuthorizationGateway;
import com.reddot.ecrm.api.utility.CommonConstant;
import com.reddot.ecrm.api.utility.HttpClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class HotBillGateway {
    private final HttpClient httpClient;
    private final Gson gson;
    private final AuthorizationGateway authorizationGateway;
    @Value("${smart.egw.base.url}")
    String baseUrlEGW;
    @Value("${smart.igw.base.url}")
    String baseUrlIGW;

    public HotBillResponse hotBillApiRequest(HotBillRequest request) throws UnsupportedEncodingException {
        //Hot bill api URL need to be changed
        String apiUrl = baseUrlEGW + "/hotBillApiRequest";
        String json = gson.toJson(request);

        try (Response response = httpClient.post(json, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), HotBillResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("hotBillApiRequest Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("hotBillApiRequest Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("hotBillApiRequest Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("hotBillApiRequest Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }



    private Map<String, String> getHeaders() {
        String bearerToken = authorizationGateway.getTokenEGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }
}
