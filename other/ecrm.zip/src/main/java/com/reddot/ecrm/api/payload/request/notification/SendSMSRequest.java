package com.reddot.ecrm.api.payload.request.notification;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@Data
@Getter
@Setter
public class SendSMSRequest implements Serializable {
    public OutboundSMSMessageRequest outboundSMSMessageRequest;

    @Data
    public static class OutboundSMSMessageRequest implements Serializable {
        private String senderAddress;

        private String senderName;

        private List<String> address;

        private ReceiptRequest receiptRequest;

        private OutboundSMSTextMessage outboundSMSTextMessage;

        private String clientCorrelator;

        @Data
        public static class ReceiptRequest implements Serializable {
            private String callbackData;

            private String notifyURL;
        }

        @Data
        public static class OutboundSMSTextMessage implements Serializable {
            private String message;
        }
    }
}
