package com.reddot.ecrm.controller.company;

import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.service.company.CompanyTempService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/company")
public class CompanyController {

    @Autowired
    private CompanyTempService companyTempService;

    @GetMapping("")
    public String viewCompany() {
        return "redirect:/company/list";
    }

    @GetMapping("/list")
    String viewCompanyList(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "List of Companies");
        return "company/company_list";
    }
    @GetMapping("/details")
    public String primaryOfferingDetailsView(Model model, HttpServletRequest request,
                                             @RequestParam(value = "companyId") String companyId){
        model.addAttribute("companyId", companyId);
//        if(!SecurityContextHolder.getContext().getAuthentication().isAuthenticated()){
//            login();
//        }
        return "company/company_360";
    }

    @GetMapping("/add")
    String viewCompanyAdd(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Add New Company");
        return "company/company_add";
    }
}
