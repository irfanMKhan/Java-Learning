//package com.reddot.ecrm.api.logger.service;
//
//import java.math.BigInteger;
//import java.sql.Timestamp;
//import java.util.Map;
//
//public interface ApiLoggerService {
//    void log(String httpMethod,
//             String channel,
//             String correlationId,
//             String pathInfo,
//             Map<String, String> requestParameters,
//             String requestBody,
//             String response,
//             Integer responseStatus,
//             String remoteAddress,
//             Timestamp requestTime,
//             Timestamp responseTime,
//             BigInteger elapsedTime
//    );
//}
