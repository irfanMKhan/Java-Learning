package com.reddot.ecrm.dto.cr.change_branch;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class GetBranchesDTO {
    private String companyId;
    private String serviceType;
}
