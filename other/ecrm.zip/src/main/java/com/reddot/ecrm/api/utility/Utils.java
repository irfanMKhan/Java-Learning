package com.reddot.ecrm.api.utility;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class Utils {
    public static boolean isValidJsonString(String jsonString) {
        try {
            new JSONObject(jsonString);
            return true;
        } catch (JSONException e) {
            return false;
        }
    }

    public static String urlEncode(String originalString) throws UnsupportedEncodingException {
        return URLEncoder.encode(originalString, StandardCharsets.UTF_8.toString());
    }

    public static JSONArray convertJsonObjectToArray(JSONObject jsonObject) {
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(jsonObject);
        return jsonArray;
    }
}
