package com.reddot.ecrm.controller.eshop;

import com.reddot.ecrm.entity.eshop.Product;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.eshop.ProductModel;
import com.reddot.ecrm.service.eshop.ProductService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/eshop")
public class ProductController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private ProductService productService;

    @Autowired
    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping("")
    public String getProductPage(ModelMap model, HttpServletRequest request){
        return "redirect:/eshop/list";
    }
    @GetMapping(value = {"/", "/list"})
    public String getProductListView(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        List<Product> products = productService.getAllProducts();
        model.addAttribute("products", products);
        model.addAttribute("moduleName", "Eshop");
        model.addAttribute("title", "Products");
        model.addAttribute("breadcrumb", "Products");

        return "eshop/product/product_list";
    }

    @GetMapping(value = "/add")
    public String addProductListView(ModelMap model, HttpServletRequest request)
    {
        new MenuViewer().setupSideMenu(model, request);
        model.addAttribute("moduleName", "Eshop");
        model.addAttribute("title", "Add Product");
        model.addAttribute("breadcrumb", "Add Product");

        return "eshop/product/product_add";
    }
}
