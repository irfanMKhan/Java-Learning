package com.reddot.ecrm.api.gateway.transferOwnership;

import com.google.gson.Gson;
import com.reddot.ecrm.api.exception.ApiRequestException;
import com.reddot.ecrm.api.exception.InvalidAccessTokenException;
import com.reddot.ecrm.api.exception.InvalidClientCredentialException;
import com.reddot.ecrm.api.payload.request.transferOwnership.ChangeCustProfileRequest;
import com.reddot.ecrm.api.payload.request.transferOwnership.ChangeSubscriberStatusRequest;
import com.reddot.ecrm.api.payload.response.transferOwnership.*;
import com.reddot.ecrm.api.security.AuthorizationGateway;
import com.reddot.ecrm.api.utility.CommonConstant;
import com.reddot.ecrm.api.utility.HttpClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;


@RequiredArgsConstructor
@Slf4j
@Service
public class TransferOwnershipGateway {

    private final HttpClient httpClient;

    private final Gson gson;

    private final AuthorizationGateway authorizationGateway;

    @Value("${smart.egw.base.url}")
    String baseUrlEGW;

    @Value("${smart.igw.base.url}")
    String baseUrlIGW;

    public ChangeCustProfileResponse changeCustProfile(ChangeCustProfileRequest changeCustProfileRequest) {
        String apiUrl = baseUrlEGW + "/customer/changeCustProfile/v1.0";
        String json = gson.toJson(changeCustProfileRequest);

        try (Response response = httpClient.put(json, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), ChangeCustProfileResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ChangeCustProfileErrorResponse errorResponse = gson.fromJson(response.body().string(), ChangeCustProfileErrorResponse.class);
                throw new ApiRequestException(errorResponse.getError().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("changeCustProfile Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("changeCustProfile Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("changeCustProfile Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("changeCustProfile Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    public ChangeSubscriberStatusResponse changeSubscriberStatus(String subscriberId, ChangeSubscriberStatusRequest changeSubscriberStatusRequest) {
        //need to check while we get creds
        String apiUrl = baseUrlIGW + "/api/bss/subscribers/v1/" + subscriberId + "/status?id_type=msisdn";
        String json = gson.toJson(changeSubscriberStatusRequest);

        try (Response response = httpClient.put(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), ChangeSubscriberStatusResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ChangeSubscriberStatusErrorResponse errorResponse = gson.fromJson(response.body().string(), ChangeSubscriberStatusErrorResponse.class);
                throw new ApiRequestException(errorResponse.getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("changeSubscriberStatus Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("changeSubscriberStatus Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("changeSubscriberStatus Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("changeSubscriberStatus Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }


    public QueryCDRDetailResponse queryCDRDetail(String subscriberId, String bss_username, String bss_password, String start_time, String end_time, int startRow, int totalRow, int fetchRow) {
        //need to check while we get creds
        String apiUrl = baseUrlIGW + "/api/igw/bss/cdr/v1/" + subscriberId + "?id_type=msisdn&" + "bss_username=" + bss_username + "&bss_password=" + bss_password + "&start_time=" + start_time + "&end_time=" + end_time + "&start_row=" + startRow + "&total_row=" + totalRow + "&fetch_row=" + fetchRow;

        try (Response response = httpClient.get(apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), QueryCDRDetailResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ChangeSubscriberStatusErrorResponse errorResponse = gson.fromJson(response.body().string(), ChangeSubscriberStatusErrorResponse.class);
                throw new ApiRequestException(errorResponse.getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("queryCDRDetail Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("queryCDRDetail Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("queryCDRDetail Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("queryCDRDetail Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }


    private Map<String, String> getHeaders() {
        String bearerToken = authorizationGateway.getTokenEGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }

    private Map<String, String> getIGWHeaders() {
        String bearerToken = authorizationGateway.getTokenIGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }
}
