package com.reddot.ecrm.api.payload.response.transferOwnership;

import lombok.Data;

import java.io.Serializable;

@Data
public class ChangeSubscriberStatusResponse implements Serializable {
    private BssInfo bss_info;

    private ChangeStatus change_status;

    private String transaction_id;

    private String channel_id;

    @Data
    public class BssInfo implements Serializable {

        private String username;

        private String operator_id;
    }

    @Data
    public class ChangeStatus implements Serializable {


        private String operation_type;

        private String reason_code;
    }
}
