package com.reddot.ecrm.api.payload.response.contract.payment;

import lombok.Data;

import java.io.Serializable;
import java.lang.Integer;
import java.lang.Long;
import java.lang.String;

@Data
public class ChangeCorporateAccountPaymentRelationResponse implements Serializable {
  private ChangeCorporatePaymentRelationRspMsg ChangeCorporatePaymentRelationRspMsg;

  @Data
  public static class ChangeCorporatePaymentRelationRspMsg implements Serializable {
    private RspHeader RspHeader;

    @Data
    public static class RspHeader implements Serializable {
      private Long RspTime;

      private Integer ReturnCode;

      private String ReturnMsg;
    }
  }
}
