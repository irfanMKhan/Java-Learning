package com.reddot.ecrm.controller.email;

import com.reddot.ecrm.dto.approval.MultiOrderApprovalLogDetailsDTO;
import com.reddot.ecrm.entity.approval.ApprovalLogDetailsEntity;
import com.reddot.ecrm.entity.approval.ApprovalRequestEntity;
import com.reddot.ecrm.enum_config.approval.ApprovalRequestStatusEnum;
import com.reddot.ecrm.model.email.EmailModel;
import com.reddot.ecrm.repository.approval.ApprovalLogDetailsRepo;
import com.reddot.ecrm.repository.approval.ApprovalRequestRepo;
import com.reddot.ecrm.service.email.ApprovalsUpdateService;
import com.reddot.ecrm.service.email.EmailService;
import com.reddot.ecrm.spring_config.ThreadPool.SingletonThreadPool;
import com.reddot.ecrm.util.Utility;
import freemarker.template.TemplateException;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/approval/flow/request/email/rest")
public class EmailRestController {
    private final ThreadPoolTaskExecutor threadPoolTaskExecutor = SingletonThreadPool.getInstance();
    @Autowired
    ApprovalLogDetailsRepo approvalLogDetailsRepo;
    @Autowired
    ApprovalRequestRepo approvalRequestRepo;
    @Autowired
    ApprovalsUpdateService approvalsUpdateService;
    @Autowired
    private EmailService emailService;
    @Autowired
    private EmailController emailController;


    @PostMapping("/send")
    public String sendMail(@RequestBody EmailModel emailModel) throws MessagingException, TemplateException, IOException {
        emailService.sendMail(emailModel);
        return "done";
    }


    @PostMapping("/send/tymeleaf")
    public String sendMailUsingThymeleaf(@RequestBody EmailModel emailModel, HttpServletRequest request) throws MessagingException, TemplateException, IOException {
        emailService.sendMailUsingEmailModel(emailModel, request);
        return "done";
    }


    @GetMapping("/accept")
    public Object acceptMail(@RequestParam("approverId") String approverId, @RequestParam("token") String token,
                             @RequestParam("approvalLogDetailsId") Long approvalLogDetailsId) throws UnsupportedEncodingException {


        String msg = "";
        Optional<ApprovalLogDetailsEntity> approvalLogDetails = approvalLogDetailsRepo.findByApproverIDAndUuidTokenAndIdAndIsActive(Long.valueOf(approverId),
                token, approvalLogDetailsId, true);

        if (approvalLogDetails.isPresent()) {
            Optional<ApprovalRequestEntity> approvalRequest = approvalRequestRepo.findById(approvalLogDetails.get().getApprovalReqId());
            if (!approvalLogDetails.get().getStatus().equals(ApprovalRequestStatusEnum.PENDING.toString())) {  //if not pending means already accept or reject
                msg = "Already executed the request.";
                return msg;
            }
            approvalLogDetails.get().setStatus(ApprovalRequestStatusEnum.APPROVED.toString());
            //approved time
            LocalDate localDate = LocalDate.now();
            approvalLogDetails.get().setApprovedAt(Utility.loggedInCurrentTime());
            approvalLogDetails.get().setApprovedAtDt(localDate);
            approvalLogDetailsRepo.saveAndFlush(approvalLogDetails.get());

            //check all the req_id approved or not?
            List<ApprovalLogDetailsEntity> listAllApprover = approvalLogDetailsRepo.findAllByApprovalReqIdAndIsActiveOrderByIdDesc(
                    approvalLogDetails.get().getApprovalReqId(), true);
            msg = "The Request is Accepted. ";

            if (!approvalRequest.get().getStatus().equals(ApprovalRequestStatusEnum.PENDING.toString())) {  //if not pending means already accept or reject
                if (approvalRequest.get().getStatus().equals(ApprovalRequestStatusEnum.APPROVED.toString())) {  //if not pending means already accept or reject
                    msg = msg + " This approval already accepted.";
                } else if (approvalRequest.get().getStatus().equals(ApprovalRequestStatusEnum.REJECTED.toString())) {
                    msg = msg + " This approval already rejected.";
                }
            }

            if (listAllApprover.size() == 1) {  //only one approver to req approval
                if (approvalRequest.isPresent()) {
                    approvalRequest.get().setStatus(ApprovalRequestStatusEnum.APPROVED.toString());
                    approvalRequestRepo.save(approvalRequest.get());
                }
                approvalsUpdateService.UpdateMainTable(approvalRequest.get().getApprovalFor(), ApprovalRequestStatusEnum.APPROVED, approvalRequest.get());
            } else {
                MultiOrderApprovalLogDetailsDTO dto = approvalsUpdateService.mapWithStepOrderANDLogDetails(listAllApprover);
                Integer highStepOrder = dto.getHighestStepOrder();
                Map<Integer, List<ApprovalLogDetailsEntity>> map = dto.getMapData();
                Boolean isThisApproverInHighOrderList = false;

                if (!ObjectUtils.isEmpty(highStepOrder) && !ObjectUtils.isEmpty(map) && !ObjectUtils.isEmpty(map.get(highStepOrder))) {
                    for (ApprovalLogDetailsEntity singleLogDetailsEntity : map.get(highStepOrder)) {
                        if (singleLogDetailsEntity.getId().equals(approvalLogDetails.get().getId())) {
                            isThisApproverInHighOrderList = true;
                            break;
                        }
                    }
                }

                //single step and multi-steps do same thing here
                //take highestStepOrder bcz high order approval action will determine that req should accept or reject.
                //low levels approver accept or reject bt not reflect in the main request
                if (isThisApproverInHighOrderList) {
                    CompletableFuture<Void> completableFuture = CompletableFuture.runAsync(() -> {
                        approvalsUpdateService.updateAcceptData(map.get(highStepOrder), approvalRequest.get());
                    }, threadPoolTaskExecutor);
                }
            }


            return msg;

        } else {

            msg = "Error: User not find in approval log details"; //todo: update this error page
            return msg;
        }
    }

    @GetMapping("/reject")
    public Object rejectMail(@RequestParam("approverId") String approverId, @RequestParam("token") String token,
                             @RequestParam("approvalLogDetailsId") Long approvalLogDetailsId) throws UnsupportedEncodingException {

        String msg = "";
        boolean IsMandatoryApprover = false;

        Optional<ApprovalLogDetailsEntity> approvalLogDetails = approvalLogDetailsRepo.findByApproverIDAndUuidTokenAndIdAndIsActive(
                Long.valueOf(approverId), token, approvalLogDetailsId,true);
        if (approvalLogDetails.isPresent()) {
            if (!approvalLogDetails.get().getStatus().equals(ApprovalRequestStatusEnum.PENDING.toString())) {  //if not pending means already accept or reject
                msg = "Already executed the request.";
                return msg;
            }
            approvalLogDetails.get().setStatus(ApprovalRequestStatusEnum.REJECTED.toString());
            if (!approvalLogDetails.get().getIsOptional()) {
                IsMandatoryApprover = true;
            }
            //approved time
            LocalDate localDate = LocalDate.now();
            approvalLogDetails.get().setApprovedAt(Utility.loggedInCurrentTime());
            approvalLogDetails.get().setApprovedAtDt(localDate);
            approvalLogDetailsRepo.saveAndFlush(approvalLogDetails.get());
            //check all the req_id approved or not?
            List<ApprovalLogDetailsEntity> listAllApprover = approvalLogDetailsRepo.findAllByApprovalReqIdAndIsActiveOrderByIdDesc(
                    approvalLogDetails.get().getApprovalReqId(), true);
            Optional<ApprovalRequestEntity> approvalRequest = approvalRequestRepo.findById(approvalLogDetails.get().getApprovalReqId());

            msg = "The Request is Rejected. ";

            if (!approvalRequest.get().getStatus().equals(ApprovalRequestStatusEnum.PENDING.toString())) {  //if not pending means already accept or reject
                if (approvalRequest.get().getStatus().equals(ApprovalRequestStatusEnum.APPROVED.toString())) {  //if not pending means already accept or reject
                    msg = msg + " This approval already Accepted.";
                } else if (approvalRequest.get().getStatus().equals(ApprovalRequestStatusEnum.REJECTED.toString())) {
                    msg = msg + " This approval already Rejected.";
                }
            }

            if (listAllApprover.size() == 1) {  //only one approver to req approval
                if (approvalRequest.isPresent()) {
                    approvalRequest.get().setStatus(ApprovalRequestStatusEnum.REJECTED.toString());
                    approvalRequestRepo.save(approvalRequest.get());
                }
                approvalsUpdateService.UpdateMainTable(approvalRequest.get().getApprovalFor(), ApprovalRequestStatusEnum.APPROVED, approvalRequest.get());
            } else {
                MultiOrderApprovalLogDetailsDTO dto = approvalsUpdateService.mapWithStepOrderANDLogDetails(listAllApprover);
                Integer highStepOrder = dto.getHighestStepOrder();
                Map<Integer, List<ApprovalLogDetailsEntity>> map = dto.getMapData();

                Boolean isThisApproverInHighOrderList = false;

                if (!ObjectUtils.isEmpty(highStepOrder) && !ObjectUtils.isEmpty(map) && !ObjectUtils.isEmpty(map.get(highStepOrder))) {
                    for (ApprovalLogDetailsEntity singleLogDetailsEntity : map.get(highStepOrder)) {
                        if (singleLogDetailsEntity.getId().equals(approvalLogDetails.get().getId())) {
                            isThisApproverInHighOrderList = true;
                            break;
                        }
                    }
                }

                //single step and multi-steps do same thing here
                //take highestStepOrder bcz high order approval action will determine that req should accept or reject.
                //low levels approver accept or reject bt not reflect in the main request
                if (isThisApproverInHighOrderList) {
                    boolean finalIsMandatoryApprover = IsMandatoryApprover;
                    CompletableFuture<Void> completableFuture = CompletableFuture.runAsync(() -> {
                        approvalsUpdateService.updateRejectData(map.get(highStepOrder), approvalRequest.get(), finalIsMandatoryApprover);
                    }, threadPoolTaskExecutor);

                }
            }

            return msg;
        } else {
            msg = "Error: User not find in approval log details"; //todo: update this error page
            return msg;
        }
    }


}


//return ResponseEntity.status(HttpStatus.FOUND).header(HttpHeaders.LOCATION, "/redirect").build();