package com.reddot.ecrm.controller.PDFAndHotBill;

import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.service.ContractAgreementReportService;
import com.reddot.ecrm.service.pdfAndHotBill.PDFBillService;
import com.reddot.ecrm.spring_config.session.SessionManager;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/PDFBill/Report")
public class PDFBillController {

    private final PDFBillService pdfBillService;
    private final ContractAgreementReportService contractAgreementReportService;

    @GetMapping
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        List<CompanyEntity> listOfCompany = pdfBillService.getAllCompany();
        MDUserModel userModel = SessionManager.getUserDetails(request);
        model.put("title", "PDF Bill");

        model.put("userType", userModel.getUSER_TYPE().toUpperCase().toString());

        return "PDFAndHotBill/index";
    }

    @RequestMapping(value = "/pdfDownload", method = RequestMethod.POST)
    @ResponseBody
    public void excelDownload(HttpServletRequest request, HttpServletResponse response, @RequestParam(value = "fileName", required = true) String fileName) throws Exception {
        pdfBillService.pdfDownload(request, response, fileName);
    }

   /* @RequestMapping(value = "/pdfDownload", method = RequestMethod.POST)
    @ResponseBody
    public void excelDownload(HttpServletRequest request, HttpServletResponse response, @RequestParam(value = "fileName", required = true) String fileName) throws Exception {
        fileName="SPONSORED";
        contractAgreementReportService.downloadContractAgreement(request, response, fileName);
    }*/

}
