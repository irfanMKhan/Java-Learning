package com.reddot.ecrm.api.payload.request.itsm;

import com.fasterxml.jackson.annotation.JsonKey;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Data;
import org.json.JSONPropertyName;

import java.io.Serializable;
import java.lang.Integer;
import java.lang.String;
import java.util.List;

@Data
public class CreateServiceRequest implements Serializable {
  private Product primaryContact;

  private Product product;

  private CustomFields.C.Incident_type category;

  private StatusWithType statusWithType;

  private CustomFields customFields;


  @Data
  public static class Product implements Serializable {
    @JsonProperty("id")
    private Integer id;
  }

  @Data
  public static class CustomFields implements Serializable {
    @JsonProperty("c")
    private C c;

    @JsonProperty("CO")
    private CO CO;

    @JsonProperty("ITSM")
    private ITSM ITSM;

    @Data
    public static class C implements Serializable {

      @JsonProperty("incident_type")
      private Incident_type incident_type;

      @JsonProperty("urged_count")
      private Integer urged_count;

      @JsonProperty("priority")
      private Incident_type priority;

      @Data
      public static class Incident_type implements Serializable {
        @JsonProperty("lookupName")
        private String lookupName;
      }
    }

    @Data
    public static class ITSM implements Serializable {
      @JsonProperty("BORefNumbers")
      private String BORefNumbers;
    }

    @Data
    public static class CO implements Serializable {
      @JsonProperty("Issue")
      private List<String> Issue;
    }
  }

  @Data
  public static class StatusWithType implements Serializable {
    @JsonProperty("status")
    private Product status;
  }
}
