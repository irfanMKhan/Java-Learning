package com.reddot.ecrm.controller.sr.management;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.controller.sr.notificationMatrix.SRStatusNotifyExecutor;
import com.reddot.ecrm.dto.sr.management.SRMsisdnInfo;
import com.reddot.ecrm.dto.sr.management.TBLSRActionModel;
import com.reddot.ecrm.dto.sr.management.TBLSRModel;
import com.reddot.ecrm.dto.srsettings.subarea.MDSrSubAreaModel;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.util.JsonIterator;
import com.reddot.ecrm.util.QueryBuilder;
import com.reddot.ecrm.util.Utility;
import org.json.JSONObject;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.naming.Context;
import javax.naming.directory.*;
import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.*;

@RestController
public class SRExternalRestController {

    private final Logger logger = LoggerFactory.getLogger(getClass().getName());

    //    ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
//    CommonDAO commonDAO = (CommonDAO) context.getBean("CommonDAO");
    @Autowired
    private CommonRepository commonDAO;

    @Autowired
    private SRStatusNotifyExecutor srStatusNotifyExecutor;

    @PostMapping(path = "/QueryServiceRequestReqABCSPS", produces = {MediaType.TEXT_XML_VALUE, MediaType.APPLICATION_XML_VALUE}, consumes = {MediaType.TEXT_XML_VALUE, MediaType.APPLICATION_XML_VALUE})
    public String queryServiceRequestReqABCSPS(@RequestBody String request) {
        String response = "";
        try {
            int sp = request.indexOf("<soapenv:Body>");
            int ep = request.indexOf("</soapenv:Body>");
            String restr = request.substring(sp, ep + "</soapenv:Body>".length())
                    .replaceAll("quer:", "")
                    .replaceAll("com:", "")
                    .replaceAll("soapenv:", "");

            JSONObject result = XML.toJSONObject(restr);
            String msisdn = new JsonIterator().getFirstOccurrence(result, "ServiceID").toString();
            logger.info("QueryServiceRequestReqABCSPS from " + new JsonIterator().getFirstOccurrence(result, "SenderID").toString() + " mmsisdn: " + msisdn);
            String processingNumber = new JsonIterator().getFirstOccurrence(result, "ProcessingNumber").toString();

            response = "";

            response = response + processingNumber + "</com:ProcessingNumber>\n";
            //Have to fix RequestDateTime


            String fromDateString = new JsonIterator().getFirstOccurrence(result, "FromDateTime").toString().replace("Z", "");
            String toDateString = new JsonIterator().getFirstOccurrence(result, "ToDateTime").toString().replace("Z", "");
            Long fromDateLong = parseFormattedDate(fromDateString);
            Long toDateLong = parseFormattedDate(toDateString);

            String query = "select * from " + Utility.tbl_sr + " where MSISDN=" + msisdn + " AND ACTIVE=1 AND CREATED_AT>=" + fromDateLong + " AND CREATED_AT<=" + toDateLong;
            Object objects = commonDAO.CommoGetData(query);
            List<TBLSRModel> tblsrModelList = new Gson().fromJson(Utility.ObjectToJson(objects), new TypeToken<List<TBLSRModel>>() {
            }.getType());

            if (tblsrModelList.size() > 0) {
                response = response + "            <quer:StatusInfo>\n" +
                        "                <quer:StatusCode>0</quer:StatusCode>\n" +
                        "                <quer:StatusDesc>Success</quer:StatusDesc>\n" +
                        "            </quer:StatusInfo>\n";

                for (int i = 0; i < tblsrModelList.size(); i++) {
                    try {
                        Long resolveDateLong = tblsrModelList.get(i).getRESOLVED_AT();
                        String resolveDateString = "";
                        if (resolveDateLong != null && resolveDateLong > 0) {
                            resolveDateString = "                <quer:ResolveDate>" + getFormattedDate(resolveDateLong) + "</quer:ResolveDate>\n";
                        } else {
                            resolveDateString = "                <quer:ResolveDate/>\n";
                        }

                        Long loggedDateLong = tblsrModelList.get(i).getLOG_AT();
                        String loggedDateString = "";
                        if (loggedDateLong != null && loggedDateLong > 0) {
                            loggedDateString = "                <quer:LoggedDate>" + getFormattedDate(loggedDateLong) + "</quer:LoggedDate>\n";
                        } else {
                            loggedDateString = "                <quer:LoggedDate/>\n";
                        }

                        String summaryString = "";
                        if (tblsrModelList.get(i).getSUMMARY() != null && tblsrModelList.get(i).getSUMMARY().length() > 0) {
                            summaryString = "                    <quer:Remark>" + tblsrModelList.get(i).getSUMMARY() + "</quer:Remark>\n";
                        } else {
                            summaryString = "                    <quer:Remark/>\n";
                        }
                        response = response +
                                "            <quer:QueryServiceRequestResponseDetails>\n" +
                                "                <quer:Identification>\n" +
                                "                    <quer:ServiceReqNum>" + tblsrModelList.get(i).getSR_NUM() + "</quer:ServiceReqNum>\n" +
                                "                    <quer:ServiceID>" + tblsrModelList.get(i).getMSISDN() + "</quer:ServiceID>\n" +
                                //Have to change trouble ticket id
                                "                    <quer:TroubleTicketID>" + tblsrModelList.get(i).getID() + "</quer:TroubleTicketID>\n" +
                                "                </quer:Identification>\n" +
                                "                <quer:Description>" + tblsrModelList.get(i).getDESCRIPTION() + "</quer:Description>\n" +
                                "                <quer:Type>" + tblsrModelList.get(i).getSR_TYPE_NAME() + "</quer:Type>\n" +
                                "                <quer:Area>" + tblsrModelList.get(i).getSR_AREA_NAME() + "</quer:Area>\n" +
                                "                <quer:SubArea>" + tblsrModelList.get(i).getSR_SUB_AREA_NAME() + "</quer:SubArea>\n" +
                                "                <quer:Status>" + tblsrModelList.get(i).getSR_STATUS_NAME() + "</quer:Status>\n" +
                                loggedDateString +
                                resolveDateString +
                                "                <quer:Action>\n" +
                                ((tblsrModelList.get(i).getREMEDY_INCIDENT_NO() == null || tblsrModelList.get(i).getREMEDY_INCIDENT_NO().isEmpty()) ?
                                        "                    <quer:Id/>\n" :
                                        "                    <quer:Id>" + tblsrModelList.get(i).getREMEDY_INCIDENT_NO() + "</quer:Id>\n") +
                                "                    <quer:Remark/>\n" +
                                "                </quer:Action>\n" +
                                "            </quer:QueryServiceRequestResponseDetails>\n";
                    } catch (Exception e) {
                        e.printStackTrace();
                        logger.error(e.getMessage(), e);
                    }
                }

                response = response + "        </quer:QueryServiceResponse>\n" +
                        "    </SOAP-ENV:Body>\n" +
                        "</soapenv:Envelope>";
            } else {
                response = "            <quer:StatusInfo>\n" +
                        "                <quer:StatusCode>404</quer:StatusCode>\n" +
                        "                <quer:StatusDesc>No service request found!</quer:StatusDesc>\n" +
                        "            </quer:StatusInfo>\n" +
                        "        </quer:QueryServiceResponse>\n" +
                        "    </SOAP-ENV:Body>\n" +
                        "</soapenv:Envelope>";
            }
            return response;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        response = response + "            <quer:StatusInfo>\n" +
                "                <quer:StatusCode>500</quer:StatusCode>\n" +
                "                <quer:StatusDesc>Error Occurred! Please try later</quer:StatusDesc>\n" +
                "            </quer:StatusInfo>\n" +
                "        </quer:QueryServiceResponse>\n" +
                "    </SOAP-ENV:Body>\n" +
                "</soapenv:Envelope>";

        return response;
    }

    private String getFormattedDate(Long date) {
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
            return simpleDateFormat.format(date);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return "";
    }

    private Long parseFormattedDate(String date) {
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
            return simpleDateFormat.parse(date).getTime();
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return 0L;
    }

    @PostMapping(path = "/CreateServiceRequestReqABCSPS", produces = {MediaType.TEXT_XML_VALUE, MediaType.APPLICATION_XML_VALUE}, consumes = {MediaType.TEXT_XML_VALUE, MediaType.APPLICATION_XML_VALUE})
    public String createServiceRequestReqABCSPS(@RequestBody String request, HttpServletRequest httpServletRequest) {
        String response = "";
        try {
            SimpleDateFormat externalDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.s");
            int sp = request.indexOf("<soapenv:Body>");
            int ep = request.indexOf("</soapenv:Body>");
            String restr = request.substring(sp, ep + "</soapenv:Body>".length())
                    .replaceAll("cre:", "")
                    .replaceAll("com:", "")
                    .replaceAll("soapenv:", "");

            JSONObject result = XML.toJSONObject(restr);
            String msisdn = new JsonIterator().getFirstOccurrence(result, "MSISDNNum").toString();
            logger.info("CreateServiceRequestReqABCSPS from " + new JsonIterator().getFirstOccurrence(result, "SenderID").toString() + " mmsisdn: " + msisdn);
            String processingNumber = new JsonIterator().getFirstOccurrence(result, "ProcessingNumber").toString();
            String senderID = new JsonIterator().getFirstOccurrence(result, "SenderID").toString();
            String requestType = new JsonIterator().getFirstOccurrence(result, "RequestType").toString();
            String serviceType = new JsonIterator().getFirstOccurrence(result, "ServiceType").toString();
            String complaintType = new JsonIterator().getFirstOccurrence(result, "ComplaintType").toString();
            String complaintArea = new JsonIterator().getFirstOccurrence(result, "ComplaintArea").toString();
            String complaintSubArea = new JsonIterator().getFirstOccurrence(result, "ComplaintSubArea").toString();
            String complaintDescription = new JsonIterator().getFirstOccurrence(result, "ComplaintDescription").toString();
            String complaintDetails = new JsonIterator().getFirstOccurrence(result, "ComplaintDetails").toString();
            String complaintCreateDate = new JsonIterator().getFirstOccurrence(result, "ComplaintCreateDate").toString();

            List<MDSrSubAreaModel> subAreaList = new ArrayList<>();
            try {
                String query = "SELECT * FROM " + Utility.md_sr_sub_area + " WHERE NAME='" + complaintSubArea + "' AND SR_AREA_NAME='" + complaintArea + "' AND sr_type_name='" + complaintType + "'";
                logger.info(query);
                Object listObject = commonDAO.CommoGetData(query);
                subAreaList = new Gson().fromJson(Utility.ObjectToJson(listObject), new TypeToken<List<MDSrSubAreaModel>>() {
                }.getType());
            } catch (Exception e) {
                e.printStackTrace();
                logger.error(e.getMessage(), e);
            }

            if (subAreaList.isEmpty()) {
                return getCreateSRFailedResponse(processingNumber, "500", "Invalid complaint information!");
            }

            MDSrSubAreaModel subAreaModel = subAreaList.get(0);

            SRMsisdnInfo srMsisdnInfo = new SRManagementAjxController().getMsisdnInfo(msisdn);

            if (srMsisdnInfo.getAccountClass() == null || srMsisdnInfo.getAccountClass().isEmpty() || srMsisdnInfo.getAccountType() == null || srMsisdnInfo.getAccountType().isEmpty()) {
                return getCreateSRFailedResponse(processingNumber, "404", "Invalid subscriber!");
            }

            Map<String, Object> insertData = new HashMap<String, Object>();

            String nextId = commonDAO.getNextIdPostgres(Utility.seq_name_tbl_sr);
            String srNumber = Utility.generateSRNumber(nextId);
            insertData.put("SR_NUM", srNumber);
            insertData.put("ACCOUNT_NAME", srMsisdnInfo.getAccountName());
            insertData.put("CONTACT_NAME", srMsisdnInfo.getContactName());
            insertData.put("MSISDN", msisdn);
            insertData.put("SR_SERVICE_TYPE_ID", subAreaModel.getSR_SERVICE_TYPE_ID());
            insertData.put("SR_SERVICE_TYPE_NAME", serviceType);
            insertData.put("SR_TYPE_ID", subAreaModel.getSR_TYPE_ID());
            insertData.put("SR_TYPE_NAME", complaintType);
            insertData.put("SR_AREA_ID", subAreaModel.getSR_AREA_ID());
            insertData.put("SR_AREA_NAME", complaintArea);
            insertData.put("SR_SUB_AREA_ID", subAreaModel.getID());
            insertData.put("SR_SUB_AREA_NAME", complaintSubArea);
//            insertData.put("SLA_HR", newSR.getSlaHr());
//            insertData.put("SRC_ID", newSR.getSrcId());
//            insertData.put("SRC_NAME", "external");
//            insertData.put("SRC_LOCATION_ID", newSR.getSrcLocationId());
//            insertData.put("SRC_LOCATION_NAME", newSR.getSrcLocationName());
            insertData.put("ACC_TYPE_ID", srMsisdnInfo.getAccountType_id());
            insertData.put("ACC_TYPE_NAME", srMsisdnInfo.getAccountType());
//            insertData.put("PRIORITY_ID", subAreaModel.getPRIORITY_ID());
//            insertData.put("PRIORITY_NAME", newSR.getPriorityName());
//            insertData.put("SEVERITY_ID", newSR.getSeverityId());
//            insertData.put("SEVERITY_NAME", newSR.getSeverityName());


//            insertData.put("LOG_BY", Utility.getUserId(httpServletRequest));
//            insertData.put("LOG_BY_NAME", Utility.getLoginName(httpServletRequest));
//            insertData.put("COMMITED_BY", Utility.getUserId(httpServletRequest));
//            insertData.put("COMMITED_BY_NAME", Utility.getLoginName(httpServletRequest));
            insertData.put("SR_STATUS_ID", 1);
            insertData.put("SR_STATUS_NAME", "Open");
//            insertData.put("SR_SUB_STATUS_ID", newSR.getSrSubStatusId());
//            insertData.put("SR_SUB_STATUS_NAME", newSR.getSrSubStatusName());
            insertData.put("OWNER_GROUP_ID", subAreaModel.getOWNER_GROUP_ID());
            insertData.put("OWNER_GROUP_NAME", subAreaModel.getOWNER_GROUP_NAME());

//            insertData.put("FULL_ADDRESS", newSR.getFullAddress());
//            insertData.put("ADDRESS", newSR.getAddress());
            insertData.put("SUMMARY", complaintDetails);
            insertData.put("DESCRIPTION", complaintDescription);

            insertData.put("ACC_CLASS_ID", srMsisdnInfo.getAccountClass_id());
            insertData.put("ACC_CLASS_NAME", srMsisdnInfo.getAccountClass());

            insertData.put("SUBMITTED_BY", Utility.getUserId(httpServletRequest));
            insertData.put("SUBMITTED_BY_NAME", Utility.getLoginName(httpServletRequest));

            insertData.put("CON_MOBILE_PHONE", srMsisdnInfo.getCONTACT_MOBILE_PHONE());
            insertData.put("CON_EMAIL", srMsisdnInfo.getEMAIL());

            insertData.put("ACTIVE", 1);
            insertData.put("CREATED_BY", Utility.getUserId(httpServletRequest));
            insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(httpServletRequest));
            insertData.put("CREATED_AT", Utility.getCurrentTimestamp());
            insertData.put("UPDATED_BY", Utility.getUserId(httpServletRequest));
            insertData.put("UPDATED_AT", Utility.getCurrentTimestamp());
            insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(httpServletRequest));
            insertData.put("LOG_AT", Utility.getCurrentTimestamp());


//            if (newSR.getSlaHr() != null && newSR.getSlaHr() > 0) {
//                long committedTime = Utility.getCurrentTimestamp() + (newSR.getSlaHr() * 60 * 60 * 1000);
//                insertData.put("COMMITED_AT", committedTime);
//            }

            insertData.put("SUBMITTED_AT", Utility.getCurrentTimestamp());


            Map<String, Object> searchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            searchData.put("MSISDN", msisdn);
            whereSearchType.put("MSISDN", "AND");
            searchData.put("SR_TYPE_ID", subAreaModel.getSR_TYPE_ID());
            whereSearchType.put("SR_TYPE_ID", "AND");
            searchData.put("SR_AREA_ID", subAreaModel.getSR_AREA_ID());
            whereSearchType.put("SR_AREA_ID", "AND");
            searchData.put("SR_SUB_AREA_ID", subAreaModel.getID());
            whereSearchType.put("SR_SUB_AREA_ID", "AND");
//            searchData.put("FULL_ADDRESS", newSR.getFullAddress());
//            whereSearchType.put("FULL_ADDRESS", "AND");
            searchData.put("SR_STATUS_ID!", 6); //status id 6 found for close at db
            whereSearchType.put("SR_STATUS_ID!", "AND");
            String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.tbl_sr, searchData, whereSearchType);
            logger.info(duplicateQry);
            int TotalRows = commonDAO.CommoNumberOfRow(duplicateQry);
            if (TotalRows > 0) {
                String duplicateSR = "";
                String query = QueryBuilder.getSelectWhereQuery(Utility.tbl_sr, searchData, whereSearchType);
                Object objects = commonDAO.CommoGetData(query);
                List<TBLSRModel> tblsrModelList = new Gson().fromJson(Utility.ObjectToJson(objects), new TypeToken<List<TBLSRModel>>() {
                }.getType());
                if (tblsrModelList.size() > 0) {
                    TBLSRModel tblsrModel = tblsrModelList.get(0);
                    duplicateSR = tblsrModel.getSR_NUM();
                }
                return getCreateSRFailedResponse(processingNumber, "500", "SR is already exist and SR No : " + duplicateSR);
            }


            if (commonDAO.CommoInsert(Utility.tbl_sr, insertData, logger)) {
                srStatusNotifyExecutor.execute(srNumber, httpServletRequest);
//                new SendMessage().send(msisdn, "Your Service request no. is " + insertData.get("SR_NUM").toString() + " which will be taken care of with utmost priority", "SR", httpServletRequest);
                TBLSRActionModel tblsrActionModel = new TBLSRActionModel();
                tblsrActionModel.setSR_NUM(srNumber);
                tblsrActionModel.setMSISDN(msisdn);
                tblsrActionModel.setSR_ACTION_TYPE_NAME("SR Created");
                tblsrActionModel.setREMARKS("SR created");
                insertSrAction(tblsrActionModel, httpServletRequest);
            } else {
                return getCreateSRFailedResponse(processingNumber, "500", "Error occurred! Please try later");
            }

            return getSRCreateSRSuccessResponse(srNumber, processingNumber);
        } catch (
                Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }

        return response;
    }

    private String getCreateSRFailedResponse(String processingNumber, String statusCode, String reason) {
        String response = "";
        response = "";

        return response;
    }

    private String getSRCreateSRSuccessResponse(String srNumber, String processingNumber) {
        String response = "";

        response = "";

        return response;

    }


    void insertSrAction(TBLSRActionModel tblsrActionModel, HttpServletRequest request) {
        try {
            Map<String, Object> insertData = new HashMap<String, Object>();
            insertData.put("SR_NUM", tblsrActionModel.getSR_NUM());
            insertData.put("MSISDN", tblsrActionModel.getMSISDN());
            insertData.put("REMARKS", tblsrActionModel.getREMARKS());
            insertData.put("SR_ACTION_TYPE_NAME", tblsrActionModel.getSR_ACTION_TYPE_NAME());
            insertData.put("OLD_DATA", tblsrActionModel.getOLD_DATA());
            insertData.put("NEW_DATA", tblsrActionModel.getNEW_DATA());
            insertData.put("CREATED_BY", Utility.getUserId(request));
            insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
            insertData.put("CREATED_AT", Utility.getCurrentTimestamp());
            insertData.put("CREATED_AT_DT", new Date());
            commonDAO.CommoInsert(Utility.tbl_sr_actions, insertData, logger);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
    }

    @PostMapping(path = "/UpdateServiceRequestReqABCSPS", produces = {MediaType.TEXT_XML_VALUE, MediaType.APPLICATION_XML_VALUE}, consumes = {MediaType.TEXT_XML_VALUE, MediaType.APPLICATION_XML_VALUE})
    public String updateServiceRequestReqABCSPS(@RequestBody String request, HttpServletRequest httpServletRequest) {
        String response = "";
        try {
            int sp = request.indexOf("<soapenv:Body>");
            int ep = request.indexOf("</soapenv:Body>");
            String restr = request.substring(sp, ep + "</soapenv:Body>".length())
                    .replaceAll("cre:", "")
                    .replaceAll("com:", "")
                    .replaceAll("soapenv:", "");

            JSONObject result = XML.toJSONObject(restr);
            String msisdn = new JsonIterator().getFirstOccurrence(result, "MSISDNNum").toString();
            logger.info("CreateServiceRequestReqABCSPS from " + new JsonIterator().getFirstOccurrence(result, "SenderID").toString() + " mmsisdn: " + msisdn);
            String processingNumber = new JsonIterator().getFirstOccurrence(result, "ProcessingNumber").toString();
            String senderID = new JsonIterator().getFirstOccurrence(result, "SenderID").toString();
            String srNumber = new JsonIterator().getFirstOccurrence(result, "ServiceReqNum").toString();
            String complaintDescription = new JsonIterator().getFirstOccurrence(result, "Description").toString();

            Map<String, Object> updateData = new HashMap<String, Object>();
            updateData.put("DESCRIPTION", complaintDescription);
            Map<String, Object> whereData = new HashMap<String, Object>();
            whereData.put("SR_NUM", srNumber);
            if (commonDAO.CommoUpdate(Utility.tbl_sr, updateData, whereData, logger)) {
                response = "";
                TBLSRActionModel tblsrActionModel = new TBLSRActionModel();
                tblsrActionModel.setSR_NUM(srNumber);
                tblsrActionModel.setMSISDN(msisdn);
                tblsrActionModel.setSR_ACTION_TYPE_NAME("SR Updated");
                tblsrActionModel.setREMARKS("SR Updated");
                insertSrAction(tblsrActionModel, httpServletRequest);
            } else {
                response = "";

                return response;
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }

        return response;
    }

    @GetMapping(path = "/changeLdap")
    public String changeLdapPass() {
        try {
            Hashtable env = new Hashtable();
            env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
            env.put(Context.PROVIDER_URL, "ldap://dc1.smart.com.kh:389");
            env.put(Context.SECURITY_AUTHENTICATION, "simple");
            env.put(Context.SECURITY_PRINCIPAL, "samim.reza@smart.com.kh");
            env.put(Context.SECURITY_CREDENTIALS, "");

            InitialDirContext initialContext = new InitialDirContext(env);
            DirContext ctx = (DirContext) initialContext;
            System.out.println("Context Sucessfully Initialized");
            ModificationItem[] mods = new ModificationItem[1];
            Attribute mod0 = new BasicAttribute("sn", "");
            mods[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, mod0);
//            ctx.modifyAttributes("uid=yiwei,ou=Administrator,o=SID", mods);
            ctx.modifyAttributes("sn", mods);
            System.out.println("Credential changed");
            ctx.close();
        } catch (Exception e) {
            e.printStackTrace();
            return "Failed";
        }
        return "Success";
    }
}
