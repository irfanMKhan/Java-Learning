package com.reddot.ecrm.controller.email;

import com.reddot.ecrm.dto.approval.MultiOrderApprovalLogDetailsDTO;
import com.reddot.ecrm.entity.approval.ApprovalLogDetailsEntity;
import com.reddot.ecrm.entity.approval.ApprovalRequestEntity;
import com.reddot.ecrm.enum_config.approval.ApprovalRequestStatusEnum;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.repository.approval.ApprovalLogDetailsRepo;
import com.reddot.ecrm.repository.approval.ApprovalRequestRepo;
import com.reddot.ecrm.service.email.ApprovalsUpdateService;
import com.reddot.ecrm.spring_config.ThreadPool.SingletonThreadPool;
import com.reddot.ecrm.spring_config.session.SessionManager;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@Controller
@RequestMapping("/approval/flow/request/email")
@RequiredArgsConstructor
public class EmailController {
    private final ThreadPoolTaskExecutor threadPoolTaskExecutor = SingletonThreadPool.getInstance();
    @Autowired
    ApprovalLogDetailsRepo approvalLogDetailsRepo;
    @Autowired
    ApprovalRequestRepo approvalRequestRepo;
    @Autowired
    ApprovalsUpdateService approvalsUpdateService;

    @GetMapping("/redirect")
    public String redirectPage(@RequestParam(value = "token", required = false) String token) {
        System.out.println(token);
        return "survey/surveyDetails";
    }

    @GetMapping("/accept")
    public Object acceptMail(@RequestParam("approverId") String approverId, @RequestParam("token") String token,
                             @RequestParam("approvalLogDetailsId") Long approvalLogDetailsId, ModelMap model,
                             HttpServletRequest request) throws UnsupportedEncodingException {
        new MenuViewer().setupSideMenu(model, request);
        MDUserModel userModel = SessionManager.getUserDetails(request);

        String msg = "";
        Optional<ApprovalLogDetailsEntity> approvalLogDetails = approvalLogDetailsRepo.findByApproverIDAndUuidTokenAndIdAndIsActive(
                Long.valueOf(approverId), token, approvalLogDetailsId, true);

        if (approvalLogDetails.isPresent()) {
            Optional<ApprovalRequestEntity> approvalRequest = approvalRequestRepo.findById(approvalLogDetails.get().getApprovalReqId());
            if (!approvalLogDetails.get().getStatus().equals(ApprovalRequestStatusEnum.PENDING.toString())) {  //if not pending means already accept or reject
                msg = "Already executed the request.";
                model.put("msg", msg);
                return "approval/approval_msg";
            }
            approvalLogDetails.get().setStatus(ApprovalRequestStatusEnum.APPROVED.toString());
            //approved time
            LocalDate localDate = LocalDate.now();
            approvalLogDetails.get().setApprovedAt(Utility.loggedInCurrentTime());
            approvalLogDetails.get().setApprovedAtDt(localDate);
            approvalLogDetailsRepo.saveAndFlush(approvalLogDetails.get());

            //check all the req_id approved or not?
            List<ApprovalLogDetailsEntity> listAllApprover = approvalLogDetailsRepo.findAllByApprovalReqIdAndIsActiveOrderByIdDesc(
                    approvalLogDetails.get().getApprovalReqId(), true);
            msg = "The Request is Accepted. ";

            if (!approvalRequest.get().getStatus().equals(ApprovalRequestStatusEnum.PENDING.toString())) {  //if not pending means already accept or reject
                if (approvalRequest.get().getStatus().equals(ApprovalRequestStatusEnum.APPROVED.toString())) {  //if not pending means already accept or reject
                    msg = msg + " This approval already accepted.";
                } else if (approvalRequest.get().getStatus().equals(ApprovalRequestStatusEnum.REJECTED.toString())) {
                    msg = msg + " This approval already rejected.";
                }
            }

            if (listAllApprover.size() == 1) {  //only one approver to req approval
                if (approvalRequest.isPresent()) {
                    approvalRequest.get().setStatus(ApprovalRequestStatusEnum.APPROVED.toString());
                    approvalRequestRepo.save(approvalRequest.get());
                }
                approvalsUpdateService.UpdateMainTable(approvalRequest.get().getApprovalFor(), ApprovalRequestStatusEnum.APPROVED, approvalRequest.get());
            } else {
                MultiOrderApprovalLogDetailsDTO dto = approvalsUpdateService.mapWithStepOrderANDLogDetails(listAllApprover);
                Integer highStepOrder = dto.getHighestStepOrder();
                Map<Integer, List<ApprovalLogDetailsEntity>> map = dto.getMapData();
                Boolean isThisApproverInHighOrderList = false;

                if (!ObjectUtils.isEmpty(highStepOrder) && !ObjectUtils.isEmpty(map) && !ObjectUtils.isEmpty(map.get(highStepOrder))) {
                    for (ApprovalLogDetailsEntity singleLogDetailsEntity : map.get(highStepOrder)) {
                        if (singleLogDetailsEntity.getId().equals(approvalLogDetails.get().getId())) {
                            isThisApproverInHighOrderList = true;
                            break;
                        }
                    }
                }

                //single step and multi-steps do same thing here
                //take highestStepOrder bcz high order approval action will determine that req should accept or reject.
                //low levels approver accept or reject bt not reflect in the main request
                if (isThisApproverInHighOrderList) {
                    CompletableFuture<Void> completableFuture = CompletableFuture.runAsync(() -> {
                        approvalsUpdateService.updateAcceptData(map.get(highStepOrder), approvalRequest.get());
                    }, threadPoolTaskExecutor);
                }
            }


            model.put("msg", msg);
            return "approval/approval_msg";

        } else {

            msg = "Error: User not find in approval log details"; //todo: update this error page
            model.put("msg", msg);
            return "approval/approval_msg";
        }
    }

    @GetMapping("/reject")
    public Object rejectMail(@RequestParam("approverId") String approverId, @RequestParam("token") String token,
                             @RequestParam("approvalLogDetailsId") Long approvalLogDetailsId,
                             ModelMap model, HttpServletRequest request) throws UnsupportedEncodingException {
        new MenuViewer().setupSideMenu(model, request);

        MDUserModel userModel = SessionManager.getUserDetails(request);
        String msg = "";
        boolean IsMandatoryApprover = false;

        Optional<ApprovalLogDetailsEntity> approvalLogDetails = approvalLogDetailsRepo.findByApproverIDAndUuidTokenAndIdAndIsActive(
                Long.valueOf(approverId), token, approvalLogDetailsId, true);
        if (approvalLogDetails.isPresent()) {
            if (!approvalLogDetails.get().getStatus().equals(ApprovalRequestStatusEnum.PENDING.toString())) {  //if not pending means already accept or reject
                msg = "Already executed the request.";
                model.put("msg", msg);
                return "approval/approval_msg";
            }
            approvalLogDetails.get().setStatus(ApprovalRequestStatusEnum.REJECTED.toString());
            if (!approvalLogDetails.get().getIsOptional()) {
                IsMandatoryApprover = true;
            }
            //approved time
            LocalDate localDate = LocalDate.now();
            approvalLogDetails.get().setApprovedAt(Utility.loggedInCurrentTime());
            approvalLogDetails.get().setApprovedAtDt(localDate);
            approvalLogDetailsRepo.saveAndFlush(approvalLogDetails.get());
            //check all the req_id approved or not?
            List<ApprovalLogDetailsEntity> listAllApprover = approvalLogDetailsRepo.findAllByApprovalReqIdAndIsActiveOrderByIdDesc(
                    approvalLogDetails.get().getApprovalReqId(), true);
            Optional<ApprovalRequestEntity> approvalRequest = approvalRequestRepo.findById(approvalLogDetails.get().getApprovalReqId());

            msg = "The Request is Rejected. ";

            if (!approvalRequest.get().getStatus().equals(ApprovalRequestStatusEnum.PENDING.toString())) {  //if not pending means already accept or reject
                if (approvalRequest.get().getStatus().equals(ApprovalRequestStatusEnum.APPROVED.toString())) {  //if not pending means already accept or reject
                    msg = msg + " This approval already Accepted.";
                } else if (approvalRequest.get().getStatus().equals(ApprovalRequestStatusEnum.REJECTED.toString())) {
                    msg = msg + " This approval already Rejected.";
                }
            }

            if (listAllApprover.size() == 1) {  //only one approver to req approval
                if (approvalRequest.isPresent()) {
                    approvalRequest.get().setStatus(ApprovalRequestStatusEnum.REJECTED.toString());
                    approvalRequestRepo.save(approvalRequest.get());
                }
                approvalsUpdateService.UpdateMainTable(approvalRequest.get().getApprovalFor(), ApprovalRequestStatusEnum.APPROVED, approvalRequest.get());
            } else {
                MultiOrderApprovalLogDetailsDTO dto = approvalsUpdateService.mapWithStepOrderANDLogDetails(listAllApprover);
                Integer highStepOrder = dto.getHighestStepOrder();
                Map<Integer, List<ApprovalLogDetailsEntity>> map = dto.getMapData();

                Boolean isThisApproverInHighOrderList = false;

                if (!ObjectUtils.isEmpty(highStepOrder) && !ObjectUtils.isEmpty(map) && !ObjectUtils.isEmpty(map.get(highStepOrder))) {
                    for (ApprovalLogDetailsEntity singleLogDetailsEntity : map.get(highStepOrder)) {
                        if (singleLogDetailsEntity.getId().equals(approvalLogDetails.get().getId())) {
                            isThisApproverInHighOrderList = true;
                            break;
                        }
                    }
                }

                //single step and multi-steps do same thing here
                //take highestStepOrder bcz high order approval action will determine that req should accept or reject.
                //low levels approver accept or reject bt not reflect in the main request
                if (isThisApproverInHighOrderList) {
                    boolean finalIsMandatoryApprover = IsMandatoryApprover;
                    CompletableFuture<Void> completableFuture = CompletableFuture.runAsync(() -> {
                        approvalsUpdateService.updateRejectData(map.get(highStepOrder), approvalRequest.get(), finalIsMandatoryApprover);
                    }, threadPoolTaskExecutor);

                }
            }


            model.put("msg", msg);
            return "approval/approval_msg";
        } else {
            msg = "error: User not find in approval log details"; //todo: update this error page
            model.put("msg", msg);
            return "approval/approval_msg";
        }
    }
}
