package com.reddot.ecrm.api.payload.response.shared.group;


import lombok.Data;

import java.io.Serializable;

@Data
public class DeleteCUGGroupMemberResponse implements Serializable {

    public String transaction_status;

    public Object data;

    public String transaction_id;

    public Metadata metadata;



    @Data
    public class Metadata implements Serializable {

        public String channel_id;
        public String operator_id;

    }
}
