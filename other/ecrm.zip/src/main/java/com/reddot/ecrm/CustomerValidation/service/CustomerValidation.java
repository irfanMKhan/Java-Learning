package com.reddot.ecrm.CustomerValidation.service;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.CustomerValidation.model.CustomerType;
import com.reddot.ecrm.model.Account.AccountSearchModel;
import com.reddot.ecrm.model.creation.MSISDNCTDETAILS;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.service.WebClientService;
import com.reddot.ecrm.service.manageservice.ManageService;
import com.reddot.ecrm.util.JsonIterator;
import com.reddot.ecrm.util.QueryBuilder;
import com.reddot.ecrm.util.Utility;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CustomerValidation {
    private final Logger logger = LoggerFactory.getLogger(ManageService.class);
//    static ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

//    @Autowired
//    WebClientService WCS;

    @Autowired
    private CommonRepository commonDAO;

//    @Value("${soam.staticTocken}")
    String staticTocken;

//    @Value("${saas.getallinfosaas}")
    String URLCustSaaS;

    public CustomerType CheckCustomerType(AccountSearchModel searchModel) {
        CustomerType R = new CustomerType();
        try {
            R.setMSISDN(searchModel.getMSISDN());
            R = IsPostPaidByAPI(searchModel);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return R;
    }


    public CustomerType IsPostPaidByTBL(AccountSearchModel searchModel) {

        CustomerType R = new CustomerType();
        try {
            Map<String, Object> WST = new HashMap<String, Object>();
            Map<String, Object> SD = new HashMap<String, Object>();
            if (!searchModel.getMSISDN().trim().toString().isEmpty()) {
                if (searchModel.getMSISDN().trim().toString().substring(0, 1).equals("9")) {
                    SD.put("ACCT_CODE", searchModel.getMSISDN().trim().toString());
                    WST.put("ACCT_CODE", "AND");
                } else {
                    SD.put("MSISDN", searchModel.getMSISDN().trim().toString().substring(3));
                    WST.put("MSISDN", "AND");
                }
            }
            if (searchModel.getACCOUNTNO() != null) {
                if (!searchModel.getACCOUNTNO().trim().toString().isEmpty()) {
                    SD.put("ACCT_CODE", searchModel.getACCOUNTNO().trim().toString());
                    WST.put("ACCT_CODE", "AND");
                }
            }
            if (WST.size() > 0) {
                String iiQStr = QueryBuilder.getCountWhereQueryNew(Utility.post_paid_demo_info, SD, WST, "*");
                logger.info(iiQStr);
                int ii = commonDAO.CommoNumberOfRow(iiQStr);
                if (ii > 0) {
                    R.setCONNECTION_TYPE("Postpaid");
                }
            }
            SD.clear();
            WST.clear();

            try {
                List<MSISDNCTDETAILS> ML = getMSISDNDetails(searchModel.getMSISDN());
                if (ML.size() > 0) {
                    R.setCONNECTION_TYPE(ML.get(0).getOPERATOR());
                }
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
            R.setSTATUS(true);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return R;
    }


    public CustomerType IsPostPaidByAPI(AccountSearchModel searchModel) {
        CustomerType R = new CustomerType();
        String msisdn = null;
        try {
            if (!searchModel.getMSISDN().trim().toString().isEmpty()) {
                msisdn = searchModel.getMSISDN().trim().toString();
            }

            if (searchModel.getACCOUNTNO() != null) {
                if (!searchModel.getACCOUNTNO().trim().toString().isEmpty()) {
                    msisdn = searchModel.getACCOUNTNO();
                }
            }

            R = getCustInfo(msisdn);
            if (!R.getSTATUS()) {
                R = IsPostPaidByTBL(searchModel);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return R;
    }


    public CustomerType getCustInfo(String msisdn) {
        CustomerType R = new CustomerType();
        try {
            ResponseEntity<String> res = WebClientService.HttpRequestGetData(URLCustSaaS + msisdn, "Basic " + staticTocken, "GET", logger);
            JSONObject jsonString = new JSONObject(res.getBody());
            JSONObject requestHeader = new JSONObject(jsonString.get("ResultHeader").toString());
            if (requestHeader.get("ResultCode").toString().equals("0")) {
                JSONObject SubIdentity = (JSONObject) new JsonIterator().getFirstOccurrence(jsonString, "SubscriberInfo");
                if (SubIdentity.has("Brand")) {
                    R = getOpName(SubIdentity.get("Brand").toString());
                    System.err.println(msisdn + " " + R.getOPERATOR() + " " + R.getCONNECTION_TYPE());
                }
                R.setSTATUS(true);
            } else {
                R.setSTATUS(false);
            }
        } catch (Exception e) {
            R.setSTATUS(false);
            logger.error(e.getMessage(), e);
        }
        return R;
    }

    private static CustomerType getOpName(String ban) {
        CustomerType H = new CustomerType();
        H.setSTATUS(true);
        switch (ban) {
            case "102":
                H.setCONNECTION_TYPE("Prepaid");
                H.setOPERATOR("Robi");
                break;
            case "103":
                H.setCONNECTION_TYPE("Prepaid");
                H.setOPERATOR("Robi");
                break;
            case "104":
                H.setCONNECTION_TYPE("Prepaid");
                H.setOPERATOR("Robi");
                break;
            case "105":
                H.setCONNECTION_TYPE("Prepaid");
                H.setOPERATOR("Robi");
                break;
            case "106":
                H.setCONNECTION_TYPE("Prepaid");
                H.setOPERATOR("Airtel");
                break;
            case "302":
                H.setCONNECTION_TYPE("Postpaid");
                H.setOPERATOR("Airtel");
                break;
            case "301":
                H.setCONNECTION_TYPE("Postpaid");
                H.setOPERATOR("Robi");
                break;
            case "201":
                H.setCONNECTION_TYPE("Prepaid");
                H.setOPERATOR("Airtel");
                break;
            default:
                H.setCONNECTION_TYPE("");
                H.setOPERATOR("");
                H.setSTATUS(false);
                break;
        }
        return H;
    }

    private List<MSISDNCTDETAILS> getMSISDNDetails(String number) {
        List<MSISDNCTDETAILS> cls = new ArrayList<MSISDNCTDETAILS>();
        try {

            String qry_fetch = "SELECT * FROM " + Utility.tbl_msisdn_ct_details + " where MSISDN = '" + number + "' FETCH NEXT 1 ROWS ONLY";
            Object srslist = commonDAO.CommoGetData(qry_fetch);
            cls = new Gson().fromJson(Utility.ObjectToJson(srslist), new TypeToken<List<MSISDNCTDETAILS>>() {
            }.getType());
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return cls;
    }
}
