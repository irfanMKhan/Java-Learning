package com.reddot.ecrm.dto.cr.change_branch;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MSISDNBranchDTO {
    private String msisdn;
    private String accountName;
    private String serviceType;
    private String accountCode;
    private Long accountPrimaryId;
}
