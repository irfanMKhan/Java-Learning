package com.reddot.ecrm.controller.srSettings.api;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.model.srSettings.SrPriorityModel;
import com.reddot.ecrm.service.srsettings.SrPriorityService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequestMapping(value = "/api/srPriority", method = RequestMethod.GET)
public class SrPriorityRestController {

    private final Logger logger = LoggerFactory.getLogger("SR Priority Logger");

    @Autowired
    private SrPriorityService service;

    @GetMapping("/all")
    public Object getAllPriority(){
        return service.getAllPriority();
    }

    @GetMapping("/DTData")
    public DataTablesOutput<SrPriorityModel> DTInteractionType(@Valid DataTablesInput input, HttpServletRequest request,
                                                               @RequestParam(value = "searchText", required = false) String customQuery,
                                                               @RequestParam(value = "customSearchCriteria", required = false) String customSearchCriteria){
        return service.DTSrPriority(input, request, customSearchCriteria, customQuery);
    }

    @PostMapping("/add")
    public CommonRestResponse srPriorityAdd(@RequestBody String srPriority, HttpServletRequest request){
        SrPriorityModel srPriorityModel = new Gson().fromJson(srPriority, new TypeToken<SrPriorityModel>(){}.getType());
//        SrPriorityModel srPriorityModel = new Gson().fromJson(srPriority, SrPriorityModel.class);
        System.err.println(srPriority);
        System.err.println(srPriorityModel);
        return service.addSrPriorityFunction(srPriorityModel, request);
    }

    @GetMapping("/item")
    public CommonRestResponse getPriorityItemById(@RequestParam("item") String id, HttpServletRequest request){
        String priorityId = new Gson().fromJson(id, String.class);
        return service.getPriorityItemById(priorityId);
    }

    @PostMapping("/update")
    public CommonRestResponse updatePriorityFunction(@RequestBody String priorityData, HttpServletRequest request){
//        SrPriorityModel srPriorityModel = new Gson().fromJson(priorityData,SrPriorityModel.class);
        SrPriorityModel srPriorityModel = new Gson().fromJson(priorityData, new TypeToken<SrPriorityModel>(){}.getType());
        System.err.println(priorityData);
        System.err.println(srPriorityModel);
        return service.updatePriorityFunction(srPriorityModel, request);
    }
/*
    @PostMapping("/update")
    public String srPriorityUpdate(HttpServletRequest request, @RequestParam("srPriority") String srPriority){
        try{
            srPriorityModel srPriorityModel = new Gson().fromJson(srPriority, new TypeToken<srPriorityModel>(){}.getType());
            if(srPriorityModel.getNAME() == null || srPriorityModel.getNAME().isEmpty()){
                return "Please enter a name";
            }
            if(service.updatesrPriorityFunction(srPriorityModel, request)){
                return "success";
            }
            else{
                return "This name already exists, please provide a different name";
            }
        }
        catch (Exception e){
            e.printStackTrace();
            logger.error("Update Order Priority Error");
            logger.error(e.getMessage(), e);
            return "Order Priority Update Failed! Try later.";
        }
    }*/

}
