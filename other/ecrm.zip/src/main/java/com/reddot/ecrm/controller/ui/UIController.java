package com.reddot.ecrm.controller.ui;

import com.google.gson.JsonArray;
import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.repository.company.CompanyRepository;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/ui")
public class UIController {

    @GetMapping("/template/single")
    public String UITemplateTableSingleSearch(ModelMap model, HttpServletRequest request){
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Page Title");
        return "ui/template_table_single";
    }
    @GetMapping("/template/multi")
    public String UITemplateTableMultiSearch(ModelMap model, HttpServletRequest request){
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Page Title");
        return "ui/template_table_multi";
    }
    @GetMapping("/template/noTable")
    public String UITemplateTableNoTable(ModelMap model, HttpServletRequest request){
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Page Title");
        return "ui/template_no_table";
    }

    @GetMapping("/opportunity")
    public String viewOpportunity(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Opportunities");
        return "ui/opportunityUI";
    }

    @GetMapping("/lead")
    public String viewLead(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Leads");
        return "ui/leadUI";
    }

    @GetMapping("/contracts")
    public String viewContracts(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Contracts");
        return "ui/contractUI";
    }

    @GetMapping("/subContracts")
    public String viewSubContracts(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Sub-Contract");
        return "ui/subContractUI";
    }

    @GetMapping("/eshop")
    public String viewEshop(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "E-Shop");
        return "ui/eshopUI";
    }

    @GetMapping("/addEditOpportunity")
    public String viewAddEditOpportunity(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Add Opportunity");
        return "ui/addEditOpportunityUI";
    }

    @GetMapping("/addEditLead")
    public String viewAddEditLead(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Add Lead");
        return "ui/addEditLeadUI";
    }

    @GetMapping("/addEditContract")
    public String viewAddEditContract(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Add Contract");
        return "ui/addEditContractUI";
    }

    @GetMapping("/addEditSubContract")
    public String viewAddEditSubContract(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Sub-Contract");
        return "ui/addEditSubContractUI";
    }

    @GetMapping("/purchaseHistory")
    public String viewPurchaseHistory(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Purchase History");
        return "ui/purchaseHistoryUI";
    }

//    @GetMapping("/newNumberListCR")
//    public String viewNewNumberListCR(ModelMap model, HttpServletRequest request){
//        new MenuViewer().setupSideMenu(model, request);
//        model.put("title", "Numbers List");
//        return "ui/CRnewNumberListUI";
//    }
//    @GetMapping("/newNumberListWP")
//    public String viewNewNumberListWP(ModelMap model, HttpServletRequest request){
//        new MenuViewer().setupSideMenu(model, request);
//        model.put("title", "Numbers List");
//        return "ui/WPnewNumberListUI";
//    }

    @GetMapping("/numberListCR")
    public String viewNumberListCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Numbers List");
        return "ui/numberListUICR";
    }

    @GetMapping("/numberListWP")
    public String viewNumberListWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Numbers List");
        return "ui/numberListUIWP";
    }

    @GetMapping("/addNewNumberCR")
    public String viewAddNewNumberSummaryCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Add New Number");
        return "ui/addNewNumberSummaryUICR";
    }

    @GetMapping("/addNewNumberCR/summary")
    public String redirectAddNewNumberSummaryCR() {
        return "redirect:/ui/addNewNumberCR";
    }

    @GetMapping("/addNewNumberCR/add")
    public String viewAddNewNumberCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Add New Number");
        return "ui/addNewNumberUICR";
    }

    @GetMapping("/addNewNumberWP")
    public String viewAddNewNumberSummaryWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Add New Number");
        return "ui/addNewNumberSummaryUIWP";
    }

    @GetMapping("/addNewNumberWP/summary")
    public String redirectAddNewNumberSummaryWP() {
        return "redirect:/ui/addNewNumberWP";
    }

    @GetMapping("/addNewNumberWP/add")
    public String viewAddNewNumberWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Add New Number");
        return "ui/addNewNumberUIWP";
    }

    @GetMapping("/changePlanCR")
    public String viewChangeSummaryPlanCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Change Plan");
        return "ui/changePlanSummaryUICR";
    }

    @GetMapping("/changePlanCR/summary")
    public String redirectChangeSummaryPlanCR() {
        return "redirect:/ui/changePlanCR";
    }

    @GetMapping("/changePlanCR/change")
    public String viewChangePlanCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Change Plan");
        return "ui/changePlanUICR";
    }

    @GetMapping("/changePlanWP")
    public String viewChangePlanSummaryWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Change Plan");
        return "ui/changePlanSummaryUIWP";
    }

    @GetMapping("/changePlanWP/summary")
    public String redirectChangeSummaryPlanWP() {
        return "redirect:/ui/changePlanWP";
    }

    @GetMapping("/changePlanWP/change")
    public String viewChangePlanWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Change Plan");
        return "ui/changePlanUIWP";
    }

    @GetMapping("/addRemoveServiceCR")
    public String viewAddRemoveServiceCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Add / Remove Service");
        return "ui/addRemoveServiceUICR";
    }

    @GetMapping("/addRemoveServiceWP")
    public String viewAddRemoveServiceWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Add / Remove Service");
        return "ui/addRemoveServiceUIWP";
    }

    @GetMapping("/increaseDecreaseCreditLimitCR")
    public String viewIncreaseDecreaseCreditLimitCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Increase / Decrease Credit Limit");
        return "ui/increaseDecreaseCreditLimitUICR";
    }

    @GetMapping("/increaseDecreaseCreditLimitWP")
    public String viewIncreaseDecreaseCreditLimitWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Increase / Decrease Credit Limit");
        return "ui/increaseDecreaseCreditLimitUIWP";
    }

    @GetMapping("/BatchUploadCR")
    public String viewBatchUploadCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Batch Upload");
        return "ui/BatchUploadUICR";
    }

    @GetMapping("/BatchUploadWP")
    public String viewBatchUploadWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Batch Upload");
        return "ui/BatchUploadUIWP";
    }

    @GetMapping("/hotbillCR")
    public String viewGenerateBillCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "PDF Bill + Hotbill");
        return "ui/HotbillUICR";
    }

    @GetMapping("/hotbillWP")
    public String viewGenerateBillWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "PDF Bill + Hotbill");
        return "ui/HotbillUIWP";
    }

    @GetMapping("/cdrCR")
    public String viewCDRCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Download CDR");
        return "ui/CDRUICR";
    }

    @GetMapping("/cdrWP")
    public String viewCDRWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Download CDR");
        return "ui/CDRUIWP";
    }

    @GetMapping("/downloadCustomerInformationWP")
    public String viewCustInfoWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Download Customer Information");
        return "ui/CustomerInfoUIWP";
    }

    @GetMapping("/downloadReceiptWP")
    public String viewReceiptWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Download Statement Note / Receipt");
        return "ui/downloadReceiptUIWP";
    }

    @GetMapping("/terminateCR")
    public String viewTerminateCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Terminate");
        return "ui/TerminateUICR";
    }

    @GetMapping("/terminateWP")
    public String viewTerminateWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Terminate");
        return "ui/TerminateUIWP";
    }

    @GetMapping("/post2preCR")
    public String viewPost2PreCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Postpaid to Prepaid");
        return "ui/Post2PreUICR";
    }

    @GetMapping("/post2preWP")
    public String viewPost2PreWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Postpaid to Prepaid");
        return "ui/Post2PreUIWP";
    }

    @GetMapping("/suspendCR")
    public String viewSuspendCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Suspend");
        return "ui/SuspendUICR";
    }

    @GetMapping("/suspendWP")
    public String viewSuspendWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Suspend");
        return "ui/SuspendUIWP";
    }

    @GetMapping("/changeBranchCR")
    public String viewChangeBranchCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Change Branch");
        return "ui/ChangeBranchUICR";
    }

    @GetMapping("/changeBranchWP")
    public String viewChangeBranchWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Change Branch");
        return "ui/ChangeBranchUIWP";
    }

    @GetMapping("/transferOwnershipCR")
    public String viewTransferOwnershipCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Transfer Ownership");
        return "ui/TransferOwnershipUICR";
    }

    @GetMapping("/resetNetworkCR")
    public String viewResetNetworkCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Change SIM / Phone Stolen / Reset Network");
        return "ui/ResetNetworkUICR";
    }

    @GetMapping("/changeCustomerInfoCR")
    public String viewChangeCustomerInfoCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Change Customer Information");
        return "ui/ChangeCustomerInfoUICR";
    }

    @GetMapping("/changeCustomerInfoWP")
    public String viewChangeCustomerInfoWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Change Customer Information");
        return "ui/ChangeCustomerInfoUIWP";
    }

    @GetMapping("/changeSIMWP")
    public String viewChangeSIMWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Change SIM / Phone Stolen / Reactivate");
        return "ui/ChangeSIMUIWP";
    }

    @GetMapping("/delegation")
    public String viewDelegation(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Delegate Approval");
        return "ui/DelegationUI";
    }

    @GetMapping("/refundDeposit")
    public String viewRefund(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Refund Deposit");
        return "ui/RefundDepositUICR";
    }

    @GetMapping("/promise2payCR")
    public String viewPromise2PayCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Promise to Pay");
        return "ui/Promise2PayUICR";
    }

    @GetMapping("/promise2payWP")
    public String viewPromise2PayWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Agree To Pay");
        return "ui/Promise2PayUIWP";
    }

    @GetMapping("/Pre2PostCR")
    public String viewPre2PostCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Prepaid To Postpaid");
        return "ui/Pre2PostUICR";
    }

    @GetMapping("/Pre2PostWP")
    public String viewPre2PostWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Prepaid To Postpaid");
        return "ui/Pre2PostUIWP";
    }

    @GetMapping("/IncreaseCreditCeilingCR")
    public String viewIncreaseCreditCeilingCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Increase Credit Ceiling");
        return "ui/IncreaseCreditCeilingUICR";
    }

    @GetMapping("/IncreaseCreditCeilingWP")
    public String viewIncreaseCreditCeilingWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Increase Credit Ceiling");
        return "ui/IncreaseCreditCeilingUIWP";
    }

    @GetMapping("/SwapSIMCR")
    public String viewSwapSIMCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Swap SIM");
        return "ui/SwapSIMUICR";
    }

    @GetMapping("/SwapSIMWP")
    public String viewSwapSIMWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Swap SIM");
        return "ui/SwapSIMUIWP";
    }

    @GetMapping("/DepositCR")
    public String viewDepositCR(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Deposit");
        return "ui/DepositCRUI";
    }

    @GetMapping("/DepositWP")
    public String viewDepositWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Deposit");
        return "ui/DepositWPUI";
    }

    @GetMapping("/integrateProductWP")
    public String viewIntegrateProductWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Integrate with Other Product/Solution");
        return "ui/integrateProductWP";
    }

    @GetMapping("/joinCUGMaster")
    public String viewJoinCUGMaster(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Join Master / CUG Group");
        return "ui/JoinCUGMaster";
    }

    @GetMapping("/makePaymentWP")
    public String viewMakePaymentWP(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Make Payment");
        return "ui/MakePaymentUIWP";
    }


    //    COLOR
    @GetMapping("/color")
    public String viewColorUI() {
        return "redirect:/ui/color/list";
    }

    @GetMapping("/color/list")
    public String viewColorSetupList(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Color Setup");
        return "ui/ColorSetupListUI";
    }

    @GetMapping("/color/add")
    public String viewColorSetupAdd(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Add Color");
        return "ui/ColorSetupAddUI";
    }

    //    BRAND
    @GetMapping("/deviceBrand")
    public String viewDeviceBrandUI() {
        return "redirect:/ui/deviceBrand/list";
    }

    @GetMapping("/deviceBrand/list")
    public String viewDeviceBrandSetupList(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Device Brand Setup");
        return "ui/DeviceBrandSetupListUI";
    }

    @GetMapping("/deviceBrand/add")
    public String viewDeviceBrandSetupAdd(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Add Device Brand");
        return "ui/DeviceBrandSetupAddUI";
    }

    //    TYPE
    @GetMapping("/deviceType")
    public String viewDeviceTypeSetupUI() {
        return "redirect:/ui/deviceType/list";
    }

    @GetMapping("/deviceType/list")
    public String viewDeviceTypeSetupList(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Device Type Setup");
        return "ui/DeviceTypeSetupListUI";
    }

    @GetMapping("/deviceType/add")
    public String viewDeviceTypeSetupAdd(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Add Device Type");
        return "ui/DeviceTypeSetupAddUI";
    }

    //    CAPACITY
    @GetMapping("/deviceCapacity")
    public String viewDeviceCapacitySetupUI() {
        return "redirect:/ui/deviceCapacity/list";
    }

    @GetMapping("/deviceCapacity/list")
    public String viewDeviceCapacitySetupList(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Device Capacity Setup");
        return "ui/DeviceCapacitySetupListUI";
    }

    @GetMapping("/deviceCapacity/add")
    public String viewDeviceCapacitySetupAdd(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Add Device Capacity");
        return "ui/DeviceCapacitySetupAddUI";
    }

    //    MODEL
    @GetMapping("/deviceModel")
    public String viewDeviceModelSetupUI() {
        return "redirect:/ui/deviceModel/list";
    }

    @GetMapping("/deviceModel/list")
    public String viewDeviceModelSetupList(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Device Model Setup");
        return "ui/DeviceModelSetupListUI";
    }

    @GetMapping("/deviceModel/add")
    public String viewDeviceModelSetupAdd(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Add Device Model");
        return "ui/DeviceModelSetupAddUI";
    }

    // SUPPLEMENTARY OFFERING
    @GetMapping("/supplementaryOffering")
    public String viewSupplementaryOfferingUI() {
        return "redirect:/ui/supplementaryOffering/list";
    }

    @GetMapping("/supplementaryOffering/list")
    public String viewSupplementaryOfferingList(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Supplementary Offering");
        return "ui/SupplementaryOfferingListUI";
    }

    @GetMapping("/supplementaryOffering/add")
    public String viewSupplementaryOfferingAdd(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Add Supplementary Offering");
        return "ui/SupplementaryOfferingAddUI";
    }

    // PRIMARY OFFERING
    @GetMapping("/primaryOffering")
    public String viewPrimaryOfferingUI() {
        return "redirect:/ui/primaryOffering/list";
    }

    @GetMapping("/primaryOffering/list")
    public String viewPrimaryOfferingList(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Primary Offering");
        return "ui/PrimaryOfferingListUI";
    }

    @GetMapping("/primaryOffering/add")
    public String viewPrimaryOfferingAdd(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Add Primary Offering");
        return "ui/PrimaryOfferingAddUI";
    }

    @GetMapping("/company")
    public String viewCompanyUI() {
        return "redirect:/ui/company/list";
    }

    @GetMapping("/company/list")
    String viewCompanyListUI(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Company");
        return "ui/CompanyListUI";
    }

    @GetMapping("/company/view")
    String viewCompanyAddUI(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "View Company Details");
        return "ui/CompanyAddUI";
    }
    
    @GetMapping("/fa")
    String viewFaAdjustUI(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Financial Adjustment");
        return "ui/FaAdjustUI";
    }
    
    @GetMapping("/bill-medium")
    String viewPICDashboard(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Bill Medium");
        return "ui/bill_medium";
    }
    
    @GetMapping("/plan-company-mapping")
    String viewPlanCompanyMapping(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Plan Company Mapping");
        return "ui/plan_company_mapping";
    }
}
