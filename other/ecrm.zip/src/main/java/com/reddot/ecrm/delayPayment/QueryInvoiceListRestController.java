package com.reddot.ecrm.delayPayment;

import com.reddot.ecrm.api.payload.request.payment.QueryInvoiceAPIRequest;
import com.reddot.ecrm.module.ptp.InvoiceListSearchReqDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
public class QueryInvoiceListRestController {

    @Autowired
    private QueryInvoiceListService queryInvoiceListService;

    @RequestMapping(value = "/get-all/query-invoice", method = RequestMethod.POST)
    public ResponseEntity<?> getAllInvoice(HttpServletRequest httpServletRequest, @RequestBody QueryInvoiceListReqBody reqBody) {
        return queryInvoiceListService.getAllInvoice(httpServletRequest, reqBody);
    }
}
