package com.reddot.ecrm.api.payload.response.contract.customer;

import java.io.Serializable;
import java.lang.String;
import java.lang.String;
import java.lang.String;
import java.lang.String;
import java.util.List;

public class CBSBCCustomerResponse implements Serializable {
  private QueryCustomerInfoResult QueryCustomerInfoResult;

  public QueryCustomerInfoResult getQueryCustomerInfoResult() {
    return this.QueryCustomerInfoResult;
  }

  public void setQueryCustomerInfoResult(QueryCustomerInfoResult QueryCustomerInfoResult) {
    this.QueryCustomerInfoResult = QueryCustomerInfoResult;
  }

  public static class QueryCustomerInfoResult implements Serializable {
    private Account Account;

    private Customer Customer;

    private Subscriber Subscriber;

    public Account getAccount() {
      return this.Account;
    }

    public void setAccount(Account Account) {
      this.Account = Account;
    }

    public Customer getCustomer() {
      return this.Customer;
    }

    public void setCustomer(Customer Customer) {
      this.Customer = Customer;
    }

    public Subscriber getSubscriber() {
      return this.Subscriber;
    }

    public void setSubscriber(Subscriber Subscriber) {
      this.Subscriber = Subscriber;
    }

    public static class Account implements Serializable {
      private String AcctKey;

      private OfferingInst OfferingInst;

      private AcctInfo AcctInfo;

      public String getAcctKey() {
        return this.AcctKey;
      }

      public void setAcctKey(String AcctKey) {
        this.AcctKey = AcctKey;
      }

      public OfferingInst getOfferingInst() {
        return this.OfferingInst;
      }

      public void setOfferingInst(OfferingInst OfferingInst) {
        this.OfferingInst = OfferingInst;
      }

      public AcctInfo getAcctInfo() {
        return this.AcctInfo;
      }

      public void setAcctInfo(AcctInfo AcctInfo) {
        this.AcctInfo = AcctInfo;
      }

      public static class OfferingInst implements Serializable {
        private String Status;

        private String OfferingClass;

        private String EffectiveTime;

        private String ActivationTime;

        private String ActivationMode;

        private OfferingKey OfferingKey;

        private String ExpirationTime;

        private String BundledFlag;

        public String getStatus() {
          return this.Status;
        }

        public void setStatus(String Status) {
          this.Status = Status;
        }

        public String getOfferingClass() {
          return this.OfferingClass;
        }

        public void setOfferingClass(String OfferingClass) {
          this.OfferingClass = OfferingClass;
        }

        public String getEffectiveTime() {
          return this.EffectiveTime;
        }

        public void setEffectiveTime(String EffectiveTime) {
          this.EffectiveTime = EffectiveTime;
        }

        public String getActivationTime() {
          return this.ActivationTime;
        }

        public void setActivationTime(String ActivationTime) {
          this.ActivationTime = ActivationTime;
        }

        public String getActivationMode() {
          return this.ActivationMode;
        }

        public void setActivationMode(String ActivationMode) {
          this.ActivationMode = ActivationMode;
        }

        public OfferingKey getOfferingKey() {
          return this.OfferingKey;
        }

        public void setOfferingKey(OfferingKey OfferingKey) {
          this.OfferingKey = OfferingKey;
        }

        public String getExpirationTime() {
          return this.ExpirationTime;
        }

        public void setExpirationTime(String ExpirationTime) {
          this.ExpirationTime = ExpirationTime;
        }

        public String getBundledFlag() {
          return this.BundledFlag;
        }

        public void setBundledFlag(String BundledFlag) {
          this.BundledFlag = BundledFlag;
        }

        public static class OfferingKey implements Serializable {
          private String PurchaseSeq;

          private String OfferingID;

          public String getPurchaseSeq() {
            return this.PurchaseSeq;
          }

          public void setPurchaseSeq(String PurchaseSeq) {
            this.PurchaseSeq = PurchaseSeq;
          }

          public String getOfferingID() {
            return this.OfferingID;
          }

          public void setOfferingID(String OfferingID) {
            this.OfferingID = OfferingID;
          }
        }
      }

      public static class AcctInfo implements Serializable {
        private String AcctType;

        private String BillCycleEndDate;

        private String UserCustomerKey;

        private String AcctCode;

        private String BillCycleType;

        private UserCustomer UserCustomer;

        private String CurrencyID;

        private AddressInfo AddressInfo;

        private String RootAcctKey;

        private String AcctClass;

        private String AcctPayMethod;

        private String PaymentType;

        private String BillCycleOpenDate;

        private AcctBasicInfo AcctBasicInfo;

        public String getAcctType() {
          return this.AcctType;
        }

        public void setAcctType(String AcctType) {
          this.AcctType = AcctType;
        }

        public String getBillCycleEndDate() {
          return this.BillCycleEndDate;
        }

        public void setBillCycleEndDate(String BillCycleEndDate) {
          this.BillCycleEndDate = BillCycleEndDate;
        }

        public String getUserCustomerKey() {
          return this.UserCustomerKey;
        }

        public void setUserCustomerKey(String UserCustomerKey) {
          this.UserCustomerKey = UserCustomerKey;
        }

        public String getAcctCode() {
          return this.AcctCode;
        }

        public void setAcctCode(String AcctCode) {
          this.AcctCode = AcctCode;
        }

        public String getBillCycleType() {
          return this.BillCycleType;
        }

        public void setBillCycleType(String BillCycleType) {
          this.BillCycleType = BillCycleType;
        }

        public UserCustomer getUserCustomer() {
          return this.UserCustomer;
        }

        public void setUserCustomer(UserCustomer UserCustomer) {
          this.UserCustomer = UserCustomer;
        }

        public String getCurrencyID() {
          return this.CurrencyID;
        }

        public void setCurrencyID(String CurrencyID) {
          this.CurrencyID = CurrencyID;
        }

        public AddressInfo getAddressInfo() {
          return this.AddressInfo;
        }

        public void setAddressInfo(AddressInfo AddressInfo) {
          this.AddressInfo = AddressInfo;
        }

        public String getRootAcctKey() {
          return this.RootAcctKey;
        }

        public void setRootAcctKey(String RootAcctKey) {
          this.RootAcctKey = RootAcctKey;
        }

        public String getAcctClass() {
          return this.AcctClass;
        }

        public void setAcctClass(String AcctClass) {
          this.AcctClass = AcctClass;
        }

        public String getAcctPayMethod() {
          return this.AcctPayMethod;
        }

        public void setAcctPayMethod(String AcctPayMethod) {
          this.AcctPayMethod = AcctPayMethod;
        }

        public String getPaymentType() {
          return this.PaymentType;
        }

        public void setPaymentType(String PaymentType) {
          this.PaymentType = PaymentType;
        }

        public String getBillCycleOpenDate() {
          return this.BillCycleOpenDate;
        }

        public void setBillCycleOpenDate(String BillCycleOpenDate) {
          this.BillCycleOpenDate = BillCycleOpenDate;
        }

        public AcctBasicInfo getAcctBasicInfo() {
          return this.AcctBasicInfo;
        }

        public void setAcctBasicInfo(AcctBasicInfo AcctBasicInfo) {
          this.AcctBasicInfo = AcctBasicInfo;
        }

        public static class UserCustomer implements Serializable {
          private IndividualInfo IndividualInfo;

          private CustInfo CustInfo;

          private String CustKey;

          public IndividualInfo getIndividualInfo() {
            return this.IndividualInfo;
          }

          public void setIndividualInfo(IndividualInfo IndividualInfo) {
            this.IndividualInfo = IndividualInfo;
          }

          public CustInfo getCustInfo() {
            return this.CustInfo;
          }

          public void setCustInfo(CustInfo CustInfo) {
            this.CustInfo = CustInfo;
          }

          public String getCustKey() {
            return this.CustKey;
          }

          public void setCustKey(String CustKey) {
            this.CustKey = CustKey;
          }

          public static class IndividualInfo implements Serializable {
            private List< IndividualProperty> IndividualProperty;

            private String HomeAddressKey;

            private String FirstName;

            private String Birthday;

            private String LastName;

            private String Gender;

            private String IDType;

            private String Nationality;

            private String IDNumber;

            public List<? extends IndividualProperty> getIndividualProperty() {
              return this.IndividualProperty;
            }

            public void setIndividualProperty(List<IndividualProperty> IndividualProperty) {
              this.IndividualProperty = IndividualProperty;
            }

            public String getHomeAddressKey() {
              return this.HomeAddressKey;
            }

            public void setHomeAddressKey(String HomeAddressKey) {
              this.HomeAddressKey = HomeAddressKey;
            }

            public String getFirstName() {
              return this.FirstName;
            }

            public void setFirstName(String FirstName) {
              this.FirstName = FirstName;
            }

            public String getBirthday() {
              return this.Birthday;
            }

            public void setBirthday(String Birthday) {
              this.Birthday = Birthday;
            }

            public String getLastName() {
              return this.LastName;
            }

            public void setLastName(String LastName) {
              this.LastName = LastName;
            }

            public String getGender() {
              return this.Gender;
            }

            public void setGender(String Gender) {
              this.Gender = Gender;
            }

            public String getIDType() {
              return this.IDType;
            }

            public void setIDType(String IDType) {
              this.IDType = IDType;
            }

            public String getNationality() {
              return this.Nationality;
            }

            public void setNationality(String Nationality) {
              this.Nationality = Nationality;
            }

            public String getIDNumber() {
              return this.IDNumber;
            }

            public void setIDNumber(String IDNumber) {
              this.IDNumber = IDNumber;
            }

            public static class IndividualProperty implements Serializable {
              private String Value;

              private String Code;

              public String getValue() {
                return this.Value;
              }

              public void setValue(String Value) {
                this.Value = Value;
              }

              public String getCode() {
                return this.Code;
              }

              public void setCode(String Code) {
                this.Code = Code;
              }
            }
          }

          public static class CustInfo implements Serializable {
            private String CustNodeType;

            private String CustClass;

            private String CustType;

            private String CustCode;

            private CustBasicInfo CustBasicInfo;

            public String getCustNodeType() {
              return this.CustNodeType;
            }

            public void setCustNodeType(String CustNodeType) {
              this.CustNodeType = CustNodeType;
            }

            public String getCustClass() {
              return this.CustClass;
            }

            public void setCustClass(String CustClass) {
              this.CustClass = CustClass;
            }

            public String getCustType() {
              return this.CustType;
            }

            public void setCustType(String CustType) {
              this.CustType = CustType;
            }

            public String getCustCode() {
              return this.CustCode;
            }

            public void setCustCode(String CustCode) {
              this.CustCode = CustCode;
            }

            public CustBasicInfo getCustBasicInfo() {
              return this.CustBasicInfo;
            }

            public void setCustBasicInfo(CustBasicInfo CustBasicInfo) {
              this.CustBasicInfo = CustBasicInfo;
            }

            public static class CustBasicInfo implements Serializable {
              private String CustLevel;

              private String DFTCurrencyID;

              private String DunningFlag;

              private List<? extends IndividualInfo.IndividualProperty> CustProperty;

              private String DFTBillCycleType;

              private String DFTIVRLang;

              private String DFTWrittenLang;

              public String getCustLevel() {
                return this.CustLevel;
              }

              public void setCustLevel(String CustLevel) {
                this.CustLevel = CustLevel;
              }

              public String getDFTCurrencyID() {
                return this.DFTCurrencyID;
              }

              public void setDFTCurrencyID(String DFTCurrencyID) {
                this.DFTCurrencyID = DFTCurrencyID;
              }

              public String getDunningFlag() {
                return this.DunningFlag;
              }

              public void setDunningFlag(String DunningFlag) {
                this.DunningFlag = DunningFlag;
              }

              public List<? extends IndividualInfo.IndividualProperty> getCustProperty() {
                return this.CustProperty;
              }

              public void setCustProperty(List<? extends IndividualInfo.IndividualProperty> CustProperty) {
                this.CustProperty = CustProperty;
              }

              public String getDFTBillCycleType() {
                return this.DFTBillCycleType;
              }

              public void setDFTBillCycleType(String DFTBillCycleType) {
                this.DFTBillCycleType = DFTBillCycleType;
              }

              public String getDFTIVRLang() {
                return this.DFTIVRLang;
              }

              public void setDFTIVRLang(String DFTIVRLang) {
                this.DFTIVRLang = DFTIVRLang;
              }

              public String getDFTWrittenLang() {
                return this.DFTWrittenLang;
              }

              public void setDFTWrittenLang(String DFTWrittenLang) {
                this.DFTWrittenLang = DFTWrittenLang;
              }
            }
          }
        }

        public static class AddressInfo implements Serializable {
          private String Address7;

          private String Address11;

          private String Address5;

          private String Address2;

          private String Address3;

          private String AddressKey;

          private String Address1;

          public String getAddress7() {
            return this.Address7;
          }

          public void setAddress7(String Address7) {
            this.Address7 = Address7;
          }

          public String getAddress11() {
            return this.Address11;
          }

          public void setAddress11(String Address11) {
            this.Address11 = Address11;
          }

          public String getAddress5() {
            return this.Address5;
          }

          public void setAddress5(String Address5) {
            this.Address5 = Address5;
          }

          public String getAddress2() {
            return this.Address2;
          }

          public void setAddress2(String Address2) {
            this.Address2 = Address2;
          }

          public String getAddress3() {
            return this.Address3;
          }

          public void setAddress3(String Address3) {
            this.Address3 = Address3;
          }

          public String getAddressKey() {
            return this.AddressKey;
          }

          public void setAddressKey(String AddressKey) {
            this.AddressKey = AddressKey;
          }

          public String getAddress1() {
            return this.Address1;
          }

          public void setAddress1(String Address1) {
            this.Address1 = Address1;
          }
        }

        public static class AcctBasicInfo implements Serializable {
          private String AcctName;

          private String DunningFlag;

          private List<? extends UserCustomer.IndividualInfo.IndividualProperty> AcctProperty;

          private String BillLang;

          private ContactInfo ContactInfo;

          private String LateFeeChargeable;

          private String RedlistFlag;

          public String getAcctName() {
            return this.AcctName;
          }

          public void setAcctName(String AcctName) {
            this.AcctName = AcctName;
          }

          public String getDunningFlag() {
            return this.DunningFlag;
          }

          public void setDunningFlag(String DunningFlag) {
            this.DunningFlag = DunningFlag;
          }

          public List<? extends UserCustomer.IndividualInfo.IndividualProperty> getAcctProperty() {
            return this.AcctProperty;
          }

          public void setAcctProperty(List<? extends UserCustomer.IndividualInfo.IndividualProperty> AcctProperty) {
            this.AcctProperty = AcctProperty;
          }

          public String getBillLang() {
            return this.BillLang;
          }

          public void setBillLang(String BillLang) {
            this.BillLang = BillLang;
          }

          public ContactInfo getContactInfo() {
            return this.ContactInfo;
          }

          public void setContactInfo(ContactInfo ContactInfo) {
            this.ContactInfo = ContactInfo;
          }

          public String getLateFeeChargeable() {
            return this.LateFeeChargeable;
          }

          public void setLateFeeChargeable(String LateFeeChargeable) {
            this.LateFeeChargeable = LateFeeChargeable;
          }

          public String getRedlistFlag() {
            return this.RedlistFlag;
          }

          public void setRedlistFlag(String RedlistFlag) {
            this.RedlistFlag = RedlistFlag;
          }

          public static class ContactInfo implements Serializable {
            private String FirstName;

            private String Title;

            private String LastName;

            private String AddressKey;

            public String getFirstName() {
              return this.FirstName;
            }

            public void setFirstName(String FirstName) {
              this.FirstName = FirstName;
            }

            public String getTitle() {
              return this.Title;
            }

            public void setTitle(String Title) {
              this.Title = Title;
            }

            public String getLastName() {
              return this.LastName;
            }

            public void setLastName(String LastName) {
              this.LastName = LastName;
            }

            public String getAddressKey() {
              return this.AddressKey;
            }

            public void setAddressKey(String AddressKey) {
              this.AddressKey = AddressKey;
            }
          }
        }
      }
    }

    public static class Customer implements Serializable {
      private Account.AcctInfo.UserCustomer.IndividualInfo IndividualInfo;

      private Account.AcctInfo.UserCustomer.CustInfo CustInfo;

      private String CustKey;

      private AddressInfo AddressInfo;

      public Account.AcctInfo.UserCustomer.IndividualInfo getIndividualInfo() {
        return this.IndividualInfo;
      }

      public void setIndividualInfo(Account.AcctInfo.UserCustomer.IndividualInfo IndividualInfo) {
        this.IndividualInfo = IndividualInfo;
      }

      public Account.AcctInfo.UserCustomer.CustInfo getCustInfo() {
        return this.CustInfo;
      }

      public void setCustInfo(Account.AcctInfo.UserCustomer.CustInfo CustInfo) {
        this.CustInfo = CustInfo;
      }

      public String getCustKey() {
        return this.CustKey;
      }

      public void setCustKey(String CustKey) {
        this.CustKey = CustKey;
      }

      public AddressInfo getAddressInfo() {
        return this.AddressInfo;
      }

      public void setAddressInfo(AddressInfo AddressInfo) {
        this.AddressInfo = AddressInfo;
      }

      public static class AddressInfo implements Serializable {
        private String Address11;

        private String Address2;

        private String Address3;

        private String AddressKey;

        private String Address1;

        public String getAddress11() {
          return this.Address11;
        }

        public void setAddress11(String Address11) {
          this.Address11 = Address11;
        }

        public String getAddress2() {
          return this.Address2;
        }

        public void setAddress2(String Address2) {
          this.Address2 = Address2;
        }

        public String getAddress3() {
          return this.Address3;
        }

        public void setAddress3(String Address3) {
          this.Address3 = Address3;
        }

        public String getAddressKey() {
          return this.AddressKey;
        }

        public void setAddressKey(String AddressKey) {
          this.AddressKey = AddressKey;
        }

        public String getAddress1() {
          return this.Address1;
        }

        public void setAddress1(String Address1) {
          this.Address1 = Address1;
        }
      }
    }

    public static class Subscriber implements Serializable {
      private String SubscriberKey;

      private SubscriberInfo SubscriberInfo;

      private PrimaryOffering PrimaryOffering;

      private List<? extends SupplementaryOffering> SupplementaryOffering;

      private String PaymentMode;

      public String getSubscriberKey() {
        return this.SubscriberKey;
      }

      public void setSubscriberKey(String SubscriberKey) {
        this.SubscriberKey = SubscriberKey;
      }

      public SubscriberInfo getSubscriberInfo() {
        return this.SubscriberInfo;
      }

      public void setSubscriberInfo(SubscriberInfo SubscriberInfo) {
        this.SubscriberInfo = SubscriberInfo;
      }

      public PrimaryOffering getPrimaryOffering() {
        return this.PrimaryOffering;
      }

      public void setPrimaryOffering(PrimaryOffering PrimaryOffering) {
        this.PrimaryOffering = PrimaryOffering;
      }

      public List<? extends SupplementaryOffering> getSupplementaryOffering() {
        return this.SupplementaryOffering;
      }

      public void setSupplementaryOffering(List<? extends SupplementaryOffering> SupplementaryOffering) {
        this.SupplementaryOffering = SupplementaryOffering;
      }

      public String getPaymentMode() {
        return this.PaymentMode;
      }

      public void setPaymentMode(String PaymentMode) {
        this.PaymentMode = PaymentMode;
      }

      public static class SubscriberInfo implements Serializable {
        private String Brand;

        private String SubClass;

        private String Status;

        private String ActiveTimeLimit;

        private String UserCustomerKey;

        private List<? extends SubIdentity> SubIdentity;

        private String ActivationTime;

        private String NetworkType;

        private String StatusDetail;

        private SubBasicInfo SubBasicInfo;

        private Account.AcctInfo.UserCustomer UserCustomer;

        private Customer.AddressInfo AddressInfo;

        public String getBrand() {
          return this.Brand;
        }

        public void setBrand(String Brand) {
          this.Brand = Brand;
        }

        public String getSubClass() {
          return this.SubClass;
        }

        public void setSubClass(String SubClass) {
          this.SubClass = SubClass;
        }

        public String getStatus() {
          return this.Status;
        }

        public void setStatus(String Status) {
          this.Status = Status;
        }

        public String getActiveTimeLimit() {
          return this.ActiveTimeLimit;
        }

        public void setActiveTimeLimit(String ActiveTimeLimit) {
          this.ActiveTimeLimit = ActiveTimeLimit;
        }

        public String getUserCustomerKey() {
          return this.UserCustomerKey;
        }

        public void setUserCustomerKey(String UserCustomerKey) {
          this.UserCustomerKey = UserCustomerKey;
        }

        public List<? extends SubIdentity> getSubIdentity() {
          return this.SubIdentity;
        }

        public void setSubIdentity(List<? extends SubIdentity> SubIdentity) {
          this.SubIdentity = SubIdentity;
        }

        public String getActivationTime() {
          return this.ActivationTime;
        }

        public void setActivationTime(String ActivationTime) {
          this.ActivationTime = ActivationTime;
        }

        public String getNetworkType() {
          return this.NetworkType;
        }

        public void setNetworkType(String NetworkType) {
          this.NetworkType = NetworkType;
        }

        public String getStatusDetail() {
          return this.StatusDetail;
        }

        public void setStatusDetail(String StatusDetail) {
          this.StatusDetail = StatusDetail;
        }

        public SubBasicInfo getSubBasicInfo() {
          return this.SubBasicInfo;
        }

        public void setSubBasicInfo(SubBasicInfo SubBasicInfo) {
          this.SubBasicInfo = SubBasicInfo;
        }

        public Account.AcctInfo.UserCustomer getUserCustomer() {
          return this.UserCustomer;
        }

        public void setUserCustomer(Account.AcctInfo.UserCustomer UserCustomer) {
          this.UserCustomer = UserCustomer;
        }

        public Customer.AddressInfo getAddressInfo() {
          return this.AddressInfo;
        }

        public void setAddressInfo(Customer.AddressInfo AddressInfo) {
          this.AddressInfo = AddressInfo;
        }

        public static class SubIdentity implements Serializable {
          private String PrimaryFlag;

          private String SubIdentity;

          private String SubIdentityType;

          public String getPrimaryFlag() {
            return this.PrimaryFlag;
          }

          public void setPrimaryFlag(String PrimaryFlag) {
            this.PrimaryFlag = PrimaryFlag;
          }

          public String getSubIdentity() {
            return this.SubIdentity;
          }

          public void setSubIdentity(String SubIdentity) {
            this.SubIdentity = SubIdentity;
          }

          public String getSubIdentityType() {
            return this.SubIdentityType;
          }

          public void setSubIdentityType(String SubIdentityType) {
            this.SubIdentityType = SubIdentityType;
          }
        }

        public static class SubBasicInfo implements Serializable {
          private String WrittenLang;

          private String DunningFlag;

          private List<? extends Account.AcctInfo.UserCustomer.IndividualInfo.IndividualProperty> SubProperty;

          private String IVRLang;

          public String getWrittenLang() {
            return this.WrittenLang;
          }

          public void setWrittenLang(String WrittenLang) {
            this.WrittenLang = WrittenLang;
          }

          public String getDunningFlag() {
            return this.DunningFlag;
          }

          public void setDunningFlag(String DunningFlag) {
            this.DunningFlag = DunningFlag;
          }

          public List<? extends Account.AcctInfo.UserCustomer.IndividualInfo.IndividualProperty> getSubProperty() {
            return this.SubProperty;
          }

          public void setSubProperty(List<? extends Account.AcctInfo.UserCustomer.IndividualInfo.IndividualProperty> SubProperty) {
            this.SubProperty = SubProperty;
          }

          public String getIVRLang() {
            return this.IVRLang;
          }

          public void setIVRLang(String IVRLang) {
            this.IVRLang = IVRLang;
          }
        }
      }

      public static class PrimaryOffering implements Serializable {
        private String Status;

        private String OfferingClass;

        private String TrialEndTime;

        private List<? extends ProductInst> ProductInst;

        private Account.OfferingInst.OfferingKey OfferingKey;

        private String BundledFlag;

        private String TrialStartTime;

        public String getStatus() {
          return this.Status;
        }

        public void setStatus(String Status) {
          this.Status = Status;
        }

        public String getOfferingClass() {
          return this.OfferingClass;
        }

        public void setOfferingClass(String OfferingClass) {
          this.OfferingClass = OfferingClass;
        }

        public String getTrialEndTime() {
          return this.TrialEndTime;
        }

        public void setTrialEndTime(String TrialEndTime) {
          this.TrialEndTime = TrialEndTime;
        }

        public List<? extends ProductInst> getProductInst() {
          return this.ProductInst;
        }

        public void setProductInst(List<? extends ProductInst> ProductInst) {
          this.ProductInst = ProductInst;
        }

        public Account.OfferingInst.OfferingKey getOfferingKey() {
          return this.OfferingKey;
        }

        public void setOfferingKey(Account.OfferingInst.OfferingKey OfferingKey) {
          this.OfferingKey = OfferingKey;
        }

        public String getBundledFlag() {
          return this.BundledFlag;
        }

        public void setBundledFlag(String BundledFlag) {
          this.BundledFlag = BundledFlag;
        }

        public String getTrialStartTime() {
          return this.TrialStartTime;
        }

        public void setTrialStartTime(String TrialStartTime) {
          this.TrialStartTime = TrialStartTime;
        }

        public static class ProductInst implements Serializable {
          private String PackageFlag;

          private String PrimaryFlag;

          private String NetworkType;

          private String ProductType;

          private String ProductID;

          public String getPackageFlag() {
            return this.PackageFlag;
          }

          public void setPackageFlag(String PackageFlag) {
            this.PackageFlag = PackageFlag;
          }

          public String getPrimaryFlag() {
            return this.PrimaryFlag;
          }

          public void setPrimaryFlag(String PrimaryFlag) {
            this.PrimaryFlag = PrimaryFlag;
          }

          public String getNetworkType() {
            return this.NetworkType;
          }

          public void setNetworkType(String NetworkType) {
            this.NetworkType = NetworkType;
          }

          public String getProductType() {
            return this.ProductType;
          }

          public void setProductType(String ProductType) {
            this.ProductType = ProductType;
          }

          public String getProductID() {
            return this.ProductID;
          }

          public void setProductID(String ProductID) {
            this.ProductID = ProductID;
          }
        }
      }

      public static class SupplementaryOffering implements Serializable {
        private String Status;

        private String ActiveTimeLimit;

        private String OfferingClass;

        private String EffectiveTime;

        private String ActivationTime;

        private String TrialEndTime;

        private PrimaryOffering.ProductInst ProductInst;

        private String ActivationMode;

        private Account.OfferingInst.OfferingKey OfferingKey;

        private String ExpirationTime;

        private String BundledFlag;

        private String TrialStartTime;

        public String getStatus() {
          return this.Status;
        }

        public void setStatus(String Status) {
          this.Status = Status;
        }

        public String getActiveTimeLimit() {
          return this.ActiveTimeLimit;
        }

        public void setActiveTimeLimit(String ActiveTimeLimit) {
          this.ActiveTimeLimit = ActiveTimeLimit;
        }

        public String getOfferingClass() {
          return this.OfferingClass;
        }

        public void setOfferingClass(String OfferingClass) {
          this.OfferingClass = OfferingClass;
        }

        public String getEffectiveTime() {
          return this.EffectiveTime;
        }

        public void setEffectiveTime(String EffectiveTime) {
          this.EffectiveTime = EffectiveTime;
        }

        public String getActivationTime() {
          return this.ActivationTime;
        }

        public void setActivationTime(String ActivationTime) {
          this.ActivationTime = ActivationTime;
        }

        public String getTrialEndTime() {
          return this.TrialEndTime;
        }

        public void setTrialEndTime(String TrialEndTime) {
          this.TrialEndTime = TrialEndTime;
        }

        public PrimaryOffering.ProductInst getProductInst() {
          return this.ProductInst;
        }

        public void setProductInst(PrimaryOffering.ProductInst ProductInst) {
          this.ProductInst = ProductInst;
        }

        public String getActivationMode() {
          return this.ActivationMode;
        }

        public void setActivationMode(String ActivationMode) {
          this.ActivationMode = ActivationMode;
        }

        public Account.OfferingInst.OfferingKey getOfferingKey() {
          return this.OfferingKey;
        }

        public void setOfferingKey(Account.OfferingInst.OfferingKey OfferingKey) {
          this.OfferingKey = OfferingKey;
        }

        public String getExpirationTime() {
          return this.ExpirationTime;
        }

        public void setExpirationTime(String ExpirationTime) {
          this.ExpirationTime = ExpirationTime;
        }

        public String getBundledFlag() {
          return this.BundledFlag;
        }

        public void setBundledFlag(String BundledFlag) {
          this.BundledFlag = BundledFlag;
        }

        public String getTrialStartTime() {
          return this.TrialStartTime;
        }

        public void setTrialStartTime(String TrialStartTime) {
          this.TrialStartTime = TrialStartTime;
        }
      }
    }
  }
}
