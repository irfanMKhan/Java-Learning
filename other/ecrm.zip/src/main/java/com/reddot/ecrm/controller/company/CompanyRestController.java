package com.reddot.ecrm.controller.company;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.entity.company.dto.CompanyAddReqDTO;
import com.reddot.ecrm.entity.company.dto.CompanySearchReqDTO;
import com.reddot.ecrm.entity.lead.settings.NumberOfEmployees;
import com.reddot.ecrm.entity.lead.settings.SubIndustry;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.repository.lead.settings.NumberOfEmployeesRepository;
import com.reddot.ecrm.repository.lead.settings.SubIndustryRepository;
import com.reddot.ecrm.service.company.CompanyService;
import com.reddot.ecrm.service.company.CompanyTempService;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping(method = RequestMethod.GET, value = "/api/company")
public class CompanyRestController {
    @Autowired
    private CompanyTempService companyTempService;

    @Autowired
    private CompanyService companyService;

    @Autowired
    private SubIndustryRepository subIndustryRepository;

    @Autowired
    private NumberOfEmployeesRepository numberOfEmployeesRepository;

    @PostMapping("/DTData")
    public DataTablesOutput<CompanyEntity> DTData(@RequestBody Map<String, Object> data) throws JsonProcessingException {
        DataTablesInput input = new Gson().fromJson(Utility.ObjectToJson(data.get("dtInput")), new TypeToken<DataTablesInput>() {
        }.getType());

        ObjectMapper mapper = new ObjectMapper();
        CompanySearchReqDTO searchReqDTO = mapper.readValue(data.get("searchData").toString(), CompanySearchReqDTO.class);

        return companyService.DTData(input, searchReqDTO);
    }

//    @PostMapping("/checkName")
//    public CommonRestResponse checkDuplicateName(@RequestBody String name){
//        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error occurred! Please try again", null);
//        Optional<CompanyEntity> companyEntity = companyService.findCompanyByName(name);
//        if(companyEntity.isPresent()){
//            commonRestResponse.setCode(302);
//            commonRestResponse.setMessage("Company with this name already exists");
//        }
//        else {
//            commonRestResponse.setCode(200);
//            commonRestResponse.setMessage("OK");
//        }
//        return commonRestResponse;
//    }

    @GetMapping("/findByKam")
    public CommonRestResponse findByKam(@RequestParam(name = "KAM", required = true) String kam_name) {
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error occurred! Please try again", null);
        List<CompanyEntity> companyList = companyService.findCompanyByKam(kam_name);
        if (companyList.size() > 0) {
            commonRestResponse.setCode(200);
            commonRestResponse.setMessage("List of companies by KAM");
            commonRestResponse.setData(companyList);
        } else {
            commonRestResponse.setCode(HttpStatus.NOT_FOUND.value());
            commonRestResponse.setMessage("No company found!");
            commonRestResponse.setData(companyList);
        }
        return commonRestResponse;
    }

    @PostMapping("/findByName")
    public CommonRestResponse findByName(@RequestBody(required = false) String name) {
        if (name == null) {
            return new CommonRestResponse(200, "Empty name entered", null);
        }
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error occurred! Please try again", null);
        Optional<CompanyEntity> companyEntity = companyService.findCompanyByName(name);
        try {
            if (companyEntity.isPresent()) {
                commonRestResponse.setCode(200);
                commonRestResponse.setMessage("Company with name: " + name + " already exists!");
                commonRestResponse.setData(companyEntity.get());
            } else {
                commonRestResponse.setCode(404);
                commonRestResponse.setMessage("Company Not Found");
                commonRestResponse.setData(companyEntity.get());
            }
        } catch (Exception e) {
            commonRestResponse.setData(e.getMessage());
        }
        return commonRestResponse;
    }

    @PostMapping("/get")
    public CommonRestResponse getCompanyDetailsById(@RequestBody String id, HttpServletRequest request) {
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error occurred! Please try again!", null);
        CompanyEntity companyEntity = companyService.getCompanyById(id);
        if (companyEntity != null) {
            commonRestResponse.setCode(200);
            commonRestResponse.setMessage("Company found!");
            commonRestResponse.setData(companyEntity);
        } else {
            commonRestResponse.setCode(404);
            commonRestResponse.setMessage("Company not found!");
        }
        return commonRestResponse;
    }

    @PostMapping("/get/companyName")
    public CommonRestResponse getCompanyDetailsByCompanyName(@RequestBody String companyName, HttpServletRequest request) {
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error occurred! Please try again!", null);
        CompanyEntity companyEntity = companyService.getCompanyDetailsByCompanyName(companyName);
        if (companyEntity != null) {
            commonRestResponse.setCode(200);
            commonRestResponse.setMessage("Company found!");
            commonRestResponse.setData(companyEntity);
        } else {
            commonRestResponse.setCode(404);
            commonRestResponse.setMessage("Company not found!");
        }
        return commonRestResponse;
    }

    @PostMapping("/add")
    public CommonRestResponse addCompanyFunction(HttpServletRequest request, @RequestBody CompanyAddReqDTO companyAddReqDTO) {
        return companyTempService.addCompanyFunction(request, companyAddReqDTO);
    }

    @GetMapping("/allSubindustries")
    public List<SubIndustry> getAllSubIndustries() {
        return subIndustryRepository.findAll();
    }

    @GetMapping("/allNumberOfEmployees")
    public List<NumberOfEmployees> getAllNumberOfEmployees() {
        return numberOfEmployeesRepository.findAll();
    }

}