package com.reddot.ecrm.dto.agreement.pbx;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PbxDTO {
    private String contractNumber;
    //basic info
    private String addressWithDate;
    private String agentName;
    private String id;
    private String contractPersonAndPosition;
    private String headOfEnterpriseName;

    private String termsConditionDate;

    //address fields
    private String addressNo;
    private String street;
    private String sangkat;
    private String khan;
    private String city;
    private String country;

    private String contractNo;
    private String phoneNumber;
    private String emailAddress;
    private String invoiceDeliveryMethod;
    private String image;

    //first person in charge fields
    private String firstPersonInChargeContactName;
    private String firstPersonInChargePosition;
    private String firstPersonInChargePhoneNumber;
    private String firstPersonInChargeEmail;

    //second person in charge fields
    private String secondPersonInChargeContactName;
    private String secondPersonInChargePosition;
    private String secondPersonPhoneNumber;
    private String secondPersonInChargeEmail;

    //patient info
    private String patientDocNumber;
    private String patientDateOfIssue;
    //MOC info
    private String mocDocNumber;
    private String mocDateOfIssue;

    private String contactDetailOne;
    private String contactDetailTwo;
    private String contactDetailThree;


    private String subscriberName;
    private String subscriberPosition;
    private String subscriberDate;


    private String uniqueNumber;
    private String templateName;
}
