package com.reddot.ecrm.api.payload.response.subscriber;

import lombok.Data;

import java.io.Serializable;
import java.lang.Integer;
import java.lang.String;

@Data
public class ReportLostErrorResponse implements Serializable {
  private String variables;

  private Integer code;

  private String message;
}
