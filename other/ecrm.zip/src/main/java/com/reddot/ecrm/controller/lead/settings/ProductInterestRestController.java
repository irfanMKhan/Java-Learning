package com.reddot.ecrm.controller.lead.settings;

import com.reddot.ecrm.dto.lead.settings.ProductInterestDto;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.lead.settings.ProductInterestService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequestMapping("lead/productInterest")
public class ProductInterestRestController {
    
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    
    @Autowired
    private ProductInterestService productInterestService;
    
    @GetMapping("/dt/all")
    public DataTablesOutput<ProductInterestDto> dtProductInterest(@Valid DataTablesInput input,
                                                                HttpServletRequest request,
                                                     @RequestParam(value = "searchText", required = false) String searchText, @RequestParam(value = "searchCol", required = false) String searchCol) {
        return productInterestService.getDTProductInterest(input, request, searchText, searchCol);
    }
    
    @PostMapping("/add")
    public CommonRestResponse addProductInterest(HttpServletRequest request, @RequestBody ProductInterestDto productInterestDto) {
        return productInterestService.addProductInterest(request, productInterestDto);
    }
    
    @GetMapping("/details")
    public CommonRestResponse getProductInterestById(@RequestParam("id") Long id) {
        return productInterestService.getProductInterestById(id);
    }
    
    @PostMapping("/update")
    public CommonRestResponse updateProductInterest(HttpServletRequest request,
                                               @RequestBody ProductInterestDto productInterestDto) {
        return productInterestService.updateProductInterest(request, productInterestDto);
    }
    
}