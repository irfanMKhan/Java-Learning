package com.reddot.ecrm.dto.agreement.simOrMobile;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SimOrMobileHtmlTemplateDTO {
    private String contractNo;
    private String companyPhoneNumber;
    private String companyEmail;
    private String contractDate;
    private String companyName;
    private String companyAddress;


    private String primaryContactPersonName;
    private String primaryContactPersonEmail;
    private String primaryContactPersonPhone;
    private String primaryContactPersonPosition;

    private String billingContactPersonName;
    private String billingContactPersonEmail;
    private String billingContactPersonPhone;
    private String billingContactPersonPosition;



}
