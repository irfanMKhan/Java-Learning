package com.reddot.ecrm.dto.account;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AddMasterAccountDTO {
    private Long companyId;
    private String serviceTypeName;
    private String accountName;
    private String branchName;
    private String billMediumId;
    private String billMediumCodeApiValue;
    private String billContentTypeApiValue;
    private String billMediumInfo;
    private Long picId;
    private String picEmail;
    private String picName;
    private String picPersonTypeMobile;
    private String picPersonType;
    private String picPersonTypeText;
}
