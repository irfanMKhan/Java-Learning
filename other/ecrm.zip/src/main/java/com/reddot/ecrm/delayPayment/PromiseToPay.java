package com.reddot.ecrm.delayPayment;

import lombok.*;

import javax.persistence.*;

@Entity
@Table(name = "tbl_promise_to_pay", schema = "ecrm")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class PromiseToPay {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "account_code")
    private String accountCode;
    @Column(name = "trans_type")
    private String transType;

    @Column(name = "transaction_id")
    private String transactionId;
    @Column(name = "primary_identity")
    private String primaryIdentity;

//    @Column(name = "agreed_paid_date")
//    private String agreedPaidDate;
//    @Column(name = "agreed_paid_amt")
//    private String agreedPaidAmt;
}
