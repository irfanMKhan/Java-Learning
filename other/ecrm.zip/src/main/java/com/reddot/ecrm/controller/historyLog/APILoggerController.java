package com.reddot.ecrm.controller.historyLog;

import com.reddot.ecrm.menu.MenuViewer;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;

@RequestMapping(value = "/log/apiLogger", method = RequestMethod.GET)
@RequiredArgsConstructor
@Controller
public class APILoggerController {

    @GetMapping("")
    public String viewHistoryLog() {
        return "redirect:/log/apiLogger/list";
    }

    @GetMapping("/list")
    String viewHistoryLogList(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "API Log");
        return "log_view/api_logger";
    }
}
