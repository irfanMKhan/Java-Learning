package com.reddot.ecrm.api.payload.response.transferOwnership;

import lombok.Data;

import java.io.Serializable;

@Data

public class QueryCDRDetailResponse implements Serializable {
    private QueryCDRResult QueryCDRResult;

    @Data
    public class QueryCDRResult implements Serializable {


        private String TotalCDRNum;
        private String BeginRowNum;
        private String FetchRowNum;
    }
}
