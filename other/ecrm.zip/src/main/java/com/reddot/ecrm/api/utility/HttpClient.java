package com.reddot.ecrm.api.utility;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.Map;


@Slf4j
@Service
@RequiredArgsConstructor
public class HttpClient {

    private final OkHttpClient client;

    public Response post(String json, String url, Map<String, String> headers) throws Exception {

        RequestBody body = RequestBody.create(json, MediaType.parse("application/json"));

        Request request = new Request.Builder()
                .url(url)
                .headers(Headers.of(headers))
                .post(body)
                .build();

        return client.newCall(request).execute();
    }

    public Response patch(String json, String url, Map<String, String> headers) throws Exception {

        RequestBody body = RequestBody.create(json, MediaType.parse("application/json"));

        Request request = new Request.Builder()
                .url(url)
                .headers(Headers.of(headers))
                .patch(body)
                .build();

        return client.newCall(request).execute();
    }

    public Response post(String url, Map<String, String> headers) throws Exception {
        RequestBody body = RequestBody.create(new byte[0], MediaType.parse("null"));

        Request request = new Request.Builder()
                .url(url)
                .headers(Headers.of(headers))
                .post(body)
                .build();

        return client.newCall(request).execute();
    }

    public Response post(RequestBody formBody, String url, Map<String, String> headers) throws Exception {

        Request request = new Request.Builder()
                .url(url)
                .headers(Headers.of(headers))
                .post(formBody)
                .build();

        return client.newCall(request).execute();
    }

    public Response put(String url, Map<String, String> headers) throws Exception {
        RequestBody body = RequestBody.create(new byte[0],
                MediaType.parse("null"));

        Request request = new Request.Builder()
                .url(url)
                .headers(Headers.of(headers))
                .put(body)
                .build();

        return client.newCall(request).execute();
    }

    public Response put(String json, String url, Map<String, String> headers) throws Exception {

        RequestBody body = RequestBody.create(json.getBytes(StandardCharsets.UTF_8), MediaType.parse("application/json"));

        Request request = new Request.Builder()
                .url(url)
                .headers(Headers.of(headers))
                .put(body)
                .build();

        return client.newCall(request).execute();
    }

    public Response get(String url, Map<String, String> headers) throws Exception {

        Request request = new Request.Builder()
                .url(url)
                .headers(Headers.of(headers))
                .build();

        return client.newCall(request).execute();
    }

    public Response delete(String url, Map<String, String> headers) throws Exception {

        Request request = new Request.Builder()
                .url(url)
                .headers(Headers.of(headers))
                .header("Content-Type", "")
                .delete()
                .build();

        return client.newCall(request).execute();
    }
}
