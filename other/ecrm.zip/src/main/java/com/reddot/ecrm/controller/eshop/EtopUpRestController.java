package com.reddot.ecrm.controller.eshop;

import com.reddot.ecrm.entity.eshop.EtopUp;
import com.reddot.ecrm.service.eshop.EtopUpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.security.Principal;

@RestController
@RequestMapping("/crm/eShop")
public class EtopUpRestController {

    @Autowired
    private EtopUpService eTopUpService;

    @GetMapping("/dataTable/eTopUpData")
    public DataTablesOutput<EtopUp> eTopUpData(@Valid DataTablesInput input, HttpServletRequest request, @RequestParam(value = "searchText", required = false) String searchText, @RequestParam(value = "searchCol", required = false) String searchCol, @RequestParam(value = "purchaseNo", required = false) String purchaseNo) {
        return eTopUpService.getDataTableETopUpData(input, request, searchText, searchCol, purchaseNo);
    }


    @PostMapping("/addETopUp")
    public String addETopUp(HttpServletRequest request, @RequestBody EtopUp etopUp) {
        return eTopUpService.addETopUp(request, etopUp);
    }

    @GetMapping(value = "/deleteETopUpData")
    public String deleteETopUpData(ModelMap model, HttpServletRequest request, Principal principal, @RequestParam(value = "id", required = false) Long id) {
        return eTopUpService.deleteETopUpDataById(id);
    }
}
