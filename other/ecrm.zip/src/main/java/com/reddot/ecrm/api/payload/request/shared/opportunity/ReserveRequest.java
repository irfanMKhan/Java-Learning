package com.reddot.ecrm.api.payload.request.shared.opportunity;

import lombok.Data;

import java.io.Serializable;
import java.lang.Integer;
import java.lang.String;

@Data
public class ReserveRequest implements Serializable {
  private Metadata metadata;

  private String correlation_id;

  private Reservation reservation;

  @Data
  public static class Metadata implements Serializable {
    private Integer store_id;

    private Integer channel_id;
  }

  @Data
  public static class Reservation implements Serializable {
    private String description;

    private String release_time;
  }
}
