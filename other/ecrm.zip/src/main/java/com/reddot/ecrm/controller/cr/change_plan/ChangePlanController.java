package com.reddot.ecrm.controller.cr.change_plan;

import com.reddot.ecrm.entity.approval.ApprovalLogDetailsEntity;
import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.entity.cr.CRMasterEntity;
import com.reddot.ecrm.enum_config.cr.add_new_number.PaymentTerm;
import com.reddot.ecrm.enum_config.cr.add_new_number.ReservationStatus;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.repository.approval.ApprovalLogDetailsRepo;
import com.reddot.ecrm.repository.company.CompanyRepository;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/cr/changePlan")
public class ChangePlanController {
    @Autowired
    CompanyRepository companyRepository;

    @Autowired
    com.reddot.ecrm.repository.cr.CRDetailsRepo CRDetailsRepo;

    @Autowired
    ApprovalLogDetailsRepo logDetailsRepo;

    @Value("${app.base_url}")
    private String baseUrl;

    @GetMapping("/summary")
    public String viewPageSummary(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        ReservationStatus[] reservationStatus = ReservationStatus.values();
        PaymentTerm[] paymentTerms = PaymentTerm.values();

        List<CompanyEntity> companyEntityList = companyRepository.findAllByActiveAndContractStatus(true, 2);

        model.put("reservation_status", reservationStatus);
        model.put("payment_terms", paymentTerms);
        model.put("company_list", companyEntityList);
        model.addAttribute("breadcrumb", "Change Plan Summary");
        model.put("title", "Change Plan Summary");
        model.put("baseUrl", baseUrl);
        return "cr/change_plan/change_plan_summary";
    }

    @GetMapping("/summary/singleCRPlan")
    public String viewPageSingleSummary(@RequestParam("id") Long id, ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        Optional<CRMasterEntity> crMasterOptional = CRDetailsRepo.findById(id);
        if (crMasterOptional.isPresent()) {
            List<ApprovalLogDetailsEntity> logDetailsEntityList = logDetailsRepo.findAllByRequestDetailsIdAndIsActiveOrderByIdDesc(
                    crMasterOptional.get().getId(), true);
            model.put("logDetailsList", logDetailsEntityList);
        } else {
            model.put("logDetailsList", new ArrayList<>());
        }

        model.addAttribute("breadcrumb", "Change Plan Summary");
        model.put("title", "Change Plan Summary Details");
        model.put("baseUrl", baseUrl);
        return "cr/change_plan/change_plan_single_summary";
    }


    @GetMapping
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        ReservationStatus[] reservationStatus = ReservationStatus.values();
        PaymentTerm[] paymentTerms = PaymentTerm.values();

        List<CompanyEntity> companyList = companyRepository.findAllByActiveAndContractStatus(true, 2);

        Boolean isPIC = false;
        MDUserModel mdUserModel = Utility.CheckPICAndReturnUserDetails(request);
        Long companyId = null;
        String companyName = null;

        if (mdUserModel != null) {
            isPIC = true;
            companyId = mdUserModel.getCOMPANY_ID();
            companyName = mdUserModel.getCOMPANY_NAME();
        }

        model.addAttribute("breadcrumb", "Change Plan Summary");
        model.put("reservation_status", reservationStatus);
        model.put("payment_terms", paymentTerms);
        model.put("company_list", companyList);
        model.put("title", "Change Plan");
        model.put("isPIC", isPIC);
        model.put("companyId", companyId);
        model.put("companyName", companyName);
        model.put("baseUrl", baseUrl);

        return "cr/change_plan/change_plan";
    }

}
