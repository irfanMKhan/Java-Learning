package com.reddot.ecrm.controller.sr.ticket;

import lombok.Data;

@Data
public class RemoveFileDTO {
    private String attachmentId;
    private String ticketNumber;
}
