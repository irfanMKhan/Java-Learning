package com.reddot.ecrm.dto.cr.change_branch;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChangeBranchDTO {
    private String custId;
    private String companyId;
    private List<ChangeGroupList> changeGroupList;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ChangeGroupList {
        private String msisdn;
        private String departmentID;
        private String departmentName;
        private String newDepartmentID;
        private String newDepartmentName;
        private String accountPrimaryId;
        private String newAccountPrimaryId;
        private String effectiveDate;
    }
}
