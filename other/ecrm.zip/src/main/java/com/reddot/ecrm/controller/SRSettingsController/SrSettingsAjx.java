package com.reddot.ecrm.controller.SRSettingsController;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.dto.GlobalSettings.AccountClass.MDAccountClassModel;
import com.reddot.ecrm.dto.GlobalSettings.AccountType.MDAccountTypeModel;
import com.reddot.ecrm.dto.GlobalSettings.User.MDUserModel;
import com.reddot.ecrm.dto.GlobalSettings.UserGroup.MDUserGroupModel;
import com.reddot.ecrm.dto.srsettings.ActType.MDSrActTypeModel;
import com.reddot.ecrm.dto.srsettings.ActType.QueryMDSrActTypeModel;
import com.reddot.ecrm.dto.srsettings.ActionType.MDSrActionTypeModel;
import com.reddot.ecrm.dto.srsettings.ActionType.QueryMDSrActionTypeModel;
import com.reddot.ecrm.dto.srsettings.AnsType.MDSrAnsTypeModel;
import com.reddot.ecrm.dto.srsettings.AnsType.QueryMDSrAnsTypeModel;
import com.reddot.ecrm.dto.srsettings.Area.MDSrAreaModel;
import com.reddot.ecrm.dto.srsettings.Area.QueryMDSrAreaModel;
import com.reddot.ecrm.dto.srsettings.Priority.MDSrPriorityModel;
import com.reddot.ecrm.dto.srsettings.Priority.QueryMDSrPriorityModel;
import com.reddot.ecrm.dto.srsettings.QuesMgt.*;
import com.reddot.ecrm.dto.srsettings.RootCause.MDSrRootCauseModel;
import com.reddot.ecrm.dto.srsettings.RootCause.QueryMDSrRootCauseModel;
import com.reddot.ecrm.dto.srsettings.RoutingGroup.SRRoutingGroupModel;
import com.reddot.ecrm.dto.srsettings.SRConfigAjxModel;
import com.reddot.ecrm.dto.srsettings.ServiceType.MDSrServiceTypeModel;
import com.reddot.ecrm.dto.srsettings.ServiceType.QueryMDSrServiceTypeModel;
import com.reddot.ecrm.dto.srsettings.Severity.MDSrSeverityModel;
import com.reddot.ecrm.dto.srsettings.Severity.QueryMDSrSeverityModel;
import com.reddot.ecrm.dto.srsettings.Status.MDSrStatusModel;
import com.reddot.ecrm.dto.srsettings.Status.QueryMDSrStatusModel;
import com.reddot.ecrm.dto.srsettings.TBLDataShowModel;
import com.reddot.ecrm.dto.srsettings.Type.QueryMDSrTypeModel;
import com.reddot.ecrm.dto.srsettings.Type.SRTypeModel;
import com.reddot.ecrm.dto.srsettings.subarea.*;
import com.reddot.ecrm.exporter.fileExport.GenerateCSV;
import com.reddot.ecrm.exporter.fileExport.GenerateExcel;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.repository.SrTypeRepository;
import com.reddot.ecrm.repository.redisrepo.srsettings.RedisDBSrSettings;
import com.reddot.ecrm.util.QueryBuilder;
import com.reddot.ecrm.util.Utility;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.lang.Integer.parseInt;


@RestController
public class SrSettingsAjx {
    private final Logger logger = LoggerFactory.getLogger("SRSettingsLogger");

    @Autowired
    private SrTypeRepository srtypeDAO;

    @Autowired
    private CommonRepository commonDAO;

    @Autowired
    private RedisDBSrSettings redisDBSrSettings;

    @RequestMapping(value = "/getServiceTypeList", method = RequestMethod.POST)
    public QueryMDSrServiceTypeModel getServiceTypeList(HttpServletRequest request, @RequestParam("searchType") String searchType, @RequestParam("searchKey") String searchKey) {
        QueryMDSrServiceTypeModel empList = new QueryMDSrServiceTypeModel();
        try {
            int cpage = 1;
            String cm = request.getParameter("cpage");
            String sortName = request.getParameter("sortName");
            String sortColName = request.getParameter("sortColName");

            if (sortName == null) {
                sortName = "ASC";
            }
            if (sortColName == null) {
                sortColName = "ID";
            }

            if (cm == null || cm.equals("0")) {
                cpage = 1;
            } else {
                cpage = parseInt(request.getParameter("cpage"));
            }

            String perPageValue = request.getParameter("parPage");
            int perPage = perPageValue != "" ? parseInt(perPageValue) : Utility.perPageDataLoad;

            int EndPage = (cpage * perPage);
            int StartPage = (EndPage - perPage);
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }


            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_sr_service_type, SearchData, whereSearchType);
            logger.info(iiQStr);
            int ii = commonDAO.CommoNumberOfRow(iiQStr);

            String iQStr = QueryBuilder.getWherQueryPagination(Utility.md_sr_service_type, SearchData, StartPage, perPage, whereSearchType);
            logger.info(iQStr);
            Object i = commonDAO.getDataPaginationPostgres(iQStr);

            List<MDSrServiceTypeModel> resList = new Gson().fromJson(Utility.ObjectToJson(i), new TypeToken<List<MDSrServiceTypeModel>>() {
            }.getType());
            empList = new QueryMDSrServiceTypeModel(new TBLDataShowModel(ii, perPage, StartPage, EndPage), resList);

        } catch (Exception ee) {
            //System.out.print(ee.toString());
            logger.error(ee.getMessage());
        }
        return empList;
    }


    @RequestMapping(value = "/getServiceTypeListCsv", method = RequestMethod.GET)
    public void getServiceTypeListCsv(HttpServletResponse response, HttpServletRequest request) {
        try {
            List<MDSrServiceTypeModel> ListTotal = null;

            String searchType = request.getParameter("searchType");
            String searchKey = request.getParameter("searchKey");
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }

            String filename = "Service Type.csv";
            response.setContentType("text/csv");
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");

            String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_service_type, SearchData, whereSearchType);
            logger.info(iiQStr);
            Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
            ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrServiceTypeModel>>() {
            }.getType());
            GenerateCSV.serviceType(response.getWriter(), ListTotal);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }


    @GetMapping("/getServiceTypeListXls")
    public void getServiceTypeListXls(HttpServletResponse response, HttpServletRequest request) throws IOException {
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=Service Type.xlsx");

        List<MDSrServiceTypeModel> ListTotal = null;

        String searchType = request.getParameter("searchType");
        String searchKey = request.getParameter("searchKey");
        Map<String, Object> SearchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();

        if (!searchType.isEmpty() && !searchKey.isEmpty()) {
            if (searchType.toUpperCase().equals("ACTIVE")) {
                searchKey = Utility.getStatusID_str(searchKey);
                whereSearchType.put(searchType, "AND");
            } else {
                whereSearchType.put(searchType, "LIKE");
            }
            SearchData.put(searchType, searchKey);

        }

        String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_service_type, SearchData, whereSearchType);
        logger.info(iiQStr);
        Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
        ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrServiceTypeModel>>() {
        }.getType());

        ByteArrayInputStream stream = GenerateExcel.serviceType(ListTotal);
        IOUtils.copy(stream, response.getOutputStream());
    }


    @RequestMapping(value = "/getTypeList", method = RequestMethod.POST)
    public QueryMDSrTypeModel getSRType(HttpServletRequest request, @RequestParam("searchType") String searchType, @RequestParam("searchKey") String searchKey) {
        QueryMDSrTypeModel empList = new QueryMDSrTypeModel();
        try {
            int cpage = 1;
            String cm = request.getParameter("cpage");
            String sortName = request.getParameter("sortName");
            String sortColName = request.getParameter("sortColName");

            if (sortName == null) {
                sortName = "ASC";
            }
            if (sortColName == null) {
                sortColName = "ID";
            }

            if (cm == null || cm.equals("0")) {
                cpage = 1;
            } else {
                cpage = parseInt(request.getParameter("cpage"));
            }

            String perPageValue = request.getParameter("parPage");
            int perPage = perPageValue != "" ? parseInt(perPageValue) : Utility.perPageDataLoad;

            int EndPage = (cpage * perPage);
            int StartPage = (EndPage - perPage);
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }


            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_sr_type, SearchData, whereSearchType);
            logger.info(iiQStr);
            int ii = commonDAO.CommoNumberOfRow(iiQStr);

            String iQStr = QueryBuilder.getWherQueryPagination(Utility.md_sr_type, SearchData, StartPage, perPage, whereSearchType);
            logger.info(iQStr);
            Object i = commonDAO.getDataPaginationPostgres(iQStr);

            List<SRTypeModel> resList = new Gson().fromJson(Utility.ObjectToJson(i), new TypeToken<List<SRTypeModel>>() {
            }.getType());
            empList = new QueryMDSrTypeModel(new TBLDataShowModel(ii, perPage, StartPage, EndPage), resList);

        } catch (Exception ee) {
            //System.out.print(ee.toString());
            logger.error(ee.getMessage());
        }
        return empList;
    }


    @RequestMapping(value = "/getTypeListCsv", method = RequestMethod.GET)
    public void getTypeListCsv(HttpServletResponse response, HttpServletRequest request) {
        try {
            List<SRTypeModel> ListTotal = null;

            String searchType = request.getParameter("searchType");
            String searchKey = request.getParameter("searchKey");
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }


            String filename = "SR Type List.csv";
            response.setContentType("text/csv");
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");

            String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_type, SearchData, whereSearchType);
            logger.info(iiQStr);
            Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
            ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<SRTypeModel>>() {
            }.getType());
            GenerateCSV.type(response.getWriter(), ListTotal);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

    @GetMapping("/getTypeListXls")
    public void getTypeListXls(HttpServletResponse response, HttpServletRequest request) throws IOException {
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=SR Type List.xlsx");

        List<SRTypeModel> ListTotal = null;

        String searchType = request.getParameter("searchType");
        String searchKey = request.getParameter("searchKey");
        Map<String, Object> SearchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();

        if (!searchType.isEmpty() && !searchKey.isEmpty()) {
            if (searchType.toUpperCase().equals("ACTIVE")) {
                searchKey = Utility.getStatusID_str(searchKey);
                whereSearchType.put(searchType, "AND");
            } else {
                whereSearchType.put(searchType, "LIKE");
            }
            SearchData.put(searchType, searchKey);

        }

        String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_type, SearchData, whereSearchType);
        logger.info(iiQStr);
        Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
        ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<SRTypeModel>>() {
        }.getType());

        ByteArrayInputStream stream = GenerateExcel.type(ListTotal);
        IOUtils.copy(stream, response.getOutputStream());
    }

    @RequestMapping(value = "/srTypeForServiceType", method = RequestMethod.POST)
    public List<SRTypeModel> getSRTypeForServiceType(@RequestParam("serviceType") String serviceType) {
        logger.info("Inside getSRTypeForServiceType");
        List<SRTypeModel> srTypeModels = new ArrayList<>();
        try {
            String[] parts = serviceType.split("/");

            Map<String, Object> SrTypeData = new HashMap<>();
            Map<String, Object> whereSearchType = new HashMap<>();
            SrTypeData.put("SR_SERVICE_TYPE_ID", parts[0]);
            whereSearchType.put("SR_SERVICE_TYPE_ID", "AND");
            SrTypeData.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");

            String qry_fetch = QueryBuilder.getSelectWhereQuery(Utility.md_sr_type, SrTypeData, whereSearchType);
            logger.info(qry_fetch);
            Object srSrTypeList = commonDAO.getDataPostgres(qry_fetch);

            srTypeModels = new Gson().fromJson(Utility.ObjectToJson(srSrTypeList), new TypeToken<List<SRTypeModel>>() {
            }.getType());

//            Object srSrTypeList = redisDBSrSettings.getSRTypeByServiceTypeId(Integer.parseInt(parts[0]), 1);
//            srTypeModels = new Gson().fromJson(Utility.ObjectToJson(srSrTypeList), new TypeToken<List<SRTypeModel>>() {
//            }.getType());

        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        logger.info("Returning from getSRTypeForServiceType with data: " + srTypeModels.size());
        return srTypeModels;
    }

    /*******************************  Area : start ********************************************/

    @RequestMapping(value = "/srAreaForSRType", method = RequestMethod.POST)
    public List<MDSrAreaModel> getSrAreaForSRType(@RequestParam("srType") String srType) {
        logger.info("Inside getSrAreaForSRType");
        List<MDSrAreaModel> mdSrAreaModels = new ArrayList<>();
        try {
            String[] parts = srType.split("/");

			Map<String,Object> searchMap = new HashMap<String, Object>();
			Map<String,Object> whereSearchType = new HashMap<String, Object>();
			searchMap.put("SR_TYPE_ID",parts[0]);
			whereSearchType.put("SR_TYPE_ID","AND");
			searchMap.put("ACTIVE","1");
			whereSearchType.put("ACTIVE","AND");

			Object srAreaList = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereQuery(Utility.md_sr_area, searchMap, whereSearchType));
			mdSrAreaModels = new Gson().fromJson(Utility.ObjectToJson(srAreaList), new TypeToken<List<MDSrAreaModel>>() { }.getType());

//            Object objects = redisDBSrSettings.getMDSrAreaBySrTypeId(Integer.parseInt(parts[0]), 1);
//            mdSrAreaModels = new Gson().fromJson(Utility.ObjectToJson(objects), new TypeToken<List<MDSrAreaModel>>() {
//            }.getType());

        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
        logger.info("Returning from getSrAreaForSRType with data: " + mdSrAreaModels.size());
        return mdSrAreaModels;
    }


    @RequestMapping(value = "/get_sr_area_list", method = RequestMethod.POST)
    public QueryMDSrAreaModel getSRAreaList(HttpServletRequest request, @RequestParam("searchType") String searchType, @RequestParam("searchKey") String searchKey) {
        QueryMDSrAreaModel empList = new QueryMDSrAreaModel();
        try {
            int cpage = 1;
            String cm = request.getParameter("cpage");
            String sortName = request.getParameter("sortName");
            String sortColName = request.getParameter("sortColName");

            if (sortName == null) {
                sortName = "ASC";
            }
            if (sortColName == null) {
                sortColName = "ID";
            }

            if (cm == null || cm.equals("0")) {
                cpage = 1;
            } else {
                cpage = parseInt(request.getParameter("cpage"));
            }

            String perPageValue = request.getParameter("parPage");
            int perPage = perPageValue != "" ? parseInt(perPageValue) : Utility.perPageDataLoad;

            int EndPage = (cpage * perPage);
            int StartPage = (EndPage - perPage);
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }


            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_sr_area, SearchData, whereSearchType);
            logger.info(iiQStr);
            int ii = commonDAO.CommoNumberOfRow(iiQStr);

            String iQStr = QueryBuilder.getWherQueryPagination(Utility.md_sr_area, SearchData, StartPage, perPage, whereSearchType);
            logger.info(iQStr);
            Object i = commonDAO.getDataPaginationPostgres(iQStr);

            List<MDSrAreaModel> resList = new Gson().fromJson(Utility.ObjectToJson(i), new TypeToken<List<MDSrAreaModel>>() {
            }.getType());
            empList = new QueryMDSrAreaModel(new TBLDataShowModel(ii, perPage, StartPage, EndPage), resList);

        } catch (Exception ee) {
            //System.out.print(ee.toString());
            logger.error(ee.getMessage());
        }
        return empList;
    }


    @RequestMapping(value = "/get_sr_area_csv", method = RequestMethod.GET)
    public void getSRAreaCsv(HttpServletResponse response, HttpServletRequest request) {
        try {
            List<MDSrAreaModel> ListTotal = null;

            String searchType = request.getParameter("searchType");
            String searchKey = request.getParameter("searchKey");
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }


            String filename = "SR Area List.csv";
            response.setContentType("text/csv");
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");

            String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_area, SearchData, whereSearchType);
            logger.info(iiQStr);
            Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
            ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrAreaModel>>() {
            }.getType());
            GenerateCSV.srArea(response.getWriter(), ListTotal);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

    @GetMapping("/get_sr_area_xls")
    public void getSRAreaXls(HttpServletResponse response, HttpServletRequest request) throws IOException {
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=SR Area List.xlsx");

        List<MDSrAreaModel> ListTotal = null;

        String searchType = request.getParameter("searchType");
        String searchKey = request.getParameter("searchKey");
        Map<String, Object> SearchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();

        if (!searchType.isEmpty() && !searchKey.isEmpty()) {
            if (searchType.toUpperCase().equals("ACTIVE")) {
                searchKey = Utility.getStatusID_str(searchKey);
                whereSearchType.put(searchType, "AND");
            } else {
                whereSearchType.put(searchType, "LIKE");
            }
            SearchData.put(searchType, searchKey);

        }

        String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_area, SearchData, whereSearchType);
        logger.info(iiQStr);
        Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
        ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrAreaModel>>() {
        }.getType());

        ByteArrayInputStream stream = GenerateExcel.srArea(ListTotal);
        IOUtils.copy(stream, response.getOutputStream());
    }


    /*******************************  Area : end ********************************************/

    /********************************************* Status : start ***********************************************************/
    @RequestMapping(value = "/getStatusList", method = RequestMethod.POST)
    public QueryMDSrStatusModel getStatusList(HttpServletRequest request, @RequestParam("searchType") String searchType, @RequestParam("searchKey") String searchKey) {
        QueryMDSrStatusModel empList = new QueryMDSrStatusModel();
        try {
            int cpage = 1;
            String cm = request.getParameter("cpage");
            String sortName = request.getParameter("sortName");
            String sortColName = request.getParameter("sortColName");

            if (sortName == null) {
                sortName = "ASC";
            }
            if (sortColName == null) {
                sortColName = "ID";
            }

            if (cm == null || cm.equals("0")) {
                cpage = 1;
            } else {
                cpage = parseInt(request.getParameter("cpage"));
            }

            String perPageValue = request.getParameter("parPage");
            int perPage = perPageValue != "" ? parseInt(perPageValue) : Utility.perPageDataLoad;
            int EndPage = (cpage * perPage);
            int StartPage = (EndPage - perPage);
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }

            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_sr_status, SearchData, whereSearchType);
            logger.info(iiQStr);
            int ii = commonDAO.CommoNumberOfRow(iiQStr);

            String iQStr = QueryBuilder.getWherQueryPagination(Utility.md_sr_status, SearchData, StartPage, perPage, whereSearchType);
            logger.info(iQStr);
            Object i = commonDAO.getDataPaginationPostgres(iQStr);

            List<MDSrStatusModel> resList = new Gson().fromJson(Utility.ObjectToJson(i), new TypeToken<List<MDSrStatusModel>>() {
            }.getType());
            empList = new QueryMDSrStatusModel(new TBLDataShowModel(ii, perPage, StartPage, EndPage), resList);

        } catch (Exception ee) {
            logger.error(ee.getMessage());
        }
        return empList;
    }

    @RequestMapping(value = "/getStatusListCsv", method = RequestMethod.GET)
    public void getStatusListCsv(HttpServletResponse response, HttpServletRequest request) {
        try {
            List<MDSrStatusModel> ListTotal = null;

            String searchType = request.getParameter("searchType");
            String searchKey = request.getParameter("searchKey");
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }

            String filename = "SrStatusList.csv";
            response.setContentType("text/csv");
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");

            String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_status, SearchData, whereSearchType);
            logger.info(iiQStr);
            Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
            ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrStatusModel>>() {
            }.getType());
            GenerateCSV.status(response.getWriter(), ListTotal);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

    @GetMapping("/getStatusListXls")
    public void getStatusListXls(HttpServletResponse response, HttpServletRequest request) throws IOException {
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=SrStatusList.xlsx");

        List<MDSrStatusModel> ListTotal = null;

        String searchType = request.getParameter("searchType");
        String searchKey = request.getParameter("searchKey");
        Map<String, Object> SearchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();

        if (!searchType.isEmpty() && !searchKey.isEmpty()) {
            if (searchType.toUpperCase().equals("ACTIVE")) {
                searchKey = Utility.getStatusID_str(searchKey);
                whereSearchType.put(searchType, "AND");
            } else {
                whereSearchType.put(searchType, "LIKE");
            }
            SearchData.put(searchType, searchKey);

        }


        String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_status, SearchData, whereSearchType);
        logger.info(iiQStr);
        Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
        ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrStatusModel>>() {
        }.getType());

        ByteArrayInputStream stream = GenerateExcel.status(ListTotal);
        IOUtils.copy(stream, response.getOutputStream());
    }
    /********************************************* Status : end ***********************************************************/


    /********************************************* Priority : start ***********************************************************/
    @RequestMapping(value = "/getPriorityList", method = RequestMethod.POST)
    public QueryMDSrPriorityModel getPriorityList(HttpServletRequest request, @RequestParam("searchType") String searchType, @RequestParam("searchKey") String searchKey) {
        QueryMDSrPriorityModel empList = new QueryMDSrPriorityModel();
        try {
            int cpage = 1;
            String cm = request.getParameter("cpage");
            String sortName = request.getParameter("sortName");
            String sortColName = request.getParameter("sortColName");

            if (sortName == null) {
                sortName = "ASC";
            }
            if (sortColName == null) {
                sortColName = "ID";
            }

            if (cm == null || cm.equals("0")) {
                cpage = 1;
            } else {
                cpage = parseInt(request.getParameter("cpage"));
            }

            String perPageValue = request.getParameter("parPage");
            int perPage = perPageValue != "" ? parseInt(perPageValue) : Utility.perPageDataLoad;
            int EndPage = (cpage * perPage);
            int StartPage = (EndPage - perPage);
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }

            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_sr_priority, SearchData, whereSearchType);
            logger.info(iiQStr);
            int ii = commonDAO.CommoNumberOfRow(iiQStr);

            String iQStr = QueryBuilder.getWherQueryPagination(Utility.md_sr_priority, SearchData, StartPage, perPage, whereSearchType);
            logger.info(iQStr);
            Object i = commonDAO.getDataPaginationPostgres(iQStr);

            List<MDSrPriorityModel> resList = new Gson().fromJson(Utility.ObjectToJson(i), new TypeToken<List<MDSrPriorityModel>>() {
            }.getType());
            empList = new QueryMDSrPriorityModel(new TBLDataShowModel(ii, perPage, StartPage, EndPage), resList);

        } catch (Exception ee) {
            //System.out.print(ee.toString());
            logger.error(ee.getMessage());
        }
        return empList;
    }

    @RequestMapping(value = "/getPriorityListCsv", method = RequestMethod.GET)
    public void getPriorityListCsv(HttpServletResponse response, HttpServletRequest request) {
        try {
            List<MDSrPriorityModel> ListTotal = null;

            String searchType = request.getParameter("searchType");
            String searchKey = request.getParameter("searchKey");
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }

            String filename = "SrPriorityList.csv";
            response.setContentType("text/csv");
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");

            String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_priority, SearchData, whereSearchType);
            logger.info(iiQStr);
            Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
            ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrPriorityModel>>() {
            }.getType());
            GenerateCSV.priority(response.getWriter(), ListTotal);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

    @GetMapping("/getPriorityListXls")
    public void getPriorityListXls(HttpServletResponse response, HttpServletRequest request) throws IOException {
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=SrPriorityList.xlsx");

        List<MDSrPriorityModel> ListTotal = null;

        String searchType = request.getParameter("searchType");
        String searchKey = request.getParameter("searchKey");
        Map<String, Object> SearchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();

        if (!searchType.isEmpty() && !searchKey.isEmpty()) {
            if (searchType.toUpperCase().equals("ACTIVE")) {
                searchKey = Utility.getStatusID_str(searchKey);
                whereSearchType.put(searchType, "AND");
            } else {
                whereSearchType.put(searchType, "LIKE");
            }
            SearchData.put(searchType, searchKey);

        }

        String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_priority, SearchData, whereSearchType);
        logger.info(iiQStr);
        Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
        ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrPriorityModel>>() {
        }.getType());

        ByteArrayInputStream stream = GenerateExcel.priority(ListTotal);
        IOUtils.copy(stream, response.getOutputStream());
    }

    /********************************************* Priority  : end ***********************************************************/

    /********************************************* Severity  : start ***********************************************************/

    @RequestMapping(value = "/getSeverityList", method = RequestMethod.POST)
    public QueryMDSrSeverityModel getSeverityList(HttpServletRequest request, @RequestParam("searchType") String searchType, @RequestParam("searchKey") String searchKey) {
        QueryMDSrSeverityModel empList = new QueryMDSrSeverityModel();
        try {
            int cpage = 1;
            String cm = request.getParameter("cpage");
            String sortName = request.getParameter("sortName");
            String sortColName = request.getParameter("sortColName");

            if (sortName == null) {
                sortName = "ASC";
            }
            if (sortColName == null) {
                sortColName = "ID";
            }

            if (cm == null || cm.equals("0")) {
                cpage = 1;
            } else {
                cpage = parseInt(request.getParameter("cpage"));
            }

            String perPageValue = request.getParameter("parPage");
            int perPage = perPageValue != "" ? parseInt(perPageValue) : Utility.perPageDataLoad;
            int EndPage = (cpage * perPage);
            int StartPage = (EndPage - perPage);
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }


            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_sr_severity, SearchData, whereSearchType);
            logger.info(iiQStr);
            int ii = commonDAO.CommoNumberOfRow(iiQStr);

            String iQStr = QueryBuilder.getWherQueryPagination(Utility.md_sr_severity, SearchData, StartPage, perPage, whereSearchType);
            logger.info(iQStr);
            Object i = commonDAO.getDataPaginationPostgres(iQStr);

            List<MDSrSeverityModel> resList = new Gson().fromJson(Utility.ObjectToJson(i), new TypeToken<List<MDSrSeverityModel>>() {
            }.getType());
            empList = new QueryMDSrSeverityModel(new TBLDataShowModel(ii, perPage, StartPage, EndPage), resList);

        } catch (Exception ee) {
            //System.out.print(ee.toString());
            logger.error(ee.getMessage());
        }
        return empList;
    }

    @RequestMapping(value = "/getSeverityListCsv", method = RequestMethod.GET)
    public void getSeverityListCsv(HttpServletResponse response, HttpServletRequest request) {
        try {
            List<MDSrSeverityModel> ListTotal = null;

            String searchType = request.getParameter("searchType");
            String searchKey = request.getParameter("searchKey");
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }

            String filename = "SrSeverityList.csv";
            response.setContentType("text/csv");
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");

            String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_severity, SearchData, whereSearchType);
            logger.info(iiQStr);
            Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
            ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrSeverityModel>>() {
            }.getType());
            GenerateCSV.severity(response.getWriter(), ListTotal);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

    @GetMapping("/getSeverityListXls")
    public void getSeverityListXls(HttpServletResponse response, HttpServletRequest request) throws IOException {
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=SrSeverityList.xlsx");

        List<MDSrSeverityModel> ListTotal = null;

        String searchType = request.getParameter("searchType");
        String searchKey = request.getParameter("searchKey");
        Map<String, Object> SearchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();

        if (!searchType.isEmpty() && !searchKey.isEmpty()) {
            if (searchType.toUpperCase().equals("ACTIVE")) {
                searchKey = Utility.getStatusID_str(searchKey);
                whereSearchType.put(searchType, "AND");
            } else {
                whereSearchType.put(searchType, "LIKE");
            }
            SearchData.put(searchType, searchKey);

        }


        String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_severity, SearchData, whereSearchType);
        logger.info(iiQStr);
        Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
        ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrSeverityModel>>() {
        }.getType());

        ByteArrayInputStream stream = GenerateExcel.severity(ListTotal);
        IOUtils.copy(stream, response.getOutputStream());
    }
    /********************************************* Severity  : end ***********************************************************/

    /********************************************* RootCause  : start ***********************************************************/

    @RequestMapping(value = "/getRootCauseList", method = RequestMethod.POST)
    public QueryMDSrRootCauseModel getRootCauseList(HttpServletRequest request, @RequestParam("searchType") String searchType, @RequestParam("searchKey") String searchKey) {
        QueryMDSrRootCauseModel empList = new QueryMDSrRootCauseModel();
        try {
            int cpage = 1;
            String cm = request.getParameter("cpage");
            String sortName = request.getParameter("sortName");
            String sortColName = request.getParameter("sortColName");

            if (sortName == null) {
                sortName = "ASC";
            }
            if (sortColName == null) {
                sortColName = "ID";
            }

            if (cm == null || cm.equals("0")) {
                cpage = 1;
            } else {
                cpage = parseInt(request.getParameter("cpage"));
            }

            String perPageValue = request.getParameter("parPage");
            int perPage = perPageValue != "" ? parseInt(perPageValue) : Utility.perPageDataLoad;

            int EndPage = (cpage * perPage);
            int StartPage = (EndPage - perPage);
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }


            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_sr_root_cause, SearchData, whereSearchType);
            logger.info(iiQStr);
            int ii = commonDAO.CommoNumberOfRow(iiQStr);

            String iQStr = QueryBuilder.getWherQueryPagination(Utility.md_sr_root_cause, SearchData, StartPage, perPage, whereSearchType);
            logger.info(iQStr);
            Object i = commonDAO.getDataPaginationPostgres(iQStr);

            List<MDSrRootCauseModel> resList = new Gson().fromJson(Utility.ObjectToJson(i), new TypeToken<List<MDSrRootCauseModel>>() {
            }.getType());
            empList = new QueryMDSrRootCauseModel(new TBLDataShowModel(ii, perPage, StartPage, EndPage), resList);

        } catch (Exception ee) {
            //System.out.print(ee.toString());
            logger.error(ee.getMessage());
        }
        return empList;
    }

    @RequestMapping(value = "/getRootCauseListCsv", method = RequestMethod.GET)
    public void getRootCauseListCsv(HttpServletResponse response, HttpServletRequest request) {
        try {
            List<MDSrRootCauseModel> ListTotal = null;

            String searchType = request.getParameter("searchType");
            String searchKey = request.getParameter("searchKey");
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }


            String filename = "SrRootCauseList.csv";
            response.setContentType("text/csv");
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");

            String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_root_cause, SearchData, whereSearchType);
            logger.info(iiQStr);
            Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
            ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrRootCauseModel>>() {
            }.getType());
            GenerateCSV.root_cause(response.getWriter(), ListTotal);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

    @GetMapping("/getRootCauseListXls")
    public void getRootCauseListXls(HttpServletResponse response, HttpServletRequest request) throws IOException {
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=SrRootCauseList.xlsx");

        List<MDSrRootCauseModel> ListTotal = null;

        String searchType = request.getParameter("searchType");
        String searchKey = request.getParameter("searchKey");
        Map<String, Object> SearchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();

        if (!searchType.isEmpty() && !searchKey.isEmpty()) {
            if (searchType.toUpperCase().equals("ACTIVE")) {
                searchKey = Utility.getStatusID_str(searchKey);
                whereSearchType.put(searchType, "AND");
            } else {
                whereSearchType.put(searchType, "LIKE");
            }
            SearchData.put(searchType, searchKey);

        }

        String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_root_cause, SearchData, whereSearchType);
        logger.info(iiQStr);
        Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
        ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrRootCauseModel>>() {
        }.getType());

        ByteArrayInputStream stream = GenerateExcel.root_cause(ListTotal);
        IOUtils.copy(stream, response.getOutputStream());
    }
    /********************************************* RootCause  : end ***********************************************************/

    /********************************************* ActionType  : start ***********************************************************/


    @RequestMapping(value = "/getActionTypeList", method = RequestMethod.POST)
    public QueryMDSrActionTypeModel getActionTypeList(HttpServletRequest request, @RequestParam("searchType") String searchType, @RequestParam("searchKey") String searchKey) {
        QueryMDSrActionTypeModel empList = new QueryMDSrActionTypeModel();
        try {
            int cpage = 1;
            String cm = request.getParameter("cpage");
            String sortName = request.getParameter("sortName");
            String sortColName = request.getParameter("sortColName");

            if (sortName == null) {
                sortName = "ASC";
            }
            if (sortColName == null) {
                sortColName = "ID";
            }

            if (cm == null || cm.equals("0")) {
                cpage = 1;
            } else {
                cpage = parseInt(request.getParameter("cpage"));
            }

            String perPageValue = request.getParameter("parPage");
            int perPage = perPageValue != "" ? parseInt(perPageValue) : Utility.perPageDataLoad;
            int EndPage = (cpage * perPage);
            int StartPage = (EndPage - perPage);
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }

            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_sr_action_type, SearchData, whereSearchType);
            logger.info(iiQStr);
            int ii = commonDAO.CommoNumberOfRow(iiQStr);

            String iQStr = QueryBuilder.getWherQueryPagination(Utility.md_sr_action_type, SearchData, StartPage, perPage, whereSearchType);
            logger.info(iQStr);
            Object i = commonDAO.getDataPaginationPostgres(iQStr);

            List<MDSrActionTypeModel> resList = new Gson().fromJson(Utility.ObjectToJson(i), new TypeToken<List<MDSrActionTypeModel>>() {
            }.getType());
            empList = new QueryMDSrActionTypeModel(new TBLDataShowModel(ii, perPage, StartPage, EndPage), resList);

        } catch (Exception ee) {
            //System.out.print(ee.toString());
            logger.error(ee.getMessage());
        }
        return empList;
    }

    @RequestMapping(value = "/getActionTypeListCsv", method = RequestMethod.GET)
    public void getActionTypeListCsv(HttpServletResponse response, HttpServletRequest request) {
        try {
            List<MDSrActionTypeModel> ListTotal = null;

            String searchType = request.getParameter("searchType");
            String searchKey = request.getParameter("searchKey");
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }

            String filename = "SrActionTypeList.csv";
            response.setContentType("text/csv");
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");

            String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_action_type, SearchData, whereSearchType);
            logger.info(iiQStr);
            Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
            ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrActionTypeModel>>() {
            }.getType());
            GenerateCSV.action_type(response.getWriter(), ListTotal);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

    @GetMapping("/getActionTypeListXls")
    public void getActionTypeListXls(HttpServletResponse response, HttpServletRequest request) throws IOException {
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=SrActionTypeList.xlsx");

        List<MDSrActionTypeModel> ListTotal = null;

        String searchType = request.getParameter("searchType");
        String searchKey = request.getParameter("searchKey");
        Map<String, Object> SearchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();

        if (!searchType.isEmpty() && !searchKey.isEmpty()) {
            if (searchType.toUpperCase().equals("ACTIVE")) {
                searchKey = Utility.getStatusID_str(searchKey);
                whereSearchType.put(searchType, "AND");
            } else {
                whereSearchType.put(searchType, "LIKE");
            }
            SearchData.put(searchType, searchKey);

        }

        String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_action_type, SearchData, whereSearchType);
        logger.info(iiQStr);
        Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
        ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrActionTypeModel>>() {
        }.getType());

        ByteArrayInputStream stream = GenerateExcel.action_type(ListTotal);
        IOUtils.copy(stream, response.getOutputStream());
    }

    /********************************************* ActionType  : end ***********************************************************/

    /********************************************* Answer Type  : start ***********************************************************/


    @RequestMapping(value = "/getAnsTypeList", method = RequestMethod.POST)
    public QueryMDSrAnsTypeModel getAnsTypeList(HttpServletRequest request, @RequestParam("searchType") String searchType, @RequestParam("searchKey") String searchKey) {
        QueryMDSrAnsTypeModel empList = new QueryMDSrAnsTypeModel();
        try {
            int cpage = 1;
            String cm = request.getParameter("cpage");
            String sortName = request.getParameter("sortName");
            String sortColName = request.getParameter("sortColName");

            if (sortName == null) {
                sortName = "ASC";
            }
            if (sortColName == null) {
                sortColName = "ID";
            }

            if (cm == null || cm.equals("0")) {
                cpage = 1;
            } else {
                cpage = parseInt(request.getParameter("cpage"));
            }

            String perPageValue = request.getParameter("parPage");
            int perPage = perPageValue != "" ? parseInt(perPageValue) : Utility.perPageDataLoad;

            int EndPage = (cpage * perPage);
            int StartPage = (EndPage - perPage);
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }

            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_sr_ans_type, SearchData, whereSearchType);
            logger.info(iiQStr);
            int ii = commonDAO.CommoNumberOfRow(iiQStr);

            String iQStr = QueryBuilder.getWherQueryPagination(Utility.md_sr_ans_type, SearchData, StartPage, perPage, whereSearchType);
            logger.info(iQStr);
            Object i = commonDAO.getDataPaginationPostgres(iQStr);

            List<MDSrAnsTypeModel> resList = new Gson().fromJson(Utility.ObjectToJson(i), new TypeToken<List<MDSrAnsTypeModel>>() {
            }.getType());
            empList = new QueryMDSrAnsTypeModel(new TBLDataShowModel(ii, perPage, StartPage, EndPage), resList);

        } catch (Exception ee) {
            //System.out.print(ee.toString());
            logger.error(ee.getMessage());
        }
        return empList;
    }

    @RequestMapping(value = "/getAnsTypeListCsv", method = RequestMethod.GET)
    public void getAnsTypeListCsv(HttpServletResponse response, HttpServletRequest request) {
        try {
            List<MDSrAnsTypeModel> ListTotal = null;

            String searchType = request.getParameter("searchType");
            String searchKey = request.getParameter("searchKey");
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }

            String filename = "SrAnsTypeList.csv";
            response.setContentType("text/csv");
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");

            String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_ans_type, SearchData, whereSearchType);
            logger.info(iiQStr);
            Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
            ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrAnsTypeModel>>() {
            }.getType());
            GenerateCSV.ans_type(response.getWriter(), ListTotal);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

    @GetMapping("/getAnsTypeListXls")
    public void getAnsTypeListXls(HttpServletResponse response, HttpServletRequest request) throws IOException {
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=SrAnsTypeList.xlsx");

        List<MDSrAnsTypeModel> ListTotal = null;

        String searchType = request.getParameter("searchType");
        String searchKey = request.getParameter("searchKey");
        Map<String, Object> SearchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();

        if (!searchType.isEmpty() && !searchKey.isEmpty()) {
            if (searchType.toUpperCase().equals("ACTIVE")) {
                searchKey = Utility.getStatusID_str(searchKey);
                whereSearchType.put(searchType, "AND");
            } else {
                whereSearchType.put(searchType, "LIKE");
            }
            SearchData.put(searchType, searchKey);

        }

        String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_ans_type, SearchData, whereSearchType);
        logger.info(iiQStr);
        Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
        ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrAnsTypeModel>>() {
        }.getType());

        ByteArrayInputStream stream = GenerateExcel.ans_type(ListTotal);
        IOUtils.copy(stream, response.getOutputStream());
    }

    /********************************************* Answer Type  : end ***********************************************************/


    /********************************************* Activity Type  : start ***********************************************************/


    @RequestMapping(value = "/getActTypeList", method = RequestMethod.POST)
    public QueryMDSrActTypeModel getActTypeList(HttpServletRequest request, @RequestParam("searchType") String searchType, @RequestParam("searchKey") String searchKey) {
        QueryMDSrActTypeModel empList = new QueryMDSrActTypeModel();
        try {
            int cpage = 1;
            String cm = request.getParameter("cpage");
            String sortName = request.getParameter("sortName");
            String sortColName = request.getParameter("sortColName");

            if (sortName == null) {
                sortName = "ASC";
            }
            if (sortColName == null) {
                sortColName = "ID";
            }

            if (cm == null || cm.equals("0")) {
                cpage = 1;
            } else {
                cpage = parseInt(request.getParameter("cpage"));
            }

            String perPageValue = request.getParameter("parPage");
            int perPage = perPageValue != "" ? parseInt(perPageValue) : Utility.perPageDataLoad;
            int EndPage = (cpage * perPage);
            int StartPage = (EndPage - perPage);
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }

            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_sr_act_type, SearchData, whereSearchType);
            logger.info(iiQStr);
            int ii = commonDAO.CommoNumberOfRow(iiQStr);

            String iQStr = QueryBuilder.getWherQueryPagination(Utility.md_sr_act_type, SearchData, StartPage, perPage, whereSearchType);
            logger.info(iQStr);
            Object i = commonDAO.getDataPaginationPostgres(iQStr);

            List<MDSrActTypeModel> resList = new Gson().fromJson(Utility.ObjectToJson(i), new TypeToken<List<MDSrActTypeModel>>() {
            }.getType());
            empList = new QueryMDSrActTypeModel(new TBLDataShowModel(ii, perPage, StartPage, EndPage), resList);

        } catch (Exception ee) {
            //System.out.print(ee.toString());
            logger.error(ee.getMessage());
        }
        return empList;
    }

    @RequestMapping(value = "/getActTypeListCsv", method = RequestMethod.GET)
    public void getActTypeListCsv(HttpServletResponse response, HttpServletRequest request) {
        try {
            List<MDSrActTypeModel> ListTotal = null;

            String searchType = request.getParameter("searchType");
            String searchKey = request.getParameter("searchKey");
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }

            String filename = "SrActTypeList.csv";
            response.setContentType("text/csv");
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");

            String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_act_type, SearchData, whereSearchType);
            logger.info(iiQStr);
            Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
            ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrActTypeModel>>() {
            }.getType());
            GenerateCSV.act_type(response.getWriter(), ListTotal);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

    @GetMapping("/getActTypeListXls")
    public void getActTypeListXls(HttpServletResponse response, HttpServletRequest request) throws IOException {
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=SrActTypeList.xlsx");

        List<MDSrActTypeModel> ListTotal = null;

        String searchType = request.getParameter("searchType");
        String searchKey = request.getParameter("searchKey");
        Map<String, Object> SearchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();

        if (!searchType.isEmpty() && !searchKey.isEmpty()) {
            if (searchType.toUpperCase().equals("ACTIVE")) {
                searchKey = Utility.getStatusID_str(searchKey);
                whereSearchType.put(searchType, "AND");
            } else {
                whereSearchType.put(searchType, "LIKE");
            }
            SearchData.put(searchType, searchKey);

        }

        String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_act_type, SearchData, whereSearchType);
        logger.info(iiQStr);
        Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
        ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrActTypeModel>>() {
        }.getType());

        ByteArrayInputStream stream = GenerateExcel.act_type(ListTotal);
        IOUtils.copy(stream, response.getOutputStream());
    }

    /********************************************* Activity Type  : end ***********************************************************/

    @RequestMapping(value = "/getSRSubArea", method = RequestMethod.POST)
    public SRConfigAjxModel getSRSubArea() {
        List<MDAccountClassModel> accountClass = new ArrayList<MDAccountClassModel>();
        List<MDSrServiceTypeModel> mdSrServiceTypeModels = new ArrayList<MDSrServiceTypeModel>();
        List<SRRoutingGroupModel> mdRoutingList = new ArrayList<SRRoutingGroupModel>();
        List<MDSrSeverityModel> srserList = new ArrayList<MDSrSeverityModel>();
        List<MDSrPriorityModel> mdSrPriorityModels = new ArrayList<MDSrPriorityModel>();
        List<MDAccountTypeModel> accountType = new ArrayList<MDAccountTypeModel>();
        Map<String, Object> ServiceTypeData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        ServiceTypeData.put("ACTIVE", "1");
        whereSearchType.put("ACTIVE", "AND");

        try {
            Object srServiceList = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_service_type, ServiceTypeData, "ID,NAME", whereSearchType));
            mdSrServiceTypeModels = new Gson().fromJson(Utility.ObjectToJson(srServiceList), new TypeToken<List<MDSrServiceTypeModel>>() {
            }.getType());
            Object mdRouting = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_routing_group, ServiceTypeData, "ID,NAME,OWNER_NAME,OWNER_ID", whereSearchType));
            mdRoutingList = new Gson().fromJson(Utility.ObjectToJson(mdRouting), new TypeToken<List<SRRoutingGroupModel>>() {
            }.getType());

            Object ssl = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_severity, ServiceTypeData, "ID,NAME", whereSearchType));
            srserList = new Gson().fromJson(Utility.ObjectToJson(ssl), new TypeToken<List<MDSrSeverityModel>>() {
            }.getType());

//            Object accl = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_acc_class, ServiceTypeData,"ID,NAME", "AND"));
//            accountClass = new Gson().fromJson(Utility.ObjectToJson(accl), new TypeToken<List<MDAccountClassModel>>() {
//            }.getType());
//
            Object pp = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_priority, ServiceTypeData, "ID,NAME", whereSearchType));
            mdSrPriorityModels = new Gson().fromJson(Utility.ObjectToJson(pp), new TypeToken<List<MDSrPriorityModel>>() {
            }.getType());
//
//
//            Object acctype = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_acc_type, ServiceTypeData,"ID,NAME", "AND"));
//            accountType = new Gson().fromJson(Utility.ObjectToJson(acctype), new TypeToken<List<MDAccountTypeModel>>() {
//            }.getType());
//

        } catch (Exception e) {
            System.out.println("error" + e.getMessage());
        }

        return new SRConfigAjxModel(mdSrServiceTypeModels, mdRoutingList, srserList, accountClass, mdSrPriorityModels, accountType);
    }

    @RequestMapping(value = "/getSRSLAMatrix", method = RequestMethod.POST)
    public SRConfigAjxModel getSRSLAMatrix() {
        List<MDAccountClassModel> accountClass = new ArrayList<MDAccountClassModel>();
        List<MDSrPriorityModel> mdSrPriorityModels = new ArrayList<MDSrPriorityModel>();
        List<MDAccountTypeModel> accountType = new ArrayList<MDAccountTypeModel>();
        Map<String, Object> ServiceTypeData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        ServiceTypeData.put("ACTIVE", "1");
        whereSearchType.put("ACTIVE", "AND");

        try {

            Object accl = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_acc_class, ServiceTypeData, "ID,NAME", whereSearchType));
            accountClass = new Gson().fromJson(Utility.ObjectToJson(accl), new TypeToken<List<MDAccountClassModel>>() {
            }.getType());


            Object pp = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_priority, ServiceTypeData, "ID,NAME", whereSearchType));
            mdSrPriorityModels = new Gson().fromJson(Utility.ObjectToJson(pp), new TypeToken<List<MDSrPriorityModel>>() {
            }.getType());


            Object acctype = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_acc_type, ServiceTypeData, "ID,NAME", whereSearchType));
            accountType = new Gson().fromJson(Utility.ObjectToJson(acctype), new TypeToken<List<MDAccountTypeModel>>() {
            }.getType());


        } catch (Exception e) {
            System.out.println("error" + e.getMessage());
        }

        return new SRConfigAjxModel(accountClass, mdSrPriorityModels, accountType);
    }

    @RequestMapping(value = "/getSRNotify", method = RequestMethod.POST)
    public SRConfigAjxModel getSRNotify() {
        List<MDSrStatusModel> mdSrStatusModels = new ArrayList<MDSrStatusModel>();
        Map<String, Object> ServiceTypeData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        ServiceTypeData.put("ACTIVE", "1");
        whereSearchType.put("ACTIVE", "AND");

        try {
            Object acctype = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_status, ServiceTypeData, "ID,NAME", whereSearchType));
            mdSrStatusModels = new Gson().fromJson(Utility.ObjectToJson(acctype), new TypeToken<List<MDSrStatusModel>>() {
            }.getType());

        } catch (Exception e) {
            System.out.println("error" + e.getMessage());
        }

        return new SRConfigAjxModel(mdSrStatusModels);
    }

    @RequestMapping(value = "/getSREscalation", method = RequestMethod.POST)
    public SRConfigAjxModel getSREscalation() {
        List<MDUserGroupModel> groupModels = new ArrayList<MDUserGroupModel>();
        SRConfigAjxModel ajxModel = new SRConfigAjxModel();
        Map<String, Object> ServiceTypeData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        ServiceTypeData.put("ACTIVE", "1");
        whereSearchType.put("ACTIVE", "AND");
        try {
            Object acctype = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_user_group, ServiceTypeData, "ID,NAME", whereSearchType));
            groupModels = new Gson().fromJson(Utility.ObjectToJson(acctype), new TypeToken<List<MDSrStatusModel>>() {
            }.getType());
            ajxModel.setGroupModels(groupModels);
        } catch (Exception e) {
            System.out.println("error" + e.getMessage());
        }
        return ajxModel;
    }

    @RequestMapping(value = "/getSRUserGroup", method = RequestMethod.POST)
    public List<MDUserModel> getSRUserGroup(@RequestParam("group") String group) {
        List<MDUserModel> groupModels = new ArrayList<MDUserModel>();
        Map<String, Object> ServiceTypeData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        ServiceTypeData.put("ACTIVE", "1");
        whereSearchType.put("ACTIVE", "AND");

        ServiceTypeData.put("USER_GROUP_ID", group);
        whereSearchType.put("USER_GROUP_ID", "AND");

        try {
            Object acctype = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_user, ServiceTypeData, "ID,LOGIN_NAME,EMAIL", whereSearchType));
            groupModels = new Gson().fromJson(Utility.ObjectToJson(acctype), new TypeToken<List<MDUserModel>>() {
            }.getType());
        } catch (Exception e) {
            System.out.println("error" + e.getMessage());
        }
        return groupModels;
    }

    @RequestMapping(value = "/getSRSubAreaData", method = RequestMethod.POST)
    public MDSubAreaUpdateViewModel getSRSubAreaData(@RequestParam("id") String id) {
        List<MDSrSubAreaModel> groupModels = new ArrayList<MDSrSubAreaModel>();
        List<MDSrSLAModel> mdSrSLAModels = new ArrayList<MDSrSLAModel>();
        List<MDSrNotify> mdSrNotifies = new ArrayList<MDSrNotify>();
        List<MDSrescaModel> mdSrescaModels = new ArrayList<MDSrescaModel>();
        Map<String, Object> ServiceTypeData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();
        ServiceTypeData.put("UNIQUE_ID", id);
        whereSearchType.put("UNIQUE_ID", "AND");

        try {
            Object acctype = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_sub_area, ServiceTypeData, "*", whereSearchType));
            groupModels = new Gson().fromJson(Utility.ObjectToJson(acctype), new TypeToken<List<MDSrSubAreaModel>>() {
            }.getType());


            Object sla = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_sla, ServiceTypeData, "*", whereSearchType));
            mdSrSLAModels = new Gson().fromJson(Utility.ObjectToJson(sla), new TypeToken<List<MDSrSLAModel>>() {
            }.getType());

            Object notifyMt = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_notify_mt, ServiceTypeData, "*", whereSearchType));
            mdSrNotifies = new Gson().fromJson(Utility.ObjectToJson(notifyMt), new TypeToken<List<MDSrNotify>>() {
            }.getType());

            Object esceMt = commonDAO.getDataPostgres(QueryBuilder.getSelectWhereFieldsQuery(Utility.md_sr_esca_mt, ServiceTypeData, "*", whereSearchType));
            mdSrescaModels = new Gson().fromJson(Utility.ObjectToJson(esceMt), new TypeToken<List<MDSrescaModel>>() {
            }.getType());

        } catch (Exception e) {
            System.out.println("error" + e.getMessage());
        }
        return new MDSubAreaUpdateViewModel(groupModels, mdSrSLAModels, mdSrNotifies, mdSrescaModels);
    }

    /********************************************* SubArea : start ***********************************************************/
    @RequestMapping(value = "/getSubAreaList", method = RequestMethod.POST)
    public QueryMDSrSubAreaModel getSubAreaList(HttpServletRequest request, @RequestParam("searchType") String searchType, @RequestParam("searchKey") String searchKey) {
        QueryMDSrSubAreaModel empList = new QueryMDSrSubAreaModel();
        try {
            int cpage = 1;
            String cm = request.getParameter("cpage");
            String sortName = request.getParameter("sortName");
            String sortColName = request.getParameter("sortColName");

            if (sortName == null) {
                sortName = "ASC";
            }
            if (sortColName == null) {
                sortColName = "ID";
            }

            if (cm == null || cm.equals("0")) {
                cpage = 1;
            } else {
                cpage = Integer.parseInt(request.getParameter("cpage"));
            }
            String perPageValue = request.getParameter("parPage");

            int perPage = perPageValue != "" ? parseInt(perPageValue) : Utility.perPageDataLoad;
            int EndPage = (cpage * perPage);
            int StartPage = (EndPage - perPage);
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }

            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.md_sr_sub_area, SearchData, whereSearchType);
            logger.info(iiQStr);
            int ii = commonDAO.CommoNumberOfRow(iiQStr);

            String iQStr = QueryBuilder.getWherQueryPagination(Utility.md_sr_sub_area, SearchData, StartPage, perPage, whereSearchType);
            logger.info(iQStr);
            Object i = commonDAO.getDataPaginationPostgres(iQStr);

            List<MDSrSubAreaModel> resList = new Gson().fromJson(Utility.ObjectToJson(i), new TypeToken<List<MDSrSubAreaModel>>() {
            }.getType());
            empList = new QueryMDSrSubAreaModel(new TBLDataShowModel(ii, Utility.perPageDataLoad, StartPage, EndPage), resList);

        } catch (Exception ee) {
            //System.out.print(ee.toString());
            logger.error(ee.getMessage());
        }
        return empList;
    }


    /********************************************* Ques Mgt  : start ***********************************************************/


    @RequestMapping(value = "/getQuesMgtList", method = RequestMethod.POST)
    public QueryMDSrQuesMgtModel getQuesMgtList(HttpServletRequest request, @RequestParam("searchType") String searchType, @RequestParam("searchKey") String searchKey) {
        QueryMDSrQuesMgtModel empList = new QueryMDSrQuesMgtModel();
        try {
            int cpage = 1;
            String cm = request.getParameter("cpage");
            String sortName = request.getParameter("sortName");
            String sortColName = request.getParameter("sortColName");

            if (sortName == null) {
                sortName = "ASC";
            }
            if (sortColName == null) {
                sortColName = "ID";
            }

            if (cm == null || cm.equals("0")) {
                cpage = 1;
            } else {
                cpage = parseInt(request.getParameter("cpage"));
            }

            String perPageValue = request.getParameter("parPage");
            int perPage = perPageValue != "" ? parseInt(perPageValue) : Utility.perPageDataLoad;
            int EndPage = (cpage * perPage);
            int StartPage = (EndPage - perPage);
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }

            String iiQStr = QueryBuilder.getCountWhereQuery(Utility.tbl_sr_ques, SearchData, whereSearchType);
            logger.info(iiQStr);
            int ii = commonDAO.CommoNumberOfRow(iiQStr);

            String iQStr = QueryBuilder.getWherQueryPagination(Utility.tbl_sr_ques, SearchData, StartPage, perPage, whereSearchType);
            logger.info(iQStr);
            Object i = commonDAO.getDataPaginationPostgres(iQStr);

            List<MDSrQuesMgtModel> resList = new Gson().fromJson(Utility.ObjectToJson(i), new TypeToken<List<MDSrQuesMgtModel>>() {
            }.getType());
            empList = new QueryMDSrQuesMgtModel(new TBLDataShowModel(ii, perPage, StartPage, EndPage), resList);

        } catch (Exception ee) {
            //System.out.print(ee.toString());
            logger.error(ee.getMessage());
        }
        return empList;
    }

    @RequestMapping(value = "/getQuesMgtListCsv", method = RequestMethod.GET)
    public void getQuesMgtListCsv(HttpServletResponse response, HttpServletRequest request) {
        try {
            List<MDSrQuesMgtModel> ListTotal = null;

            String searchType = request.getParameter("searchType");
            String searchKey = request.getParameter("searchKey");
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }

            String filename = "Question List.csv";
            response.setContentType("text/csv");
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");

            String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.tbl_sr_ques, SearchData, whereSearchType);
            logger.info(iiQStr);
            Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
            ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrQuesMgtModel>>() {
            }.getType());
            GenerateCSV.ques_mgt(response.getWriter(), ListTotal);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

    @GetMapping("/getQuesMgtListXls")
    public void getQuesMgtListXls(HttpServletResponse response, HttpServletRequest request) throws IOException {
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=QuestionList.xlsx");

        List<MDSrQuesMgtModel> ListTotal = null;

        String searchType = request.getParameter("searchType");
        String searchKey = request.getParameter("searchKey");
        Map<String, Object> SearchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();

        if (!searchType.isEmpty() && !searchKey.isEmpty()) {
            if (searchType.toUpperCase().equals("ACTIVE")) {
                searchKey = Utility.getStatusID_str(searchKey);
                whereSearchType.put(searchType, "AND");
            } else {
                whereSearchType.put(searchType, "LIKE");
            }
            SearchData.put(searchType, searchKey);

        }

        String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.tbl_sr_ques, SearchData, whereSearchType);
        logger.info(iiQStr);
        Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
        ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrQuesMgtModel>>() {
        }.getType());

        ByteArrayInputStream stream = GenerateExcel.ques_mgt(ListTotal);
        IOUtils.copy(stream, response.getOutputStream());
    }

    @RequestMapping(value = "/get_mapped_ques_list", method = RequestMethod.POST)
    public List<SrSubAreaQuesList> getMappedQuesList(@RequestParam("sr_sub_area_id") int sr_sub_area_id) {
        logger.info("fetching already mapped ques list for sr sub area ");
        List<MDSrQuesListModel> MDSrQuesListModels = new ArrayList<>();
        List<SrSubAreaQuesList> final_data = new ArrayList<>();
        try {
            String qry = "SELECT T.* FROM (select m.SR_SUB_AREA_ID as sr_SUB_AREA_ID,m.SR_QUES_ID as ques_ID,COALESCE(m.IS_MANDATORY, 0) as is_MANDATORY,COALESCE(m.QUES_SEQUENCE, 0)  as ques_SEQUENCE,q.name as name,q.question as question, 1 as is_SELECTED  from md_sr_subarea_ques_map m left join md_sr_ques q on q.ID=m.SR_QUES_ID where m.SR_SUB_AREA_ID=" + sr_sub_area_id + " UNION select " + sr_sub_area_id + " as sr_SUB_AREA_ID,qu.ID as ques_ID,0 as is_MANDATORY,0 as ques_SEQUENCE,qu.NAME as name,qu.QUESTION as question,0 as is_SELECTED  from md_sr_ques qu where qu.id not in (select q.ID  from md_sr_subarea_ques_map m left join md_sr_ques q on q.ID=m.SR_QUES_ID where m.SR_SUB_AREA_ID=" + sr_sub_area_id + ")) T order by T.ques_SEQUENCE,T.ques_ID ASC";
            logger.info("Query :" + qry);
            Object SrSubAreaQuesList = commonDAO.getDataPostgres(qry);
            MDSrQuesListModels = new Gson().fromJson(Utility.ObjectToJson(SrSubAreaQuesList), new TypeToken<List<MDSrQuesListModel>>() {
            }.getType());
        } catch (Exception ex) {
            ex.printStackTrace();
            logger.error(ex.getMessage(), ex);
        }
        logger.info(Utility.ObjectToJson(MDSrQuesListModels));
        System.out.println(Utility.ObjectToJson(MDSrQuesListModels));
        logger.info("Returning fromalready mapped ques list for sr sub area with data: " + MDSrQuesListModels.size());

        SrSubAreaQuesList local_data;
        for (MDSrQuesListModel data : MDSrQuesListModels) {
            local_data = new SrSubAreaQuesList();
            local_data.setQues_ID(data.getQUES_ID());
            local_data.setSr_SUB_AREA_ID(data.getSR_SUB_AREA_ID());
            local_data.setName(data.getNAME());
            local_data.setQuestion(data.getQUESTION());
            local_data.setIs_MANDATORY(data.getIS_MANDATORY());
            local_data.setQues_SEQUENCE(data.getQUES_SEQUENCE());
            local_data.setIs_SELECTED(data.getIS_SELECTED());
            final_data.add(local_data);
        }
        return final_data;
    }

    @RequestMapping(value = "/get_smartscript_ques_list", method = RequestMethod.POST)
    public List<MDSmartScriptQuesListModel> getSmartscriptQuesList(@RequestParam("sr_sub_area_id") int sr_sub_area_id) {
        logger.info("fetching Smart Script Data ");
        List<MDSmartScriptQuesListModel> MDSmartScriptQuesListModels = new ArrayList<>();
        try {
            String qry = "SELECT QAM.ID AS ID,QAM.SR_SUB_AREA_ID AS SR_SUB_AREA_ID,QAM.SR_QUES_ID AS SR_QUES_ID,QAM.QUES_SEQUENCE AS QUES_SEQUENCE,QAM.IS_MANDATORY AS IS_MANDATORY,Q.ANS_TYPE_ID,Q.ANS_TYPE_NAME,Q.HAS_CHILD_QUES,Q.CHILD_QUESTION_ID,Q.INPUT_OPTIONS,Q.ANS_INPUT_TYPE,Q.NAME,Q.QUESTION,Q.CHILD_QUESTION FROM MD_SR_SUBAREA_QUES_MAP QAM LEFT JOIN MD_SR_QUES Q ON Q.ID=QAM.SR_QUES_ID WHERE QAM.SR_SUB_AREA_ID=" + sr_sub_area_id + "  ORDER BY QAM.QUES_SEQUENCE,QAM.ID ASC";
            logger.info("Query :" + qry);
            Object SrQuesList = commonDAO.getDataPostgres(qry);
            MDSmartScriptQuesListModels = new Gson().fromJson(Utility.ObjectToJson(SrQuesList), new TypeToken<List<MDSmartScriptQuesListModel>>() {
            }.getType());
        } catch (Exception ex) {
            ex.printStackTrace();
            logger.error(ex.getMessage(), ex);
        }
        logger.info(Utility.ObjectToJson(MDSmartScriptQuesListModels));
        System.out.println(Utility.ObjectToJson(MDSmartScriptQuesListModels));
        logger.info("Returning smartscript ques list for sr sub area with data: " + MDSmartScriptQuesListModels.size());
        return MDSmartScriptQuesListModels;
    }


    @RequestMapping(value = "/update_ques_mapping", method = RequestMethod.POST)
    public String updateQuesMapping(HttpServletRequest request, @RequestParam("responsibility_data") String responsibility_data, @RequestParam("sub_area_id") Integer sub_area_id) {
        SrSubAreaQuesList empList = new SrSubAreaQuesList();
        List<SrSubAreaQuesList> resList = new Gson().fromJson(responsibility_data, new TypeToken<List<SrSubAreaQuesList>>() {
        }.getType());

        System.out.println("Sub Area ID:" + sub_area_id);
        System.out.println(Utility.ObjectToJson(resList));

        int action_by = Utility.getUserId(request).intValue();
        String action_by_username = Utility.getLoginName(request);
        long current_ts = Utility.getCurrentTimestamp();

        if (resList.size() > 0) {
            List<Object[]> batchArgsList = new ArrayList<Object[]>();
            long sr_subarea_id = new Long(sub_area_id);

            try {
                for (SrSubAreaQuesList row : resList) {

                    boolean validSeq = false;
                    Integer quesSeq = 0;
                    try {
                        quesSeq = Integer.parseInt(row.getQues_SEQUENCE().toString());
                        validSeq = true;
                    } catch (NumberFormatException e) {

                    }


                    Object[] objectArray = {
                            row.getSr_SUB_AREA_ID(),
                            row.getQues_ID(),
                            quesSeq,
                            row.getIs_MANDATORY(),
                            row.getName(),
                            row.getQuestion(),
                            1,
                            current_ts,
                            action_by,
                            action_by_username
                    };
                    batchArgsList.add(objectArray);
                }

                logger.info(Utility.ObjectToJson(batchArgsList));
                System.out.println(Utility.ObjectToJson(batchArgsList));
                System.out.println("Sub Area ID:" + sr_subarea_id);

                boolean s = srtypeDAO.DeleteQuesSubareaMapping(sr_subarea_id, logger);

                if (s) {
                    boolean h = srtypeDAO.insertQuesSubareaMappingy(batchArgsList, sr_subarea_id, logger);
                    if (h) {
                        return "success";
                    }
                }

            } catch (Exception ex) {
                ex.printStackTrace();
                logger.error(ex.getMessage(), ex);
            }

        } else {
            Long sr_subarea_id = new Long(sub_area_id);
            boolean s = srtypeDAO.DeleteQuesSubareaMapping(sr_subarea_id, logger);
            if (s) {
                return "success";
            }
        }
        return "failed";
    }

    /********************************************* Ques Mgt  : end ***********************************************************/

//	@Autowired
//	private SRSettingsRepository srSettingsRepository;
//	@GetMapping(value = "/sr-status", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Iterable<MDSrStatusModel>> getActiveSR() {
//		Map<String, Object> SearchData = new HashMap<String, Object>();
//		Map<String, Object> whereSearchType = new HashMap<String, Object>();
//		String qry_count = QueryBuilder.getCountWhereQuery(Utility.md_sr_status, new HashMap<String, Object>(), whereSearchType);
//		logger.info(qry_count);
//		logger.info("HEREOOO");
        try {
//			int ii = commonDAO.CommoNumberOfRow(qry_count);

//			String qry_fetch = QueryBuilder.getWherQueryPagination(Utility.md_sr_status, SearchData, 0, Utility.perPageDataLoad, whereSearchType);
            String qry_fetch = "SELECT * FROM MD_SR_STATUS";
//			logger.info(qry_fetch);
            Object stslist = commonDAO.getDataPostgres(qry_fetch);

            List<MDSrStatusModel> statusList = new Gson().fromJson(Utility.ObjectToJson(stslist), new TypeToken<List<MDSrStatusModel>>() {
            }.getType());
//			return srSettingsRepository.findAll(input);
            return new ResponseEntity<>(statusList, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
//		return null;
    }

    @RequestMapping(value = "/sub-area-csv", method = RequestMethod.GET)
    public void getSubAreaCsv(HttpServletResponse response, HttpServletRequest request) {
        try {
            List<MDSrSubAreaModel> ListTotal = null;

            String searchType = request.getParameter("searchType");
            String searchKey = request.getParameter("searchKey");
            Map<String, Object> SearchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();

            if (!searchType.isEmpty() && !searchKey.isEmpty()) {
                if (searchType.toUpperCase().equals("ACTIVE")) {
                    searchKey = Utility.getStatusID_str(searchKey);
                    whereSearchType.put(searchType, "AND");
                } else {
                    whereSearchType.put(searchType, "LIKE");
                }
                SearchData.put(searchType, searchKey);

            }

            String filename = "SrSubArea.csv";
            response.setContentType("text/csv");
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");

            String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_sub_area, SearchData, whereSearchType);
            logger.info(iiQStr);
            Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
            ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrSubAreaModel>>() {
            }.getType());
            GenerateCSV.subArea(response.getWriter(), ListTotal);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

    @GetMapping("/sub-area-xls")
    public void getSubAreaXls(HttpServletResponse response, HttpServletRequest request) throws IOException {
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=Sub Area List.xlsx");

        List<MDSrSubAreaModel> ListTotal = null;

        String searchType = request.getParameter("searchType");
        String searchKey = request.getParameter("searchKey");
        Map<String, Object> SearchData = new HashMap<String, Object>();
        Map<String, Object> whereSearchType = new HashMap<String, Object>();

        if (!searchType.isEmpty() && !searchKey.isEmpty()) {
            if (searchType.toUpperCase().equals("ACTIVE")) {
                searchKey = Utility.getStatusID_str(searchKey);
                whereSearchType.put(searchType, "AND");
            } else {
                whereSearchType.put(searchType, "LIKE");
            }
            SearchData.put(searchType, searchKey);

        }

        String iiQStr = QueryBuilder.getSelectWhereQuery(Utility.md_sr_sub_area, SearchData, whereSearchType);
        logger.info(iiQStr);
        Object ii = commonDAO.getDataPaginationPostgres(iiQStr);
        ListTotal = new Gson().fromJson(Utility.ObjectToJson(ii), new TypeToken<List<MDSrSubAreaModel>>() {
        }.getType());

        ByteArrayInputStream stream = GenerateExcel.srSubArea(ListTotal);
        IOUtils.copy(stream, response.getOutputStream());
    }
}
