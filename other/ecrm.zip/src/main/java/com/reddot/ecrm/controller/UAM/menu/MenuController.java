package com.reddot.ecrm.controller.UAM.menu;

import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.service.menu.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping(value = "/menu", method = RequestMethod.GET)
public class MenuController {

    @Autowired
    private MenuService menuService;

    @GetMapping("")
    public String getMenuPage(ModelMap model, HttpServletRequest request){
        return "redirect:/menu/list";
    }

    @GetMapping({"/list"})
    public String getMenuListView(ModelMap model, HttpServletRequest request){
        new MenuViewer().setupSideMenu(model, request);
        model.addAttribute("title", "Menu");
        model.addAttribute("breadcrumb", "Menu");
        return "menu/menu_list";
    }

    @GetMapping("/add")
    public String getMenuAddView(ModelMap model, HttpServletRequest request){
        new MenuViewer().setupSideMenu(model, request);
        model.addAttribute("title", "Add Menu Item");
        model.addAttribute("breadcrumb", "Add");
        return "menu/menu_add";
    }

}
