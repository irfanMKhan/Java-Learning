package com.reddot.ecrm.controller.historyLog;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.entity.logger.APPLogger;
import com.reddot.ecrm.entity.logger.AppLoggerDetail;
import com.reddot.ecrm.model.applogger.AppLoggerDTO;
import com.reddot.ecrm.service.historyLog.HistoryLogService;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RequestMapping("/api/log/loc")
@RequiredArgsConstructor
@RestController
public class HistoryLogRestController {

    private final HistoryLogService service;
    private enum features {Lead, Opportunity, Contract};
    @GetMapping("/dropdowns")
    public ResponseEntity<?> getAllDropdowns(){

        List<CompanyEntity> companyList = service.findAllActiveCompany();

        Map<String, Object> response = new HashMap<>();
        if(companyList==null || companyList.isEmpty()){
            response.put("statusList", null);
        }
        else {
            response.put("statusList", companyList);
        }
        response.put("featureList", features.values());

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/DT/all")
    public DataTablesOutput<APPLogger> getAllDataTable(@RequestBody Map<String, Object> reqBody){
        DataTablesInput input = new Gson().fromJson(Utility.ObjectToJson(reqBody.get("input")), new TypeToken<DataTablesInput>(){}.getType());

        AppLoggerDTO appLogger = new Gson().fromJson(Utility.ObjectToJson(reqBody.get("appLogger")), AppLoggerDTO.class);

        return service.getAllDataTable(input, appLogger);
    }

    @GetMapping("/details/{id}")
    public ResponseEntity<?> getAppLoggerDetailsById(@PathVariable("id") Long id){
        List<AppLoggerDetail> appLoggerDetail = service.getAppLoggerDetailsById(id);
        if(appLoggerDetail!=null){
            return new ResponseEntity<>(appLoggerDetail, HttpStatus.OK);
        }
        else return new ResponseEntity<>(appLoggerDetail, HttpStatus.NO_CONTENT);
    }

    @GetMapping("/previous/{logId}/{txnId}")
    public ResponseEntity<?> getPreviousLogDetailById(@PathVariable("logId") Long logId, @PathVariable("txnId") String txnId){

        APPLogger previousLog = service.getPreviousLog(logId, txnId);
        if(previousLog!=null){
            return new ResponseEntity<>(previousLog, HttpStatus.OK);
        }

        return new ResponseEntity<>(previousLog, HttpStatus.NO_CONTENT);
    }
}
