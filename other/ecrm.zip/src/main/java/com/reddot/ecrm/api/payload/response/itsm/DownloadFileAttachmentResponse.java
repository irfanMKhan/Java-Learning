package com.reddot.ecrm.api.payload.response.itsm;

import lombok.Data;

import java.sql.Timestamp;

@Data
public class DownloadFileAttachmentResponse {
    private String contentType;
    private String fileName;
    private String id;
    private String size;
    private Timestamp createdTime;
}
