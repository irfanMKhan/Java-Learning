package com.reddot.ecrm.controller.subscriber;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.dto.cr.ChangeSimRequest;
import com.reddot.ecrm.dto.cr.NewRequestDTO;
import com.reddot.ecrm.dto.cr.SearchSubscriberDTO;
import com.reddot.ecrm.entity.cr.CRMasterEntity;
import com.reddot.ecrm.entity.cr.CRMsisdnDetailsEntity;
import com.reddot.ecrm.entity.msisdn.MsisdnEntity;
import com.reddot.ecrm.enum_config.bulk.BulkProcessFileTypeEnum;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.model.userRole.RoleEntity;
import com.reddot.ecrm.service.attachment.implementation.AttachmentServiceImplementation;
import com.reddot.ecrm.service.cr.add_new_number.AddNewNumberService;
import com.reddot.ecrm.service.cr.add_remove_service.AddRemoveService;
import com.reddot.ecrm.service.cr.change_plan.ChangePlanService;
import com.reddot.ecrm.service.msisdn.MsisdnService;
import com.reddot.ecrm.spring_config.session.SessionManager;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Controller
@RequiredArgsConstructor
@RequestMapping(value = "/subscriber")
public class SubscriberViewController {

    private final AddNewNumberService addNewNumberService;
    private final AddRemoveService addRemoveService;
    private final ChangePlanService changePlanService;
    private final MsisdnService msisdnService;
    private final AttachmentServiceImplementation attachmentServiceImplementation;

    @GetMapping
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Request List");
        return "/subscriber/index";
    }

    @ResponseBody
    @GetMapping("/list")
    public List<CRMasterEntity> getSubscriberList() {
        return changePlanService.getAllCRMasterEntity();
    }

    @ResponseBody
    @PostMapping("/list/search")
    public List<CRMasterEntity> getSubscriberListSearch(@Valid @RequestBody SearchSubscriberDTO searchSubscriberDTO, HttpServletRequest request) {
        MDUserModel user = SessionManager.getUserDetails(request);
        if( user.getUSER_TYPE().equalsIgnoreCase("PIC") ){
            searchSubscriberDTO.setCompanyName(user.getCOMPANY_NAME());
        }

        return changePlanService.getAllCRMasterEntityBySearch(searchSubscriberDTO);
    }

    @ResponseBody
    @RequestMapping(value = "/list/search-dt", method = RequestMethod.POST)
    public DataTablesOutput<CRMasterEntity> getOpportunityListDT(@RequestBody Map<String, Object> data, HttpServletRequest request) throws JsonProcessingException {

        DataTablesInput input = new Gson().fromJson(
                Utility.ObjectToJson(data.get("dtInput")), new TypeToken<DataTablesInput>() {
                }.getType()
        );
        MDUserModel user = SessionManager.getUserDetails(request);

        List<RoleEntity> roleEntityList = user.getRoleEntityList();
        Boolean isAdmin = false;
        for (RoleEntity role : roleEntityList) {
            if (Objects.equals(role.getName(), "ADMIN")) {
                isAdmin = true;
                break;
            }
        }

        ObjectMapper mapper = new ObjectMapper();
        SearchSubscriberDTO searchSubscriberDTO = mapper.readValue(data.get("searchData").toString(), SearchSubscriberDTO.class);

        return changePlanService.searchDataTable(input, searchSubscriberDTO, isAdmin);

    }

    @ResponseBody
    @GetMapping("/details/list")
    public List<CRMsisdnDetailsEntity> getSubscriberDetailsList(String masterId) {
        return changePlanService.getAllCRDetailsEntity(masterId);
    }

    @GetMapping("/add")
    public String viewAddPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        MDUserModel user = SessionManager.getUserDetails(request);

        model.put("login_name", user.getLOGIN_NAME());
        model.put("name", user.getNAME());
        model.put("logged_in_id", user.getID());
        model.put("title", "Request List");
        model.put("userType", user.getUSER_TYPE());

        return "/subscriber/add";
    }

    @ResponseBody
    @PostMapping(value = "/add/submit", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> addOpportunity(@Valid @RequestBody ChangeSimRequest changeSimRequest, HttpServletRequest request) throws JsonProcessingException {
        changePlanService.saveChangeSimOrReactiveOrStolenRequest(changeSimRequest, request);
        return new ResponseEntity<>("Success", HttpStatus.OK);
    }

    @ResponseBody
    @GetMapping("/add/get/msisdn-list")
    public List<MsisdnEntity> getMsisdnList(String companyName) {
        if (Objects.equals(companyName, ""))
            return new ArrayList<MsisdnEntity>();
        else
            return msisdnService.findAllByCompanyName(companyName);
    }

    @ResponseBody
    @GetMapping("/add/get/final-msisdn-list")
    public List<NewRequestDTO> getfinalList() {
        return new ArrayList<NewRequestDTO>();
    }

    @GetMapping("/view")
    public String viewDetailsPage(String id, ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        MDUserModel user = SessionManager.getUserDetails(request);

        model.put("login_name", user.getLOGIN_NAME());
        model.put("name", user.getNAME());
        model.put("logged_in_id", user.getID());
        model.put("title", "Request List");
        model.put("request_id", id);

        return "/subscriber/view";
    }

    @ResponseBody
    @GetMapping("/view/get-data")
    public ResponseEntity<?> getViewData(String id) {
        CRMsisdnDetailsEntity crMsisdnDetails = changePlanService.getCrMsisdnDetailsById(id);
        return new ResponseEntity<>(crMsisdnDetails, HttpStatus.OK);
    }

    @ResponseBody
    @PostMapping("/list/get-all-attachment")
    public CommonRestResponse getAllAttachmentByMasterID(@RequestBody Long crMasterID, HttpServletRequest request) {
        return attachmentServiceImplementation.getAllAttachmentByMasterID(crMasterID, BulkProcessFileTypeEnum.Change_Reset_Stolen_Sim);
    }

}
