package com.reddot.ecrm.api.payload.response.opportunity;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class ReserveListMSISDNResponse implements Serializable {
    private Integer code;

    private Data data;

    private String message;

    private Integer timestamp;

    @lombok.Data
    public static class Data {
        private String code;

        private List<Integer> success;

        private List<Integer> failed;

        private String correlation_id;

        private String message;

        private MetaData meta_data;

        @lombok.Data
        public static class MetaData {
            private Object db_success;

            private Object db_failed;
        }
    }
}
