package com.reddot.ecrm.controller.GlobalSettingsController;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.dto.GlobalSettings.Address.MDAddressModel;
import com.reddot.ecrm.dto.GlobalSettings.Division.MDDivisionModel;
import com.reddot.ecrm.dto.GlobalSettings.Upazila.MDUpazilaModel;
import com.reddot.ecrm.dto.sr.management.TBLSRModelDT;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.model.GlobalSettings.Address.MDAddressModelDT;
import com.reddot.ecrm.repository.AddressRepository;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.util.QueryBuilder;
import com.reddot.ecrm.util.Utility;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class AddressRestController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());


    @Autowired
    private CommonRepository commonDAO;

    @Autowired
    private AddressRepository addressRepository;

    @RequestMapping(value = "/address/getDivisionList", method = RequestMethod.GET)
    public List<MDDivisionModel> getSRTypeForServiceType(HttpServletRequest request) {
        logger.info("Inside /address/getDivisionList");
        List<MDDivisionModel> divisionList = new ArrayList<>();
        try {
            Map<String, Object> search = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            search.put("ACTIVE", "1");
            whereSearchType.put("ACTIVE", "AND");

            String qry_fetch = QueryBuilder.getSelectWhereQuery(Utility.md_division, search, whereSearchType);
            logger.info(qry_fetch);
            Object objectLit = commonDAO.getDataPostgres(qry_fetch);
            divisionList = new Gson().fromJson(Utility.ObjectToJson(objectLit), new TypeToken<List<MDDivisionModel>>() {
            }.getType());

        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return divisionList;
    }

    @RequestMapping(value = "/address/getUpzilaByDistrict", method = RequestMethod.POST)
    public List<MDUpazilaModel> getSRTypeForServiceType(HttpServletRequest request, @RequestParam("districtId") String districtId) {
        logger.info("Inside /address/getUpzilaByDistrict");
        List<MDUpazilaModel> upzilaList = new ArrayList<>();
        try {
            Map<String, Object> search = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            search.put("ACTIVE", "1");
            search.put("DISTRICT_ID", districtId);
            whereSearchType.put("ACTIVE", "AND");
            whereSearchType.put("DISTRICT_ID", "AND");

            String qry_fetch = QueryBuilder.getSelectWhereQuery(Utility.md_upazila, search, whereSearchType);
            logger.info(qry_fetch);
            Object objectLit = commonDAO.getDataPostgres(qry_fetch);
            upzilaList = new Gson().fromJson(Utility.ObjectToJson(objectLit), new TypeToken<List<MDUpazilaModel>>() {
            }.getType());

        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return upzilaList;
    }

    @RequestMapping(value = "/address/addNewAddress", method = RequestMethod.POST)
    public CommonRestResponse addNewUser(HttpServletRequest request, @RequestParam("addressData") String userData) {
        CommonRestResponse commonRestResponse = new CommonRestResponse();
        try {
            MDAddressModel mdAddressModel = new Gson().fromJson(userData, new TypeToken<MDAddressModel>() {
            }.getType());

            Map<String, Object> searchData = new HashMap<String, Object>();
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            searchData.put("PIPELINE_DATA", mdAddressModel.getPIPELINE_DATA());
            whereSearchType.put("PIPELINE_DATA", "AND");

            String duplicateQry = QueryBuilder.getCountWhereQuery(Utility.tbl_address, searchData, whereSearchType);
            logger.info(duplicateQry);
            int count = commonDAO.CommoNumberOfRow(duplicateQry);
            if (count > 0) {
//                return "duplicate";
                commonRestResponse.setCode(202);
                commonRestResponse.setMessage("Duplicate address.");
                return commonRestResponse;
            }

            Map<String, Object> insertData = new HashMap<String, Object>();
            insertData.put("FLAT_NO", mdAddressModel.getFLAT_NO());
            insertData.put("HOUSE_NO", mdAddressModel.getHOUSE_NO());
            insertData.put("ROAD_NO", mdAddressModel.getROAD_NO());
            insertData.put("VILLAGE_AREA", mdAddressModel.getVILLAGE_AREA());
            insertData.put("PO_BOX", mdAddressModel.getPO_BOX());
            insertData.put("UPAZILA_PS_ID", mdAddressModel.getUPAZILA_PS_ID());
            insertData.put("UPAZILA_PS_NAME", mdAddressModel.getUPAZILA_PS_NAME());
            insertData.put("DISTRICT_ID", mdAddressModel.getDISTRICT_ID());
            insertData.put("DISTRICT_NAME", mdAddressModel.getDISTRICT_NAME());
            insertData.put("DIVISION_ID", mdAddressModel.getDIVISION_ID());
            insertData.put("DIVISION_NAME", mdAddressModel.getDIVISION_NAME());
            insertData.put("COUNTRY_ID", mdAddressModel.getCOUNTRY_ID());
            insertData.put("COUNTRY_NAME", mdAddressModel.getCOUNTRY_NAME());
            insertData.put("FULL_ADDRESS", mdAddressModel.getFULL_ADDRESS());
            insertData.put("PIPELINE_DATA", mdAddressModel.getPIPELINE_DATA().toUpperCase());
            insertData.put("CREATED_BY", Utility.getUserId(request));
            insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
            insertData.put("CREATED_AT", Utility.getCurrentTimestamp());
            insertData.put("ACTIVE", 1);
            insertData.put("UPDATED_BY", Utility.getUserId(request));
            insertData.put("UPDATED_AT", Utility.getCurrentTimestamp());
            insertData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
//            boolean addressId = commonDAO.CommoInsert(Utility.tbl_address, insertData, logger);

            String addressId = commonDAO.commonInsertGetReturn(Utility.tbl_address, insertData, logger, "id");
            System.out.println("Created new address ID: " + addressId);
            if (addressId != null && !addressId.isEmpty()) {
                commonRestResponse.setCode(200);
                commonRestResponse.setMessage("Address created successfully.");
                return commonRestResponse;
            } else {
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("Address creation failed.");
                return commonRestResponse;
            }

        } catch (Exception e) {
            e.printStackTrace();
            logger.error("addNewAddress Error");
            logger.error(e.getMessage(), e);
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Address creation failed.");
            return commonRestResponse;
        }
    }

    @RequestMapping(value = "/dt/address/addressList", method = RequestMethod.GET)
    public DataTablesOutput<MDAddressModelDT> getSDPServiceList(@Valid DataTablesInput input) {
        /*DataTablesOutput<MDAddressModelDT> output = new DataTablesOutput<MDAddressModelDT>();
        try {
            output.setDraw(input.getDraw());
            List<MDAddressModelDT> valuesFromRepo = addressRepository.findAll();
            output.setData(valuesFromRepo);
            return output;
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return output;*/
        return addressRepository.findAll(input);
    }

    @RequestMapping(value = "/dt/address/addressList", method = RequestMethod.POST)
    public DataTablesOutput<MDAddressModelDT> getSDPServiceListPost(@Valid DataTablesInput input) {
        System.out.println(input.getSearch().getValue());
        return addressRepository.findAll(input);
    }

    public Specification<MDAddressModelDT> buildSpecification(String keyword) {
        return (root, query, builder) -> builder.like(root.get("divisionName"), "%" + keyword + "%");
    }

    @GetMapping(value = "/data")
    public DataTablesOutput<MDAddressModelDT> getData(@Valid DataTablesInput input, @RequestParam("search[value]") String keyword) {
        Specification<MDAddressModelDT> specification = StringUtils.isNotBlank(keyword) ? buildSpecification(keyword) : null;
        return addressRepository.findAll(input, specification);
    }
}
