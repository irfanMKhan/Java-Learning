package com.reddot.ecrm.controller.emailTemplate;

import com.reddot.ecrm.entity.emailTemplate.EmailTemplateDTO;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.emailTemplate.EmailTemplateService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping(value = "/api/email-template", method = RequestMethod.GET)
@RequiredArgsConstructor
public class EmailTemplateRestController {
    private final EmailTemplateService emailTemplateService;

    @GetMapping("/list")
    public CommonRestResponse getAllEmailTemplate(){
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error occurred! Please try again", null);
        List<EmailTemplateDTO> result = emailTemplateService.getAllEmailTemplates();
        if(result.isEmpty()){
            commonRestResponse.setCode(400);
            commonRestResponse.setMessage("No templates found!");
            commonRestResponse.setData(result);
        } else {
            commonRestResponse.setCode(200);
            commonRestResponse.setMessage("List of templates found");
            commonRestResponse.setData(result);
        }
        return commonRestResponse;
    }

    @GetMapping("/{id}")
    public CommonRestResponse getEmailTemplateById(@PathVariable("id") String id){
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error occurred! Please try again", null);
        EmailTemplateDTO result = emailTemplateService.getEmailTemplateById(id);
        if(result!=null){
            commonRestResponse.setCode(200);
            commonRestResponse.setMessage("Found email template");
            commonRestResponse.setData(result);
        }
        else {
            commonRestResponse.setCode(400);
            commonRestResponse.setMessage("Email template not found!");
        }
        return commonRestResponse;
    }

    @PostMapping("/add")
    public CommonRestResponse createEmailTemplate(@RequestBody EmailTemplateDTO emailTemplateDTO, HttpServletRequest request){
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error occurred! Please try again", null);
        EmailTemplateDTO result = emailTemplateService.createEmailTemplate(emailTemplateDTO, request);
        if (result.getId()== -1L){
            commonRestResponse.setCode(403);
            commonRestResponse.setMessage("Template with this name already exists!");
        }
        else if(result!=null){
            commonRestResponse.setCode(200);
            commonRestResponse.setMessage("Successfully created email template!");
            commonRestResponse.setData(result);
        }

        return commonRestResponse;
    }

    @PatchMapping("/update")
    public CommonRestResponse updateEmailTemplate(@RequestBody EmailTemplateDTO emailTemplateDTO, HttpServletRequest request){
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error occurred! Please try again", null);
        EmailTemplateDTO result = emailTemplateService.updateEmailTemplate(emailTemplateDTO, request);
        if (result.getId()== -1L){
            commonRestResponse.setCode(403);
            commonRestResponse.setMessage("Template with this name already exists!");
        }
        else if (result!=null){
            commonRestResponse.setCode(200);
            commonRestResponse.setMessage("Successfully updated email template!");
            commonRestResponse.setData(result);
        }
        return commonRestResponse;
    }
}
