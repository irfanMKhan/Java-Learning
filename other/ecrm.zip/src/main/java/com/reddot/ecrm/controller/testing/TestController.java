package com.reddot.ecrm.controller.testing;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.UserModel;
import com.reddot.ecrm.service.responsibility.ResponsibilityService;
import com.reddot.ecrm.service.user.UserService;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

@Controller
public class TestController {

    @Autowired
    private ResponsibilityService responsibilityService;

    @Autowired
    private UserService userService;

    @RequestMapping(value = "/test/dashboard", method = RequestMethod.GET)
    public String showTestPage(ModelMap model, HttpServletRequest request){
        new MenuViewer().setupSideMenu(model, request);
        model.addAttribute("title", "Dashboard");
        return "theme_migration/dashboard";
    }

    @RequestMapping(value = "/test/users", method = RequestMethod.GET)
    public String showUserListPage(ModelMap model, HttpServletRequest request){
        new MenuViewer().setupSideMenu(model, request);

        model.addAttribute("title", "User List");
        return "theme_migration/user/user_list";
    }

    @RequestMapping(value = "/test/users/add", method = RequestMethod.GET)
    public String showAddUserPage(ModelMap model, HttpServletRequest request){
        new MenuViewer().setupSideMenu(model, request);
        UserModel user = new UserModel();

        model.addAttribute("title", "Add User");
        model.addAttribute("new_user", user);
        model.addAttribute("responsibilities", responsibilityService.getAllResponsibility());

        return "theme_migration/user/user_add";
    }

    @RequestMapping(value = "/test/users/{id}", method = RequestMethod.GET)
    public String showUpdateUserPage(ModelMap model, HttpServletRequest request, @PathVariable(name = "id") String id){
        new MenuViewer().setupSideMenu(model, request);

        List<UserModel> userModelList = new ArrayList<>();
        userModelList = new Gson().fromJson(Utility.ObjectToJson(userService.getUserById(id)), new TypeToken<List<UserModel>>(){}
                .getType());
        userModelList.get(0).setMapList(userService.getUserResponsibilityMapping(id.toString()));

        model.addAttribute("title", "Update User");
        model.addAttribute("user", userModelList);
        model.addAttribute("responsibilities", userService.getRespSelectList(id.toString()));

        return "theme_migration/user/user_update";
    }
    @RequestMapping(value = "/test/users/delete/{id}", method = RequestMethod.POST)
    public void deleteUserFunction(@PathVariable(name = "id") Long id){
        //userService.deleteUser(id);
    }
}
