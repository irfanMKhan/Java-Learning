package com.reddot.ecrm.controller.cr.change_branch;

import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.enum_config.cr.add_new_number.PaymentTerm;
import com.reddot.ecrm.enum_config.cr.add_new_number.ReservationStatus;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.repository.company.CompanyRepository;
import com.reddot.ecrm.service.user.UserService;
import com.reddot.ecrm.spring_config.session.SessionManager;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/cr/changeBranch")
@RequiredArgsConstructor
public class ChangeBranchController {
    private final CompanyRepository companyRepository;
    private final UserService userService;

    @GetMapping("")
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        ReservationStatus[] reservationStatus = ReservationStatus.values();
        PaymentTerm[] paymentTerms = PaymentTerm.values();

        MDUserModel mdUserModel = SessionManager.getUserDetails(request);

        Long loggedInPICCompanyId = mdUserModel.getCOMPANY_ID();

        List<CompanyEntity> companyList = this.companyRepository.findAllByActiveAndContractStatus(true, 2);

        boolean isPICUser = false;
        if (! ObjectUtils.isEmpty(loggedInPICCompanyId)) {
            isPICUser = true;
        } else {
            model.put("company_list", companyList);
        }

        model.put("isPICUser", isPICUser);
        if (ObjectUtils.isEmpty(loggedInPICCompanyId)) {
            model.put("loggedInPICCompanyId", "-99");
        } else {
            model.put("loggedInPICCompanyId", loggedInPICCompanyId);
        }

        model.addAttribute("breadcrumb", "Change Branch Summary");
        model.put("reservation_status", reservationStatus);
        model.put("payment_terms", paymentTerms);
        model.put("title", "Change Branch");

        return "cr/change_branch/change_branch";
    }

    @GetMapping("/summary")
    public String viewPageSummary(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        ReservationStatus[] reservationStatus = ReservationStatus.values();
        PaymentTerm[] paymentTerms = PaymentTerm.values();

        List<CompanyEntity> companyList = companyRepository.findAllByActiveAndContractStatus(true, 2);


        model.put("reservation_status", reservationStatus);
        model.put("payment_terms", paymentTerms);
        model.put("company_list", companyList);
        model.addAttribute("breadcrumb", "Change Branch Summary");
        model.put("title", "Change Branch Summary");
        return "cr/change_branch/index";
    }

    @GetMapping("/summary/singleCRRequest")
    public String viewPageSingleSummary(@RequestParam("id") Long id, ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        model.addAttribute("breadcrumb", "Change Branch Summary");
        model.put("title", "Change Branch Summary Details");
        return "cr/change_branch/view";
    }

}
