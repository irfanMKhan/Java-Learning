package com.reddot.ecrm.creditCeiling;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetCreditCeilingRowByIdReqBody {
    private String creditCeilingRowID;
}
