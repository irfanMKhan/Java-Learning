package com.reddot.ecrm.controller.sr.management;

import com.reddot.ecrm.dto.sr.management.BulkSRPostModel;
import com.reddot.ecrm.dto.sr.management.TBLSRActivityModel;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.CustomActivityDTQueryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.Column;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.Map;

@RestController
public class ActivityRestController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    private CustomActivityDTQueryService customActivityDTQueryService;

    @Autowired
    private ActivityBulkUpdateService activityBulkUpdateService;

    @RequestMapping(value = "/dt/activity/activityList", method = RequestMethod.GET)
    public DataTablesOutput<TBLSRActivityModel> getActivityList(@Valid DataTablesInput input, @RequestParam(value = "customQuery", required = false) String customQuery, HttpServletRequest request,
                                                                @RequestParam(value = "customSearchCriteria", required = false) String customSearchCriteria) {
        if (isColumnSpecificSearch(input.getColumnsAsMap())) {
            customQuery = "";
        }
        if (customSearchCriteria == null) {
            customSearchCriteria = "";
        }
        return customActivityDTQueryService.findActivityList(input, customQuery, request, logger, customSearchCriteria);
    }

    @RequestMapping(value = "/dt/activity/activityList", method = RequestMethod.POST)
    public DataTablesOutput<TBLSRActivityModel> getActivityListPost(@Valid DataTablesInput input, @RequestParam(value = "customQuery", required = false) String customQuery, HttpServletRequest request,
                                                                    @RequestParam(value = "customSearchCriteria", required = false) String customSearchCriteria) {
        if (isColumnSpecificSearch(input.getColumnsAsMap())) {
            customQuery = "";
        }
        if (customSearchCriteria == null) {
            customSearchCriteria = "";
        }
        return customActivityDTQueryService.findActivityList(input, customQuery, request, logger, customSearchCriteria);
    }

    private boolean isColumnSpecificSearch(Map<String, Column> columnMap) {
        try {
            for (String key : columnMap.keySet()) {
                if (columnMap.get(key).getSearch().getValue() != null && !columnMap.get(key).getSearch().getValue().trim().isEmpty()) {
                    return true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return false;
    }

    @RequestMapping(value = "/bulk/activityUpdate", method = RequestMethod.POST)
    public CommonRestResponse resolveSRInBulk(HttpServletRequest request, @RequestBody BulkSRPostModel bulkSRPostModel) {
        return activityBulkUpdateService.updateActivityInBulk(request, bulkSRPostModel);
    }

    @RequestMapping(value = "/bulk/activityUpdateCheck", method = RequestMethod.GET)
    public CommonRestResponse getActivityUpdateCheck(HttpServletRequest request, @RequestParam("rowSpec") String rowSpec) {
        return activityBulkUpdateService.getActivityUpdateCheck(rowSpec, request);
    }

}
