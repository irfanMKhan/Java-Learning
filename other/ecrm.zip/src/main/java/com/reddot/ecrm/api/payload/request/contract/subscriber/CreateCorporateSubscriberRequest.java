package com.reddot.ecrm.api.payload.request.contract.subscriber;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.lang.String;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateCorporateSubscriberRequest implements Serializable {
  @Valid
  @NotNull(message = "Order is required.")
  private Order Order;

  @NotNull(message = "AcctId is required.")
  @NotEmpty(message = "AcctId is required.")
  private String AcctId;

  @NotNull(message = "CustId is required.")
  @NotEmpty(message = "CustId is required.")
  private String CustId;

  @Valid
  @NotNull(message = "Subscriber is required.")
  private Subscriber Subscriber;

  @Valid
  @NotNull(message = "ReqHeader is required.")
  private ReqHeader ReqHeader;

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class Order implements Serializable {
    @NotNull(message = "OrderType is required.")
    @NotEmpty(message = "OrderType is required.")
    private String OrderType;
  }

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class Subscriber implements Serializable {
    @NotNull(message = "GroupName is required.")
    @NotEmpty(message = "GroupName is required.")
    private String GroupName;

    @NotNull(message = "MaxGroupMember is required.")
    @NotEmpty(message = "MaxGroupMember is required.")
    private String MaxGroupMember;

    @Valid
    @NotNull(message = "AdditionalProperty is required.")
    private List<AdditionalProperty> AdditionalProperty;

    @Valid
    @NotNull(message = "PrimaryOffering is required.")
    private PrimaryOffering PrimaryOffering;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class PrimaryOffering implements Serializable {
      @Valid
      @NotNull(message = "OfferingId is required.")
      private OfferingId OfferingId;
      @Data
      @AllArgsConstructor
      @NoArgsConstructor
      public static class OfferingId implements Serializable {
        @NotNull(message = "OfferingId is required.")
        @NotEmpty(message = "OfferingId is required.")
        private String OfferingId;
      }
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class AdditionalProperty implements Serializable {
      @NotNull(message = "Value is required.")
      @NotEmpty(message = "Value is required.")
      private String Value;

      @NotNull(message = "Code is required.")
      @NotEmpty(message = "Code is required.")
      private String Code;
    }
  }

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class ReqHeader implements Serializable {
    @NotNull(message = "ReqTime is required.")
    @NotEmpty(message = "ReqTime is required.")
    private String ReqTime;

    @NotNull(message = "Version is required.")
    @NotEmpty(message = "Version is required.")
    private String Version;

    @NotNull(message = "Channel is required.")
    @NotEmpty(message = "Channel is required.")
    private String Channel;

    @NotNull(message = "BusinessCode is required.")
    @NotEmpty(message = "BusinessCode is required.")
    private String BusinessCode;

    @NotNull(message = "AccessPassword is required.")
    @NotEmpty(message = "AccessPassword is required.")
    private String AccessPassword;

    @NotNull(message = "PartnerId is required.")
    @NotEmpty(message = "PartnerId is required.")
    private String PartnerId;

    @NotNull(message = "OperatorId is required.")
    @NotEmpty(message = "OperatorId is required.")
    private String OperatorId;

    @NotNull(message = "BrandId is required.")
    @NotEmpty(message = "BrandId is required.")
    private String BrandId;

    @NotNull(message = "TransactionId is required.")
    @NotEmpty(message = "TransactionId is required.")
    private String TransactionId;

    @NotNull(message = "AccessUser is required.")
    @NotEmpty(message = "AccessUser is required.")
    private String AccessUser;
  }
}
