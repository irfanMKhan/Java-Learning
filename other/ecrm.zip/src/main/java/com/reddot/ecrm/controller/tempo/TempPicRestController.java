package com.reddot.ecrm.controller.tempo;


import com.google.gson.Gson;
import com.reddot.ecrm.entity.tempo.TempPic;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.tempo.TempPicService;
import com.reddot.ecrm.util.Utility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;


import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import static java.lang.Long.parseLong;

@RestController
@RequestMapping(value = "/api/temp-pic", method = RequestMethod.GET)
public class TempPicRestController {

    private final Logger logger =  LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    private TempPicService tempPicService;

    @DeleteMapping("/delete")
    public CommonRestResponse deleteTempPic(@RequestBody String temp_pic_id)
    {
        System.out.println("In controller " + parseLong(temp_pic_id));
        CommonRestResponse commonRestResponse = new CommonRestResponse(400, "Error", null);

        return tempPicService.deletePic(parseLong(temp_pic_id));
    }

    @PutMapping("/edit")
    public CommonRestResponse editTempPic(@RequestBody String editedPic)
    {
        CommonRestResponse restResponse = new CommonRestResponse();

        TempPic tempPic = new Gson().fromJson(editedPic, TempPic.class);
        System.out.println("In controller " + tempPic);



        return tempPicService.editTempPic(tempPic);
    }
    @GetMapping("/DTData")
    public DataTablesOutput<TempPic> DTData(@Valid DataTablesInput input, HttpServletRequest request,
                                            @RequestParam(value = "searchText", required = false) String customQuery,
                                            @RequestParam(value = "customSearchCriteria", required = false) String customSearchCriteria){
        if (customSearchCriteria == null) {
            customSearchCriteria = "";
        }

        if (Utility.isColumnSpecificSearch(input.getColumnsAsMap())) {
            customQuery = "";
        }
        return tempPicService.DTData(input, request, customSearchCriteria, customQuery);
    }
}
