package com.reddot.ecrm.dto.contract;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ContractReqSingleDTO {
    private Long cid;
    private String oid;
    private String ctoken;
    private String otoken;
    private String viewMode;
}
