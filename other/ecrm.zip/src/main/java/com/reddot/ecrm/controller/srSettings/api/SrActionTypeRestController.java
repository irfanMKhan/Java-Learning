package com.reddot.ecrm.controller.srSettings.api;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.model.srSettings.SrActionTypeModel;
import com.reddot.ecrm.service.srsettings.SrActionTypeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequestMapping(value = "/api/srActionType", method = RequestMethod.GET)
public class SrActionTypeRestController {

    private final Logger logger = LoggerFactory.getLogger("SR Action Type Logger");

    @Autowired
    private SrActionTypeService service;

    @GetMapping("/all")
    public Object getAllActionType() {
        return service.getAllActionType();
    }


    @GetMapping("/DTData")
    public DataTablesOutput<SrActionTypeModel> DTInteractionType(@Valid DataTablesInput input, HttpServletRequest request,
                                                                 @RequestParam(value = "searchText", required = false) String customQuery,
                                                                 @RequestParam(value = "customSearchCriteria", required = false) String customSearchCriteria) {
        return service.DTSrActionType(input, request, customSearchCriteria, customQuery);
    }

    @PostMapping("/add")
    public CommonRestResponse srActionTypeAdd(@RequestBody String srActionType, HttpServletRequest request) {
        SrActionTypeModel srActionTypeModel = new Gson().fromJson(srActionType, new TypeToken<SrActionTypeModel>() {
        }.getType());
//        SrStatusModel SrStatusModel = new Gson().fromJson(srPriority, SrStatusModel.class);
        System.err.println(srActionType);
        System.err.println(srActionTypeModel);
        return service.addSrActionTypeFunction(srActionTypeModel, request);
    }

    @GetMapping("/item")
    public CommonRestResponse getActionTypeItemById(@RequestParam("item") String id, HttpServletRequest request) {
        String actionTypeId = new Gson().fromJson(id, String.class);
        return service.getActionTypeItemById(actionTypeId);
    }

    @PostMapping("/update")
    public CommonRestResponse updateActionTypeFunction(@RequestBody String actionTypeData, HttpServletRequest request) {
//        SrStatusModel SrStatusModel = new Gson().fromJson(priorityData,SrStatusModel.class);
        SrActionTypeModel srActionTypeModel = new Gson().fromJson(actionTypeData, new TypeToken<SrActionTypeModel>() {
        }.getType());
        System.err.println(actionTypeData);
        System.err.println(srActionTypeModel);
        return service.updateActionTypeFunction(srActionTypeModel, request);
    }

}
