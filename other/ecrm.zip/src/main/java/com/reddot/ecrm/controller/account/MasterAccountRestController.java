package com.reddot.ecrm.controller.account;

import com.reddot.ecrm.dto.account.AddMasterAccountDTO;
import com.reddot.ecrm.entity.company.CompanyAccountEntity;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.company.CompanyAccountService;
import com.reddot.ecrm.service.contact.ContactService;
import com.reddot.ecrm.service.masterCorporateAccount.MasterCorporateAccountService;
import com.reddot.ecrm.util.Utility;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/account/masterAccount/rest")
public class MasterAccountRestController {
    private final ContactService contactService;
    private final CompanyAccountService companyAccountService;
    private final MasterCorporateAccountService masterCorporateAccountService;

    @GetMapping("/contacts")
    public CommonRestResponse findContactListByCompanyId(@RequestParam Long companyId) {
        CommonRestResponse response = new CommonRestResponse();
        try {
            response.setCode(200);
            response.setData(contactService.findContactListByCompanyId(companyId));
            response.setMessage("Data fetched successfully.");
        } catch (Exception e) {
            response.setCode(400);
            response.setData(new ArrayList<>());
            response.setMessage("Something went wrong.");
        }
        return response;
    }

    @PostMapping("/save")
    public CommonRestResponse save(@Valid @RequestBody AddMasterAccountDTO accountDTO, HttpServletRequest request) {
        System.out.println(accountDTO);
        CommonRestResponse response = new CommonRestResponse();
        boolean exitsAccountName = companyAccountService.existsByCompanyIdAndAccountName(accountDTO.getCompanyId(), accountDTO.getAccountName());
        boolean exitsServiceType = companyAccountService.existsByCompanyIdAndServiceTypeName(accountDTO.getCompanyId(), accountDTO.getServiceTypeName());

        if (exitsAccountName) {
            response.setCode(409);
            response.setMessage("Account name: " + accountDTO.getAccountName() + " already exists.");
        } else if (exitsServiceType) {
            response.setCode(409);
            response.setMessage("Service Type: " + accountDTO.getServiceTypeName() + " already exists.");
        } else if (!ObjectUtils.isEmpty(accountDTO.getBillMediumInfo()) && !Utility.isValidEmail(accountDTO.getBillMediumInfo())) {
            response.setCode(400);
            response.setMessage("Invalid Bill Medium Info.");
        } else {
            masterCorporateAccountService.createCorporateMasterAccount(accountDTO, request);
            //todo: service
            //create contract , then pass with proper values
            response.setCode(200);
            response.setMessage("Add Master Account Request Received Successfully.");
        }
        return response;
    }

    @GetMapping("/accountList")
    public CommonRestResponse accountList(
            @RequestParam(defaultValue = "", name = "companyId") String companyId,
            @RequestParam(defaultValue = "", name = "accountName") String accountName,
            @RequestParam(defaultValue = "", name = "accountId") String accountId,
            @RequestParam(defaultValue = "", name = "accountCode") String accountCode
    ) {

        if (ObjectUtils.isEmpty(companyId)) {
            companyId = null;
        }

        assert companyId != null;
        if (companyId.equalsIgnoreCase("-99")) {
            companyId = null;
        }

        if (ObjectUtils.isEmpty(accountName)) {
            accountName = null;
        }

        if (ObjectUtils.isEmpty(accountId)) {
            accountId = null;
        }

        if (ObjectUtils.isEmpty(accountCode)) {
            accountCode = null;
        }

        CommonRestResponse response = new CommonRestResponse();
        List<CompanyAccountEntity> companyAccountEntityList = companyAccountService.findAllParentCorporateAccount(companyId, accountName, accountId, accountCode);
        response.setData(companyAccountEntityList);
        response.setCode(200);
        response.setMessage("Data fetch successfully");

        return response;
    }

    @GetMapping("/existsServiceType")
    public CommonRestResponse checkServiceTypeExists(@RequestParam Long companyId, @RequestParam String serviceTypeName) {
        CommonRestResponse response = new CommonRestResponse();
        try {
            boolean exitsCompanyAccount = companyAccountService.existsByCompanyIdAndServiceTypeName(companyId, serviceTypeName);
            if (exitsCompanyAccount) {
                response.setCode(409);
                response.setMessage(serviceTypeName + " already exists.");
            } else {
                response.setCode(200);
                response.setMessage(serviceTypeName + "  is available.");
            }
        } catch (Exception e) {
            response.setCode(400);
            response.setMessage("Something went wrong! Please try again later.");
        }
        return response;
    }

    @GetMapping("/existsAccountName")
    public CommonRestResponse checkAccountNameExists(@RequestParam Long companyId, @RequestParam String accountName) {
        CommonRestResponse response = new CommonRestResponse();
        try {
            if (! ObjectUtils.isEmpty(accountName)) {
                boolean exitsCompanyAccount = companyAccountService.existsByCompanyIdAndAccountName(companyId, accountName);
                if (exitsCompanyAccount) {
                    response.setCode(409);
                    response.setMessage(accountName + " already exists.");
                } else {
                    response.setCode(200);
                    response.setMessage(accountName + "  is available.");
                }
            } else {
                response.setCode(200);
                response.setMessage(accountName + "  can't be empty.");
            }
        } catch (Exception e) {
            response.setCode(400);
            response.setMessage("Something went wrong! Please try again later.");
        }
        return response;
    }
}
