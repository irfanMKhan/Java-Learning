package com.reddot.ecrm.controller.cr.add_new_number;

import com.reddot.ecrm.api.SmartAxiataAPI;
import com.reddot.ecrm.entity.approval.ApprovalLogDetailsEntity;
import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.entity.cr.CRMasterEntity;
import com.reddot.ecrm.enum_config.cr.add_new_number.PaymentTerm;
import com.reddot.ecrm.enum_config.cr.add_new_number.ReservationStatus;
import com.reddot.ecrm.enum_config.feature.RequestTypeEnum;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.module.commonConfig.CommonConfig;
import com.reddot.ecrm.module.commonConfig.CommonConfigRepo;
import com.reddot.ecrm.module.deviceModel.DeviceModelRepository;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.repository.approval.ApprovalLogDetailsRepo;
import com.reddot.ecrm.repository.company.CompanyRepository;
import com.reddot.ecrm.repository.contract.ProductDetailsContractAnnexRepo;
import com.reddot.ecrm.repository.cr.CRDetailsRepo;
import com.reddot.ecrm.repository.cr.CRMSISDNDetailsRepo;
import com.reddot.ecrm.repository.msisdn.MsisdnRepository;
import com.reddot.ecrm.repository.statement_note.StatementNoteRepository;
import com.reddot.ecrm.service.approval.CommonSendingMailRequestService;
import com.reddot.ecrm.service.bulkfile.BulkFileService;
import com.reddot.ecrm.service.company.CompanyAccountService;
import com.reddot.ecrm.service.contract.CreateRequestEntityForContractAPI;
import com.reddot.ecrm.service.user.UserService;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Controller
@RequestMapping("/cr/add/newnumber")
@RequiredArgsConstructor
public class AddNewNumberController {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    private final CompanyAccountService companyAccountService;
    private final UserService userService;
    private final BulkFileService bulkFileService;
    @Autowired
    CommonConfigRepo commonConfigRepo;
    @Autowired
    DeviceModelRepository deviceModelRepository;
    @Autowired
    CommonSendingMailRequestService commonSendingMailRequestService;
    @Autowired
    CompanyRepository companyRepository;
    @Autowired
    MsisdnRepository msisdnRepository;
    @Autowired
    ProductDetailsContractAnnexRepo productDetailsContractAnnexRepo;
    @Autowired
    CRMSISDNDetailsRepo crmsisdnDetailsRepo;
    @Autowired
    SmartAxiataAPI smartAxiataAPI;
    @Autowired
    CreateRequestEntityForContractAPI contractAPI;
    @Autowired
    CommonRepository commonRepository;
    @Autowired
    CRDetailsRepo CRDetailsRepo;
    @Autowired
    ApprovalLogDetailsRepo logDetailsRepo;
    @Autowired
    private StatementNoteRepository statementNoteRepository;
    @Value("${app.base_url}")
    private String baseUrl;

    @GetMapping("/summary")
    public String viewPageSummary(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        ReservationStatus[] reservationStatus = ReservationStatus.values();
        PaymentTerm[] paymentTerms = PaymentTerm.values();

        List<CompanyEntity> companyList = companyRepository.findAllByActiveAndContractStatus(true, 2);

        model.put("reservation_status", reservationStatus);
        model.put("payment_terms", paymentTerms);
        model.put("company_list", companyList);
        model.put("baseUrl", baseUrl);
        model.addAttribute("breadcrumb", "New Number Summary");
        model.put("title", "Add New Number Summary");
        return "cr/add_new_number/add_new_numbers_summary";
    }

    @GetMapping("/summary/singleCRRequest")
    public String viewPageSingleSummary(@RequestParam("id") Long id, ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        Optional<CRMasterEntity> crMasterOptional = CRDetailsRepo.findById(id);
        if (crMasterOptional.isPresent()) {
            List<ApprovalLogDetailsEntity> logDetailsEntityList = logDetailsRepo.findAllByRequestDetailsIdAndIsActiveOrderByIdDesc(
                    crMasterOptional.get().getId(), true);
            model.put("logDetailsList", logDetailsEntityList);
        } else {
            model.put("logDetailsList", new ArrayList<>());
        }

        model.addAttribute("breadcrumb", "New Number Summary");
        model.put("title", "New Number Summary Details");
        model.put("baseUrl", baseUrl);
        return "cr/add_new_number/add_new_numbers_summary_single_view";
    }


    @GetMapping
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        ReservationStatus[] reservationStatus = ReservationStatus.values();
        PaymentTerm[] paymentTerms = PaymentTerm.values();

//        String sql = "select * from company where active=true and contract_status=2";
//        List<Map<String, Object>> companyList = (List<Map<String, Object>>) commonRepository.CommoGetData(sql);

        List<CompanyEntity> companyEntityList = companyRepository.findAllByActiveAndContractStatus(true, 2);

        //type: add new number and sub-type: special offer type
        List<CommonConfig> specialOfferType = commonConfigRepo.findAllByTypeIdAndSubTypeId(17L, 39L);
        //type: add new number and sub-type: special offer level
        List<CommonConfig> specialOfferLevel = commonConfigRepo.findAllByTypeIdAndSubTypeId(17L, 40L);

        Boolean isPIC = false;
        MDUserModel mdUserModel = Utility.CheckPICAndReturnUserDetails(request);
        Long companyId = null;
        String companyName = null;

        if (mdUserModel != null) {
            isPIC = true;
            companyId = mdUserModel.getCOMPANY_ID();
            companyName = mdUserModel.getCOMPANY_NAME().trim();
        }


        model.addAttribute("breadcrumb", "New Number Summary");
        model.put("reservation_status", reservationStatus);
        model.put("payment_terms", paymentTerms);
        model.put("company_list", companyEntityList);
        model.put("specialOfferType", specialOfferType);
        model.put("specialOfferLevel", specialOfferLevel);
        model.put("title", "Add New Number");
        model.put("requestTypeKey", RequestTypeEnum.Add_New_Number.getKey());
        model.put("requestTypeValue", RequestTypeEnum.Add_New_Number.getValue());
        model.put("isPIC", isPIC);
        model.put("companyId", companyId);
        model.put("companyName", companyName);
        model.put("baseUrl", baseUrl);

        return "cr/add_new_number/add_new_number";
    }

    @GetMapping("/test")
    @Transactional
    public String viewPageTest(ModelMap model, HttpServletRequest request) throws IOException {
        new MenuViewer().setupSideMenu(model, request);

        String test = " Hello    world.  ";
        System.out.println(test.trim().toLowerCase().replaceAll("\\s+", " ").replace(" ", "_"));
        System.out.println(test.trim().toLowerCase().replaceAll("[ ]+", " ").replace(" ", "_"));

        return "cr/add_new_number/add_new_number";
    }
}
