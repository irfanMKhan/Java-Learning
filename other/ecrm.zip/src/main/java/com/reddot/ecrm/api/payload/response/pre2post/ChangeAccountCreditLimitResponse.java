package com.reddot.ecrm.api.payload.response.pre2post;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChangeAccountCreditLimitResponse implements Serializable {
    private ChangeAccountCreditLimitRspMsg ChangeAccountCreditLimitRspMsg;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ChangeAccountCreditLimitRspMsg implements Serializable {
        private RspHeader RspHeader;

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class RspHeader implements Serializable {
            private Integer ReturnCode;

            private String ReturnMsg;

            private Integer Version;
        }
    }
}
