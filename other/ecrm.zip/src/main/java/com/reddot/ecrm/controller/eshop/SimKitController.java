package com.reddot.ecrm.controller.eshop;

import com.reddot.ecrm.service.eshop.SimKitService;
import com.reddot.ecrm.service.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/crm/simKit")
public class SimKitController {
    @Autowired
    private SimKitService simKitService;

    @Autowired
    private UserService userService;

    // we will use later if we need it
}
