package com.reddot.ecrm.api.payload.response.shared.subscriber;

import lombok.Data;

import java.io.Serializable;
import java.lang.String;

@Data
public class SubscriberLifeCycleErrorResponse implements Serializable {
  private String variables;

  private String code;

  private String message;
}
