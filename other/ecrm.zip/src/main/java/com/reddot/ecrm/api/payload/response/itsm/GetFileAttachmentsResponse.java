package com.reddot.ecrm.api.payload.response.itsm;

import lombok.Data;

import java.util.List;

@Data
public class GetFileAttachmentsResponse {
    private List<Item> items;

    private List<Link> links;
    @Data
    public static class Item {
        private String rel;

        private String href;
    }

    @Data
    public static class Link {
        private String rel;

        private String href;

        private String mediaType;
    }
}
