package com.reddot.ecrm.creditCeiling;

import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.spring_config.session.SessionManager;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping(value = "/credit_ceiling_history")
public class CreditCeilingHistoryViewController {
//    @GetMapping
//    public String viewPage(ModelMap model, HttpServletRequest request) {
//        new MenuViewer().setupSideMenu(model, request);
//        model.put("title", "Credit Ceiling List");
//        return "/credit_ceiling_history/list";
//    }

    @GetMapping("")
    public String viewCreditCeilingHistory() {
        return "redirect:/credit_ceiling_history/list";
    }

    @GetMapping("/list")
    String viewCreditCeilingHistoryList(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "Increase/Decrease Credit Ceiling Summary");
        return "/credit_ceiling_history/list";
    }

    @GetMapping("/add")
    String addCreditCeilingHistory(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        MDUserModel user = SessionManager.getUserDetails(request);

        model.put("login_name", user.getLOGIN_NAME());
        model.put("name", user.getNAME());
        model.put("logged_in_id", user.getID());

        model.put("title", "Increase/Decrease Credit Ceiling");
        return "/credit_ceiling_history/add";
    }
}
