package com.reddot.ecrm.api.payload.response.contract.customer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.lang.Integer;
import java.lang.String;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class QryCorporateEntityIdsResponse implements Serializable {
  private String GroupName;

  private String CustName;

  private String AcctId;

  private String AcctName;

  private Integer SubGroupNumber;

  private ResHeader ResHeader;

  private String CustId;

  private String AcctCode;

  private String CreatedDate;

  private String GroupCode;

  private List<SubGroups> SubGroups;

  private String GroupId;

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class ResHeader implements Serializable {
    private Integer ReturnCode;

    private String ReturnMsg;

    private String ReturnDesc;
  }

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class SubGroups implements Serializable {
    private String GroupName;

    private String AcctId;

    private String AcctName;

    private String AcctCode;

    private String GroupCode;

    private String GroupId;
  }
}
