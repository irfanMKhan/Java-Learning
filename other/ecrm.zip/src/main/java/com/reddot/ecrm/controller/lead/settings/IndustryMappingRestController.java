package com.reddot.ecrm.controller.lead.settings;

import com.reddot.ecrm.dto.lead.settings.SubIndustryDTO;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.module.commonConfig.CommonConfigRepo;
import com.reddot.ecrm.module.commonConfig.dto.CommonConfigDTO;
import com.reddot.ecrm.service.lead.settings.IndustryMappingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("lead/industryMapping")
public class IndustryMappingRestController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    private IndustryMappingService industryMappingService;

    @Autowired
    CommonConfigRepo commonConfigRepo;

    @GetMapping("/dt/all")
    public DataTablesOutput<Object> dtSubIndustry(@Valid DataTablesInput input, HttpServletRequest request,
                                                           @RequestParam(value = "searchText", required = false) String searchText, @RequestParam(value = "searchCol", required = false) String searchCol) {
        return industryMappingService.getDataTableValues(input, request, searchText, searchCol);
    }


    @PostMapping("/add-map")
    public CommonRestResponse addSubIndustryMap(HttpServletRequest request, @RequestBody SubIndustryDTO subIndustryDTO) {

        CommonRestResponse crr = new CommonRestResponse();
        crr.setCode(500);
        crr.setData(null);
        crr.setMessage("Failed to map industry & sub-industry");

        try {
            industryMappingService.AddMappedSubIndustry(request, subIndustryDTO);
            crr.setCode(200);
            crr.setData("OK");
            crr.setMessage("Successfully mapped! Redirecting to list Page");
        } catch (Exception ex){
            logger.error(ex.getMessage());
        }
        return crr;
    }

    @GetMapping("/mapped-sub-industries/{industryId}")
    public CommonRestResponse addSubIndustryMap(HttpServletRequest request, @PathVariable("industryId") Long industryIdO) {
        return industryMappingService.getAllMappedSubIndustries(request, industryIdO);
    }

}