package com.reddot.ecrm.delayPayment.rest.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PromiseToPayResponseDTO {
    private String id;
    private String transactionId;
    private String primaryIdentity;
    private String paExternalID;
    private String paType;
    private String agreedPaidDate;
    private String agreedPaidAmt;
    private String currencyId;
    private String remark;
    private String attachment;
}
