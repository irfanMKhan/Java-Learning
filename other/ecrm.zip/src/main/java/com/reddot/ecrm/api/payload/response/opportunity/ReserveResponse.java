package com.reddot.ecrm.api.payload.response.opportunity;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class ReserveResponse implements Serializable {
  private Integer code;

  private List<Data> data;

  private String message;

  private Integer timestamp;

  @lombok.Data
  public static class Data implements Serializable {
    private String iccid;

    private Integer code;

    private String release_date;

    private String correlation_id;

    private String message;

    private String msisdn;
  }
}
