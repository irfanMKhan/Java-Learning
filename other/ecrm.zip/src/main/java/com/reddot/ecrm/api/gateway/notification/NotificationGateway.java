package com.reddot.ecrm.api.gateway.notification;

import com.google.gson.Gson;
import com.reddot.ecrm.api.exception.ApiRequestException;
import com.reddot.ecrm.api.exception.InvalidAccessTokenException;
import com.reddot.ecrm.api.exception.InvalidClientCredentialException;
import com.reddot.ecrm.api.payload.request.notification.SendSMSRequest;
import com.reddot.ecrm.api.payload.response.notification.SendSMSErrorResponse;
import com.reddot.ecrm.api.payload.response.notification.SendSMSResponse;
import com.reddot.ecrm.api.security.AuthorizationGateway;
import com.reddot.ecrm.api.utility.CommonConstant;
import com.reddot.ecrm.api.utility.HttpClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@RequiredArgsConstructor
@Service
@Slf4j
public class NotificationGateway {
    @Value("${smart.igw.base.url}")
    String baseUrlIGW;
    @Value("${smart.epayment.client.code}")
    String clientCode;
    private final HttpClient httpClient;
    private final Gson gson;
    private final AuthorizationGateway authorizationGateway;

    public SendSMSResponse sendSMS(SendSMSRequest sendSmsRequest) {
        String apiUrl = baseUrlIGW + "/smsmessaging/v1/outbound/888/requests";
        String json = gson.toJson(sendSmsRequest);

        try (Response response = httpClient.post(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.CREATED.value()) {
                return gson.fromJson(response.body().string(), SendSMSResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else if (response.code() == HttpStatus.BAD_REQUEST.value()) {
                SendSMSErrorResponse errorResponse = gson.fromJson(response.body().string(), SendSMSErrorResponse.class);
                throw new ApiRequestException(errorResponse.getRequestError().getServiceException().getText());
            } else {
                log.debug("Status Code: {}, Message: {}", response.code(), response.message());
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("SendSMS Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("SendSMS Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("SendSMS Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("SendSMS Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    private Map<String, String> getIGWHeaders() {
        String bearerToken = authorizationGateway.getTokenIGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }
}
