package com.reddot.ecrm.controller.survey.survey_answer;


import com.reddot.ecrm.dto.survey.SurveyAnswerDTO;
import com.reddot.ecrm.dto.survey.SurveyParticipatedReqDTO;
import com.reddot.ecrm.entity.survey.survey_participated.ParticipatedSurveyAnswerDetailsEntity;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.survey.survey_answer.AnswerSurveyService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("/survey/answer/rest")
public class AnswerSurveyRestController {

    @Autowired
    AnswerSurveyService answerSurveyService;

    @PostMapping("/saveAllAnsData")
    public CommonRestResponse saveAllAnsData(@RequestBody SurveyAnswerDTO surveyAnswerDTO, HttpServletRequest request) {
        return answerSurveyService.saveAllAnsData(surveyAnswerDTO, request);
    }

    @PostMapping("/updateAllAnsData")
    public CommonRestResponse updateAllAnsData(@RequestBody SurveyAnswerDTO surveyAnswerDTO, HttpServletRequest request) {
        return answerSurveyService.updateAllAnsData(surveyAnswerDTO, request);
    }

    @PostMapping("/getAllAnsData")
    public List<ParticipatedSurveyAnswerDetailsEntity> getAllAnsData(@RequestBody Long surveyId, HttpServletRequest request) {
        return answerSurveyService.AnswerList(surveyId, request);
    }

    @PostMapping("/getSurveyParticipatedListByCompanyIdAndSurveyId")
    public CommonRestResponse getSurveyParticipatedListByCompanyIdAndSurveyId(@RequestBody SurveyParticipatedReqDTO surveyParticipatedReqDTO, HttpServletRequest request) {
        return answerSurveyService.getSurveyParticipatedListByCompanyIdAndSurveyId(surveyParticipatedReqDTO, request);
    }
}


