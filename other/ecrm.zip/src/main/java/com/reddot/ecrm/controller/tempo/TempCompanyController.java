package com.reddot.ecrm.controller.tempo;

import com.reddot.ecrm.entity.tempo.TempCompany;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.service.tempo.TempCompanyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.ui.ModelMap;
import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping(value = "/temp-company", method = RequestMethod.GET)
public class TempCompanyController {

    private TempCompanyService tempCompanyService;

    @Autowired
    public TempCompanyController(TempCompanyService tempCompanyService) {
        this.tempCompanyService = tempCompanyService;
    }


    @RequestMapping(value = "", method = RequestMethod.GET)
    public String TempCompanyPage(ModelMap model, HttpServletRequest request)
    {
        new MenuViewer().setupSideMenu(model, request);

        model.put("title", "Company");
        model.addAttribute("moduleName", "Company");
        model.addAttribute("title", "Company");
        model.addAttribute("breadcrumb", "Company");
        return "tempo/company_list";
    }

    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public String addCompany(ModelMap model, HttpServletRequest request)
    {
        new MenuViewer().setupSideMenu(model, request);

//        List<UserModel> userData = new ArrayList<>();
//        userData = new Gson().fromJson(Utility.ObjectToJson(userService.getUserByUserName(principal.getName())), new TypeToken<List<UserModel>>(){}
//                .getType());


//        model.addAttribute("userData", userData.get(0));
        model.addAttribute("module_name", "Company");
        model.addAttribute("title", "Add Company");
        model.addAttribute("breadcrumb", "Add");

        return "tempo/company_add";
    }

    @GetMapping("/{id}")
    public String getCompanyUpdateView(@PathVariable("id") String id, ModelMap model, HttpServletRequest request)
    {
        new MenuViewer().setupSideMenu(model, request);

        TempCompany tempCompany = tempCompanyService.getCompanyDetails(id);

        model.addAttribute("title", "Edit Company");
        model.addAttribute("breadcrumb", "Company");
        model.addAttribute("company_id", id);
        model.addAttribute("company_name", tempCompany.getName());
        model.addAttribute("company_website", tempCompany.getWebsite());


        return "tempo/company_edit";
    }

}

