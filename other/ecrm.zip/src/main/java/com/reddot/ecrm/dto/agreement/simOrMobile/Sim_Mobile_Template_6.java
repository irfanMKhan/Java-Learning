package com.reddot.ecrm.dto.agreement.simOrMobile;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class Sim_Mobile_Template_6 {
    private String monthlyFeeForCorporate_5;
    private String monthlyFeeForCorporate_8;
    private String monthlyFeeForCorporate_11;
    private String monthlyFeeForCorporate_15;
    private String monthlyFeeForCorporate_22;

    private String freeMonthlyCreditForCorporate_5;
    private String freeMonthlyCreditForCorporate_8;
    private String freeMonthlyCreditForCorporate_11;
    private String freeMonthlyCreditForCorporate_15;
    private String freeMonthlyCreditForCorporate_22;

    //for all benefit
    private String benefitsOfDataForCorporate_5;
    private String benefitsOfDataForCorporate_8;
    private String benefitsOfDataForCorporate_11;
    private String benefitsOfDataForCorporate_15;
    private String benefitsOfDataForCorporate_22;

    private String benefitsOfFreeCallsInSmartMonthlyForCorporate_5;
    private String benefitsOfFreeCallsInSmartMonthlyForCorporate_8;
    private String benefitsOfFreeCallsInSmartMonthlyForCorporate_all;

    private String benefitsOfFreeSMSInSmartMonthlyForCorporate_5;
    private String benefitsOfFreeSMSInSmartMonthlyForCorporate_8;
    private String benefitsOfFreeSMSInSmartMonthlyForCorporate_all;

    private String benefitsOfFreeCUGCallsPerDay;

    private String benefitsOfFreeSpecialNumberForCorporate_5;
    private String benefitsOfFreeSpecialNumberForCorporate_8;
    private String benefitsOfFreeSpecialNumberForCorporate_11;
    private String benefitsOfFreeSpecialNumberForCorporate_15;
    private String benefitsOfFreeSpecialNumberForCorporate_22;

    private String benefitsOfVASServiceForCorporate_all;

    //for all standards
    private String standardRatesOfClosedUserGroupCallForCorporate_all;

    private String standardRatesOfCallsWithinSmartNetworkForCorporate_5_8;
    private String standardRatesOfCallsWithinSmartNetworkForCorporate_11_15_22;

    private String standardRatesOfCallsToOtherNetworkForCorporate_all;

    private String standardRatesOfSMSWithinSmartNetworkForCorporate_5_8;
    private String standardRatesOfSMSWithinSmartNetworkForCorporate_11_15_22;

    private String standardRatesOfSMSToOtherNetworkForCorporate_all;

    private String standardRatesOfSMSToOtherCountriesInTheWorldForCorporate_all;
    private String standardRatesOfMobileNetworkPayuForCorporate_all;

    //for all add on
    private String addOnPackagesMobileInternet_1_GB_packageForCorporate_all;
    private String addOnPackagesMobileInternet_4_GB_packageForCorporate_all;
    private String addOnPackagesMobileInternet_8_GB_packageForCorporate_all;
    private String addOnPackagesMobileInternet_17_GB_packageForCorporate_all;
    private String addOnPackagesMobileInternet_26_GB_packageForCorporate_all;
    private String addOnPackagesMobileInternet_45_GB_packageForCorporate_all;


    //for all add on
    private String depositOfLocalAndInternationalCallsForCorporate_all;
    private String depositOfInternationalRoamingForCorporate_all;

    private String contractTerm;

    private String otherRatesVAS;
    private String otherRatesCallToTheWorld;
    private String contractRoaming;


}
