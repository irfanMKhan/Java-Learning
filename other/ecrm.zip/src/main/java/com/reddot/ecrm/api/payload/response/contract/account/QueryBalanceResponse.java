package com.reddot.ecrm.api.payload.response.contract.account;

import lombok.Data;

import java.io.Serializable;
import java.lang.Integer;
import java.lang.Long;
import java.lang.String;

@Data
public class QueryBalanceResponse implements Serializable {
  private QueryBalanceRspMsg QueryBalanceRspMsg;

  @Data
  public static class QueryBalanceRspMsg implements Serializable {
    private Account Account;

    private RspHeader RspHeader;

    @Data
    public static class Account implements Serializable {
      private AcctBalance AcctBalance;

      private Long AcctId;

      private AcctCreditAmt AcctCreditAmt;

      @Data
      public static class AcctBalance implements Serializable {
        private String BalanceTypeName;

        private Integer Currency;

        private String BalanceType;

        private BalanceDetail BalanceDetail;

        private Integer TotalAmount;

        private Integer IsRefund;

        private Integer IsDeposit;

        @Data
        public static class BalanceDetail implements Serializable {
          private Long EffectiveTime;

          private Long BalanceInstanceId;

          private Integer Amount;

          private Long ExpireTime;
        }
      }

      @Data
      public static class AcctCreditAmt implements Serializable {
        private Integer TotalUsageAmt;

        private Integer TotalCreditAmt;

        private Integer TotalRemainAmt;
      }
    }

    @Data
    public static class RspHeader implements Serializable {
      private Long RspTime;

      private String ReturnCode;

      private String ReturnMsg;

      private Integer Version;
    }
  }
}
