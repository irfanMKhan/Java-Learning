package com.reddot.ecrm.dto.agreement.fttx;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class FttxHtmlTemplateDTO {
    private String siteId;
    private String longAndLat;
    private String address;
    private String locatedAt;
    private String effectiveDate;

}
