package com.reddot.ecrm.deposit;

import lombok.Data;

@Data
public class ThirdPartyReqBody {
    private String companyAccountCode;
}
