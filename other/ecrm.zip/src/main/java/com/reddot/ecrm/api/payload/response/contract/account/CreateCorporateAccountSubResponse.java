package com.reddot.ecrm.api.payload.response.contract.account;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.lang.Integer;
import java.lang.Long;
import java.lang.String;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateCorporateAccountSubResponse implements Serializable {
  private CreateCorporateAcctRspMsg CreateCorporateAcctRspMsg;

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class CreateCorporateAcctRspMsg implements Serializable {
    private RspHeader RspHeader;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class RspHeader implements Serializable {
      private Long RspTime;

      private String ReturnCode;

      private String ReturnMsg;

      private Integer Version;
    }
  }
}
