package com.reddot.ecrm.controller.historyLog;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.entity.logger.APILogger;
import com.reddot.ecrm.entity.logger.APILoggerDTO;
import com.reddot.ecrm.enum_config.contract.ContractFinalStatus;
import com.reddot.ecrm.service.historyLog.APILogService;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RequestMapping(value = "/api/historyLog", method = RequestMethod.GET)
@RequiredArgsConstructor
@RestController
public class APILoggerRestController {

    private final APILogService service;

    @GetMapping("/dropdowns")
    public ResponseEntity<?> getAllStatusList(){
        Map<String, Object> response = new HashMap<>();
        response.put("statusList", service.getAllStatusList());
        response.put("featureList", service.getAllRequestTypes());

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/DT/all")
    public DataTablesOutput<APILogger> getAllDataTable(@RequestBody Map<String, Object> reqBody){
        DataTablesInput input = new Gson().fromJson(Utility.ObjectToJson(reqBody.get("input")), new TypeToken<DataTablesInput>(){}.getType());
        APILoggerDTO apiLogger = new Gson().fromJson(Utility.ObjectToJson(reqBody.get("apiLogger")), new TypeToken<APILoggerDTO>(){}.getType());

        return service.getAllDataTable(input, apiLogger);
    }
}
