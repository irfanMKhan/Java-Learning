package com.reddot.ecrm.api.payload.response.contract.group;

import lombok.Data;

import java.io.Serializable;
import java.lang.String;

@Data
public class CreateCUGGroupErrorResponse implements Serializable {
  private Error error;

  @Data
  public static class Error implements Serializable {
    private String exception;

    private String code;

    private String detail;

    private String message;
  }
}
