package com.reddot.ecrm.controller.cr.delay_payment;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.delayPayment.PromiseToPay;
import com.reddot.ecrm.delayPayment.PromiseToPayInvoiceMapping;
import com.reddot.ecrm.delayPayment.rest.dto.PromiseToPaySearchRequestDTO;
import com.reddot.ecrm.service.cr.delay_payment.DelayPaymentService;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/cr/delay-payment")
public class DelayPaymentRestController {

    private final DelayPaymentService delayPaymentService;

    @PostMapping("/DTData")
    public DataTablesOutput<PromiseToPayInvoiceMapping> DTData(@RequestBody Map<String, Object> data) throws JsonProcessingException {
        DataTablesInput input = new Gson().fromJson(Utility.ObjectToJson(data.get("dtInput")), new TypeToken<DataTablesInput>() {
        }.getType());

        ObjectMapper mapper = new ObjectMapper();
        DelayPaymentSearchReqDto searchReqDTO = mapper.readValue(data.get("searchData").toString(), DelayPaymentSearchReqDto.class);

        System.out.println(data.get("searchData"));
        return delayPaymentService.DTData(input, searchReqDTO);
    }

    @RequestMapping(value = "/search-dt", method = RequestMethod.POST)
    public DataTablesOutput<PromiseToPay> searchDT(@RequestBody Map<String, Object> data) throws IOException {
        DataTablesInput input = new Gson().fromJson(Utility.ObjectToJson(data.get("dtInput")), new TypeToken<DataTablesInput>() {
        }.getType());

        ObjectMapper mapper = new ObjectMapper();
        PromiseToPaySearchRequestDTO searchReqDTO = mapper.readValue(data.get("searchData").toString(), PromiseToPaySearchRequestDTO.class);

        return delayPaymentService.searchDT(input, searchReqDTO);
    }
}
