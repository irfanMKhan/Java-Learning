package com.reddot.ecrm.dto.agreement;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AgreementDTO {
    private String fileType;
    private String companyName;
    private String buttonName;
}
