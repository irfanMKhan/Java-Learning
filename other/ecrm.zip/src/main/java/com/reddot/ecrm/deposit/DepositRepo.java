package com.reddot.ecrm.deposit;

import com.reddot.ecrm.creditCeiling.CreditCeilingHistory;
import com.reddot.ecrm.entity.cr.CRMsisdnDetailsEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface DepositRepo extends JpaRepository<Deposit, Long>, JpaSpecificationExecutor<Deposit> {
    Page<Deposit> findById(Long id, Pageable pageable);
}
