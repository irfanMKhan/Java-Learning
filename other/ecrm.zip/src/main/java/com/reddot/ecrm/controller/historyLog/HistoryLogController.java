package com.reddot.ecrm.controller.historyLog;

import com.reddot.ecrm.menu.MenuViewer;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

@RequestMapping("/log/historyLog")
@RequiredArgsConstructor
@Controller
public class HistoryLogController {
    @GetMapping("")
    public String viewHistoryLog() {
        return "redirect:/log/historyLog/list";
    }

    @GetMapping("/list")
    String viewHistoryLogList(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        model.put("title", "History Log");
        return "log_view/history_log";
    }
}
