package com.reddot.ecrm.api.payload.response.pre2post;

import lombok.Data;

import java.io.Serializable;

@Data
public class QueryDebitnoteResponse implements Serializable {

    public String invoice_no;

    public String trans_type;

    public String acct_id;

    public String invoice_amt;

    public String open_amt;

    public String ext_trans_id;

    public String invoice_date;

    public String invoice_status;

    public String close_date;
}
