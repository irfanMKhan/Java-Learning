//package com.reddot.ecrm.api.logger.service;
//
//
//import com.google.gson.Gson;
//import com.reddot.ecrm.api.logger.repository.ApiLoggerRepository;
//import com.reddot.ecrm.api.utility.Utils;
//import com.reddot.ecrm.entity.logger.APILogger;
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.stereotype.Service;
//
//import java.math.BigInteger;
//import java.sql.Timestamp;
//import java.util.Map;
//
//@Service
//@Slf4j
//@RequiredArgsConstructor
//public class ApiLoggerServiceImpl implements ApiLoggerService {
//    private final ApiLoggerRepository apiLoggerRepository;
//    private final Gson gson;
//
//    @Override
//    public void log(String httpMethod, String channel, String correlationId, String pathInfo, Map<String, String> requestParameters, String requestBody, String response, Integer responseStatus, String remoteAddress, Timestamp requestTime, Timestamp responseTime, BigInteger elapsedTime) {
//        try {
//            APILogger apiLogger = new APILogger();
//            apiLogger.setHttpMethod(httpMethod);
//            apiLogger.setChannel(channel);
//            apiLogger.setCorrelationId(correlationId);
//            apiLogger.setPathInfo(pathInfo);
//            apiLogger.setRequestParameters(gson.toJson(requestParameters));
//            apiLogger.setRequestBody(requestBody);
//            apiLogger.setRemoteAddress(remoteAddress);
//            apiLogger.setResponse(Utils.isValidJsonString(response) ? response : gson.toJson(response));
//            apiLogger.setRequestTime(requestTime);
//            apiLogger.setResponseTime(responseTime);
//            apiLogger.setResponseStatus(responseStatus);
//            apiLogger.setElapsedTime(elapsedTime);
//
//            apiLoggerRepository.save(apiLogger);
//        } catch (Exception e) {
//            log.error(e.getMessage());
//        }
//    }
//}
