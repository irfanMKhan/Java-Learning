package com.reddot.ecrm.controller.manage_company.add_branch;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.reddot.ecrm.dto.manage_company.AddBranchDTO;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.manage_company.AddBranchService;
import lombok.RequiredArgsConstructor;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("/manageCompany/rest")
@RequiredArgsConstructor
public class AddBranchRestController {
    private final AddBranchService addBranchService;

    @GetMapping("/branchList")
    public CommonRestResponse getBranchList(
            @RequestParam(defaultValue = "", value = "companyId") String companyId,
            @RequestParam(defaultValue = "", value = "accountId", required = false) Long accountId,
            @RequestParam(defaultValue = "", value = "branchCode", required = false) String branchCode) {

        if (ObjectUtils.isEmpty(accountId) || accountId == -99) {
            accountId = null;
        }

        return addBranchService.getBranchList(companyId, accountId, branchCode);
    }

    @GetMapping("/accountList")
    public CommonRestResponse getAccountList(
            @RequestParam(defaultValue = "", name = "companyId") String companyId) {
        return addBranchService.getAccountList(Long.valueOf(companyId));
    }

    @PostMapping("/addBranch")
    public CommonRestResponse addBranch(@Valid @RequestBody AddBranchDTO addBranch) throws JsonProcessingException, ExecutionException, InterruptedException {
        return addBranchService.addBranch(addBranch);
    }
}
