package com.reddot.ecrm.delayPayment.rest.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PromiseToPayInvoiceMappingResponseDTO {
    private String id;
    private String promiseToPayId;
    private String acctKey;
    private String custKey;
    private String subKey;
    private String primaryIdentity;
    private String transType;
    private String invoiceID;
    private String invoiceNo;
    private String billCycleID;
    private String billCycleBeginTime;
    private String billCycleEndTime;
    private String invoiceAmount;
    private String openAmount;
    private String disputeAmount;
    private String currencyId;
    private String invoiceDate;
    private String dueDate;
    private String status;
    private String serviceCategory;
    private String chargeCode;
    private String chargeAmount;
    private String agreedAmount;
}
