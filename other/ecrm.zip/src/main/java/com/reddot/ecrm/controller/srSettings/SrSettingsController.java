package com.reddot.ecrm.controller.srSettings;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.srSettings.SRStatusModel;
import com.reddot.ecrm.repository.CommonRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//@Controller
//@RequestMapping("/settings/sr")
public class SrSettingsController {
    private final Logger logger = LoggerFactory.getLogger("SRSettingsLogger");

    @Autowired
    private CommonRepository commonDAO;

 /*   @GetMapping("")
    public String getUsersPage(){
        return "redirect:/users/list";
    }
*/

    @RequestMapping(value = "/status", method = RequestMethod.GET)
    public String statusController(HttpServletRequest request, ModelMap model) {
        new MenuViewer().setupSideMenu(model, request);

        //model.addAttribute("viewDataModel", empList);
        model.addAttribute("title", "SRList");
        return "settings/srSettings/status/status_list";
    }

    @RequestMapping(value = "/status/add", method = RequestMethod.GET)
    public String showAddStatusPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        SRStatusModel srStatusModel = new SRStatusModel();

        model.addAttribute("title", "Add New SR Status");
        model.addAttribute("new_status", srStatusModel);
        //model.addAttribute("menus", menuService.getAllMenu());

        return "settings/srSettings/status/status_add";
    }


    @RequestMapping(value = "/status/update")
    public String showStatusUpdatePage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

       /* List<DivisionModel> divisionList = new ArrayList<>();
        divisionList = new Gson().fromJson(Utility.ObjectToJson(divisionService.getDivisionById(id)), new TypeToken<List<DivisionModel>>() {
        }.getType());
        */
        //TODO:
//        divisionList.get(0).setMapList(divisionService.GetResponsibilityManuMapping(id.toString()));

        model.addAttribute("title", "Update SR Status");
        //model.addAttribute("division", divisionList);
        // model.addAttribute("menus", divisionService.getMenuSelectList(id.toString()));
        //model.addAttribute("mapList", responsibilityMenuMapList);

        return "settings/srSettings/status/status_update";
    }

    @RequestMapping(value = "/serviceType", method = RequestMethod.GET)
    public String serviceTypeController(HttpServletRequest request, ModelMap model) {
        new MenuViewer().setupSideMenu(model, request);

        //model.addAttribute("viewDataModel", empList);
        model.addAttribute("title", "Service Type List");
        return "settings/srSettings/service_type/service_type_list";
    }

    @RequestMapping(value = "/serviceType/add", method = RequestMethod.GET)
    public String showAddServiceTypePage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        //SRStatusModel srStatusModel = new SRStatusModel();

        model.addAttribute("title", "Add New SR Service Type");
        //model.addAttribute("new_status", srStatusModel);
        //model.addAttribute("menus", menuService.getAllMenu());

        return "settings/srSettings/service_type/service_type_add";
    }


    @RequestMapping(value = "/serviceType/update")
    public String showServiceTypeUpdatePage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

       /* List<DivisionModel> divisionList = new ArrayList<>();
        divisionList = new Gson().fromJson(Utility.ObjectToJson(divisionService.getDivisionById(id)), new TypeToken<List<DivisionModel>>() {
        }.getType());
        */
        //TODO:
//        divisionList.get(0).setMapList(divisionService.GetResponsibilityManuMapping(id.toString()));

        model.addAttribute("title", "Update SR Service Type");
        //model.addAttribute("division", divisionList);
        // model.addAttribute("menus", divisionService.getMenuSelectList(id.toString()));
        //model.addAttribute("mapList", responsibilityMenuMapList);

        return "settings/srSettings/service_type/service_type_update";
    }

//////////////////////////---------priority controller---------////////////////////

    @RequestMapping(value = "/priority", method = RequestMethod.GET)
    public String priorityController(HttpServletRequest request, ModelMap model) {
        new MenuViewer().setupSideMenu(model, request);

        //model.addAttribute("viewDataModel", empList);
        model.addAttribute("title", "Priority List");
        return "settings/srSettings/priority/priority_list";
    }

    @RequestMapping(value = "/priority/add", method = RequestMethod.GET)
    public String showAddPriorityPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        //SRStatusModel srStatusModel = new SRStatusModel();

        model.addAttribute("title", "Add New SR Priority");
        //model.addAttribute("new_status", srStatusModel);
        //model.addAttribute("menus", menuService.getAllMenu());

        return "settings/srSettings/priority/priority_add";
    }


    @RequestMapping(value = "/priority/update")
    public String showPriorityUpdatePage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

       /* List<DivisionModel> divisionList = new ArrayList<>();
        divisionList = new Gson().fromJson(Utility.ObjectToJson(divisionService.getDivisionById(id)), new TypeToken<List<DivisionModel>>() {
        }.getType());
        */
        //TODO:
//        divisionList.get(0).setMapList(divisionService.GetResponsibilityManuMapping(id.toString()));

        model.addAttribute("title", "Update SR Priority");
        //model.addAttribute("division", divisionList);
        // model.addAttribute("menus", divisionService.getMenuSelectList(id.toString()));
        //model.addAttribute("mapList", responsibilityMenuMapList);

        return "settings/srSettings/priority/priority_update";
    }

    //////////////////////////---------SR Type controller---------////////////////////

    @RequestMapping(value = "/srType", method = RequestMethod.GET)
    public String srTypeController(HttpServletRequest request, ModelMap model) {
        new MenuViewer().setupSideMenu(model, request);

        //model.addAttribute("viewDataModel", empList);
        model.addAttribute("title", "SR Type List");
        return "settings/srSettings/sr_type/sr_type_list";
    }

    @RequestMapping(value = "/srType/add", method = RequestMethod.GET)
    public String showAddSrTypePage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        //SRStatusModel srStatusModel = new SRStatusModel();

        model.addAttribute("title", "Add New SR Type");
        //model.addAttribute("new_status", srStatusModel);
        //model.addAttribute("menus", menuService.getAllMenu());

        return "settings/srSettings/sr_type/sr_type_add";
    }


    @RequestMapping(value = "/srType/update")
    public String showSrTypeUpdatePage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

       /* List<DivisionModel> divisionList = new ArrayList<>();
        divisionList = new Gson().fromJson(Utility.ObjectToJson(divisionService.getDivisionById(id)), new TypeToken<List<DivisionModel>>() {
        }.getType());
        */
        //TODO:
//        divisionList.get(0).setMapList(divisionService.GetResponsibilityManuMapping(id.toString()));

        model.addAttribute("title", "Update SR Type");
        //model.addAttribute("division", divisionList);
        // model.addAttribute("menus", divisionService.getMenuSelectList(id.toString()));
        //model.addAttribute("mapList", responsibilityMenuMapList);

        return "settings/srSettings/sr_type/sr_type_update";
    }
    //////////////////////////---------SR Action Type controller---------////////////////////

    @RequestMapping(value = "/actionType", method = RequestMethod.GET)
    public String actionTypeController(HttpServletRequest request, ModelMap model) {
        new MenuViewer().setupSideMenu(model, request);

        //model.addAttribute("viewDataModel", empList);
        model.addAttribute("title", "SR Action Type List");
        return "settings/srSettings/action_type/action_type_list";
    }

    @RequestMapping(value = "/actionType/add", method = RequestMethod.GET)
    public String showAddActionTypePage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        //SRStatusModel srStatusModel = new SRStatusModel();

        model.addAttribute("title", "Add New SR Action Type");
        //model.addAttribute("new_status", srStatusModel);
        //model.addAttribute("menus", menuService.getAllMenu());

        return "settings/srSettings/action_type/action_type_add";
    }


    @RequestMapping(value = "/actionType/update")
    public String showActionTypeUpdatePage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

       /* List<DivisionModel> divisionList = new ArrayList<>();
        divisionList = new Gson().fromJson(Utility.ObjectToJson(divisionService.getDivisionById(id)), new TypeToken<List<DivisionModel>>() {
        }.getType());
        */
        //TODO:
//        divisionList.get(0).setMapList(divisionService.GetResponsibilityManuMapping(id.toString()));

        model.addAttribute("title", "Update SR Action Type");
        //model.addAttribute("division", divisionList);
        // model.addAttribute("menus", divisionService.getMenuSelectList(id.toString()));
        //model.addAttribute("mapList", responsibilityMenuMapList);

        return "settings/srSettings/action_type/action_type_update";
    }

    /*
    SR Area
    * */
    @RequestMapping(value = "/area", method = RequestMethod.GET)
    public String areaController(HttpServletRequest request, ModelMap model) {
        new MenuViewer().setupSideMenu(model, request);


        return "srsettings/srArea";
    }
}

