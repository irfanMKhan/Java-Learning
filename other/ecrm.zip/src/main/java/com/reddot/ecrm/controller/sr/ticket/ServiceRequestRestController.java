package com.reddot.ecrm.controller.sr.ticket;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.entity.itsm.*;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.itsm.ServiceRequestService;
import com.reddot.ecrm.util.Utility;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "/api/tickets", method = RequestMethod.GET)
@RequiredArgsConstructor
public class ServiceRequestRestController {
    private final ServiceRequestService service;

    @GetMapping("/all")
    public CommonRestResponse getAllSRTickets(){
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error occurred! Please try again", null);
        try{
            List<TicketDTO> ticketDTOList = service.getAllTickets();
            commonRestResponse.setCode(200);
            commonRestResponse.setData(ticketDTOList);

            if(ticketDTOList.size() > 0){
                commonRestResponse.setMessage("List of tickets");
            }
            else {
                commonRestResponse.setMessage("No tickets found!");
            }
        }
        catch (Exception e){
            commonRestResponse.setMessage(e.getMessage());
        }
        return commonRestResponse;

    }

    @PostMapping("/DTData")
    public DataTablesOutput<TicketEntity> DTData(@RequestBody Map<String, Object> data, HttpServletRequest request) throws JsonProcessingException {
        DataTablesInput input = new Gson().fromJson(Utility.ObjectToJson(data.get("dtInput")), new TypeToken<DataTablesInput>(){}.getType());

        ObjectMapper mapper = new ObjectMapper();
        TicketSearchDto searchReqDTO = mapper.readValue(data.get("searchData").toString(), TicketSearchDto.class);

        return service.DTData(input, searchReqDTO, request);
    }

    @PostMapping("/add")
    public CommonRestResponse addNewServiceRequest(@RequestBody TicketDTO requestDTO, HttpServletRequest request){
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error occurred! Please try again", null);

        try {
            TicketEntity response = service.addNewServiceRequest(requestDTO, request);
            if (response.getId() != null) {
                commonRestResponse.setCode(HttpStatus.CREATED.value());
                commonRestResponse.setMessage("Service requested created successfully!");
                commonRestResponse.setData(response);

            } else {
                commonRestResponse.setCode(HttpStatus.Series.CLIENT_ERROR.value());
                commonRestResponse.setMessage("Failed to create service request");
                commonRestResponse.setData(null);

            }
        } catch (Exception ex){
            commonRestResponse.setCode(HttpStatus.Series.CLIENT_ERROR.value());
            commonRestResponse.setMessage(ex.getMessage());
            commonRestResponse.setData("Failed to create service request");
        }
        return commonRestResponse;
    }

    @PostMapping("/update")
    public CommonRestResponse updateServiceRequest(@RequestBody TicketDTO requestDto, HttpServletRequest request){
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error occurred! Please try again", null);
        TicketEntity response = service.updateServiceRequest(requestDto, request);
        if (response.getId()==-1){
            commonRestResponse.setCode(HttpStatus.NOT_FOUND.value());
            commonRestResponse.setMessage("Ticket number: "+requestDto.getTicketNumber() + "was not found!");
            commonRestResponse.setData(null);
        }
        else if(response==null){
            return commonRestResponse;
        }
        else{
            commonRestResponse.setMessage("Ticket updated");
            commonRestResponse.setData(response);
            commonRestResponse.setCode(HttpStatus.OK.value());
        }
        return commonRestResponse;
    }

    @PostMapping("/details")
    public CommonRestResponse getTicketDetailsByTicketNumber(@RequestBody String ticketNumber){
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error occurred! Please try again", null);
        TicketEntity response = service.getByTicketNumber(ticketNumber);
        if (response==null){
            return commonRestResponse;
        }
        if(response.getId() == -1){
            commonRestResponse.setCode(HttpStatus.NOT_FOUND.value());
            commonRestResponse.setMessage("Ticket details not found");
            commonRestResponse.setData(null);
        }
        else if(response != null){
            commonRestResponse.setCode(HttpStatus.OK.value());
            commonRestResponse.setMessage("Ticket details found!");
            commonRestResponse.setData(response);
        }
        return commonRestResponse;
    }

    @PostMapping("/synchronize")
    public ResponseEntity<?> syncTicket(@RequestBody String ticketNumber){
        return service.syncTicket(ticketNumber);
    }

    @GetMapping("/{ticketNumber}/getConversation")
    public List<ConversationEntity> getConversationByTicket(@PathVariable("ticketNumber") String ticketNumber){
        return service.getConversationByTicket(ticketNumber);
    }

    @GetMapping("/{ticketNumber}/auditTrail")
    public List<AuditTrailEntity> getAuditTrailByTicket(@PathVariable("ticketNumber") String ticketNumber){
        return service.getAuditTrailByTicket(ticketNumber);
    }

    @PostMapping("/addConversation")
    public CommonRestResponse addConversation(@RequestBody ConversationDTO conversationDTO, HttpServletRequest request){
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error occurred! Please try again", null);
        try{
            ConversationEntity conversationEntity = service.addConversation(conversationDTO, request);
            if(conversationEntity==null){
                return commonRestResponse;
            }
            else {
                commonRestResponse.setCode(200);
                commonRestResponse.setMessage("Response added successfully!");
                commonRestResponse.setData(conversationEntity);
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return commonRestResponse;
    }

    @GetMapping("/{ticket_number}/reopen")
    public CommonRestResponse reopenTicket(@PathVariable("ticket_number") String ticketNumber, HttpServletRequest request){
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error occurred! Please try again", null);
        TicketEntity result = service.reopenTicket(ticketNumber, request);
        if(result==null){
            return commonRestResponse;
        }
        else if(result.getId()==-1L){
            commonRestResponse.setCode(HttpStatus.NOT_FOUND.value());
            commonRestResponse.setMessage("Failed to reopen ticket");
            commonRestResponse.setData(null);
        }
        else {
            commonRestResponse.setCode(HttpStatus.OK.value());
            commonRestResponse.setMessage("Ticket reopened successfully!");
            commonRestResponse.setData(result);
        }
        return commonRestResponse;
    }

    @GetMapping("/{ticket_number}/sendToBo")
    public CommonRestResponse sendToBo(@PathVariable("ticket_number") String ticketNumber, HttpServletRequest request){
        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Error occurred! Please try again", null);
        TicketEntity result = service.sendToBo(ticketNumber, request);
        if(result==null){
            return commonRestResponse;
        }
        else if(result.getId()==-1L){
            commonRestResponse.setCode(HttpStatus.NOT_FOUND.value());
            commonRestResponse.setMessage("Failed to send ticket to back office");
            commonRestResponse.setData(null);
        }
        else {
            commonRestResponse.setCode(HttpStatus.OK.value());
            commonRestResponse.setMessage("Ticket successfully sent to back office!");
            commonRestResponse.setData(result);
        }
        return commonRestResponse;
    }

    @GetMapping("/{ticket_number}/attachments/list")
    public ResponseEntity<?> getAttachmentsByTicketNumber(@PathVariable(name = "ticket_number") String ticketNumber){
        List<TicketAttachmentEntity> attachmentEntities = service.getAttachmentsByTicketNumber(ticketNumber);
        if(attachmentEntities.isEmpty()){
            return new ResponseEntity<>(attachmentEntities, HttpStatus.NO_CONTENT);
        }
        else {
            return new ResponseEntity<>(attachmentEntities, HttpStatus.FOUND);
        }
    }

    @PostMapping(value = "/attachments/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> uploadFile(@RequestParam("file") List<MultipartFile> fileList, @RequestParam(required = false) String ticketDto){
        return service.itsmFileUpload(fileList, ticketDto);
    }

    @DeleteMapping("/attachments/removeFile")
    public ResponseEntity<?> removeFile(@RequestBody RemoveFileDTO removeFileDTO){
        return service.itsmRemoveFile(removeFileDTO.getAttachmentId() , removeFileDTO.getTicketNumber());
    }
}

