package com.reddot.ecrm.dto.cr.change_branch;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
public class GetAllNumberDTO {
    private String custId;
    private List<MSISDNBranchDTO> list;
}
