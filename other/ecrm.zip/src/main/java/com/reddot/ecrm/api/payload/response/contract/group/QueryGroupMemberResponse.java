package com.reddot.ecrm.api.payload.response.contract.group;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.lang.Double;
import java.lang.Integer;
import java.lang.Long;
import java.lang.String;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class QueryGroupMemberResponse implements Serializable {
  private QueryGroupMemberRspMsg QueryGroupMemberRspMsg;


  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class QueryGroupMemberRspMsg implements Serializable {
    private GroupInfo GroupInfo;

    private RspHeader RspHeader;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class GroupInfo implements Serializable {
      private String GroupName;

      private List<GroupMember> GroupMember;

      private Long AcctId;

      private Integer BusinessEntityId;

      private Long ExpireDate;

      private Long CustId;

      private Integer GroupStatus;

      private PrimaryOffering PrimaryOffering;

      private Long GroupId;

      private Double GroupNum;

      private Long EffectiveDate;

      @Data
      @AllArgsConstructor
      @NoArgsConstructor
      public static class GroupMember implements Serializable {
        private Integer MemberServiceNum;

        private String MemberType;

        private PaymentPlan PaymentPlan;

        private Long MemberSubId;

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class PaymentPlan implements Serializable {
          private Long AcctId;

          private Integer ServiceNum;

          private Long SubId;

        }
      }

      @Data
      @AllArgsConstructor
      @NoArgsConstructor
      public static class PrimaryOffering implements Serializable {
        private Long ExpireDate;

        private OfferingId OfferingId;

        private Long EffectiveDate;

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class OfferingId implements Serializable {
          private Integer OfferingId;
        }
      }
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class RspHeader implements Serializable {
      private Long RspTime;

      private String ReturnCode;

      private String ReturnMsg;

      private Integer Version;
    }
  }
}
