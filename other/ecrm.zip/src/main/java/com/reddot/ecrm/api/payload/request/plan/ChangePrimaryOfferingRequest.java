package com.reddot.ecrm.api.payload.request.plan;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;
import java.lang.String;

@Data
public class ChangePrimaryOfferingRequest implements Serializable {
  private NewPrimaryOffering NewPrimaryOffering;

  private ReqHeader ReqHeader;

  private AccessInfo AccessInfo;

  @Data
  public static class NewPrimaryOffering implements Serializable {
    private EffectiveMode EffectiveMode;

    private OfferingId OfferingId;

    @Data
    @AllArgsConstructor
    public static class EffectiveMode implements Serializable {
      private String Mode;
    }

    @Data
    @AllArgsConstructor
    public static class OfferingId implements Serializable {
      private String OfferingId;
    }
  }

  @Data
  public static class ReqHeader implements Serializable {
    private String ReqTime;

    private String Version;

    private String BusinessCode;

    private String Channel;

    private String AccessPassword;

    private String PartnerId;

    private String TransactionId;

    private String AccessUser;
  }

  @Data
  @AllArgsConstructor
  public static class AccessInfo implements Serializable {
    private String ObjectId;

    private String ObjectIdType;
  }
}
