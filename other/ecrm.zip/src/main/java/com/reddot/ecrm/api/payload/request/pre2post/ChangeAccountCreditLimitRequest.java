package com.reddot.ecrm.api.payload.request.pre2post;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChangeAccountCreditLimitRequest implements Serializable {
    private Account Account;

    private ReqHeader ReqHeader;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Account implements Serializable {
        private String AcctId;

        private String ActionType;

        private List<? extends CreditLimit> CreditLimit;
        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class CreditLimit implements Serializable {
            private String LimitType;

            private String LimitValue;

            private String EffectiveDate;
        }
    }

    @Data
    public static class ReqHeader implements Serializable {
        private String ReqTime;

        private String Version;

        private String Channel;

        private String AccessPassword;

        private String PartnerId;

        private String TransactionId;

        private String AccessUser;
    }
}
