package com.reddot.ecrm.controller.survey;

import com.reddot.ecrm.entity.survey.SurveyEntity;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.survey.SurveyService;
import com.reddot.ecrm.util.Utility;
import org.apache.poi.util.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Optional;

@RestController
@RequestMapping("/survey/rest")
public class SurveyRestController {
    @Autowired
    private SurveyService surveyService;

    @GetMapping("/DTData")
    public DataTablesOutput<SurveyEntity> DTData(@Valid DataTablesInput input, HttpServletRequest request,
                                                 @RequestParam(value = "searchText", required = false) String customQuery,
                                                 @RequestParam(value = "customSearchCriteria", required = false) String customSearchCriteria) {
        if (customSearchCriteria == null) {
            customSearchCriteria = "";
        }

        if (Utility.isColumnSpecificSearch(input.getColumnsAsMap())) {
            customQuery = "";
        }
        return surveyService.DTData(input, request, customSearchCriteria, customQuery);
    }

    @PostMapping("/saveData")
    public CommonRestResponse saveSurveyData(@RequestBody SurveyEntity survey, HttpServletRequest request) {

        return surveyService.saveSurveyData(survey, request);
    }

    @PostMapping("/editData")
    public CommonRestResponse editSurveyData(@RequestBody SurveyEntity survey, HttpServletRequest request) {

        return surveyService.editSurveyData(survey, request);
    }

    @PostMapping("/getByID")
    public CommonRestResponse getByID(@RequestBody Long id) {
        return surveyService.getByID(id);
    }

    @PostMapping("/delete")
    public CommonRestResponse deleteByID(@RequestBody Long id) {
        return surveyService.deleteById(id);
    }

    @GetMapping("/surveyList")
    public CommonRestResponse getAllActiveSurveyList() {
        return surveyService.getSurveyActiveList();
    }

    @GetMapping("/surveyList/all")
    public CommonRestResponse getAllSurveyList() {
        return surveyService.getSurveyList();
    }

    @GetMapping("/download/bulkfile")
    public ResponseEntity<?> getFile() throws IOException {
        InputStreamResource file = new InputStreamResource(new FileInputStream(Utility.survey_demo_bulk_file_location));
        String filename = Utility.survey_bulk_file_name;
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
                .contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
                .body(file);
    }

    @PostMapping("/bulk/addFileData")
    public CommonRestResponse saveBulkFileData(@RequestParam("file") MultipartFile file, HttpServletRequest request) {
        return surveyService.saveBulkFileData(file, request);
    }
}
