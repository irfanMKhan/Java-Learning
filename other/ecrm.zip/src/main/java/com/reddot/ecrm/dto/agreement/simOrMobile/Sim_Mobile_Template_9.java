package com.reddot.ecrm.dto.agreement.simOrMobile;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class Sim_Mobile_Template_9 {
    private String monthlyBenefitsMonthlyFeeFor_hybrid_3;
    private String monthlyBenefitsMonthlyFeeFor_hybrid_5;
    private String monthlyBenefitsMonthlyFeeFor_hybrid_6;
    private String monthlyBenefitsMonthlyFeeFor_hybrid_9;
    private String monthlyBenefitsMonthlyFeeFor_hybrid_15;
    private String monthlyBenefitsMonthlyFeeFor_hybrid_25;
    private String monthlyBenefitsMonthlyFeeFor_hybrid_50;
    private String monthlyBenefitsMonthlyFeeFor_hybrid_100;

    private String monthlyBenefitsPostpaidBalanceFor_hybrid_3;
    private String monthlyBenefitsPostpaidBalanceFor_hybrid_5;
    private String monthlyBenefitsPostpaidBalanceFor_hybrid_6;
    private String monthlyBenefitsPostpaidBalanceFor_hybrid_9;
    private String monthlyBenefitsPostpaidBalanceFor_hybrid_15;
    private String monthlyBenefitsPostpaidBalanceFor_hybrid_25;
    private String monthlyBenefitsPostpaidBalanceFor_hybrid_50;
    private String monthlyBenefitsPostpaidBalanceFor_hybrid_100;

    private String monthlyBenefitsFreeDataFor_hybrid_3;
    private String monthlyBenefitsFreeDataFor_hybrid_5;
    private String monthlyBenefitsFreeDataFor_hybrid_6;
    private String monthlyBenefitsFreeDataFor_hybrid_9;
    private String monthlyBenefitsFreeDataFor_hybrid_15;
    private String monthlyBenefitsFreeDataFor_hybrid_25;
    private String monthlyBenefitsFreeDataFor_hybrid_50;
    private String monthlyBenefitsFreeDataFor_hybrid_100;

    private String monthlyBenefitsOnNetCallsFor_hybrid_3;
    private String monthlyBenefitsOnNetCallsFor_hybrid_5;
    private String monthlyBenefitsOnNetCallsFor_hybrid_6;
    private String monthlyBenefitsOnNetCallsFor_hybrid_9;
    private String monthlyBenefitsOnNetCallsFor_hybrid_15;
    private String monthlyBenefitsOnNetCallsFor_hybrid_25;
    private String monthlyBenefitsOnNetCallsFor_hybrid_50;
    private String monthlyBenefitsOnNetCallsFor_hybrid_100;

    private String monthlyBenefitsOnNetSMSFor_hybrid_3;
    private String monthlyBenefitsOnNetSMSFor_hybrid_5;
    private String monthlyBenefitsOnNetSMSFor_hybrid_6;
    private String monthlyBenefitsOnNetSMSFor_hybrid_9;
    private String monthlyBenefitsOnNetSMSFor_hybrid_15;
    private String monthlyBenefitsOnNetSMSFor_hybrid_25;
    private String monthlyBenefitsOnNetSMSFor_hybrid_50;
    private String monthlyBenefitsOnNetSMSFor_hybrid_100;

    private String monthlyBenefitsCUGCallsFor_hybrid_3;
    private String monthlyBenefitsCUGCallsFor_hybrid_5;
    private String monthlyBenefitsCUGCallsFor_hybrid_6;
    private String monthlyBenefitsCUGCallsFor_hybrid_9;
    private String monthlyBenefitsCUGCallsFor_hybrid_15;
    private String monthlyBenefitsCUGCallsFor_hybrid_25;
    private String monthlyBenefitsCUGCallsFor_hybrid_50;
    private String monthlyBenefitsCUGCallsFor_hybrid_100;

    private String monthlyBenefitsPrepaidSelfTopUpFor_hybrid_all;


    private String monthlyBenefitsFreeSpecialNumberBundleFor_hybrid_3;
    private String monthlyBenefitsFreeSpecialNumberBundleFor_hybrid_5;
    private String monthlyBenefitsFreeSpecialNumberBundleFor_hybrid_6;
    private String monthlyBenefitsFreeSpecialNumberBundleFor_hybrid_9;
    private String monthlyBenefitsFreeSpecialNumberBundleFor_hybrid_15;
    private String monthlyBenefitsFreeSpecialNumberBundleFor_hybrid_25;
    private String monthlyBenefitsFreeSpecialNumberBundleFor_hybrid_50;
    private String monthlyBenefitsFreeSpecialNumberBundleFor_hybrid_100;

    private String monthlyBenefitsContractFor_hybrid_all;

    private String StandardRatesOnNetCallsFor_hybrid_all;
    private String StandardRatesOffNetCallsFor_hybrid_all;
    private String StandardRatesCallToTheWorldsFor_hybrid_all;

    private String StandardRatesOnNetSMSFor_hybrid_3_5;
    private String StandardRatesOnNetSMSFor_hybrid_6_9_15_25_50_100;

    private String StandardRatesOffNetSMSFor_hybrid_all;
    private String StandardRatesInternationalSMSFor_hybrid_all;
    private String StandardRatesDataPayuRatesFor_hybrid_all;
    private String StandardRatesBusinessCommunicationDataFor_hybrid_all;
    private String StandardRatesFreeDataFor_hybrid_all;

    private String StandardRatesCUGCallsFor_hybrid_3_5;
    private String StandardRatesCUGCallsFor_hybrid_6_9_15_25_50_100;

    private String StandardRatesInternationalRoamingFor_hybrid_all;
    private String StandardRatesChargePriorityFor_hybrid_all;

    private String DepositFor_hybrid_all;



}
