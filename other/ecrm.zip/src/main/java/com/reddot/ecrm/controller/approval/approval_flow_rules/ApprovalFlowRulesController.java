package com.reddot.ecrm.controller.approval.approval_flow_rules;

import com.reddot.ecrm.entity.approval.ApprovalFlowEntity;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.service.approval.ApprovalFlowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/approval")
public class ApprovalFlowRulesController {

    @Autowired
    ApprovalFlowService approvalFlowService;

    @GetMapping("/flow/rules")
    public String viewPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        List<ApprovalFlowEntity> list = (List<ApprovalFlowEntity>) approvalFlowService.getAllApprovalFlowData(request).getData();

        model.put("flowList", list);
        model.put("title", "Approval Flow Rules");
        model.addAttribute("breadcrumb", "Approval Flow");
        return "approval/approval_flow_rules";
    }
}
