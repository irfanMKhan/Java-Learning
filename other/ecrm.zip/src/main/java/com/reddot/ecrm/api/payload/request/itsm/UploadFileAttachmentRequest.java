package com.reddot.ecrm.api.payload.request.itsm;

import lombok.Data;

import java.io.Serializable;
import java.lang.String;

@Data
public class UploadFileAttachmentRequest implements Serializable {
  private String fileName;

  private String data;
}
