package com.reddot.ecrm.controller.UAM.menu;

import com.google.gson.Gson;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.model.menu.MDMenuModel;
import com.reddot.ecrm.service.menu.MenuService;
import com.reddot.ecrm.util.Utility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.Map;

@RestController
@RequestMapping(value = "/api/menu", method = RequestMethod.GET)
public class MenuRestController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    private MenuService service;

    @GetMapping("/DTData")
    public DataTablesOutput<MDMenuModel> DTData(@Valid DataTablesInput input, HttpServletRequest request,
                                                @RequestParam(value = "searchText", required = false) String customQuery,
                                                @RequestParam(value = "customSearchCriteria", required = false) String customSearchCriteria){
        if (customSearchCriteria == null) {
            customSearchCriteria = "";
        }

        if (Utility.isColumnSpecificSearch(input.getColumnsAsMap())) {
            customQuery = "";
        }
        return service.DTData(input, request, customSearchCriteria, customQuery);
    }

    @GetMapping("/all")
    public CommonRestResponse getAllMenu(){
        return service.getAllMenu();
    }

    @PostMapping("/addMenu")
    public CommonRestResponse addMenuFunction(@RequestBody String menuData, HttpServletRequest request){
        MDMenuModel menuModel = new Gson().fromJson(menuData, MDMenuModel.class);
        return service.addMenuFunction(menuModel, request);
    }

    @PostMapping("/update")
    public CommonRestResponse updateMenuFunction(@RequestBody String menuData, HttpServletRequest request){
        MDMenuModel menuModel = new Gson().fromJson(menuData, MDMenuModel.class);
        return service.updateMenuFunction(menuModel, request);
    }

    @GetMapping("/parentMenu/{id}")
    public CommonRestResponse parentMenu(@PathVariable(value = "id", required = false) String id ,HttpServletRequest request){
        return service.getParentMenu(id, request);
    }
    @GetMapping("/parentMenu/all")
    public CommonRestResponse allParentMenu(HttpServletRequest request){
        return service.getAllParentMenu(request);
    }

    @GetMapping("/item")
    public CommonRestResponse getMenuItemById(@RequestParam("item") String id, HttpServletRequest request){
        String menuId = new Gson().fromJson(id, String.class);
        return service.getMenuItemById(menuId);
    }

}
