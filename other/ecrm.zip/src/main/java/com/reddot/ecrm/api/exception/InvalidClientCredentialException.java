package com.reddot.ecrm.api.exception;

public class InvalidClientCredentialException extends RuntimeException {

    public InvalidClientCredentialException(String message) {
        super(message);
    }

    public InvalidClientCredentialException(String message, Throwable throwable) {
        super(message, throwable);
    }

}
