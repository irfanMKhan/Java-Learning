package com.reddot.ecrm.delayPayment.rest.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PromiseToPaySearchRequestDTO {
    private String accountCode;
    private String transType;
    private String transactionId;
    private String primaryIdentity;
    private String agreedPaidDate;
}
