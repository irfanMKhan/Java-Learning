package com.reddot.ecrm.controller.testing;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.reddot.ecrm.dto.httpServletRequest.HttpServletRequestDto;
import com.reddot.ecrm.entity.notification.NotificationEntity;
import com.reddot.ecrm.enum_config.email.email_template.EmailTemplateEnum;
import com.reddot.ecrm.repository.notification.NotificationRepo;
import com.reddot.ecrm.service.approval.ApprovalRequestService;
import com.reddot.ecrm.service.contract.implementation.ContractServiceImplementation;
import com.reddot.ecrm.service.cr.add_remove_service.AddRemoveServiceForAPI;
import com.reddot.ecrm.service.cr.increase_decrease_CL.IncreaseDecreaseCLService;
import com.reddot.ecrm.service.email.ThymleafService;
import com.reddot.ecrm.service.testing.TestingPurposeService;
import com.reddot.ecrm.spring_config.ThreadPool.SingletonThreadPool;
import com.reddot.ecrm.util.Utility;
import freemarker.template.TemplateException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

/* Notes:
1.Sharing HttpServletRequest objects between threads without proper synchronization can lead to issues
 like data corruption, race conditions, and unexpected behavior. Not thread safe.
 */
@RestController
@RequestMapping("/test")
@RequiredArgsConstructor
public class TestingPurposeRestController {

    private final ThreadPoolTaskExecutor threadPoolTaskExecutor = SingletonThreadPool.getInstance();
    private final TestingPurposeService testingService;
    private final IncreaseDecreaseCLService increaseDecreaseCLService;
    private final AddRemoveServiceForAPI addRemoveServiceForAPI;
    private final ContractServiceImplementation contractServiceImplementation;
    private final NotificationRepo notificationRepo;
    private final ApprovalRequestService approvalRequestService;
    @Autowired
    JavaMailSender javaMailSender;
    @Autowired
    ThymleafService thymleafService;
    @Value("${spring.mail.from}")
    private String emailFrom;

    @GetMapping("/mail")
    public String testMail() throws MessagingException, TemplateException, IOException {
        HttpServletRequestDto httpServletRequestDto = new HttpServletRequestDto();
        approvalRequestService.testingDemoPurposeSendMail(true, httpServletRequestDto);
        return "Ok";
    }

    @GetMapping("/mail/2")
    public String testMail2() throws MessagingException, TemplateException, IOException {
        HttpServletRequestDto httpServletRequestDto = new HttpServletRequestDto();
        approvalRequestService.testingDemoPurposeSendMail(false, httpServletRequestDto);
        return "Ok";
    }

    @GetMapping("/stage/mail")
    public String testMailStage() throws MessagingException, TemplateException, IOException {
        HttpServletRequestDto httpServletRequestDto = new HttpServletRequestDto();
        approvalRequestService.testingDemoPurposeSendMailStage(true, httpServletRequestDto);
        return "Ok";
    }

    @GetMapping("/stage/mail/2")
    public String testMail2Stage() throws MessagingException, TemplateException, IOException {
        HttpServletRequestDto httpServletRequestDto = new HttpServletRequestDto();
        approvalRequestService.testingDemoPurposeSendMailStage(false, httpServletRequestDto);
        return "Ok";
    }

    @GetMapping("/testBySamrat")
    public String test() {
        // increaseDecreaseCLService.ScheduledCreditLimitApiCall();
        addRemoveServiceForAPI.ScheduledAddRemoveServiceApiCall();
        return "Ok";
    }

    @GetMapping("/testBySamrat/test2")
    public String test2() throws MessagingException, JsonProcessingException {
        //  increaseDecreaseCLService.ScheduledForTemporaryCreditLimitApiCall();
//        addRemoveServiceForAPI.ScheduledForTemporaryCreditLimitApiCall();

        NotificationEntity notificationEntity = notificationRepo.getById(277L);

//        Gson gson = new Gson();
//        JsonParser parser = new JsonParser();
//        Map<String, Object> model = (Map<String, Object>) parser.parse(notificationEntity.getMailParameters());// response will be the json String

        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> mapData = mapper.readValue(notificationEntity.getMailParameters(), new TypeReference<Map<String, Object>>() {
        });

        Map<String, Object> model = new HashMap<>();
        model.put("title", notificationEntity.getNotificationTitle());
        model.put("customerName", mapData.get("Customer"));
        model.put("contractNumber", mapData.get("Contract Number"));
        model.put("paymentMap", mapData.get("detailsMapData"));
        MimeMessage message = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED, StandardCharsets.UTF_8.name());
        helper.setText(thymleafService.createContent(EmailTemplateEnum.Contract_Products_Template.getTemplateName(), model), true);

        String mailBody = thymleafService.createContent(EmailTemplateEnum.Contract_Products_Template.getTemplateName(), model);
        helper.setFrom(emailFrom);
        String[] recipientList = notificationEntity.getRecipientEmailAddress().split(",");
        helper.setTo(recipientList);
        String[] recipientCCList = notificationEntity.getRecipientCCEmailList().split(",");
        if (recipientCCList.length > 0) {
            helper.setCc(recipientCCList);
        }
        helper.setSubject(notificationEntity.getNotificationTitle());

        javaMailSender.send(message);
        //todo: need to update status

        return "Ok";
    }

    @GetMapping("/testBySamrat/test3")
    public String test3() throws MessagingException, JsonProcessingException {
        //  increaseDecreaseCLService.ScheduledForTemporaryCreditLimitApiCall();
//        addRemoveServiceForAPI.ScheduledForTemporaryCreditLimitApiCall();

        NotificationEntity notificationEntity = notificationRepo.getById(270L);

//        Gson gson = new Gson();
//        JsonParser parser = new JsonParser();
//        Map<String, Object> model = (Map<String, Object>) parser.parse(notificationEntity.getMailParameters());// response will be the json String

        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> mapData = mapper.readValue(notificationEntity.getMailParameters(), new TypeReference<Map<String, Object>>() {
        });

        Map<String, Object> model = new HashMap<>();
        model.put("title", notificationEntity.getNotificationTitle());
        model.put("detailsMap", mapData);
        MimeMessage message = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED, StandardCharsets.UTF_8.name());
        helper.setText(thymleafService.createContent(EmailTemplateEnum.Contract_Template.getTemplateName(), model), true);

        String mailBody = thymleafService.createContent(EmailTemplateEnum.Contract_Template.getTemplateName(), model);
        helper.setFrom(emailFrom);
        String[] recipientList = notificationEntity.getRecipientEmailAddress().split(",");
        helper.setTo(recipientList);
        String[] recipientCCList = notificationEntity.getRecipientCCEmailList().split(",");
        if (recipientCCList.length > 0) {
            helper.setCc(recipientCCList);
        }
        helper.setSubject(notificationEntity.getNotificationTitle());

        javaMailSender.send(message);

        //todo: need to update status


        return "Ok";
    }

    @PostMapping("/mandatory/offeringId")
    public void testAddMandatoryOfferingId(@RequestParam("file") MultipartFile file) throws IOException {
//        File tempFile = new File(file.getOriginalFilename());
//        try {
//            tempFile.createNewFile();
//            FileOutputStream fos = new FileOutputStream(tempFile);
//            fos.write(file.getBytes());
//            fos.close();
//        }catch (Exception e){
//
//        }
        // MultipartFile file1 = file;

        //todo: problem facing reading excel file in multipart in req. tomcat server can not delete tmpfile.
        //todo: need to copy and then send that is one solution
        testingService.addMandatoryOfferingFileData(file);
        return;
    }

    @GetMapping("/multi-thread")
    public void testMultiThread(HttpServletRequest request) throws ExecutionException, InterruptedException {
        //HttpServletRequest are not thread safe so we create dto to store request information.
        HttpServletRequestDto httpServletRequestDto = Utility.createHttpServletDTO(request);
        //we can use this dto insted of request in multithread

        if (httpServletRequestDto == null) {
            httpServletRequestDto = new HttpServletRequestDto();
        }

        for (int i = 1; i <= 10; i++) {
            int finalI = i;
            //which have return type
            CompletableFuture<Integer> completableFuture = CompletableFuture.supplyAsync(() -> {
                System.out.println("Thread Loop 1: " + Thread.currentThread().getName());
                try {
                    Thread.sleep(1000);
                    return helperFunctionDemo(finalI);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }

            }, threadPoolTaskExecutor);
        }

        for (int i = 20; i <= 30; i++) {
            int finalI = i;
            //which have no return type, though here helperFunctionDemo return int, we can skip the return
            CompletableFuture<Void> completableFuture = CompletableFuture.supplyAsync(() -> {
                System.out.println("Thread  Loop 2: " + Thread.currentThread().getName());
                try {
                    Thread.sleep(2000);
                    helperFunctionDemoVoid(finalI);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                return null;
            }, threadPoolTaskExecutor);
        }


        for (int i = 20; i <= 30; i++) {
            int finalI = i;
            //can run code in the CompletableFuture,
            CompletableFuture<Void> completableFuture = CompletableFuture.supplyAsync(() -> {
                System.out.println("Thread Loop 3: " + Thread.currentThread().getName());
                try {
                    Thread.sleep(3000);
                    System.out.println("..... another loop 3...." + finalI);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                return null;
            }, threadPoolTaskExecutor);
        }

        //supplyAsync produces a result though it is "Void" we need to return something here null.
        CompletableFuture<Void> completableFuture = CompletableFuture.supplyAsync(() -> {
            System.out.println("Thread No Loop: " + Thread.currentThread().getName());
            try {
                //Thread.sleep(4000);
                System.out.println("..... Nooooo loop ....");
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
            return null;  //return needed though it is void because supplyAsync used.
        }, threadPoolTaskExecutor);


        // runAsync doesn't produce any result, Void type
        CompletableFuture<Void> completableFuture2 = CompletableFuture.runAsync(() -> {
            System.out.println("Thread No Loop Run Async: " + Thread.currentThread().getName());
            try {
                //Thread.sleep(4000);
                System.out.println("..... Nooooo loop Using Run Async ....");
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }, threadPoolTaskExecutor);

    }

    @GetMapping("/multi-thread/getResult")
    public Integer testMultiThreadAndGetResult() throws ExecutionException, InterruptedException {
        CompletableFuture<Integer> completableFuture2 = CompletableFuture.supplyAsync(() -> {
            System.out.println("Blocking by .get() and Return Thread : " + Thread.currentThread().getName());
            try {
                Thread.sleep(6000);
                return helperFunctionDemo(1000);
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
            return null;
        }, threadPoolTaskExecutor);

        //.get() is a blocking method. ---> loader will loading...and hold the request...
        // after getting value it will realise the request
        // It will block the current thread until the result of the CompletableFuture is available.
        Integer x = completableFuture2.get(); //x will be 1100
        System.out.println("Blocking and Return value: ");
        System.out.println(x);
        return x;
    }


    public int helperFunctionDemo(int finalI) {
        System.out.println("....loop 1......" + finalI);
        return finalI + 100;
    }

    public void helperFunctionDemoVoid(int finalI) {
        System.out.println(".... another ....loop 2...." + finalI);

    }


}


// // increaseDecreaseCLService.ScheduledCreditLimitApiCall();
//        CommonRestResponse commonRestResponse1 = contractServiceImplementation.getContractDetailsDataById(null, null,
//                "ES2023-008898");
//        HttpServletRequestDto requestDto = new HttpServletRequestDto();
//        requestDto.setCreatedBy(2L);
//        requestDto.setCreatedUsername("Samrat Alam");
//        ContractDTO contractDTO = (ContractDTO) commonRestResponse1.getData();
//        contractDTO.setRequestDTO(requestDto);
//        CommonRestResponse commonRestResponse = new CommonRestResponse(500, "Failed Due to .....", null);
//        //  contractServiceImplementation.SendNotificationForContract(commonRestResponse, contractDTO);
//        contractServiceImplementation.SendNotificationForProducts(contractDTO);


