package com.reddot.ecrm.api.payload.request.contract.account;

import com.reddot.ecrm.api.payload.request.contract.customer.CreateCorporateCustomerRequest;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.lang.String;
import java.util.List;

@Data
public class CreateCorporateAccountRequest implements Serializable {
  @Valid
  @NotNull(message = "Account is required.")
  private Account Account;

  @NotNull(message = "CustId is required.")
  @NotEmpty(message = "CustId is required.")
  private String CustId;

  @Valid
  @NotNull(message = "ReqHeader is required")
  private ReqHeader ReqHeader;


  @Data
  public static class Account implements Serializable {
    @Valid
    @NotNull(message = "Address is required.")
    private List<Address> Address;

    @NotNull(message = "BillCycleType is required.")
    @NotEmpty(message = "BillCycleType is required.")
    private String BillCycleType;

    @Valid
    @NotNull(message = "CreditLimit is required.")
    private List<CreditLimit> CreditLimit;

    @NotNull(message = "Title is required.")
    @NotEmpty(message = "Title is required.")
    private String Title;

    @NotNull(message = "InitialBalance is required.")
    @NotEmpty(message = "InitialBalance is required.")
    private String InitialBalance;

    @Valid
    @NotNull(message = "Name is required.")
    private Name Name;

    @Valid
    @NotNull(message = "Contact is required.")
    private List<Contact> Contact;

    @NotNull(message = "AcctName is required.")
    @NotEmpty(message = "AcctName is required.")
    private String AcctName;

    @NotNull(message = "Currency is required.")
    @NotEmpty(message = "Currency is required.")
    private String Currency;

    @NotNull(message = "AcctPayMethod is required.")
    @NotEmpty(message = "AcctPayMethod is required.")
    private String AcctPayMethod;

    @Valid
    @NotNull(message = "BillMedium is required.")
    private List<BillMedium> BillMedium;

    @NotNull(message = "PaymentType is required.")
    @NotEmpty(message = "PaymentType is required.")
    private String PaymentType;

    @Valid
    @NotNull(message = "AdditionalProperty is required.")
    private List<AdditionalProperty> AdditionalProperty;

    @NotNull(message = "BillLanguage is required.")
    @NotEmpty(message = "BillLanguage is required.")
    private String BillLanguage;

    @Data
    public static class Address implements Serializable {
      @NotNull(message = "Address7 - House No is required.")
      @NotEmpty(message = "Address7 - House No is required.")
      private String Address7;

      @NotNull(message = "Address11 - Commune is required.")
      @NotEmpty(message = "Address11 - Commune is required.")
      private String Address11;

      @NotNull(message = "Address5 - Street is required.")
      @NotEmpty(message = "Address5 - Street is required.")
      private String Address5;

      @NotNull(message = "Address2 - Province is required.")
      @NotEmpty(message = "Address2 - Province is required.")
      private String Address2;

      @NotNull(message = "Address3 - Sangkat is required.")
      @NotEmpty(message = "Address3 - Sangkat is required.")
      private String Address3;

      @NotNull(message = "Address1 - Nationality Code is required.")
      @NotEmpty(message = "Address1 - Nationality Code is required.")
      private String Address1;

      @NotNull(message = "AddressType is required.")
      @NotEmpty(message = "AddressType is required.")
      private String AddressType;
    }

    @Data
    public static class CreditLimit implements Serializable {
      @NotNull(message = "LimitType is required.")
      @NotEmpty(message = "LimitType is required.")
      private String LimitType;

      @NotNull(message = "LimitValue is required.")
      @NotEmpty(message = "LimitValue is required.")
      private String LimitValue;
    }

    @Data
    public static class Name implements Serializable {
      @Size(max = 64, message = "FirstName is too long.")
      private String FirstName;

      @Size(max = 64, message = "LastName is too long.")
      private String LastName;

      private String MiddleName;
    }

    @Data
    public static class Contact implements Serializable {
      @NotNull(message = "ContactType is required.")
      @NotEmpty(message = "ContactType is required.")
      private String ContactType;

      @NotNull(message = "Email is required.")
      @NotEmpty(message = "Email is required.")
      private String Email;

      @NotNull(message = "Priority is required.")
      @NotEmpty(message = "Priority is required.")
      private String Priority;

      @NotNull(message = "Title is required.")
      @NotEmpty(message = "Title is required.")
      private String Title;

      @NotNull(message = "MobilePhone is required.")
      @NotEmpty(message = "MobilePhone is required.")
      private String MobilePhone;

      @Valid
      @NotNull(message = "Name is required.")
      private Name Name;
    }

    @Data
    public static class BillMedium implements Serializable {
      @NotNull(message = "BillMediumId is required.")
      @NotEmpty(message = "BillMediumId is required.")
      private String BillMediumId;

      @NotNull(message = "BillMediumCode is required.")
      @NotEmpty(message = "BillMediumCode is required.")
      private String BillMediumCode;

      @NotNull(message = "BillContentType is required.")
      @NotEmpty(message = "BillContentType is required.")
      private String BillContentType;

      @NotNull(message = "BillMediumInfo is required.")
      @NotEmpty(message = "BillMediumInfo is required.")
      private String BillMediumInfo;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class AdditionalProperty implements Serializable {
      @NotEmpty(message = "Value is required.")
      @NotNull(message = "Value is required.")
      private String Value;

      @NotEmpty(message = "Code is required.")
      @NotNull(message = "Code is required.")
      private String Code;
    }
  }

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class ReqHeader implements Serializable {
    @NotNull(message = "ReqTime is required.")
    @NotEmpty(message = "ReqTime is required.")
    private String ReqTime;

    @NotNull(message = "Version is required.")
    @NotEmpty(message = "Version is required.")
    private String Version;

    @NotNull(message = "Channel is required.")
    @NotEmpty(message = "Channel is required.")
    private String Channel;

    @NotNull(message = "AccessPassword is required.")
    @NotEmpty(message = "AccessPassword is required.")
    private String AccessPassword;

    @NotNull(message = "PartnerId is required.")
    @NotEmpty(message = "PartnerId is required.")
    private String PartnerId;

    @NotNull(message = "TransactionId is required.")
    @NotEmpty(message = "TransactionId is required.")
    private String TransactionId;

    @NotNull(message = "AccessUser is required.")
    @NotEmpty(message = "AccessUser is required.")
    private String AccessUser;
  }
}
