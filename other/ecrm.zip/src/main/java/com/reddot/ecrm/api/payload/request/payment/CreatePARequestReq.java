package com.reddot.ecrm.api.payload.request.payment;

import lombok.Data;

import java.io.Serializable;

@Data
public class CreatePARequestReq implements Serializable {
  private CreatePARequestMsg CreatePARequestMsg;

  @Data
  public static class CreatePARequestMsg implements Serializable {
    private CreatePARequest CreatePARequest;

    @Data
    public static class CreatePARequest implements Serializable {
      private AcctAccessCode AcctAccessCode;

      private String PAExternalID;

      private Integer PAType;

      private String PARequestDate;

      private String TotalPAAmount;

      private PADetailInfo PADetailInfo;

      private PAInvoiceInfo PAInvoiceInfo;

      private String PAReminderFlag;

      @Data
      public static class PAInvoiceInfo implements Serializable {
        private String InvoiceNo;
      }

      @Data
      public static class AcctAccessCode implements Serializable {
        private String PrimaryIdentity;
      }

      @Data
      public static class PADetailInfo implements Serializable {
        private String AgreedPaidDate;

        private String AgreedPaidAmt;

        private String CurrencyId;

        private String Remark;
      }
    }
  }

  private String transaction_id;
}
