package com.reddot.ecrm.api.gateway.pre2post;


import com.reddot.ecrm.api.exception.ApiRequestException;
import com.reddot.ecrm.api.exception.InvalidAccessTokenException;
import com.reddot.ecrm.api.exception.InvalidClientCredentialException;
import com.reddot.ecrm.api.payload.request.pre2post.BssSubscribersPrepaidToPostpaidRequest;
import com.reddot.ecrm.api.payload.response.contract.customer.CBSBCCustomerErrorResponse;
import com.reddot.ecrm.api.payload.response.pre2post.BssSubscribersPrepaidToPostpaidResponse;

import com.google.gson.Gson;
import com.reddot.ecrm.api.payload.response.pre2post.PrepaidToPostpaidResponse;
import com.reddot.ecrm.api.security.AuthorizationGateway;
import com.reddot.ecrm.api.utility.CommonConstant;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import com.reddot.ecrm.api.utility.HttpClient;
import java.util.HashMap;
import java.util.Map;

;

@Service
@Slf4j
@RequiredArgsConstructor
public class PrepaidToPostpaidGateway {

    private final HttpClient httpClient;

    private final Gson gson;

    private final AuthorizationGateway authorizationGateway;

    @Value("${smart.egw.base.url}")
    String baseUrlEGW;

    @Value("${smart.igw.base.url}")
    String baseUrlIGW;

    public PrepaidToPostpaidResponse bssSubscribersPrepaidToPostpaid(String subscriberId, BssSubscribersPrepaidToPostpaidRequest bssSubscribersPrepaidToPostpaidRequest) {
        String apiUrl = baseUrlIGW + "/api/bss/1207/subscribers/v2/" + subscriberId + "/change-prepaid-to-postpaid?id_type=msisdn";
        String json = gson.toJson(bssSubscribersPrepaidToPostpaidRequest);
        PrepaidToPostpaidResponse prepaidToPostpaidResponse = new PrepaidToPostpaidResponse();

        try (Response response = httpClient.put(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                BssSubscribersPrepaidToPostpaidResponse bssSubscribersPrepaidToPostpaidResponse =
                        gson.fromJson(response.body().string(), BssSubscribersPrepaidToPostpaidResponse.class);
                prepaidToPostpaidResponse.setSuccess(true);
                prepaidToPostpaidResponse.setCode("0000");
                prepaidToPostpaidResponse.setMessage(bssSubscribersPrepaidToPostpaidResponse.getTransaction_status());

            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                CBSBCCustomerErrorResponse errorResponse = gson.fromJson(response.body().string(), CBSBCCustomerErrorResponse.class);
                prepaidToPostpaidResponse.setSuccess(false);
                prepaidToPostpaidResponse.setCode(errorResponse.getCode());
                prepaidToPostpaidResponse.setMessage(errorResponse.getMessage());
            }

            return prepaidToPostpaidResponse;
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("BssSubscribersPrepaidToPostpaidRequest Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("BssSubscribersPrepaidToPostpaidRequest Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialException) {
                log.debug("BssSubscribersPrepaidToPostpaidRequest Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialException(e.getMessage());
            }
            log.error("BssSubscribersPrepaidToPostpaidRequest Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    private Map<String, String> getHeaders() {
        String bearerToken = authorizationGateway.getTokenEGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }

    private Map<String, String> getIGWHeaders() {
        String bearerToken = authorizationGateway.getTokenIGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }

}
