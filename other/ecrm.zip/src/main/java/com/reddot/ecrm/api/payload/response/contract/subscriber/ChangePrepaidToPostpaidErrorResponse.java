package com.reddot.ecrm.api.payload.response.contract.subscriber;

import lombok.Data;

import java.io.Serializable;
import java.lang.String;

@Data
public class ChangePrepaidToPostpaidErrorResponse implements Serializable {
  private String variables;

  private String code;

  private String message;
}
