package com.reddot.ecrm.controller.lead.quotation;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.dto.lead.LeadDto;
import com.reddot.ecrm.dto.lead.quotation.QuotationDto;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.model.User.UserModel;
import com.reddot.ecrm.module.primaryOffering.PrimaryOfferingService;
import com.reddot.ecrm.service.lead.LeadContactService;
import com.reddot.ecrm.service.lead.LeadService;
import com.reddot.ecrm.service.lead.quotation.QuotationDetailsService;
import com.reddot.ecrm.service.lead.quotation.QuotationService;
import com.reddot.ecrm.service.user.UserService;
import com.reddot.ecrm.spring_config.session.SessionManager;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/quotation")
public class QuotationController {
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private QuotationService quotationService;
    
    @Autowired
    private QuotationDetailsService quotationDetailsService;
    
    @Autowired
    private LeadService leadService;
    
    @Autowired
    private LeadContactService leadContactService;
    
    @Autowired
    private PrimaryOfferingService primaryOfferingService;
    
    @RequestMapping(value = "", method = RequestMethod.GET)
    public String viewQuotations(ModelMap model, HttpServletRequest request, @RequestParam(value = "lead_num", required = false) String leadNum) {
        new MenuViewer().setupSideMenu(model, request);
        
        model.addAttribute("title", "Quotations");
        model.addAttribute("breadcrumb", "Quotations");
        model.addAttribute("lead_num", leadNum);
        
        if (leadNum != null) {
            LeadDto selectedLead = leadService.getLeadByLeadNumber(leadNum);
            
            if (selectedLead != null) {
                model.addAttribute("selectedLeadId", selectedLead.getId());
            }
        }
        
        return "lead/quotation/quotation_list";
    }
    
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public String addQuotation(@RequestParam(value = "leadNumber", required = false) String leadNumber, ModelMap model,
                               HttpServletRequest request, Principal principal) {
        new MenuViewer().setupSideMenu(model, request);
        
        if (leadNumber != null) {
            LeadDto leadDto = leadService.getLeadByLeadNumber(leadNumber);
            
            if (leadDto != null) {
                model.addAttribute("lead", leadDto);
            }
        }
        
        MDUserModel user = SessionManager.getUserDetails(request);
        
        model.addAttribute("senderName", user.getNAME());
        model.addAttribute("senderPhone", user.getWORK_PHONE());
        model.addAttribute("senderEmail", user.getEMAIL());
        
        model.addAttribute("title", "Add Quotation");
        model.addAttribute("breadcrumb", "Add");
        
        return "lead/quotation/quotation_add";
    }
    
    @RequestMapping(value = "/edit/{quotationNumber}", method = RequestMethod.GET)
    public String editQuotation(ModelMap model, HttpServletRequest request, Principal principal,
                                @PathVariable("quotationNumber") String quotationNumber) {
        new MenuViewer().setupSideMenu(model, request);
        
        QuotationDto quotationDto = quotationService.getQuotationByQuotationNumber(quotationNumber);
        
        if (quotationDto != null) {
            
            model.addAttribute("quotation", quotationDto);
            
            model.addAttribute("title", "Edit Quotation");
            model.addAttribute("breadcrumb", "Edit");
            
            return "lead/quotation/quotation_edit";
        } else {
            return null;
        }
    }
    
}