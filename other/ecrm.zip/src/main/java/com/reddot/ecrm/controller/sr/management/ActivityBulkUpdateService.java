package com.reddot.ecrm.controller.sr.management;


import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm.dto.sr.management.BulkSRObjectModel;
import com.reddot.ecrm.dto.sr.management.BulkSRPostModel;
import com.reddot.ecrm.dto.sr.management.TBLSRActivityModel;
import com.reddot.ecrm.dto.sr.management.TBLSRModel;
import com.reddot.ecrm.dto.srsettings.RoutingGroup.SRRoutingGroupModel;
import com.reddot.ecrm.model.CommonLovModel;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.model.User.MDUserModel;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.session.SessionConstants;
import com.reddot.ecrm.spring_config.session.SessionManager;
import com.reddot.ecrm.util.Utility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

@Service
public class ActivityBulkUpdateService {

    private final Logger logger = LoggerFactory.getLogger("SRSettingsLogger");
//    ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

    @Autowired
    private CommonRepository commonDAO;

    public CommonRestResponse updateActivityInBulk(HttpServletRequest request, BulkSRPostModel bulkSRPostModel) {
        CommonRestResponse commonRestResponse = new CommonRestResponse();
        int successUpdateCount = 0;
        int failedUpdateCount = 0;

        try {
            MDUserModel mdUserModel = SessionManager.getUserDetails(request);
            Map<String, Object> updateData = new HashMap<String, Object>();
            long timeStamp = Utility.getCurrentTimestamp();

            String modStatus = "";
            String modComments = "";
            String modDescription = "";

            if (bulkSRPostModel.getEditItems().isEmpty()) {
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("No update items found. Please try with valid filed inputs.");
                return commonRestResponse;
            } else {
                for (BulkSRObjectModel bulkSRObjectModel : bulkSRPostModel.getEditItems()) {
                    switch (bulkSRObjectModel.getItemId()) {
                        case "4":
                            modStatus = bulkSRObjectModel.getItemValue();
                            break;
                        case "7":
                            modComments = bulkSRObjectModel.getItemValue();
                            break;
                        case "6":
                            modDescription = bulkSRObjectModel.getItemValue();
                            break;
                    }
                }
            }

            if (modStatus.isEmpty() && modComments.isEmpty() && modDescription.isEmpty()) {
                commonRestResponse.setCode(404);
                commonRestResponse.setMessage("No update items found. Please try with valid filed inputs.");
                return commonRestResponse;
            }

//            String query = "SELECT * FROM " + Utility.tbl_sr_activity + " " + SessionManager.getAttribute(SessionConstants.ACTIVITY_LAST_QUERY.name(), request) + " OFFSET 0 ROWS FETCH NEXT 250 ROWS ONLY";
            String query = "SELECT * FROM " + Utility.tbl_sr_activity + " WHERE STATUS_ID NOT IN (61,263,269,302) AND (OWNER_GROUP_ID=" + mdUserModel.getPOSITION_ID() + " OR CREATED_BY_GROUP_ID=" + mdUserModel.getPOSITION_ID() + ") " +
                    " AND ID IN (SELECT ID FROM " + Utility.tbl_sr_activity + SessionManager.getAttribute(SessionConstants.ACTIVITY_LAST_QUERY.name(), request) + " OFFSET 0 ROWS FETCH NEXT 250 ROWS ONLY)";

            if (bulkSRPostModel.getRowSpec() != null && !bulkSRPostModel.getRowSpec().isEmpty() && bulkSRPostModel.getRowSpec().equalsIgnoreCase("onlyVisibleRow")) {
//                query = "SELECT * FROM " + Utility.tbl_sr_activity + " " + SessionManager.getAttribute(SessionConstants.ACTIVITY_LAST_QUERY.name(), request) + SessionManager.getAttribute(SessionConstants.ACTIVITY_LAST_QUERY_PAGINATION.name(), request);
                query = "SELECT * FROM " + Utility.tbl_sr_activity + " WHERE STATUS_ID NOT IN (61,263,269,302) AND (OWNER_GROUP_ID=" + mdUserModel.getPOSITION_ID() + " OR CREATED_BY_GROUP_ID=" + mdUserModel.getPOSITION_ID() + ") " +
                        " AND ID IN (SELECT ID FROM " + Utility.tbl_sr_activity + SessionManager.getAttribute(SessionConstants.ACTIVITY_LAST_QUERY.name(), request) + SessionManager.getAttribute(SessionConstants.ACTIVITY_LAST_QUERY_PAGINATION.name(), request) + ")";
            }
            logger.info("Bulk query: " + query);
            Object listObject = commonDAO.CommoGetData(query);
            List<TBLSRActivityModel> activityList = new Gson().fromJson(Utility.ObjectToJson(listObject), new TypeToken<List<TBLSRActivityModel>>() {
            }.getType());

            if (activityList.isEmpty()) {
                commonRestResponse.setCode(404);
                commonRestResponse.setMessage("No activity found");
                return commonRestResponse;
            }

            String newStatusId = "";

            if (!modStatus.isEmpty()) {
                String statusQuery = "SELECT ID,NAME FROM " + Utility.tbl_sr_activity_lov + " WHERE TYPE_ID = '3' AND ACTIVE = '1' AND NAME='" + modStatus + "'";
                Object statusObject = commonDAO.CommoGetData(statusQuery);
                List<CommonLovModel> statusModelList = new Gson().fromJson(Utility.ObjectToJson(statusObject), new TypeToken<List<CommonLovModel>>() {
                }.getType());

                if (statusModelList.isEmpty()) {
                    commonRestResponse.setCode(500);
                    commonRestResponse.setMessage("Status name is invalid. Please try with valid status");
                    return commonRestResponse;
                }

                newStatusId = statusModelList.get(0).getID();
            }


            for (TBLSRActivityModel activityModel : activityList) {
                try {
                    //Restriction on old status
                    if (activityModel.getSTATUS_NAME() != null && (activityModel.getSTATUS_NAME().equalsIgnoreCase("Cancelled")
                            || activityModel.getSTATUS_NAME().equalsIgnoreCase("Closed")
                            || activityModel.getSTATUS_NAME().equalsIgnoreCase("Done")
                            || activityModel.getSTATUS_NAME().equalsIgnoreCase("Completed"))) {
                        failedUpdateCount++;
                        continue;
                    }

                    updateData.clear();
                    if (!modStatus.isEmpty()) {
                        updateData.put("STATUS_ID", newStatusId);
                        updateData.put("STATUS_NAME", modStatus);
                    }

                    if (modComments != null && !modComments.isEmpty())
                        updateData.put("COMMENTS", modComments);

                    if (modDescription != null && !modDescription.isEmpty())
                        updateData.put("DESCRIPTION", modDescription);

                    updateData.put("UPDATED_BY", Utility.getUserId(request));
                    updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
                    updateData.put("UPDATED_AT", timeStamp);
                    updateData.put("UPDATED_AT_DT", new Date());

                    if (!newStatusId.isEmpty() && newStatusId.equalsIgnoreCase("61")) {
                        updateData.put("COMPLETED_AT", timeStamp);
                        updateData.put("COMPLETED_DT", new Date());
                        updateData.put("SOLVED_BY_USERNAME", Utility.getLoginName(request));
                        updateData.put("SOLVED_AT", timeStamp);
                        updateData.put("SOLVED_AT_DT", new Date());
                    }

                    updateData.put("REMARKS", "Bulk Activity Update. TimeStamp: " + timeStamp + ", User: " + Utility.getLoginName(request));

                    Map<String, Object> whereData = new HashMap<String, Object>();
                    whereData.put("ID", activityModel.getID());
                    if (commonDAO.CommoUpdate(Utility.tbl_sr_activity, updateData, whereData, logger)) {
                        successUpdateCount++;
                        try {
                            Map<String, Object> insertData = new HashMap<String, Object>();
                            if (!modStatus.isEmpty() && !newStatusId.isEmpty() && newStatusId.equals("61")) {
                                insertData.put("OLD_DATA", activityModel.getSTATUS_NAME());
                                insertData.put("NEW_DATA", modStatus);
                                insertData.put("REMARKS", "Activity Bulk Completed");
                                insertData.put("SR_ACTION_TYPE_NAME", "Activity Bulk Completed");
                            } else {
                                insertData.put("REMARKS", "Activity Bulk Updated");
                                insertData.put("SR_ACTION_TYPE_NAME", "Activity Bulk Updated");
                            }
                            insertData.put("SR_NUM", activityModel.getSR_NUM());
                            insertData.put("MSISDN", activityModel.getMSISDN());
                            insertData.put("CREATED_BY", Utility.getUserId(request));
                            insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
                            insertData.put("CREATED_AT", Utility.getCurrentTimestamp());
                            insertData.put("CREATED_AT_DT", new Date());
                            commonDAO.CommoInsert(Utility.tbl_sr_actions, insertData, logger);
                            insertData.clear();
                        } catch (Exception e) {
                            e.printStackTrace();
                            logger.error(e.getMessage(), e);
                        }
                    } else {
                        failedUpdateCount++;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    logger.error(e.getMessage(), e);
                    failedUpdateCount++;
                }
            }

            commonRestResponse.setCode(200);
            commonRestResponse.setMessage(successUpdateCount + " Activity Updated successfully.\n" +
                    failedUpdateCount + " Activity Failed to update.\n");
            return commonRestResponse;

        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Error occurred. Please try later.");
        }
        return commonRestResponse;
    }

    private CommonRestResponse proceedToChangeOwner(String newOwner, HttpServletRequest request, List<TBLSRModel> srList) {
        CommonRestResponse commonRestResponse = new CommonRestResponse();
        List<SRRoutingGroupModel> list = new ArrayList<>();
        int updateSuccessCount = 0;
        int updateFailedCount = 0;
        try {
            String query = "SELECT * FROM " + Utility.md_user_position + " WHERE IS_SR_OWNER=1 AND (NAME='" + newOwner + "' OR OWNER_NAME='" + newOwner + "')";
            Object listObject = commonDAO.CommoGetData(query);
            list = new Gson().fromJson(Utility.ObjectToJson(listObject), new TypeToken<List<SRRoutingGroupModel>>() {
            }.getType());

            if (list.isEmpty()) {
                commonRestResponse.setCode(404);
                commonRestResponse.setMessage("Invalid owner information.");
                return commonRestResponse;
            } else {
                SRRoutingGroupModel owner = list.get(0);
                Map<String, Object> updateData = new HashMap<String, Object>();
                updateData.put("OWNER_GROUP_ID", owner.getID());
                updateData.put("OWNER_GROUP_NAME", owner.getNAME());
                updateData.put("OWNER_ID", owner.getOWNER_ID());
                updateData.put("OWNER_NAME", owner.getOWNER_NAME());
                updateData.put("OWNER_EMAIL", owner.getOWNER_EMAIL());
                updateData.put("UPDATED_BY", Utility.getUserId(request));
                updateData.put("UPDATED_AT", Utility.getCurrentTimestamp());
                updateData.put("UPDATED_BY_USERNAME", Utility.getLoginName(request));
                Map<String, Object> whereData = new HashMap<String, Object>();
                for (TBLSRModel tblsrModel : srList) {
                    try {
                        whereData.clear();
                        whereData.put("SR_NUM", tblsrModel.getSR_NUM());
                        if (commonDAO.CommoUpdate(Utility.tbl_sr, updateData, whereData, logger)) {
                            updateSuccessCount++;
                            try {
                                Map<String, Object> insertData = new HashMap<String, Object>();
                                insertData.put("SR_NUM", tblsrModel.getSR_NUM());
                                insertData.put("MSISDN", tblsrModel.getMSISDN());
                                insertData.put("OLD_DATA", tblsrModel.getOWNER_GROUP_NAME());
                                insertData.put("NEW_DATA", owner.getNAME());
                                String remarks = "Bulk change owner";
                                insertData.put("REMARKS", remarks);
                                insertData.put("SR_ACTION_TYPE_NAME", "Owner Changed");
                                insertData.put("CREATED_BY", Utility.getUserId(request));
                                insertData.put("CREATED_BY_USERNAME", Utility.getLoginName(request));
                                insertData.put("CREATED_AT", Utility.getCurrentTimestamp());
                                insertData.put("CREATED_AT_DT", new Date());
                                commonDAO.CommoInsert(Utility.tbl_sr_actions, insertData, logger);
                            } catch (Exception e) {
                                e.printStackTrace();
                                logger.error(e.getMessage(), e);
                            }
                        } else {
                            updateFailedCount++;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        updateFailedCount++;
                    }
                }
            }
            commonRestResponse.setCode(200);
            commonRestResponse.setMessage("Owner updated. Successful=" + updateSuccessCount + ", Failed=" + updateFailedCount);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Error occurred during owner change.");
        }
        return commonRestResponse;
    }

    public CommonRestResponse getActivityUpdateCheck(String rowSpec, HttpServletRequest request) {

        CommonRestResponse commonRestResponse = new CommonRestResponse();
        try {
            MDUserModel mdUserModel = SessionManager.getUserDetails(request);
//            String query = "SELECT * FROM " + Utility.tbl_sr_activity + " " + SessionManager.getAttribute(SessionConstants.ACTIVITY_LAST_QUERY.name(), request) + " OFFSET 0 ROWS FETCH NEXT 500 ROWS ONLY";
//            if (rowSpec != null && !rowSpec.isEmpty() && rowSpec.equalsIgnoreCase("onlyVisibleRow")) {
//                query = "SELECT * FROM " + Utility.tbl_sr_activity + " " + SessionManager.getAttribute(SessionConstants.ACTIVITY_LAST_QUERY.name(), request) + SessionManager.getAttribute(SessionConstants.ACTIVITY_LAST_QUERY_PAGINATION.name(), request);
//            }

            String query = "SELECT * FROM " + Utility.tbl_sr_activity + " WHERE STATUS_ID NOT IN (61,263,269,302) AND (OWNER_GROUP_ID=" + mdUserModel.getPOSITION_ID() + " OR CREATED_BY_GROUP_ID=" + mdUserModel.getPOSITION_ID() + ") " +
                    " AND ID IN (SELECT ID FROM " + Utility.tbl_sr_activity + SessionManager.getAttribute(SessionConstants.ACTIVITY_LAST_QUERY.name(), request) + " OFFSET 0 ROWS FETCH NEXT 250 ROWS ONLY)";

            if (rowSpec != null && !rowSpec.isEmpty() && rowSpec.equalsIgnoreCase("onlyVisibleRow"))
                query = "SELECT * FROM " + Utility.tbl_sr_activity + " WHERE STATUS_ID NOT IN (61,263,269,302) AND (OWNER_GROUP_ID=" + mdUserModel.getPOSITION_ID() + " OR CREATED_BY_GROUP_ID=" + mdUserModel.getPOSITION_ID() + ") " +
                        " AND ID IN (SELECT ID FROM " + Utility.tbl_sr_activity + SessionManager.getAttribute(SessionConstants.ACTIVITY_LAST_QUERY.name(), request) + SessionManager.getAttribute(SessionConstants.ACTIVITY_LAST_QUERY_PAGINATION.name(), request) + ")";

            logger.info(query);
            Object listObject = commonDAO.CommoGetData(query);
            List<CommonLovModel> srList = new Gson().fromJson(Utility.ObjectToJson(listObject), new TypeToken<List<CommonLovModel>>() {
            }.getType());

            if (srList.size() > 0) {
                commonRestResponse.setCode(201);
                commonRestResponse.setMessage("Be careful: " + srList.size() + " activities will be updated after your submission. And this action cannot be undone.");
            } else {
                commonRestResponse.setCode(500);
                commonRestResponse.setMessage("Unable to validate query. Please reload/research again.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Error Occurred to validate query! Please reload/research again.");
        }
        return commonRestResponse;
    }
}
