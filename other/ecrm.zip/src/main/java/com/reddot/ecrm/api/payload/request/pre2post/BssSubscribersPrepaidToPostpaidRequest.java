package com.reddot.ecrm.api.payload.request.pre2post;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class BssSubscribersPrepaidToPostpaidRequest implements Serializable {
    public ChangePrepaidToPostpaidReq ChangePrepaidToPostpaidReq;
    public String transaction_id;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ChangePrepaidToPostpaidReq implements Serializable {

        public PostpaidCust PostpaidCust;
        public PostpaidAcct PostpaidAcct;
        public Offering Offering;



    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Offering implements Serializable {

        public NewPrimaryOffering NewPrimaryOffering;

        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class NewPrimaryOffering implements Serializable {

            public OfferingId OfferingId;
            public EffectiveMode EffectiveMode;

            @Data
            @AllArgsConstructor
            @NoArgsConstructor
            public static class EffectiveMode implements Serializable {

                public String Mode;

            }
            @Data
            @AllArgsConstructor
            @NoArgsConstructor
            public static class OfferingId implements Serializable {

                public String OfferingId;

            }


        }

    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class PostpaidAcct implements Serializable {

        public Account Account;
        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class Account implements Serializable {

            public String CustId;
            public String AcctName;
            public String PaymentType;
            public String Title;
            public Name__1 Name;
            public String BillCycleType;
            public String BillLanguage;
            public Contact Contact;
            public Address Address;
            public BillMedium BillMedium;
            public String Currency;
            public CreditLimit CreditLimit;

            @Data
            @AllArgsConstructor
            @NoArgsConstructor
            public static class Address implements Serializable {

                public String AddressType;
                public String Address1;
                public String Address2;
                public String Address3;
                public String Address5;
                public String Address7;
                public String Address11;

            }

            @Data
            @AllArgsConstructor
            @NoArgsConstructor
            public static class BillMedium implements Serializable {

                public String BillMediumId;
                public String BillMediumCode;
                public String BillContentType;

            }


            @Data
            @AllArgsConstructor
            @NoArgsConstructor
            public static class Contact implements Serializable {

                public String Priority;
                public String ContactType;
                public String Title;
                public Name__2 Name;
                public String MobilePhone;
                public String Email;

            }

            @Data
            @AllArgsConstructor
            @NoArgsConstructor
            public static class CreditLimit implements Serializable {

                public String LimitType;
                public String LimitValue;

            }



            @Data
            @AllArgsConstructor
            @NoArgsConstructor
            public static class Example implements Serializable {

                public ChangePrepaidToPostpaidReq ChangePrepaidToPostpaidReq;
                public String TransactionId;

            }

            @Data
            @AllArgsConstructor
            @NoArgsConstructor
            public static class Name implements Serializable {

                public String FirstName;
                public String MiddleName;
                public String LastName;

            }

            @Data
            @AllArgsConstructor
            @NoArgsConstructor
            public static class Name__1 implements Serializable {

                public String FirstName;
                public String MiddleName;
                public String LastName;

            }

            @Data
            @AllArgsConstructor
            @NoArgsConstructor
            public static class Name__2 implements Serializable {

                public String FirstName;
                public String MiddleName;
                public String LastName;

            }


        }

    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class PostpaidCust implements Serializable {

        public String CustId;
        public Name Name;
        public String Nationality;
        public String Birthday;
        @Data
        @AllArgsConstructor
        @NoArgsConstructor
        public static class Name implements Serializable {

            public String FirstName;
            public String MiddleName;
            public String LastName;

        }

    }

}
