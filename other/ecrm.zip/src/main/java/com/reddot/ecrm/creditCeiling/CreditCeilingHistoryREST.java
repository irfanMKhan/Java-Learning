package com.reddot.ecrm.creditCeiling;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.reddot.ecrm.entity.attachment.AttachmentEntity;
import com.reddot.ecrm.service.attachment.AttachmentService;
import com.reddot.ecrm.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/credit-ceiling-history")
public class CreditCeilingHistoryREST {
    @Autowired
    private CreditCeilingHistoryService creditCeilingHistoryService;
    
    @Autowired
    private AttachmentService attachmentService;

    @RequestMapping(value = "/get-all-v1", method = RequestMethod.GET)
    public ResponseEntity<?> getAllCreditCeilingHistory() {
        return creditCeilingHistoryService.getAllCreditCeilingHistory();
    }

    @RequestMapping(value = "/search-dt", method = RequestMethod.POST)
    public DataTablesOutput<CreditCeilingHistory> searchDT(@RequestBody Map<String, Object> data) throws IOException {
        DataTablesInput input = new Gson().fromJson(Utility.ObjectToJson(data.get("dtInput")), new TypeToken<DataTablesInput>() {
        }.getType());

        ObjectMapper mapper = new ObjectMapper();
        CreditCeilingHistorySearchReqDTO creditCeilingHistorySearchReqDTO = mapper.readValue(data.get("searchData").toString(), CreditCeilingHistorySearchReqDTO.class);

        return creditCeilingHistoryService.searchDT(input, creditCeilingHistorySearchReqDTO);
    }

    @RequestMapping(value = "/get-all-company", method = RequestMethod.GET)
    public ResponseEntity<?> getAllCompany(HttpServletRequest httpServletRequest) {
        return creditCeilingHistoryService.getAllCompany(httpServletRequest);
    }

    @RequestMapping(value = "/get-company", method = RequestMethod.GET)
    public ResponseEntity<?> getCompanyById(HttpServletRequest httpServletRequest, @RequestParam String id) {
        return creditCeilingHistoryService.getCompanyById(httpServletRequest, id);
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public ResponseEntity<?> addCC(HttpServletRequest httpServletRequest, @RequestBody CreditCeilingHistoryReqBodyForAdd reqBody) {
        return creditCeilingHistoryService.addCC(httpServletRequest, reqBody);
    }

    @RequestMapping(value = "/get-by-id", method = RequestMethod.POST)
    public ResponseEntity<?> getCreditCeilingById(HttpServletRequest httpServletRequest, @RequestBody CreditCeilingHistoryReqBodyForGetById reqBody) {
        return creditCeilingHistoryService.getCreditCeilingById(httpServletRequest, reqBody);
    }

    @RequestMapping(value = "/updateCC", method = RequestMethod.POST)
    public ResponseEntity<?> updateCC(HttpServletRequest httpServletRequest, @RequestBody CreditCeilingHistoryReqBodyForUpdate reqBody) {
        return creditCeilingHistoryService.updateCC(httpServletRequest, reqBody);
    }
    
    @PostMapping("/get-attachment")
    public List<AttachmentEntity> getAllCreditCeilingAttachment(HttpServletRequest httpServletRequest,
                                                            DataTablesInput input, @RequestBody GetCreditCeilingRowByIdReqBody reqBody) {
        return creditCeilingHistoryService.getAllCreditCeilingAttachment(httpServletRequest, reqBody);
    }
}
