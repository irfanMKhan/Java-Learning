package com.reddot.ecrm.api.payload.response.hotBill;

import lombok.Data;

import java.io.Serializable;

@Data
public class HotBillResponse implements Serializable {
    private String Code;
    private String Message;
    private String TransactionId;

}
