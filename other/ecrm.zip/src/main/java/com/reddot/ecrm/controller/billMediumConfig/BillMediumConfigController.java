package com.reddot.ecrm.controller.billMediumConfig;

import com.reddot.ecrm.dto.billMediumConfig.BillMediumConfigDto;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.model.CommonRestResponse;
import com.reddot.ecrm.service.billMediumConfig.BillMediumConfigService;
import com.reddot.ecrm.service.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;

@Controller
@RequestMapping("/bill-medium")
public class BillMediumConfigController {
    
    @Autowired
    private BillMediumConfigService billMediumConfigService;
    
    @Autowired
    private UserService userService;
    
    @RequestMapping(value = "", method = RequestMethod.GET)
    public String viewBillMediumConfigs(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        
        model.addAttribute("title", "Bill Medium Configuration");
        model.addAttribute("breadcrumb", "Bill Medium Configuration List");
        
        return "billMedium/bill_medium_config_list";
    }
    
    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public String addBillMediumConfig(ModelMap model, HttpServletRequest request, Principal principal) {
        new MenuViewer().setupSideMenu(model, request);
        
        model.addAttribute("title", "Add Bill Medium Configuration");
        model.addAttribute("breadcrumb", "Add Bill Medium Configuration");
        
        return "billMedium/bill_medium_config_add";
    }
    
    @RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
    public String editBillMediumConfig(@PathVariable("id") Long id, ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);
        
        CommonRestResponse response = billMediumConfigService.getBillMediumConfigById(id);
        
        if (response.getCode() == 200) {
            BillMediumConfigDto billMediumConfigDto = (BillMediumConfigDto) response.getData();
            
            model.addAttribute("billMediumConfig", billMediumConfigDto);
            model.addAttribute("title", "Edit Bill Medium Configuration");
            model.addAttribute("breadcrumb", "Edit Bill Medium Configuration");
            
            return "billMedium/bill_medium_config_edit";
        } else {
            return null;
        }
    }
    
}
