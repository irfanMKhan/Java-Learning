package com.reddot.ecrm.controller.bulk_files;

import com.reddot.ecrm.entity.company.CompanyEntity;
import com.reddot.ecrm.enum_config.bulk.BulkProcessFileTypeEnum;
import com.reddot.ecrm.enum_config.bulk.FilePathLocationEnum;
import com.reddot.ecrm.enum_config.cr.add_new_number.PaymentTerm;
import com.reddot.ecrm.enum_config.cr.add_new_number.ReservationStatus;
import com.reddot.ecrm.menu.MenuViewer;
import com.reddot.ecrm.repository.CommonRepository;
import com.reddot.ecrm.repository.company.CompanyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/bulkfile")
public class BulkFileController {
    @Autowired
    CommonRepository commonRepository;

    @Autowired
    CompanyRepository companyRepository;


    @GetMapping()
    public String viewMainBulkPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        List<CompanyEntity> companyList = companyRepository.findAllByActiveAndContractStatus(true, 2);

        BulkProcessFileTypeEnum[] processFileTypeEnumsList = BulkProcessFileTypeEnum.values();

        model.put("process_file_type_list", processFileTypeEnumsList);
        model.put("company_list", companyList);
        model.put("title", "Bulk Files");
        return "bulk_files/bulk_files";
    }

    @GetMapping("/list")
    public String viewBulkPage(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        List<CompanyEntity> companyList = companyRepository.findAllByActiveAndContractStatus(true, 2);

        BulkProcessFileTypeEnum[] processFileTypeEnumsList = BulkProcessFileTypeEnum.values();

        model.put("process_file_type_list", processFileTypeEnumsList);
        model.put("company_list", companyList);
        model.put("title", "Bulk Files");
        return "bulk_files/bulk_files";
    }

    @GetMapping("/details")
    public String viewBulkFileDetailsPage(@RequestParam(value = "companyId") Long companyId,
                                          @RequestParam("fileId") Long fileId,
                                          @RequestParam("processId") Integer processId,
                                          ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        ReservationStatus[] reservationStatus = ReservationStatus.values();
        PaymentTerm[] paymentTerms = PaymentTerm.values();
        BulkProcessFileTypeEnum[] processFileTypeEnumsList = BulkProcessFileTypeEnum.values();

        List<CompanyEntity> companyList = companyRepository.findAllByActiveAndContractStatus(true, 2);

        model.put("process_file_type_list", processFileTypeEnumsList);
        model.put("reservation_status", reservationStatus);
        model.put("payment_terms", paymentTerms);
        model.put("company_list", companyList);
        model.put("title", "Bulk Files Details");
        model.addAttribute("breadcrumb", "Bulk Files");
        return "bulk_files/bulk_file_details";
    }


    @GetMapping("/template/list")
    public String viewAddRemoveBulkFiles(ModelMap model, HttpServletRequest request) {
        new MenuViewer().setupSideMenu(model, request);

        FilePathLocationEnum[] filePathLocationEnums = FilePathLocationEnum.values();

        model.put("filePathLocation", filePathLocationEnums);
        model.put("title", "Add/Remove Bulk Template Files");
        return "bulk_files/add_remove_bulk_template/add_remove_bulk_template";
    }

}
