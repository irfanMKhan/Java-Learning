package com.reddot.ecrm.delayPayment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
public class SubGroupRestController {
    @Autowired
    private SubGroupService subGroupService;

    @RequestMapping(value = "/subgroup/get-all-account-code", method = RequestMethod.GET)
    public ResponseEntity<?> getAllAccountCode(HttpServletRequest httpServletRequest) {
        return subGroupService.getAllAccountCode(httpServletRequest);
    }
}
