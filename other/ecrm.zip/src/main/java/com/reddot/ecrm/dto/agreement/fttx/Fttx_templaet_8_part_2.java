package com.reddot.ecrm.dto.agreement.fttx;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class Fttx_templaet_8_part_2 {
    private Integer no;
    private String name;
    private String position;
    private String email;
    private String phone;

}
