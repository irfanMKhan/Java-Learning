package com.reddot.ecrm_bulk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcrmBulkApplicationTests {

	@Test
	void contextLoads() {
	}

}
