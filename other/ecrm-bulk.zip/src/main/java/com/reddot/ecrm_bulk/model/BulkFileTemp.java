package com.reddot.ecrm_bulk.model;

public class BulkFileTemp {
	private String ID,
	   BULK_FILE_ID,
	   FILE_DATA,
			ACADEMIC_YEAR_ID,
			ACADEMIC_YEAR_NAME,
	   FILE_ROW_NUM,
	   CONNECTION_TYPE,
	   PROCESS_TYPE_NAME,
	   PROCESS_TYPE_ID,
	   FINAL_STATUS,
	   FAILED_REASON,
	   CREATED_BY,
	   CREATED_BY_USERNAME,
	   UPDATED_BY,
	   UPDATED_BY_USERNAME,
	   CREATED_AT_DT,
	   UPDATED_AT_DT;

	private String INSTITUTE_ID,
			INSTITUTE_NAME
			, REGISTRATION_ID
			, NAME
			, ROLL
			, SCHOLARSHIP
			, GUARDIAN_NAME
			, MOBILE_NO
			, GENDER
			, RELIGION
			, UPDATE_DATE
			, PREVIOUS_CLASS
			, CLASS
			, SECTION
			, SHIFT
			, GROUP
			, STUDENT_SESSION
			, STUDENT_TYPE
			, HOSTEL
			,STUDENT_ID
			,ISACTIVE
			,STUDENT_NAME;

	public String getSTUDENT_ID() {
		return STUDENT_ID;
	}

	public void setSTUDENT_ID(String STUDENT_ID) {
		this.STUDENT_ID = STUDENT_ID;
	}

	public String getSTUDENT_NAME() {
		return STUDENT_NAME;
	}

	public void setSTUDENT_NAME(String STUDENT_NAME) {
		this.STUDENT_NAME = STUDENT_NAME;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String getBULK_FILE_ID() {
		return BULK_FILE_ID;
	}

	public void setBULK_FILE_ID(String bULK_FILE_ID) {
		BULK_FILE_ID = bULK_FILE_ID;
	}

	public String getFILE_DATA() {
		return FILE_DATA;
	}

	public void setFILE_DATA(String fILE_DATA) {
		FILE_DATA = fILE_DATA;
	}

	public String getACADEMIC_YEAR_ID() {
		return ACADEMIC_YEAR_ID;
	}

	public void setACADEMIC_YEAR_ID(String ACADEMIC_YEAR_ID) {
		this.ACADEMIC_YEAR_ID = ACADEMIC_YEAR_ID;
	}

	public String getACADEMIC_YEAR_NAME() {
		return ACADEMIC_YEAR_NAME;
	}

	public void setACADEMIC_YEAR_NAME(String ACADEMIC_YEAR_NAME) {
		this.ACADEMIC_YEAR_NAME = ACADEMIC_YEAR_NAME;
	}

	public String getFILE_ROW_NUM() {
		return FILE_ROW_NUM;
	}

	public void setFILE_ROW_NUM(String fILE_ROW_NUM) {
		FILE_ROW_NUM = fILE_ROW_NUM;
	}

	public String getCONNECTION_TYPE() {
		return CONNECTION_TYPE;
	}

	public void setCONNECTION_TYPE(String cONNECTION_TYPE) {
		CONNECTION_TYPE = cONNECTION_TYPE;
	}

	public String getPROCESS_TYPE_NAME() {
		return PROCESS_TYPE_NAME;
	}

	public void setPROCESS_TYPE_NAME(String pROCESS_TYPE_NAME) {
		PROCESS_TYPE_NAME = pROCESS_TYPE_NAME;
	}

	public String getPROCESS_TYPE_ID() {
		return PROCESS_TYPE_ID;
	}

	public void setPROCESS_TYPE_ID(String pROCESS_TYPE_ID) {
		PROCESS_TYPE_ID = pROCESS_TYPE_ID;
	}

	public String getFINAL_STATUS() {
		return FINAL_STATUS;
	}

	public void setFINAL_STATUS(String fINAL_STATUS) {
		FINAL_STATUS = fINAL_STATUS;
	}

	public String getFAILED_REASON() {
		return FAILED_REASON;
	}

	public void setFAILED_REASON(String fAILED_REASON) {
		FAILED_REASON = fAILED_REASON;
	}

	public String getCREATED_BY() {
		return CREATED_BY;
	}

	public void setCREATED_BY(String cREATED_BY) {
		CREATED_BY = cREATED_BY;
	}

	public String getCREATED_BY_USERNAME() {
		return CREATED_BY_USERNAME;
	}

	public void setCREATED_BY_USERNAME(String cREATED_BY_USERNAME) {
		CREATED_BY_USERNAME = cREATED_BY_USERNAME;
	}

	public String getUPDATED_BY() {
		return UPDATED_BY;
	}

	public void setUPDATED_BY(String uPDATED_BY) {
		UPDATED_BY = uPDATED_BY;
	}

	public String getUPDATED_BY_USERNAME() {
		return UPDATED_BY_USERNAME;
	}

	public void setUPDATED_BY_USERNAME(String uPDATED_BY_USERNAME) {
		UPDATED_BY_USERNAME = uPDATED_BY_USERNAME;
	}

	public String getCREATED_AT_DT() {
		return CREATED_AT_DT;
	}

	public void setCREATED_AT_DT(String cREATED_AT_DT) {
		CREATED_AT_DT = cREATED_AT_DT;
	}

	public String getUPDATED_AT_DT() {
		return UPDATED_AT_DT;
	}

	public void setUPDATED_AT_DT(String uPDATED_AT_DT) {
		UPDATED_AT_DT = uPDATED_AT_DT;
	}

	public String getINSTITUTE_NAME() {
		return INSTITUTE_NAME;
	}

	public void setINSTITUTE_NAME(String INSTITUTE_NAME) {
		this.INSTITUTE_NAME = INSTITUTE_NAME;
	}

	public String getREGISTRATION_ID() {
		return REGISTRATION_ID;
	}

	public void setREGISTRATION_ID(String REGISTRATION_ID) {
		this.REGISTRATION_ID = REGISTRATION_ID;
	}

	public String getNAME() {
		return NAME;
	}

	public void setNAME(String NAME) {
		this.NAME = NAME;
	}

	public String getROLL() {
		return ROLL;
	}

	public void setROLL(String ROLL) {
		this.ROLL = ROLL;
	}

	public String getSCHOLARSHIP() {
		return SCHOLARSHIP;
	}

	public void setSCHOLARSHIP(String SCHOLARSHIP) {
		this.SCHOLARSHIP = SCHOLARSHIP;
	}

	public String getGUARDIAN_NAME() {
		return GUARDIAN_NAME;
	}

	public void setGUARDIAN_NAME(String GUARDIAN_NAME) {
		this.GUARDIAN_NAME = GUARDIAN_NAME;
	}

	public String getMOBILE_NO() {
		return MOBILE_NO;
	}

	public void setMOBILE_NO(String MOBILE_NO) {
		this.MOBILE_NO = MOBILE_NO;
	}

	public String getGENDER() {
		return GENDER;
	}

	public void setGENDER(String GENDER) {
		this.GENDER = GENDER;
	}

	public String getRELIGION() {
		return RELIGION;
	}

	public void setRELIGION(String RELIGION) {
		this.RELIGION = RELIGION;
	}

	public String getUPDATE_DATE() {
		return UPDATE_DATE;
	}

	public void setUPDATE_DATE(String UPDATE_DATE) {
		this.UPDATE_DATE = UPDATE_DATE;
	}

	public String getPREVIOUS_CLASS() {
		return PREVIOUS_CLASS;
	}

	public void setPREVIOUS_CLASS(String PREVIOUS_CLASS) {
		this.PREVIOUS_CLASS = PREVIOUS_CLASS;
	}

	public String getCLASS() {
		return CLASS;
	}

	public void setCLASS(String CLASS) {
		this.CLASS = CLASS;
	}

	public String getSECTION() {
		return SECTION;
	}

	public void setSECTION(String SECTION) {
		this.SECTION = SECTION;
	}

	public String getSHIFT() {
		return SHIFT;
	}

	public void setSHIFT(String SHIFT) {
		this.SHIFT = SHIFT;
	}

	public String getGROUP() {
		return GROUP;
	}

	public void setGROUP(String GROUP) {
		this.GROUP = GROUP;
	}

	public String getSTUDENT_SESSION() {
		return STUDENT_SESSION;
	}

	public void setSTUDENT_SESSION(String STUDENT_SESSION) {
		this.STUDENT_SESSION = STUDENT_SESSION;
	}

	public String getSTUDENT_TYPE() {
		return STUDENT_TYPE;
	}

	public void setSTUDENT_TYPE(String STUDENT_TYPE) {
		this.STUDENT_TYPE = STUDENT_TYPE;
	}

	public String getHOSTEL() {
		return HOSTEL;
	}

	public void setHOSTEL(String HOSTEL) {
		this.HOSTEL = HOSTEL;
	}

	public String getISACTIVE() {
		return ISACTIVE;
	}

	public void setISACTIVE(String ISACTIVE) {
		this.ISACTIVE = ISACTIVE;
	}

	public String getINSTITUTE_ID() {
		return INSTITUTE_ID;
	}

	public void setINSTITUTE_ID(String INSTITUTE_ID) {
		this.INSTITUTE_ID = INSTITUTE_ID;
	}
}
