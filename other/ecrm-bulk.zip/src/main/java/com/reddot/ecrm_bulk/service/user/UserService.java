package com.reddot.ecrm_bulk.service.user;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm_bulk.dto.common.CommonRestResponse;
import com.reddot.ecrm_bulk.dto.user.UserModel;
import com.reddot.ecrm_bulk.pool_repository.CommonRepository;
import com.reddot.ecrm_bulk.util.Utility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    @Autowired
    private CommonRepository commonRepository;
    public UserModel getUserById(Long id) {
        String sql = "SELECT * FROM " + Utility.md_user + " WHERE id='" + id + "';";
        try {
            Object object = commonRepository.CommoGetData(sql);

            JsonArray result = new Gson().fromJson(Utility.ObjectToJson(object), new TypeToken<JsonArray>() {
            }.getType());
            for (JsonElement item : result) {
                UserModel userModel = new UserModel();

                userModel.setId(item.getAsJsonObject().get("id").getAsLong());
                userModel.setEmail(item.getAsJsonObject().get("email").getAsString());
                userModel.setName(item.getAsJsonObject().get("name").getAsString());
                userModel.setTenant_id(item.getAsJsonObject().get("tenant_id").getAsLong());
                logger.info("UserService:getUserById() success");
                return userModel;
            }
            return null;
        } catch (Exception e) {
            logger.error(e.getMessage());
            return null;
        }
    }

    public List<UserModel> getAllUserListByRoleId(Long roleId) {
        String sql = "select md_user.id, md_user.name, md_user.email, md_user.active from md_user\n" +
                "Inner Join md_user_role on  md_user_role.user_id=md_user.id and md_user_role.role_id ='" + roleId + "';";
        List<UserModel> list = new ArrayList<>();
        try {
            Object object = commonRepository.CommoGetData(sql);
            JsonArray result = new Gson().fromJson(Utility.ObjectToJson(object), new TypeToken<JsonArray>() {
            }.getType());
            for (JsonElement item : result) {
                UserModel userModel = new UserModel();

                userModel.setId(item.getAsJsonObject().get("id").getAsLong());

                userModel.setEmail(item.getAsJsonObject().get("email").getAsString());
                userModel.setName(item.getAsJsonObject().get("name").getAsString());

                list.add(userModel);
                logger.info("UserService:getAllUserListByRoleId() success");
            }

        } catch (Exception e) {
            logger.error(String.format("UserService:getAllUserListByRoleId() Error: %s", e.getMessage()));
        }
        return list;
    }


}
