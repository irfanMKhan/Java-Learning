package com.reddot.ecrm_bulk.entity.msisdn;

import lombok.extern.java.Log;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface MsisdnRepository extends JpaRepository<MSISDN, Long>, JpaSpecificationExecutor<MSISDN> {
    List<MSISDN> findByCompanyIdAndActive(Long companyId, Boolean active);

    List<MSISDN> findAllByCompanyId(Long aLong);



    List<MSISDN> findAllById(Long id);

    List<MSISDN> findAllByCompanyIdAndActiveIsTrue(Long companyId);

    List<MSISDN> findAllByCompanyNameAndActiveIsTrue(String companyName);

    List<MSISDN> findAllByCompanyIdAndIsSuspended(Long companyId, Boolean isSuspended);

    Optional<MSISDN> findByMsisdn(String msisdn);

    Optional<MSISDN> findByMsisdnAndCompanyIdAndActive(String msisdn, Long companyId, Boolean isActive);

    List<MSISDN> findListByMsisdn(String msisdn);

    List<MSISDN> findAllByMsisdnAndCompanyId(String msisdn, Long companyId);

    List<MSISDN> findAllByMsisdnAndActive(String msisdn, Boolean isActive);

    List<MSISDN> findAllByMsisdnAccountCodeAndActive(String accountCode, Boolean isActive);

    Optional<MSISDN> findByCompanyIdAndMsisdnAccountCodeAndActive(Long companyId, String accountCode, Boolean isActive);

    List<MSISDN> findAllByCompanyIdAndMsisdnAccountCodeAndActive(Long companyId, String accountCode, Boolean isActive);

    List<MSISDN> findAllByMsisdnAccountCode(String accountCode);

    @Query(value = "SELECT msisdn FROM MSISDN msisdn WHERE" +
            "(:companyIdQ IS NULL OR msisdn.companyId =:companyIdQ )" +
            "AND (:msisdnAccountCodeQ IS NULL OR cast(msisdn.msisdnAccountCode as string ) like cast( concat('%', :msisdnAccountCodeQ,'%') as string ))" +
            "AND (:msisdnQ IS NULL OR cast(msisdn.msisdn as string ) like cast( concat('%', :msisdnQ,'%') as string ))")
    Page<MSISDN> findAllByCustomSearchQuery(Long companyIdQ, String msisdnAccountCodeQ, String msisdnQ, Pageable pageable);

    MSISDN findByMsisdnAccountCode(String accountCode);

    MSISDN findByMsisdnAccountCodeAndActive(String accountCode, boolean b);
}
