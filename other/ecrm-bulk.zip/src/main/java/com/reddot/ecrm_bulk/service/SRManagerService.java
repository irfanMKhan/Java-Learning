package com.reddot.ecrm_bulk.service;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm_bulk.config.Utility;
import com.reddot.ecrm_bulk.model.TBLSRModel;
import com.reddot.ecrm_bulk.pool_repository.CommonRepository;
import com.reddot.ecrm_bulk.config.fileExport.GenerateCSV;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class SRManagerService {

    @Autowired
    CommonRepository commonDAO;

    private final Logger logger = LoggerFactory.getLogger(getClass().getName());

    @Value("${mail.file.location}")
    String filebaseloc;

    public String SRMailPUsh() {
        List<Map<String, Object>> mapList = new ArrayList<>();
        List<TBLSRModel> srLists = new ArrayList<>();

        try {

            Calendar cal = Calendar.getInstance();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            System.out.println("Today's date is "+dateFormat.format(cal.getTime()));

            String today = dateFormat.format(cal.getTime());
            cal.add(Calendar.DATE, -1);
            System.out.println("Yesterday's date was "+dateFormat.format(cal.getTime()));


            String yesterday = dateFormat.format(cal.getTime());
            String query = "SELECT * FROM TBL_SR WHERE EVENT_DATE <TO_DATE('"+today+"', 'YYYY-MM-dd') and EVENT_DATE >=TO_DATE('"+yesterday+"', 'YYYY-MM-dd') AND SR_TYPE_NAME='Product & Services' AND SR_AREA_NAME='DND' AND SR_SUB_AREA_NAME='Promotional sms'";

            logger.info("Export query: " + query);
            Object listObject = commonDAO.CommoGetData(query);
            srLists = new Gson().fromJson(Utility.ObjectToJson(listObject), new TypeToken<List<TBLSRModel>>() {
            }.getType());

            String[] columnTitles = {"SR #", "MSISDN", "Account", "Interaction Type", "Type",
                    "Area", "Sub Area", "Owner", "Owner Group", "Status", "Sub - status",
                    "Severity", "Priority", "Master Issue", "Master Issue #", "Summary", "Description", "Root Cause", "Root Cause Detail",
                    "Address", "Account Class", "Account Type", "Accepted By", "Accepted Date", "Problem Since", "Cell Name",
                    "Source", "Source Location", "SLA(Hrs)", "Duration(Hrs)", "First Call Resolution", "Created By", "Log Date", "Modified Date", "Escalated Date",
                    "Resolved Date", "Resolved By", "Closed By", "Closed Date", "KeepInView Date", "Remedy Incident No", "Reopen Date", "Reopen By", "Submitted Date", "Commit Time",
                    "Full Address", "Reopened", "Feedback Type", "Feedback Received", "Complaint Resolution / Solution", "Escalation / Cancel Reason", "Brand Name", "Division", "District", "Thana", "Reference Complaint #", "Reference Complaint Count"};

            String[] headers = {"SR_NUM", "MSISDN", "ACCOUNT_NAME", "SR_SERVICE_TYPE_NAME", "SR_TYPE_NAME",
                    "SR_AREA_NAME", "SR_SUB_AREA_NAME", "OWNER_NAME", "OWNER_GROUP_NAME", "SR_STATUS_NAME", "SR_SUB_STATUS_NAME",
                    "SEVERITY_NAME", "PRIORITY_NAME", "MASTER_ISSUE", "PAR_SR_NUM", "SUMMARY", "DESCRIPTION", "ROOT_CAUSE_NAME", "ROOT_CAUSE_DETAIL",
                    "ADDRESS", "ACC_CLASS_NAME", "ACC_TYPE_NAME", "ACCEPTED_BY", "ACCEPTED_AT", "PROBLEM_SINCE", "CELL_NAME",
                    "SRC_NAME", "SRC_LOCATION_NAME", "SLA_HR", "DURATION", "FIRST_CALL_RESOLVED", "CREATED_BY", "LOG_AT", "UPDATED_AT", "ESCALATED_AT",
                    "RESOLVED_AT", "RESOLVED_BY_NAME", "CLOSED_BY", "CLOSED_AT", "KEEPINVIEW_DATE", "REMEDY_INCIDENT_NO", "REOPEN_AT", "REOPEN_BY_NAME", "SUBMITTED_AT", "COMMITED_AT",
                    "FULL_ADDRESS", "IS_REOPENED", "FEEDBACK_TYPE", "IS_FEEDBACK_RECEIVED", "RESOLUTION_SOLUTION", "ESC_CANCEL_REASON", "BRAND_NAME", "DIVISION", "DISTRICT", "THANA", "REFERENCE_COMPLAINT", "REFERENCE_COMPLAINT_COUNT"};

            for (TBLSRModel tblsrModel : srLists) {
                HashMap<String, Object> hashMap = new HashMap<>();
                hashMap.put("SR_NUM", tblsrModel.getSR_NUM());
                hashMap.put("MSISDN", tblsrModel.getMSISDN());
                hashMap.put("ACCOUNT_NAME", tblsrModel.getACCOUNT_NAME());
                hashMap.put("SR_SERVICE_TYPE_NAME", tblsrModel.getSR_SERVICE_TYPE_NAME());
                hashMap.put("SR_TYPE_NAME", tblsrModel.getSR_TYPE_NAME());
                hashMap.put("SR_AREA_NAME", tblsrModel.getSR_AREA_NAME());
                hashMap.put("SR_SUB_AREA_NAME", tblsrModel.getSR_SUB_AREA_NAME());
                hashMap.put("OWNER_NAME", tblsrModel.getOWNER_NAME());
                hashMap.put("OWNER_GROUP_NAME", tblsrModel.getOWNER_GROUP_NAME());
                hashMap.put("SR_STATUS_NAME", tblsrModel.getSR_STATUS_NAME());
                hashMap.put("SR_SUB_STATUS_NAME", tblsrModel.getSR_SUB_STATUS_NAME());
                hashMap.put("SEVERITY_NAME", tblsrModel.getSEVERITY_NAME());
                hashMap.put("PRIORITY_NAME", tblsrModel.getPRIORITY_NAME());
                hashMap.put("MASTER_ISSUE", getFormattedYesNo(tblsrModel.getMASTER_ISSUE()));
                hashMap.put("PAR_SR_NUM", tblsrModel.getPAR_SR_NUM());
                hashMap.put("SUMMARY", tblsrModel.getSUMMARY());
                hashMap.put("DESCRIPTION", tblsrModel.getDESCRIPTION());
                hashMap.put("ROOT_CAUSE_NAME", tblsrModel.getROOT_CAUSE_NAME());
                hashMap.put("ROOT_CAUSE_DETAIL", tblsrModel.getROOT_CAUSE_DETAIL());
                hashMap.put("ADDRESS", tblsrModel.getADDRESS());
                hashMap.put("ACC_CLASS_NAME", tblsrModel.getACC_CLASS_NAME());
                hashMap.put("ACC_TYPE_NAME", tblsrModel.getACC_TYPE_NAME());
                hashMap.put("ACCEPTED_BY", tblsrModel.getACCEPTED_BY_NAME());
                hashMap.put("ACCEPTED_AT", Utility.convertTimestampToDateTime(tblsrModel.getACCEPTED_AT(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("PROBLEM_SINCE", Utility.convertTimestampToDateTime(tblsrModel.getPROBLEM_SINCE(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("CELL_NAME", tblsrModel.getCELL_NAME());
                hashMap.put("SRC_NAME", tblsrModel.getSRC_NAME());
                hashMap.put("SRC_LOCATION_NAME", tblsrModel.getSRC_LOCATION_NAME());
                hashMap.put("SLA_HR", tblsrModel.getSLA_HR());
                hashMap.put("DURATION", getDuration(tblsrModel));
                hashMap.put("FIRST_CALL_RESOLVED", getFormattedYesNo(tblsrModel.getFIRST_CALL_RESOLVED()));
                hashMap.put("CREATED_BY", tblsrModel.getCREATED_BY_USERNAME());
                hashMap.put("LOG_AT", Utility.convertTimestampToDateTime(tblsrModel.getLOG_AT(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("UPDATED_AT", Utility.convertTimestampToDateTime(tblsrModel.getUPDATED_AT(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("ESCALATED_AT", Utility.convertTimestampToDateTime(tblsrModel.getESCALATED_AT(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("RESOLVED_AT", Utility.convertTimestampToDateTime(tblsrModel.getRESOLVED_AT(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("RESOLVED_BY_NAME", tblsrModel.getRESOLVED_BY_NAME());
                hashMap.put("CLOSED_BY", tblsrModel.getCLOSED_BY_NAME());
                hashMap.put("CLOSED_AT", Utility.convertTimestampToDateTime(tblsrModel.getCLOSED_AT(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("KEEPINVIEW_DATE", Utility.convertTimestampToDateTime(tblsrModel.getKEEPINVIEW_DATE(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("REMEDY_INCIDENT_NO", tblsrModel.getREMEDY_INCIDENT_NO());
                hashMap.put("REOPEN_AT", Utility.convertTimestampToDateTime(tblsrModel.getREOPEN_AT(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("REOPEN_BY_NAME", tblsrModel.getREOPEN_BY_NAME());
                hashMap.put("SUBMITTED_AT", Utility.convertTimestampToDateTime(tblsrModel.getSUBMITTED_AT(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("COMMITED_AT", Utility.convertTimestampToDateTime(tblsrModel.getCOMMITED_AT(), "yyyy-MM-dd HH:mm:ss"));
                hashMap.put("FULL_ADDRESS", tblsrModel.getFULL_ADDRESS());
                hashMap.put("IS_REOPENED", getFormattedYesNo(tblsrModel.getIS_REOPENED()));
                hashMap.put("FEEDBACK_TYPE", tblsrModel.getFEEDBACK_TYPE());
                hashMap.put("IS_FEEDBACK_RECEIVED", getFormattedYesNo(tblsrModel.getIS_FEEDBACK_RECEIVED()));
                hashMap.put("RESOLUTION_SOLUTION", tblsrModel.getRESOLUTION_SOLUTION());
                hashMap.put("ESC_CANCEL_REASON", tblsrModel.getESC_CANCEL_REASON());
                hashMap.put("BRAND_NAME", tblsrModel.getBRAND_NAME());
                hashMap.put("DIVISION", tblsrModel.getDIVISION());
                hashMap.put("DISTRICT", tblsrModel.getDISTRICT());
                hashMap.put("THANA", tblsrModel.getTHANA());
                hashMap.put("REFERENCE_COMPLAINT", tblsrModel.getREFERENCE_COMPLAINT());
                hashMap.put("REFERENCE_COMPLAINT_COUNT", tblsrModel.getREFERENCE_COMPLAINT_COUNT());
                mapList.add(hashMap);
            }
              String filename=  generateSRListCSV(mapList, headers, columnTitles);

            srLists.clear();
            if (!filename.isEmpty())
                return filename;

        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        } finally {
            mapList.clear();
        }

        return "";

    }

    private String generateSRListCSV(List<Map<String, Object>> mapList, String[] headers, String[] columnTitles) {

        try {

            Calendar cal = Calendar.getInstance();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            cal.add(Calendar.DATE, -1);
            String filename = "SR_LIST_" + dateFormat.format(cal.getTime())+ ".csv";
            filename=filebaseloc+filename;

           boolean b= GenerateCSV.writeApacheCSVtoResponse(mapList, logger, headers, columnTitles,filename);
           if (b)
            return filename;

        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return "";
    }

    private String getDuration(TBLSRModel tblsrModel) {
        String duration = "";
        double hourFrac = 0;
        DecimalFormat df = new DecimalFormat("#.##");
        try {
            if (tblsrModel.getSUBMITTED_AT() == null || tblsrModel.getSUBMITTED_AT() <= 0) {
                return duration;
            } else if (tblsrModel.getSLA_STOP_TIME() != null && tblsrModel.getSLA_STOP_TIME() > 0) {
                hourFrac = (tblsrModel.getSLA_STOP_TIME() - tblsrModel.getSUBMITTED_AT()) / 3600000.0;
                duration = df.format(hourFrac);
            } else {
                hourFrac = (System.currentTimeMillis() - tblsrModel.getSUBMITTED_AT()) / 3600000.0;
                duration = df.format(hourFrac);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return duration;
    }

    private String getFormattedYesNo(Integer value) {
        if (value != null && value == 1) {
            return "Y";
        } else {
            return "N";
        }
    }

    private void generateSRListExcel(String[] headers, List<Map<String, Object>> mapList, HttpServletResponse response, String[] columnTitles) {
        try {
            response.setContentType("application/octet-stream");
            SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyyHHmmss");
            String filename = "SR_LIST_" + dateFormat.format(new Date()) + ".xlsx";
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");


            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("SR List");

            Row row = sheet.createRow(0);
            CellStyle headerCellStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerCellStyle.setFont(headerFont);
            DataFormat dataFormat = workbook.createDataFormat();
            headerCellStyle.setDataFormat(dataFormat.getFormat("@"));
            for (int i = 0; i < columnTitles.length; i++) {
                Cell cell = row.createCell(i);
                cell.setCellValue(columnTitles[i]);
                cell.setCellStyle(headerCellStyle);
                sheet.autoSizeColumn(i);
            }

            CellStyle childCellStyle = workbook.createCellStyle();
            childCellStyle.setDataFormat(dataFormat.getFormat("@"));
            for (int i = 0; i < mapList.size(); i++) {
                Row cellRow = sheet.createRow(i + 1);
                for (int j = 0; j < headers.length; j++) {
                    Cell cell = cellRow.createCell(j);
                    Object cellValue = mapList.get(i).get(headers[j]);
                    if (cellValue != null && !cellValue.toString().isEmpty()) {
                        cell.setCellValue(mapList.get(i).get(headers[j]).toString());
                    }
                    cell.setCellStyle(childCellStyle);
                    sheet.autoSizeColumn(j);
                }
            }

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            ByteArrayInputStream stream = new ByteArrayInputStream(outputStream.toByteArray());
            IOUtils.copy(stream, response.getOutputStream());
            workbook.close();
            outputStream.close();
            stream.close();
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
    }

}
