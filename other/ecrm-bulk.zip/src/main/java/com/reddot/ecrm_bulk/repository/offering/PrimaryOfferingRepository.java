package com.reddot.ecrm_bulk.repository.offering;

import com.reddot.ecrm_bulk.entity.primary_offering.PrimaryOffering;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

@Repository
public class PrimaryOfferingRepository {
    @PersistenceContext
    private EntityManager entityManager;

    public PrimaryOffering findByOfferingId(Long offeringId) {
        TypedQuery<PrimaryOffering> query = entityManager.createQuery(
                "SELECT o FROM PrimaryOffering o WHERE o.ngbssOfferingId = :offeringId AND o.statusName = :statusName",
                PrimaryOffering.class);
        return query.setParameter("offeringId", offeringId)
                .setParameter("statusName", "Active")
                .getSingleResult();
    }
}
