package com.reddot.ecrm_bulk.repository.contact;

import com.reddot.ecrm_bulk.entity.contract.Contact;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.List;

@Repository
public class ContactRepository {
    @PersistenceContext
    private EntityManager entityManager;

    public List<Contact> findByContractId(Long contractId) {
        TypedQuery<Contact> query = entityManager.createQuery(
                "SELECT c FROM Contact c WHERE c.contractId = :contractId",
                Contact.class);
        return query.setParameter("contractId", contractId).getResultList();
    }
}
