package com.reddot.ecrm_bulk.enums.company;

public enum CustomerAccountType {
    Customer,
    Account,
    Subscriber,
    CUG_GROUP
}
