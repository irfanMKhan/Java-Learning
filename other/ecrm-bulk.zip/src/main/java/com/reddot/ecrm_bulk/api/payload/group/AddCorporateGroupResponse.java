package com.reddot.ecrm_bulk.api.payload.group;

import java.io.Serializable;

public class AddCorporateGroupResponse implements Serializable {
  private AddCorporateGroupMemberRspMsg AddCorporateGroupMemberRspMsg;

  public AddCorporateGroupMemberRspMsg getAddCorporateGroupMemberRspMsg() {
    return this.AddCorporateGroupMemberRspMsg;
  }

  public void setAddCorporateGroupMemberRspMsg(AddCorporateGroupMemberRspMsg AddCorporateGroupMemberRspMsg) {
    this.AddCorporateGroupMemberRspMsg = AddCorporateGroupMemberRspMsg;
  }

  public static class AddCorporateGroupMemberRspMsg implements Serializable {
    private RspHeader RspHeader;

    public RspHeader getRspHeader() {
      return this.RspHeader;
    }

    public void setRspHeader(RspHeader RspHeader) {
      this.RspHeader = RspHeader;
    }

    public static class RspHeader implements Serializable {
      private Long RspTime;

      private String ReturnCode;

      private String ReturnMsg;

      private Integer Version;

      public Long getRspTime() {
        return this.RspTime;
      }

      public void setRspTime(Long RspTime) {
        this.RspTime = RspTime;
      }

      public String getReturnCode() {
        return this.ReturnCode;
      }

      public void setReturnCode(String ReturnCode) {
        this.ReturnCode = ReturnCode;
      }

      public String getReturnMsg() {
        return this.ReturnMsg;
      }

      public void setReturnMsg(String ReturnMsg) {
        this.ReturnMsg = ReturnMsg;
      }

      public Integer getVersion() {
        return this.Version;
      }

      public void setVersion(Integer Version) {
        this.Version = Version;
      }
    }
  }
}
