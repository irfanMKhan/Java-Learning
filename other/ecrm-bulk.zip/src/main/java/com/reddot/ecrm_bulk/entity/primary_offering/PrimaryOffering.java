package com.reddot.ecrm_bulk.entity.primary_offering;

import lombok.*;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Entity
@Table(name = "tbl_primary_offering", schema = "ecrm")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class PrimaryOffering {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "tariff_plan_type_id")
    private Long tariffPlanTypeId;

    @Column(name = "tariff_plan_type_name")
    private String tariffPlanTypeName;

    @Column(name = "tariff_plan_category_id")
    private Long tariffPlanCategoryId;

    @Column(name = "tariff_plan_category_name")
    private String tariffPlanCategoryName;

    @Column(name = "tariff_plan_group_id")
    private Long tariffPlanGroupId;

    @Column(name = "tariff_plan_group_name")
    private String tariffPlanGroupName;

    @Column(name = "ngbss_offering_id")
    private Long ngbssOfferingId;

    @Column(name = "ngbss_offering_name")
    private String ngbssOfferingName;

    @Column(name = "tariff_plan_name")
    private String tariffPlanName;

    @Column(name = "agreement_id")
    private String agreementId;

    @Column(name = "level_id")
    private Long levelId;

    @Column(name = "level_name")
    private String levelName;


    @Column(name = "minimum_credit_limit")
    private BigDecimal minimumCreditLimit;

    @Column(name = "monthly_fee")
    private BigDecimal monthlyFee;

    @Column(name = "status_id")
    private Long statusId;

    @Column(name = "status_name")
    private String statusName;

    @Column(name = "available_id")
    private Long availableId;

    @Column(name = "available_name")
    private String availableName;

    @Column(name = "description")
    private String description;

    @Column(name = "start_dt")
    private String startDt;

    @Column(name = "end_dt")
    private String endDt;

    @Column(name = "created_at")
    private Long createdAt;

    @Column(name = "created_at_dt")
    private Timestamp createdAtDt;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_by_username")
    private String createdByUsername;

    @Column(name = "updated_at")
    private Long updatedAt;

    @Column(name = "updated_at_dt")
    private Timestamp updatedAtDt;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_by_username")
    private String updatedByUsername;

    @Column(name = "service_type_id")
    private Long serviceTypeId;

    @Column(name = "service_type_name")
    private String serviceTypeName;

    @Column(name = "device_subsidy")
    private BigDecimal deviceSubsidy;
}
