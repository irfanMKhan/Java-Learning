package com.reddot.ecrm_bulk.repository.contract;

import com.reddot.ecrm_bulk.entity.contract.Contract;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.List;

@Repository
public class ContractRepository {
    @PersistenceContext
    private EntityManager entityManager;

    public List<Contract> findAll() {
        TypedQuery<Contract> query = entityManager.createQuery(
                "SELECT c FROM Contract c WHERE c.saveType =:saveType",
                Contract.class);
        return query.setParameter("saveType", "Activate").getResultList();
    }
}
