package com.reddot.ecrm_bulk.api.payload.group;

import lombok.Data;

import java.io.Serializable;

@Data
public class AddGroupCUGResponse implements Serializable {
    private String transaction_id;

    private String transaction_status;

    private AddGroupCUGResponse.Metadata metadata;

    private AddGroupCUGResponse.Data data;

    @lombok.Data
    public static class Metadata implements Serializable {
        private String operator_id;

        private String channel_id;
    }

    @lombok.Data
    public static class Data implements Serializable {

    }
}
