package com.reddot.ecrm_bulk.entity.bulk;

import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
@Table(name = "BULK_FILE_DETAILS")
public class BulkFileDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    @Column(name = "BULK_FILE_ID")
    private Long bulkFileId;

    @Column(name = "BULK_FILE_NAME")
    private String bulkFileName;

    @Column(name = "COMPANY_ID")
    private Long companyId;

    @Column(name = "COMPANY_NAME")
    private String companyName;

    @Column(name = "CREATED_AT")
    private Long createdAt;
    @Column(name = "CREATED_AT_DT")
    private Timestamp createdAtDt;
    @Column(name = "CREATED_BY")
    private Long createdBy;
    @Column(name = "CREATED_BY_USERNAME")
    private String createdByUsername;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "FAILED_REASON")
    private String failedReason;

    @Column(name = "FILE_ROW_DATA")
    private String fileRowData;

    @Column(name = "FILE_ROW_NUM")
    private Integer fileRowNum;

    @Column(name = "FINAL_STATUS")
    private String finalStatus;

    @Column(name = "IS_ACTIVE")
    private Boolean isActive;

    @Column(name = "ORDERID")
    private Long orderId;

    @Column(name = "UPDATED_AT")
    private Long updatedAt;
    @Column(name = "UPDATED_AT_DT")
    private Timestamp updatedAtDt;
    @Column(name = "UPDATED_BY")
    private Long updatedBy;
    @Column(name = "UPDATED_BY_USERNAME")
    private String updatedByUsername;
    @Column(name = "PROCESS_TYPE_ID")
    private Integer processTypeId;
    @Column(name = "PROCESS_TYPE_NAME")
    private String processTypeName;
    @Column(name = "BULK_FILE_PROCESS_TYPE_ID")
    private Integer bulkFileProcessTypeId;
    @Column(name = "BULK_FILE_PROCESS_TYPE_NAME")
    private String bulkFileProcessTypeName;
}
