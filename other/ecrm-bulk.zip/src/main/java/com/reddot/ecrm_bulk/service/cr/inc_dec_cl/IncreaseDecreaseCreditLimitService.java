package com.reddot.ecrm_bulk.service.cr.inc_dec_cl;

import com.reddot.ecrm_bulk.api.gateway.ContractGateway;
import com.reddot.ecrm_bulk.api.payload.customer.CBSBCCustomerResponse;
import com.reddot.ecrm_bulk.api.payload.subscriber.ChangeAccountCreditLimitRequest;
import com.reddot.ecrm_bulk.api.payload.subscriber.ChangeAccountCreditLimitResponse;
import com.reddot.ecrm_bulk.dto.common.CommonRestResponse;
import com.reddot.ecrm_bulk.dto.product_details.ProductDetailsDTO;
import com.reddot.ecrm_bulk.entity.company.Company;
import com.reddot.ecrm_bulk.entity.cr.CRMsisdnDetailsEntity;
import com.reddot.ecrm_bulk.entity.msisdn.MSISDN;
import com.reddot.ecrm_bulk.entity.msisdn.MsisdnRepository;
import com.reddot.ecrm_bulk.enums.cr.CRStatusEnum;
import com.reddot.ecrm_bulk.enums.requestType.RequestTypeEnum;
import com.reddot.ecrm_bulk.repository.company.CompanyJPARepository;
import com.reddot.ecrm_bulk.repository.cr.CRDetailsRepo;
import com.reddot.ecrm_bulk.repository.cr.CRMSISDNDetailsRepo;
import com.reddot.ecrm_bulk.util.Utility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.UnsupportedEncodingException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.reddot.ecrm_bulk.util.Utility.EntityObjectToJsonConvertGson;

@Service
@RequiredArgsConstructor
public class IncreaseDecreaseCreditLimitService {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    private final MsisdnRepository msisdnRepository;
    private final CompanyJPARepository companyRepository;
    private final ContractGateway contractGateway;
    @Autowired
    CRDetailsRepo crDetailsRepo;
    @Autowired
    CRMSISDNDetailsRepo crmsisdnDetailsRepo;
    @Value("${smart.access.user}")
    String smart_bss_username;
    @Value("${smart.access.password}")
    String smart_bss_password;
    @Value("${smart.api.partnerId}")
    String smart_partnerId;
    @Value("${smart.api.channel}")
    String smart_channel;
    @Value("${smart.api.version}")
    String smart_version;

    public synchronized List<CRMsisdnDetailsEntity> getListForCreditLimitChange() {
        List<CRMsisdnDetailsEntity> list = new ArrayList<>();
        try {
            LocalDate today = LocalDate.now();
            list = crmsisdnDetailsRepo.findAllByRequestTypeAndStatusAndEffectiveDateLessThanEqual(
                    RequestTypeEnum.Increase_Decrease_Credit_Limit.getKey(), CRStatusEnum.Created.toString(), today
            );
            for (CRMsisdnDetailsEntity crMsisdnDetailsEntity : list) {
                crMsisdnDetailsEntity.setStatus(CRStatusEnum.InProgress.toString());
            }
            crmsisdnDetailsRepo.saveAll(list);
        } catch (Exception e) {
            logger.error("IncreaseDecreaseCreditLimitService::getListForCreditLimitChange() Error: %s", e.getMessage());
        }
        return list;
    }

    public synchronized List<CRMsisdnDetailsEntity> getListForTemporaryCreditLimitChange() {
        List<CRMsisdnDetailsEntity> list = new ArrayList<>();
        try {
            LocalDate dayBeforeToday = LocalDate.now().minusDays(1);
            list = crmsisdnDetailsRepo.findAllByRequestTypeAndIsChangePermanentAndTemporaryEndDateToLessThanEqualAndStatusAndIsTemporaryToPreviousStateDone(
                    RequestTypeEnum.Increase_Decrease_Credit_Limit.getKey(), false, dayBeforeToday, CRStatusEnum.Activate.toString(), false
            );
            for (CRMsisdnDetailsEntity crMsisdnDetailsEntity : list) {
                crMsisdnDetailsEntity.setStatus(CRStatusEnum.InProgress.toString());
            }
            crmsisdnDetailsRepo.saveAll(list);
        } catch (Exception e) {
            logger.error("IncreaseDecreaseCreditLimitService::getListForTemporaryCreditLimitChange() Error: %s", e.getMessage());
        }
        return list;
    }

    public void ScheduledCreditLimitApiCall() {
        try {
            LocalDate today = LocalDate.now();
            List<CRMsisdnDetailsEntity> list = getListForCreditLimitChange();
            logger.info("Inside IncreaseDecreaseCreditLimitService  ScheduledCreditLimitApiCall() Scheduler: list size={} ", list.size());
            if (list.size() > 0) {
                for (CRMsisdnDetailsEntity crMsisdnDetailsEntity : list) {
                    Boolean CanCallApi = false;
                    if (crMsisdnDetailsEntity.getIsChangePermanent()) {
                        CanCallApi = true;
                    } else {
                        //if it is a temporary change, then need to check if it is equal to the temporary date from
                        LocalDate temporaryDateFrom = crMsisdnDetailsEntity.getTemporaryStartDateFrom();
                        if (temporaryDateFrom.isEqual(today)) {
                            CanCallApi = true;
                        }
                    }

                    if (CanCallApi) {
                        Boolean IsFirstTimeApiCall = true; // for the first time api call for all types--> temporary and permanent
                        CommonRestResponse commonRestResponse = ChangeCreditLimit(crMsisdnDetailsEntity, IsFirstTimeApiCall);
                        if (commonRestResponse.getCode() == 500) {
                            crMsisdnDetailsEntity.setStatus(CRStatusEnum.Failed.toString());
                            if (!ObjectUtils.isEmpty(commonRestResponse.getMessage())) {
                                crMsisdnDetailsEntity.setFailedReason((String) commonRestResponse.getMessage());
                            }
                            crmsisdnDetailsRepo.saveAndFlush(crMsisdnDetailsEntity);
                            logger.info(EntityObjectToJsonConvertGson(crMsisdnDetailsEntity));
                            logger.error("IncreaseDecreaseCreditLimitService::ScheduledCreditLimitApiCall() Msisdn{} and Error: {}", crMsisdnDetailsEntity.getMsisdn(), commonRestResponse.getMessage().toString());
                        } else if (commonRestResponse.getCode() == 204) {
                            //not InProgress Status, just skip
                        } else {
                            crMsisdnDetailsEntity.setStatus(CRStatusEnum.Activate.toString());
                            crmsisdnDetailsRepo.saveAndFlush(crMsisdnDetailsEntity);
                        }
                    }
                }
            }

        } catch (Exception e) {
            logger.error("IncreaseDecreaseCreditLimitService::ScheduledCreditLimitApiCall() Error: %s", e.getMessage());
        }
    }


    public void ScheduledForTemporaryCreditLimitApiCall() {
        try {
            List<CRMsisdnDetailsEntity> list = getListForTemporaryCreditLimitChange();
            logger.info("Inside IncreaseDecreaseCreditLimitService  ScheduledForTemporaryCreditLimitApiCall() Scheduler: list size={} ", list.size());

            if (list.size() > 0) {
                for (CRMsisdnDetailsEntity crMsisdnDetailsEntity : list) {
                    Boolean IsFirstTimeApiCall = false; // for temporary---> we use oldValue and now back to previous credit limit
                    CommonRestResponse commonRestResponse1 = ChangeCreditLimit(crMsisdnDetailsEntity, IsFirstTimeApiCall);
                    if (commonRestResponse1.getCode() == 500) {
                        crMsisdnDetailsEntity.setStatus(CRStatusEnum.Failed.toString());
                        if (!ObjectUtils.isEmpty(commonRestResponse1.getMessage())) {
                            crMsisdnDetailsEntity.setFailedReason((String) commonRestResponse1.getMessage());
                        }
                        crmsisdnDetailsRepo.saveAndFlush(crMsisdnDetailsEntity);
                        logger.info(EntityObjectToJsonConvertGson(crMsisdnDetailsEntity));
                        logger.error("IncreaseDecreaseCreditLimitService::ScheduledForTemporaryCreditLimitApiCall() Msisdn{} and Error: {}", crMsisdnDetailsEntity.getMsisdn(), commonRestResponse1.getMessage().toString());
                    } else if (commonRestResponse1.getCode() == 204) {
                        //not InProgress Status, just skip
                    } else {
                        crMsisdnDetailsEntity.setStatus(CRStatusEnum.Activate.toString());
                        crmsisdnDetailsRepo.saveAndFlush(crMsisdnDetailsEntity);
                    }
                }
            }

        } catch (Exception e) {
            logger.error("IncreaseDecreaseCreditLimitService::ScheduledCreditLimitApiCall() Error: %s", e.getMessage());
        }
    }


    @Transactional
    public CommonRestResponse ChangeCreditLimit(CRMsisdnDetailsEntity crMsisdnDetailsEntity, Boolean IsFirstTimeApiCall) {
        CommonRestResponse commonRestResponse = new CommonRestResponse();
        if (!crMsisdnDetailsEntity.getStatus().equalsIgnoreCase(CRStatusEnum.InProgress.toString())) {
            logger.warn("Data not in InProgress status for this msisdn={} and CRMsisdnDetails id={}", crMsisdnDetailsEntity.getMsisdn(), crMsisdnDetailsEntity.getId());
            commonRestResponse.setCode(204);
            commonRestResponse.setMessage("Data not in InProgress status.");
            return commonRestResponse;
        }

        crMsisdnDetailsEntity.setStatus(CRStatusEnum.Processing.toString()); //api call starts so Processing
        if (!crMsisdnDetailsEntity.getIsChangePermanent() && IsFirstTimeApiCall) {
            //if it is new and is a temporary change, then set isTemporaryToPreviousStateDone to false.
            crMsisdnDetailsEntity.setIsTemporaryToPreviousStateDone(false);
        }
        crmsisdnDetailsRepo.saveAndFlush(crMsisdnDetailsEntity);

        try {
            String msisdn_string = crMsisdnDetailsEntity.getMsisdn();
            Optional<MSISDN> msisdn = msisdnRepository.findByMsisdn(crMsisdnDetailsEntity.getMsisdn());

            if (msisdn.isPresent()) {
                if (!validateMsisdnReturnIfOKOrNot(crMsisdnDetailsEntity, msisdn.get())) {
                    crmsisdnDetailsRepo.saveAndFlush(crMsisdnDetailsEntity);
                    commonRestResponse.setCode(500);
                    commonRestResponse.setMessage(crMsisdnDetailsEntity.getFailedReason());
                    return commonRestResponse;
                }
            } else {
                return msisdnNotPresentResponse(crMsisdnDetailsEntity, commonRestResponse);
            }

            // cbs-bc-customer
            String accountID = CheckSubscriberIsExistsReturnAccountIdOrNull(msisdn_string);
            if (accountID == null) {
                int i = 0;
                while (i < 3) {
                    accountID = CheckSubscriberIsExistsReturnAccountIdOrNull(msisdn_string);
                    logger.info("Repeated CheckSubscriberIsExistsReturnAccountIdOrNull() function call and count{}.", i);
                    if (accountID != null) {
                        break;
                    }
                    i++;
                }
            }

            if (accountID == null) {
                return accountIDNotPresentResponse(commonRestResponse, crMsisdnDetailsEntity);
            }

            if (msisdn.isPresent() && !IsFirstTimeApiCall) {
                Double requestedReserveCredit = crMsisdnDetailsEntity.getRequestedReserveCredit();
                Double ExistingRemainingCredit = msisdn.get().getRemainingCredit();

                Double remainingCreditAfterApiCall = null;
                //check remaining credit is positive or not?? for temporary to go back previous
                if (crMsisdnDetailsEntity.getIsIncreaseCreditLimit()) {
                    remainingCreditAfterApiCall = ExistingRemainingCredit - requestedReserveCredit;
                } else {
                    remainingCreditAfterApiCall = ExistingRemainingCredit + requestedReserveCredit;
                }

                if (remainingCreditAfterApiCall < 0.0) {
                    logger.error("For Msisdn {}, Remaining Credit After api call will be less than 0. So Revert!!!", crMsisdnDetailsEntity.getMsisdn());
                    crMsisdnDetailsEntity.setFailedReason("Remaining Credit After api call will be less than 0!!!");
                    crMsisdnDetailsEntity.setStatus(CRStatusEnum.Failed.toString());
                    crmsisdnDetailsRepo.saveAndFlush(crMsisdnDetailsEntity);
                    commonRestResponse.setCode(500);
                    commonRestResponse.setMessage("Remaining Credit After api call will be less than 0. So Revert!!!");
                    return commonRestResponse;
                }
            }

            ProductDetailsDTO productDetailsDTO = new ProductDetailsDTO();
            if (IsFirstTimeApiCall) {
                productDetailsDTO.setTotalCredit(String.valueOf(crMsisdnDetailsEntity.getNewValue()));
            } else {
                //for temporary, we need to back to the old credit limit, that's why use oldValue
                productDetailsDTO.setTotalCredit(String.valueOf(crMsisdnDetailsEntity.getOldValue()));
            }

            //change credit limit
            ChangeAccountCreditLimitRequest changeAccountCreditLimitRequest = createChangeAccountCreditLimitRequest(accountID, productDetailsDTO);
            EntityObjectToJsonConvertGson(changeAccountCreditLimitRequest);
            ChangeAccountCreditLimitResponse changeAccountCreditLimitResponse = contractGateway.changeAccountCreditLimit(changeAccountCreditLimitRequest);
            EntityObjectToJsonConvertGson(changeAccountCreditLimitResponse);

            boolean isAPISuccess = true;

            if (!changeAccountCreditLimitResponse.getChangeAccountCreditLimitRspMsg().getRspHeader().getReturnCode().equals("0000")) {
                isAPISuccess = false;
                int i = 0;
                while (i < 3) {
                    logger.info("Repeated changeAccountCreditLimit() API call and count{}.", i);
                    changeAccountCreditLimitResponse = contractGateway.changeAccountCreditLimit(changeAccountCreditLimitRequest);
                    EntityObjectToJsonConvertGson(changeAccountCreditLimitResponse);
                    if (changeAccountCreditLimitResponse.getChangeAccountCreditLimitRspMsg().getRspHeader().getReturnCode().equals("0000")) {
                        isAPISuccess = true;
                        break;
                    }
                    i++;
                }
            }

            if (!isAPISuccess) {
                return changeCreditLimitAPIFailedResponse(crMsisdnDetailsEntity, changeAccountCreditLimitResponse, commonRestResponse);
            }

            if (!IsFirstTimeApiCall) {
                //change temporary to previous done successfully so isTemporaryToPreviousStateDone to true.
                crMsisdnDetailsEntity.setIsTemporaryToPreviousStateDone(true);
            }

            //update: msisdn, company table for permanent and temporary change
            if (msisdn.isPresent()) {
                if (!updateMsisdnSuccess(msisdn, crMsisdnDetailsEntity, IsFirstTimeApiCall)) {
                    logger.error("IncreaseDecreaseCreditLimitService::ChangeCreditLimit() Error: Msisdn={} and CRMsisdnId={} Update Failed.", crMsisdnDetailsEntity.getMsisdn(), crMsisdnDetailsEntity.getId());
                }
            }

            Long COMPANY_ID = crMsisdnDetailsEntity.getCompanyId();
            if (COMPANY_ID == null) {
                return companyIDNullResponse(commonRestResponse, crMsisdnDetailsEntity);
            }

            if (!updateCompanySuccess(crMsisdnDetailsEntity, IsFirstTimeApiCall)) {
                logger.error("IncreaseDecreaseCreditLimitService::ChangeCreditLimit() Error: Msisdn={} and CRMsisdnId={} Company Update Failed.", crMsisdnDetailsEntity.getMsisdn(), crMsisdnDetailsEntity.getId());
            }

            crMsisdnDetailsEntity.setStatus(CRStatusEnum.Activate.toString()); //api call success so Activate
            crmsisdnDetailsRepo.saveAndFlush(crMsisdnDetailsEntity);

            commonRestResponse.setCode(200);
            commonRestResponse.setMessage("Successfully change credit limit.");
        } catch (Exception e) {
            logger.error(String.format("IncreaseDecreaseCreditLimitService::ChangeCreditLimit() Error: %s", e.getMessage()));
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Failed to get the data");
        }
        return commonRestResponse;
    }

    private CommonRestResponse companyIDNullResponse(CommonRestResponse commonRestResponse, CRMsisdnDetailsEntity crMsisdnDetailsEntity) {
        logger.error(String.format("IncreaseDecreaseCreditLimitService::ChangeCreditLimit() Error: companyId is null"));
        commonRestResponse.setCode(500);
        commonRestResponse.setMessage("CompanyId is null. Failed to update company table.");
        crMsisdnDetailsEntity.setFailedReason("CompanyId is null. Failed to update company table.");
        crMsisdnDetailsEntity.setStatus(CRStatusEnum.Failed.toString());
        crmsisdnDetailsRepo.saveAndFlush(crMsisdnDetailsEntity);
        return commonRestResponse;
    }

    private boolean updateCompanySuccess(CRMsisdnDetailsEntity crMsisdnDetailsEntity, Boolean IsFirstTimeApiCall) {
        try {
            Company company = companyRepository.findByIdAndActive(crMsisdnDetailsEntity.getCompanyId(), true);
            if (company == null) {
                logger.error("Company Not Found. So msisdn data not added in company table.");
                return false;
            } else {
                Double creditLimit = -99.0;
                if (IsFirstTimeApiCall) {
                    //Todo: PBX ---> ??
                    Double totalCreditLimit = crMsisdnDetailsEntity.getTotalCredit();
                    Double newTotalCreditLimit = crMsisdnDetailsEntity.getNewTotalCredit();
                    if (company.getCreditLimit() != null) {
                        //subtract previous creditLimit and add new one;
                        creditLimit = company.getCreditLimit() - totalCreditLimit + newTotalCreditLimit;
                    } else {
                        //though it will not be null.
                        creditLimit = newTotalCreditLimit;
                    }

                } else {
                    //for temporary to go back previous state: newTotalCredit need to remove and previous credit need to add
                    Double totalCreditLimit = crMsisdnDetailsEntity.getNewTotalCredit();
                    Double newTotalCreditLimit = crMsisdnDetailsEntity.getTotalCredit();
                    if (company.getCreditLimit() != null) {
                        //subtract previous creditLimit and add new one;
                        creditLimit = company.getCreditLimit() - totalCreditLimit + newTotalCreditLimit;
                    } else {
                        //though it will not be null.
                        creditLimit = newTotalCreditLimit;
                    }
                }

                company.setCreditLimit(creditLimit);
                companyRepository.saveAndFlush(company);
                return true;
            }
        } catch (Exception e) {
            logger.error(String.format("IncreaseDecreaseCreditLimitService::updateCompanySuccess() Error: %s", e.getMessage()));
        }
        return false;
    }

    private boolean updateMsisdnSuccess(Optional<MSISDN> msisdn, CRMsisdnDetailsEntity crMsisdnDetailsEntity, Boolean IsFirstTimeApiCall) {
        try {
            Double requestedReserveCredit = crMsisdnDetailsEntity.getRequestedReserveCredit();
            if (IsFirstTimeApiCall) {
                if (crMsisdnDetailsEntity.getIsIncreaseCreditLimit()) {
                    msisdn.get().setTotalCredit(msisdn.get().getTotalCredit() + requestedReserveCredit);
                    msisdn.get().setMaxMonthlyFee(msisdn.get().getMaxMonthlyFee() + requestedReserveCredit);
                    msisdn.get().setRemainingCredit(msisdn.get().getRemainingCredit() + requestedReserveCredit);
                    msisdn.get().setReserveCredit(msisdn.get().getReserveCredit() + requestedReserveCredit);
                } else {
                    msisdn.get().setTotalCredit(msisdn.get().getTotalCredit() - requestedReserveCredit);
                    msisdn.get().setMaxMonthlyFee(msisdn.get().getMaxMonthlyFee() - requestedReserveCredit); //todo: check is it negative?
                    msisdn.get().setRemainingCredit(msisdn.get().getRemainingCredit() - requestedReserveCredit);
                    msisdn.get().setReserveCredit(msisdn.get().getReserveCredit() - requestedReserveCredit);
                }
            } else { //temporary so if it is increasing, then i need to decrease for back to the previous version
                if (crMsisdnDetailsEntity.getIsIncreaseCreditLimit()) {
                    msisdn.get().setTotalCredit(msisdn.get().getTotalCredit() - requestedReserveCredit);
                    msisdn.get().setMaxMonthlyFee(msisdn.get().getMaxMonthlyFee() - requestedReserveCredit);
                    msisdn.get().setRemainingCredit(msisdn.get().getRemainingCredit() - requestedReserveCredit);
                    msisdn.get().setReserveCredit(msisdn.get().getReserveCredit() - requestedReserveCredit);
                } else {
                    msisdn.get().setTotalCredit(msisdn.get().getTotalCredit() + requestedReserveCredit);
                    msisdn.get().setMaxMonthlyFee(msisdn.get().getMaxMonthlyFee() + requestedReserveCredit);
                    msisdn.get().setRemainingCredit(msisdn.get().getRemainingCredit() + requestedReserveCredit);
                    msisdn.get().setReserveCredit(msisdn.get().getReserveCredit() + requestedReserveCredit);
                }
            }
            msisdnRepository.saveAndFlush(msisdn.get());
            return true;
        } catch (Exception e) {
            logger.error(String.format("IncreaseDecreaseCreditLimitService::updateMsisdnSuccess() Error: %s", e.getMessage()));
        }
        return false;
    }

    private CommonRestResponse changeCreditLimitAPIFailedResponse(CRMsisdnDetailsEntity crMsisdnDetailsEntity, ChangeAccountCreditLimitResponse changeAccountCreditLimitResponse, CommonRestResponse commonRestResponse) {
        String errorMsg = changeAccountCreditLimitResponse.getChangeAccountCreditLimitRspMsg().getRspHeader().getReturnMsg();
        logger.error(errorMsg);
        crMsisdnDetailsEntity.setFailedReason(errorMsg);
        crMsisdnDetailsEntity.setStatus(CRStatusEnum.Failed.toString());
        crmsisdnDetailsRepo.saveAndFlush(crMsisdnDetailsEntity);
        commonRestResponse.setCode(500);
        commonRestResponse.setMessage(errorMsg);
        return commonRestResponse;
    }

    private CommonRestResponse accountIDNotPresentResponse(CommonRestResponse commonRestResponse, CRMsisdnDetailsEntity crMsisdnDetailsEntity) {
        logger.info("Subscriber api call failed. Account Id is null");
        commonRestResponse.setCode(500);
        commonRestResponse.setMessage("Subscriber api call failed. Account Id is null");
        crMsisdnDetailsEntity.setFailedReason("Subscriber api call failed. Account Id is null");
        crMsisdnDetailsEntity.setStatus(CRStatusEnum.Failed.toString());
        crmsisdnDetailsRepo.saveAndFlush(crMsisdnDetailsEntity);
        return commonRestResponse;
    }

    private CommonRestResponse msisdnNotPresentResponse(CRMsisdnDetailsEntity crMsisdnDetailsEntity, CommonRestResponse commonRestResponse) {
        logger.error(String.format("IncreaseDecreaseCreditLimitService::ChangeCreditLimit() Error: %s msisdn not found.", crMsisdnDetailsEntity.getMsisdn()));
        crMsisdnDetailsEntity.setStatus(CRStatusEnum.Failed.toString());
        crMsisdnDetailsEntity.setFailedReason("Msisdn not found in ECRM.");
        crmsisdnDetailsRepo.saveAndFlush(crMsisdnDetailsEntity);
        commonRestResponse.setCode(500);
        commonRestResponse.setMessage(crMsisdnDetailsEntity.getFailedReason());
        return commonRestResponse;
    }

    private boolean validateMsisdnReturnIfOKOrNot(CRMsisdnDetailsEntity crMsisdnDetailsEntity, MSISDN msisdn) {
        String failedReason = "";
        boolean validationError = false;

        Double remainingCompanyCC = getCompanyRemainingCreditCeiling(crMsisdnDetailsEntity.getCompanyId());

        if (remainingCompanyCC == null) {
            logger.error("Company Remaining CC is null for this company={} and msisdn={}, crMsisdnDetailsId={}",
                    crMsisdnDetailsEntity.getCompanyName(), crMsisdnDetailsEntity.getMsisdn(), crMsisdnDetailsEntity.getId());
            return false;
        }

        Double remainingCreditLimit = ObjectUtils.isEmpty(msisdn.getRemainingCredit()) ? 0.0 : msisdn.getRemainingCredit();
        if (!crMsisdnDetailsEntity.getIsIncreaseCreditLimit() && crMsisdnDetailsEntity.getRequestedReserveCredit() > remainingCreditLimit) {
            failedReason = "Can not decrease more than remaining credit limit for this msisdn.";
            validationError = true;
        }

        if (!ObjectUtils.isEmpty(crMsisdnDetailsEntity.getIsIncreaseCreditLimit()) && crMsisdnDetailsEntity.getIsIncreaseCreditLimit()
                && !ObjectUtils.isEmpty(crMsisdnDetailsEntity.getRequestedReserveCredit())
                && crMsisdnDetailsEntity.getRequestedReserveCredit() > remainingCompanyCC) {
            failedReason = "Cannot increase more than Remaining Company's CC";
            validationError = true;
        }

        Double newReserveCredit = 0.0;

        if (!ObjectUtils.isEmpty(crMsisdnDetailsEntity.getIsIncreaseCreditLimit()) && crMsisdnDetailsEntity.getIsIncreaseCreditLimit()) {
            newReserveCredit = crMsisdnDetailsEntity.getRequestedReserveCredit() + msisdn.getReserveCredit();
        } else if (!ObjectUtils.isEmpty(crMsisdnDetailsEntity.getIsIncreaseCreditLimit()) && !crMsisdnDetailsEntity.getIsIncreaseCreditLimit()) {
            newReserveCredit = msisdn.getReserveCredit() - crMsisdnDetailsEntity.getRequestedReserveCredit();
        }

        if (!ObjectUtils.isEmpty(crMsisdnDetailsEntity.getIsIncreaseCreditLimit())
                && !crMsisdnDetailsEntity.getIsIncreaseCreditLimit()
                && !ObjectUtils.isEmpty(crMsisdnDetailsEntity.getRequestedReserveCredit()) && newReserveCredit < 0.0) {
            failedReason = "Cannot decrease Credit limit more than existing Reserve Credit";
            validationError = true;
        }

        if (validationError) {
            crMsisdnDetailsEntity.setFailedReason(failedReason);
            crMsisdnDetailsEntity.setStatus(CRStatusEnum.Failed.toString());
            return false;
        }

        return true;
    }

    private Double getCompanyRemainingCreditCeiling(Long companyId) {
        try {
            Optional<Company> companyEntity = companyRepository.findById(companyId);
            if (!companyEntity.isPresent()) {
                logger.error(String.format("IncreaseDecreaseCLService::getCompanyRemainingCreditCeiling()  Company Not found for this id=%s", companyId));
                return null;
            }

            Double CreditCeiling = 0.0, CreditLimit = 0.0;

            if (!ObjectUtils.isEmpty(companyEntity.get().getCreditCeiling())) {
                CreditCeiling = companyEntity.get().getCreditCeiling();
            }
            if (!ObjectUtils.isEmpty(companyEntity.get().getCreditLimit())) {
                CreditLimit = companyEntity.get().getCreditLimit();
            }
            return (double) (CreditCeiling - CreditLimit) < 0.0 ? null : (double) (CreditCeiling - CreditLimit);

        } catch (Exception e) {
            logger.error(String.format("IncreaseDecreaseCLService::getCompanyRemainingCreditCeiling() Error: %s", e.getMessage()));
            return null;
        }
    }

    public String CheckSubscriberIsExistsReturnAccountIdOrNull(String msisdnString) throws UnsupportedEncodingException {
        try {
            Thread.sleep(2000);
            CBSBCCustomerResponse cbsbcCustomerResponse = contractGateway.cbsbcCustomer(msisdnString, smart_bss_username, smart_bss_password);
            EntityObjectToJsonConvertGson(cbsbcCustomerResponse);
            String accountID = cbsbcCustomerResponse.getQueryCustomerInfoResult().getAccount().getAcctKey();
            logger.info("For this {} msisdn AccountId: {}", msisdnString, accountID);
            return accountID;
        } catch (Exception e) {
            logger.error(String.format("IncreaseDecreaseCreditLimitService::CheckSubscriberIsExistsReturnAccountIdOrNull() Error: %s", e.getMessage()));
            return null;
        }
    }


    public ChangeAccountCreditLimitRequest createChangeAccountCreditLimitRequest(String ACCT_ID, ProductDetailsDTO productDetailsDTO) {
        try {
            ChangeAccountCreditLimitRequest request = new ChangeAccountCreditLimitRequest();
            ChangeAccountCreditLimitRequest.Account account = new ChangeAccountCreditLimitRequest.Account();
            account.setAcctId(ACCT_ID);//todo: Account-> AccKey. AcctId: refer to acct_id of subscriber. Get from API CBS-BC-Customer
            account.setActionType("MOD");
            List<ChangeAccountCreditLimitRequest.Account.CreditLimit> CreditLimit = new ArrayList<>();
            ChangeAccountCreditLimitRequest.Account.CreditLimit creditLimit = new ChangeAccountCreditLimitRequest.Account.CreditLimit();

            if (!ObjectUtils.isEmpty(productDetailsDTO.getTotalCredit())) {
                Integer totalCreditIntegerVal = (int) (Double.valueOf(productDetailsDTO.getTotalCredit()) * 100); //2
                Long totalCredit = Long.valueOf(totalCreditIntegerVal) * 1000000;  //6 total 2+6=8
                Long totalCreditInteger = totalCredit;
                creditLimit.setLimitValue(String.valueOf(totalCreditInteger));
            }


            creditLimit.setLimitType("I");
            creditLimit.setEffectiveDate(Utility.getTimeInFormatyyyyMMddHHmmss());
            CreditLimit.add(creditLimit);
            account.setCreditLimit(CreditLimit);
            ChangeAccountCreditLimitRequest.ReqHeader reqHeader = CreateChangeAccountCreditLimitReqHeader();
            request.setAccount(account);
            request.setReqHeader(reqHeader);


            return request;
        } catch (Exception e) {
            logger.error(String.format("CreateRequestEntityForContractAPI:createChangeAccountCreditLimitRequest() Error: %s", e.getMessage()));
            return null;
        }
    }

    public ChangeAccountCreditLimitRequest.ReqHeader CreateChangeAccountCreditLimitReqHeader() {
        try {
            ChangeAccountCreditLimitRequest.ReqHeader reqHeader = new ChangeAccountCreditLimitRequest.ReqHeader();
            String transactionId = Utility.getTransactionIdTimeIn_Date_T_Time_Format();
            reqHeader.setVersion(smart_version);
            reqHeader.setPartnerId(smart_partnerId);
            reqHeader.setTransactionId(transactionId);
            reqHeader.setReqTime(Utility.getTimeInFormatyyyyMMddHHmmss());
            reqHeader.setChannel(smart_channel);
            reqHeader.setAccessUser(smart_bss_username);
            reqHeader.setAccessPassword(smart_bss_password);

            return reqHeader;
        } catch (Exception e) {
            logger.error(String.format("CreateRequestEntityForContractAPI:CreateChangeAccountCreditLimitReqHeader() Error: %s", e.getMessage()));
            return null;
        }
    }
}
