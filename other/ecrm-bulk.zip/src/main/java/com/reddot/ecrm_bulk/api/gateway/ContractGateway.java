package com.reddot.ecrm_bulk.api.gateway;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm_bulk.api.exception.*;
import com.reddot.ecrm_bulk.api.payload.*;
import com.reddot.ecrm_bulk.api.payload.QueryDebitNoteResponse;
import com.reddot.ecrm_bulk.api.payload.SmartErrorResponse;
import com.reddot.ecrm_bulk.api.payload.change_account_information.ChangeAccountInformationCommonResponse;
import com.reddot.ecrm_bulk.api.payload.change_account_information.ChangeAccountInformationErrorResponse;
import com.reddot.ecrm_bulk.api.payload.change_account_information.ChangeAccountInformationRequest;
import com.reddot.ecrm_bulk.api.payload.change_account_information.ChangeAccountInformationResponse;
import com.reddot.ecrm_bulk.api.payload.customer.CBSBCCustomerErrorResponse;
import com.reddot.ecrm_bulk.api.payload.customer.CBSBCCustomerResponse;
import com.reddot.ecrm_bulk.api.payload.group.*;
import com.reddot.ecrm_bulk.api.payload.order.CreateOrderRequest;
import com.reddot.ecrm_bulk.api.payload.order.CreateOrderResponse;
import com.reddot.ecrm_bulk.api.payload.subscriber.*;
import com.reddot.ecrm_bulk.api.utils.CommonConstant;
import com.reddot.ecrm_bulk.api.utils.HttpClient;
import com.reddot.ecrm_bulk.api.utils.Utils;
import com.reddot.ecrm_bulk.enums.requestType.CommonStatusEnum;
import com.reddot.ecrm_bulk.enums.requestType.PrimaryTableNameEnum;
import com.reddot.ecrm_bulk.enums.requestType.RequestTypeEnum;
import com.reddot.ecrm_bulk.service.logger.APILoggerService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Response;
import org.hibernate.validator.constraints.URL;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.io.UnsupportedEncodingException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor
public class ContractGateway {
    @Value("${smart.egw.base.url}")
    String baseUrlEGW;
    @Value("${smart.igw.base.url}")
    String baseUrlIGW;
    private final HttpClient httpClient;
    private final Gson gson;
    private final AuthorizationGateway authorizationGateway;
    private final APILoggerService logger;

    public List<QueryDebitNoteResponse> queryDebitNote(String extTransId) {
        String apiUrl = baseUrlIGW + "/api/debit-notes/v1/" + extTransId;

        try (Response response = httpClient.get(apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                String responseStr = response.body().string();
                log.debug("QueryDebitNote Response: {} for ExtTransId: {}", responseStr, extTransId);
                if (responseStr.contains("The Ext Trans ID does not exist!")) {
                    log.debug("The Ext Trans "+ extTransId +" does not exist!");
                    return new ArrayList<>();
                } else {
                    return gson.fromJson(responseStr, new TypeToken<List<QueryDebitNoteResponse>>(){}.getType());
                }
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new UrlNotFoundException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                log.debug("QueryDebitNote error response: {} for extTransId: {}", gson.toJson(errorResponse), extTransId);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("QueryDebitNote Api Request Error for ExtId: {} Message: {}", extTransId, e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("QueryDebitNote Access Token for ExtId: {} Error: {}", extTransId, e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialsException) {
                log.debug("QueryDebitNote Credentials for ExtId: {} Error: {}", extTransId, e.getMessage());
                throw new InvalidClientCredentialsException(e.getMessage());
            } else if (e instanceof UrlNotFoundException) {
                log.debug("QueryDebitNote UrlNotFound ExtId: {} Error: {}", extTransId, e.getMessage());
                throw new UrlNotFoundException(e.getMessage());
            } else {
                log.error("QueryDebitNote Error for ExtId: {} {}", extTransId, e.getMessage(), e.getCause());
                throw new ApiRequestException(e.getMessage(), e.getCause());
            }
        }
    }

    @Retryable(value = { PendingBusinessOrderException.class }, include = { ThrottleException.class, ConnectionResetException.class },  maxAttemptsExpression = "${retry.maxAttempts}" , backoff = @Backoff(delayExpression = "${retry.maxDelay}"))
    public ChangeAccountCreditLimitResponse changeAccountCreditLimit(ChangeAccountCreditLimitRequest creditLimitRequest) {
        String apiUrl = baseUrlEGW + "/HWCRM/Account/ChangeAccountCreditLimit/v1.0";
        String json = gson.toJson(creditLimitRequest);

        try (Response response = httpClient.post(json, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                ChangeAccountCreditLimitResponse changeAccountCreditLimitResponse = gson.fromJson(response.body().string(), ChangeAccountCreditLimitResponse.class);
                log.debug("Change Credit Limit Response: {} for AccountId: {}", creditLimitRequest.getAccount().getAcctId(), gson.toJson(changeAccountCreditLimitResponse));

                if (changeAccountCreditLimitResponse.getChangeAccountCreditLimitRspMsg().getRspHeader().getReturnCode().equalsIgnoreCase("1211000473")) {
                    throw new PendingBusinessOrderException(changeAccountCreditLimitResponse.getChangeAccountCreditLimitRspMsg().getRspHeader().getReturnMsg());
                } else {
                    return changeAccountCreditLimitResponse;
                }
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                log.debug("Change Credit Limit Error Response: {}", gson.toJson(errorResponse));
                if (errorResponse.getFault().getCode() == CommonConstant.THROTTLE_ERROR_CODE) {
                    throw new ThrottleException(errorResponse.getFault().getMessage());
                } else {
                    throw new ApiRequestException(errorResponse.getFault().getMessage());
                }
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("Change Credit Limit Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("Change Credit Limit Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialsException) {
                log.debug("Change Credit Limit Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialsException(e.getMessage());
            } else if (e instanceof ThrottleException) {
                log.debug("Change Credit Limit Throttle Error: {}", e.getMessage());
                throw new ThrottleException(e.getMessage());
            } else if (e instanceof PendingBusinessOrderException) {
                log.debug("Change Credit Limit Pending Business Order Error: {}", e.getMessage());
                throw new PendingBusinessOrderException(e.getMessage());
            } else {
                log.error("Change Credit Limit Error: {}", e.getMessage(), e.getCause());
                throw new ApiRequestException(e.getMessage(), e.getCause());
            }
        }
    }

    public CreateOrderResponse createOrder(CreateOrderRequest orderReq) {
        String apiUrl = baseUrlEGW + "/order/createOrder/v1.0";
        String json = gson.toJson(orderReq);
        long startTime = System.currentTimeMillis();

        try (Response response = httpClient.put(json, apiUrl, getHeaders())) {
            long elapsed = System.currentTimeMillis() - startTime;
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                CreateOrderResponse createOrderResponse = gson.fromJson(response.body().string(), CreateOrderResponse.class);
                log.debug("Create Order Response for MSISDN: {} and Response: {}",orderReq.getSubscriber().getServiceNum(),  gson.toJson(createOrderResponse));

                CommonStatusEnum statusEnum = createOrderResponse.getCreateOrderRspMsg().getRspHeader().getReturnCode().equals("0000") ? CommonStatusEnum.Success : CommonStatusEnum.Failed;
                logger.store(RequestTypeEnum.Create_Order,orderReq.getReqHeader().getTransactionId(), 1, "Postpaid_Activation",gson.toJson(orderReq), gson.toJson(createOrderResponse), null, startTime, elapsed, statusEnum);

                switch (createOrderResponse.getCreateOrderRspMsg().getRspHeader().getReturnCode()) {
                    case "1231000178":
                        throw new AlreadyExistsException(createOrderResponse.getCreateOrderRspMsg().getRspHeader().getReturnMsg());
                    case "1211000533":
                        throw new ServiceNumberNotFoundException(createOrderResponse.getCreateOrderRspMsg().getRspHeader().getReturnMsg());
                    case "1211000980":
                        throw new SIMCardNotExistsException(createOrderResponse.getCreateOrderRspMsg().getRspHeader().getReturnMsg());
                    case "0000":
                        return createOrderResponse;
                    default:
                        throw new ApiRequestException(createOrderResponse.getCreateOrderRspMsg().getRspHeader().getReturnMsg());
                }
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new UrlNotFoundException("Url Not Found: " + apiUrl);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                log.debug("Create Order error response :{}", gson.toJson(errorResponse));
                logger.store(RequestTypeEnum.Create_Order,orderReq.getReqHeader().getTransactionId(), 1, "Postpaid_Activation",json, null, gson.toJson(errorResponse), startTime, elapsed, CommonStatusEnum.Failed);

                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("Create Order Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("Create Order Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialsException) {
                log.debug("Create Order Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialsException(e.getMessage());
            } else if (e instanceof UrlNotFoundException) {
                log.debug("Create Order UrlNotFound for MSISDN: {} Message: {}", orderReq.getSubscriber().getServiceNum(), e.getMessage());
                throw new UrlNotFoundException(e.getMessage());
            } else if (e instanceof AlreadyExistsException) {
                log.debug("Create Order AlreadyExists for MSISDN: {} Message: {}", orderReq.getSubscriber().getServiceNum(), e.getMessage());
                throw new AlreadyExistsException(e.getMessage());
            } else if (e instanceof ServiceNumberNotFoundException) {
                log.debug("Create Order ServiceNumberNotFound for MSISDN: {} Message: {}", orderReq.getSubscriber().getServiceNum(), e.getMessage());
                throw new ServiceNumberNotFoundException(e.getMessage());
            } else if (e instanceof SIMCardNotExistsException) {
                log.debug("Create Order SIMCardNotExists Exception for MSISDN: {} Message: {}", orderReq.getSubscriber().getServiceNum(), e.getMessage());
                throw new SIMCardNotExistsException(e.getMessage());
            } else {
                log.error("Create Order Error: {}", e.getMessage(), e.getCause());
                throw new ApiRequestException(e.getMessage(), e.getCause());
            }
        }
    }
//    @Retryable(value = { ConnectionResetException.class }, maxAttemptsExpression = "${retry.socket.maxAttempts}" , backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    @Retryable(value = { PendingBusinessOrderException.class }, include = { ConnectionResetException.class },  maxAttemptsExpression = "${retry.maxAttempts}" , backoff = @Backoff(delayExpression = "${retry.maxDelay}"))
    public AddGroupCUGResponse addGroupCUG(AddGroupCUGRequest addGroupCUGRequest, String groupId) {
        String apiUrl = baseUrlIGW + "/api/bss/cug/v2/groups/"+groupId+"/members";
        String json = gson.toJson(addGroupCUGRequest);

        try (Response response = httpClient.post(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.CREATED.value()) {
                AddGroupCUGResponse addGroupCUGResponse = gson.fromJson(response.body().string(), AddGroupCUGResponse.class);
                log.debug("AddGroupCUG Response: {} for MSISDN: {}", gson.toJson(addGroupCUGResponse), addGroupCUGRequest.getAddCUGGroupMemberReq().getAddMemberInfo().getMemberServiceNum());
                if (!ObjectUtils.isEmpty(addGroupCUGResponse.getTransaction_status())
                        && addGroupCUGResponse.getTransaction_status().equalsIgnoreCase("SUCCESS")) {
                    return addGroupCUGResponse;
                } else {
                    throw new ApiRequestException(addGroupCUGResponse.getTransaction_status());
                }
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new UrlNotFoundException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else if (response.code() == HttpStatus.BAD_REQUEST.value()) {
                SmartErrorResponse errorResponse = gson.fromJson(response.body().string(), SmartErrorResponse.class);
                if (errorResponse.getError().getCode().equalsIgnoreCase("1211001021")) {
                    throw new AlreadyExistsException(errorResponse.getError().getMessage());
                } else if (errorResponse.getError().getCode().equalsIgnoreCase("1211000472")) {
                    throw new PendingBusinessOrderException(errorResponse.getError().getMessage());
                } else {
                    throw new ApiRequestException(errorResponse.getError().getMessage());
                }
            } else {
                SmartErrorResponse errorResponse = gson.fromJson(response.body().string(), SmartErrorResponse.class);
                log.debug("AddGroupCUG error response :{}", gson.toJson(errorResponse));
                throw new ApiRequestException(errorResponse.getError().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("AddGroupCUG Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("AddGroupCUG Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialsException) {
                log.debug("AddGroupCUG Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialsException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("AddGroupCUG Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            } else if (e instanceof AlreadyExistsException) {
                log.debug("AddGroupCUG AlreadyExists for MSISDN: {}", addGroupCUGRequest.getAddCUGGroupMemberReq().getAddMemberInfo().getMemberServiceNum());
                throw new AlreadyExistsException(e.getMessage());
            } else if (e instanceof PendingBusinessOrderException) {
                log.debug("AddGroupCUG Pending Business Order for MSISDN: {}", addGroupCUGRequest.getAddCUGGroupMemberReq().getAddMemberInfo().getMemberServiceNum());
                throw new PendingBusinessOrderException(e.getMessage());
            } else if (e instanceof UrlNotFoundException) {
                log.debug("AddGroupCUG UrlNotFound for MSISDN: {}", addGroupCUGRequest.getAddCUGGroupMemberReq().getAddMemberInfo().getMemberServiceNum());
                throw new UrlNotFoundException(e.getMessage());
            } else {
                log.error("AddGroupCUG Error: {}", e.getMessage(), e.getCause());
                throw new ApiRequestException(e.getMessage(), e.getCause());
            }
        }
    }
    @Retryable(value = { PendingBusinessOrderException.class }, include = {SubscriberNotFoundException.class} ,maxAttemptsExpression = "${retry.maxAttempts}" , backoff = @Backoff(delayExpression = "${retry.maxDelay}"))
    public AddCorporateGroupResponse addCorporateGroup(AddCorporateGroupRequest groupReq) {
        String apiUrl = baseUrlEGW + "/AddCorporateGroup/V1.0";
        String json = gson.toJson(groupReq);

        try (Response response = httpClient.put(json, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                AddCorporateGroupResponse addCorporateGroupResponse = gson.fromJson(response.body().string(), AddCorporateGroupResponse.class);
                log.debug("AddCorporateGroup Response: {} for MSISDN: {}", gson.toJson(addCorporateGroupResponse), groupReq.getAddMemberInfo().getMemberServiceNum());

                switch (addCorporateGroupResponse.getAddCorporateGroupMemberRspMsg().getRspHeader().getReturnCode()) {
                    case "1211000472":
                        throw new PendingBusinessOrderException(addCorporateGroupResponse.getAddCorporateGroupMemberRspMsg().getRspHeader().getReturnMsg());
                    case "1211002201":
                        throw new AlreadyExistsException(addCorporateGroupResponse.getAddCorporateGroupMemberRspMsg().getRspHeader().getReturnMsg());
                    case "1211000433":
                        throw new SubscriberNotFoundException(addCorporateGroupResponse.getAddCorporateGroupMemberRspMsg().getRspHeader().getReturnMsg());
                    case "0000":
                        return addCorporateGroupResponse;
                    default:
                        throw new ApiRequestException(addCorporateGroupResponse.getAddCorporateGroupMemberRspMsg().getRspHeader().getReturnMsg());
                }
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new UrlNotFoundException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                log.debug("AddCorpGroup Error Response: {}", gson.toJson(errorResponse));
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("AddCorpGroup Api Request Error for MSISDN: {} Error: {}", groupReq.getAddMemberInfo().getMemberServiceNum(),  e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("AddCorpGroup Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialsException) {
                log.debug("AddCorpGroup Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialsException(e.getMessage());
            } else if (e instanceof PendingBusinessOrderException) {
                log.debug("AddCorpGroup Pending Business Order for MSISDN: {}", groupReq.getAddMemberInfo().getMemberServiceNum());
                throw new PendingBusinessOrderException(e.getMessage());
            } else if (e instanceof AlreadyExistsException) {
                log.debug("AddCorpGroup AlreadyExists for MSISDN: {}", groupReq.getAddMemberInfo().getMemberServiceNum());
                throw new AlreadyExistsException(e.getMessage());
            } else if (e instanceof SubscriberNotFoundException) {
                log.debug("AddCorpGroup SubscriberNotFoundException for MSISDN: {}", groupReq.getAddMemberInfo().getMemberServiceNum());
                throw new SubscriberNotFoundException(e.getMessage());
            } else if (e instanceof UrlNotFoundException) {
                log.debug("AddCorpGroup UrlNotFound for MSISDN: {}", groupReq.getAddMemberInfo().getMemberServiceNum());
                throw new UrlNotFoundException(e.getMessage());
            } else {
                log.error("AddCorpGroup Error for MSISDN: {} {}", groupReq.getAddMemberInfo().getMemberServiceNum(), e.getMessage(), e.getCause());
                throw new ApiRequestException(e.getMessage(), e.getCause());
            }
        }
    }
    @Retryable(value = { SubscriberNotFoundException.class }, maxAttemptsExpression = "${retry.subscriber.maxAttempts}" , backoff = @Backoff(delayExpression = "${retry.subscriber.maxDelay}"))
    public SubscriberInfoResponse subscriberInfo(String subscriberId, String bssUsername, String bssPassword) throws UnsupportedEncodingException {
        String apiUrl = baseUrlIGW + "/api/bss/subscribers/v1/" + subscriberId + "/info?id_type=msisdn&bss_username=" + bssUsername + "&bss_password=" + Utils.urlEncode(bssPassword);

        try (Response response = httpClient.get(apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), SubscriberInfoResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new UrlNotFoundException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else if (response.code() == HttpStatus.BAD_REQUEST.value()) {
                SubscriberInfoErrorResponse errorResponse = gson.fromJson(response.body().string(), SubscriberInfoErrorResponse.class);
                if (!ObjectUtils.isEmpty(errorResponse.getCode()) &&
                        (errorResponse.getCode().equalsIgnoreCase("1005") ||
                                errorResponse.getMessage().equalsIgnoreCase("The subscriber does not exist.")
                        )) {
                    throw new SubscriberNotFoundException(errorResponse.getMessage());
                } else {
                    throw new ApiRequestException(errorResponse.getMessage());
                }
            } else {
                SubscriberInfoErrorResponse errorResponse = gson.fromJson(response.body().string(), SubscriberInfoErrorResponse.class);
                log.debug("SubscriberInfo error response :{}", gson.toJson(errorResponse));
                throw new ApiRequestException(errorResponse.getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("SubscriberInfo Api Request Error for MSISDN: {} Error: {}", subscriberId, e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("SubscriberInfo Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialsException) {
                log.debug("SubscriberInfo Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialsException(e.getMessage());
            } else if (e instanceof SubscriberNotFoundException) {
                log.debug("Subscriber not found: " + subscriberId);
                throw new SubscriberNotFoundException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("SubscriberInfo Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            } else if (e instanceof UrlNotFoundException) {
                log.debug("SubscriberInfo UrlNotFound for MSISDN: {}", subscriberId);
                throw new UrlNotFoundException(e.getMessage());
            } else {
                log.error("SubscriberInfo Error for MSISDN: {} Error: {}", subscriberId, e.getMessage(), e.getCause());
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            }
        }
    }
    @Retryable(value = { PendingBusinessOrderException.class }, include = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.maxAttempts}" , backoff = @Backoff(delayExpression = "${retry.maxDelay}"))
    public PrepaidToPostpaidResponse prepaidToPostpaid(String subscriberId, PrepaidToPostpaidRequest prepaidToPostpaidRequest) {
        String apiUrl = baseUrlIGW + "/api/bss/1207/subscribers/v2/" + subscriberId + "/change-prepaid-to-postpaid?id_type=msisdn";
        String json = gson.toJson(prepaidToPostpaidRequest);

        try (Response response = httpClient.put(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), PrepaidToPostpaidResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new UrlNotFoundException("Url Not Found: " + apiUrl);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                PrepaidToPostpaidErrorResponse errorResponse = gson.fromJson(response.body().string(), PrepaidToPostpaidErrorResponse.class);
                log.debug("PrepaidToPostpaid Error Response: {}", gson.toJson(errorResponse));
                if (! ObjectUtils.isEmpty(errorResponse.getCode()) && errorResponse.getCode().equalsIgnoreCase("1211000215")) {
                    throw new NoDataModifiedException(errorResponse.getMessage());
                } else if (! ObjectUtils.isEmpty(errorResponse.getCode()) && errorResponse.getCode().equalsIgnoreCase("1211000313")) {
                    throw new IncorrectSubscriberPaymentTypeException(errorResponse.getMessage());
                } else if (! ObjectUtils.isEmpty(errorResponse.getCode()) && errorResponse.getCode().equalsIgnoreCase("1211000472")) {
                    throw new PendingBusinessOrderException(errorResponse.getMessage());
                } else {
                    throw new ApiRequestException(errorResponse.getMessage());
                }
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("PrepaidToPostpaidRequest Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("PrepaidToPostpaidRequest Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialsException) {
                log.debug("PrepaidToPostpaidRequest Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialsException(e.getMessage());
            } else if (e instanceof NoDataModifiedException) {
                log.debug("PrepaidToPostpaid NoDataModified for MSISDN: {}", subscriberId);
                throw new NoDataModifiedException(e.getMessage());
            } else if (e instanceof IncorrectSubscriberPaymentTypeException) {
                log.debug("PrepaidToPostpaid IncorrectSubscriberPaymentType for MSISDN: {}", subscriberId);
                throw new IncorrectSubscriberPaymentTypeException(e.getMessage());
            } else if (e instanceof PendingBusinessOrderException) {
                log.debug("PrepaidToPostpaid Pending Business Order for MSISDN: {}", subscriberId);
                throw new PendingBusinessOrderException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.error("PrepaidToPostpaid Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            }  else if (e instanceof SocketTimeoutException) {
                log.error("PrepaidToPostpaid SocketTimeoutException");
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof UrlNotFoundException) {
                log.debug("PrepaidToPostpaid UrlNotFound for MSISDN: {}", subscriberId);
                throw new UrlNotFoundException(e.getMessage());
            } else {
                log.error("PrepaidToPostpaidRequest Error: {}", e.getMessage(), e.getCause());
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            }
        }
    }
    public CBSBCCustomerResponse cbsbcCustomer(String msisdn, String bssUsername, String bssPassword) throws UnsupportedEncodingException {
        String apiUrl = baseUrlIGW + "/api/cbsbc/customers/v1/"+msisdn+"?id_type=msisdn&bss_username=" + bssUsername + "&bss_password=" + Utils.urlEncode(bssPassword);

        try (Response response = httpClient.get(apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {

                String responseStr = response.body().string();
                JSONObject jsonObject = new JSONObject(responseStr);

                if (jsonObject.has("QueryCustomerInfoResult")) {
                    JSONObject QueryCustomerInfoResult = jsonObject.getJSONObject("QueryCustomerInfoResult");

                    if (QueryCustomerInfoResult.has("Subscriber")) {
                        JSONObject Subscriber = QueryCustomerInfoResult.getJSONObject("Subscriber");

                        if (Subscriber.has("SupplementaryOffering")) {
                            if (Subscriber.get("SupplementaryOffering").getClass().getName().contains("org.json.JSONObject")) {
                                JSONObject SupplementaryOfferingObject = Subscriber.getJSONObject("SupplementaryOffering");
                                JSONArray SupplementaryOfferingJsonArray = Utils.convertJsonObjectToArray(SupplementaryOfferingObject);
                                Subscriber.put("SupplementaryOffering", SupplementaryOfferingJsonArray);
                            }
                        }
                    }

                    if (QueryCustomerInfoResult.has("Subscriber")) {
                        JSONObject Subscriber = QueryCustomerInfoResult.getJSONObject("Subscriber");

                        if (Subscriber.has("SubscriberInfo")) {
                            JSONObject SubscriberInfo = Subscriber.getJSONObject("SubscriberInfo");

                            if (SubscriberInfo.has("UserCustomer")) {
                                JSONObject UserCustomer = SubscriberInfo.getJSONObject("UserCustomer");

                                if (UserCustomer.has("IndividualInfo")) {
                                    JSONObject IndividualInfo = UserCustomer.getJSONObject("IndividualInfo");

                                    if (IndividualInfo.get("IndividualProperty").getClass().getName().contains("org.json.JSONObject")) {
                                        JSONObject IndividualPropertyObject = IndividualInfo.getJSONObject("IndividualProperty");
                                        JSONArray IndividualPropertyJsonArray = Utils.convertJsonObjectToArray(IndividualPropertyObject);
                                        IndividualInfo.put("IndividualProperty", IndividualPropertyJsonArray);
                                    }
                                }
                            }
                        }
                    }
                    if (QueryCustomerInfoResult.has("Account")) {
                        JSONObject Account = QueryCustomerInfoResult.getJSONObject("Account");

                        if (Account.has("AcctInfo")) {
                            JSONObject AcctInfo = Account.getJSONObject("AcctInfo");

                            if (AcctInfo.has("UserCustomer")) {
                                JSONObject UserCustomer = AcctInfo.getJSONObject("UserCustomer");

                                if (UserCustomer.has("IndividualInfo")) {
                                    JSONObject IndividualInfo = UserCustomer.getJSONObject("IndividualInfo");

                                    if (IndividualInfo.get("IndividualProperty").getClass().getName().contains("org.json.JSONObject")) {
                                        JSONObject IndividualPropertyObject = IndividualInfo.getJSONObject("IndividualProperty");
                                        JSONArray IndividualPropertyJsonArray = Utils.convertJsonObjectToArray(IndividualPropertyObject);
                                        IndividualInfo.put("IndividualProperty", IndividualPropertyJsonArray);
                                    }
                                }
                            }
                        }
                    }

                    if (QueryCustomerInfoResult.has("Customer")) {
                        JSONObject Customer = QueryCustomerInfoResult.getJSONObject("Customer");

                        if (Customer.has("IndividualInfo")) {
                            JSONObject IndividualInfo = Customer.getJSONObject("IndividualInfo");

                            if (IndividualInfo.get("IndividualProperty").getClass().getName().contains("org.json.JSONObject")) {
                                JSONObject IndividualPropertyObject = IndividualInfo.getJSONObject("IndividualProperty");
                                JSONArray IndividualPropertyJsonArray = Utils.convertJsonObjectToArray(IndividualPropertyObject);
                                IndividualInfo.put("IndividualProperty", IndividualPropertyJsonArray);
                            }
                        }
                    }

                }

                return gson.fromJson(String.valueOf(jsonObject), CBSBCCustomerResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new UrlNotFoundException("Url Not Found: " + apiUrl);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                CBSBCCustomerErrorResponse errorResponse = gson.fromJson(response.body().string(), CBSBCCustomerErrorResponse.class);
                log.debug("CBSBCCustomer error response :{}", gson.toJson(errorResponse));
                if (errorResponse.getCode().equals("118030260")) {
                    throw new SubscriberNotFoundException(errorResponse.getMessage());
                } else {
                    throw new ApiRequestException(errorResponse.getMessage());
                }
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("CBSBCCustomer Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("CBSBCCustomer Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialsException) {
                log.debug("CBSBCCustomer Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialsException(e.getMessage());
            } else if (e instanceof UrlNotFoundException) {
                log.debug("CBSBCCustomer UrlNotFound for MSISDN: {}", msisdn);
                throw new UrlNotFoundException(e.getMessage());
            } else if (e instanceof SubscriberNotFoundException) {
                log.debug("CBSBCCustomer Subscriber Message for MSISDN: {}", msisdn);
                throw new SubscriberNotFoundException(e.getMessage());
            } else {
                log.error("CBSBCCustomer Error: {}", e.getMessage(), e.getCause());
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            }
        }
    }
    @Retryable(value = { PendingBusinessOrderException.class }, include = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.maxAttempts}" , backoff = @Backoff(delayExpression = "${retry.maxDelay}"))
    public ChangeCorporateGroupMemberInfoResponse changeCorporateGroupMemberInfo(ChangeCorporateGroupMemberInfoRequest groupMemberInfoRequest) {
        String apiUrl = baseUrlEGW + "/HWCRM/ChangeCorporateGroupMemberInformation/v1.0";
        String json = gson.toJson(groupMemberInfoRequest);

        try (Response response = httpClient.post(json, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                ChangeCorporateGroupMemberInfoResponse changeCorporateGroupMemberInfoResponse = gson.fromJson(response.body().string(), ChangeCorporateGroupMemberInfoResponse.class);
                log.debug("{}", changeCorporateGroupMemberInfoResponse);
                if (!ObjectUtils.isEmpty(changeCorporateGroupMemberInfoResponse) && changeCorporateGroupMemberInfoResponse.getChangeCorporateGroupMemberInfoRspMsg().getRspHeader().getReturnCode().equals("1219000485")) {
                    throw new SubscriberHasSomeOutstandingException(changeCorporateGroupMemberInfoResponse.getChangeCorporateGroupMemberInfoRspMsg().getRspHeader().getReturnMsg());
                } else if (!ObjectUtils.isEmpty(changeCorporateGroupMemberInfoResponse) && changeCorporateGroupMemberInfoResponse.getChangeCorporateGroupMemberInfoRspMsg().getRspHeader().getReturnCode().equals("0000")) {
                    return changeCorporateGroupMemberInfoResponse;
                }  else if (!ObjectUtils.isEmpty(changeCorporateGroupMemberInfoResponse) && changeCorporateGroupMemberInfoResponse.getChangeCorporateGroupMemberInfoRspMsg().getRspHeader().getReturnCode().equals("1211000472")) {
                    throw new PendingBusinessOrderException(changeCorporateGroupMemberInfoResponse.getChangeCorporateGroupMemberInfoRspMsg().getRspHeader().getReturnMsg());
                } else {
                    throw new ApiRequestException(changeCorporateGroupMemberInfoResponse.getChangeCorporateGroupMemberInfoRspMsg().getRspHeader().getReturnMsg());
                }
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new UrlNotFoundException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                log.debug("ChangeCorporateGroupMemberInfo error response: {}", gson.toJson(errorResponse));
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("ChangeCorporateGroupMemberInfo Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("ChangeCorporateGroupMemberInfo Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            }  else if (e instanceof InvalidClientCredentialsException) {
                log.debug("ChangeCorporateGroupMemberInfo Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialsException(e.getMessage());
            } else if (e instanceof SubscriberHasSomeOutstandingException) {
                log.debug("ChangeCorporateGroupMemberInfo Subscriber Has Some Outstanding: {}", e.getMessage());
                throw new SubscriberHasSomeOutstandingException(e.getMessage());
            } else if (e instanceof UrlNotFoundException) {
                log.debug("ChangeCorporateGroupMemberInfo UrlNotFound for MSISDN: {}", groupMemberInfoRequest.getAccessInfo().getObjectId());
                throw new UrlNotFoundException(e.getMessage());
            }  else if (e instanceof PendingBusinessOrderException) {
                log.debug("ChangeCorporateGroupMemberInfo Pending Business Order for MSISDN: {}", groupMemberInfoRequest.getAccessInfo().getObjectId());
                throw new PendingBusinessOrderException(e.getMessage());
            } else {
                log.error("ChangeCorporateGroupMemberInfo Error: {}", e.getMessage(), e.getCause());
                throw new ApiRequestException(e.getMessage());
            }
        }
    }

    @Retryable(value = { PendingBusinessOrderException.class }, include = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.maxAttempts}" , backoff = @Backoff(delayExpression = "${retry.maxDelay}"))
    public ChangeSupplementaryOfferingResponse changeSupplementaryOffering(ChangeSupplementaryOfferingRequest offeringRequest) {
        String apiUrl = baseUrlEGW + "/offering/changeSupplementaryOffering/V1.0";
        String json = gson.toJson(offeringRequest);

        try (Response response = httpClient.put(json, apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                ChangeSupplementaryOfferingResponse changeSupplementaryOfferingResponse = gson.fromJson(response.body().string(), ChangeSupplementaryOfferingResponse.class);
                log.debug("Change SupplementaryOffering Response: {} for MSISDN: {}", gson.toJson(changeSupplementaryOfferingResponse), offeringRequest.getAccessInfo().getObjectId());

                if (changeSupplementaryOfferingResponse.getChangeSupplementaryOfferingRspMsg().getRspHeader().getReturnCode().equalsIgnoreCase("9999")) {
                    throw new PendingBusinessOrderException(changeSupplementaryOfferingResponse.getChangeSupplementaryOfferingRspMsg().getRspHeader().getReturnMsg());
                } else {
                    return changeSupplementaryOfferingResponse;
                }
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                log.debug("Change SupplementaryOffering errorResponse :{} for MSISDN: {}", gson.toJson(errorResponse), offeringRequest.getAccessInfo().getObjectId());
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("Change SupplementaryOffering Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("Change SupplementaryOffering Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialsException) {
                log.debug("Change SupplementaryOffering Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialsException(e.getMessage());
            }  else if (e instanceof PendingBusinessOrderException) {
                log.debug("Change SupplementaryOffering Pending Business Order Error: {}", e.getMessage());
                throw new PendingBusinessOrderException(e.getMessage());
            } else {
                log.error("Change SupplementaryOffering Error: {}", e.getMessage(), e.getCause());
                throw new ApiRequestException(e.getMessage(), e.getCause());
            }
        }
    }


    public QueryPurchasedSupplementaryOfferingResponse queryPurchasedSupplementaryOffering(String partnerId, String transactionId, String reqTime, String channel, String accessUser, String accessPassword, String objectIdType, String objectId) throws UnsupportedEncodingException {
        String apiUrl = baseUrlEGW + "/offering/queryPurchasedSupplementaryOffering/V1.0?partnerId=" + partnerId + "&" + "transactionId=" + transactionId + "&" + "reqTime=" + reqTime + "&" + "channel=" + channel + "&" + "accessUser=" + accessUser + "&" + "accessPassword=" + Utils.urlEncode(accessPassword) + "&" + "objectIdType=" + objectIdType + "&" + "objectId=" + objectId;

        try (Response response = httpClient.get(apiUrl, getHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                String responseStr = response.body().string();
                log.debug("QueryPurchaseSupplementaryOffering Response: {}", responseStr);
                JSONObject jsonObject = new JSONObject(responseStr);

                if (jsonObject.has("QueryPurchasedSupplementaryOfferingRspMsg")) {
                    JSONObject QueryPurchasedSupplementaryOfferingRspMsg = jsonObject.getJSONObject("QueryPurchasedSupplementaryOfferingRspMsg");

                    if (QueryPurchasedSupplementaryOfferingRspMsg.has("SupplementaryOffering")) {
                        if (QueryPurchasedSupplementaryOfferingRspMsg.get("SupplementaryOffering").getClass().getName().contains("org.json.JSONObject")) {
                            JSONObject SupplementaryOfferingObject = QueryPurchasedSupplementaryOfferingRspMsg.getJSONObject("SupplementaryOffering");
                            JSONArray SupplementaryOfferingJsonArray = Utils.convertJsonObjectToArray(SupplementaryOfferingObject);
                            QueryPurchasedSupplementaryOfferingRspMsg.put("SupplementaryOffering", SupplementaryOfferingJsonArray);
                        }
                    }
                }

                return gson.fromJson(String.valueOf(jsonObject), QueryPurchasedSupplementaryOfferingResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ErrorResponse errorResponse = gson.fromJson(response.body().string(), ErrorResponse.class);
                log.debug("SupplementaryOffering errorResponse : {}", errorResponse);
                throw new ApiRequestException(errorResponse.getFault().getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("SupplementaryOffering Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("SupplementaryOffering Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialsException) {
                log.debug("SupplementaryOffering Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialsException(e.getMessage());
            } else {
                log.error("SupplementaryOffering Error: {}", e.getMessage(), e.getCause());
                throw new ApiRequestException(e.getMessage(), e.getCause());
            }
        }
    }

    @Retryable(value = { PendingBusinessOrderException.class }, include = {ConnectionResetException.class}, maxAttemptsExpression = "${retry.maxAttempts}" , backoff = @Backoff(delayExpression = "${retry.maxDelay}"))
    public ChangeAccountInformationCommonResponse changeAccountInformation(String accountId, ChangeAccountInformationRequest accountInformationRequest) {
        String apiUrl = baseUrlIGW + "/api/bss/0102/accounts/v2/" + accountId + "/info";
        String json = gson.toJson(accountInformationRequest);
        ChangeAccountInformationCommonResponse changeAccountInformationCommonResponse = new ChangeAccountInformationCommonResponse();
        try (Response response = httpClient.put(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                ChangeAccountInformationResponse changeAccountInformationResponse = gson.fromJson(response.body().string(), ChangeAccountInformationResponse.class);
                changeAccountInformationCommonResponse.setIsSuccess(true);
                changeAccountInformationCommonResponse.setCode("0000");
                changeAccountInformationCommonResponse.setMessage(changeAccountInformationResponse.getTransaction_status());
                log.debug("ChangeAccountInformation Response : {} for AccountId: {}", gson.toJson(changeAccountInformationResponse), accountId);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new UrlNotFoundException("Url Not Found: " + apiUrl);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ChangeAccountInformationErrorResponse errorResponse = gson.fromJson(response.body().string(), ChangeAccountInformationErrorResponse.class);
                log.debug("ChangeAccountInformation errorResponse: {} for AccountId: {}", gson.toJson(errorResponse), accountId);

                if (! ObjectUtils.isEmpty(errorResponse.getError()) &&
                        errorResponse.getError().getCode().equalsIgnoreCase("1211000473")) {
                    throw new PendingBusinessOrderException(errorResponse.getError().getMessage());
                } else {
                    changeAccountInformationCommonResponse.setIsSuccess(true);
                    changeAccountInformationCommonResponse.setCode(errorResponse.getError().getCode());
                    changeAccountInformationCommonResponse.setMessage(errorResponse.getError().getMessage());
                }
            }
            return changeAccountInformationCommonResponse;
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("ChangeAccountInformation Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("ChangeAccountInformation Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialsException) {
                log.debug("ChangeAccountInformation Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialsException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.debug("ChangeAccountInformation Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            } else if (e instanceof UrlNotFoundException) {
                log.debug("ChangeAccountInformation UrlNotFound Error: {}", e.getMessage());
                throw new UrlNotFoundException(e.getMessage());
            } else if (e instanceof PendingBusinessOrderException) {
                log.debug("ChangeAccountInformation Pending Business Order Error: {}", e.getMessage());
                throw new PendingBusinessOrderException(e.getMessage());
            } else {
                log.error("ChangeAccountInformation Error: {}", e.getMessage(), e.getCause());
                throw new ApiRequestException(e.getMessage(), e.getCause());
            }
        }
    }

    private Map<String, String> getIGWHeaders() {
        String bearerToken = authorizationGateway.getTokenIGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }
    private Map<String, String> getHeaders() {
        String bearerToken = authorizationGateway.getTokenEGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }
}
