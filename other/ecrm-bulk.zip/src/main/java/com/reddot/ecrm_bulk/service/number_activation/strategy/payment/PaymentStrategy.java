package com.reddot.ecrm_bulk.service.number_activation.strategy.payment;

import com.reddot.ecrm_bulk.entity.annex.Annex;
import com.reddot.ecrm_bulk.entity.contract.Contract;

import java.io.UnsupportedEncodingException;

public interface PaymentStrategy {
    void process(Contract contract, Annex annex) throws UnsupportedEncodingException;
}
