package com.reddot.ecrm_bulk.entity.statement_note;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "tbl_statement_note")
public class StatementNoteEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Boolean isIndividual;
    private Long companyId;
    private String companyName;
    private String address;
    private String purpose;
    private Integer quantity;
    private Double unitPrice;
    private Double amount;
    private String transactionId;
    private String indivisualTransactionId;
    private String apiAccountKeyCode;

    private String featureName;
    private Long featureId;
    private String status;
    private Long primaryTableId;
    private String primaryTableName;


    private Long processAt;
    private Timestamp processAtDt;

    @Column(name = "created_at")
    private Long createdAt;

    @Column(name = "created_at_dt")
    private Timestamp createdAtDt;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_by_username")
    private String createdUsername;

}

