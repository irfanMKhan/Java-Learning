package com.reddot.ecrm_bulk.config;

import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.reddot.ecrm_bulk.model.CommonMDModel;
import com.reddot.ecrm_bulk.model.FeeDetailModel;

import com.google.gson.Gson;

import com.google.common.base.Splitter;

public class Utility {

    /* SR Tables : start */
    public static String md_sr_service_type = "MD_SR_SERVICE_TYPE";
    public static String md_sr_type = "MD_SR_TYPE";
    public static String md_sr_area = "MD_SR_AREA";
    public static String md_sr_sub_area = "MD_SR_SUB_AREA";
    public static String md_sr_status = "MD_SR_STATUS";
    public static String md_sr_priority = "MD_SR_PRIORITY";
    public static String md_sr_severity = "MD_SR_SEVERITY";
    public static String md_sr_root_cause = "MD_SR_ROOT_CAUSE";
    public static String md_sr_action_type = "MD_SR_ACTION_TYPE";
    public static String md_sr_ans_type = "MD_SR_ANS_TYPE";
    public static String md_sr_act_type = "MD_SR_ACT_TYPE";
    public static String file_msisdn_ct = "FILE_MSISDN_CT";
    public static String file_msisdn_ct_details = "FILE_MSISDN_CT_DETAILS";
    public static String md_sr_routing_group = "MD_USER_POSITION";
    public static String test = "MD_USER_POSITION";
    public static String md_user = "MD_USER";
    public static String md_sr_sla = "MD_SR_SLA";
    public static String md_user_group = "MD_USER_GROUP";
    public static String md_sr_notify_mt = "MD_SR_NOTIFY_MT";
    public static String md_sr_esca_mt = "MD_SR_ESCA_MT";
    public static String md_msisdn_list = "MD_MSISDN_LIST";
    public static String tbl_asset_details = "TBL_ASSET_DETAILS";
    public static String tbl_ups_api_call_log = "TBL_UPS_API_CALL_LOG";
    public static String tbl_asset_details_history = "TBL_ASSET_DETAILS_HISTORY";
    public static String tbl_msisdn_action_logs = "TBL_MSISDN_ACTION_LOGS";
    public static String tbl_sr = "TBL_SR";
    public static String tbl_misidn_create_file = "TBL_MSISDN_CREATE_FILE";
    public static String tbl_lov = "MD_LOV";
    public static String tbl_sr_attachment = "TBL_SR_ATTACHMENT";
    public static String tbl_sr_notes = "TBL_SR_NOTES";
    public static String tbl_sr_notes_lov = "TBL_SR_NOTES_LOV";
    public static String tbl_sr_actions = "TBL_SR_ACTIONS";
    public static String tbl_token = "TBL_TOKEN";
    public static String md_user_details = "MD_USER_DETAILS";
    public static String bc_individual = "BC_INDIVIDUAL";
    public static String tbl_order = "TBL_ORDER";
    public static String tbl_order_lov = "TBL_ORDER_LOV";
    public static String seq_name_tbl_sr = "SR_NUM";
    public static String seq_order_id = "ORDER_ID";
    public static String seq_name_tbl_activity = "ACTIVITY_NUM";
    public static final String seq_cm_credit_limit_id_seq = "CM_CREDIT_LIMIT_ID_SEQ";
    public static String cm_credit_limit_value = "CM_CREDIT_LIMIT_VALUE";

    public static String tbl_sr_activity_lov = "TBL_SR_ACTIVITY_LOV";
    public static String tbl_sr_activity = "TBL_SR_ACTIVITY";

    /* SR Tables : End */

    public static String tbl_msisdn_ct_details = "MD_MSISDN_DETAILS";
    public static String tbl_biometric_temp = "TBL_BIOMETRIC_TEMP";
    public static String bc_subscriber = "BC_SUBSCRIBER";

    public static String Area = "TBL_AREA";
    public static String HLRList = "TBL_HLR_LIST";
    public static String tbl_sdp_service_list = "TBL_SDP_SERVICE_LIST";
    public static String tbl_sdp_error_code = "TBL_SDP_ERROR_CODE";
    public static String tbl_aucdata = "TBL_AUC_DATA";
    public static String tbl_auc_details_tmp = "TBL_AUC_DETAILS_TMP";
    public static String tbl_auc_details = "TBL_AUC_DETAILS";
    public static String tbl_product = "MD_PRODUCT";
    public static String tbl_cug = "TBL_CUG";
    public static String tbl_app_logger = "TBL_APP_LOGGER";
    public static String tbl_bulk_upload_file = "TBL_BULK_UPLOAD_FILE";
    public static String tbl_bulk_upload_file_details = "TBL_BULK_UPLOAD_FILE_DETAILS";
    public static String tbl_sms_template = "TBL_SMS_TEMPLATE";
    public static int perPageDataLoad = 5;

    public static String epm_student_payment = "EPM_STUDENT_PAYMENT";
    public static String epm_student_fee = "EPM_STUDENT_FEE";
    public static String epm_class_type = "EPM_CLASS_TYPE";
    public static String epm_fee_details = "EPM_FEE_DETAILS";
    public static String epm_student = "EPM_STUDENT";
    public static String epm_academic_year = "EPM_ACADEMIC_YEAR";
    public static String epm_hostel = "EPM_HOSTEL";
    public static String epm_class = "EPM_CLASS";
    public static String epm_section = "EPM_SECTION";
    public static String epm_shift = "EPM_SHIFT";
    public static String epm_student_group = "EPM_STUDENT_GROUP";
    public static String epm_student_session = "EPM_STUDENT_SESSION";
    public static String epm_institute = "EPM_INSTITUTE";
    public static String epm_month = "EPM_MONTH";
    public static String epm_payment_period = "EPM_PAYMENT_PERIOD";
    public static String epm_fee_category = "EPM_FEE_CATEGORY";
    public static String epm_bulkprocess_files = "EPM_BULKPROCESS_FILES";
    public static String epm_bulkprocess_file_details = "EPM_BULKPROCESS_FILE_DETAILS";
    public static String epm_bulkprocess_response = "EPM_BULKPROCESS_RESPONSE";



    public static String tbl_send_sms_log = "TBL_SEND_SMS_LOG";
    public static String tbl_kdm_msisdn = "TBL_KDM_MSISDN";

    public static int userLoginID = 1;
    //	public static String userLoginName= "jobaidur.rahman";
    public static String domainUrl = "http://localhost:9090";

    // Global Settings: Tables || Start
    public static String md_acc_type = "MD_ACC_TYPE";
    public static String md_acc_class = "MD_ACC_CLASS";
    public static String md_src = "MD_SRC";
    public static String md_src_location = "MD_SRC_LOCATION";
    public static String md_menu = "MD_MENU";
    public static String md_responsibility = "MD_RESPONSIBILITY";
    public static String md_responsibility_menu_map = "MD_RESPONSIBILITY_MENU_MAP";
    public static String md_user_responsibility_map = "MD_USER_RESPONSIBILITY_MAP";
    public static String tbl_demographic_info = "TBL_DEMOGRAPHIC_INFO";
    public static String post_paid_info = "POST_PAID_DEMO_INFO";
    public static String md_user_position = "MD_USER_POSITION";
    public static long country_id = 1;
    public static String country_name = "Bangladesh";
    public static String md_division = "MD_DIVISION";
    public static String md_district = "MD_DISTRICT";
    public static String md_upazila = "MD_UPAZILA_PS";
    public static String tbl_address = "TBL_ADDRESS";

    public static String tbl_adjustment_config = "MD_ADJUSTMENT_CONF";
    public static String tbl_adjustment_bucket = "TBL_ADJUSTMENT_BUCKET";

    public static String crm_demographic_info = "CRM_DEMOGRAPHIC_INFO";

    public static String tbl_loyalty_customer_info = "TBL_LOYALTY_CUSTOMER_INFO";

    public static String tbl_recent_records = "TBL_RECENT_RECORDS";
    public static String tbl_postpaid_creation_temp = "TBL_POSTPAID_CREATION_TEMP";
    public static String tbl_ups_response_logs_final = "TBL_UPS_RESPONSE_LOGS_FINAL";

    // Global Settings: Tables || END

    /************************************************************ Message format : start **********************************************/
    public static String duplicateMsg = "Same #msg already exists.";
    public static String addSuccMsg = "#msg has been added successfully.";
    public static String addFailMsg = "#msg has not been added.";
    public static String emptyMsg = "#msg is empty.";
    public static String updateSuccMsg = "#msg has been updated successfully.";
    public static String updateFailMsg = "#msg has not been updated.";


    /************************************************************ Message format : End **********************************************/
    /************************************************************ Postpaid : Start **********************************************/
    public static String AccountSubType = "Account Subtype";
    public static String ID_Type = "ID Type";
    public static String Customer_Class = "Customer Class";
    public static String Account_Class = "Account Class";
    public static String Credit_Policy = "Credit Policy";
    public static String Dunning_Class = "Dunning Class";
    public static String Dunning_Class_Master = "Dunning Class Master";
    public static String Taxing_Model = "Taxing Model";
    public static String Payment_Method = "Payment Method";
    public static String Payment_Method_Master = "Payment Method Master";
    public static String Bill_Medium = "Bill Medium";
    public static String Bill_Cycle = "Bill Cycle";
    public static String Bank_Name = "Bank Name";
    public static String Bank_Branch_Name = "Bank Branch Name";
    public static String Card_Type = "Card Type";
    public static String Card_Provider = "Card Provider";
    public static String Red_List_Flag = "Red List Flag";

    public static String AccountSubTypeDomestic = "Account Subtype Domestic";
    public static String CustomerClassDomestic = "Customer Class Domestic";

    //Table
    public static String tbl_postpaid_master_acc_info = "TBL_POSTPAID_MASTER_ACC_INFO";
    public static String bc_contact = "BC_CONTACT";
    public static String cm_credit_limit = "CM_CREDIT_LIMIT";
    public static String bc_acct = "BC_ACCT";
    public static String bc_address = "BC_ADDRESS";
    public static String bc_acct_bill_cycle = "BC_ACCT_BILL_CYCLE";
    public static String bc_offering_inst = "BC_OFFERING_INST";
    public static String bc_payment_channel = "BC_PAYMENT_CHANNEL";
    public static String pe_red_list = "PE_RED_LIST";
    public static String tbl_bc_acct = "BC_ACCT";
    public static String bc_sub_group = "BC_SUB_GROUP";
    public static String bc_acct_prop = "BC_ACCT_PROP";
    public static String crm_cust_info = "CRM_CUST_INFO";
    public static String bc_g_member = "BC_G_MEMBER";
    public static String bc_cust_extinfo = "BC_CUST_EXTINFO";

    public static final String seq_bc_g_member_member_id = "SEQ_BC_G_MEMBER_MEMBER_ID";
    public static String tbl_postpaid_bulk_upload_file_details = "TBL_POSTPAID_BULK_UPLOAD_FILE_DETAILS";

    /************************************************************ Postpaid : End **********************************************/


/*
Author: Zakaria
Modified date: 28.01.2020
Reason: Method can return random string of n length
 */
    public String getAlphaNumericString(int n) {

        // chose a Character random from this String
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                + "0123456789"
                + "abcdefghijklmnopqrstuvxyz";

        // create StringBuffer size of AlphaNumericString
        StringBuilder sb = new StringBuilder(n);

        for (int i = 0; i < n; i++) {

            // generate a random number between
            // 0 to AlphaNumericString variable length
            int index
                    = (int) (AlphaNumericString.length()
                    * Math.random());

            // add Character one by one in end of sb
            sb.append(AlphaNumericString
                    .charAt(index));
        }

        return sb.toString();
    }

    public static Map<String, String> splitToMap(String in) {
        Map<String, String> res = Splitter.on(',').withKeyValueSeparator('=').split(in.replace("{", "").replace("}", "").replaceAll(" ", ""));
        return res;
    }

    public double getStringToDoubleAndFormate(String n) {
        System.out.println(n);
        DecimalFormat df2 = new DecimalFormat("0.00");
        double dd2dec = new Double(df2.format(Double.parseDouble(n))).doubleValue();
        return 0.0;
    }

    public static String customgetDate(int MONTH, String fomate) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -MONTH);
        SimpleDateFormat s = new SimpleDateFormat(fomate);
        String result = s.format(new Date(cal.getTimeInMillis()));
        return result;
    }

    public static String dateFormate(String datetype, String Currentdatetype, String CurrentDate) {

        String returnDate = "";

        try {
            Date date1 = new SimpleDateFormat(Currentdatetype).parse(CurrentDate);
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(datetype);
            returnDate = simpleDateFormat.format(date1);
        } catch (ParseException e) {
            System.out.println(e.getMessage());
        }

        return returnDate;
    }

    public static Date getCurrntDateTime() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");  // United States style of format.
        java.util.Date myDate;
        Timestamp sqlDates = null;
        Date date = new Date();
        try {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();

            myDate = format.parse(dtf.format(now));
            sqlDates = new java.sql.Timestamp(myDate.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }


        return sqlDates;
    }

    public static Timestamp getOracleCurrntDateTime() {
        return new java.sql.Timestamp(System.currentTimeMillis());
    }

    public static String addMinutDate(String d2, int scheduleTime) {
        String result = null;
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
        try {
            Date date = formatter.parse(d2);
            Calendar calender = Calendar.getInstance();
            calender.setTime(date);
            calender.add(Calendar.HOUR, +scheduleTime);
            SimpleDateFormat s = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            result = s.format(new Date(calender.getTimeInMillis()));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return result;
    }

    public static long getCurrentTimestamp() {
        Date date = new Date();
        long time = date.getTime();
        return time;
    }

    public static long convertDateTimeToTimestamp(String current_date, String current_format) {
        long time = 0;
        SimpleDateFormat formatter = new SimpleDateFormat(current_format);
        try {
            Date date = formatter.parse(current_date);
            time = date.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return time;

    }

    public static String convertTimestampToDateTime(Long timestamp, String dateFormat) {
        String result = "";

        try {
            Timestamp ts = new Timestamp(timestamp);
            Date date = new Date(ts.getTime());
            SimpleDateFormat s = new SimpleDateFormat(dateFormat);
            result = s.format(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public static String ObjectToJson(Object i) {
        Gson gson = new Gson();
        String json = "";
        try {
            json = gson.toJson(i);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }

        return json;
    }

    public static String getStatusName(int i) {
        String statusName = "";
        if (i == 1) {
            statusName = "Active";
        } else if (i == 2) {
            statusName = "Inactive";
        }
        return statusName;
    }

    public static int getStatusID(String statusName) {
        int statusID = 0;
        if (statusName.toUpperCase().equals("ACTIVE")) {
            statusID = 1;
        } else if (statusName.toUpperCase().equals("INACTIVE")) {
            statusID = 2;
        }
        return statusID;
    }

    public static String getStatusID_str(String statusName) {
        String statusID = "9999999999";
        if (statusName.toUpperCase().equals("ACTIVE")) {
            statusID = "1";
        } else if (statusName.toUpperCase().equals("INACTIVE")) {
            statusID = "2";
        }
        return statusID;
    }

    public static List<String> getHLRList(String[] kk, int i, String name) {
        List<String> ll = new ArrayList<String>();
        if (kk[i].contains("\"" + name)) {
            String[] head = kk[i + 1].trim().split("\"");
            String[] h = head[0].trim().replaceAll("   ", "\n").split("\n");
            for (int j = 0; j < h.length; j++) {
                if (!h[j].equals("")) {
                    ll.add(h[j].trim());
                }
            }
        }
        return ll;
    }

    public static List<String> getHLRListHead(String[] kk, int i, String name) {
        List<String> ll = new ArrayList<String>();
        if (kk[i].contains(name)) {
            String[] head = kk[i].trim().split(":Operation is successful ");
            String[] h = head[1].trim().replaceAll("      ", "\n").split("\n");
            for (int j = 0; j < h.length; j++) {
                if (!h[j].equals("")) {
                    ll.add(h[j].trim());
                }
            }
        }
        return ll;
    }

    /*public static String stackTraceToString(StackTraceElement[] stackTraceElement) {
        StringBuilder builder = new StringBuilder();
        for (StackTraceElement traceElement : stackTraceElement)
            builder.append("\tat " + traceElement + "\n");

        return builder.toString();
    }*/

    public static String getStatusIDRun(String statusName) {
        String statusID = "";

        if (statusName.equals("1")) {
            statusID = "New";
        } else if (statusName.equals("2")) {
            statusID = "Comlpite";
        }
        return statusID;
    }

    public static String getValueFromKey(Map<Integer, String> arry, int key) {
        return key == 0 ? "N/A" : arry.get(key);
    }


    public static ArrayList<String> getNameTitles() {
        ArrayList<String> titles = new ArrayList<>();
        titles.add("Mr");
        titles.add("Mrs");
        titles.add("Ms");
        titles.add("Miss");
        return titles;
    }

    public static Long getPrimaryResponsibilityId() {
        return 31L;
    }

    public static String getPrimaryResponsibilityName() {
        return "Default";
    }

    public static String generateSRNumber(String nextId) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
        if (!nextId.isEmpty())
            return simpleDateFormat.format(new Date()) + nextId;
        else
            return simpleDateFormat.format(new Date()) + System.currentTimeMillis();
    }


    public static String getNumber(String nuber) {
        return nuber;
    }


    public static String getGender(String id) {
        String Gtype = "";
        if (id.equals("1")) {
            Gtype = "Male";
        } else {
            Gtype = "Female";
        }
        return Gtype;
    }

    public static boolean getCurrectTime(String datetype, String Currentdatetype, String CurrentDate) {
        try {
            Date date1 = new SimpleDateFormat(Currentdatetype).parse(CurrentDate);
            Date dt = new Date();
//			System.out.println(date1.after(dt));
//			System.out.println(date1.before(dt));
//			System.out.println(simpleDateFormat.format(dt));
//			System.out.println(returnDate);
            if (date1.before(dt)) {
                return true;
            } else {
                return false;
            }
        } catch (ParseException e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public static String yyyymmddToyyyy_mm_dd(String old) {
        DateTimeFormatter inFormatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        LocalDate date = LocalDate.parse(old, inFormatter);

        DateTimeFormatter outFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String outStr = outFormatter.format(date);
        return outStr;
    }

    public static boolean IsBefore(String CurrentDate) {
        try {
            Date date1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(CurrentDate);
            Date dt = new Date();
            if (date1.before(dt)) {
                return true;
            } else {
                return false;
            }
        } catch (ParseException e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public static String getNextDate(int curDate, int min) {
        final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        Calendar calendar = null;
        try {
            date = format.parse(format.format(date));
            calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(Calendar.HOUR, curDate);
            calendar.add(Calendar.MINUTE, min);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return format.format(calendar.getTime());
    }

    public static List<FeeDetailModel> getFeeDetailPeriodMonth(List<CommonMDModel> months, List<CommonMDModel> periods, String dateFormat, Timestamp fromDate, Timestamp toDate, String period, String startMonth, String amount){
        List<FeeDetailModel> list = new ArrayList<>();

        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
        try {
            int fromMonth = fromDate.getMonth();//formatter.parse(fromDate).getMonth();
            int toMonth = toDate.getMonth();//formatter.parse(toDate).getMonth();
            List<CommonMDModel> startMonthData = months.stream().filter(x -> startMonth.equals(x.getNAME())).collect(Collectors.toList());
            List<CommonMDModel> periodData = periods.stream().filter(x -> period.equals(x.getNAME())).collect(Collectors.toList());
            int startMonthNo = Integer.parseInt(startMonthData.get(0).getMONTH_NO());
            int periodMonthInterval = Integer.parseInt(periodData.get(0).getMONTH_INTERVAL());
            int startFrom = startMonthNo > fromMonth ? startMonthNo : fromMonth;

            for(int j = 0; startFrom <= toMonth; j++){
                FeeDetailModel detail = new FeeDetailModel();
                for (CommonMDModel mo: months) {
                    if(Integer.parseInt(mo.getMONTH_NO()) == startFrom){
                        detail.setPAYMENT_PERIOD_ID(periodData.get(0).getID());
                        detail.setPAYMENT_PERIOD_NAME(periodData.get(0).getNAME());
                        detail.setMONTH_ID(mo.getID());
                        detail.setMONTH_NAME(mo.getNAME());
                        detail.setAMOUNT(amount);
                    }
                }
                list.add(detail);
                startFrom = startFrom + periodMonthInterval;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

}
