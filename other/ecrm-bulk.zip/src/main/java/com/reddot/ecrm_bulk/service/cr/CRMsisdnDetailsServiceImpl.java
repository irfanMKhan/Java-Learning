package com.reddot.ecrm_bulk.service.cr;

import com.reddot.ecrm_bulk.api.exception.NotFoundException;
import com.reddot.ecrm_bulk.entity.cr.CRMsisdnDetailsEntity;
import com.reddot.ecrm_bulk.enums.cr.CRStatusEnum;
import com.reddot.ecrm_bulk.enums.requestType.CommonStatusEnum;
import com.reddot.ecrm_bulk.repository.cr.CRMsisdnDetailsRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.util.List;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class CRMsisdnDetailsServiceImpl implements CRMsisdnDetailsService {
    private final CRMsisdnDetailsRepository crMsisdnDetailsRepository;

    @Override
    public List<CRMsisdnDetailsEntity> findAllCRMsisdnDetailsByCRMasterId(Long id) {
        return crMsisdnDetailsRepository.findAllByChangeRequestMasterId(id);
    }

    @Override
    public List<CRMsisdnDetailsEntity> findAllCRMsisdnDetailsByCRMasterIdWithSuccessStatus(Long id) {
        return crMsisdnDetailsRepository.findAllByChangeRequestMasterIdAndStatus(id, CRStatusEnum.Success.toString());
    }

    @Override
    public CRMsisdnDetailsEntity findById(Long id) {
        Optional<CRMsisdnDetailsEntity> crMsisdnDetails = crMsisdnDetailsRepository.findById(id);
        return crMsisdnDetails.orElse(null);
    }

    @Override
    public CRMsisdnDetailsEntity update(CRMsisdnDetailsEntity crMsisdnDetailsEntity) {
        return crMsisdnDetailsRepository.save(crMsisdnDetailsEntity);
    }

    @Override
    public void updateMsisdnDetailsRemarksAndFailedStatus(CRMsisdnDetailsEntity crMsisdnDetailsEntity, String remarks) {
        CRMsisdnDetailsEntity existingCRMsisdnDetailsEntity = findById(crMsisdnDetailsEntity.getId());

        if (!ObjectUtils.isEmpty(existingCRMsisdnDetailsEntity)) {
            existingCRMsisdnDetailsEntity.setFinalStatus(CommonStatusEnum.Failed.name());
            existingCRMsisdnDetailsEntity.setRemarks(remarks);
            crMsisdnDetailsRepository.save(crMsisdnDetailsEntity);
        } else {
            log.debug("CRMsisdnDetails Not Found By Id: {}", crMsisdnDetailsEntity.getId());
            throw new NotFoundException("CRMsisdnDetails Not Found By Id: " + crMsisdnDetailsEntity.getId());
        }
    }
}
