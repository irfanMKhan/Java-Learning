package com.reddot.ecrm_bulk.repository.approval;

import com.reddot.ecrm_bulk.entity.approval.ApprovalFlowStepsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ApprovalFlowStepsRepo extends JpaRepository<ApprovalFlowStepsEntity, Long> {
    List<ApprovalFlowStepsEntity> findAllByApprovalFlowIdAndTenantId(Long flowId, Long tenantId);

    List<ApprovalFlowStepsEntity> findAllByApprovalFlowIdAndUnitValueAndTenantId(Long flowId, String unitValue, Long tenantId);

    List<ApprovalFlowStepsEntity>
    findAllByMinValueLessThanEqualAndMaxValueGreaterThanEqualAndApprovalFlowIdEqualsAndTenantIdEquals(
            Double amount1, Double amount2, Long approvalFLowID, Long tenantId);

    void deleteAllByApprovalFlowId(Long approvalId);

    void deleteAllByFlowRulesId(Long flowRulesId);

}
