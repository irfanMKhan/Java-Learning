package com.reddot.ecrm_bulk.scheduler;

import com.reddot.ecrm_bulk.service.report.ReportService;
import com.reddot.ecrm_bulk.service.report.StatementReportService;
import freemarker.template.TemplateException;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.mail.MessagingException;
import java.io.IOException;

@Component
@RequiredArgsConstructor
public class ReportScheduler {
    private final Logger logger = LoggerFactory.getLogger(getClass().getName());

    private final ReportService reportService;
    private final StatementReportService statementReportService;


    // @Scheduled(cron = "0 0 1 */15 * ?")
    // @Scheduled(fixedRate = 180000)
    @Scheduled(fixedDelay = 3 * 60 * 1000)
    public void ReportServiceScheduler() throws TemplateException, IOException {
        logger.info("Inside SmartNotificationScheduler");
        reportService.pendingLeadReportProcess();
    }

    @Scheduled(fixedRate = 180000)

    public void bulkStatementSyncScheduler() throws MessagingException {
        logger.info("Inside Statement");
        statementReportService.processStatementReportData();
    }

}
