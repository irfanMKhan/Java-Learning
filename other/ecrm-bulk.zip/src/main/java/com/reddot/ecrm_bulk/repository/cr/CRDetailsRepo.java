package com.reddot.ecrm_bulk.repository.cr;

import com.reddot.ecrm_bulk.entity.cr.CRMasterEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface CRDetailsRepo extends JpaRepository<CRMasterEntity, Long>, JpaSpecificationExecutor<CRMasterEntity> {
    //  List<ChangeRequestDetailsEntity> findAllByRequestType(String reqType,Pageable pageable);

    Page<CRMasterEntity> findAllByRequestType(String reqType, Pageable pageable);

    CRMasterEntity findAllByRequestTypeId(Integer typeId);

    List<CRMasterEntity> findAllByRequestType(String requestType);

    CRMasterEntity findAllByTransactionID(String transactionID);


    @Query(value = "SELECT * FROM cr_master WHERE\n" +
            "             (lower(request_type) = lower(:crRequestType))\n" +
            " AND  (:transitionIdQ IS NULL OR lower(transactionid) LIKE lower(concat('%', :transitionIdQ, '%')))\n" +
            "            AND (:companyNameQ IS NULL OR lower(company_name) LIKE lower(concat('%', :companyNameQ, '%')))\n" +
            "            AND (:finalStatusQ IS NULL OR lower(final_status) LIKE lower(concat('%', :finalStatusQ, '%')))\n" +
            "            AND (:paymentTypeStatusQ IS NULL OR lower(payment_type) LIKE lower(concat('%', :paymentTypeStatusQ, '%')))\n" +
            "            AND (:requestedDateQ IS NULL OR cast(requested_date as TEXT) = cast(:requestedDateQ as TEXT))\n" +
            "            AND (:effectiveDateQ IS NULL OR cast(effective_date as TEXT) = cast(:effectiveDateQ as TEXT))\n" +
            "            AND (:numberOfLinesQ IS NULL OR cast(number_of_lines as TEXT) = cast(:numberOfLinesQ as TEXT) )\n" +
            "            AND (((:startDateQ IS NULL AND :endDateQ IS NULL) OR (cast(requested_date as TEXT)  BETWEEN cast(:startDateQ as TEXT) AND cast(:endDateQ as TEXT)))\n" +
            "            OR ((:startDateQ IS NULL AND :endDateQ IS NULL) OR (cast(effective_date as TEXT)  BETWEEN cast(:startDateQ as TEXT) AND cast(:endDateQ as TEXT))))",

            nativeQuery = true)
    Page<CRMasterEntity> searchCRDetailsSummaryQuery(Pageable pageable, String transitionIdQ, String companyNameQ,
                                                     String finalStatusQ, String paymentTypeStatusQ,
                                                     String requestedDateQ, String effectiveDateQ,
                                                     String numberOfLinesQ, String startDateQ,
                                                     String endDateQ, String crRequestType

    );


    @Query(value = "SELECT * FROM cr_master WHERE\n" +
            "    ( ?1 IS NULL OR lower(transactionid) LIKE lower(concat('%', ?1, '%')))\n" +
            "            AND ( ?2 IS NULL OR lower(company_name) LIKE lower(concat('%', ?2, '%')))\n" +
            "            AND ( ?3 IS NULL OR lower(final_status) LIKE lower(concat('%', ?3, '%')))\n" +
            "            AND ( ?4 IS NULL OR lower(payment_type_status) LIKE lower(concat('%', ?4, '%')))\n" +
            "            AND ( ?5 IS NULL OR cast(requested_date as TEXT) = cast(?5 as TEXT))\n" +
            "            AND ( ?6 IS NULL OR cast(effective_date as TEXT) = cast(?6 as TEXT))\n" +
            "            AND ( ?7 IS NULL OR cast(number_of_lines as TEXT) = cast(?7 as TEXT) )\n" +
            "            AND ( (?8 IS NULL AND ?9 IS NULL) OR (cast(requested_date as TEXT)  BETWEEN cast(?8 as TEXT) AND cast(?9 as TEXT)))\n" +
            "            AND ( (?8 IS NULL AND ?9 IS NULL) OR (cast(effective_date as TEXT)  BETWEEN cast(?8 as TEXT) AND cast(?9 as TEXT)))", nativeQuery = true)
    Page<CRMasterEntity> searchCRDetailsSummaryQuery2(Pageable pageable, String transitionIdQ, String companyNameQ,
                                                      String finalStatusQ, String paymentTypeStatusQ,
                                                      String requestedDateQ, String effectiveDateQ,
                                                      String numberOfLinesQ, String startDateQ,
                                                      String endDateQ
    );

    @Query(value = "SELECT cr FROM CRMasterEntity cr WHERE" +
            "(:transitionIdQ IS NULL OR lower(cr.transactionID) LIKE lower(concat('%', :transitionIdQ, '%')))" +
            "AND (:companyNameQ IS NULL OR lower(cr.companyName) LIKE lower(concat('%', :companyNameQ, '%')))" +
            "AND (:finalStatusQ IS NULL OR lower(cr.finalStatus) LIKE lower(concat('%', :finalStatusQ, '%')))" +
            "AND (:paymentTypeStatusQ IS NULL OR lower(cr.paymentType) LIKE lower(concat('%', :paymentTypeStatusQ, '%')))" +
            "AND (:requestedDateQ IS NULL OR cr.requestedDate = :requestedDateQ)" +
            "AND (:effectiveDateQ IS NULL OR cr.effectiveDate = :effectiveDateQ)" +
            "AND (:numberOfLinesQ IS NULL OR cr.numberOfLines= :numberOfLinesQ )" +
            "AND ((:startDateQ IS NULL AND :endDateQ IS NULL) OR (cr.effectiveDate BETWEEN :startDateQ AND :endDateQ))" +
            "AND ((:startDateQ IS NULL AND :endDateQ IS NULL) OR (cr.requestedDate BETWEEN :startDateQ AND :endDateQ))"
    )
    Page<CRMasterEntity> searchCRDetailsSummaryQuery1(Pageable pageable,
                                                      String transitionIdQ,
                                                      String companyNameQ,
                                                      String finalStatusQ,
                                                      String paymentTypeStatusQ,
                                                      LocalDate requestedDateQ,
                                                      LocalDate effectiveDateQ,
                                                      Integer numberOfLinesQ,
                                                      LocalDate startDateQ,
                                                      LocalDate endDateQ);

    @Query(value = "SELECT cr FROM CRMasterEntity cr WHERE cr.requestType in ('Change Sim','Phone Stolen/ Reactive','Reset Network')")
    List<CRMasterEntity> findAllForRequestType_ChangeSim_ResetNetwork_Reactive();

    @Query(value = "SELECT cr FROM CRMasterEntity cr WHERE cr.requestType in ('Change Sim','Phone Stolen/ Reactive','Reset Network') order by cr.id desc")
    List<CRMasterEntity> findAllForRequestType_ChangeSim_ResetNetwork_ReactiveOrderById();

    @Query(value = "SELECT cr FROM CRMasterEntity cr WHERE cr.requestType in ('Join CUG','Join Master/Branch')")
    List<CRMasterEntity> findAllRequestTypeForCUG_Master();

    @Query(value = "SELECT cr FROM CRMasterEntity cr WHERE cr.requestType in ('Change Sim','Phone Stolen/ Reactive','Reset Network')" +
            " AND ((:transactionId IS NULL OR lower(cr.transactionID) LIKE lower(concat('%', :transactionId, '%')))" +
            " AND (:companyName = '-99' OR lower(cr.companyName) LIKE lower(concat('%', :companyName, '%')))" +
            " AND (:requestType = '-- Select --' OR lower(cr.requestType) LIKE lower(concat('%', :requestType, '%'))))")
    List<CRMasterEntity> findAllByTransactionIDOrCompanyNameLikeIgnoreCaseOrRequestType_ForRequestType_ChangeSim_ResetNetwork_Reactive(
            String transactionId,
            String companyName,
            String requestType
    );

    void deleteByTransactionID(String transactionID);
}


