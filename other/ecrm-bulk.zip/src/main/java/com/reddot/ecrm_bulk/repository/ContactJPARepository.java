package com.reddot.ecrm_bulk.repository;

import com.reddot.ecrm_bulk.entity.contract.ContactEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ContactJPARepository extends JpaRepository<ContactEntity, Long> {
    @Query(value = "select * from tbl_ecrm_contact tec  \n"
            + "where tec.company_id =:companyId \n"
            + "and tec.person_type_text =:personTypeText", nativeQuery = true)
    List<String> findAllByCompanyIdAndPersonTypeText(Long companyId, String personTypeText);

    @Query(value = "select tec from ContactEntity tec  where tec.companyId =:companyId and tec.personTypeText =:personTypeText")
    List<ContactEntity> findAllEntityByCompanyIdAndPersonTypeText(Long companyId, String personTypeText);
}
