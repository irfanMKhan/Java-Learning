package com.reddot.ecrm_bulk.entity.contract;

import com.reddot.ecrm_bulk.entity.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;
@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "TBL_ECRM_CONTACT")
public class ContactEntity extends AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "id_generator_contact")
    @SequenceGenerator(name = "id_generator_contact", initialValue = 1, allocationSize = 1)
    private Long id;

    @Column(name = "NAME")
    private String name;

    private String lastName;

    @Column(name = "SALUTATION")
    private String salutation;

    @Column(name = "SALUTATION_TEXT")
    private String salutationText;

    private String salutationApiValue;
    @Column(name = "POSITION")
    private String position;

    @Column(name = "MOBILE")
    private String mobile;

    @Column(name = "EMAIL")
    private String email;

    private String dateOfBirth;

    private Boolean webPortal;

    private Boolean notification;

    @Column(name = "PERSON_TYPE")
    private String personType;

    @Column(name = "PERSON_TYPE_TEXT")
    private String personTypeText;

    private String products;

    private String productsText;

    @Column(name = "CONTRACT_NUMBER")
    private String contractNumber;

    private Long contractId;

    private Long opportunityId;

    @Column(name = "OPPORTUNITY_NUMBER")
    private String opportunityNumber;

    private Boolean isCRContract;

    private Long companyId;

    private String companyName;

    private Long userId;

    private String userName;
}

