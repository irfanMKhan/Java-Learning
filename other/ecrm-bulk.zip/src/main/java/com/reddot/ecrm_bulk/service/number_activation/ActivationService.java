package com.reddot.ecrm_bulk.service.number_activation;

import com.reddot.ecrm_bulk.api.exception.AlreadyExistsException;
import com.reddot.ecrm_bulk.api.exception.ApiRequestException;
import com.reddot.ecrm_bulk.api.exception.IncorrectSubscriberPaymentTypeException;
import com.reddot.ecrm_bulk.api.exception.SIMCardNotExistsException;
import com.reddot.ecrm_bulk.api.payload.customer.CBSBCCustomerResponse;
import com.reddot.ecrm_bulk.dto.contract.ContractInfo;
import com.reddot.ecrm_bulk.entity.account_details.Address;
import com.reddot.ecrm_bulk.entity.annex.Annex;
import com.reddot.ecrm_bulk.entity.company.Company;
import com.reddot.ecrm_bulk.entity.company.CompanyAccount;
import com.reddot.ecrm_bulk.entity.contract.Contact;
import com.reddot.ecrm_bulk.entity.contract.Contract;
import com.reddot.ecrm_bulk.entity.msisdn.MSISDN;
import com.reddot.ecrm_bulk.entity.primary_offering.PrimaryOffering;
import com.reddot.ecrm_bulk.enums.status.ActivationStatus;
import com.reddot.ecrm_bulk.enums.status.Status;
import com.reddot.ecrm_bulk.service.account.AddressService;
import com.reddot.ecrm_bulk.service.company.CompanyAccountService;
import com.reddot.ecrm_bulk.service.company.CompanyService;
import com.reddot.ecrm_bulk.service.company.MSISDNService;
import com.reddot.ecrm_bulk.service.contact.ContactService;
import com.reddot.ecrm_bulk.service.contract.AnnexService;
import com.reddot.ecrm_bulk.service.contract.ContractService;
import com.reddot.ecrm_bulk.service.offering.MandatoryOfferingService;
import com.reddot.ecrm_bulk.service.offering.PrimaryOfferingService;
import com.reddot.ecrm_bulk.util.Utility;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ActivationService {
    private final AnnexService annexService;
    private final ContractService contractService;
    private final PrimaryOfferingService primaryOfferingService;
    private final ContactService contactService;
    private final AddressService addressService;
    private final CompanyAccountService companyAccountService;
    private final MSISDNService msisdnService;
    private final CompanyService companyService;
    private final MandatoryOfferingService mandatoryOfferingService;
    @Value("${max-outstanding-check-month}")
    private int maxOutstandingCheckMonth;
    private boolean isActivationCompleted = false;

    public Boolean hasNoOutstanding(Annex annex) {
        return contractService.isDebitNoteClosed(annex.getAdjustmentSerialNo());
    }

    public void executeActivation(Contract contract, Annex annex) {
        annexService.updateAnnexStatus(annex, Status.InProgress);

        if (isPrePaidToPostPaid(annex)) {

            // Delete Supplementary Offering
            Boolean deletedSupplementaryOffering = deleteSupplementaryOffering(annex);
            if (deletedSupplementaryOffering) {
                updateAnnexActivationStatus(annex, ActivationStatus.DeleteSupplementaryOffering_Success);

                CBSBCCustomerResponse customer = contractService.cbsbcCustomer(annex.getMsisdn());

                log.debug("Before Pre2Post API Call CBSBCCustomer CBSBCCustomerResponse={} for MSISDN: {}", Utility.EntityObjectToJsonConvertGson(customer), annex.getMsisdn());
                String accountIdBeforePre2Post = customer.getQueryCustomerInfoResult().getAccount().getAcctKey();
                // Prepaid to Postpaid
                Boolean prePaidToPostPaidConverted = prePaidToPostpaidConvert(contract, annex);
                if (prePaidToPostPaidConverted) {
                    updateAnnexActivationStatus(annex, ActivationStatus.Pre2Post_Success);

                    // Change Account Information
                    Boolean accountInformationChanged = changeAccountInformation(contract, annex, accountIdBeforePre2Post);
                    if (accountInformationChanged) {
                        updateAnnexActivationStatus(annex, ActivationStatus.ChangeAccountInformation_Success);

                        // Change Credit Limit
                        Boolean creditLimitChanged = changeAccountCreditLimit(annex);
                        if (creditLimitChanged) {
                            updateAnnexActivationStatus(annex, ActivationStatus.ChangeCreditLimit_Success);

                            // Add Supplementary Offering
                            Boolean addSupplementaryOffering = addSupplementaryOffering(annex);
                            if (addSupplementaryOffering) {
                                updateAnnexActivationStatus(annex, ActivationStatus.AddSupplementaryOffering_Success);

                                makeCorporateCustomer(contract, annex);
                            } else {
                                annexService.updateAnnexStatus(annex, Status.Failed);
                                log.debug("AddSupplementary Offering failed. For contractId: {}, company: {} and MSISDN: {}", contract.getId(), contract.getCustomerName(), annex.getMsisdn());
                            }
                        } else {
                            annexService.updateAnnexStatus(annex, Status.Failed);
                            log.debug("Change Credit limit failed. For contractId: {}, company: {} and MSISDN: {}", contract.getId(), contract.getCustomerName(), annex.getMsisdn());
                        }
                    } else {
                        annexService.updateAnnexStatus(annex, Status.Failed);
                        log.debug("Change Account Information failed. For contractId: {}, company: {} and MSISDN: {}", contract.getId(), contract.getCustomerName(), annex.getMsisdn());
                    }
                } else {
                    annexService.updateAnnexStatus(annex, Status.Failed);
                    log.debug("Pre2Post Conversion failed. For contractId: {}, company: {} and MSISDN: {}", contract.getId(), contract.getCustomerName(), annex.getMsisdn());
                }
            } else {
                annexService.updateAnnexStatus(annex, Status.Failed);
                log.debug("Delete Supplementary Offering failed. For contractId: {}, company: {} and MSISDN: {}", contract.getId(), contract.getCustomerName(), annex.getMsisdn());
            }
        } else if (!isPrePaidToPostPaid(annex)) {
            // Create Order
            Boolean orderCreated = createOrder(contract, annex);
            if (orderCreated) {
                updateAnnexActivationStatus(annex, ActivationStatus.Create_Order_Success);

                makeCorporateCustomer(contract, annex);
            } else {
                annexService.updateAnnexStatus(annex, Status.Failed);
                log.debug("Create Order failed. For contractId: {}, company: {} and MSISDN: {}", contract.getId(), contract.getCustomerName(), annex.getMsisdn());
            }
        }
    }

    public void updateAnnexActivationStatus(Annex annex, ActivationStatus activationStatus) {
        annex.setApiStatus(activationStatus.name());
        annexService.update(annex);
        log.debug("Annex: {} API Calling Status: {}", annex.getMsisdn(), activationStatus.name());
    }


    public void makeCorporateCustomer(Contract contract, Annex annex) {
        //Add to a Corporate Group
        Boolean corporateGroupAdded = addCorporateGroup(contract, annex);
        if (corporateGroupAdded) {
            updateAnnexActivationStatus(annex, ActivationStatus.CorporateGroup_Success);

            // Add Group CUG
            Boolean cugGroupAdded = addGroupCUG(contract, annex);
            if (cugGroupAdded) {
                updateAnnexActivationStatus(annex, ActivationStatus.CUGGroup_Success);
                try {
                    // Insert into msisdn table
                    insertMSISDN(contract, annex);
                    // Company table total credit, credit ceiling
                    updateCompany(contract, annex);
                    // Update Annex Status
                    annexService.updateAnnexStatus(annex, Status.Activate);

                    isActivationCompleted = true;
                } catch (Exception e) {
                    log.debug("Annex Activation Failed. For company: {} and MSISDN: {} | Error: {}", contract.getCustomerName(), annex.getMsisdn(), e.getMessage());
                } finally {
                    if (isActivationCompleted) {
                        updateAnnexActivationStatus(annex, ActivationStatus.Activate);
                        log.debug("Annex Activated Successfully. For company: {} and MSISDN: {}", contract.getCustomerName(), annex.getMsisdn());
                    } else {
                        annexService.updateAnnexStatus(annex, Status.Failed);
                        log.debug("Annex Activation Not Completed. For company: {} and MSISDN: {}", contract.getCustomerName(), annex.getMsisdn());
                    }
                }
            } else {
                annexService.updateAnnexStatus(annex, Status.Failed);
                log.debug("Add CUG Group failed. For company: {} and MSISDN: {}", contract.getCustomerName(), annex.getMsisdn());
            }
        } else {
            annexService.updateAnnexStatus(annex, Status.Failed);
            log.debug("Add Corporate Group failed. For company: {} and MSISDN: {}", contract.getCustomerName(), annex.getMsisdn());
        }
    }

    public Boolean changeAccountInformation(Contract contract, Annex annex, String accountIdBeforePre2Post) {
        try {
            updateAnnexActivationStatus(annex, ActivationStatus.ChangeAccountInformation_Invoked);

            CBSBCCustomerResponse customer = contractService.cbsbcCustomer(annex.getMsisdn());

            log.debug("changeAccountInformation() After Pre2Post CBSBCCustomer CBSBCCustomerResponse={} for MSISDN: {}", Utility.EntityObjectToJsonConvertGson(customer), annex.getMsisdn());

            String accountId = customer.getQueryCustomerInfoResult().getAccount().getAcctKey();

            log.debug("After Pre2Post CBSBCCustomer AccountId={} for MSISDN: {}", accountId, annex.getMsisdn());

            if (!ObjectUtils.isEmpty(accountId) && !ObjectUtils.isEmpty(accountIdBeforePre2Post) &&
                    accountId.equals(accountIdBeforePre2Post)) {

                int i = 0;

                while (i < 5) {
                    customer = contractService.cbsbcCustomer(annex.getMsisdn());
                    String newAccountIdInRepetativeCall = customer.getQueryCustomerInfoResult().getAccount().getAcctKey();
                    log.debug("Repetative Call After Pre2Post CBSBCCustomer AccountId={} for MSISDN: {} and Loop Num={}", newAccountIdInRepetativeCall, annex.getMsisdn(), i);
                    if (!ObjectUtils.isEmpty(accountId) && !ObjectUtils.isEmpty(accountIdBeforePre2Post) &&
                            !accountId.equals(newAccountIdInRepetativeCall)) {
                        accountId = customer.getQueryCustomerInfoResult().getAccount().getAcctKey();
                        break;
                    }
                    Thread.sleep(30000);
                    i++;
                }

            }


            if (ObjectUtils.isEmpty(accountId)) {
                log.debug("CBSBCCustomer Acct Key is Not Found for MSISDN: {}", annex.getMsisdn());
                return false;
            }

            Address address = addressService.findById(contract.getAccountDetailsId());

            if (!ObjectUtils.isEmpty(address)) {
                return contractService.changeAccountInformation(accountId, contract, annex, address);
            } else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.debug("ChangeAccountInformation Error : {} for MSISDN: {}", e.getMessage(), annex.getMsisdn());
            annexService.updateAnnexAPIMessage(annex, e.getMessage());
            return false;
        }
    }

    public Boolean prePaidToPostpaidConvert(Contract contract, Annex annex) {
        try {
            String custId;
            String birthDayFormatted;

            updateAnnexActivationStatus(annex, ActivationStatus.Pre2Post_Invoked);

            CBSBCCustomerResponse customer = contractService.cbsbcCustomer(annex.getMsisdn());

            if (!ObjectUtils.isEmpty(customer.getQueryCustomerInfoResult().getCustomer().getIndividualInfo().getBirthday())) {
                String birthDay = customer.getQueryCustomerInfoResult().getCustomer().getIndividualInfo().getBirthday();
                birthDayFormatted = birthDay.substring(0, 8);
            } else {
                log.debug("Birthday not found for msisdn: {} in CBS-BC-Customer", annex.getMsisdn());
                return false;
            }

            if (!ObjectUtils.isEmpty(customer.getQueryCustomerInfoResult().getCustomer().getCustKey())) {
                custId = customer.getQueryCustomerInfoResult().getCustomer().getCustKey();
            } else {
                log.debug("CustKey not found for msisdn: {} in CBS-BC-Customer", annex.getMsisdn());
                return false;
            }

            List<Contact> contactList = contactService.findByContractId(contract.getId());
            Address address = addressService.findById(contract.getAccountDetailsId());

            if (!CollectionUtils.isEmpty(contactList) &&
                    !ObjectUtils.isEmpty(address)) {
                return contractService.prepaidToPostpaid(custId, birthDayFormatted, contract, annex, contactList, address);
            } else {
                log.debug("PrePaidToPostpaidConvert Contact: {} Address: {}", contactList, address);
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.debug("PrePaidToPostpaidConvert error: {}", e.getMessage(), e.getCause());
            annexService.updateAnnexAPIMessage(annex, e.getMessage());
            return e instanceof IncorrectSubscriberPaymentTypeException;
        }
    }

    public Boolean createOrder(Contract contract, Annex annex) {
        try {
            updateAnnexActivationStatus(annex, ActivationStatus.Create_Order_Invoked);

            if (ObjectUtils.isEmpty(annex.getNgbssPlanOfferingId())) {
                log.debug("NGBSS Offering Id is not found for msisdn: {}", annex.getMsisdn());
                return false;
            }

            PrimaryOffering primaryOffering = primaryOfferingService.findByOfferingId(Long.valueOf(annex.getNgbssPlanOfferingId()));
            List<Contact> contactList = contactService.findByContractId(contract.getId());
            Address address = addressService.findById(contract.getAccountDetailsId());

            if (!ObjectUtils.isEmpty(primaryOffering) &&
                    !CollectionUtils.isEmpty(contactList) &&
                    !ObjectUtils.isEmpty(address)) {
                return contractService.createOrder(contract, annex, primaryOffering, contactList, address);
            } else {
                return false;
            }
        } catch (Exception e) {
            if (e instanceof SIMCardNotExistsException) {
                log.debug("The SIM Card: {} does not exist for MSISDN: {}", annex.getIccid(), annex.getMsisdn());
                annexService.updateAnnexRemarksAndSetStatusFailed(annex, e.getMessage());
            }
            e.printStackTrace();
            annexService.updateAnnexAPIMessage(annex, e.getMessage());
            return false;
        }
    }

    public Boolean addCorporateGroup(Contract contract, Annex annex) {
        try {
            updateAnnexActivationStatus(annex, ActivationStatus.CorporateGroup_Invoked);

            Map<String, String> corporateGroup = companyAccountService.findBranchSubscriberByCustomerNameAndServiceTypeBranch(contract.getCustomerName(), annex.getServiceTypeName(), annex.getBranch());
            CompanyAccount parentCustomer = companyAccountService.findParentCustomerByAccountName(contract.getCustomerName());
            String groupId = companyAccountService.findParentCorporateGroupIdByCorporateGroupCode(corporateGroup.get("groupCode"));

            if (!corporateGroup.isEmpty() &&
                    !ObjectUtils.isEmpty(contract) &&
                    !ObjectUtils.isEmpty(groupId)) {
                return contractService.addCorporateGroup(parentCustomer.getAccountId(), groupId, annex.getMsisdn(), corporateGroup.get("groupCode"), corporateGroup.get("groupName"));
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            annexService.updateAnnexAPIMessage(annex, e.getMessage());
            return e instanceof AlreadyExistsException;
        }
    }

    public Boolean addGroupCUG(Contract contract, Annex annex) {
        try {
            updateAnnexActivationStatus(annex, ActivationStatus.CUGGroup_Invoked);

            String groupCode = companyAccountService.findCUGGroupByCustomerName(contract.getCustomerName());
            if (!ObjectUtils.isEmpty(groupCode)) {
                return contractService.addGroupCUG(contract, annex, groupCode);
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            annexService.updateAnnexAPIMessage(annex, e.getMessage());
            return e instanceof AlreadyExistsException;
        }
    }

    public List<String> queryPurchasedSupplementaryOffering(String msisdn) {
        try {
            List<String> offerings = contractService.queryPurchasedSupplementaryOffering(msisdn);

            if (ObjectUtils.isEmpty(offerings)) {
                return new ArrayList<>();
            }

            List<String> excludeMandatoryOfferings = new ArrayList<>();

            for (String item : offerings) {
                if (mandatoryOfferingService.IsMandatoryOffering(item)) {
                    continue;
                }
                excludeMandatoryOfferings.add(item);
            }

            log.debug("Exclude MandatoryOffering List: {}", excludeMandatoryOfferings);
            return excludeMandatoryOfferings;
        } catch (Exception e) {
            log.debug("QueryPurchasedSupplementaryOffering Error: {} for MSISDN: {}", e.getMessage(), msisdn);
            throw new ApiRequestException(e.getMessage());
        }
    }


    public Boolean deleteSupplementaryOffering(Annex annex) {
        try {
            updateAnnexActivationStatus(annex, ActivationStatus.DeleteSupplementaryOffering_Invoked);
            List<String> existingOffering = queryPurchasedSupplementaryOffering(annex.getMsisdn());
            if (!ObjectUtils.isEmpty(existingOffering)) {
                return contractService.changeSupplementaryOffering(annex, existingOffering);
            } else {
                log.debug("DeleteSupplementaryOffering existing offering is empty for MSISDN: {}", annex.getMsisdn());
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.debug("DeleteSupplementaryOffering Error: {} for MSISDN: {}", e.getMessage(), annex.getMsisdn());
            annexService.updateAnnexAPIMessage(annex, e.getMessage());
            return false;
        }
    }

    public Boolean addSupplementaryOffering(Annex annex) {
        try {
            updateAnnexActivationStatus(annex, ActivationStatus.AddSupplementaryOffering_Invoked);
            return contractService.addSupplementaryOffering(annex);
        } catch (Exception e) {
            e.printStackTrace();
            log.debug("AddSupplementaryOffering Error: {} for MSISDN: {}", e.getMessage(), annex.getMsisdn());
            annexService.updateAnnexAPIMessage(annex, e.getMessage());
            return false;
        }
    }

    public Boolean changeAccountCreditLimit(Annex annex) {
        try {
            updateAnnexActivationStatus(annex, ActivationStatus.ChangeCreditLimit_Invoked);

            CBSBCCustomerResponse customer = contractService.cbsbcCustomer(annex.getMsisdn());
            String acctId = customer.getQueryCustomerInfoResult().getAccount().getAcctKey();

            if (!ObjectUtils.isEmpty(acctId)) {
                return contractService.changeAccountCreditLimit(acctId, annex);
            } else {
                log.debug("CBSBCCustomer Acct Id not found for MSISDN: {}", annex.getMsisdn());
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.debug("ChangeAccountCreditLimit Error: {} for MSISDN: {}", e.getMessage(), annex.getMsisdn());
            annexService.updateAnnexAPIMessage(annex, e.getMessage());
            return false;
        }
    }

    public void insertMSISDN(Contract contract, Annex annex) {
        ContractInfo contractInfo = companyAccountService.findContractInfoByCompanyName(contract.getCustomerName(), annex);
        if (!ObjectUtils.isEmpty(contractInfo)) {

            List<MSISDN> msisdnList = msisdnService.findAllByMSISDN(annex.getMsisdn());

            // Check whether msisdn is exists.
            if (!msisdnList.isEmpty()) {

                List<MSISDN> activeMSISDNList = msisdnList.stream().filter(MSISDN::getActive).collect(Collectors.toList());
                // Store msisdn if msisdn exits and status is inactive
                if (activeMSISDNList.isEmpty()) {
                    msisdnService.insertMSISDN(contract, annex, contractInfo);
                } else {
                    // Update remarks of Annex if msisdn exists and status is active
                    log.debug("MSISDN: {} already exists.", annex.getMsisdn());
                    annexService.updateAnnexRemarksAndSetStatusFailed(annex, "MSISDN " + annex.getMsisdn() + " already used.");
                }
            } else {
                // Store msisdn if msisdn does not exist.
                msisdnService.insertMSISDN(contract, annex, contractInfo);
            }

        } else {
            log.debug("Contract Info is empty for MSISDN: {}", annex.getMsisdn());
        }
    }

    public synchronized void updateCompany(Contract contract, Annex annex) {
        Company company = companyService.findCompanyByName(contract.getCustomerName());
        if (!ObjectUtils.isEmpty(company)) {
            companyService.updateCompany(company, annex);
        }
    }

    public Boolean isPrePaidToPostPaid(Annex annex) {
        return !ObjectUtils.isEmpty(annex.getPreToPost()) ? annex.getPreToPost() : false;
    }

    public Boolean hasDevice(Annex annex) {
        if (!ObjectUtils.isEmpty(annex.getDevice())) {
            return Integer.parseInt(annex.getDevice()) > 0;
        } else {
            return false;
        }
    }

    public Boolean todayIsEffectiveDate(Annex annex) {
        if (!ObjectUtils.isEmpty(annex.getEffectiveDate())) {
            LocalDate parsedStringDate = LocalDate.parse(annex.getEffectiveDate());
            LocalDate currentDate = LocalDate.now();

            return parsedStringDate.compareTo(currentDate) == 0;
        } else {
            return false;
        }
    }

    public Boolean isEligibleToRecheckOutstanding(Annex annex) {
        if (!ObjectUtils.isEmpty(annex.getEffectiveDate())) {
            LocalDate effectiveDate = LocalDate.parse(annex.getEffectiveDate());
            LocalDate maxOutstandingCheckingDate = effectiveDate.plusMonths(maxOutstandingCheckMonth);
            LocalDate currentDate = LocalDate.now();

            return currentDate.compareTo(effectiveDate) > 0 &&
                    maxOutstandingCheckingDate.compareTo(currentDate) >= 0;
        } else {
            return false;
        }
    }

    public Boolean todayIsPromiseToPayDate(Annex annex) {
        if (!ObjectUtils.isEmpty(annex.getPtpPaymentProcessDate())) {
            LocalDate parsedStringDate = annex.getPtpPaymentProcessDate();
            LocalDate currentDate = LocalDate.now();

            return parsedStringDate.compareTo(currentDate) == 0;
        } else {
            return false;
        }
    }

    public void notify(Contract contract, Annex annex) {
        log.debug("PromiseToPay unpaid for the company : {} and msisdn: {}", contract.getCustomerName(), annex.getMsisdn());
    }
}
