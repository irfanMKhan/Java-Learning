package com.reddot.ecrm_bulk.service.logger;

import com.reddot.ecrm_bulk.api.payload.ErrorResponse;
import com.reddot.ecrm_bulk.api.payload.order.CreateOrderRequest;
import com.reddot.ecrm_bulk.api.payload.order.CreateOrderResponse;
import com.reddot.ecrm_bulk.enums.requestType.CommonStatusEnum;
import com.reddot.ecrm_bulk.enums.requestType.RequestTypeEnum;

import java.sql.Timestamp;

public interface APILoggerService {
    void log(String featureName, Integer featureId, String uniqueTransaction,
                           Integer stepNumber, String stepDescription, String request,
                           String response, String requestParameter,
                           Timestamp requestTime, Timestamp responseTime, Long elapsedTime,
                           Long primaryId, String tableName, String remoteAddress,
                           Integer responseStatus, String status);
    void store(RequestTypeEnum requestTypeEnum, String txnId, Integer stepNum, String stepDec, String request, String response, String errorResponse, long startTime, long elapsed, CommonStatusEnum status);
}
