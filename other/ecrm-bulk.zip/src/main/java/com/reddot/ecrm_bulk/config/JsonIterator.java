package com.reddot.ecrm_bulk.config;

import org.json.JSONArray;
import org.json.JSONObject;

public class JsonIterator {

    private JSONArray resultArray;
    private Object resultantOccurrence = null;
    private boolean firstOccurrenceDone = false;

    public JSONArray getExtractedArray(JSONObject rawData, String keyRequired) {
        resultArray = new JSONArray();
//        System.out.println("Have iterate raw data: " + rawData.toString());
        iterateJSONObject(rawData, keyRequired);
        return resultArray;
    }

    public Object getFirstOccurrence(JSONObject rawData, String keyRequired) {
        resultantOccurrence = null;
        firstOccurrenceDone = false;
//        System.out.println("Have iterate raw data: " + rawData.toString());
        iterateJSONObjectForFirstOccur(rawData, keyRequired);
        return resultantOccurrence;
    }

    private void iterateJSONObject(JSONObject rawData, String keyRequired) {
        try {
            for (String key : rawData.keySet()) {
                Object keyValue = rawData.get(key);
                String keyValueString = keyValue.toString();
                if (keyValue instanceof JSONObject) {
                    JSONObject jsonObject = new JSONObject(keyValueString);
                    if (key.equals(keyRequired)) {
                        resultArray.put(jsonObject);
                    }
                    iterateJSONObject(jsonObject, keyRequired);
                } else if (keyValue instanceof JSONArray) {
                    JSONArray jsonArray = new JSONArray(keyValueString);
                    if (key.equals(keyRequired)) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            resultArray.put(jsonArray.getJSONObject(i));
                        }
                    }
                    iterateJSONArray(jsonArray, keyRequired);
                } else {
                    if (key.equals(keyRequired)) {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("key", keyValueString);
                        resultArray.put(jsonObject);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void iterateJSONArray(JSONArray rawData, String keyRequired) {
        try {
            for (int i = 0; i < rawData.length(); i++) {
                iterateJSONObject(rawData.getJSONObject(i), keyRequired);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void iterateJSONObjectForFirstOccur(JSONObject rawData, String keyRequired) {
        try {
            for (String key : rawData.keySet()) {
                Object keyValue = rawData.get(key);
                String keyValueString = keyValue.toString();
                if (key.equals(keyRequired) && !firstOccurrenceDone) {
                    resultantOccurrence = keyValue;
                    firstOccurrenceDone = true;
                }
                if (keyValue instanceof JSONObject) {
                    JSONObject jsonObject = new JSONObject(keyValueString);
                    iterateJSONObjectForFirstOccur(jsonObject, keyRequired);
                } else if (keyValue instanceof JSONArray) {
                    JSONArray jsonArray = new JSONArray(keyValueString);
                    iterateJSONArrayForFirstOccur(jsonArray, keyRequired);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void iterateJSONArrayForFirstOccur(JSONArray rawData, String keyRequired) {
        try {
            for (int i = 0; i < rawData.length(); i++) {
                iterateJSONObjectForFirstOccur(rawData.getJSONObject(i), keyRequired);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
