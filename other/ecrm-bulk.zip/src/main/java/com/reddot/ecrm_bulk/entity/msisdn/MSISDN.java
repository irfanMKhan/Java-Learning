package com.reddot.ecrm_bulk.entity.msisdn;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;
import java.time.LocalDate;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "msisdn")
public class MSISDN {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String msisdn;
    private String iccid;
    private Double creditLimit;
    private Double reserveCredit;
    private Double totalCredit;
    private Double monthlyFee;
    private Double maxMonthlyFee;
    private Long planId;
    private String planName;
    private String addOn;
    private Integer contractDuration;  //contact_duration(in front-end)
    private LocalDate effectiveDate;
    private LocalDate maturityDate;  //maturity_date(front-end)
    private Long companyId;
    private String companyName;
    private Long masterAccountId;
    private String msisdnAccountCode;
    private Boolean active;

    private Boolean isSuspended;
    private Long statusId;
    private String statusName;

    private String ngbssPlanOfferingId;
    private String ngbssAddOnsOfferingId;
    private Double remainingCredit;

    private Long branchAccountId;
    private Long cugAccountId;
    private Long cugId;

    @Column(name = "created_at")
    private Long createdAt;

    @Column(name = "created_at_dt")
    private Timestamp createdAtDt;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_by_username")
    private String createdUsername;

    @Column(name = "updated_at")
    private Long updatedAt;

    @Column(name = "updated_at_dt")
    private Timestamp updatedAtDt;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_by_username")
    private String updatedUsername;

}
