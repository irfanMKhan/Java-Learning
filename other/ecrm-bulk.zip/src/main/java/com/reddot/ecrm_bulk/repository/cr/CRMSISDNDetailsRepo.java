package com.reddot.ecrm_bulk.repository.cr;

import com.reddot.ecrm_bulk.entity.cr.CRMsisdnDetailsEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface CRMSISDNDetailsRepo extends JpaRepository<CRMsisdnDetailsEntity, Long> {
    List<CRMsisdnDetailsEntity> findAllByChangeRequestMasterId(Long crReqId);

    List<CRMsisdnDetailsEntity> findAllByChangeRequestMasterIdOrderByIdDesc(Long crReqId);

    List<CRMsisdnDetailsEntity> findAllByCompanyId(Long companyId);

    Page<CRMsisdnDetailsEntity> findAllByRequestTypeAndRequestTypeId(String reqType, Integer reqId, Pageable pageable);

    List<CRMsisdnDetailsEntity> findAllByCompanyIdAndRequestTypeId(Long companyId, Integer requestTypeId);


    CRMsisdnDetailsEntity findByMsisdnId(Long aLong);

    List<CRMsisdnDetailsEntity> findAllByTransactionID(String transactionId);


    Page<CRMsisdnDetailsEntity> findAllByTransactionID(String transactionID, Pageable pageable);

    List<CRMsisdnDetailsEntity> findAllByCompanyIdAndRequestType(Long companyId, String requestType);

    List<CRMsisdnDetailsEntity> findAllByMsisdnAndRequestType(String msisdn, String type);

    List<CRMsisdnDetailsEntity> findAllByRequestTypeAndStatus(String requestType, String status);

    List<CRMsisdnDetailsEntity> findAllByRequestTypeAndStatusAndEffectiveDateLessThanEqual(String requestType, String status,
                                                                                           LocalDate effectiveDate);

    List<CRMsisdnDetailsEntity> findAllByRequestTypeAndIsChangePermanentAndTemporaryEndDateToLessThanEqualAndStatusAndIsTemporaryToPreviousStateDone(
            String requestType, Boolean isChangePermanent, LocalDate temporaryTo, String status, Boolean isTemporaryToPreviousStateDone);


    @Query(value = "SELECT * FROM cr_msisdn_details WHERE\n" +
            "             (lower(request_type) = lower(:crRequestType))\n" +
            " AND  (:transactionIdQ IS NULL OR lower(transactionid) LIKE lower(concat('%', :transactionIdQ, '%')))\n" +
            "            AND (:companyNameQ IS NULL OR lower(company_name) LIKE lower(concat('%', :companyNameQ, '%')))\n" +
            "            AND (:finalStatusQ IS NULL OR lower(final_status) LIKE lower(concat('%', :finalStatusQ, '%')))\n" +
            "            AND (:paymentTypeStatusQ IS NULL OR lower(payment_type) LIKE lower(concat('%', :paymentTypeStatusQ, '%')))\n" +
            "            AND (:paymentStatusQ IS NULL OR lower(status_of_payment) LIKE lower(concat('%', :paymentStatusQ, '%')))\n" +
            "            AND (:requestedDateQ IS NULL OR cast(requested_date as TEXT) = cast(:requestedDateQ as TEXT))\n" +
            "            AND (:effectiveDateQ IS NULL OR cast(effective_date as TEXT) = cast(:effectiveDateQ as TEXT))\n" +
            "            AND (:msisdn IS NULL OR cast(msisdn as TEXT) = cast(:msisdn as TEXT))\n" +
            "            AND (((:startDateQ IS NULL AND :endDateQ IS NULL) OR (cast(requested_date as TEXT)  BETWEEN cast(:startDateQ as TEXT) AND cast(:endDateQ as TEXT)))\n" +
            "            OR ((:startDateQ IS NULL AND :endDateQ IS NULL) OR (cast(effective_date as TEXT)  BETWEEN cast(:startDateQ as TEXT) AND cast(:endDateQ as TEXT))))",

            nativeQuery = true)
    Page<CRMsisdnDetailsEntity> searchCRDetailsSummaryQuery(Pageable pageable, String transactionIdQ, String companyNameQ,
                                                            String finalStatusQ, String paymentTypeStatusQ, String paymentStatusQ,
                                                            String requestedDateQ, String effectiveDateQ,
                                                            String startDateQ, String endDateQ,
                                                            String crRequestType, String msisdn

    );


}
