package com.reddot.ecrm_bulk.service.contract;

import com.reddot.ecrm_bulk.entity.contract.BillMedium;
import com.reddot.ecrm_bulk.repository.contract.BillMediumRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import javax.persistence.NonUniqueResultException;

@Slf4j
@AllArgsConstructor
@Service
public class BillMediumServiceImpl implements BillMediumService {
    private final BillMediumRepository billMediumRepository;

    @Override
    public BillMedium findByContractIdAndServiceTypeName(Long contractId, String serviceTypeName) {
        try {
            return billMediumRepository.findByContractIdAndServiceTypeName(contractId, serviceTypeName);
        } catch (EmptyResultDataAccessException e) {
            log.debug("Bill Medium Not Found By Contract Id: {} and Service Type: {}", contractId, serviceTypeName);
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            if (e instanceof NonUniqueResultException) {
                log.debug("Bill Medium More Than One Found By Contract Id: {}, Service Type: {} and Error: {}", contractId, serviceTypeName, e.getMessage(), e.getCause());
            } else {
                log.error("Bill Medium Find Error. Contract Id: {}, Service Type: {} and Error: {}", contractId, serviceTypeName, e.getMessage(), e.getCause());
            }
            return null;
        }
    }
}
