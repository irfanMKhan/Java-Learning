package com.reddot.ecrm_bulk.request;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class SendSMSRequest implements Serializable {
    private OutboundSMSMessageRequest outboundSMSMessageRequest;

    @Data
    public static class OutboundSMSMessageRequest implements Serializable {
        private String senderAddress;

        private String senderName;

        private List<String> address;

        private ReceiptRequest receiptRequest;

        private OutboundSMSTextMessage outboundSMSTextMessage;

        private String clientCorrelator;

        @Data
        public static class ReceiptRequest implements Serializable {
            private String callbackData;

            private String notifyURL;
        }

        @Data
        public static class OutboundSMSTextMessage implements Serializable {
            private String message;
        }
    }
}
