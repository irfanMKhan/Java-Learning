package com.reddot.ecrm_bulk.api.payload.subscriber;

import lombok.Data;

import java.io.Serializable;

@Data
public class SubscriberInfoErrorResponse implements Serializable {
  private String variables;

  private String code;

  private String message;
}
