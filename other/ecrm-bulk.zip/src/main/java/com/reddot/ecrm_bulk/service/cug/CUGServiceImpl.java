package com.reddot.ecrm_bulk.service.cug;

import com.reddot.ecrm_bulk.entity.cug.CUG;
import com.reddot.ecrm_bulk.repository.cug.CUGRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class CUGServiceImpl implements CUGService {
    private final CUGRepository cugRepository;
    @Override
    public CUG findByCugAccountId(Long cugAccountId) {
        try {
            return cugRepository.findByCugAccountId(cugAccountId);
        } catch (EmptyResultDataAccessException e) {
            log.debug("CUG Not found By CUG Account Id: {}", cugAccountId);
            return null;
        }
    }
}
