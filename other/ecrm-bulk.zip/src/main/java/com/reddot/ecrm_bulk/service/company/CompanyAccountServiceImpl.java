package com.reddot.ecrm_bulk.service.company;

import com.google.gson.Gson;
import com.reddot.ecrm_bulk.dto.contract.ContractInfo;
import com.reddot.ecrm_bulk.entity.annex.Annex;
import com.reddot.ecrm_bulk.entity.company.CompanyAccount;
import com.reddot.ecrm_bulk.entity.cug.CUG;
import com.reddot.ecrm_bulk.enums.company.CustomerAccountType;
import com.reddot.ecrm_bulk.repository.company.CompanyAccountRepository;
import com.reddot.ecrm_bulk.service.cug.CUGService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class CompanyAccountServiceImpl implements CompanyAccountService {
    private final CompanyAccountRepository companyAccountRepository;
    private final CUGService cugService;
    private final Gson gson;

    public String findCUGGroupByCustomerName(String customerName) {
        try {
            CompanyAccount companyAccount = companyAccountRepository.findByCompanyNameAndCustomerAccountTypeAndActive(customerName, CustomerAccountType.CUG_GROUP.name(), true);
            if (!ObjectUtils.isEmpty(companyAccount)) {
                return companyAccount.getAccountCode();
            } else {
                return null;
            }
        } catch (EmptyResultDataAccessException e) {
            log.debug("Company Account not found with company name: " + customerName);
            return null;
        }
    }

    @Override
    public String findCustomerIdByCustomerName(String customerName) {
        try {
            CompanyAccount companyAccount = companyAccountRepository.findByCompanyName(customerName);
            if (! ObjectUtils.isEmpty(companyAccount)) {
                return companyAccount.getAccountId();
            } else {
                return null;
            }
        } catch (EmptyResultDataAccessException e) {
            log.debug("Company Account not found with company name: " + customerName);
            return null;
        }
    }

    @Override
    public CompanyAccount findByAccountCode(String accountCode)  {
        try {
            return companyAccountRepository.findByAccountCode(accountCode);
        } catch (EmptyResultDataAccessException e) {
            log.debug("Company not found with account code: " + accountCode);
            return null;
        }
    }

    @Override
    public CompanyAccount findParentSubscriberAccountById(Long id)  {
        try {
            return companyAccountRepository.findParentSubscriberAccountById(id);
        } catch (EmptyResultDataAccessException e) {
            log.debug("Parent subscriber account not found with account id: " + id);
            return null;
        }
    }

    @Override
    public String findParentCorporateGroupIdByCorporateGroupCode(String corporateGroupCode) {
        try {
            CompanyAccount companyAccount = findByAccountCode(corporateGroupCode);

            if (!ObjectUtils.isEmpty(companyAccount)) {
                CompanyAccount parentSubscriberAccount = findParentSubscriberAccountById(companyAccount.getParentSubscriberId());
                if (!ObjectUtils.isEmpty(parentSubscriberAccount)) {
                    return parentSubscriberAccount.getAccountId();
                } else {
                    return null;
                }
            } else {
                return null;
            }
        } catch (EmptyResultDataAccessException e) {
            log.debug("Company Account not found with account code: " + corporateGroupCode);
            return null;
        }
    }

    @Override
    public Map<String, String> findBranchSubscriberByCustomerNameAndServiceTypeBranch(String customerName, String serviceType, String branch) {
        Map<String, String> group = new HashMap<>();
        try {
            CompanyAccount companyAccount = findBranchSubscriberByCustomerNameAndServiceTypeAndBranch(customerName, serviceType, branch);
            if (!ObjectUtils.isEmpty(companyAccount)) {
                group.put("groupCode", companyAccount.getAccountCode());
                group.put("groupName", companyAccount.getAccountName());
            }
            return group;
        } catch (EmptyResultDataAccessException e) {
            log.debug("Company Account not found with company name: {} and service type: {}", customerName, serviceType);
            return group;
        }
    }

    @Override
    public CompanyAccount findParentCustomerByAccountName(String accountName) {
        try {
            return companyAccountRepository.findParentCustomerByAccountName(accountName);
        } catch (EmptyResultDataAccessException e) {
            log.debug("Parent Customer Not Found with Account Name: {}", accountName);
            return null;
        }
    }

    @Override
    public CompanyAccount findBranchSubscriberByCustomerNameAndServiceTypeAndBranch(String companyName, String serviceTypeName, String branch) {
        try {
            return companyAccountRepository.findBranchSubscriberByCustomerNameAndServiceTypeAndBranch(companyName, serviceTypeName, branch);
        } catch (EmptyResultDataAccessException e) {
            log.debug("Branch Subscriber Not Found with Company Name: {}, service type: {} and branch: {}", companyName, serviceTypeName, branch);
            return null;
        }
    }

    @Override
    public CompanyAccount findById(Long id) {
        try {
            return companyAccountRepository.findById(id);
        } catch (EmptyResultDataAccessException e) {
            log.debug("Company Account Not Found with Id: {}", id);
            return null;
        }
    }
    @Override
    public CompanyAccount findCUGGroupByCompanyName(String companyName) {
        try {
            return companyAccountRepository.findCUGGroupByCompanyName(companyName);
        } catch (EmptyResultDataAccessException e) {
            log.debug("CUG Group Subscriber Not Found with Company Name: {}", companyName);
            return null;
        }
    }

    @Override
    public CompanyAccount findParentSubscriberAccountByCustomerName(String companyName, String serviceTypeName) {
        try {
            return companyAccountRepository.findParentSubscriberAccountByCustomerName(companyName, serviceTypeName);
        } catch (EmptyResultDataAccessException e) {
            log.debug("Parent Subscriber Account Not Found with Company Name: {} and service type: {}", companyName, serviceTypeName);
            return null;
        }
    }
    @Override
    public ContractInfo findContractInfoByCompanyName(String companyName, Annex annex) {
        ContractInfo contractInfo = new ContractInfo();

        CompanyAccount branchSubscriber = findBranchSubscriberByCustomerNameAndServiceTypeAndBranch(companyName, annex.getServiceTypeName(), annex.getBranch());
        CompanyAccount companyCUGGroup = findCUGGroupByCompanyName(companyName);
        CompanyAccount parentSubscriber = findParentSubscriberAccountByCustomerName(companyName, annex.getServiceTypeName());

        if (!ObjectUtils.isEmpty(companyCUGGroup)) {
            contractInfo.setCugGroupCode(companyCUGGroup.getAccountCode());
            contractInfo.setCugAccountId(companyCUGGroup.getId());
            CUG cugEntity = cugService.findByCugAccountId(companyCUGGroup.getId());
            if (!ObjectUtils.isEmpty(cugEntity)) {
                contractInfo.setCugId(cugEntity.getId());
            }
        }

        if (!ObjectUtils.isEmpty(branchSubscriber)) {
            contractInfo.setBranchSubscriberAccountId(branchSubscriber.getId());
            contractInfo.setParentCustomerAccountId(branchSubscriber.getParentCustomerId());
            contractInfo.setBranchAccountAccountId(branchSubscriber.getParentAccountId());
            contractInfo.setCompanyId(branchSubscriber.getCompanyId());
            contractInfo.setBranchGRPCode(branchSubscriber.getAccountCode());
            contractInfo.setBranchGRPName(branchSubscriber.getAccountName());
            contractInfo.setBranchGRPId(branchSubscriber.getAccountId());
            contractInfo.setMainCorSubscriberAccountId(branchSubscriber.getParentSubscriberId());


        }

        if (!ObjectUtils.isEmpty(parentSubscriber)) {
            contractInfo.setMain_Grp_ID(parentSubscriber.getAccountId());
            contractInfo.setMain_Grp_Code(parentSubscriber.getAccountCode());
            contractInfo.setMain_Grp_Name(parentSubscriber.getAccountName());
            contractInfo.setMainCorAccountAccountId(parentSubscriber.getParentAccountId());

            CompanyAccount parentAccount = findById(parentSubscriber.getParentAccountId());
            contractInfo.setParentAccountAccountCode(parentAccount.getAccountCode());
        }
        return contractInfo;
    }

}
