package com.reddot.ecrm_bulk.scheduler;

import com.reddot.ecrm_bulk.service.cr.inc_dec_cl.IncreaseDecreaseCreditLimitService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CRSchedulerService {
    private static final Logger logger = LoggerFactory.getLogger(CRSchedulerService.class);
    private final IncreaseDecreaseCreditLimitService increaseDecreaseCreditLimitService;

    @Scheduled(cron = "0 */1 * ? * *")
    public void SchedulerIncDecCreditLimit() {
        try {
            increaseDecreaseCreditLimitService.ScheduledCreditLimitApiCall();
        } catch (Exception e) {
            logger.error(String.format("CRSchedulerService:SchedulerIncDecCreditLimit() Error: %s", e.getMessage()));
        }
    }

    @Scheduled(cron = "0 */30 * ? * *")
    public void SchedulerIncDecCreditLimitForTemporary() {
        try {
            increaseDecreaseCreditLimitService.ScheduledForTemporaryCreditLimitApiCall();
        } catch (Exception e) {
            logger.error(String.format("CRSchedulerService:SchedulerIncDecCreditLimitForTemporary() Error: %s", e.getMessage()));

        }
    }

}
