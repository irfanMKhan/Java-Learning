package com.reddot.ecrm_bulk.repository.account;

import com.reddot.ecrm_bulk.entity.account_details.Address;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

@Repository
public class AddressRepository {
    @PersistenceContext
    private EntityManager entityManager;

    public Address findById(Long id) {
        TypedQuery<Address> query = entityManager.createQuery(
                "SELECT a FROM Address a WHERE a.id = :id",
                Address.class);
        return query.setParameter("id", id).getSingleResult();
    }
}
