package com.reddot.ecrm_bulk.scheduler;

import com.reddot.ecrm_bulk.service.notification.NotificationService;
import freemarker.template.TemplateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;


@Component
public class NotificationScheduler {

    private final Logger logger = LoggerFactory.getLogger(getClass().getName());

    @Autowired
    NotificationService notificationService;

    @Scheduled(cron = "0 0 6,18 * * *")
    //@Scheduled(fixedRate = 100000000)
    public void dailyTwiceSyncScheduler() throws TemplateException, IOException {
        logger.info("Inside rpaDailyTwiceSyncScheduler");
        //notificationService.processRPAReport("ECRM_UNWILLING_DATA_ADJUSTMENT", "Unwillingly purchased Data pack adjustment AI_OPS Report");
    }

    @Scheduled(cron = "0 0 12 * * *")
    //@Scheduled(fixedRate = 100000000)
    public void dailySyncScheduler() throws TemplateException, IOException {
        logger.info("Inside rpaDailySyncScheduler");
        //notificationService.processRPAReport("ECRM_CC_CALL_COST_REBATE", "Call cost rebate AI_OPS Report");
    }
}
