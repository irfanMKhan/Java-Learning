package com.reddot.ecrm_bulk.dto.SwapSim;

import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SwapSimDTO {
    private Long companyId;
    private String companyName;

    private String accountCode;

    private String oldMsisdn;
    private String newMsisdn;
    private String oldIccId;
    private String newIccId;
    private String swapType;
    private Double discount;
    private Double serviceCharge;
    private Double upfrontFee;
    private String effectiveMode;
    private String date;
    private Boolean emailNotification;
    private Boolean requestForPtoP;
    private String documentType;
    private String documentName;
    private String remarks;
    private Boolean ptp;
    private Boolean email;
    private String status;

    private String financialType;
    private String financialTypeText;
    private Double financialTypeAmount;
    private Double finalCost;
    private String ptpDate;
    private Integer ptpDays;
    private String adjustmentSerialNo;
    private Long tenant_id;

    //private MultipartFile file;
    private String apiRequest;
    private String apiResponse;
    private String fileLocation;
}
