package com.reddot.ecrm_bulk.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

public class UniqueIDGenerator {
    private static final UniqueIDGenerator object = new UniqueIDGenerator();

    private static LocalDate lastResetDate;
    private static LocalDateTime lastLocalDateTime;
    private static AtomicInteger counter = null;

    private UniqueIDGenerator() {
        if (counter != null) {
            //if anyone reinitialized using java reflection.
            throw new RuntimeException("Counter already initialized.");
        }
        counter = new AtomicInteger(0);
        lastResetDate = LocalDate.now();
    }

    private static UniqueIDGenerator getInstance() {
        return object;
    }

    public static synchronized String getNextUniqueNumber(String prefix) {
        resetCounterValue();
        String dateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MMddhhmmss")); //EB2023000151
        // dateTime = dateTime.substring(2, dateTime.length());
        int number = counter.incrementAndGet();
        String contractNO = prefix + dateTime + String.format("%02d", number);
        return contractNO;
    }

    public static synchronized String getNextUniqueNumberOnly() {
        resetCounterValue();
        String dateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddhhmmss")); //EB2023000151
        // dateTime = dateTime.substring(2, dateTime.length());
        int number = counter.incrementAndGet();
        String contractNO =  dateTime + String.format("%02d", number);
        return contractNO;
    }

    private static void resetCounterValue() {
        //2 digit always if it 99 then next 100 which is 3 digit
        if (counter == null) {
            new UniqueIDGenerator();
        }
        if (counter != null && counter.incrementAndGet() == 99) {
            counter.set(0);
        }
        //new date will auto set counter to 0
        LocalDate currentDate = LocalDate.now();
        if (!currentDate.equals(lastResetDate)) {
            counter.set(0);
            lastResetDate = currentDate;
        }
    }


//    public static synchronized String getNextUniqueNumber(String prefix) {
//        resetCounterValue();
//        String dateTime = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")); //EB2023000151
//        dateTime = dateTime.substring(0, 4);
//        int number = counter.incrementAndGet();
//        String newUniqueNumber = prefix + dateTime + "-" + String.format("%06d", number);
//        //todo: prb when we deploy it will restart the value and for same year we got same unique number
//        return newUniqueNumber;
//    }
//
//    private static void resetCounterValue() {
////        //2 digit always if it 99 then next 100 which is 3 digit
////        if (counter.incrementAndGet() == 999999) {
////            counter.set(0);
////        }
//        //new date will auto set counter to 0
//        LocalDate currentDate = LocalDate.now();
//        String curYear = getYear(currentDate);
//        String lastResetYear = getYear(lastResetDate);
//
//        if (!curYear.equals(lastResetYear)) {
//            counter.set(0);
//            lastResetDate = currentDate;
//        }
//    }
//
//    private static String getYear(LocalDate localDate) {
//        String year = localDate.format(DateTimeFormatter.ofPattern("yyyy"));
//        return year;
//    }
}

