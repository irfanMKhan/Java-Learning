package com.reddot.ecrm_bulk.service.contact;

import com.reddot.ecrm_bulk.entity.contract.Contact;

import java.util.List;

public interface ContactService {
    List<Contact> findByContractId(Long contractId);
}
