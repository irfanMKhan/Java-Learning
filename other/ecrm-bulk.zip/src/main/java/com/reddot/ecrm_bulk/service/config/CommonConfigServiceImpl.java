package com.reddot.ecrm_bulk.service.config;

import com.reddot.ecrm_bulk.repository.config.CommonConfigRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class CommonConfigServiceImpl implements CommonConfigService {
    private final CommonConfigRepository commonConfigRepository;

    @Override
    public String findNameByIdAndTypeNameAndSubTypeName(Long id, String typeName, String subTypeName) {
        try {
            return commonConfigRepository.findNameByIdAndTypeNameAndSubTypeName(id, typeName, subTypeName);
        } catch (Exception e) {
            if (e instanceof EmptyResultDataAccessException) {
                log.debug("Common Config Not Found By Id: {}", id);
                return null;
            } else {
                throw new RuntimeException(e);
            }
        }
    }
}
