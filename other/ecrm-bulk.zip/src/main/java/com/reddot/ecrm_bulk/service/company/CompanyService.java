package com.reddot.ecrm_bulk.service.company;

import com.reddot.ecrm_bulk.entity.annex.Annex;
import com.reddot.ecrm_bulk.entity.company.Company;

public interface CompanyService {
    Company findCompanyByName(String companyName);
    void updateCompany(Company company, Annex annex);
    Company findCompanyById(Long companyId);
}
