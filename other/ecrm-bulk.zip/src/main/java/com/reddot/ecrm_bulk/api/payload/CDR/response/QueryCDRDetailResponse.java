package com.reddot.ecrm_bulk.api.payload.CDR.response;

import lombok.*;

import java.io.Serializable;
import java.util.List;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class QueryCDRDetailResponse implements Serializable {
    private QueryCDRResult QueryCDRResult;

    @Data
    public class QueryCDRResult implements Serializable {


        private String TotalCDRNum;
        private String BeginRowNum;
        private String FetchRowNum;
        private List<CDRSummary> CDRSummary;
        private List<CDRInfo> CDRInfo;
    }

    @Data
    public class CDRSummary implements Serializable {
        private String ServiceCategory;
        private String SeriveType;

        private String ServiceTypeName;

        private Object FlowType;

        private Object RoamFlag;

        private String BillCycleID;

        private VolumeInfo VolumeInfo;
    }
    @Data

    public static class CDRInfo implements Serializable{


        private String CdrSeq;

        private String ServiceCategory;

        private String SeriveType;

        private String ServiceTypeName;

        private String SubKey;

        private String PrimaryIdentity;
        private String AccountKey;

        private Object OtherNumber;

        private Object OriginalCalledParty;

        private Object FlowType;

        private String ChargingPartyNumber;

        private Object RoamFlag;

        private Object CallingCellID;

        private Object CalledCellID;
        private AreaInfo AreaInfo;

        private Object RefundIndicator;

        private Object SpecialNumberIndicator;

        private Object URL;

        private Object ServiceID;

        private Object SpCpID;

        private Object CategoryID;

        private Object ContentID;

        private String StartTime;

        private String EndTime;

        private String BillCycleID;

        private VolumeInfo__1 VolumeInfo;

        private String ChargeDuration;

        private Object OperatorID;

        private Object LoanTransID;

        private Object Channel;

        private Object AccountBalanceID;

        private Object FreeUnitID;

        private List<AdditionalProperty> AdditionalProperty;

        private TotalChargeInfo TotalChargeInfo;
        private ChargeDetail ChargeDetail;
    }
    @Data

    public class VolumeInfo implements Serializable{


        private String ActualVolume;

        private String RatingVolume;

        private String FreeVolume;

        private String MeasureUnit;
    }
    @Data

    public class AreaInfo implements Serializable{


        private String CallingHomeCountryCode;

        private String CallingHomeAreaNumber;

        private String CallingHomeOperatorNumber;

        private String CallingRoamCountryCode;

        private String CallingRoamAreaNumber;

        private String CallingRoamOperatorNumber;

        private String CalledHomeCountryCode;

        private String CalledHomeAreaNumber;

        private String CalledHomeOperatorNumber;

        private String CalledRoamCountryCode;

        private String CalledRoamAreaNumber;

        private String CalledRoamOperatorNumber;

        private Object CallingHomeNetWorkCode;

        private Object CallingRoamNetWorkCode;

        private Object CalledHomeNetWorkCode;

        private Object CalledRoamNetWorkCode;
    }
    @Data

    public class VolumeInfo__1 implements Serializable{

        private String ActualVolume;

        private String RatingVolume;

        private String FreeVolume;

        private String MeasureUnit;
    }
    @Data

    public class AdditionalProperty implements Serializable{

        private String Code;

        private String Value;
    }
    @Data
    public class TotalChargeInfo implements Serializable{

        private String ActualChargeAmt;

        private String FreeChargeAmt;

        private String CurrencyID;
    }
    @Data
    public class ChargeDetail implements Serializable {


        private String ChargeCode;

        private String ChargeCodeName;

        private String ChargeAmount;

        private String PayAcctKey;

        private String PayObjClass;

        private String PayObjType;

        private String PayObjID;

        private String OfferingID;

        private String PlanID;

        private String CurrencyID;
    }
}