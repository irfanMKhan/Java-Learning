package com.reddot.ecrm_bulk.service.number_activation;

import com.google.common.collect.Lists;
import com.reddot.ecrm_bulk.entity.annex.Annex;
import com.reddot.ecrm_bulk.entity.contract.Contract;
import com.reddot.ecrm_bulk.entity.msisdn.MSISDN;
import com.reddot.ecrm_bulk.enums.payment.PaymentOption;
import com.reddot.ecrm_bulk.service.company.MSISDNService;
import com.reddot.ecrm_bulk.service.config.CommonConfigService;
import com.reddot.ecrm_bulk.service.contract.AnnexService;
import com.reddot.ecrm_bulk.service.contract.ContractService;
import com.reddot.ecrm_bulk.service.number_activation.strategy.payment.PaymentStrategy;
import com.reddot.ecrm_bulk.service.number_activation.strategy.payment.PaymentStrategyFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jobrunr.scheduling.JobScheduler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.util.List;
import java.util.stream.Collectors;

import static com.reddot.ecrm_bulk.enums.payment.PaymentOption.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class NumberActivationService {
    @Value("${batch.chunkSize}")
    private int chunkSize;
    private final ContractService contractService;
    private final AnnexService annexService;
    private final JobScheduler jobScheduler;
    private final MSISDNService msisdnService;
    private final PaymentStrategyFactory paymentStrategyFactory;
    private final CommonConfigService commonConfigService;

    // Contract List
    public void proceedExecution() {
        List<Contract> contractList = contractService.findAll();
        List<List<Contract>> result = Lists.partition(contractList, chunkSize);

        for (List<Contract> contracts: result) {
            for (Contract contract: contracts) {
                jobScheduler.enqueue(() -> this.proceedContractExecution(contract));
            }
        }
    }

    // Annex List
    public void proceedContractExecution(Contract contract) {
        List<Annex> annexList = annexService.findAllByContractId(contract.getId());
        List<List<Annex>> result = Lists.partition(annexList, chunkSize);

        for (List<Annex> annexes: result) {
            for (Annex annex : annexes) {
                jobScheduler.enqueue(() -> proceedAnnexExecution(contract, annex));
            }
        }
    }

    // Proceed
    public void proceedAnnexExecution(Contract contract, Annex annex) {
        List<MSISDN> msisdnList = msisdnService.findAllByMSISDN(annex.getMsisdn());

        // Check whether msisdn is exists.
        if (! msisdnList.isEmpty()) {

            List<MSISDN> activeMSISDNList = msisdnList.stream().filter(MSISDN::getActive).collect(Collectors.toList());
            // Proceed activation if msisdn exits and status is inactive
            if (activeMSISDNList.isEmpty()) {
                proceed(contract, annex);
            } else {
                // Update remarks of Annex if msisdn exists and status is active
                log.debug("MSISDN: {} already exists.", annex.getMsisdn());
                annexService.updateAnnexRemarksAndSetStatusFailed(annex, "MSISDN " + annex.getMsisdn() + " already used.");
            }
        } else {
            // Proceed activation if msisdn does not exist.
            proceed(contract, annex);
        }
    }

    public void proceed(Contract contract, Annex annex) {
        try {
            switch (getPaymentOption(annex)) {
                case Prepayment:
                    PaymentStrategy prePaymentStrategy = paymentStrategyFactory.createPaymentStrategy(Prepayment);
                    prePaymentStrategy.process(contract, annex);
                    break;
                case Immediately:
                    PaymentStrategy immediatelyPaymentStrategy = paymentStrategyFactory.createPaymentStrategy(Immediately);
                    immediatelyPaymentStrategy.process(contract, annex);
                    break;
                case PromiseToPay:
                    PaymentStrategy promiseToPayPaymentStrategy = paymentStrategyFactory.createPaymentStrategy(PromiseToPay);
                    promiseToPayPaymentStrategy.process(contract, annex);
                    break;
                case NoDevice:
                    PaymentStrategy noDevicePaymentStrategy = paymentStrategyFactory.createPaymentStrategy(NoDevice);
                    noDevicePaymentStrategy.process(contract, annex);
                    break;
                default:
                    throw new IllegalArgumentException("Invalid payment option.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.debug("Proceed Error: {} {}", e.getMessage(), e.getCause());
        }
    }

    public PaymentOption getPaymentOption(Annex annex) {
        if (!ObjectUtils.isEmpty(annex.getPayment()) && !annex.getPayment().equalsIgnoreCase("-99")) {
            String paymentName = commonConfigService.findNameByIdAndTypeNameAndSubTypeName(Long.valueOf(annex.getPayment()), "Product", "Payment");

            if (!ObjectUtils.isEmpty(annex.getPayment()) && !ObjectUtils.isEmpty(paymentName) && paymentName.equalsIgnoreCase(Prepayment.getValue())) {
                return Prepayment;
            } else if (!ObjectUtils.isEmpty(annex.getPayment()) && !ObjectUtils.isEmpty(paymentName) && paymentName.equalsIgnoreCase(Immediately.getValue())) {
                return Immediately;
            }  else if (!ObjectUtils.isEmpty(annex.getPayment()) && !ObjectUtils.isEmpty(paymentName) && paymentName.equalsIgnoreCase(PromiseToPay.getValue())) {
                return PromiseToPay;
            } else {
                throw new IllegalArgumentException("No Payment Option Found For Payment:" + annex.getPayment());
            }
        } else {
            return NoDevice;
        }
    }
}
