package com.reddot.ecrm_bulk.api.payload.subscriber;

import lombok.Data;

import java.io.Serializable;

@Data
public class PrepaidToPostpaidResponse implements Serializable {
    private String transaction_id;

    private String transaction_status;

    private Metadata metadata;

    private Object data;

    @Data
    public static class Metadata implements Serializable {
        private String operator_id;

        private String channel_id;
    }
}
