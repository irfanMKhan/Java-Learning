package com.reddot.ecrm_bulk.entity.bulk;

import com.reddot.ecrm_bulk.enums.bulk.BulkProcessStatusEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;
import java.time.LocalDate;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "bulk_file")
public class BulkUploadFilesEntity extends AbstractEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "file_name")
    private String fileName;
    @Column(name = "file_extension_type")

    private String fileExtensionType;
    @Column(name = "file_path")
    private String filePath;
    @Column(name = "file_serverip")

    private String fileServerIP;
    @Column(name = "process_type_id")

    private Integer processTypeId;
    @Column(name = "process_type_name")

    private String processTypeName;
    @Column(name = "file_size")

    private Long fileSize;
    @Column(name = "total_rows")

    private Integer totalRows;
    @Column(name = "total_columns")

    private Integer totalColumns;
    @Column(name = "success_rows")

    private Integer successRows;
    @Column(name = "failed_rows")

    private Integer failedRows;
    @Enumerated(EnumType.STRING)
    @Column(name = "process_status")
    private BulkProcessStatusEnum processStatus;
    @Column(name = "active")

    private Boolean active;
    @Column(name = "remarks",columnDefinition = "text")
    private String remarks;
    @Column(name = "start_date")
    private LocalDate startDate;
    @Column(name = "end_date")
    private LocalDate endDate;
    @Column(name = "is_run")

    private Boolean isRun;
    @Column(name = "schedule_time")

    private LocalDate scheduleTime;
    @Column(name = "company_id")

    private Long companyId;
    @Column(name = "company_name")

    private String companyName;
    @Column(name = "uuid_token")

    private String uuidToken;
}

