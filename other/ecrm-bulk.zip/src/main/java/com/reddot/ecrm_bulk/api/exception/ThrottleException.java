package com.reddot.ecrm_bulk.api.exception;

public class ThrottleException extends RuntimeException {
    public ThrottleException(String message) {
        super(message);
    }

    public ThrottleException(String message, Throwable throwable) {
        super(message, throwable);
    }
}
