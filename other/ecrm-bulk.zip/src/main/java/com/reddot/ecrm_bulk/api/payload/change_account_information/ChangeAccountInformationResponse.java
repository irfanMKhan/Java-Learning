package com.reddot.ecrm_bulk.api.payload.change_account_information;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class ChangeAccountInformationResponse implements Serializable {
  private String transaction_id;

  private String transaction_status;

  private Data data;

  @lombok.Data
  public static class Data implements Serializable {
    private Account Account;

    @lombok.Data
    public static class Account implements Serializable {
      private List<Address> Address;

      private String BillCycleType;

      private String AcctPayMethod;

      private List<AdditionalProperty> AdditionalProperty;

      private String BillLanguage;

      private Name Name;

      @lombok.Data
      public static class Address implements Serializable {
        private String ActionType;

        private String Address11;

        private String Address2;

        private String Address3;

        private String Address1;

        private String AddressType;
      }

      @lombok.Data
      public static class AdditionalProperty implements Serializable {
        private String Value;

        private String Code;
      }

      @lombok.Data
      public static class Name implements Serializable {
        private String FirstName;

        private String LastName;
      }
    }
  }
}
