package com.reddot.ecrm_bulk.enums.email.email_template;

import lombok.Getter;

@Getter
public enum EmailTemplateEnum {
    Common_Template("Common", "email-template.html"),
    Contract_Template("Contract", "contract/contract-template.html"),
    Contract_Products_Template("Contract Product", "contract/contract_product_template.html"),
    KAM_Notification_Template("KAM Approval Notification","email-template-for-kam-notification.html"),
    Delegation_Template("Delegation", "delegation/email-template-for-delegation.html"),
    Opportunity_Template("Opportunity", "contract/contract-template.html");


    private final String featureName, templateName;

    EmailTemplateEnum(String featureName, String templateName) {

        this.featureName = featureName;
        this.templateName = templateName;
    }
}
