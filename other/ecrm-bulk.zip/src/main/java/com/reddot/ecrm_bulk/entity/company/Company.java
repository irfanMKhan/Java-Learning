package com.reddot.ecrm_bulk.entity.company;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "company")
public class Company {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private Boolean active;

    @Column(name = "contract_status")
    private Integer contractStatus;

    @Column(name = "contract_status_value")
    private String contractStatusValue;

    @Column(name = "opportunity_status")
    private Integer opportunityStatus;

    @Column(name = "opportunity_status_value")
    private String opportunityStatusValue;

    private Double creditCeiling;
    private Double creditLimit;

    @Column(name = "lead_number", unique = true)
    private String leadNumber;

    @Column(name = "opportunity_number", unique = true)
    private String opportunityNumber;

    @Column(name = "CONTRACT_NUMBER")
    private String contractNumber;

    @Column(name = "status_id")
    private String statusId;

    @Column(name = "status_name")
    private String statusName;

    @Column(name = "kam_id")
    private Long kamId;

    @Column(name = "kam_name")
    private String kamName;

    @Column(name = "opportunity_percentage_id")
    private Long opportunityPercentageId;

    @Column(name = "opportunity_percentage_name")
    private String opportunityPercentageName;

    @Column(name = "creator_id")
    private Long creatorId;

    @Column(name = "creator_name")
    private String creatorName;

    @Column(name = "customer_name")
    private String customerName;

    @Column(name = "current_prod_serv_id")
    private Long currentProdServId;

    @Column(name = "current_prod_serv_name")
    private String currentProdServName;

    @Column(name = "current_plan_expiry")
    private Long currentPlanExpiryAt;

    @Column(name = "current_plan_expiry_dt")
    private Timestamp currentPlanExpiryAtDt;

    @Column(name = "follow_up")
    private Long followUpAt;

    @Column(name = "follow_up_dt")
    private Timestamp followUpAtDt;

    @Column(name = "latitude")
    private String latitude;

    @Column(name = "longitude")
    private String longitude;

    @Column(name = "coverage_available")
    private Boolean coverageAvailable;

    @Column(name = "remarks")
    private String remarks;

    @Column(name = "sub_industry_id")
    private Long subIndustryId;

    @Column(name = "sub_industry_name")
    private String subIndustryName;

    @Column(name = "industry_id")
    private Long industryId;

    @Column(name = "industry_name")
    private String industryName;

    @Column(name = "number_of_employees_id")
    private Long numberOfEmployeesId;

    @Column(name = "num_of_employees")
    private String numOfEmployees;

    @Column(name = "size_of_industry")
    private String sizeOfIndustry;

//    @Column(name = "num_of_lines")
//    private Long numOfLines;
//
//    @Column(name = "monthly_fee")
//    private BigDecimal monthlyFee;

    // uncommenting the code below to get contractDuration on refund module
    @Column(name = "contract_duration")
    private Long contractDuration;

//    @Column(name = "estimated_revenue")
//    private BigDecimal estimatedRevenue;

    @Column(name = "website")
    private String website;

    @Column(name = "revenue_id")
    private Long revenueId;

    @Column(name = "revenue_name")
    private String revenueName;

    @Column(name = "house_num")
    private String houseNum;

    @Column(name = "street")
    private String street;

    @Column(name = "sangkat_commune_id")
    private Long sangkatCommuneId;

    @Column(name = "sangkat_commune_name")
    private String sangkatCommuneName;

    @Column(name = "khan_district_id")
    private Long khanDistrictId;

    @Column(name = "khan_district_name")
    private String khanDistrictName;

    @Column(name = "city_province_id")
    private Long cityProvinceId;

    @Column(name = "city_province_name")
    private String cityProvinceName;

    @Column(name = "village_group_name")
    private String villageGroupName;

    @Column(name = "postcode")
    private String postcode;

    @Column(name = "country_id")
    private Long countryId;

    @Column(name = "country_name")
    private String countryName;


    @Column(name = "created_at")
    private Long createdAt;

    @Column(name = "created_at_dt")
    private Timestamp createdAtDt;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_by_username")
    private String createdUsername;

    @Column(name = "updated_at")
    private Long updatedAt;

    @Column(name = "updated_at_dt")
    private Timestamp updatedAtDt;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_by_username")
    private String updatedUsername;


}
