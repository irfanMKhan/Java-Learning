package com.reddot.ecrm_bulk.service.contract;

import com.reddot.ecrm_bulk.entity.annex.Annex;
import com.reddot.ecrm_bulk.enums.status.Status;

import java.util.List;

public interface AnnexService {
    void updateAnnexAPIMessage(Annex annex, String message);

    void updateAnnexStatus(Annex annex, Status status);

    void updateAnnexRemarksAndSetStatusFailed(Annex annex, String remarks);

    Annex update(Annex annex);
    List<Annex> findAllByContractId(Long contractId);
}
