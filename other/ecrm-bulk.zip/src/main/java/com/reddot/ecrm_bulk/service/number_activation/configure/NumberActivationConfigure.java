package com.reddot.ecrm_bulk.service.number_activation.configure;

import com.reddot.ecrm_bulk.service.number_activation.ActivationService;
import com.reddot.ecrm_bulk.service.number_activation.strategy.payment.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class NumberActivationConfigure {

    @Bean
    public PaymentStrategyFactory paymentStrategyFactory(ActivationService activationService) {
        return paymentOption -> {
            switch (paymentOption) {
                case Prepayment:
                    return new PrepaymentStrategy(activationService);
                case Immediately:
                    return new ImmediatelyStrategy(activationService);
                case PromiseToPay:
                    return new PromiseToPayStrategy(activationService);
                case NoDevice:
                    return new NoDeviceStrategy(activationService);
                default:
                    throw new IllegalArgumentException("Invalid payment option: " + paymentOption);
            }
        };
    }
}
