package com.reddot.ecrm_bulk.entity.cr;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "cr_master")
public class CRMasterEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long tenantId;

    private String transactionID;
    private Boolean isBulkFile;


    private String apiRequest;
    private String apiResponse;
    private Long companyId;
    private String companyName;
    private Integer requestTypeId;
    private String requestType;
    private LocalDate requestedDate;
    private String month;
    private String status;


    private String paymentType;
    private String ptpPaymentFor;
    private Integer ptpPaymentProcessDays;
    private LocalDate ptpPaymentProcessDate;
    @Column(columnDefinition = "text")
    private String remarks;

    private LocalDate effectiveDate;


    private String finalStatus;

    private Integer numberOfLines;

    private Long bulkFileId;

    @Column(name = "created_at")
    private Long createdAt;

    @Column(name = "created_at_dt")
    private Timestamp createdAtDt;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_by_username")
    private String createdUsername;

    @Column(name = "updated_at")
    private Long updatedAt;

    @Column(name = "updated_at_dt")
    private Timestamp updatedAtDt;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_by_username")
    private String updatedUsername;
}
