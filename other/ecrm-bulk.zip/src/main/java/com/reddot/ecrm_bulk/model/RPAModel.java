package com.reddot.ecrm_bulk.model;

public class RPAModel {
    String  RPA_NAME, SR_NUMBER, MSISDN, PACK, PACK_ID, BONUS_PACK, BONUS_PACK_ID, PRICE,
            USAGE, ERROR, LIST_TYPE, CREATED_AT_DT, SR_STATUS, REMARKS, MSISDN_CATEGORY;

    public String getRPA_NAME() {
        return RPA_NAME;
    }

    public void setRPA_NAME(String RPA_NAME) {
        this.RPA_NAME = RPA_NAME;
    }

    public String getSR_NUMBER() {
        return SR_NUMBER;
    }

    public void setSR_NUMBER(String SR_NUMBER) {
        this.SR_NUMBER = SR_NUMBER;
    }

    public String getMSISDN() {
        return MSISDN;
    }

    public void setMSISDN(String MSISDN) {
        this.MSISDN = MSISDN;
    }

    public String getPACK() {
        return PACK;
    }

    public void setPACK(String PACK) {
        this.PACK = PACK;
    }

    public String getPACK_ID() {
        return PACK_ID;
    }

    public void setPACK_ID(String PACK_ID) {
        this.PACK_ID = PACK_ID;
    }

    public String getBONUS_PACK() {
        return BONUS_PACK;
    }

    public void setBONUS_PACK(String BONUS_PACK) {
        this.BONUS_PACK = BONUS_PACK;
    }

    public String getBONUS_PACK_ID() {
        return BONUS_PACK_ID;
    }

    public void setBONUS_PACK_ID(String BONUS_PACK_ID) {
        this.BONUS_PACK_ID = BONUS_PACK_ID;
    }

    public String getPRICE() {
        return PRICE;
    }

    public void setPRICE(String PRICE) {
        this.PRICE = PRICE;
    }

    public String getUSAGE() {
        return USAGE;
    }

    public void setUSAGE(String USAGE) {
        this.USAGE = USAGE;
    }

    public String getERROR() {
        return ERROR;
    }

    public void setERROR(String ERROR) {
        this.ERROR = ERROR;
    }

    public String getLIST_TYPE() {
        return LIST_TYPE;
    }

    public void setLIST_TYPE(String LIST_TYPE) {
        this.LIST_TYPE = LIST_TYPE;
    }

    public String getCREATED_AT_DT() {
        return CREATED_AT_DT;
    }

    public void setCREATED_AT_DT(String CREATED_AT_DT) {
        this.CREATED_AT_DT = CREATED_AT_DT;
    }

    public String getSR_STATUS() {
        return SR_STATUS;
    }

    public void setSR_STATUS(String SR_STATUS) {
        this.SR_STATUS = SR_STATUS;
    }

    public String getREMARKS() {
        return REMARKS;
    }

    public void setREMARKS(String REMARKS) {
        this.REMARKS = REMARKS;
    }

    public String getMSISDN_CATEGORY() {
        return MSISDN_CATEGORY;
    }

    public void setMSISDN_CATEGORY(String MSISDN_CATEGORY) {
        this.MSISDN_CATEGORY = MSISDN_CATEGORY;
    }
}
