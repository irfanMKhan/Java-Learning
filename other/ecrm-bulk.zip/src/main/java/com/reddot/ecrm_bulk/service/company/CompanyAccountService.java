package com.reddot.ecrm_bulk.service.company;

import com.reddot.ecrm_bulk.dto.contract.ContractInfo;
import com.reddot.ecrm_bulk.entity.annex.Annex;
import com.reddot.ecrm_bulk.entity.company.CompanyAccount;

import java.util.Map;

public interface CompanyAccountService {
    String findCUGGroupByCustomerName(String customerName);
    String findCustomerIdByCustomerName(String customerName);

    CompanyAccount findByAccountCode(String accountCode);

    CompanyAccount findParentSubscriberAccountById(Long id);

    String findParentCorporateGroupIdByCorporateGroupCode(String corporateGroupCode);
    Map<String, String> findBranchSubscriberByCustomerNameAndServiceTypeBranch(String customerName, String serviceType, String branch);

    CompanyAccount findBranchSubscriberByCustomerNameAndServiceTypeAndBranch(String companyName, String serviceTypeName, String branch);

    CompanyAccount findById(Long id);

    CompanyAccount findCUGGroupByCompanyName(String companyName);

    CompanyAccount findParentSubscriberAccountByCustomerName(String companyName, String serviceTypeName);

    ContractInfo findContractInfoByCompanyName(String companyName, Annex annex);
    CompanyAccount findParentCustomerByAccountName(String accountName);
}
