package com.reddot.ecrm_bulk.entity.cr;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "cr_msisdn_details")
public class CRMsisdnDetailsEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long tenantId;
    //Hot bill generate
    private String transactionID;
    private Integer requestTypeId;
    private String requestType;
    private Long changeRequestMasterId;
    private Long companyId;
    private String msisdn;
    private Long msisdnId;
    private Long planId;
    private LocalDate requestedDate;
    private String month;
    private String status;


    //new
    private String msisdnCategory;
    private String ngbssPlanOfferingId;
    private String ngbssAddOnsOfferingId;
    private String serviceTypeName;
    private Long serviceTypeId;
    private Boolean preToPost;
    private String productId;
    private String productName;

    //Hot bill generate
    private String planName;   //cr--> current_plan==planName


    private Long suspensionStartDate;
    private Long suspensionEndDate;
    private BigDecimal existingDefaultCredit;
    private String attachment;
    @Column(columnDefinition = "text")
    private String remarks;

    //add new number
    private String iccid;
    private Double creditLimit;
    private Double reserveCredit;
    private Double totalCredit;
    private Double monthlyFee;
    private Double maxMonthlyFee;
    private String addOn;
    private String branchName;
    private Long bulkFileId;

    private String deviceId;
    private String deviceName;
    private Double upfrontFee;
    private Integer contractDuration;  //contact_duration(in front-end)
    private LocalDate effectiveDate;
    private LocalDate maturityDate;  //maturity_date(front-end)
    private String companyName;
    private String employeeName;
    private String numberAddType;
    private String specialOfferType;
    private String specialOfferLevel;
    private String specialOfferValueType;
    private Integer specialOfferValue;
    //  private String discount;  //todo: discount --> CR add new number
    private String imei;
    private String paymentType;
    @Transient
    private String paymentTypeText;
    private String ptpPaymentFor;
    private Integer ptpPaymentProcessDays;
    private LocalDate ptpPaymentProcessDate;
    private String finalPaymentStatus;  //if ptp then done or not??
    private String finalStatus;

    //todo: new page 20 comment
    private Double amount;
    private String subBranchName;

    //cp-change plan
    private String requestedPlan;
    private Double requestedDefaultCredit;
    private Double newTotalCredit;
    private Double newMonthlyFee;
    private Double newMaxMonthlyFee;
    @Transient
    private Double remainingContractDuration;
    private Double remainingDeviceFee;
    private String newDefaultOfferPlan;
    private String financialAdjustment; //discount
    private Double totalFee;  //all fee -FA(financialAdjustment)
    private Boolean hasCharge;
    private Double chargeFee;

    @Transient
    private Long tariffPlanCategoryId;
    @Transient
    private String tariffPlanCategoryName;

    //new for cp
    private String reqNgbssPlanOfferingId;
    private String reqNgbssAddonsPlanOfferingId;


    //add remove service
    private Boolean isRoaming;
    private Double remainingPrepaidCredit;
    private String removedPlanName;
    private String ngbssRemovedOfferingPlanId;
    private String addedPlanName;
    private String ngbssAddedOfferingPlanId;
    private String finalOfferingPlans;
    private Double newRemainingCredit;

    //    private String existingOffering;
    private Boolean isChangePermanent;
    private Boolean isTemporaryToPreviousStateDone;
    private LocalDate temporaryStartDateFrom;
    private LocalDate temporaryEndDateTo;


    //increase decrease credit limit
    private Double remainingCredit;
    private Boolean isIncreaseCreditLimit; //true means increase false means decrease
    private Double requestedReserveCredit;


    //terminate
    private Integer accountNumber;
    private LocalDate activationDate;
    private Double outstandingRemainingBill;
    private Integer remainingMonth;
    private Double remainingMonthlyFee;
    private Boolean isChangeBranchApplicable;


    //cug_grp
    private String oldValue;
    private String newValue;
    private String newBranchCode;
    private String oldBranchCode;

    private Double addedTotalCredit;
    private Double removedTotalCredit;

    private Long oldPrimaryId;
    private Long newPrimaryId;

    //new
    private String adjustmentSerialNo;
    private String primaryOfferingAgreementId;
    private String upfrontPaymentAfterFA;
    private String financialType;
    private String financialTypeText;
    private Double financialAmount;
    private String statusOfPayment;

    @Column(columnDefinition = "text")
    private String requestDetails;
    @Column(columnDefinition = "text")
    private String responseDetails;

    @Transient
    private Boolean isDraftMsisdn;

    //62
    //pretopost
    private String businessPayment;

    @Column(name = "created_at")
    private Long createdAt;

    @Column(name = "created_at_dt")
    private Timestamp createdAtDt;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_by_username")
    private String createdUsername;

    @Column(name = "updated_at")
    private Long updatedAt;

    @Column(name = "updated_at_dt")
    private Timestamp updatedAtDt;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_by_username")
    private String updatedUsername;

    @Column(columnDefinition = "text")
    private String failedReason;
}
