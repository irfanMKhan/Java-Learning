package com.reddot.ecrm_bulk.model;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class StudentFeeModel {
    private Long ID;
    private Long STUDENT_PAYMENT_ID;
    private Long PAYMENT_MONTH_ID;
    private Double AMOUNT;
    @Temporal(TemporalType.TIMESTAMP)
    private Timestamp PAYMENT_DATE;
    private Integer ACTIVE;
    private Integer IS_PAID;

    public Long getID() {
        return ID;
    }

    public void setID(Long ID) {
        this.ID = ID;
    }

    public Long getSTUDENT_PAYMENT_ID() {
        return STUDENT_PAYMENT_ID;
    }

    public void setSTUDENT_PAYMENT_ID(Long STUDENT_PAYMENT_ID) {
        this.STUDENT_PAYMENT_ID = STUDENT_PAYMENT_ID;
    }

    public Long getPAYMENT_MONTH_ID() {
        return PAYMENT_MONTH_ID;
    }

    public void setPAYMENT_MONTH_ID(Long PAYMENT_MONTH_ID) {
        this.PAYMENT_MONTH_ID = PAYMENT_MONTH_ID;
    }

    public Double getAMOUNT() {
        return AMOUNT;
    }

    public void setAMOUNT(Double AMOUNT) {
        this.AMOUNT = AMOUNT;
    }

    public Timestamp getPAYMENT_DATE() {
        return PAYMENT_DATE;
    }

    public void setPAYMENT_DATE(Timestamp PAYMENT_DATE) {
        this.PAYMENT_DATE = PAYMENT_DATE;
    }

    public Integer getACTIVE() {
        return ACTIVE;
    }

    public void setACTIVE(Integer ACTIVE) {
        this.ACTIVE = ACTIVE;
    }

    public Integer getIS_PAID() {
        return IS_PAID;
    }

    public void setIS_PAID(Integer IS_PAID) {
        this.IS_PAID = IS_PAID;
    }
}
