package com.reddot.ecrm_bulk.repository.bulk;

import com.reddot.ecrm_bulk.entity.bulk.BulkUploadFileDetailsEntity;
import com.reddot.ecrm_bulk.entity.bulk.BulkUploadFilesEntity;
import com.reddot.ecrm_bulk.enums.bulk.BulkProcessStatusEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BulkFileDataRepo extends JpaRepository<BulkUploadFilesEntity,Long> {
    List<BulkUploadFilesEntity> findAllByProcessStatus(BulkProcessStatusEnum status);
}
