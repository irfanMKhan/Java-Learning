package com.reddot.ecrm_bulk.entity.bulk;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import java.sql.Timestamp;

@MappedSuperclass
@Data
public class AbstractEntity {
    @Column(name = "created_at")
    private Long createdAt;

    @Column(name = "created_at_dt")
    private Timestamp createdAtDt;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_by_username")
    private String createdByUsername;

    @Column(name = "updated_at")
    private Long updatedAt;

    @Column(name = "updated_at_dt")
    private Timestamp updatedAtDt;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_by_username")
    private String updatedByUsername;
}
