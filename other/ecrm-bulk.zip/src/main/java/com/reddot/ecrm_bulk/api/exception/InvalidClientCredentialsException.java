package com.reddot.ecrm_bulk.api.exception;

public class InvalidClientCredentialsException extends RuntimeException {
    public InvalidClientCredentialsException(String message) {
        super(message);
    }

    public InvalidClientCredentialsException(String message, Throwable throwable) {
        super(message, throwable);
    }
}
