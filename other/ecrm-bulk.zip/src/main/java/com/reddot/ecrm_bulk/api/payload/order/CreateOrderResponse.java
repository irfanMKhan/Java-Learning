package com.reddot.ecrm_bulk.api.payload.order;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateOrderResponse implements Serializable {
  private CreateOrderRspMsg CreateOrderRspMsg;

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class CreateOrderRspMsg implements Serializable {
    private RspHeader RspHeader;

    private Long OrderId;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class RspHeader implements Serializable {
      private Long RspTime;

      private String ReturnCode;

      private String ReturnMsg;

      private Integer Version;
    }
  }
}
