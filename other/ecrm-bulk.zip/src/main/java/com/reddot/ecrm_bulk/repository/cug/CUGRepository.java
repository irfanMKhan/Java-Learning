package com.reddot.ecrm_bulk.repository.cug;

import com.reddot.ecrm_bulk.entity.cug.CUG;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

@Repository
public class CUGRepository {
    @PersistenceContext
    private EntityManager entityManager;

    public CUG findById(long id) {
        return entityManager.find(CUG.class, id);
    }

    public CUG findByCugAccountId(Long cugAccountId) {
        TypedQuery<CUG> query = entityManager.createQuery(
                "SELECT c FROM CUG c WHERE c.cugAccountId = :cugAccountId AND c.active = :active",
                CUG.class);
        return query.setParameter("cugAccountId", cugAccountId)
                .setParameter("active", true)
                .getSingleResult();
    }
}
