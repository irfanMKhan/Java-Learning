package com.reddot.ecrm_bulk.service.number_activation.strategy.payment;

import com.reddot.ecrm_bulk.entity.annex.Annex;
import com.reddot.ecrm_bulk.entity.contract.Contract;
import com.reddot.ecrm_bulk.service.number_activation.ActivationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;

@Service
@Slf4j
public class PrepaymentStrategy implements PaymentStrategy {
    private final ActivationService activationService;

    @Autowired
    public PrepaymentStrategy(ActivationService _activationService) {
        activationService = _activationService;
    }
    @Override
    public void process(Contract contract, Annex annex) throws UnsupportedEncodingException {
        if (activationService.hasDevice(annex)) {
            if (activationService.todayIsEffectiveDate(annex)) {
                if (activationService.hasNoOutstanding(annex)) {
                    activationService.executeActivation(contract, annex);
                } else {
                    log.debug("Has outstanding for MSISDN: {}", annex.getMsisdn());
                }
            }
        } else {
            if (activationService.todayIsEffectiveDate(annex)) {
                activationService.executeActivation(contract, annex);
            }
        }

    }
}
