package com.reddot.ecrm_bulk.enums.status;

public enum Status {
    TODO,
    Activate,
    InProgress,
    Failed,
    Success,
    Complete,
    Submitted,
    Pending
}
