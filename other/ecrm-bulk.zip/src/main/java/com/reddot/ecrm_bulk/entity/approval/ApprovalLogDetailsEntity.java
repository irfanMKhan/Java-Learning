package com.reddot.ecrm_bulk.entity.approval;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "approval_log_details")
public class ApprovalLogDetailsEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long approvalReqId;
    private Long approvalStepId;
    private Long approvalRulesId;
    private Long approvalFlowId;
    private String approvalFlowName;
    private Long requestDetailsId;
    private Long approvedAt;
    private LocalDate approvedAtDt;
    private Long approverID;
    private String approverName;
    private String approverEmail;

    private Integer stepOrder;
    private Boolean isOptional;
    private String status;
    private String uuidToken;
    private Long tenantId;
    private String transactionId;

    private Integer grpPositionId;
    private String grpPositionName;

    @Column(name = "is_active")
    private Boolean isActive;
    @Column(name = "is_delegation_mail")
    private Boolean isDelegationMail;
    @Column(name = "is_pending_mail_delegation")
    private Boolean isPendingMailDelegation;

    @Column(name = "delegation_id")
    private Long delegationId;
    @Column(name = "delegator_id")
    private Long delegatorId;
    @Column(name = "delegator_username")
    private String delegatorUsername;

    @Column(name = "delegate_id")
    private Long delegateId;
    @Column(name = "delegate_username")
    private String delegateUsername;
}
