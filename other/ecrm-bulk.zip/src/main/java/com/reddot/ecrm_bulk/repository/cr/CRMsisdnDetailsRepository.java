package com.reddot.ecrm_bulk.repository.cr;

import com.reddot.ecrm_bulk.entity.cr.CRMsisdnDetailsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CRMsisdnDetailsRepository extends JpaRepository<CRMsisdnDetailsEntity, Long> {
    List<CRMsisdnDetailsEntity> findAllByChangeRequestMasterId(Long id);
    List<CRMsisdnDetailsEntity> findAllByChangeRequestMasterIdAndStatus(Long id, String status);
}
