package com.reddot.ecrm_bulk.entity.bulk;

import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;
import java.time.LocalDate;

@Entity
@Data
@Table(name = "BULK_FILE")
public class BulkFile {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "id_generator_bulk_file")
    @SequenceGenerator(name = "id_generator_bulk_file", initialValue = 1, allocationSize = 1)
    private Long id;

    private Boolean active;
    @Column(name = "COMPANY_ID")
    private Long companyId;
    @Column(name = "COMPANY_NAME")
    private String companyName;
    @Column(name = "CREATED_AT")
    private Long createdAt;
    @Column(name = "CREATED_AT_DT")
    private Timestamp createdAtDt;
    @Column(name = "CREATED_BY")
    private Long createdBy;
    @Column(name = "CREATED_BY_USERNAME")
    private String createdByUsername;
    @Column(name = "END_DATE")
    private LocalDate endDate;
    @Column(name = "FAILED_ROWS")
    private Integer failedRows;
    @Column(name = "FILE_EXTENSION_TYPE")
    private String fileExtensionType;
    @Column(name = "FILE_NAME")
    private String fileName;
    @Column(name = "FILE_PATH")
    private String filePath;
    @Column(name = "FILE_SERVERIP")
    private String fileServerIP;
    @Column(name = "FILE_SIZE")
    private Long fileSize;
    @Column(name = "IS_RUN")
    private Boolean isRun;
    @Column(name = "PROCESS_STATUS")
    private String processStatus;
    @Column(name = "PROCESS_TYPE_ID")
    private Integer processTypeId;
    @Column(name = "PROCESS_TYPE_NAME")
    private String processTypeName;
    @Column(name = "REMARKS")
    private String remarks;
    @Column(name = "SCHEDULE_TIME")
    private LocalDate scheduleTime;
    @Column(name = "START_DATE")
    private LocalDate startDate;
    @Column(name = "SUCCESS_ROWS")
    private Integer successRows;
    @Column(name = "TOTAL_COLUMNS")
    private Integer totalColumns;
    @Column(name = "TOTAL_ROWS")
    private Integer totalRows;
    @Column(name = "UPDATED_AT")
    private Long updatedAt;
    @Column(name = "UPDATED_AT_DT")
    private Timestamp updatedAtDt;
    @Column(name = "UPDATED_BY")
    private Long updatedBy;
    @Column(name = "UPDATED_BY_USERNAME")
    private String updatedByUsername;
    @Column(name = "UUID_TOKEN")
    private String uuidToken;
}
