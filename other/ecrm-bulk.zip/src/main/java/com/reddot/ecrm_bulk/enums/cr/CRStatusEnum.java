package com.reddot.ecrm_bulk.enums.cr;

public enum CRStatusEnum {
    Pending,
    Rejected,
    Created,
    InProgress,
    Processing,
    Activate,
    Failed,
    Open,
    Success,
    Completed
}
/*

Pending---> if it has approval
Rejected---> if approval rejected
Created--->if no approval or has approval and accept all approver
Processing-->when api start to process, api will be success or failed
Activate--> if all api called successfully

 */
