package com.reddot.ecrm_bulk.entity.account_details;

import com.reddot.ecrm_bulk.entity.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.Email;
import java.time.LocalDateTime;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "TBL_ECRM_ACCOUNT_DETAILS")
public class Address extends AbstractEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "id_generator_account_details")
    @SequenceGenerator(name = "id_generator_account_details", initialValue = 1, allocationSize = 1)
    private Long id;

    @Column(name = "CONTRACT_NUMBER")
    private String contractNumber;
    private Long contractId;
    private Long opportunityId;
    @Column(name = "OPPORTUNITY_NUMBER")
    private String opportunityNumber;

    @Column(name = "PRODUCT_OF_INTEREST")
    private String productOfInterest;

    @Column(name = "latitude")
    private String latitude;

    @Column(name = "longitude")
    private String longitude;

    @Column(name = "LOCATION")
    private String location;

    @Column(name = "VAT_ID")
    private String vatId;

    @Column(name = "FOLLOW_UP_DATE")
    private LocalDateTime followUpDate;

    @Column(name = "CURRENT_PRODUCT")
    private String currentProduct;

    @Column(name = "CURRENT_EXPIRY_DATE")
    private LocalDateTime currentExpiryDate;

    @Column(name = "NUMBER_OF_LINE")
    private String numberOfLine;

    @Column(name = "MONTHLY_FEE")
    private String monthlyFee;

    @Column(name = "CONTRACT_DURATION")
    private String contractDuration;

    @Column(name = "ESTIMATED_REVENUE")
    private String estimatedRevenue;

    @Column(name = "DISCOUNT")
    private String discount;

    @Column(name = "PHONE_NUMBER")
    private String phoneNumber;

    @Email
    @Column(name = "EMAIL_ADDRESS")
    private String emailAddress;

    @Column(name = "is_Deposit")
    private Boolean isDeposit;

    @Column(name = "HAS_GUARANTEE_LETTER")
    private Boolean hasGuaranteeLetter;

    @Column(name = "HAS_WAIVER")
    private Boolean hasWaiver;

    @Column(name = "has_Pre_Payment")
    private Boolean hasPrePayment;

    @Column(name = "MOC_REGISTRATION_DATE")
    private LocalDateTime mocRegistrationDate;

    @Column(name = "MOC_NUMBER")
    private String mocNumber;

    @Column(name = "BILL_TYPE")
    private String billType;

    @Column(name = "SPECIAL_OFFER")
    private Double specialOffer;

    @Column(name = "DEPOSIT_AMOUNT")
    private Double depositAmount;

    @Column(name = "FINANCIAL_ADJUSTMENT")
    private Double financialAdjustment;

    @Column(name = "REMARKS")
    private String remarks;

    @Column(name = "SUB_INDUSTRY")
    private String subIndustry;

    @Column(name = "INDUSTRY")
    private String industry;

    @Column(name = "NUMBER_OF_EMPLOYEE")
    private String numberOfEmployee;

    @Column(name = "SIZE_OF_ENTERPRISE")
    private String sizeOfEnterprise;

    @Column(name = "ANNUAL_REVENUE")
    private String annualRevenue;

    @Column(name = "ORIGIN_OF_ENTERPRISE")
    private String originOfEnterprise;

    @Column(name = "HOUSE_NUMBER")
    private String houseNumber;

    @Column(name = "STREET")
    private String street;

    @Column(name = "SANGKAT_COMMUNE")
    private String sangkatCommune;
    private String sangkatCommuneApiValue;

    @Column(name = "kHAN_DISTRICT")
    private String khanDistrict;
    private String khanDistrictApiValue;

    @Column(name = "CITY_PROVINCE")
    private String cityProvince;
    private String cityProvinceApiValue;

    @Column(name = "VILLAGE_GROUP")
    private String villageGroup;

    @Column(name = "POSTCODE")
    private String postcode;

    @Column(name = "COUNTRY")
    private String country;
    private String countryApiValue;

    @Column(name = "WEBSITE")
    private String website;

    @Column(name = "SPECIAL_EVENT")
    private String specialEvent;

    private String corporateType;
    private String corporateTypeApiValue;
    private String corporateTypeText;
    private String certificationType;
    private String certificationTypeApiValue;
    private String certificationTypeText;
}
