package com.reddot.ecrm_bulk.service.contact;

import com.reddot.ecrm_bulk.entity.contract.Contact;
import com.reddot.ecrm_bulk.repository.contact.ContactRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ContactServiceImpl implements ContactService {
    private final ContactRepository contactRepository;

    @Override
    public List<Contact> findByContractId(Long contractId) {
        try {
            List<Contact> contactList = contactRepository.findByContractId(contractId);

            if (CollectionUtils.isEmpty(contactList)) {
                throw new EmptyResultDataAccessException(1);
            }

            return contactList;
        } catch (Exception e) {
            if (e instanceof EmptyResultDataAccessException) {
                log.debug("Contact not found with contract id: {}", contractId);
            } else {
                log.error("Contract findByContractId Error: {}", e.getMessage(), e.getCause());
            }
            return null;
        }
    }
}
