package com.reddot.ecrm_bulk.dto.subscriber;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SubscriberDataDTO {
    private String id;
    private String msisdn;
    private String iccid;
    private String new_iccid;
    private String status;
    private String statusId;
    private String company_name;
    private String msisdn_account_code;
    private String effectiveMode;
    private String effectiveDate;
    private String cugGroup;
    private String oldCugGroup;
    private String newCugGroup;
    private Boolean autoActiveStatus;
    private Boolean emailNotification;
    private String process_type;
}
