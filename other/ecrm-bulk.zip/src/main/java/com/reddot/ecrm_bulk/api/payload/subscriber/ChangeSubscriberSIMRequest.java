package com.reddot.ecrm_bulk.api.payload.subscriber;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChangeSubscriberSIMRequest implements Serializable {
    private String transaction_id;

    private ChangeSubSIMReqMsg ChangeSubSIMReqMsg;

    @Data
    @AllArgsConstructor
    public static class ChangeSubSIMReqMsg implements Serializable {
        private String NewICCID;

        private String OldICCID;

        private String ReasonCode;
    }
}
