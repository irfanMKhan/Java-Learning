package com.reddot.ecrm_bulk.repository.apiLoggerRepo;

import com.reddot.ecrm_bulk.entity.apilogger.APILogger;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface APILoggerRepository extends JpaRepository<APILogger, Long>, JpaSpecificationExecutor<APILogger> {
    @Query(value = "SELECT distinct a.status from APILogger a")
    List<String> findDistinctByStatus();
    @Query(value = "SELECT distinct a.featureName, a.featureId from APILogger a")
    List<Object> findDistinctByFeatureIdAndFeatureName();
}