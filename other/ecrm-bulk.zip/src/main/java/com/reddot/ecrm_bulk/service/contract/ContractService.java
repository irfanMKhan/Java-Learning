package com.reddot.ecrm_bulk.service.contract;

import com.reddot.ecrm_bulk.api.payload.customer.CBSBCCustomerResponse;
import com.reddot.ecrm_bulk.api.payload.group.ChangeCorporateGroupMemberInfoResponse;
import com.reddot.ecrm_bulk.api.payload.subscriber.SubscriberInfoResponse;
import com.reddot.ecrm_bulk.entity.account_details.Address;
import com.reddot.ecrm_bulk.entity.annex.Annex;
import com.reddot.ecrm_bulk.entity.contract.Contact;
import com.reddot.ecrm_bulk.entity.contract.Contract;
import com.reddot.ecrm_bulk.entity.primary_offering.PrimaryOffering;

import java.io.UnsupportedEncodingException;
import java.util.List;

public interface ContractService {
    List<Contract> findAll();
    Boolean isDebitNoteClosed(String extTransId);
    CBSBCCustomerResponse cbsbcCustomer(String msisdn);
    Boolean prepaidToPostpaid(String custId, String birthDay, Contract contract, Annex annex, List<Contact> contactList, Address address);

    Boolean changeAccountCreditLimit(String acctId, Annex annex);

    Boolean createOrder(Contract contract, Annex annex, PrimaryOffering primaryOffering, List<Contact> contactList, Address address) throws UnsupportedEncodingException;

    Boolean changeSupplementaryOffering(Annex annex, List<String> existingOfferingList) throws UnsupportedEncodingException;

    Boolean addSupplementaryOffering(Annex annex);

    Boolean changeAccountInformation(String accountId, Contract contract, Annex annex, Address address);

    List<String> queryPurchasedSupplementaryOffering(String msisdn) throws UnsupportedEncodingException;

    ChangeCorporateGroupMemberInfoResponse changeCorporateGroupMemberInfo(String customerId, String groupId, String serviceNumber, String departmentName, String departmentId);
    Boolean addGroupCUG(Contract contract, Annex annex, String groupCode);
    SubscriberInfoResponse getSubscriberInfo(String msisdn);
    Boolean addCorporateGroup(String customerId, String groupId, String serviceNumber, String departmentName, String departmentId);
}
