package com.reddot.ecrm_bulk.service.swapsim;

import com.google.gson.Gson;
import com.reddot.ecrm_bulk.api.gateway.SubscriberGateway;
import com.reddot.ecrm_bulk.dto.SwapSim.SwapSimDTO;
import com.reddot.ecrm_bulk.dto.common.HttpServletRequestDto;
import com.reddot.ecrm_bulk.entity.apilogger.APILogger;
import com.reddot.ecrm_bulk.entity.approval.ApprovalFlowEntity;
import com.reddot.ecrm_bulk.entity.approval.ApprovalRequestEntity;
import com.reddot.ecrm_bulk.entity.bulk.BulkUploadFileDetailsEntity;
import com.reddot.ecrm_bulk.entity.company.Company;
import com.reddot.ecrm_bulk.entity.msisdn.MSISDN;
import com.reddot.ecrm_bulk.entity.statement_note.StatementNoteEntity;
import com.reddot.ecrm_bulk.entity.swapsim.SwapSim;
import com.reddot.ecrm_bulk.enums.approval.ApprovalEnum;
import com.reddot.ecrm_bulk.enums.approval.ApprovalForEnum;
import com.reddot.ecrm_bulk.enums.requestType.CommonStatusEnum;
import com.reddot.ecrm_bulk.enums.requestType.PrimaryTableNameEnum;
import com.reddot.ecrm_bulk.enums.requestType.RequestTypeEnum;
import com.reddot.ecrm_bulk.enums.status.Status;
import com.reddot.ecrm_bulk.repository.apiLoggerRepo.APILoggerRepository;
import com.reddot.ecrm_bulk.repository.approval.ApprovalFlowRepo;
import com.reddot.ecrm_bulk.repository.company.CompanyRepository;
import com.reddot.ecrm_bulk.repository.statement.StatementNoteRepository;
import com.reddot.ecrm_bulk.repository.swap.SwapSimRepository;
import com.reddot.ecrm_bulk.service.approval.ApprovalRequestService;
import com.reddot.ecrm_bulk.service.company.MSISDNService;
import com.reddot.ecrm_bulk.util.SingletonTransactionNumberGenerator;
import com.reddot.ecrm_bulk.util.UniqueIDGenerator;
import com.reddot.ecrm_bulk.util.Utility;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class SwapSimService {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    private final CompanyRepository companyRepository;
    private final SubscriberGateway subscriberGateway;
    private final SwapSimRepository swapSimRepository;
    private final MSISDNService msisdnService;
    private final ApprovalFlowRepo approvalFlowRepo;
    private final ApprovalRequestService approvalRequestService;

    private final Gson gson;
    private final StatementNoteRepository statementNoteRepository;
    private final APILoggerRepository apiLoggerRepository;

    @Value("${swap.file.transfer.location}")
    String uploadDirectory;


    public String swap(SwapSimDTO swapSimDTO, BulkUploadFileDetailsEntity bulkUploadFileDetailsEntity) {
        SwapSim swapSim = swapSimDTOMappingToSwapSimEntity(swapSimDTO, bulkUploadFileDetailsEntity);
        HttpServletRequestDto requestDto = CreateHttpServletDTO(bulkUploadFileDetailsEntity, swapSimDTO);
        try {
            saveStatementNote(swapSim, requestDto);
            swapSim.setStatus(Status.Submitted.toString());
            swapSimRepository.saveAndFlush(swapSim);

            String transactionId = UniqueIDGenerator.getNextUniqueNumberOnly();
            checkApprovalFA(swapSim, requestDto, transactionId);
            ApprovalCheckForPTP(swapSim, requestDto, transactionId);

            //If we need later to
            /*Optional<MSISDN> msisdnEntity = Optional.ofNullable(msisdnService.findByMSISDN(swapSimDTO.getOldMsisdn()));
            if (swapSim.getStatus().equals(Status.Submitted.toString())) {
                //swapSimApiCall(swapSim, requestDto, msisdnEntity);
            }*/

            return Status.Success.toString();
        } catch (Exception e) {
            logger.error(String.format("SwapSimService:swap() Error: %s", e.getMessage()));
            e.printStackTrace();
            swapSim.setStatus(Status.Failed.toString());
            swapSim.setError(String.format("SwapSimService:swap() Error: %s", e.getMessage()));
            SwapSim savedSwapSim = swapSimRepository.save(swapSim);
            //commonService.saveApiLog(RequestTypeEnum.SWAP_SIM.getKey(), RequestTypeEnum.SWAP_SIM.getValue(), swapSim.getTransactionId(), null, null, null, swapSim.getApiRequest(), swapSim.getApiResponse(), null, null, null, savedSwapSim.getId(), PrimaryTableNameEnum.SWAP_SIM.getKey(), null, null, null);
            return Status.Failed.toString();
        }
        //return null;
    }

    public String uniqueNumberGenerate() {
        return SingletonTransactionNumberGenerator.getNextTransactionNumber();
    }

    public SwapSim swapSimDTOMappingToSwapSimEntity(SwapSimDTO swapSimDTO, BulkUploadFileDetailsEntity entity) {
        String uniqueNumber = uniqueNumberGenerate();

        SwapSim swapSim = new SwapSim();
        swapSim.setTransactionId(uniqueNumber);
        swapSim.setCompanyId(swapSimDTO.getCompanyId());
        swapSim.setCompanyName(swapSimDTO.getCompanyName());
        swapSim.setAccountCode(swapSimDTO.getAccountCode());

        swapSim.setNewIccId(swapSimDTO.getNewIccId());
        swapSim.setDate(LocalDate.now());

        //swapSim.setDate(LocalDate.parse(swapSimDTO.getDate()));
        swapSim.setOldIccId(swapSimDTO.getOldIccId());
        swapSim.setNewMsisdn(swapSimDTO.getNewMsisdn());
        swapSim.setOldMsisdn(swapSimDTO.getOldMsisdn());
        swapSim.setSwapType(swapSimDTO.getSwapType());
        swapSim.setDiscount(swapSimDTO.getDiscount());
        swapSim.setServiceCharge(swapSimDTO.getServiceCharge());
        swapSim.setUpfrontFee(swapSimDTO.getUpfrontFee());
        swapSim.setEffectiveMode(swapSimDTO.getEffectiveMode());
        swapSim.setEmailNotification(swapSimDTO.getEmailNotification());
        swapSim.setRequestForPtoP(swapSimDTO.getRequestForPtoP());
        swapSim.setRemarks(swapSimDTO.getRemarks());
        swapSim.setPtp(swapSimDTO.getPtp());
        swapSim.setEmail(swapSimDTO.getEmail());

        swapSim.setFinancialType(swapSimDTO.getFinancialType());
        swapSim.setFinancialTypeText(swapSimDTO.getFinancialTypeText());
        swapSim.setFinalCost(swapSimDTO.getFinalCost());
        swapSim.setPtpDate(swapSimDTO.getPtpDate());
        swapSim.setPtpDays(swapSimDTO.getPtpDays());
        swapSim.setFinancialTypeAmount(swapSimDTO.getFinancialTypeAmount());

        swapSim.setCreatedAt(System.currentTimeMillis());
        swapSim.setUpdatedAt(System.currentTimeMillis());
        swapSim.setCreatedBy(entity.getCreatedBy());
        swapSim.setUpdatedBy(entity.getCreatedBy());
        swapSim.setCreatedAtDt(new Timestamp(LocalDateTime.now().getDayOfYear()));
        swapSim.setUpdatedAtDt(new Timestamp(LocalDateTime.now().getDayOfYear()));
        return swapSim;
    }

    public Boolean saveStatementNote(SwapSim swapSim, HttpServletRequestDto request) {
        try {
            Company company = companyRepository.findByIdAndActive(swapSim.getCompanyId(), true);
            //statement note Data save
            StatementNoteEntity statementNoteEntity = new StatementNoteEntity();
            statementNoteEntity.setIsIndividual(true);
            statementNoteEntity.setAmount(swapSim.getFinalCost());
            statementNoteEntity.setUnitPrice(swapSim.getFinalCost());
            statementNoteEntity.setCompanyId(swapSim.getCompanyId());
            statementNoteEntity.setCompanyName(company.getName());
            statementNoteEntity.setQuantity(1);
            statementNoteEntity.setPurpose("Swap Sim for MSISDN: " + swapSim.getOldMsisdn() + ",Service Charge: " + swapSim.getServiceCharge() + ", Discount: " + swapSim.getFinancialTypeAmount() + ", Discount Type: " + swapSim.getFinancialTypeText());

            statementNoteEntity.setIndivisualTransactionId(swapSim.getTransactionId());
            statementNoteEntity.setTransactionId(swapSim.getTransactionId());
            //statementNoteEntity.setApiAccountKeyCode(1);
            statementNoteEntity.setFeatureId(Long.valueOf(RequestTypeEnum.SWAP_SIM.getValue()));
            statementNoteEntity.setFeatureName(RequestTypeEnum.SWAP_SIM.getKey());
            statementNoteEntity.setStatus(CommonStatusEnum.TODO.toString());
            statementNoteEntity.setPrimaryTableId(swapSim.getId());
            statementNoteEntity.setPrimaryTableName(PrimaryTableNameEnum.SWAP_SIM.getKey());
            Timestamp dateTime = new Timestamp(Utility.loggedInCurrentTime());

            statementNoteEntity.setProcessAtDt(dateTime);
            statementNoteEntity.setProcessAt(System.currentTimeMillis());

            statementNoteEntity.setCreatedBy(request.getCreatedBy());
            statementNoteEntity.setCreatedUsername(request.getCreatedUsername());
            statementNoteEntity.setCreatedAtDt(dateTime);
            statementNoteEntity.setCreatedAt(Utility.getCurrentTimestamp());

            statementNoteRepository.saveAndFlush(statementNoteEntity);
        } catch (Exception ex) {
            logger.error(String.format("SwapSimService:saveStatementNote() Error: %s", ex.getMessage()));
            ex.printStackTrace();
            swapSim.setStatus(CommonStatusEnum.Failed.toString());
            swapSim.setError(String.format("SwapSimService:saveStatementNote() Error: %s", ex.getMessage()));
            swapSimRepository.save(swapSim);
            saveApiLog(RequestTypeEnum.SWAP_SIM.getKey(), RequestTypeEnum.SWAP_SIM.getValue(), swapSim.getTransactionId(), null, null, null, swapSim.getApiRequestForDebitNote(), swapSim.getApiResponseForDebitNote(), null, null, null, swapSim.getId(), PrimaryTableNameEnum.SWAP_SIM.getKey(), null, null, null);
            return false;
        }
        return true;
    }


    public HttpServletRequestDto CreateHttpServletDTO(BulkUploadFileDetailsEntity bulkUploadFileDetailsEntity, SwapSimDTO swapSimDTO) {
        HttpServletRequestDto httpServletRequestDto = new HttpServletRequestDto();
        String userName = bulkUploadFileDetailsEntity.getCreatedByUsername();
        Long userId = bulkUploadFileDetailsEntity.getCreatedBy();
        Timestamp dateTime = new Timestamp(Utility.loggedInCurrentTime());
        httpServletRequestDto.setUpdatedAtDt(dateTime);
        httpServletRequestDto.setUpdatedBy(userId);
        httpServletRequestDto.setUpdatedUsername(userName);
        httpServletRequestDto.setCreatedUsername(userName);
        httpServletRequestDto.setCreatedBy(userId);
        httpServletRequestDto.setUpdatedAt(Utility.loggedInCurrentTime());
        httpServletRequestDto.setCreatedAt(Utility.loggedInCurrentTime());
        httpServletRequestDto.setCreatedAtDt(dateTime);
        httpServletRequestDto.setTenantId(swapSimDTO.getTenant_id());

        /*httpServletRequestDto.setSessionId(request.getRequestedSessionId());
        httpServletRequestDto.setMdUserModel(Utility.getLoggedInUserDetails(request));*/


        return httpServletRequestDto;
    }

    private void checkApprovalFA(SwapSim swapSim, HttpServletRequestDto httpServletRequest, String transactionId) {
        Boolean HasApproval = false;

        Long tenantId = httpServletRequest.getTenantId();
        try {
            ApprovalRequestEntity approvalRequestEntity = new ApprovalRequestEntity();
            Optional<ApprovalFlowEntity> approvalFlowEntity = approvalFlowRepo.findByNameAndTenantId(ApprovalEnum.FINANCIAL_ADJUSTMENT.getKey(),
                    tenantId);
            if (approvalFlowEntity.isPresent()) {
                approvalRequestEntity.setApprovalFlowId(approvalFlowEntity.get().getId());
                approvalRequestEntity.setApprovalFlowName(ApprovalEnum.FINANCIAL_ADJUSTMENT.getKey());
                approvalRequestEntity.setHasRequestedAmount(true);
                approvalRequestEntity.setApprovalFor(ApprovalForEnum.FINANCIAL_ADJUSTMENT_Swap_Sim.getKey());
                approvalRequestEntity.setIsCategoryType(false);
                approvalRequestEntity.setTransactionNumber(swapSim.getTransactionId());
                approvalRequestEntity.setRequestDetailsId(swapSim.getId());
                approvalRequestEntity.setRequestTransactionId(transactionId);
                approvalRequestEntity.setCompanyName(swapSim.getCompanyName());

                //swap sim did not have any parameter of company name//todo: need to add companyName in entity and get from ui
                //CompanyEntity company = companyRepository.findByIdAndActive(swapSim.getId(), true);
                //if (company != null) {
                approvalRequestEntity.setCompanyName(swapSim.getCompanyName());
                //}


                String description = "";

                Double financialAdjustmentAmount = swapSim.getServiceCharge() - swapSim.getFinalCost();
                approvalRequestEntity.setRequestedAmount(financialAdjustmentAmount);
                description = "Financial Adjustment";
                approvalRequestEntity.setRequestDescription(description);
                HasApproval = (Boolean) approvalRequestService.addRequestData(approvalRequestEntity, httpServletRequest).getData();

                if (HasApproval) {
                    swapSim.setStatus(Status.Pending.toString());
                    swapSimRepository.saveAndFlush(swapSim);
                }

            } else {
                logger.info("%s Approval Flow not exists.", ApprovalEnum.FINANCIAL_ADJUSTMENT.getKey());
            }

        } catch (Exception e) {
            logger.error(String.format("SwapSimService:checkApprovalFA() Error: %s", e.getMessage()));
        }
    }

    public void saveApiLog(String featureName, Integer featureId, String uniqueTransaction,
                           Integer stepNumber, String stepDescription, String request,
                           String response, String requestParameter,
                           Timestamp requestTime, Timestamp responseTime, Long elapsedTime,
                           Long primaryId, String tableName, String remoteAddress,
                           Integer responseStatus, String status) {
        try {
            APILogger apiLogger = new APILogger();
            apiLogger.setFeatureName(featureName);
            apiLogger.setFeatureId(Long.valueOf(featureId));
            apiLogger.setTransaction(uniqueTransaction);
            apiLogger.setStepNumber(stepNumber);
            apiLogger.setRequestBody(request);
            apiLogger.setResponse(response);
            apiLogger.setRequestTime(requestTime);
            apiLogger.setResponseTime(responseTime);
            apiLogger.setStatus(status);
            apiLogger.setStepDescription(stepDescription);
            apiLogger.setElapsedTime(elapsedTime);
            apiLogger.setPrimaryTableId(primaryId);
            apiLogger.setPrimaryTableName(tableName);
            apiLogger.setRemoteAddress(remoteAddress);
            apiLogger.setResponseStatus(responseStatus);
            apiLogger.setRequestParameters(requestParameter);

            apiLoggerRepository.saveAndFlush(apiLogger);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private Boolean ApprovalCheckForPTP(SwapSim swapSim, HttpServletRequestDto request, String transactionId) {
        Boolean HasApproval = false;
        Long tenantId = request.getTenantId();
        try {
            ApprovalRequestEntity approvalRequestEntity = new ApprovalRequestEntity();
            Optional<ApprovalFlowEntity> approvalFlowEntity = approvalFlowRepo.findByNameAndTenantId(ApprovalEnum.PTP_REQUEST.getKey(),
                    tenantId);
            if (approvalFlowEntity.isPresent()) {
                approvalRequestEntity.setApprovalFlowId(approvalFlowEntity.get().getId());
                approvalRequestEntity.setApprovalFlowName(ApprovalEnum.PTP_REQUEST.getKey());
                approvalRequestEntity.setHasRequestedAmount(false);
                approvalRequestEntity.setIsCategoryType(false);
                approvalRequestEntity.setApprovalFor(ApprovalForEnum.FINANCIAL_ADJUSTMENT_Swap_Sim.getKey());
                approvalRequestEntity.setTransactionNumber(swapSim.getTransactionId());
                approvalRequestEntity.setRequestDetailsId(swapSim.getId());
                approvalRequestEntity.setRequestTransactionId(transactionId);
                approvalRequestEntity.setCompanyName(swapSim.getCompanyName());

                String description = "PTP Requested: ";
                //  List<Long> IdList = new ArrayList<>();
                Boolean HasPTPApproval = false;
                Integer maxTotalDays = 0;

                if (!ObjectUtils.isEmpty(swapSim.getPtpDays()) && swapSim.getPtpDays() > 14) {
                    HasPTPApproval = true;
                    description = description + " PTP days: " + swapSim.getPtpDays() +
                            "and PTP date: " + swapSim.getPtpDate() + ",";
                    maxTotalDays = swapSim.getPtpDays();
                    // IdList.add(swapSim.getId());
                }

                if (HasPTPApproval) {
//                    updateApprovalStatus(ApprovalTableColumnNameEnum.Contract_Product_Table_PTP_Column.getTableName(),
//                            ApprovalTableColumnNameEnum.Contract_Product_Table_PTP_Column.getColumnName(),
//                            IdList
//                    );

                    if (!description.isEmpty()) {
                        char[] descriptionChars = description.toCharArray();
                        descriptionChars[descriptionChars.length - 1] = '.';
                        description = new String(descriptionChars);
                    }
                    approvalRequestEntity.setRequestDescription(description);
                    approvalRequestEntity.setRequestedNumberTypeData(maxTotalDays);
                    approvalRequestEntity.setUnitType(approvalFlowEntity.get().getUnit());
                    approvalRequestEntity.setUnitType(approvalFlowEntity.get().getUnit());
                    HasApproval = (Boolean) approvalRequestService.addRequestData(approvalRequestEntity, request).getData();
                }

            } else {
                logger.warn("%s Approval Flow not exists.", ApprovalEnum.PTP_REQUEST.getKey());
            }

        } catch (Exception e) {
            logger.error(String.format("SwapSimService:ApprovalCheckForPTP() Error: %s", e.getMessage()));
        }
        return HasApproval;
    }

}
