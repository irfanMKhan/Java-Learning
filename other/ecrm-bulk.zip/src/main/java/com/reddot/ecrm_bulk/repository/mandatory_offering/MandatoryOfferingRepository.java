package com.reddot.ecrm_bulk.repository.mandatory_offering;

import com.reddot.ecrm_bulk.entity.mandatory_offering.MandatoryOfferingEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MandatoryOfferingRepository extends JpaRepository<MandatoryOfferingEntity, Long> {
    List<MandatoryOfferingEntity> findAllByActive(Boolean isActive);

    List<MandatoryOfferingEntity> findAllByActiveIsTrue();
}
