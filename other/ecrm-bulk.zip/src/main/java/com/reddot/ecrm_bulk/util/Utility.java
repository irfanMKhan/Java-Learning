package com.reddot.ecrm_bulk.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.gson.Gson;
import com.ibm.icu.text.RuleBasedNumberFormat;
import com.ibm.icu.util.CurrencyAmount;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Currency;
import java.util.Date;
import java.util.Locale;

@Service
@Slf4j
public class Utility {
    public static String md_user = "MD_USER";
    public static String delegation_table = "delegations_details";

    public static String translate(String ctryCd, String lang, String reqStr, String fractionUnitName) {
        StringBuffer result = new StringBuffer();

        Locale locale = new Locale(lang, ctryCd);
        Currency crncy = Currency.getInstance(locale);

        String[] inputArr = StringUtils.split(new BigDecimal(reqStr).abs().toPlainString(), ".");
        RuleBasedNumberFormat rule = new RuleBasedNumberFormat(locale, RuleBasedNumberFormat.SPELLOUT);

        int i = 0;
        for (String input : inputArr) {
            CurrencyAmount crncyAmt = new CurrencyAmount(new BigDecimal(input), crncy);
            if (i++ == 0) {
                result.append(rule.format(crncyAmt)).append(" " + crncy.getDisplayName() + " and ");
            } else {
                result.append(rule.format(crncyAmt)).append(" " + fractionUnitName + " ");
            }
        }
        return result.toString();
    }

    public static String getUniqueNumber() {
        LocalDateTime now = LocalDateTime.now();

        // Format the date and time as a string
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");
        String formattedDateTime = now.format(formatter);

        // Generate the atomic number by appending a random number
        int random = (int) (Math.random() * 1000); // Change the range as needed
        String atomicNumber = formattedDateTime + String.format("%03d", random);
        return atomicNumber;
    }

    public static Long loggedInCurrentTime() {
        return System.currentTimeMillis();
    }

    public static String ObjectToJson(Object i) {
        Gson gson = new Gson();
        String json = "";
        try {
            json = gson.toJson(i);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }

        return json;
    }

    public static long getCurrentTimestamp() {
        Date date = new Date();
        long time = date.getTime();
        return time;
    }

    public static String EntityObjectToJsonConvertGson(Object object) {
        Gson gson = new Gson();
        try {
            String jsonDataInString = gson.toJson(object);
            log.info(jsonDataInString);
            return jsonDataInString;
        } catch (Exception e) {
            return EntityObjectToJsonConvert(object);
        }
    }

    public static String EntityObjectToJsonConvert(Object object) {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        try {
            String jsonDataInString = objectMapper.writeValueAsString(object);
            log.info(jsonDataInString);
            return jsonDataInString;
        } catch (Exception e) {
            System.out.printf("Utility:EntityObjectToJsonConvert() Error: %s", e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    public static String getTimeInFormatyyyyMMddHHmmss() {
        try {
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
            String dateTimeFormat = now.format(formatter);
            return dateTimeFormat;
        } catch (Exception e) {
            System.out.printf("Utility:getTimeInFormatyyyyMMddHHmmss() Error: %s%n", e.getMessage());
            return null;
        }
    }
    public static String getTransactionIdTimeIn_Date_T_Time_Format() {
        try {
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
            String transactionId = now.format(formatter);
            return transactionId;
        } catch (Exception e) {
            System.out.printf("Utility:getTransactionTimeInTFormat() Error: %s%n", e.getMessage());
            return null;
        }
    }

    public static String getTransactionNumber(String prefix) {
        String transactionId = prefix;
        try {
            transactionId = transactionId + SingletonTransactionNumberGenerator.getNextTransactionNumber();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return transactionId;
    }

}
