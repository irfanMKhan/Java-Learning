package com.reddot.ecrm_bulk.service.change_branch;

import com.google.common.collect.Lists;
import com.reddot.ecrm_bulk.entity.bulk.BulkFile;
import com.reddot.ecrm_bulk.entity.bulk.BulkFileDetails;
import com.reddot.ecrm_bulk.entity.company.CompanyAccount;
import com.reddot.ecrm_bulk.enums.status.Status;
import com.reddot.ecrm_bulk.service.bulk.BulkFileDetailsService;
import com.reddot.ecrm_bulk.service.bulk.BulkFileService;
import com.reddot.ecrm_bulk.service.company.CompanyAccountService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jobrunr.scheduling.JobScheduler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.time.LocalDate;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class ChangeBranchService {
    @Value("${batch.chunkSize}")
    private int chunkSize;
    private final BulkFileService bulkFileService;
    private final BulkFileDetailsService bulkFileDetailsService;
    private final JobScheduler jobScheduler;
    private final CompanyAccountService companyAccountService;
    private final BranchService branchService;

    // Bulk File List
    public void proceedExecution() {
        List<BulkFile> bulkFileList = bulkFileService.findAllTodosAndInProgressByIsRun(true);
        List<List<BulkFile>> result = Lists.partition(bulkFileList, chunkSize);

        // Update Listed Bulk Files Status InProgress
        bulkFileService.updateBulkFileStatus(result, Status.InProgress);

        for (List<BulkFile> bulkFiles: result) {
            for (BulkFile bulkFile: bulkFiles) {
                jobScheduler.enqueue(() -> this.proceedBulkFileExecution(bulkFile));
            }
        }
    }

    // Bulk File Details List
    public void proceedBulkFileExecution(BulkFile bulkFile) {
        // Update Check Complete Status
        branchService.updateBulkFileCompleteStatus(bulkFile);

        CompanyAccount parentCustomer = companyAccountService.findParentCustomerByAccountName(bulkFile.getCompanyName());
        List<BulkFileDetails> bulkFileDetailsList = bulkFileDetailsService.findByBulkFileIdAndStatus(bulkFile.getId(), Status.TODO);

        List<List<BulkFileDetails>> result = Lists.partition(bulkFileDetailsList, chunkSize);

        for (List<BulkFileDetails> bulkFileDetails: result) {
            for (BulkFileDetails fileDetails : bulkFileDetails) {
                jobScheduler.enqueue(() -> proceedBulkFileDetailsExecution(parentCustomer.getAccountId(), bulkFile, fileDetails));
            }
        }
    }

    // Proceed
    public void proceedBulkFileDetailsExecution(String customerId, BulkFile bulkFile, BulkFileDetails bulkFileDetails) {
        if (todayIsScheduleDate(bulkFile)) {
            branchService.executeChangeBranch(customerId, bulkFile, bulkFileDetails);
        }
    }

    public Boolean todayIsScheduleDate(BulkFile bulkFile) {
        if (ObjectUtils.isEmpty(bulkFile.getScheduleTime())) {
            return true;
        }

        LocalDate parsedStringDate = bulkFile.getScheduleTime();
        LocalDate currentDate = LocalDate.now();

        return parsedStringDate.compareTo(currentDate) == 0;
    }
}
