package com.reddot.ecrm_bulk.entity.contract;

import com.reddot.ecrm_bulk.entity.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "TBL_ECRM_CONTRACT_BILL_MEDIUM")
public class BillMedium extends AbstractEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long companyId;
    private String companyName;
    private Long contractId;
    private String serviceTypeName;
    private String billMediumId;
    private Integer billMediumCodeValue;
    private String billMediumCodeType;
    private Integer billContentTypeValue;
    private String billContentType;
    private String billMediumInfo;
    private Boolean active;
    private Long crMasterId;
}
