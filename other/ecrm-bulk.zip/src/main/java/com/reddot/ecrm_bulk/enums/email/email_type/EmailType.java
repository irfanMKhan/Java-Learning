package com.reddot.ecrm_bulk.enums.email.email_type;

public enum EmailType {
    Notification_Mail,
    Approval_Mail,
    Report_Mail
}
