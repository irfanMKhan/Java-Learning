package com.reddot.ecrm_bulk.service.cdr;

import com.reddot.ecrm_bulk.api.payload.CDR.response.CDRAPIResponseDataDTO;
import com.reddot.ecrm_bulk.bulkFileDTO.CDRReportingDataDTO;
import lombok.RequiredArgsConstructor;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class CDRReportingService {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Value("${CDR.dataSourceLocation}")
    String dataSourceLocation;
    @Value("${smart.reports.template}")
    String reportingTemplate;

    private static Map<String, Object> getParameters(CDRReportingDataDTO data) {
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("fromDate", data.getFromDate());
        parameters.put("toDate", data.getToDate());
        parameters.put("printDate", data.getPrintDate());
        parameters.put("accountNumber", data.getAccountNumber());
        parameters.put("address", data.getAddress());
        parameters.put("image", data.getImage());
        return parameters;
    }

    private InputStream convertResourceToInputStream(String path) {
        Resource resource = new ClassPathResource(path);
        InputStream imageData = null;
        try {
            //imageData = new byte[resource.getInputStream().read()];
            imageData = resource.getInputStream();

        } catch (IOException e) {
            e.printStackTrace();
            logger.error("CDRReportingService: convertResourceToInputStream:{0} " + e.getMessage());
        }
        return imageData;
    }
    public void generateCDRReport( CDRReportingDataDTO cdrReportingDataDTO) throws JRException {
        cdrReportingDataDTO.setImage("reports/images/header.png");
        InputStream topImg = convertResourceToInputStream(cdrReportingDataDTO.getImage());
        try {

            File resource = new File(reportingTemplate+"CDR.jrxml");
            InputStream inputStream = new FileInputStream(resource);

            JasperReport jasperReport = JasperCompileManager.compileReport(inputStream);
            Map<String, Object> parameters = getParameters(cdrReportingDataDTO);
            // Including the images
            parameters.put("image", topImg);
            String fileName = "CDR-" + cdrReportingDataDTO.getAccountNumber() + "-" + cdrReportingDataDTO.getPrintDate()+"-"+cdrReportingDataDTO.getDetailTableId();
            List<CDRAPIResponseDataDTO> table_details = cdrReportingDataDTO.getDataList();//getData();
            JRBeanCollectionDataSource collectionBeanParam = new JRBeanCollectionDataSource(table_details);
            parameters.put("collectionBeanParam", collectionBeanParam);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, new JREmptyDataSource());

            if (cdrReportingDataDTO.getFileType().equalsIgnoreCase("PDF")) {
                logger.info("CDRService: download:generateCDRReport Call Start in PDF method........" );

                //for pdf report
                JRPdfExporter exporter = new JRPdfExporter();
                exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
                exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(dataSourceLocation+fileName+"-"+cdrReportingDataDTO.getToken()+".pdf"));
                logger.info("CDRService: download:generateCDRReport Call Start in PDF generate start........" );
                exporter.exportReport();
            }
            if (cdrReportingDataDTO.getFileType().equalsIgnoreCase("EXCEL")) {
                JRXlsxExporter excelExporter = new JRXlsxExporter();
                SimpleXlsxReportConfiguration reportConfigXLS = new SimpleXlsxReportConfiguration();
                reportConfigXLS.setSheetNames(new String[]{"CDR"});
                reportConfigXLS.setDetectCellType(true);
                reportConfigXLS.setCollapseRowSpan(false);
                excelExporter.setConfiguration(reportConfigXLS);
                excelExporter.setExporterInput(new SimpleExporterInput(jasperPrint));
                excelExporter.setExporterOutput(new SimpleOutputStreamExporterOutput(dataSourceLocation+fileName+"-"+cdrReportingDataDTO.getToken()+ ".xlsx"));
                excelExporter.exportReport();

            }

        } catch (IOException e) {
            e.printStackTrace();
            logger.error("CDRReportingService: generateCDRReport:{0} " + e.getMessage());
        }

    }





}
