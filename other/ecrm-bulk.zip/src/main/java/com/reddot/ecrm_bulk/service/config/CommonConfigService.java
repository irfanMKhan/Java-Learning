package com.reddot.ecrm_bulk.service.config;

public interface CommonConfigService {
    String findNameByIdAndTypeNameAndSubTypeName(Long id, String typeName, String subTypeName);
}
