package com.reddot.ecrm_bulk.service.company;

import com.google.gson.Gson;
import com.reddot.ecrm_bulk.entity.annex.Annex;
import com.reddot.ecrm_bulk.entity.company.Company;
import com.reddot.ecrm_bulk.enums.service.ServiceType;
import com.reddot.ecrm_bulk.repository.company.CompanyRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

@Service
@Slf4j
@RequiredArgsConstructor

public class CompanyServiceImpl implements CompanyService {
    private final CompanyRepository companyRepository;
    private final Gson gson;

    @Override
    public Company findCompanyByName(String companyName) {
        try {
            return companyRepository.findByName(companyName);
        } catch (Exception e) {
            if (e instanceof EmptyResultDataAccessException) {
                log.debug("Company not found with name: {}", companyName);
                return null;
            }
            log.error("Find Company By Name Error: {} {}", e.getMessage(), e.getCause());
            return null;
        }
    }

    @Override
    public void updateCompany(Company company, Annex annex) {
        try {
            Double totalCreditCeiling = 0.0;
            Double totalCreditLimit = 0.0;

            Double monthlyFee = annex.getMonthlyFee();
            Double creditLimitDouble = annex.getTotalCredit();

            totalCreditLimit = creditLimitDouble;
            if (!annex.getServiceTypeName().equalsIgnoreCase(ServiceType.PBX.name())) {
                totalCreditCeiling = monthlyFee * 2;
            } else {
                totalCreditCeiling = monthlyFee; // TODO
            }


            if (!ObjectUtils.isEmpty(company.getCreditCeiling())) {
                totalCreditCeiling = company.getCreditCeiling() + totalCreditCeiling;
            }

            if (!ObjectUtils.isEmpty(company.getCreditLimit())) {
                totalCreditLimit = company.getCreditLimit() + totalCreditLimit;
            }

            company.setCreditCeiling(totalCreditCeiling);
            company.setCreditLimit(totalCreditLimit);

            Company updatedCompany = companyRepository.update(company);
            log.debug("Company: {}, Updated company entity: {}", company.getName(), gson.toJson(updatedCompany));
        } catch (Exception e) {
            log.error("Failed to update company: {} {}", company, e.getCause());
        }
    }

    public Company findCompanyById(Long companyId) {

        try {
            return companyRepository.findByIdAndActive(companyId, true);
        } catch (Exception e) {
            if (e instanceof EmptyResultDataAccessException) {
                log.debug("Company not found with id: {}", companyId);
                return null;
            }
            log.error("Find Company By id Error: {} {}", e.getMessage(), e.getCause());
            return null;
        }

    }

}
