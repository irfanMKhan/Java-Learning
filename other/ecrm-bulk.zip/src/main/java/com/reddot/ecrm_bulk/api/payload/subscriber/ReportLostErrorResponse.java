package com.reddot.ecrm_bulk.api.payload.subscriber;

import lombok.Data;

import java.io.Serializable;

@Data
public class ReportLostErrorResponse implements Serializable {
  private String variables;

  private Integer code;

  private String message;
}
