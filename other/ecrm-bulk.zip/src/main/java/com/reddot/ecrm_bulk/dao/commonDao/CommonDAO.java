package com.reddot.ecrm_bulk.dao.commonDao;


import org.slf4j.Logger;

import java.util.Map;


public interface CommonDAO {
    Object CommoPagination(String sql);

    Object CommoGetData(String sql);
    String CommoGetJsonData(String sql);

    public int CommoNumberOfRow(String sql);

    public boolean CommoInsert(String tbl, Map<String, Object> query, Logger logger);

    public boolean CommoUpdate(String tbl, Map<String, Object> setQry, Map<String, Object> whereQry, Logger logger);
    public boolean CommoUpdate(String qry, Logger logger);
    public boolean CommoInsertSQL(String qry, Logger logger);

    public boolean CommoDelete(String tbl, Map<String, Object> whereQry, Logger logger);

    public String getNextId(String sequenceName);

    String commonInsertGetReturn(String tbl, Map<String, Object> params, Logger logger, String returnColumn);
    boolean commonQuery(String query, Logger logger);
}
