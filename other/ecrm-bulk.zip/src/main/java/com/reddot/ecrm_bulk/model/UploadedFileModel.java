package com.reddot.ecrm_bulk.model;

import java.sql.Timestamp;

public class UploadedFileModel {
	private String ID,
			INSTITUTE_ID,
			ACADEMIC_YEAR_ID,
	   PROCESS_TYPE_NAME,
	   PROCESS_TYPE_ID,
	   CONNECTION_TYPE,
	   FILE_NAME,
	   FILE_PATH,
	   UPLOADED_SERVER_IP,
	   FILE_SIZE,
	   FILE_TYPE,
	   TOTAL_ROWS,
	   SUCCESS_ROWS,
	   FAILED_ROWS,
	   PROCESS_STATUS,
	   ACTIVE,
	   CREATED_BY,
	   CREATED_BY_USERNAME,
	   UPDATED_BY,
	   UPDATED_BY_USERNAME,
	   CREATED_AT,
	   UPDATED_AT,
	   CREATED_AT_DT,
	   UPDATED_AT_DT,
	   COMMENTS,
			IS_RUN;
	private Timestamp START_TIME_DT,END_TIME_DT;

	public String getINSTITUTE_ID() {
		return INSTITUTE_ID;
	}

	public void setINSTITUTE_ID(String INSTITUTE_ID) {
		this.INSTITUTE_ID = INSTITUTE_ID;
	}

	public String getACADEMIC_YEAR_ID() {
		return ACADEMIC_YEAR_ID;
	}

	public void setACADEMIC_YEAR_ID(String ACADEMIC_YEAR_ID) {
		this.ACADEMIC_YEAR_ID = ACADEMIC_YEAR_ID;
	}

	public Timestamp getSTART_TIME_DT() {
		return START_TIME_DT;
	}

	public void setSTART_TIME_DT(Timestamp START_TIME_DT) {
		this.START_TIME_DT = START_TIME_DT;
	}

	public Timestamp getEND_TIME_DT() {
		return END_TIME_DT;
	}

	public void setEND_TIME_DT(Timestamp END_TIME_DT) {
		this.END_TIME_DT = END_TIME_DT;
	}

	public String getIS_RUN() {
		return IS_RUN;
	}

	public void setIS_RUN(String IS_RUN) {
		this.IS_RUN = IS_RUN;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String getPROCESS_TYPE_NAME() {
		return PROCESS_TYPE_NAME;
	}

	public void setPROCESS_TYPE_NAME(String pROCESS_TYPE_NAME) {
		PROCESS_TYPE_NAME = pROCESS_TYPE_NAME;
	}

	public String getPROCESS_TYPE_ID() {
		return PROCESS_TYPE_ID;
	}

	public void setPROCESS_TYPE_ID(String pROCESS_TYPE_ID) {
		PROCESS_TYPE_ID = pROCESS_TYPE_ID;
	}

	public String getCONNECTION_TYPE() {
		return CONNECTION_TYPE;
	}

	public void setCONNECTION_TYPE(String cONNECTION_TYPE) {
		CONNECTION_TYPE = cONNECTION_TYPE;
	}

	public String getFILE_NAME() {
		return FILE_NAME;
	}

	public void setFILE_NAME(String fILE_NAME) {
		FILE_NAME = fILE_NAME;
	}

	public String getFILE_PATH() {
		return FILE_PATH;
	}

	public void setFILE_PATH(String fILE_PATH) {
		FILE_PATH = fILE_PATH;
	}

	public String getUPLOADED_SERVER_IP() {
		return UPLOADED_SERVER_IP;
	}

	public void setUPLOADED_SERVER_IP(String uPLOADED_SERVER_IP) {
		UPLOADED_SERVER_IP = uPLOADED_SERVER_IP;
	}

	public String getFILE_SIZE() {
		return FILE_SIZE;
	}

	public void setFILE_SIZE(String fILE_SIZE) {
		FILE_SIZE = fILE_SIZE;
	}

	public String getFILE_TYPE() {
		return FILE_TYPE;
	}

	public void setFILE_TYPE(String fILE_TYPE) {
		FILE_TYPE = fILE_TYPE;
	}

	public String getTOTAL_ROWS() {
		return TOTAL_ROWS;
	}

	public void setTOTAL_ROWS(String tOTAL_ROWS) {
		TOTAL_ROWS = tOTAL_ROWS;
	}

	public String getSUCCESS_ROWS() {
		return SUCCESS_ROWS;
	}

	public void setSUCCESS_ROWS(String sUCCESS_ROWS) {
		SUCCESS_ROWS = sUCCESS_ROWS;
	}

	public String getFAILED_ROWS() {
		return FAILED_ROWS;
	}

	public void setFAILED_ROWS(String fAILED_ROWS) {
		FAILED_ROWS = fAILED_ROWS;
	}

	public String getPROCESS_STATUS() {
		return PROCESS_STATUS;
	}

	public void setPROCESS_STATUS(String pROCESS_STATUS) {
		PROCESS_STATUS = pROCESS_STATUS;
	}

	public String getACTIVE() {
		return ACTIVE;
	}

	public void setACTIVE(String aCTIVE) {
		ACTIVE = aCTIVE;
	}

	public String getCREATED_BY() {
		return CREATED_BY;
	}

	public void setCREATED_BY(String cREATED_BY) {
		CREATED_BY = cREATED_BY;
	}

	public String getCREATED_BY_USERNAME() {
		return CREATED_BY_USERNAME;
	}

	public void setCREATED_BY_USERNAME(String cREATED_BY_USERNAME) {
		CREATED_BY_USERNAME = cREATED_BY_USERNAME;
	}

	public String getUPDATED_BY() {
		return UPDATED_BY;
	}

	public void setUPDATED_BY(String uPDATED_BY) {
		UPDATED_BY = uPDATED_BY;
	}

	public String getUPDATED_BY_USERNAME() {
		return UPDATED_BY_USERNAME;
	}

	public void setUPDATED_BY_USERNAME(String uPDATED_BY_USERNAME) {
		UPDATED_BY_USERNAME = uPDATED_BY_USERNAME;
	}

	public String getCREATED_AT() {
		return CREATED_AT;
	}

	public void setCREATED_AT(String cREATED_AT) {
		CREATED_AT = cREATED_AT;
	}

	public String getUPDATED_AT() {
		return UPDATED_AT;
	}

	public void setUPDATED_AT(String uPDATED_AT) {
		UPDATED_AT = uPDATED_AT;
	}

	public String getCREATED_AT_DT() {
		return CREATED_AT_DT;
	}

	public void setCREATED_AT_DT(String cREATED_AT_DT) {
		CREATED_AT_DT = cREATED_AT_DT;
	}

	public String getUPDATED_AT_DT() {
		return UPDATED_AT_DT;
	}

	public void setUPDATED_AT_DT(String uPDATED_AT_DT) {
		UPDATED_AT_DT = uPDATED_AT_DT;
	}

	public String getCOMMENTS() {
		return COMMENTS;
	}

	public void setCOMMENTS(String cOMMENTS) {
		COMMENTS = cOMMENTS;
	}
	
	
}
