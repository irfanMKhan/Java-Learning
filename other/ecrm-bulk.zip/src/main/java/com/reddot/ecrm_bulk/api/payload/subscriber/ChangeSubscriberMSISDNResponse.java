package com.reddot.ecrm_bulk.api.payload.subscriber;

import lombok.Data;

import java.io.Serializable;

@Data
public class ChangeSubscriberMSISDNResponse implements Serializable {
    private String transaction_id;

    private String code;

    private String message;
}
