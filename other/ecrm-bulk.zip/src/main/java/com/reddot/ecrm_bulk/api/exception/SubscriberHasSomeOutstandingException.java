package com.reddot.ecrm_bulk.api.exception;

public class SubscriberHasSomeOutstandingException extends RuntimeException {
    public SubscriberHasSomeOutstandingException(String message) {
        super(message);
    }

    public SubscriberHasSomeOutstandingException(String message, Throwable throwable) {
        super(message, throwable);
    }
}
