package com.reddot.ecrm_bulk.model;

public class FeeDetailModel {

    private String ID;
    private String PAYMENT_PERIOD_ID;
    private String PAYMENT_PERIOD_NAME;
    private String MONTH_ID;
    private String MONTH_NAME;
    private String AMOUNT;

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getPAYMENT_PERIOD_ID() {
        return PAYMENT_PERIOD_ID;
    }

    public void setPAYMENT_PERIOD_ID(String PAYMENT_PERIOD_ID) {
        this.PAYMENT_PERIOD_ID = PAYMENT_PERIOD_ID;
    }

    public String getPAYMENT_PERIOD_NAME() {
        return PAYMENT_PERIOD_NAME;
    }

    public void setPAYMENT_PERIOD_NAME(String PAYMENT_PERIOD_NAME) {
        this.PAYMENT_PERIOD_NAME = PAYMENT_PERIOD_NAME;
    }

    public String getMONTH_ID() {
        return MONTH_ID;
    }

    public void setMONTH_ID(String MONTH_ID) {
        this.MONTH_ID = MONTH_ID;
    }

    public String getMONTH_NAME() {
        return MONTH_NAME;
    }

    public void setMONTH_NAME(String MONTH_NAME) {
        this.MONTH_NAME = MONTH_NAME;
    }

    public String getAMOUNT() {
        return AMOUNT;
    }

    public void setAMOUNT(String AMOUNT) {
        this.AMOUNT = AMOUNT;
    }
}
