package com.reddot.ecrm_bulk.dto.bulk;

import lombok.Data;

@Data
public class ChangeBranchInfo {
    private String branchCode;
    private String branchName;
    private String msisdn;
}
