package com.reddot.ecrm_bulk.repository.cr;

import com.reddot.ecrm_bulk.entity.cr.CRMasterEntity;
import com.reddot.ecrm_bulk.enums.requestType.RequestTypeEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface CRMasterRepository extends JpaRepository<CRMasterEntity, Long> {
    List<CRMasterEntity> findAllByFinalStatusAndRequestTypeId(String finalStatus, Integer requestTypeId);

    @Transactional
    @Modifying
    @Query("UPDATE CRMasterEntity b SET b.finalStatus = :finalStatus WHERE b.id IN :ids")
    int update(@Param("ids") List<Long> ids, @Param("finalStatus") String finalStatus);
}
