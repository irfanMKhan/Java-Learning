package com.reddot.ecrm_bulk.service.change_branch;

import com.google.gson.Gson;
import com.reddot.ecrm_bulk.api.payload.group.ChangeCorporateGroupMemberInfoResponse;
import com.reddot.ecrm_bulk.dto.bulk.ChangeBranchInfo;
import com.reddot.ecrm_bulk.entity.bulk.BulkFile;
import com.reddot.ecrm_bulk.entity.bulk.BulkFileDetails;
import com.reddot.ecrm_bulk.enums.status.Status;
import com.reddot.ecrm_bulk.service.bulk.BulkFileDetailsService;
import com.reddot.ecrm_bulk.service.bulk.BulkFileService;
import com.reddot.ecrm_bulk.service.company.CompanyAccountService;
import com.reddot.ecrm_bulk.service.contract.ContractService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class BranchService {
    private final Gson gson;
    private final BulkFileService bulkFileService;
    private final BulkFileDetailsService bulkFileDetailsService;
    private final CompanyAccountService companyAccountService;
    private final ContractService contractService;

    public void updateBulkFileCompleteStatus(BulkFile bulkFile) {
        List<BulkFileDetails> bulkFileDetailsList = bulkFileDetailsService.findAllByBulkFileId(bulkFile.getId());
        List<BulkFileDetails> bulkFileDetailsListSuccess = bulkFileDetailsService.findByBulkFileIdAndStatus(bulkFile.getId(), Status.Success);

        if (bulkFileDetailsListSuccess.size() > 0 && bulkFileDetailsList.size() > 0 && bulkFileDetailsList.size() == bulkFileDetailsListSuccess.size()) {
            bulkFile.setProcessStatus(Status.Complete.name());
            bulkFileService.update(bulkFile);
        }
    }

    public void executeChangeBranch(String customerId, BulkFile bulkFile, BulkFileDetails bulkFileDetails) {
        ChangeBranchInfo changeBranchInfo = gson.fromJson(bulkFileDetails.getFileRowData(), ChangeBranchInfo.class);
        String groupId = companyAccountService.findParentCorporateGroupIdByCorporateGroupCode(changeBranchInfo.getBranchCode());
        try {
            if (!ObjectUtils.isEmpty(groupId) &&
                    !ObjectUtils.isEmpty(customerId) &&
                    !ObjectUtils.isEmpty(changeBranchInfo)) {

                ChangeCorporateGroupMemberInfoResponse changeCorporateGroupMemberInfoResponse = contractService.changeCorporateGroupMemberInfo(customerId, groupId, changeBranchInfo.getMsisdn(), changeBranchInfo.getBranchName(), changeBranchInfo.getBranchCode());

                if (!ObjectUtils.isEmpty(changeCorporateGroupMemberInfoResponse) && (changeCorporateGroupMemberInfoResponse.getChangeCorporateGroupMemberInfoRspMsg().getRspHeader().getReturnCode().equals("0000") ||
                        changeCorporateGroupMemberInfoResponse.getChangeCorporateGroupMemberInfoRspMsg().getRspHeader().getReturnMsg().equals("Success"))) {

                    log.debug("Branch Changed Successfully for CustomerId: {} GroupId: {} Department Name: {}, Department Id: {}", customerId, groupId, changeBranchInfo.getBranchName(), changeBranchInfo.getBranchCode());
                    updateBulkFileDetailsStatus(bulkFileDetails, Status.Success);




                } else {
                    log.debug("Change Branch Failed for CustomerId: {} GroupId: {}, ChangeBranchInfo: {}", customerId, groupId, changeBranchInfo);
                    updateBulkFileDetailsStatus(bulkFileDetails, Status.Failed);
                    updateBulkFileDetailsFailedReason(bulkFileDetails, changeCorporateGroupMemberInfoResponse.getChangeCorporateGroupMemberInfoRspMsg().getRspHeader().getReturnMsg());
                }
            } else {
                log.debug("Change Branch Invalid Information for CustomerId: {} GroupId: {}, ChangeBranchInfo: {}", customerId, groupId, changeBranchInfo);
                updateBulkFileDetailsStatus(bulkFileDetails, Status.Failed);
                updateBulkFileDetailsFailedReason(bulkFileDetails, "Change Branch Invalid Information.");
            }
        } catch (Exception e) {
            updateBulkFileDetailsStatus(bulkFileDetails, Status.Failed);
            updateBulkFileDetailsFailedReason(bulkFileDetails, e.getMessage());
        }
    }
    public void updateBulkFileDetailsStatus(BulkFileDetails bulkFileDetails, Status status) {
        bulkFileDetails.setFinalStatus(status.name());
        bulkFileDetailsService.update(bulkFileDetails);
    }

    public void updateBulkFileDetailsFailedReason(BulkFileDetails bulkFileDetails, String failedReason) {
        bulkFileDetails.setFailedReason(failedReason);
        bulkFileDetailsService.update(bulkFileDetails);
    }
}
