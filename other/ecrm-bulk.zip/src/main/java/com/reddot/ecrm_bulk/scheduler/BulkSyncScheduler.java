package com.reddot.ecrm_bulk.scheduler;

import com.reddot.ecrm_bulk.service.BulkFileDataProcessService;
import com.reddot.ecrm_bulk.service.BulkProcessService;
import com.reddot.ecrm_bulk.service.notification.BulkSMSOrEmailNotificationService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.mail.MessagingException;


@Component
@RequiredArgsConstructor
public class BulkSyncScheduler {

    private final Logger logger = LoggerFactory.getLogger(getClass().getName());

    private final BulkProcessService bulkProcessService;
    private final BulkSMSOrEmailNotificationService bulkSMSOrEmailNotificationService;
    private final BulkFileDataProcessService bulkFileDataProcessService;


    @Scheduled(fixedRate = 180000)
    public void bulkSyncScheduler() {
        logger.info("Inside bulkSyncScheduler");
        //bulkProcessService.checkBulkProcess();
    }

    //@Scheduled(cron = "0 0 1 * * *")  //every 1 hour
    //@Scheduled(fixedRate = 1000)
    @Scheduled(fixedRate = 180000)
    public void bulkNotificationSyncScheduler() throws MessagingException {
        logger.info("Inside bulkNotificationSyncScheduler");
        bulkSMSOrEmailNotificationService.processBulkSMSOrEmailNotificationService();
    }

    @Scheduled(fixedRate = 180000)
    public void bulkDataProcessSyncScheduler() {
        logger.info("Inside bulkDataProcessSyncScheduler");
        bulkFileDataProcessService.processBulkFileDataService();
    }


}
