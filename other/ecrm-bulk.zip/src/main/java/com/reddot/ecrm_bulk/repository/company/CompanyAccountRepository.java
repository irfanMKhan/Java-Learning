package com.reddot.ecrm_bulk.repository.company;

import com.reddot.ecrm_bulk.entity.company.CompanyAccount;
import com.reddot.ecrm_bulk.enums.company.CustomerAccountType;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

@Repository
public class CompanyAccountRepository {
    @PersistenceContext
    private EntityManager entityManager;
    public CompanyAccount findByCompanyNameAndCustomerAccountTypeAndActive(String companyName, String customerAccountType, Boolean active) {
        TypedQuery<CompanyAccount> query = entityManager.createQuery(
                "SELECT ca FROM CompanyAccount ca WHERE ca.companyName = :companyName AND ca.customerAccountType = :customerAccountType AND ca.active =:active",
                CompanyAccount.class);
        return query
                .setParameter("companyName", companyName)
                .setParameter("customerAccountType", customerAccountType)
                .setParameter("active", active)
                .getSingleResult();
    }

    public CompanyAccount findCorporateGroupByCustomerNameAndServiceType(String companyName, String serviceTypeName, Boolean active) {
        TypedQuery<CompanyAccount> query = entityManager.createQuery(
                "SELECT ca FROM CompanyAccount ca WHERE ca.companyName = :companyName AND ca.serviceTypeName = :serviceTypeName " +
                        "AND ca.isBranchSubscriber = :isBranchSubscriber AND ca.customerAccountType = :customerAccountType " +
                        "AND ca.active =:active",
                CompanyAccount.class);
        return query
                .setParameter("companyName", companyName)
                .setParameter("customerAccountType", CustomerAccountType.Subscriber.name())
                .setParameter("serviceTypeName", serviceTypeName)
                .setParameter("isBranchSubscriber", true)
                .setParameter("active", active)
                .getSingleResult();
    }

    public CompanyAccount findBranchSubscriberByCustomerNameAndServiceTypeAndBranch(String companyName, String serviceTypeName, String branch) {
        TypedQuery<CompanyAccount> query = entityManager.createQuery(
                "SELECT ca FROM CompanyAccount ca WHERE ca.companyName = :companyName AND ca.serviceTypeName = :serviceTypeName " +
                        "AND ca.isBranchSubscriber = :isBranchSubscriber AND ca.customerAccountType = :customerAccountType " +
                        "AND ca.accountName = :accountName",
                CompanyAccount.class);
        return query
                .setParameter("companyName", companyName)
                .setParameter("customerAccountType", CustomerAccountType.Subscriber.name())
                .setParameter("serviceTypeName", serviceTypeName)
                .setParameter("isBranchSubscriber", true)
                .setParameter("accountName", branch)
                .getSingleResult();
    }

    public CompanyAccount findByCompanyName(String companyName) {
        TypedQuery<CompanyAccount> query = entityManager.createQuery(
                "SELECT ca FROM CompanyAccount ca WHERE ca.companyName = :companyName",
                CompanyAccount.class);
        return query
                .setParameter("companyName", companyName)
                .getSingleResult();
    }

    public CompanyAccount findByAccountCode(String accountCode) {
        TypedQuery<CompanyAccount> query = entityManager.createQuery(
                "SELECT ca FROM CompanyAccount ca WHERE ca.accountCode = :accountCode",
                CompanyAccount.class);
        return query
                .setParameter("accountCode", accountCode)
                .getSingleResult();
    }

    public CompanyAccount findById(Long id) {
        TypedQuery<CompanyAccount> query = entityManager.createQuery(
                "SELECT ca FROM CompanyAccount ca WHERE ca.id = :id",
                CompanyAccount.class);
        return query
                .setParameter("id", id)
                .getSingleResult();
    }

    public CompanyAccount findParentSubscriberAccountByCustomerName(String companyName, String serviceTypeName) {
        TypedQuery<CompanyAccount> query = entityManager.createQuery(
                "SELECT ca FROM CompanyAccount ca WHERE ca.customerAccountType = :customerAccountType AND " +
                        "ca.companyName = :companyName AND ca.isParentSubscriberAccount =: isParentSubscriberAccount AND " +
                        "ca.serviceTypeName = :serviceTypeName",
                CompanyAccount.class);
        return query
                .setParameter("companyName", companyName)
                .setParameter("customerAccountType", CustomerAccountType.Subscriber.name())
                .setParameter("isParentSubscriberAccount", true)
                .setParameter("serviceTypeName", serviceTypeName)
                .getSingleResult();
    }
    
    public CompanyAccount findParentSubscriberAccountById(Long id) {
        TypedQuery<CompanyAccount> query = entityManager.createQuery(
                "SELECT ca FROM CompanyAccount ca WHERE ca.id = :id AND ca.isParentSubscriberAccount =: isParentSubscriberAccount",
                CompanyAccount.class);
        return query
                .setParameter("id", id)
                .setParameter("isParentSubscriberAccount", true)
                .getSingleResult();
    }

    public CompanyAccount findParentCustomerByAccountName(String accountName) {
        TypedQuery<CompanyAccount> query = entityManager.createQuery(
                "SELECT ca FROM CompanyAccount ca WHERE ca.accountName = :accountName AND ca.isParent = :isParent AND ca.customerAccountType = :customerAccountType AND ca.active = :active",
                CompanyAccount.class);
        return query
                .setParameter("accountName", accountName)
                .setParameter("isParent", true)
                .setParameter("customerAccountType", CustomerAccountType.Customer.name())
                .setParameter("active", true)
                .getSingleResult();
    }

    public CompanyAccount findCUGGroupByCompanyName(String companyName) {
        TypedQuery<CompanyAccount> query = entityManager.createQuery(
                "SELECT ca FROM CompanyAccount ca WHERE ca.customerAccountType = :customerAccountType AND ca.companyName = :companyName AND ca.active = :active",
                CompanyAccount.class);
        return query
                .setParameter("customerAccountType", CustomerAccountType.CUG_GROUP.toString())
                .setParameter("companyName", companyName)
                .setParameter("active", true)
                .getSingleResult();
    }

    public CompanyAccount findByParentCustomerIdAndCustomerAccountTypeAndActive(Long parentCustomerId, String customerAccountType, Boolean active) {
        TypedQuery<CompanyAccount> query = entityManager.createQuery(
                "SELECT ca FROM CompanyAccount ca WHERE ca.parentCustomerId = :parentCustomerId AND ca.customerAccountType = :customerAccountType AND ca.active = :active",
                CompanyAccount.class);
        return query
                .setParameter("parentCustomerId", parentCustomerId)
                .setParameter("customerAccountType", customerAccountType)
                .setParameter("active", active)
                .getSingleResult();
    }
}
