package com.reddot.ecrm_bulk.dto.product_details;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import java.time.LocalDate;
import java.time.LocalDateTime;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductDetailsDTO {
    private Long id;
    private String tempNO;
    private String productId;
    private String productName;
    private String msisdn;
    private String msisdnCategory;
    private String iccid;
    private String plan;
    private Long planId;
    private String planText;
    //todo: set planOfferingId
    private String ngbssPlanOfferingId;
    private String defaultCredit;
    private String reserveCredit;
    private String totalCredit;
    private String monthlyFee;
    private String maximumMonthlyFee;
    private String contractDuration;
    private String[] addOns;
    private String addOnsText;
    private String addOnsString;
    //todo: set planOfferingId
    private String ngbssAddOnsOfferingId;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private String effectiveDate;
    private String contractMaturityDate;
    private String firstName;
    private String lastName;
    private String employeeName;
    private String branch;
    private String device;
    private String deviceName;
    private String imei;
    private String upfrontPayment;
    private String payment;
    private String statusOfPayment;
    private String locationAddress;
    private String priority;
    private String numberOfOnu;
    private String testingPeriod;
    private String sla;
    private String discount;
    private String deposit;
    private String setupFee;
    private String lastMile;
    private String financialType;
    private String financialTypeText;
    private Double financialAmount;
    private Double remainingContractDuration;
    private Double remainingDeviceFee;
    private String remarks;
    private String contractNumber;
    private String opportunityNumber;

    private String createBy;
    private String createByName;
    private LocalDateTime createDate;
    private LocalDate createdDateOnly;
    private String updateBy;
    private String updateByName;
    private LocalDateTime updateDate;
    private LocalDate updatedDateOnly;
    private String deleteBy;
    private String deleteByName;
    private LocalDateTime deleteDate;
    private LocalDate deletedDateOnly;

    private Boolean preToPost;
    private Double remainingCredit;

    private String serviceTypeName;
    private Long serviceTypeId;

    private Boolean isCRContract;
    private Long crPrimaryId;

    private Integer ptpPaymentProcessDays;
    private LocalDate ptpPaymentProcessDate;
    private String upfrontPaymentAfterFA;
    private String adjustmentSerialNo;
    private String primaryOfferingAgreementId;
    private String status;
    private Boolean isChanged;

    private Boolean isDraftMsisdn;
    @Column(columnDefinition = "text")
    private String mandatoryOfferingList;
}
