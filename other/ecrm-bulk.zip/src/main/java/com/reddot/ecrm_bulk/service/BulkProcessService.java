package com.reddot.ecrm_bulk.service;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm_bulk.config.QueryBuilder;
import com.reddot.ecrm_bulk.config.Utility;
import com.reddot.ecrm_bulk.model.UploadedFileModel;

import com.reddot.ecrm_bulk.pool_repository.CommonRepository;
import org.jobrunr.scheduling.BackgroundJob;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class BulkProcessService {

    private final Logger logger = LoggerFactory.getLogger(getClass().getName());

    @Autowired
    private CommonRepository commonDAO;

    @Autowired
    private StudentImportService studentImportService;

    //    @Async("bulkPoolExecutor")
    public void checkBulkProcess() {
        logger.info("=====================Inside checkBulkProcess==================");
        try {
            Map<String, Object> searchData = new HashMap<String, Object>();
//            searchData.put("ID", "301");
            searchData.put("ACTIVE", "1");
            searchData.put("PROCESS_STATUS", "TODO");
           // searchData.put("CONNECTION_TYPE", "Postpaid");
            Map<String, Object> whereSearchType = new HashMap<String, Object>();
            whereSearchType.put("ACTIVE", "AND");
            whereSearchType.put("PROCESS_STATUS", "AND");
           // whereSearchType.put("CONNECTION_TYPE", "AND");
//            whereSearchType.put("ID", "AND");

            String listQStr = QueryBuilder.getWherQueryPaginationWithoutOrder(Utility.epm_bulkprocess_files, searchData, 0, 100, whereSearchType);
            Object srslist = commonDAO.CommoGetData(listQStr);
            System.out.println(srslist);
            List<UploadedFileModel> rows = new Gson().fromJson(Utility.ObjectToJson(srslist), new TypeToken<List<UploadedFileModel>>() {
            }.getType());

            if (rows == null || rows.isEmpty())
                return;

            String todoIds = "";
            for (int i = 0; i < rows.size(); i++) {
                try {
                    if (i == 0) {
                        todoIds = "'" + rows.get(i).getID() + "'";
                    } else {
                        todoIds = todoIds + ",'" + rows.get(i).getID() + "'";
                    }
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
            }
            String updateQuery = "UPDATE " + Utility.epm_bulkprocess_files + " SET ACTIVE='2', PROCESS_STATUS='In-Progress' WHERE ID IN (" + todoIds + ")";
            logger.info(updateQuery);
            if (!commonDAO.commonQuery(updateQuery, logger))
                return;
            for (UploadedFileModel uploadedFileModel : rows) {
                try {
//                    executeBulkProcess(uploadeFileModel);
                    BackgroundJob.enqueue(() -> executeBulkProcess(uploadedFileModel));
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    //    @Async("bulkPoolExecutor")
    public void executeBulkProcess(UploadedFileModel uploadedFileModel) {
        logger.info("Inside executeBulkProcess for: " + uploadedFileModel.getPROCESS_TYPE_NAME());
        try {
            switch (uploadedFileModel.getPROCESS_TYPE_ID()) {
                case "1": {
                    studentImportService.studentBulkImportv2(uploadedFileModel, "1");
                    break;
                }
                case "2": {
                    studentImportService.studentBulkImportv2(uploadedFileModel, "2");
                    break;
                }

                default:
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
    }
}
