package com.reddot.ecrm_bulk.api.gateway;

import com.google.gson.Gson;
import com.reddot.ecrm_bulk.api.exception.ApiRequestException;
import com.reddot.ecrm_bulk.api.exception.ConnectionResetException;
import com.reddot.ecrm_bulk.api.exception.InvalidClientCredentialsException;
import com.reddot.ecrm_bulk.api.exception.UrlNotFoundException;
import com.reddot.ecrm_bulk.api.payload.auth.AuthErrorResponse;
import com.reddot.ecrm_bulk.api.payload.auth.AuthSuccessResponse;
import com.reddot.ecrm_bulk.api.utils.CommonConstant;
import com.reddot.ecrm_bulk.api.utils.HttpClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.FormBody;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

@RequiredArgsConstructor
@Slf4j
@Service
public class AuthorizationGateway {
    @Value("${smart.egw.base.url}")
    String baseUrlEGW;
    @Value("${smart.egw.token}")
    String tokenEGW;
    @Value("${smart.igw.base.url}")
    String baseUrlIGW;
    @Value("${smart.igw.token}")
    String tokenIGW;

    private final HttpClient httpClient;
    private final Gson gson;

    @Retryable(value = { ConnectionResetException.class }, maxAttemptsExpression = "${retry.socket.maxAttempts}" , backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public AuthSuccessResponse getTokenEGW() {
        String apiUrl = baseUrlEGW + "/token";

        RequestBody formBody = new FormBody.Builder()
                .add("grant_type", "client_credentials")
                .build();

        Map<String, String> headers = new HashMap<String, String>() {{
            put("Authorization", "Basic " + tokenEGW);
            put("Accept", "application/json");
            put("Content-Type","application/x-www-form-urlencoded");
        }};

        try (Response response = httpClient.post(formBody, apiUrl, headers)) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), AuthSuccessResponse.class);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()){
                AuthErrorResponse errorResponse = gson.fromJson(response.body().string(), AuthErrorResponse.class);
                throw new InvalidClientCredentialsException(errorResponse.getError_description());
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                throw new UrlNotFoundException("Url Not Found: " + apiUrl);
            } else {
                AuthErrorResponse errorResponse = gson.fromJson(response.body().string(), AuthErrorResponse.class);
                throw new ApiRequestException(errorResponse.getError_description());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.error("Authorization Gateway Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidClientCredentialsException) {
                log.error("Authorization Gateway Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialsException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.debug("Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            } else if (e instanceof UrlNotFoundException) {
                throw new UrlNotFoundException(e.getMessage());
            }  else if (e instanceof UnknownHostException) {
                throw new UrlNotFoundException("No such host is known ( " + apiUrl + " )");
            } else {
                log.error("Authorization Gateway EGW Error: {}", e.getMessage(), e.getCause());
                throw new ApiRequestException(e.getMessage());
            }
        }
    }

    @Retryable(value = { ConnectionResetException.class }, maxAttemptsExpression = "${retry.socket.maxAttempts}" , backoff = @Backoff(delayExpression = "${retry.socket.maxDelay}"))
    public AuthSuccessResponse getTokenIGW() {
        String apiUrl = baseUrlIGW + "/token";

        RequestBody formBody = new FormBody.Builder()
                .add("grant_type", "client_credentials")
                .build();

        Map<String, String> headers = new HashMap<String, String>() {{
            put("Authorization", "Basic " + tokenIGW);
            put("Accept", "application/json");
            put("Content-Type","application/x-www-form-urlencoded");
        }};

        try (Response response = httpClient.post(formBody, apiUrl, headers)) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), AuthSuccessResponse.class);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()){
                AuthErrorResponse errorResponse = gson.fromJson(response.body().string(), AuthErrorResponse.class);
                throw new InvalidClientCredentialsException(errorResponse.getError_description());
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                throw new UrlNotFoundException("Url Not Found: " + apiUrl);
            } else {
                AuthErrorResponse errorResponse = gson.fromJson(response.body().string(), AuthErrorResponse.class);
                throw new ApiRequestException(errorResponse.getError_description());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.error("Authorization Gateway Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidClientCredentialsException) {
                log.error("Authorization Gateway Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialsException(e.getMessage());
            } else if (e instanceof SocketException) {
                log.debug("Authorization Gateway Connection Reset");
                throw new ConnectionResetException(e.getMessage());
            } else if (e instanceof UrlNotFoundException) {
                throw new UrlNotFoundException(e.getMessage());
            } else if (e instanceof UnknownHostException) {
                throw new UrlNotFoundException("No such host is known ( " + apiUrl + " )");
            } else {
                log.error("Authorization Gateway IGW Error: {}", e.getMessage(), e.getCause());
                throw new ApiRequestException(e.getMessage());
            }
        }
    }
}
