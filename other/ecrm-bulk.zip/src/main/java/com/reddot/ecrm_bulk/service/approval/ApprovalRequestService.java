package com.reddot.ecrm_bulk.service.approval;

import com.google.gson.Gson;
import com.reddot.ecrm_bulk.dto.common.CommonRestResponse;
import com.reddot.ecrm_bulk.dto.common.HttpServletRequestDto;
import com.reddot.ecrm_bulk.dto.user.MDUserModel;
import com.reddot.ecrm_bulk.dto.user.UserModel;
import com.reddot.ecrm_bulk.entity.approval.ApprovalFlowStepsEntity;
import com.reddot.ecrm_bulk.entity.approval.ApprovalLogDetailsEntity;
import com.reddot.ecrm_bulk.entity.approval.ApprovalRequestEntity;
import com.reddot.ecrm_bulk.entity.company.Company;
import com.reddot.ecrm_bulk.entity.delegation.DelegationEntity;
import com.reddot.ecrm_bulk.entity.notification.NotificationEntity;
import com.reddot.ecrm_bulk.enums.email.email_template.EmailTemplateEnum;
import com.reddot.ecrm_bulk.enums.notification.NotificationStatusEnum;
import com.reddot.ecrm_bulk.enums.notification.NotificationTypeEnum;
import com.reddot.ecrm_bulk.enums.status.Status;
import com.reddot.ecrm_bulk.pool_repository.CommonRepository;
import com.reddot.ecrm_bulk.repository.approval.ApprovalFlowStepsRepo;
import com.reddot.ecrm_bulk.repository.approval.ApprovalLogDetailsRepo;
import com.reddot.ecrm_bulk.repository.approval.ApprovalRequestRepo;
import com.reddot.ecrm_bulk.repository.company.CompanyRepository;
import com.reddot.ecrm_bulk.repository.notification.NotificationEntityRepository;
import com.reddot.ecrm_bulk.service.company.CompanyService;
import com.reddot.ecrm_bulk.service.notification.email.ThymleafService;
import com.reddot.ecrm_bulk.service.user.UserService;
import com.reddot.ecrm_bulk.util.Utility;
import freemarker.template.TemplateException;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.domain.*;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class ApprovalRequestService {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    //private final ThreadPoolTaskExecutor threadPoolTaskExecutor = SingletonThreadPool.getInstance();
    @Autowired
    CompanyRepository companyRepository;
    @Autowired
    UserService userService;
    @Autowired
    ApprovalFlowStepsRepo approvalFlowStepsRepo;
    @Autowired
    ApprovalRequestRepo approvalRequestRepo;
    @Autowired
    CommonRepository commonRepository;
    @Autowired
    ApprovalLogDetailsRepo approvalLogDetailsRepo;
    @Autowired
    JavaMailSender javaMailSender;
    @Value("${app.base_url}")
    private String app_base_url;
    @Value("${spring.mail.from}")
    private String emailFrom;
    @Autowired
    ThymleafService thymleafService;
    @Autowired
    NotificationEntityRepository notificationRepo;
    public CommonRestResponse addRequestData(ApprovalRequestEntity approvalRequest, HttpServletRequestDto request) {
        CommonRestResponse commonRestResponse = new CommonRestResponse();
        try {
            List<UserModel> kamList = getKamUserList(request);
            if (kamList.size() > 0) {
                for (UserModel kamUser : kamList) {
                    if (!ObjectUtils.isEmpty(kamUser)) {
                        request.setKamUserModel(kamUser);
                    }
                }
            }
            Boolean hasApproval = ApprovalProcess(approvalRequest, request);
            commonRestResponse.setData(hasApproval);
            commonRestResponse.setCode(200);
            commonRestResponse.setMessage("Successfully save the data");
        } catch (Exception e) {
            logger.error(String.format("ApprovalRequestService:addRequestData() Error: %s", e.getMessage()));
            commonRestResponse.setCode(500);
            commonRestResponse.setMessage("Failed to save");
        }
        return commonRestResponse;
    }

    public List<UserModel> getKamUserList(HttpServletRequestDto request) {
        List<UserModel> kamUserList = new ArrayList<>();
        try {
            MDUserModel mdUserModel = request.getMdUserModel();
            Long kamId = null;
            if (mdUserModel != null) {
                Long companyId = mdUserModel.getCOMPANY_ID();
                String companyName = mdUserModel.getCOMPANY_NAME();
                if (companyId != null) {
                    Company company = companyRepository.findByIdAndActive(companyId, true);
                    if (company != null) {
                        kamId = company.getKamId();
                    } else {
                        logger.error(String.format("ApprovalRequestService:getKamUserList(): can not find Kam's company by companyId for this user: {}",
                                request.getCreatedUsername()));
                    }
                } else if (companyName != null) {
                    Optional<Company> company = Optional.ofNullable(companyRepository.findByName(companyName));
                    if (company.isPresent()) {
                        kamId = company.get().getKamId();
                    } else {
                        logger.error(String.format("ApprovalRequestService:getKamUserList(): can not find Kam's company by companyName for this user: {}",
                                request.getCreatedUsername()));

                    }
                } else if (ObjectUtils.isEmpty(companyId) && ObjectUtils.isEmpty(companyName)) {
//                    logger.error(String.format("ApprovalRequestService:getKamUserList():  companyName and companyId is null for this user: {}",
//                            request.getCreatedUsername()));

                }
            }

            if (kamId != null) {
                UserModel userModel = userService.getUserById(kamId);
                if (userModel != null) {
                    kamUserList.add(userModel);
                }
            } else {
//                logger.error(String.format("ApprovalRequestService:getKamUserList(): KamId is null for this user: {}", request.getCreatedUsername()));
            }


        } catch (Exception e) {
            logger.error(String.format("ApprovalRequestService:getKamUserList() Error: %s", e.getMessage()));
        }
        return kamUserList;
    }
    public Boolean ApprovalProcess(ApprovalRequestEntity approvalRequest, HttpServletRequestDto request) throws MessagingException, TemplateException, IOException {
        try {
            logger.info("Send Mail: ApprovalProcess");
            Long tenantId = request.getTenantId();
            List<ApprovalFlowStepsEntity> list = new ArrayList<>();
            if (approvalRequest.getHasRequestedAmount()) {
                list = approvalFlowStepsRepo.findAllByMinValueLessThanEqualAndMaxValueGreaterThanEqualAndApprovalFlowIdEqualsAndTenantIdEquals(approvalRequest.getRequestedAmount(), approvalRequest.getRequestedAmount(), approvalRequest.getApprovalFlowId(), tenantId);
            } else if (approvalRequest.getIsCategoryType()) {
                list = approvalFlowStepsRepo.findAllByApprovalFlowIdAndUnitValueAndTenantId(approvalRequest.getApprovalFlowId(),
                        approvalRequest.getCategoryValue(), tenantId);
            } else {
                list = approvalFlowStepsRepo.findAllByApprovalFlowIdAndTenantId(approvalRequest.getApprovalFlowId(), tenantId);
            }
            if (list.size() > 0) {
                approvalRequest.setRequestedAt(Utility.loggedInCurrentTime());
                LocalDate localDate = LocalDate.now();
                approvalRequest.setRequestedAtDt(localDate);
                approvalRequest.setRequestedBy(request.getCreatedBy());
                approvalRequest.setRequestedUsername(request.getCreatedUsername());
                approvalRequest.setTenantId(request.getTenantId());
                approvalRequest.setStatus(Status.Pending.toString().toUpperCase());
                UUID uuidtoken = UUID.randomUUID();
                approvalRequest.setUuidToken(String.valueOf(uuidtoken));
                approvalRequestRepo.save(approvalRequest);
            } else {
                logger.info("No Approval Steps found for this approval request: {}", approvalRequest.getApprovalFlowName());
                return false; //has no approval
            }
            ModelMapper modelMapper = new ModelMapper();
            List<ApprovalLogDetailsEntity> approvalLogEntityList = new ArrayList<>();
            for (ApprovalFlowStepsEntity approvalFlowSteps : list) {
                ApprovalLogDetailsEntity approvalLogDetailsEntity = new ApprovalLogDetailsEntity(); //create log details
                approvalLogDetailsEntity.setTransactionId(approvalRequest.getRequestTransactionId());
                approvalLogDetailsEntity.setStepOrder(approvalFlowSteps.getStepOrder());
                approvalLogDetailsEntity.setIsOptional(approvalFlowSteps.getIsOptional());
                approvalLogDetailsEntity.setApprovalReqId(approvalRequest.getId());
                approvalLogDetailsEntity.setApprovalStepId(approvalFlowSteps.getId());
                approvalLogDetailsEntity.setApprovalRulesId(approvalFlowSteps.getFlowRulesId());
                approvalLogDetailsEntity.setApprovalFlowId(approvalFlowSteps.getApprovalFlowId());
                approvalLogDetailsEntity.setApprovalFlowName(approvalRequest.getApprovalFlowName());
                approvalLogDetailsEntity.setStatus(Status.Pending.toString().toUpperCase());
                approvalLogDetailsEntity.setUuidToken(approvalRequest.getUuidToken());
                approvalLogDetailsEntity.setRequestDetailsId(approvalRequest.getRequestDetailsId());

                if (approvalFlowSteps.getUserId() == null) //whole position group will get mail
                {
                    List<UserModel> userList = new ArrayList<>();
                    if (approvalFlowSteps.getGrpPositionId() != null) {
                        userList = userService.getAllUserListByRoleId(Long.valueOf(approvalFlowSteps.getGrpPositionId()));
                        if (approvalFlowSteps.getGrpPositionName().equals("KAM")) {
                            List<UserModel> list1 = new ArrayList<>();
                            if (!ObjectUtils.isEmpty(approvalRequest.getCompanyName())) {
                                UserModel kamUser = getKamUserByCompanyName(approvalRequest.getCompanyName());
                                if (kamUser != null) {
                                    list1.add(kamUser);
                                }

                            } else if (!ObjectUtils.isEmpty(request.getKamUserModel()) && !ObjectUtils.isEmpty(request.getKamUserModel().getEmail())) {
                                list1.add(request.getKamUserModel()); //set only comapny kam for KAM approval
                            }

                            userList = list1;

                        }
                    }

                    for (UserModel user : userList) {  //get all the user which has same positionID

                        String sql_delegation = String.format("Select * from %s where end_date > now() and is_active=true and delegator_id=%s", Utility.delegation_table, user.getId());
                        List<Map<String, Object>> delegationList = (List<Map<String, Object>>) commonRepository.CommoGetData(sql_delegation);

                        ApprovalLogDetailsEntity newApprovalLogDetailsEntity = new ApprovalLogDetailsEntity(); //create new object for each user

                        modelMapper.map(approvalLogDetailsEntity, newApprovalLogDetailsEntity);
                        newApprovalLogDetailsEntity.setTransactionId(approvalRequest.getRequestTransactionId());
                        if (delegationList.size() == 0) {

                            newApprovalLogDetailsEntity.setApproverID(user.getId());
                            newApprovalLogDetailsEntity.setApproverName(user.getName());
                            newApprovalLogDetailsEntity.setApproverEmail(user.getEmail());

                            newApprovalLogDetailsEntity = approvalLogDetailsRepo.save(newApprovalLogDetailsEntity);
                            approvalLogEntityList.add(newApprovalLogDetailsEntity);
                            // sendMail(newApprovalLogDetailsEntity, approvalRequest, request);
                        } else {
                            //delegation part
                            for (Map<String, Object> map : delegationList) {
                                newApprovalLogDetailsEntity.setApproverID((Long) map.get("delegate_id"));
                                newApprovalLogDetailsEntity.setApproverName((String) map.get("delegate_username"));
                                newApprovalLogDetailsEntity.setApproverEmail((String) map.get("delegate_email"));

                                ApprovalLogDetailsEntity approvalLogDetailsForDelegation = new ApprovalLogDetailsEntity();
                                modelMapper.map(newApprovalLogDetailsEntity, approvalLogDetailsForDelegation);

                                approvalLogDetailsForDelegation = approvalLogDetailsRepo.save(approvalLogDetailsForDelegation);
                                approvalLogEntityList.add(approvalLogDetailsForDelegation);
                                //sendMail(approvalLogDetailsForDelegation, approvalRequest, request);
                            }
                        }
                    }

                } else {  //specific user to approve the request

                    String sql_delegation = String.format("Select * from %s where end_date > now() and is_active=true and delegator_id=%s", Utility.delegation_table, approvalFlowSteps.getUserId());
                    List<Map<String, Object>> delegationList = (List<Map<String, Object>>) commonRepository.CommoGetData(sql_delegation);

                    if (delegationList.size() == 0) {
                        approvalLogDetailsEntity.setTransactionId(approvalRequest.getRequestTransactionId());
                        approvalLogDetailsEntity.setApproverID(approvalFlowSteps.getUserId());
                        approvalLogDetailsEntity.setApproverName(approvalFlowSteps.getUserName());
                        approvalLogDetailsEntity.setApproverEmail(approvalFlowSteps.getUserEmail());
                        approvalLogDetailsEntity = approvalLogDetailsRepo.save(approvalLogDetailsEntity);
                        approvalLogEntityList.add(approvalLogDetailsEntity);
                        // sendMail(approvalLogDetailsEntity, approvalRequest, request);
                    } else {
                        //delegation part
                        for (Map<String, Object> map : delegationList) {
                            approvalLogDetailsEntity.setTransactionId(approvalRequest.getRequestTransactionId());
                            approvalLogDetailsEntity.setApproverID((Long) map.get("delegate_id"));
                            approvalLogDetailsEntity.setApproverName((String) map.get("delegate_username"));
                            approvalLogDetailsEntity.setApproverEmail((String) map.get("delegate_email"));
                            approvalLogDetailsEntity = approvalLogDetailsRepo.save(approvalLogDetailsEntity);
                            approvalLogEntityList.add(approvalLogDetailsEntity);
                            //sendMail(approvalLogDetailsEntity, approvalRequest, request);
                        }
                    }

                }
            }


            if (request == null) {
                request = new HttpServletRequestDto();
            }
            if (approvalLogEntityList.size() > 0) {
                HttpServletRequestDto finalHttpServletRequestDto = request;
                logger.info("Send Mail: sendMailMain() Approver List={} , Approval Name={}", approvalLogEntityList.size(), approvalRequest.getApprovalFlowName());
                logger.info("sendMailMain() Requested By {} ", request.getCreatedUsername());
                try {
                    sendMailMain(approvalLogEntityList, approvalRequest, finalHttpServletRequestDto);
                } catch (MessagingException e) {
                    logger.error(String.format("ApprovalRequestService:sendMailMai() MessagingException Error: %s", e.getMessage()));
                    throw new RuntimeException(e);
                } catch (IOException e) {
                    logger.error(String.format("ApprovalRequestService:sendMailMai() IOException Error: %s", e.getMessage()));
                    throw new RuntimeException(e);
                } catch (TemplateException e) {
                    logger.error(String.format("ApprovalRequestService:sendMailMai() TemplateException Error: %s", e.getMessage()));
                    throw new RuntimeException(e);
                }
//                //  sendMailMain(approvalLogEntityList, approvalRequest, finalHttpServletRequestDto);
//                CompletableFuture<Void> completableFuture = CompletableFuture.runAsync(() -> {
//
//                }, threadPoolTaskExecutor);
            }

        } catch (Exception e) {
            logger.error(String.format("ApprovalRequestService:ApprovalProcess() Error: %s", e.getMessage()));
            return false;
        }
        return true;
    }
    private UserModel getKamUserByCompanyName(String companyName) {
        try {
            Long kamId = null;
            if (companyName != null) {
                Optional<Company> company = Optional.ofNullable(companyRepository.findByName(companyName));
                if (company.isPresent()) {
                    if (!ObjectUtils.isEmpty(company.get().getKamId())) {
                        kamId = company.get().getKamId();
                    } else {
                        logger.error(String.format("ApprovalRequestService:getKamUserByCompanyName(): company found but KAMId is null by companyName for this user: {}",
                                companyName));
                    }

                } else {
                    logger.error(String.format("ApprovalRequestService:getKamUserByCompanyName(): can not find Kam's company by companyName for this user: {}",
                            companyName));

                }
            } else if (ObjectUtils.isEmpty(companyName)) {
                logger.error(String.format("ApprovalRequestService:getKamUserByCompanyName():  companyName and companyId is null for this user: {}",
                        companyName));

            }


            if (!ObjectUtils.isEmpty(kamId)) {
                UserModel userModel = userService.getUserById(kamId);
                if (userModel != null) {
                    return userModel;
                } else {
                    logger.error(String.format("ApprovalRequestService:getKamUserByCompanyName(): can not get userModel by KamId for this user: {}", companyName));
                }
            } else {
                logger.error(String.format("ApprovalRequestService:getKamUserByCompanyName(): KamId is null for this user: {}", companyName));
            }

        } catch (Exception e) {
            logger.error(String.format("ApprovalRequestService:getKamUserByCompanyName() Error: %s", e.getMessage()));
        }
        return null;
    }

    public void sendMailMain(List<ApprovalLogDetailsEntity> approvalLogDetailsEntityList, ApprovalRequestEntity approvalRequest, HttpServletRequestDto request) throws MessagingException, IOException, TemplateException {
        try {

            MimeMessage message = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED, StandardCharsets.UTF_8.name());

            String base_url = String.format("%s", app_base_url);

            for (ApprovalLogDetailsEntity approvalLogDetailsEntity : approvalLogDetailsEntityList) {
                helper.setFrom(emailFrom);
                helper.setTo(approvalLogDetailsEntity.getApproverEmail());
                //helper.setTo([]);
                String subject = "";
                if (approvalRequest.getHasRequestedAmount()) {
                    subject = String.format("%s | Approval Request for %s  (Requested Amount= $%s)", approvalRequest.getCompanyName(), approvalLogDetailsEntity.getApprovalFlowName(), approvalRequest.getRequestedAmount());
                } else if (approvalRequest.getIsCategoryType()) {
                    subject = String.format("%s | Approval Request for %s  (Requested Category= %s)", approvalRequest.getCompanyName(), approvalRequest.getApprovalFlowName(), approvalRequest.getCategoryValue());
                } else {
                    subject = String.format("%s | Approval Request for %s ", approvalRequest.getCompanyName(), approvalLogDetailsEntity.getApprovalFlowName());
                }
                helper.setSubject(subject);
                String acceptLink = String.format("%s/approval/flow/request/email/accept?approverId=%s&token=%s&approvalLogDetailsId=%s", base_url,
                        approvalLogDetailsEntity.getApproverID(), approvalLogDetailsEntity.getUuidToken(), approvalLogDetailsEntity.getId());
                String rejectLink = String.format("%s/approval/flow/request/email/reject?approverId=%s&token=%s&approvalLogDetailsId=%s", base_url,
                        approvalLogDetailsEntity.getApproverID(), approvalLogDetailsEntity.getUuidToken(), approvalLogDetailsEntity.getId());
                String reqDetails = String.format("%s/approval/flow/request/email/requestDetails?reqId=%s&approverId=%s&token=%s&logDetailsId=%s",
                        base_url, approvalRequest.getId(), approvalLogDetailsEntity.getApproverID(), approvalLogDetailsEntity.getUuidToken(), approvalLogDetailsEntity.getId());

                Map<String, Object> model = new HashMap<>();
                model.put("name", approvalLogDetailsEntity.getApproverName());
                model.put("requestedByUsername", approvalRequest.getRequestedUsername());
                model.put("requestType", approvalRequest.getApprovalFlowName());
                model.put("requestedAmount", approvalRequest.getRequestedAmount());
                model.put("reqDetails", reqDetails);
                model.put("approveLink", acceptLink);
                model.put("rejectLink", rejectLink);
                model.put("companyName", approvalRequest.getCompanyName());
                model.put("description", approvalRequest.getRequestDescription());

                if (approvalRequest.getUnitType() != null) {
                    model.put("unitType", approvalRequest.getUnitType());
                } else {
                    model.put("unitType", "");
                }

                if (approvalRequest.getHasRequestedAmount()) {
                    model.put("requestedValueTitle", "Requested Amount");
                } else if (approvalRequest.getIsCategoryType()) {
                    model.put("requestedValueTitle", "Requested Category");
                } else {
                    model.put("requestedValueTitle", "Requested");
                    model.put("unitType", "");
                }


                helper.setText(thymleafService.createContent(EmailTemplateEnum.Common_Template.getTemplateName(), model), true);
                String mailBody = thymleafService.createContent(EmailTemplateEnum.Common_Template.getTemplateName(), model);

//                if (!ObjectUtils.isEmpty(request.getKamUserModel()) && !ObjectUtils.isEmpty(request.getKamUserModel().getEmail())) {
//                    helper.setCc(request.getKamUserModel().getEmail()); //set kam in cc
//                }


                logger.info("Start:");
                logger.info(String.valueOf(LocalTime.now()));

                SaveNotificationData(request, message, subject, mailBody, approvalLogDetailsEntity, null, null);
                logger.info("End:");
                logger.info(String.valueOf(LocalTime.now()));
            }

            if (!ObjectUtils.isEmpty(approvalRequest.getCompanyName())) {
                UserModel kamUser = getKamUserByCompanyName(approvalRequest.getCompanyName());
                if (kamUser != null) {
                    logger.info("Kam User Approval Notification Sent for this KAM user {}.", kamUser.getName());
                    request.setKamUserModel(kamUser);
                    request.setIsKamNotificationMail(true);
                    sendKamApprovalMailNotification(request, message, helper, approvalRequest);
                }

            } else if (!ObjectUtils.isEmpty(request.getKamUserModel()) && !ObjectUtils.isEmpty(request.getKamUserModel().getEmail())) {
                request.setIsKamNotificationMail(true);
                sendKamApprovalMailNotification(request, message, helper, approvalRequest);
            }

        } catch (Exception e) {
            logger.error(String.format("ApprovalRequestService:sendMail() Error: %s", e.getMessage()));
        }
    }

    public Boolean SaveNotificationData(HttpServletRequestDto request, MimeMessage message,
                                        String subject, String mailBody, ApprovalLogDetailsEntity approvalLogDetailsEntity,
                                        String recipient, JavaMailSenderImpl javaMailSenderCustom) throws MessagingException, IOException {
        Boolean IsMainSendSuccess = false;
        NotificationEntity notification = new NotificationEntity();
        String responseMsg = "";
        try {
            notification.setNotificationStatus(NotificationStatusEnum.Sent);
            notification.setNotificationType(NotificationTypeEnum.Mail);
            notification.setNotificationTitle(subject);
            String plainBodyText = Jsoup.parse(mailBody).text();
            notification.setNotificationBody(plainBodyText);
            if (approvalLogDetailsEntity != null) {
                notification.setRecipientId(approvalLogDetailsEntity.getApproverID());
                notification.setRecipientName(approvalLogDetailsEntity.getApproverName());
                notification.setRecipientEmailAddress(approvalLogDetailsEntity.getApproverEmail());
                notification.setFeatureName(approvalLogDetailsEntity.getApprovalFlowName());
            } else {
                notification.setRecipientName(recipient);
                notification.setRecipientEmailAddress(recipient);
                if (!ObjectUtils.isEmpty(request.getIsKamNotificationMail()) && request.getIsKamNotificationMail()) {
                    notification.setFeatureName("KAM Notification");
                }
            }

            notification.setCreatedAt(Utility.loggedInCurrentTime());
            Timestamp dateTime = new Timestamp(Utility.loggedInCurrentTime());
            notification.setCreatedAtDt(dateTime);
            notification.setCreatedBy(request.getCreatedBy());
            notification.setCreatedUsername(request.getCreatedUsername());
            notification.setNotificationTimeDt(dateTime);
            notification.setNotificationTime(Utility.loggedInCurrentTime());

            if (javaMailSenderCustom == null) {
                javaMailSender.send(message);
            } else {
                javaMailSenderCustom.send(message);
            }

            //   javaMailSender.send(message);

            IsMainSendSuccess = true;
        } catch (Exception e) {
            responseMsg = e.getMessage();
            notification.setFailedReasonMsg(responseMsg);
            notification.setNotificationStatus(NotificationStatusEnum.Failed);
            logger.error(String.format("EmailService:SaveNotificationData() Error: %s", e.getMessage()));
            logger.info(e.getMessage());
        }

        notificationRepo.saveAndFlush(notification);
        return IsMainSendSuccess;
    }

    private void sendKamApprovalMailNotification(HttpServletRequestDto request, MimeMessage message, MimeMessageHelper helper, ApprovalRequestEntity approvalRequest) throws MessagingException, IOException {
        try {
            helper.setFrom(emailFrom);
            helper.setTo(request.getKamUserModel().getEmail());
            String base_url = String.format("%s", app_base_url);
            String subject = "";
            if (approvalRequest.getHasRequestedAmount()) {
                subject = String.format("%s | Notification of Approval Request for %s  (Requested Amount= $%s)", approvalRequest.getCompanyName(), approvalRequest.getApprovalFlowName(), approvalRequest.getRequestedAmount());
            } else if (approvalRequest.getIsCategoryType()) {
                subject = String.format("%s | Notification of Approval Request for %s  (Requested Category= %s)", approvalRequest.getCompanyName(), approvalRequest.getApprovalFlowName(), approvalRequest.getCategoryValue());

            } else {
                subject = String.format("%s | Notification of Approval Request for %s ", approvalRequest.getCompanyName(), approvalRequest.getApprovalFlowName());
            }
            helper.setSubject(subject);

            String reqDetails = String.format("%s/approval/flow/request/singleRequestDetails?id=%s&token=%s", base_url, approvalRequest.getId(), approvalRequest.getUuidToken());
            //  String reqDetails = "";
            Map<String, Object> model = new HashMap<>();
            model.put("name", request.getKamUserModel().getName());
            model.put("requestType", approvalRequest.getApprovalFlowName());
            model.put("requestedAmount", approvalRequest.getRequestedAmount());
            model.put("reqDetails", reqDetails);
            model.put("companyName", approvalRequest.getCompanyName());
            model.put("description", approvalRequest.getRequestDescription());
            if (approvalRequest.getUnitType() != null) {
                model.put("unitType", approvalRequest.getUnitType());
            } else {
                model.put("unitType", "");
            }

            if (approvalRequest.getHasRequestedAmount()) {
                model.put("requestedValueTitle", "Requested Amount");
            } else if (approvalRequest.getIsCategoryType()) {
                model.put("requestedValueTitle", "Requested Category");
            } else {
                model.put("requestedValueTitle", "Requested");
                model.put("unitType", "Device");
            }

            helper.setText(thymleafService.createContent(EmailTemplateEnum.KAM_Notification_Template.getTemplateName(), model), true);
            String mailBody = thymleafService.createContent(EmailTemplateEnum.KAM_Notification_Template.getTemplateName(), model);

            logger.info("Start:");
            logger.info(String.valueOf(LocalTime.now()));

            SaveNotificationData(request, message, subject, mailBody, null, request.getKamUserModel().getEmail(), null);
            logger.info("End:");
            logger.info(String.valueOf(LocalTime.now()));
        } catch (Exception e) {
            logger.error(String.format("ApprovalRequestService:sendKamApprovalMailNotification() Error: %s", e.getMessage()));
        }
    }


    public void sendDelegationMailNotification(HttpServletRequestDto request, DelegationEntity delegationEntity, String delegationMailTitle) {
        try {
            MimeMessage message = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED, StandardCharsets.UTF_8.name());

            if (delegationEntity.getDelegatorId() != null) {
                UserModel userModel = userService.getUserById(delegationEntity.getDelegatorId());
                if (userModel != null && !ObjectUtils.isEmpty(userModel.getEmail())) {
                    helper.setCc(userModel.getEmail());
                }
            }
            helper.setFrom(emailFrom);
            helper.setTo(delegationEntity.getDelegateEmail());
            String subject = "";
            subject = String.format("%s from Delegator User %s", delegationMailTitle, delegationEntity.getDelegatorUsername(),
                    delegationEntity.getStartDate(), delegationEntity.getEndDate());
            helper.setSubject(subject);


            Map<String, Object> model = new HashMap<>();
            model.put("name", delegationEntity.getDelegateUsername());
            model.put("headLine", delegationMailTitle);

            Map<String, Object> detailsMap = new LinkedHashMap<>();
            detailsMap.put("Delegator User", delegationEntity.getDelegatorUsername());
            detailsMap.put("Start Date", delegationEntity.getStartDate());
            detailsMap.put("End Date", delegationEntity.getEndDate());
            model.put("detailsMap", detailsMap);

            helper.setText(thymleafService.createContent(EmailTemplateEnum.Delegation_Template.getTemplateName(), model), true);
            String mailBody = thymleafService.createContent(EmailTemplateEnum.Delegation_Template.getTemplateName(), model);

            logger.info("Start:");
            logger.info(String.valueOf(LocalTime.now()));

            SaveNotificationData(request, message, subject, mailBody, null, delegationEntity.getDelegateEmail(), null);
            logger.info("End:");
            logger.info(String.valueOf(LocalTime.now()));
        } catch (Exception e) {
            logger.error(String.format("ApprovalRequestService:sendDelegationMailNotification() Error: %s", e.getMessage()));
        }
    }


}