package com.reddot.ecrm_bulk.enums.bulk;

import java.util.AbstractMap;
import java.util.Map;

public enum BulkProcessFileType {

    Add_New_Number("Add New Number", 1001),
    Add_Survey("Add Survey", 2001),
    Lead("Lead", 3000),
    Contract("Contract", 3001),
    Opportunity("Opportunity", 3002),
    Change_Branch("Change Branch", 3003),
    Delay_payment("Delay_payment", 4000),
    Financial_Adjustment("Financial_Adjustment", 4001),

    Deposit("Deposit", 4002),
    Credit_Ceiling_history("Credit_Ceiling_history", 4003);


    private final String key;
    private final int value;

    BulkProcessFileType(String key, int value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public int getValue() {
        return value;
    }

    public Map.Entry<String, Integer> getBoth() {
        return new AbstractMap.SimpleEntry<>(key, value);
    }

}
