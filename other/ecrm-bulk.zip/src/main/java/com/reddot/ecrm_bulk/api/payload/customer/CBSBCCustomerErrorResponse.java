package com.reddot.ecrm_bulk.api.payload.customer;

import lombok.Data;

import java.io.Serializable;

@Data
public class CBSBCCustomerErrorResponse implements Serializable {
    private String code;

    private String variables;

    private String message;
}
