package com.reddot.ecrm_bulk.service.notification.email;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.reddot.ecrm_bulk.entity.notification.NotificationEntity;
import com.reddot.ecrm_bulk.enums.email.email_template.EmailTemplateEnum;
import org.apache.commons.codec.CharEncoding;
import org.jsoup.Jsoup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class EmailSenderService {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    @Autowired
    ThymleafService thymleafService;
    @Autowired
    private JavaMailSender sender;
    @Value("${spring.mail.from}")
    private String emailFromAddress;

    public boolean sendEmail(String toEmail, String body, String subject, String cc) {
        MimeMessage mimeMessage = sender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage);
        try {
            helper.setTo(InternetAddress.parse(toEmail));
            helper.setCc(InternetAddress.parse(cc));
            // helper.setTo(toEmail);
            helper.setSubject(subject);
            helper.setText(body, true);
            helper.setFrom(emailFromAddress);
            sender.send(mimeMessage);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return false;
    }

    public boolean sendEmailwithAttachment(String toEmail, String body, String subject, File file, String toCC) throws MessagingException {
        MimeMessage mimeMessage = sender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, CharEncoding.UTF_8);
        try {

            helper.setTo(InternetAddress.parse(toEmail));
            helper.setCc(InternetAddress.parse(toCC));
            // helper.setTo(toEmail);
            helper.setSubject(subject);
            helper.setText(body, true);
            helper.setFrom(emailFromAddress);
            helper.addAttachment(file.getName(), file);

            sender.send(mimeMessage);
            file.delete();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return false;
    }

    public boolean sendEmailwithAttachmentForMultipleRecipient(String toEmail, String body, String subject, File file, List<String> ccEmails) throws MessagingException {
        String[] ccEmailArray = (ccEmails != null) ? ccEmails.toArray(new String[0]) : null;

        MimeMessage mimeMessage = sender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, CharEncoding.UTF_8);
        try {

            helper.setTo(InternetAddress.parse(toEmail));
            helper.setCc(ccEmailArray);
            // helper.setTo(toEmail);
            helper.setSubject(subject);
            helper.setText(body, true);
            helper.setFrom(emailFromAddress);
            helper.addAttachment(file.getName(), file);

            sender.send(mimeMessage);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return false;
    }

    public boolean sendEmailwithAttachmentForStatement(List<String> toEmails, String body, String subject, File file, String ccEmail) throws MessagingException {
        String[] toEmailList = (toEmails != null) ? toEmails.toArray(new String[0]) : null;

        MimeMessage mimeMessage = sender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, CharEncoding.UTF_8);
        try {

            helper.setTo(toEmailList);
            helper.setCc(InternetAddress.parse(ccEmail));
            // helper.setTo(toEmail);
            helper.setSubject(subject);
            helper.setText(body, true);
            helper.setFrom(emailFromAddress);
            helper.addAttachment(file.getName(), file);

            sender.send(mimeMessage);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return false;
    }

    public Map<String, Object> getModelMapDataForEmailTemplate(NotificationEntity notificationEntity) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        try {
            Map<String, Object> mapData = mapper.readValue(notificationEntity.getMailParameters(), new TypeReference<Map<String, Object>>() {
            });
            Map<String, Object> model = new HashMap<>();
            model.put("title", notificationEntity.getNotificationTitle());
            if (notificationEntity.getFeatureName().equals(EmailTemplateEnum.Contract_Products_Template.getFeatureName())) {
                model.put("customerName", mapData.get("Customer"));
                model.put("contractNumber", mapData.get("Contract Number"));
                model.put("paymentMap", mapData.get("detailsMapData"));
            } else if (notificationEntity.getFeatureName().equals(EmailTemplateEnum.Contract_Template.getFeatureName())) {
                model.put("detailsMap", mapData);
            } else if (notificationEntity.getFeatureName().equals(EmailTemplateEnum.Opportunity_Template.getFeatureName())) {
                model.put("detailsMap", mapData);
            } else {
                model.put("detailsMap", mapData);
            }
            return model;
        } catch (Exception e) {
            logger.error("ECRM Bulk:EmailSenderService: getModelMapDataForEmailTemplate() Error: {}", e.getMessage());
            return null;
        }
    }

    public Boolean sendEmailForNotification(NotificationEntity notificationEntity) throws MessagingException, JsonProcessingException {
        if ((notificationEntity.getNotificationBody() == null || notificationEntity.getNotificationBody().equals(""))
                && (notificationEntity.getMailParameters() == null || notificationEntity.getMailParameters().equals(""))) {
            logger.error("ECRM Bulk:EmailSenderService: sendEmailForNotification() Error: Mail Body, Mail Parameters are null.");
            notificationEntity.setFailedReasonMsg("EmailSenderService: sendEmailForNotification() Error: Mail Body, Mail Parameters are null.");
            return false;
        }
        try {
            MimeMessage message = sender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED, StandardCharsets.UTF_8.name());
            if (!createMailBodyUsingEmailTemplate(notificationEntity, helper)) {
                logger.error("ECRM Bulk:EmailSenderService: sendEmailForNotification() Error: createMailBodyUsingEmailTemplate() Failed.");
                notificationEntity.setFailedReasonMsg("EmailSenderService: sendEmailForNotification() Error: createMailBodyUsingEmailTemplate() Failed.");
                return false;
            }
            helper.setFrom(emailFromAddress);

            if (notificationEntity.getRecipientEmailAddress() != null) {
                String[] recipientList = notificationEntity.getRecipientEmailAddress().split(",");
                if (recipientList.length == 0) {
                    logger.error("ECRM Bulk:EmailSenderService: sendEmailForNotification() Error: recipientList is empty.");
                    notificationEntity.setFailedReasonMsg("EmailSenderService: sendEmailForNotification() Error: recipientList is empty.");
                    return false;
                }
                helper.setTo(recipientList);
            }

            if (notificationEntity.getRecipientCCEmailList() != null) {
                String[] recipientCCList = notificationEntity.getRecipientCCEmailList().split(",");
                if (recipientCCList.length > 0) {
                    helper.setCc(recipientCCList);
                }
            }

            helper.setSubject(notificationEntity.getNotificationTitle());

            sender.send(message);
            return true;
        } catch (Exception e) {
            logger.error("ECRM Bulk:EmailSenderService: sendEmailForNotification() Error: {}", e.getMessage());
            notificationEntity.setFailedReasonMsg("EmailSenderService: sendEmailForNotification() Error: " + e.getMessage());
            return false;
        }

    }

    public Boolean createMailBodyUsingEmailTemplate(NotificationEntity notificationEntity, MimeMessageHelper helper) throws JsonProcessingException, MessagingException {
        try {
            Map<String, Object> model = getModelMapDataForEmailTemplate(notificationEntity);
            if (model == null) {
                logger.error("ECRM Bulk:EmailSenderService: createMailBodyUsingEmailTemplate() Mail Parameters Model is null.");
                return false;
            }
            String mailBody = null;
            EmailTemplateEnum emailTemplate = null;
            if (notificationEntity.getFeatureName().equals(EmailTemplateEnum.Contract_Products_Template.getFeatureName())) {
                emailTemplate = EmailTemplateEnum.Contract_Products_Template;
            } else if (notificationEntity.getFeatureName().equals(EmailTemplateEnum.Contract_Template.getFeatureName())) {
                emailTemplate = EmailTemplateEnum.Contract_Template;
            } else if (notificationEntity.getFeatureName().equals(EmailTemplateEnum.Opportunity_Template.getFeatureName())) {
                emailTemplate = EmailTemplateEnum.Opportunity_Template;
            } else if (notificationEntity.getMailParameters() == null || notificationEntity.getMailParameters().equals("")) {
                emailTemplate = null;
            }

            switch (emailTemplate) {
                case Contract_Products_Template:
                    helper.setText(thymleafService.createContent(EmailTemplateEnum.Contract_Products_Template.getTemplateName(), model), true);
                    mailBody = thymleafService.createContent(EmailTemplateEnum.Contract_Products_Template.getTemplateName(), model);
                    break;
                case Contract_Template:
                    helper.setText(thymleafService.createContent(EmailTemplateEnum.Contract_Template.getTemplateName(), model), true);
                    mailBody = thymleafService.createContent(EmailTemplateEnum.Contract_Template.getTemplateName(), model);
                    break;
                case Opportunity_Template:
                    helper.setText(thymleafService.createContent(EmailTemplateEnum.Opportunity_Template.getTemplateName(), model), true);
                    mailBody = thymleafService.createContent(EmailTemplateEnum.Opportunity_Template.getTemplateName(), model);
                    break;
                default:
                    //by default
                    helper.setText(thymleafService.createContent(EmailTemplateEnum.Contract_Template.getTemplateName(), model), true);
                    mailBody = thymleafService.createContent(EmailTemplateEnum.Contract_Template.getTemplateName(), model);
                    break;
            }
            String plainBodyText = Jsoup.parse(mailBody).text();
            notificationEntity.setNotificationBody(plainBodyText);
            return true;
        } catch (Exception e) {
            logger.error("ECRM Bulk:EmailSenderService: createMailBodyUsingEmailTemplate() Error: {}", e.getMessage());
            return false;
        }
    }

//    public boolean sendEmailForNotification(NotificationEntity notificationEntity) throws MessagingException {
//
//        String toEmail, String body, String subject, String toCC
//        notificationEntity.getRecipientAddress(), notificationEntity.getNotificationBody(), notificationEntity.getNotificationTitle(), ""
//
//
//        MimeMessage mimeMessage = sender.createMimeMessage();
//        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, CharEncoding.UTF_8);
//        try {
//
//            helper.setTo(InternetAddress.parse(toEmail));
//            helper.setCc(InternetAddress.parse(toCC));
//            // helper.setTo(toEmail);
//            helper.setSubject(subject);
//            helper.setText(body, true);
//            helper.setFrom(emailFromAddress);
//            //helper.addAttachment(file.getName(),file);
//
//            sender.send(mimeMessage);
//            //file.delete();
//            return true;
//        } catch (Exception e) {
//            e.printStackTrace();
//            logger.error(e.getMessage(), e);
//        }
//        return false;
//    }

}
