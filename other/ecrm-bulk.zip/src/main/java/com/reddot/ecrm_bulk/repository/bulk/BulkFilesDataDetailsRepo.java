package com.reddot.ecrm_bulk.repository.bulk;

import com.reddot.ecrm_bulk.entity.bulk.BulkUploadFileDetailsEntity;
import com.reddot.ecrm_bulk.entity.bulk.BulkUploadFilesEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BulkFilesDataDetailsRepo extends JpaRepository<BulkUploadFileDetailsEntity,Long> {
    List<BulkUploadFileDetailsEntity> findAllByBulkFileId(Long id);
}
