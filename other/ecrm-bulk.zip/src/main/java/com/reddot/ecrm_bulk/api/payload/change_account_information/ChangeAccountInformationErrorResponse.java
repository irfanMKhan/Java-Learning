package com.reddot.ecrm_bulk.api.payload.change_account_information;

import lombok.Data;

import java.io.Serializable;

@Data
public class ChangeAccountInformationErrorResponse implements Serializable {
  private Error error;

  @Data
  public static class Error implements Serializable {
    private String exception;

    private String code;

    private String detail;

    private String message;
  }
}
