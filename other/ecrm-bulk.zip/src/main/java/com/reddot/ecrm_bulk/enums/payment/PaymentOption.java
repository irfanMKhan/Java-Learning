package com.reddot.ecrm_bulk.enums.payment;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum PaymentOption {
    Prepayment("Prepayment"),
    Immediately("Immediately"),
    PromiseToPay("PTP"),
    NoDevice("NoDevice");

    private final String value;
}
