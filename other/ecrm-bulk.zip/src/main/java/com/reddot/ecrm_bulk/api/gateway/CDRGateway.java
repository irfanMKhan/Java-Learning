package com.reddot.ecrm_bulk.api.gateway;

import com.google.gson.Gson;
import com.reddot.ecrm_bulk.api.exception.ApiRequestException;
import com.reddot.ecrm_bulk.api.exception.InvalidAccessTokenException;
import com.reddot.ecrm_bulk.api.exception.InvalidClientCredentialsException;
import com.reddot.ecrm_bulk.api.payload.CDR.response.CDRDetailsErrorResponse;
import com.reddot.ecrm_bulk.api.payload.CDR.response.QueryCDRDetailResponse;
import com.reddot.ecrm_bulk.api.utils.CommonConstant;
import com.reddot.ecrm_bulk.api.utils.HttpClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class CDRGateway {
    private final HttpClient httpClient;
    private final Gson gson;
    private final AuthorizationGateway authorizationGateway;

    @Value("${smart.egw.base.url}")
    String baseUrlEGW;
    @Value("${smart.igw.base.url}")
    String baseUrlIGW;
    @Value("${smart.access.user}")
    String bss_username;
    @Value("${smart.access.password}")
    String bss_password;

    public QueryCDRDetailResponse queryCDRDetail(String subscriberId, String start_time, String end_time, int startRow, int totalRow, int fetchRow) {
        //need to check while we get creds
        String apiUrl = baseUrlIGW + "/api/igw/bss/cdr/v1/" + subscriberId + "?id_type=msisdn&" + "bss_username=" + bss_username + "&bss_password=" + bss_password + "&start_time=" + start_time + "&end_time=" + end_time + "&start_row=" + startRow + "&total_row=" + totalRow + "&fetch_row=" + fetchRow;

        try (Response response = httpClient.get(apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), QueryCDRDetailResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                CDRDetailsErrorResponse errorResponse = gson.fromJson(response.body().string(), CDRDetailsErrorResponse.class);
                throw new ApiRequestException(errorResponse.getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("queryCDRDetail Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("queryCDRDetail Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialsException) {
                log.debug("queryCDRDetail Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialsException(e.getMessage());
            }
            log.error("queryCDRDetail Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    // Headers
    private Map<String, String> getHeaders() {
        String bearerToken = authorizationGateway.getTokenEGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }

    private Map<String, String> getIGWHeaders() {
        String bearerToken = authorizationGateway.getTokenIGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }

}
