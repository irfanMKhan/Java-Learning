package com.reddot.ecrm_bulk.repository.approval;

import com.reddot.ecrm_bulk.entity.approval.ApprovalRequestEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ApprovalRequestRepo extends JpaRepository<ApprovalRequestEntity, Long> {
    Optional<ApprovalRequestEntity> findByIdAndUuidToken(Long id, String uuidToken);

    List<ApprovalRequestEntity> findAllByRequestDetailsIdAndContractNumber(Long reqDetailId, String contractNumber);

    List<ApprovalRequestEntity> findAllByRequestDetailsId(Long reqDetailId);

    List<ApprovalRequestEntity> findAllByRequestDetailsIdAndRequestTransactionId(Long reqDetailId,String reqTransactionId);
    List<ApprovalRequestEntity> findAllByRequestTransactionId(String  reqTransactionId);

    List<ApprovalRequestEntity> findAllByRequestedByOrderByRequestedAtDesc(Long reqId);

   /* @Query(value = "SELECT a FROM ApprovalRequestEntity a WHERE a.requestedBy = ?1 " +
            "AND ( CAST(a.requestedAtDt AS text) LIKE %?2% OR LOWER(a.approvalFlowName) LIKE %?2% OR " +
            "CAST(a.requestedAmount AS text) LIKE %?2% OR " +
            " LOWER(a.status) = ?2)"
    )
    Page<ApprovalRequestEntity> search(Long reqId, String search, Pageable pageable);*/


//    @Query(value = "SELECT * FROM tbl_approval_request WHERE requested_by=?1 and\n" +
//            "lower(requested_username) LIKE '%?2' or lower(requested_username) LIKE '%?2%' or lower(requested_username) LIKE '?2%' or\n" +
//            "requested_at_dt::text LIKE '%?2' or requested_at_dt::text LIKE '%?2%' or requested_at_dt::text LIKE '?2%' or\n" +
//            "lower(approval_flow_name) LIKE '%?2' or lower(approval_flow_name) LIKE '%?2%' or lower(approval_flow_name) LIKE '?2%' or\n" +
//            "lower(status) LIKE '%?2' or lower(status) LIKE '%?2%' or lower(status) LIKE '?2%';",nativeQuery = true)
//    Page<ApprovalRequestEntity> searchNativeQuery(Long reqId, String search,Pageable pageable);

//    @Query(value = "SELECT * FROM tbl_approval_request WHERE requested_by=?1 and\n" +
//            "lower(requested_username) LIKE %?2 or lower(requested_username) LIKE %?2% or lower(requested_username) LIKE ?2% or\n" +
//            "requested_at_dt::text LIKE %?2 or requested_at_dt::text LIKE %?2% or requested_at_dt::text LIKE ?2% or\n" +
//            "lower(approval_flow_name) LIKE %?2 or lower(approval_flow_name) LIKE %?2% or lower(approval_flow_name) LIKE ?2% or\n" +
//            "lower(status) LIKE %?2 or lower(status) LIKE %?2% or lower(status) LIKE ?2%;",nativeQuery = true)
//    Page<ApprovalRequestEntity> searchNativeQuery(Long reqId, String search,Pageable pageable);

    @Query(value = "SELECT * FROM approval_request WHERE requested_by=?1 and\n" +
            "(lower(requested_username) LIKE CONCAT('%', ?2, '%') or\n" +
            "CAST(requested_at_dt as TEXT) LIKE CONCAT('%', ?2, '%') or\n" +
            "CAST(requested_amount as TEXT) LIKE CONCAT('%', ?2, '%') or\n" +
            "lower(approval_flow_name) LIKE CONCAT('%', ?2, '%') or\n" +
            "lower(status) LIKE CONCAT('%', ?2, '%'))", nativeQuery = true)
    Page<ApprovalRequestEntity> searchNativeQuery(Long reqId, String search, Pageable pageable);


    @Query(value = "?1", nativeQuery = true)
    Page<ApprovalRequestEntity> searchNativeQuery1(String sql, Pageable pageable);


    Page<ApprovalRequestEntity> findAllByRequestedByOrderByRequestedAtDesc(Long reqId, Pageable pageable);


}