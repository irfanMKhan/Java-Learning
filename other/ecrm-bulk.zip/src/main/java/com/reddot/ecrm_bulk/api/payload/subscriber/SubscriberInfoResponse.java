package com.reddot.ecrm_bulk.api.payload.subscriber;

import lombok.Data;

import java.io.Serializable;

@Data
public class SubscriberInfoResponse implements Serializable {
  private Subscriber Subscriber;

  @Data
  public static class Subscriber implements Serializable {
    private String ICCID;

    private String SubType;

    private String ExpireDate;

    private String PartnerId;

    private String BrandId;

    private String WrittenLanguage;

    private String ServiceNum;

    private String SubId;

    private String Language;

    private String NetworkType;

    private String IMSI;

    private String SubStatus;

    @Data
    public static class AdditionalProperty implements Serializable {
      private String Value;

      private String Code;
    }
  }
}
