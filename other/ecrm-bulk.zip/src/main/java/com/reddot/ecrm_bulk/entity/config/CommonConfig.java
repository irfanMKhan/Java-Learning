package com.reddot.ecrm_bulk.entity.config;

import lombok.*;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "md_common_config", schema = "ecrm")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class CommonConfig {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "active")
    private Boolean active;

    @Column(name = "type_id")
    private Long typeId;

    @Column(name = "type_name")
    private String typeName;

    @Column(name = "sub_type_id")
    private Long subTypeId;

    @Column(name = "sub_type_name")
    private String subTypeName;

    @Column(name = "name ")
    private String name;

    @Column(name = "created_at")
    private Long createdAt;

    @Column(name = "created_at_dt")
    private Timestamp createdAtDt;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_by_username")
    private String createdByUsername;

    @Column(name = "updated_at")
    private Long updatedAt;

    @Column(name = "updated_at_dt")
    private Timestamp updatedAtDt;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_by_username")
    private String updatedByUsername;

    @Column(name = "api_value")
    private String apiValue;

    @Column(name = "is_fixed")
    private Boolean isFixed;
}
