package com.reddot.ecrm_bulk.service.contract;

import com.reddot.ecrm_bulk.entity.contract.BillMedium;

public interface BillMediumService {
    BillMedium findByContractIdAndServiceTypeName(Long contractId, String serviceTypeName);
}
