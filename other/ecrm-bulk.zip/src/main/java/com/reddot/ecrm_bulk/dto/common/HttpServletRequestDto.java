package com.reddot.ecrm_bulk.dto.common;

import com.reddot.ecrm_bulk.dto.user.MDUserModel;
import com.reddot.ecrm_bulk.dto.user.UserModel;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;

@Getter
@Setter
@Data
public class HttpServletRequestDto {
    private Long createdAt;
    private Timestamp createdAtDt;
    private Long createdBy;
    private String createdUsername;
    private Long updatedAt;
    private Timestamp updatedAtDt;
    private Long updatedBy;
    private String updatedUsername;
    private Long tenantId;
    private String ipAddress;
    private String serverIPAddress;
    private String sessionId;
    private MDUserModel mdUserModel;
    private UserModel kamUserModel;
    private Boolean isKamNotificationMail;
}
