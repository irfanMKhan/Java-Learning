package com.reddot.ecrm_bulk.model;

import java.sql.Timestamp;

public class LeadModel {

    private Long id;
    private String lead_number;
    private String customer_name;
    private Integer kam_id;
    private String kam_name;
    private String status_name;
    private Timestamp created_at_dt;
    private String kam_email;
    public Long getid() {
        return id;
    }
    public void setid(Long id) {
        this.id = id;
    }
    public String getlead_number() {
        return lead_number;
    }
    public void setlead_number(String lead_number) {
        this.lead_number = lead_number;
    }
    public String getcustomer_name() {
        return customer_name;
    }
    public void setcustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }
    public Integer getkam_id() {
        return kam_id;
    }
    public void setkam_id(Integer kam_id) {
        this.kam_id = kam_id;
    }
    public String getkam_name() {
        return kam_name;
    }
    public void setkam_name(String kam_name) {
        this.kam_name = kam_name;
    }
    public String getstatus_name() {
        return status_name;
    }
    public void setstatus_name(String status_name) {
        this.status_name = status_name;
    }
    public Timestamp getcreated_at_dt() {
        return created_at_dt;
    }
    public void setcreated_at_dt(Timestamp created_at_dt) {
        this.created_at_dt = created_at_dt;
    }
    public String getkam_email() {
        return kam_email;
    }
    public void setkam_email(String kam_email) {
        this.kam_email = kam_email;
    }

}

