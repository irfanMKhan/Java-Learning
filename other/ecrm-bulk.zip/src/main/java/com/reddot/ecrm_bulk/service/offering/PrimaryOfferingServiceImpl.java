package com.reddot.ecrm_bulk.service.offering;

import com.reddot.ecrm_bulk.entity.primary_offering.PrimaryOffering;
import com.reddot.ecrm_bulk.repository.offering.PrimaryOfferingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class PrimaryOfferingServiceImpl implements PrimaryOfferingService {
    private final PrimaryOfferingRepository primaryOfferingRepository;
    @Override
    public PrimaryOffering findByOfferingId(Long offeringId) {
        try {
            return primaryOfferingRepository.findByOfferingId(offeringId);
        } catch (Exception e) {
            if (e instanceof EmptyResultDataAccessException) {
                log.debug("Primary Offering not found with offering id: {}", offeringId);
            } else {
                log.error("Primary Offering findByOfferingId Error: {}", e.getMessage(), e.getCause());
            }
            return null;
        }
    }
}
