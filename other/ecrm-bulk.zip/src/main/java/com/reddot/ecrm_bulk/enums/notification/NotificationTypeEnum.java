package com.reddot.ecrm_bulk.enums.notification;

public enum NotificationTypeEnum {
    SMS,
    Mail
}
