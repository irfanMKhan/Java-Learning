package com.reddot.ecrm_bulk.api.exception;

public class PendingBusinessOrderException extends RuntimeException {
    public PendingBusinessOrderException(String message) {
        super(message);
    }

    public PendingBusinessOrderException(String message, Throwable throwable) {
        super(message, throwable);
    }
}
