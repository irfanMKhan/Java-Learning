package com.reddot.ecrm_bulk.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.gson.Gson;
import com.reddot.ecrm_bulk.api.gateway.CDRGateway;
import com.reddot.ecrm_bulk.api.gateway.SubscriberGateway;
import com.reddot.ecrm_bulk.api.payload.CDR.response.CDRAPIResponseDataDTO;
import com.reddot.ecrm_bulk.api.payload.CDR.response.QueryCDRDetailResponse;
import com.reddot.ecrm_bulk.api.payload.subscriber.*;
import com.reddot.ecrm_bulk.bulkFileDTO.CDRDetailApiRequestDTO;
import com.reddot.ecrm_bulk.bulkFileDTO.CDRJsonDataDTO;
import com.reddot.ecrm_bulk.bulkFileDTO.CDRReportingDataDTO;
import com.reddot.ecrm_bulk.dto.ReturnDTO;
import com.reddot.ecrm_bulk.dto.SwapSim.SwapJsonDataDTO;
import com.reddot.ecrm_bulk.dto.SwapSim.SwapSimDTO;
import com.reddot.ecrm_bulk.dto.subscriber.SubscriberDataDTO;
import com.reddot.ecrm_bulk.dto.user.UserModel;
import com.reddot.ecrm_bulk.entity.bulk.BulkUploadFileDetailsEntity;
import com.reddot.ecrm_bulk.entity.bulk.BulkUploadFilesEntity;
import com.reddot.ecrm_bulk.entity.company.Company;
import com.reddot.ecrm_bulk.entity.cr.CRMasterEntity;
import com.reddot.ecrm_bulk.entity.cr.CRMsisdnDetailsEntity;
import com.reddot.ecrm_bulk.enums.bulk.BulkProcessStatusEnum;
import com.reddot.ecrm_bulk.enums.requestType.CommonStatusEnum;
import com.reddot.ecrm_bulk.repository.bulk.BulkFileDataRepo;
import com.reddot.ecrm_bulk.repository.bulk.BulkFilesDataDetailsRepo;
import com.reddot.ecrm_bulk.repository.cr.CRDetailsRepo;
import com.reddot.ecrm_bulk.repository.cr.CRMSISDNDetailsRepo;
import com.reddot.ecrm_bulk.service.cdr.CDRReportingService;
import com.reddot.ecrm_bulk.service.company.CompanyService;
import com.reddot.ecrm_bulk.service.swapsim.SwapSimService;
import com.reddot.ecrm_bulk.service.user.UserService;
import com.reddot.ecrm_bulk.util.Utility;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BulkFileDataProcessService {

    private final CRDetailsRepo crDetailsRepo;
    private final CRMSISDNDetailsRepo crmsisdnDetailsRepoRepo;

    private final Logger logger = LoggerFactory.getLogger(getClass().getName());
    private final BulkFileDataRepo bulkFileDataRepo;
    private final BulkFilesDataDetailsRepo bulkFilesDataDetailsRepo;
    private final CDRGateway cdrGateway;
    private final CDRReportingService cdrReportingService;
    private final SwapSimService swapSimService;
    private final CompanyService companyService;
    private final UserService userService;
    private final Gson gson;

    private final SubscriberGateway subscriberGateway;

    @Value("${CDR.fetchRow}")
    String fetchRow;
    @Value("${CDR.startRow}")
    String startRow;
    @Value("${CDR.totalRow}")
    String totalRow;
    @Value("${CDR.address}")
    String address;

    @Value("${smart.bss.username}")
    String smart_bss_username;
    @Value("${smart.bss.password}")
    String smart_bss_password;
    @Value("${smart.query.supplementary.offering.partnerId}")
    String smart_partnerId;
    @Value("${smart.query.supplementary.offering.channel}")
    String smart_channelId;
    @Value("${smart.query.cr.lost.reasoncode}")
    String smart_reason_code;
    @Value("${smart.query.cr.lost.setflag}")
    String smart_reason_setFlag;
    @Value("${smart.query.cr.lost.productId}")
    String smart_reason_productId;
    @Value("${smart.query.supplementary.offering.transactionId}")
    String smart_transactionId;
    @Value("${smart.query.supplementary.offering.channel}")
    String smart_channel;


    public void processBulkFileDataService() {
        try {
            Map<String, List<BulkUploadFilesEntity>> fileEntities = fetchBulkFilesEntities();
            if (fileEntities == null) {
                logger.info("BulkFileDataProcessService:processBulkFileDataService fileEntities are empty");
            }
            for (Map.Entry<String, List<BulkUploadFilesEntity>> singleFileEntities : fileEntities.entrySet()) {
                String processTypeName = singleFileEntities.getKey();
                List<BulkUploadFilesEntity> entities = singleFileEntities.getValue();
                switch (processTypeName) {
                    case "CDR":
                        processingCDRFilesEntity(entities);
                        break;
                    case "SWAP":
                        processingSWAPFilesEntity(entities);
                        break;
                    case "Change Sim - Reset Network - Phone Stolen":
                        log.info("Bulk process for :: Change Sim - Reset Network - Phone Stolen started");
                        processingCRPFilesEntity(entities);
                        break;
                }

            }
        } catch (Exception e) {
            logger.error(String.format("BulkFileDataProcessService:processBulkFileDataService() Error: %s", e.getMessage()));
            e.printStackTrace();
        }

    }

    public Map<String, List<BulkUploadFilesEntity>> fetchBulkFilesEntities() {
        try {
            List<BulkUploadFilesEntity> filesEntities = bulkFileDataRepo.findAllByProcessStatus(BulkProcessStatusEnum.TODO);
            Map<String, List<BulkUploadFilesEntity>> groupedByFilesEntities = filesEntities.stream().collect(Collectors.groupingBy(BulkUploadFilesEntity::getProcessTypeName));
            return groupedByFilesEntities;
        } catch (Exception ex) {
            ex.printStackTrace();
            logger.error(String.format("BulkFileDataProcessService:fetchBulkFilesEntities() Error: %s", ex.getMessage()));
            return null;
        }

    }

    private ReturnDTO CRPDataProcessor(BulkUploadFileDetailsEntity fileDetailsEntity, String token, CRMasterEntity changeRequestDetails) {
        ReturnDTO returnDTO = new ReturnDTO();
        returnDTO.setIsMasterSuccess(true);
        try {
            String fileRowData = fileDetailsEntity.getFileRowData();
            SubscriberDataDTO subscriberDataDTO = gson.fromJson(fileRowData, SubscriberDataDTO.class);

            Company company = companyService.findCompanyById(fileDetailsEntity.getCompanyId());
            UserModel userModel = userService.getUserById(fileDetailsEntity.getCreatedBy());


            CRMsisdnDetailsEntity crMsisdnDetails = new CRMsisdnDetailsEntity();

            crMsisdnDetails.setChangeRequestMasterId(changeRequestDetails.getId());
            crMsisdnDetails.setCreatedAt(Utility.loggedInCurrentTime());

            Timestamp dateTimeStamp = new Timestamp(Utility.loggedInCurrentTime());
            crMsisdnDetails.setCreatedAtDt(dateTimeStamp);
            crMsisdnDetails.setCreatedBy(fileDetailsEntity.getCreatedBy());
            crMsisdnDetails.setCreatedUsername(fileDetailsEntity.getCreatedByUsername());

            crMsisdnDetails.setTransactionID(changeRequestDetails.getTransactionID());
            crMsisdnDetails.setRequestType(changeRequestDetails.getRequestType());
            crMsisdnDetails.setRequestTypeId(changeRequestDetails.getRequestTypeId());

            crMsisdnDetails.setMsisdn(subscriberDataDTO.getMsisdn());
            crMsisdnDetails.setRequestType(subscriberDataDTO.getProcess_type());
            crMsisdnDetails.setIccid(subscriberDataDTO.getIccid());
            crMsisdnDetails.setCompanyName(company.getName());
            crMsisdnDetails.setCompanyId(company.getId());

            if (Objects.equals(subscriberDataDTO.getProcess_type(), "Phone Stolen/ Reactive")) {

                if (Objects.equals(subscriberDataDTO.getStatus(), "Block")) {
                    ObjectMapper objectWriterRequest = new ObjectMapper();
                    objectWriterRequest.registerModule(new JavaTimeModule());

                    ReportLostRequest reportLostRequest = new ReportLostRequest();

                    reportLostRequest.setBss_info(new ReportLostRequest.bss_info(smart_bss_username, smart_bss_password, smart_partnerId));
                    reportLostRequest.setReport_lost(new ReportLostRequest.report_lost(Integer.valueOf(smart_reason_code)));
                    reportLostRequest.setChannel_id(Integer.valueOf(smart_channelId));
                    reportLostRequest.setTransaction_id(SequenceGeneratorService.generateSequenceNumberAsDateTime());

                    String jsonRequest = objectWriterRequest.writeValueAsString(reportLostRequest);
                    log.info("New Request -> phone Stolen / reactive add :: " + "For : " + subscriberDataDTO.getMsisdn() + " :: " + jsonRequest);

                    ReportLostResponse response = new ReportLostResponse();
                    try {
                        response = subscriberGateway.reportLost(subscriberDataDTO.getMsisdn(), reportLostRequest);
                        crMsisdnDetails.setStatus(String.valueOf(CommonStatusEnum.Complete));

                        ObjectWriter objectWriterResponse = new ObjectMapper().writer().withDefaultPrettyPrinter();
                        String jsonResponse = objectWriterResponse.writeValueAsString(response);
                        log.info("Response -> phone Stolen / reactive add :: " + jsonResponse);
                    } catch (Exception exception) {
                        returnDTO.setIsMasterSuccess(false);
                        crMsisdnDetails.setStatus(String.valueOf(CommonStatusEnum.Failed));
                        crMsisdnDetails.setFailedReason(exception.getMessage());
                        log.info("Response -> phone Stolen / reactive add :: " + subscriberDataDTO.getMsisdn() + " :: " + "Failed");
                    }
                } else {
                    ObjectMapper objectWriterRequest = new ObjectMapper();
                    objectWriterRequest.registerModule(new JavaTimeModule());

                    ReportLostRequest reportLostRequest = new ReportLostRequest();

                    reportLostRequest.setBss_info(new ReportLostRequest.bss_info(smart_bss_username, smart_bss_password, smart_partnerId));
                    reportLostRequest.setReport_lost(new ReportLostRequest.report_lost(Integer.valueOf(smart_reason_code)));
                    reportLostRequest.setChannel_id(Integer.valueOf(smart_channelId));
                    reportLostRequest.setTransaction_id(SequenceGeneratorService.generateSequenceNumberAsDateTime());

                    String jsonRequest = objectWriterRequest.writeValueAsString(reportLostRequest);
                    log.info("New Request -> phone Stolen / reactive add :: " + "For : " + subscriberDataDTO.getMsisdn() + " :: " + jsonRequest);

                    ReportLostResponse response = new ReportLostResponse();
                    try {
                        response = subscriberGateway.cancelLost(subscriberDataDTO.getMsisdn(), reportLostRequest);
                        crMsisdnDetails.setStatus(String.valueOf(CommonStatusEnum.Complete));

                        ObjectWriter objectWriterResponse = new ObjectMapper().writer().withDefaultPrettyPrinter();
                        String jsonResponse = objectWriterResponse.writeValueAsString(response);
                        log.info("Response -> phone Stolen / reactive add :: " + jsonResponse);
                    } catch (Exception exception) {
                        returnDTO.setIsMasterSuccess(false);
                        crMsisdnDetails.setStatus(String.valueOf(CommonStatusEnum.Failed));
                        crMsisdnDetails.setFailedReason(exception.getMessage());
                        log.info("Response -> phone Stolen / reactive add :: " + subscriberDataDTO.getMsisdn() + " :: " + "Failed");
                    }

                }

            }
            if (Objects.equals(subscriberDataDTO.getProcess_type(), "Change Sim")) {

                ObjectMapper objectWriterRequest = new ObjectMapper();
                objectWriterRequest.registerModule(new JavaTimeModule());

                ChangeSubscriberSIMRequest subscriberSIMRequest = new ChangeSubscriberSIMRequest();

                subscriberSIMRequest.setTransaction_id(SequenceGeneratorService.generateSequenceNumberAsDateTime());
                subscriberSIMRequest.setChangeSubSIMReqMsg(new ChangeSubscriberSIMRequest.ChangeSubSIMReqMsg(subscriberDataDTO.getNew_iccid(), subscriberDataDTO.getIccid(), smart_reason_code));

                String jsonRequest = objectWriterRequest.writeValueAsString(subscriberSIMRequest);
                log.info("New Request -> Change Sim :: " + "For : " + subscriberDataDTO.getMsisdn() + " :: " + jsonRequest);
                ChangeSubscriberSIMResponse response = new ChangeSubscriberSIMResponse();
                try {
                    response = subscriberGateway.changeSubscriberSIM(subscriberDataDTO.getMsisdn(), subscriberSIMRequest);
                    crMsisdnDetails.setStatus(String.valueOf(CommonStatusEnum.Complete));

                    ObjectWriter objectWriterResponse = new ObjectMapper().writer().withDefaultPrettyPrinter();
                    String jsonResponse = objectWriterResponse.writeValueAsString(response);
                    log.info("Response -> Change Sim :: " + jsonResponse);
                } catch (Exception exception) {
                    returnDTO.setIsMasterSuccess(false);
                    crMsisdnDetails.setStatus(String.valueOf(CommonStatusEnum.Failed));
                    crMsisdnDetails.setFailedReason(exception.getMessage());
                    log.info("Response -> Change Sim :: " + subscriberDataDTO.getMsisdn() + " :: " + "Failed");
                }


            }
            if (Objects.equals(subscriberDataDTO.getProcess_type(), "Reset Network")) {

                ObjectMapper objectWriterRequest = new ObjectMapper();
                objectWriterRequest.registerModule(new JavaTimeModule());

                ResetNetworkRequest resetNetworkRequest = new ResetNetworkRequest();

                resetNetworkRequest.setTransaction_id(SequenceGeneratorService.generateSequenceNumberAsDateTime());
                ResetNetworkRequest.ChangeNetworkSettingReqMsg temp = new ResetNetworkRequest.ChangeNetworkSettingReqMsg();
                temp.setNetworkSettingList(new ResetNetworkRequest.ChangeNetworkSettingReqMsg.NetworkSettingList(Integer.valueOf(smart_reason_productId), Integer.valueOf(smart_reason_setFlag)));

                resetNetworkRequest.setChangeNetworkSettingReqMsg(temp);

                String jsonRequest = objectWriterRequest.writeValueAsString(resetNetworkRequest);
                log.info("New Request -> Reset Network :: " + "For : " + subscriberDataDTO.getMsisdn() + " :: " + jsonRequest);


                ResetNetworkResponse response = new ResetNetworkResponse();
                try {
                    response = subscriberGateway.resetNetwork(subscriberDataDTO.getMsisdn(), resetNetworkRequest);
                    crMsisdnDetails.setStatus(String.valueOf(CommonStatusEnum.Complete));

                    ObjectWriter objectWriterResponse = new ObjectMapper().writer().withDefaultPrettyPrinter();
                    String jsonResponse = objectWriterResponse.writeValueAsString(response);
                    log.info("Response -> Reset Network :: " + jsonResponse);
                } catch (Exception exception) {
                    returnDTO.setIsMasterSuccess(false);
                    crMsisdnDetails.setStatus(String.valueOf(CommonStatusEnum.Failed));
                    crMsisdnDetails.setFailedReason(exception.getMessage());
                    log.info("Response -> Reset Network :: " + subscriberDataDTO.getMsisdn() + " :: " + "Failed");
                }
            }

            crmsisdnDetailsRepoRepo.save(crMsisdnDetails);


            fileDetailsEntity.setFinalStatus(BulkProcessStatusEnum.Success);
            bulkFilesDataDetailsRepo.save(fileDetailsEntity);

            returnDTO.setReturnValue(true);
            return returnDTO;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            fileDetailsEntity.setFinalStatus(BulkProcessStatusEnum.Failed);
            bulkFilesDataDetailsRepo.save(fileDetailsEntity);

            returnDTO.setReturnValue(false);
            return returnDTO;
        }
    }

    public void processingCRPFilesEntity(List<BulkUploadFilesEntity> filesEntityList) {
        try {
            String token;
            log.info("processingCRPFilesEntity :: Start ");
            for (BulkUploadFilesEntity singleFilesEntityList : filesEntityList) {

                CRMasterEntity changeRequestDetails = new CRMasterEntity();

                changeRequestDetails.setCompanyName(singleFilesEntityList.getCompanyName());
                Company companyEntity = companyService.findCompanyById(singleFilesEntityList.getCompanyId());
                changeRequestDetails.setCompanyId(companyEntity.getId());
                changeRequestDetails.setTransactionID(Utility.getTransactionNumber("R"));

                changeRequestDetails.setNumberOfLines(singleFilesEntityList.getTotalRows() - 1);

                changeRequestDetails.setFinalStatus(String.valueOf(CommonStatusEnum.Complete));
                changeRequestDetails.setCreatedAt(Utility.loggedInCurrentTime());
                Timestamp dateTime = new Timestamp(Utility.loggedInCurrentTime());
                changeRequestDetails.setCreatedAtDt(dateTime);
                changeRequestDetails.setCreatedBy(singleFilesEntityList.getCreatedBy());
                changeRequestDetails.setCreatedUsername(singleFilesEntityList.getCreatedByUsername());
                changeRequestDetails.setIsBulkFile(true);
                changeRequestDetails = crDetailsRepo.save(changeRequestDetails);


                List<BulkUploadFileDetailsEntity> fileDetailsEntities = bulkFilesDataDetailsRepo.findAllByBulkFileId(singleFilesEntityList.getId());
                token = singleFilesEntityList.getUuidToken();
                Integer counter = 0;
                boolean isMasterSuccess = true;
                ReturnDTO returnDTO = new ReturnDTO();
                log.info("processingCRPFilesEntity :: for individual details :: start");
                for (BulkUploadFileDetailsEntity fileDetailsEntity : fileDetailsEntities) {

                    SubscriberDataDTO subscriberDataDTO = gson.fromJson(fileDetailsEntity.getFileRowData(), SubscriberDataDTO.class);
                    changeRequestDetails.setRequestType(subscriberDataDTO.getProcess_type());

                    returnDTO = CRPDataProcessor(fileDetailsEntity, token, changeRequestDetails);
                    if (returnDTO.getReturnValue()) {
                        counter = counter + 1;
                    } else {
                        isMasterSuccess = false;
                    }
                }
                log.info("processingCRPFilesEntity :: for individual details :: end");

                if (returnDTO.getIsMasterSuccess()) {
                    changeRequestDetails.setFinalStatus(String.valueOf(CommonStatusEnum.Success));
                } else {
                    changeRequestDetails.setFinalStatus(String.valueOf(CommonStatusEnum.Failed));
                }
                changeRequestDetails = crDetailsRepo.save(changeRequestDetails);

                //bulk file entity update part
                singleFilesEntityList.setSuccessRows(counter);
                singleFilesEntityList.setFailedRows(singleFilesEntityList.getTotalRows() - counter);
                singleFilesEntityList.setProcessStatus(BulkProcessStatusEnum.Complete);
                bulkFileDataRepo.save(singleFilesEntityList);
            }
            log.info("processingCRPFilesEntity :: end ");
        } catch (Exception e) {
            logger.error(String.format("BulkFileDataProcessService:processingSWAPFilesEntity() Error: %s", e.getMessage()));
            e.printStackTrace();
        }
    }


    public void processingSWAPFilesEntity(List<BulkUploadFilesEntity> filesEntityList) {
        try {
            String token;
            for (BulkUploadFilesEntity singleFilesEntityList : filesEntityList) {
                if (null==singleFilesEntityList.getScheduleTime() || singleFilesEntityList.getScheduleTime().equals(LocalDate.now())) {

                    List<BulkUploadFileDetailsEntity> fileDetailsEntities = bulkFilesDataDetailsRepo.findAllByBulkFileId(singleFilesEntityList.getId());
                    token = singleFilesEntityList.getUuidToken();
                    Integer counter = 0;
                    for (BulkUploadFileDetailsEntity singleFileDetailsEntities : fileDetailsEntities) {
                        Boolean isSuccess = swapDataProcessor(singleFileDetailsEntities, token);
                        if (isSuccess) {
                            counter = counter + 1;
                        }
                    }
                    //bulk file entity update part
                    singleFilesEntityList.setSuccessRows(counter);
                    singleFilesEntityList.setFailedRows(singleFilesEntityList.getTotalRows() - counter);
                    singleFilesEntityList.setProcessStatus(BulkProcessStatusEnum.Complete);
                    bulkFileDataRepo.save(singleFilesEntityList);
                }
            }
        } catch (Exception e) {
            logger.error(String.format("BulkFileDataProcessService:processingSWAPFilesEntity() Error: %s", e.getMessage()));
            e.printStackTrace();
        }
    }

    public void processingCDRFilesEntity(List<BulkUploadFilesEntity> filesEntityList) {
        try {
            String token;
            for (BulkUploadFilesEntity singleFilesEntityList : filesEntityList) {
                if (null==singleFilesEntityList.getScheduleTime() || singleFilesEntityList.getScheduleTime().equals(LocalDate.now())) {
                    List<BulkUploadFileDetailsEntity> fileDetailsEntities = bulkFilesDataDetailsRepo.findAllByBulkFileId(singleFilesEntityList.getId());
                    token = singleFilesEntityList.getUuidToken();
                    Integer counter = 0;
                    for (BulkUploadFileDetailsEntity singleFileDetailsEntities : fileDetailsEntities) {
                        Boolean isSuccess = generateCDRReport(singleFileDetailsEntities, token);
                        if (isSuccess) {
                            counter = counter + 1;
                        }
                    }
                    //bulk file entity update part
                    singleFilesEntityList.setSuccessRows(counter);
                    singleFilesEntityList.setFailedRows(singleFilesEntityList.getTotalRows() - counter);
                    singleFilesEntityList.setProcessStatus(BulkProcessStatusEnum.Complete);
                    bulkFileDataRepo.save(singleFilesEntityList);
                }
            }
        } catch (Exception e) {
            logger.error(String.format("BulkFileDataProcessService:processingCDRFilesEntity() Error: %s", e.getMessage()));
            e.printStackTrace();
        }
    }

    private Boolean generateCDRReport(BulkUploadFileDetailsEntity singleBulkUploadFileDetailsEntity, String token) {
        //70204337
        try {
            String fileRowData = singleBulkUploadFileDetailsEntity.getFileRowData();
            CDRJsonDataDTO cdrJsonDataDTO = gson.fromJson(fileRowData, CDRJsonDataDTO.class);
            cdrJsonDataDTO.setUsage_type(cdrJsonDataDTO.getUsage_type());
            //dateTimeString.substring(0, 8) + "235959";
            //CDR api request prepare
            CDRDetailApiRequestDTO cdrDetailApiRequestDTO = new CDRDetailApiRequestDTO();
            String endDate = getDateFormat(cdrJsonDataDTO.getEnd_date());
            endDate = endDate.substring(0, 8) + "235959";
            cdrDetailApiRequestDTO.setMsisdn(cdrJsonDataDTO.getMsisdn());
            cdrDetailApiRequestDTO.setStart_time(getDateFormat(cdrJsonDataDTO.getStart_date()));
            cdrDetailApiRequestDTO.setEnd_time(endDate);
            cdrDetailApiRequestDTO.setFetchRow(fetchRow);
            cdrDetailApiRequestDTO.setStartRow(startRow);
            cdrDetailApiRequestDTO.setTotalRow(totalRow);
            //CDR API Call
            QueryCDRDetailResponse queryCDRDetail = cdrGateway.queryCDRDetail(cdrDetailApiRequestDTO.getMsisdn(), cdrDetailApiRequestDTO.getStart_time(), cdrDetailApiRequestDTO.getEnd_time(), Integer.parseInt(cdrDetailApiRequestDTO.getStartRow()), Integer.parseInt(cdrDetailApiRequestDTO.getTotalRow()), Integer.parseInt(cdrDetailApiRequestDTO.getFetchRow()));

            List<CDRAPIResponseDataDTO> data = mapSourcesToDestinations(queryCDRDetail.getQueryCDRResult().getCDRInfo(), cdrJsonDataDTO);

            //CDR reporting data prepare
            CDRReportingDataDTO cdrReportingDataDTO = new CDRReportingDataDTO();
            cdrReportingDataDTO.setAccountNumber(cdrDetailApiRequestDTO.getMsisdn());
            cdrReportingDataDTO.setPrintDate(LocalDate.now().toString());
            cdrReportingDataDTO.setFromDate(cdrJsonDataDTO.getStart_date());
            cdrReportingDataDTO.setToDate(cdrJsonDataDTO.getEnd_date());
            cdrReportingDataDTO.setAddress(address);
            cdrReportingDataDTO.setFileType(cdrJsonDataDTO.getFile_type());
            cdrReportingDataDTO.setToken(token);
            cdrReportingDataDTO.setDetailTableId(singleBulkUploadFileDetailsEntity.getId());
            cdrReportingDataDTO.setDataList(data);
            System.out.println(queryCDRDetail);
            cdrReportingService.generateCDRReport(cdrReportingDataDTO);
            singleBulkUploadFileDetailsEntity.setFinalStatus(BulkProcessStatusEnum.Success);
            bulkFilesDataDetailsRepo.save(singleBulkUploadFileDetailsEntity);
            return true;
        } catch (JRException e) {
            System.out.println(e.getMessage());
            singleBulkUploadFileDetailsEntity.setFinalStatus(BulkProcessStatusEnum.Failed);
            bulkFilesDataDetailsRepo.save(singleBulkUploadFileDetailsEntity);
            return false;
        }
    }

    public String getDateFormat(String date) {

        SimpleDateFormat inputDateFormat = new SimpleDateFormat("dd-MM-yyyyy");
        SimpleDateFormat outputDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");

        String outputDateStr = null;
        try {
            Date inputDate = inputDateFormat.parse(date);
            inputDate.setHours(0);
            inputDate.setMinutes(0);
            inputDate.setSeconds(0);
            outputDateStr = outputDateFormat.format(inputDate);
            System.out.println("Output Date String: " + outputDateStr);
        } catch (ParseException e) {
            e.printStackTrace();
            logger.error("CDRService: getDateFormat:{0} " + e.getMessage());
        }

        return outputDateStr;
    }

    public List<CDRAPIResponseDataDTO> mapSourcesToDestinations(List<QueryCDRDetailResponse.CDRInfo> cdrInfoList, CDRJsonDataDTO cdrJsonDataDTO) {
        List<CDRAPIResponseDataDTO> cdrDataList = new ArrayList<>();
        try {

            if (cdrInfoList == null) {
                throw new RuntimeException("BulkFileDataProcessService: mapSourcesToDestinations() cdrInfoList is null");

            }
            for (QueryCDRDetailResponse.CDRInfo cdrInfo : cdrInfoList) {
                CDRAPIResponseDataDTO sampleDummyData = new CDRAPIResponseDataDTO();
                if (cdrInfo.getStartTime() != null) {
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");

                    sampleDummyData.setDate(cdrInfo.getStartTime().substring(0, 8));
                    sampleDummyData.setDate(String.valueOf(LocalDate.parse(sampleDummyData.getDate(), formatter)));

                    sampleDummyData.setTime(cdrInfo.getStartTime().substring(8, 10) + ":" + cdrInfo.getStartTime().substring(10, 12) + ":" + cdrInfo.getStartTime().substring(12, 14));
                }
                if (cdrInfo.getChargeDuration() != null) {
                    sampleDummyData.setDurationOrAmount(cdrInfo.getChargeDuration());
                } else sampleDummyData.setDurationOrAmount("");

                if (cdrInfo.getOtherNumber() != null) {
                    sampleDummyData.setCalledNumber(cdrInfo.getOtherNumber().toString());
                } else sampleDummyData.setCalledNumber("");

                if (cdrInfo.getChargeDetail() != null) {
                    if (cdrInfo.getChargeDetail().getChargeAmount() != null) {
                        sampleDummyData.setAmountUSD(cdrInfo.getChargeDetail().getChargeAmount());
                    } else sampleDummyData.setAmountUSD("");

                    if (cdrInfo.getChargeDetail().getChargeCodeName() != null) {
                        if (cdrInfo.getSeriveType().equals("4")) {
                            sampleDummyData.setDestination(cdrInfo.getChargeDetail().getChargeCodeName());
                        }
                    } else sampleDummyData.setDestination(" ");


                } else {
                    sampleDummyData.setAmountUSD("");
                    sampleDummyData.setDestination(" ");
                }

                //usage data mapping and filtering
                if (cdrJsonDataDTO.getUsage_type().equalsIgnoreCase("All")) {
                    cdrDataList.add(sampleDummyData);
                }
                if (cdrJsonDataDTO.getUsage_type().equalsIgnoreCase("CALL")) {
                    if (cdrInfo.getSeriveType().equals("10") || cdrInfo.getSeriveType().equals("11") || cdrInfo.getSeriveType().equals("12") || cdrInfo.getSeriveType().equals("13") || cdrInfo.getSeriveType().equals("14") || cdrInfo.getSeriveType().equals("15")) {
                        cdrDataList.add(sampleDummyData);
                    }
                }
                if (cdrJsonDataDTO.getUsage_type().equalsIgnoreCase("DATA")) {
                    if (cdrInfo.getSeriveType().equals("31") || cdrInfo.getSeriveType().equals("33")) {
                        cdrDataList.add(sampleDummyData);
                    }
                }
                if (cdrJsonDataDTO.getUsage_type().equalsIgnoreCase("other")) {
                    if (cdrInfo.getSeriveType().equals("21") || cdrInfo.getSeriveType().equals("22") || cdrInfo.getSeriveType().equals("24") || cdrInfo.getSeriveType().equals("24") || cdrInfo.getSeriveType().equals("25") || cdrInfo.getSeriveType().equals("26") || cdrInfo.getSeriveType().equals("27")) {
                        cdrDataList.add(sampleDummyData);
                    }
                }


            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("CDRService: mapSourcesToDestinations: {0}" + e.getMessage());
        }
        return cdrDataList;
    }

    private Boolean swapDataProcessor(BulkUploadFileDetailsEntity singleBulkUploadFileDetailsEntity, String token) {
        try {
            String fileRowData = singleBulkUploadFileDetailsEntity.getFileRowData();
            SwapJsonDataDTO swapJsonDataDTO = gson.fromJson(fileRowData, SwapJsonDataDTO.class);

            Company company = companyService.findCompanyByName(swapJsonDataDTO.getCompanyname().trim());
            UserModel userModel = userService.getUserById(singleBulkUploadFileDetailsEntity.getCreatedBy());

            SwapSimDTO data = swapJsonDataToSwapDTO(swapJsonDataDTO);
            data.setCompanyName(company.getName());
            data.setCompanyId(company.getId());
            data.setTenant_id(userModel.getTenant_id());

            swapSimService.swap(data, singleBulkUploadFileDetailsEntity);

            singleBulkUploadFileDetailsEntity.setFinalStatus(BulkProcessStatusEnum.Success);
            bulkFilesDataDetailsRepo.save(singleBulkUploadFileDetailsEntity);
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            singleBulkUploadFileDetailsEntity.setFinalStatus(BulkProcessStatusEnum.Failed);
            bulkFilesDataDetailsRepo.save(singleBulkUploadFileDetailsEntity);
            return false;
        }
    }

    public SwapSimDTO swapJsonDataToSwapDTO(SwapJsonDataDTO swapJsonDataDTO) {
        SwapSimDTO swapSimDTO = new SwapSimDTO();
        swapSimDTO.setNewMsisdn(swapJsonDataDTO.getNewmsisdn());
        swapSimDTO.setOldMsisdn(swapJsonDataDTO.getOldmsisdn());
        swapSimDTO.setNewIccId(swapJsonDataDTO.getNewiccid());
        swapSimDTO.setOldIccId(swapJsonDataDTO.getOldiccid());
        swapSimDTO.setFinancialTypeText(swapJsonDataDTO.getFinancialtypetext());
        swapSimDTO.setServiceCharge(Double.parseDouble(swapJsonDataDTO.getServicecharge()));
        swapSimDTO.setFinancialTypeAmount(Double.parseDouble(swapJsonDataDTO.getFinancialtypeamount()));
        swapSimDTO.setFinalCost(Double.parseDouble(swapJsonDataDTO.getFinalcost()));
        swapSimDTO.setPtp(swapJsonDataDTO.getPtp());
        swapSimDTO.setPtpDate(swapJsonDataDTO.getPtp_date());
        swapSimDTO.setPtpDays(Integer.parseInt(swapJsonDataDTO.getPtpdays()));
        swapSimDTO.setFileLocation(swapJsonDataDTO.getFilelocation());
        swapSimDTO.setSwapType(swapJsonDataDTO.getSwaptype());
        swapSimDTO.setAccountCode(swapJsonDataDTO.getAccountcode());
        return swapSimDTO;
    }

}
