package com.reddot.ecrm_bulk.model;

import java.io.Serializable;

public class TBLSRModel implements Serializable {

    private Long ID;

    private String SR_NUM;

    private String ACCOUNT_NAME;


    private String CONTACT_NAME;


    private String MSISDN;


    private Long SR_SERVICE_TYPE_ID;


    private String SR_SERVICE_TYPE_NAME;


    private Long SR_TYPE_ID;


    private String SR_TYPE_NAME;


    private Long SR_AREA_ID;


    private String SR_AREA_NAME;


    private Long SR_SUB_AREA_ID;


    private String SR_SUB_AREA_NAME;


    private Long SRC_ID;


    private String SRC_NAME;


    private Long SRC_LOCATION_ID;


    private String SRC_LOCATION_NAME;


    private Long SLA_HR;


    private Integer FIRST_CALL_RESOLVED;


    private String CELL_NAME;


    private Long ACC_TYPE_ID;


    private String ACC_TYPE_NAME;


    private Long PRIORITY_ID;


    private String PRIORITY_NAME;


    private Long SEVERITY_ID;


    private String SEVERITY_NAME;


    private Long LOG_BY;


    private String LOG_BY_NAME;


    private Long COMMITED_BY;


    private String COMMITED_BY_NAME;


    private Long PAR_SR_ID;


    private String PAR_SR_NUM;


    private String REFERENCE_COMPLAINT;
    private Long REFERENCE_COMPLAINT_COUNT;


    private Integer MASTER_ISSUE;


    private Long SR_STATUS_ID;


    private String SR_STATUS_NAME;


    private Long SR_SUB_STATUS_ID;


    private String SR_SUB_STATUS_NAME;


    private Long OWNER_GROUP_ID;


    private String OWNER_GROUP_NAME;

    private Long OWNER_ID;
    private String OWNER_NAME;
    private String OWNER_EMAIL;
    private Long ADDRESS_ID;
    private Long SLA_STOP_TIME;
    private Long SLA_DURATION_HR;
    private String DURATION_IN_HR;
    private String IS_NETWORK;

    private String BRAND_NAME;
    private String DIVISION;
    private String DISTRICT;
    private String THANA;

    public Long getREFERENCE_COMPLAINT_COUNT() {
        return REFERENCE_COMPLAINT_COUNT;
    }

    public void setREFERENCE_COMPLAINT_COUNT(Long REFERENCE_COMPLAINT_COUNT) {
        this.REFERENCE_COMPLAINT_COUNT = REFERENCE_COMPLAINT_COUNT;
    }

    public String getDIVISION() {
        return DIVISION;
    }

    public void setDIVISION(String DIVISION) {
        this.DIVISION = DIVISION;
    }

    public String getDISTRICT() {
        return DISTRICT;
    }

    public void setDISTRICT(String DISTRICT) {
        this.DISTRICT = DISTRICT;
    }

    public String getTHANA() {
        return THANA;
    }

    public void setTHANA(String THANA) {
        this.THANA = THANA;
    }

    public String getDURATION_IN_HR() {
        return DURATION_IN_HR;
    }

    public void setDURATION_IN_HR(String DURATION_IN_HR) {
        this.DURATION_IN_HR = DURATION_IN_HR;
    }

    public String getBRAND_NAME() {
        return BRAND_NAME;
    }

    public void setBRAND_NAME(String BRAND_NAME) {
        this.BRAND_NAME = BRAND_NAME;
    }

    public String getIS_NETWORK() {
        return IS_NETWORK;
    }

    public void setIS_NETWORK(String IS_NETWORK) {
        this.IS_NETWORK = IS_NETWORK;
    }

    public Long getSLA_STOP_TIME() {
        return SLA_STOP_TIME;
    }

    public void setSLA_STOP_TIME(Long SLA_STOP_TIME) {
        this.SLA_STOP_TIME = SLA_STOP_TIME;
    }

    public Long getSLA_DURATION_HR() {
        return SLA_DURATION_HR;
    }

    public void setSLA_DURATION_HR(Long SLA_DURATION_HR) {
        this.SLA_DURATION_HR = SLA_DURATION_HR;
    }

    public Long getADDRESS_ID() {
        return ADDRESS_ID;
    }

    public void setADDRESS_ID(Long ADDRESS_ID) {
        this.ADDRESS_ID = ADDRESS_ID;
    }

    public Long getOWNER_ID() {
        return OWNER_ID;
    }

    public void setOWNER_ID(Long OWNER_ID) {
        this.OWNER_ID = OWNER_ID;
    }

    public String getOWNER_NAME() {
        return OWNER_NAME;
    }

    public void setOWNER_NAME(String OWNER_NAME) {
        this.OWNER_NAME = OWNER_NAME;
    }

    public String getOWNER_EMAIL() {
        return OWNER_EMAIL;
    }

    public void setOWNER_EMAIL(String OWNER_EMAIL) {
        this.OWNER_EMAIL = OWNER_EMAIL;
    }

    private Long ESCALATED_BY;


    private String ESCALATED_BY_NAME;


    private Long RESOLVED_BY;


    private String RESOLVED_BY_NAME;


    private Long CLOSED_BY;


    private String CLOSED_BY_NAME;


    private Long ACCEPTED_BY;


    private String ACCEPTED_BY_NAME;


    private String REMEDY_INCIDENT_NO;


    private String FULL_ADDRESS;


    private String SUMMARY;


    private String DESCRIPTION;


    private Long ROOT_CAUSE_ID;


    private String ROOT_CAUSE_NAME;


    private String ROOT_CAUSE_DETAIL;


    private String RESOLUTION_SOLUTION;


    private String ESC_CANCEL_REASON;


    private Long ACC_CLASS_ID;


    private String ACC_CLASS_NAME;


    private String ADDRESS;


    private Long REOPEN_BY;


    private String REOPEN_BY_NAME;


    private Long SUBMITTED_BY;


    private String SUBMITTED_BY_NAME;


    private String CON_MOBILE_PHONE;


    private String CON_EMAIL;


    private Integer NOTIFICATION_EMAIL;


    private Integer NOTIFICATION_CALL;


    private Integer NOTIFICATION_SMS;


    private Integer IS_ESCALATED;


    private Integer IS_FEEDBACK_RECEIVED;


    private String FEEDBACK_TYPE;


    private Integer IS_WRONG_CLASSIFICATION;


    private Integer IS_REOPENED;


    private String REMARKS;


    private String ACTIVE;


    private Long CREATED_BY;


    private String CREATED_BY_USERNAME;


    private Long UPDATED_BY;


    private String UPDATED_BY_USERNAME;


    private Long UPDATED_BY_APP;


    private String UPDATED_BY_NAME_APP;


    private Long LOG_AT;


    private Long COMMITED_AT;


    private Long APPOINTMENT_DT;


    private Long ESCALATED_AT;


    private Long RESOLVED_AT;


    private Long CLOSED_AT;


    private Long ACCEPTED_AT;


    private Long REOPEN_AT;


    private Long SUBMITTED_AT;


    private Long PROBLEM_SINCE;


    private Long PROBLEM_TILL;


    private Long KEEPINVIEW_DATE;


    private Long CREATED_AT;


    private Long UPDATED_AT;


    private Long UPDATED_AT_APP;

    private Boolean ReopenPermitted = false;

    public Boolean getReopenPermitted() {
        return ReopenPermitted;
    }

    public void setReopenPermitted(Boolean reopenPermitted) {
        ReopenPermitted = reopenPermitted;
    }

    public Long getID() {
        return ID;
    }

    public void setID(Long ID) {
        this.ID = ID;
    }

    public String getSR_NUM() {
        return SR_NUM;
    }

    public void setSR_NUM(String SR_NUM) {
        this.SR_NUM = SR_NUM;
    }

    public String getACCOUNT_NAME() {
        return ACCOUNT_NAME;
    }

    public void setACCOUNT_NAME(String ACCOUNT_NAME) {
        this.ACCOUNT_NAME = ACCOUNT_NAME;
    }

    public String getCONTACT_NAME() {
        return CONTACT_NAME;
    }

    public void setCONTACT_NAME(String CONTACT_NAME) {
        this.CONTACT_NAME = CONTACT_NAME;
    }

    public String getMSISDN() {
        return MSISDN;
    }

    public void setMSISDN(String MSISDN) {
        this.MSISDN = MSISDN;
    }

    public Long getSR_SERVICE_TYPE_ID() {
        return SR_SERVICE_TYPE_ID;
    }

    public void setSR_SERVICE_TYPE_ID(Long SR_SERVICE_TYPE_ID) {
        this.SR_SERVICE_TYPE_ID = SR_SERVICE_TYPE_ID;
    }

    public String getSR_SERVICE_TYPE_NAME() {
        return SR_SERVICE_TYPE_NAME;
    }

    public void setSR_SERVICE_TYPE_NAME(String SR_SERVICE_TYPE_NAME) {
        this.SR_SERVICE_TYPE_NAME = SR_SERVICE_TYPE_NAME;
    }

    public Long getSR_TYPE_ID() {
        return SR_TYPE_ID;
    }

    public void setSR_TYPE_ID(Long SR_TYPE_ID) {
        this.SR_TYPE_ID = SR_TYPE_ID;
    }

    public String getSR_TYPE_NAME() {
        return SR_TYPE_NAME;
    }

    public void setSR_TYPE_NAME(String SR_TYPE_NAME) {
        this.SR_TYPE_NAME = SR_TYPE_NAME;
    }

    public Long getSR_AREA_ID() {
        return SR_AREA_ID;
    }

    public void setSR_AREA_ID(Long SR_AREA_ID) {
        this.SR_AREA_ID = SR_AREA_ID;
    }

    public String getSR_AREA_NAME() {
        return SR_AREA_NAME;
    }

    public void setSR_AREA_NAME(String SR_AREA_NAME) {
        this.SR_AREA_NAME = SR_AREA_NAME;
    }

    public Long getSR_SUB_AREA_ID() {
        return SR_SUB_AREA_ID;
    }

    public void setSR_SUB_AREA_ID(Long SR_SUB_AREA_ID) {
        this.SR_SUB_AREA_ID = SR_SUB_AREA_ID;
    }

    public String getSR_SUB_AREA_NAME() {
        return SR_SUB_AREA_NAME;
    }

    public void setSR_SUB_AREA_NAME(String SR_SUB_AREA_NAME) {
        this.SR_SUB_AREA_NAME = SR_SUB_AREA_NAME;
    }

    public Long getSRC_ID() {
        return SRC_ID;
    }

    public void setSRC_ID(Long SRC_ID) {
        this.SRC_ID = SRC_ID;
    }

    public String getSRC_NAME() {
        return SRC_NAME;
    }

    public void setSRC_NAME(String SRC_NAME) {
        this.SRC_NAME = SRC_NAME;
    }

    public Long getSRC_LOCATION_ID() {
        return SRC_LOCATION_ID;
    }

    public void setSRC_LOCATION_ID(Long SRC_LOCATION_ID) {
        this.SRC_LOCATION_ID = SRC_LOCATION_ID;
    }

    public String getSRC_LOCATION_NAME() {
        return SRC_LOCATION_NAME;
    }

    public void setSRC_LOCATION_NAME(String SRC_LOCATION_NAME) {
        this.SRC_LOCATION_NAME = SRC_LOCATION_NAME;
    }

    public Long getSLA_HR() {
        return SLA_HR;
    }

    public void setSLA_HR(Long SLA_HR) {
        this.SLA_HR = SLA_HR;
    }

    public Integer getFIRST_CALL_RESOLVED() {
        return FIRST_CALL_RESOLVED;
    }

    public void setFIRST_CALL_RESOLVED(Integer FIRST_CALL_RESOLVED) {
        this.FIRST_CALL_RESOLVED = FIRST_CALL_RESOLVED;
    }

    public String getCELL_NAME() {
        return CELL_NAME;
    }

    public void setCELL_NAME(String CELL_NAME) {
        this.CELL_NAME = CELL_NAME;
    }

    public Long getACC_TYPE_ID() {
        return ACC_TYPE_ID;
    }

    public void setACC_TYPE_ID(Long ACC_TYPE_ID) {
        this.ACC_TYPE_ID = ACC_TYPE_ID;
    }

    public String getACC_TYPE_NAME() {
        return ACC_TYPE_NAME;
    }

    public void setACC_TYPE_NAME(String ACC_TYPE_NAME) {
        this.ACC_TYPE_NAME = ACC_TYPE_NAME;
    }

    public Long getPRIORITY_ID() {
        return PRIORITY_ID;
    }

    public void setPRIORITY_ID(Long PRIORITY_ID) {
        this.PRIORITY_ID = PRIORITY_ID;
    }

    public String getPRIORITY_NAME() {
        return PRIORITY_NAME;
    }

    public void setPRIORITY_NAME(String PRIORITY_NAME) {
        this.PRIORITY_NAME = PRIORITY_NAME;
    }

    public Long getSEVERITY_ID() {
        return SEVERITY_ID;
    }

    public void setSEVERITY_ID(Long SEVERITY_ID) {
        this.SEVERITY_ID = SEVERITY_ID;
    }

    public String getSEVERITY_NAME() {
        return SEVERITY_NAME;
    }

    public void setSEVERITY_NAME(String SEVERITY_NAME) {
        this.SEVERITY_NAME = SEVERITY_NAME;
    }

    public Long getLOG_BY() {
        return LOG_BY;
    }

    public void setLOG_BY(Long LOG_BY) {
        this.LOG_BY = LOG_BY;
    }

    public String getLOG_BY_NAME() {
        return LOG_BY_NAME;
    }

    public void setLOG_BY_NAME(String LOG_BY_NAME) {
        this.LOG_BY_NAME = LOG_BY_NAME;
    }

    public Long getCOMMITED_BY() {
        return COMMITED_BY;
    }

    public void setCOMMITED_BY(Long COMMITED_BY) {
        this.COMMITED_BY = COMMITED_BY;
    }

    public String getCOMMITED_BY_NAME() {
        return COMMITED_BY_NAME;
    }

    public void setCOMMITED_BY_NAME(String COMMITED_BY_NAME) {
        this.COMMITED_BY_NAME = COMMITED_BY_NAME;
    }

    public Long getPAR_SR_ID() {
        return PAR_SR_ID;
    }

    public void setPAR_SR_ID(Long PAR_SR_ID) {
        this.PAR_SR_ID = PAR_SR_ID;
    }

    public String getPAR_SR_NUM() {
        return PAR_SR_NUM;
    }

    public void setPAR_SR_NUM(String PAR_SR_NUM) {
        this.PAR_SR_NUM = PAR_SR_NUM;
    }

    public String getREFERENCE_COMPLAINT() {
        return REFERENCE_COMPLAINT;
    }

    public void setREFERENCE_COMPLAINT(String REFERENCE_COMPLAINT) {
        this.REFERENCE_COMPLAINT = REFERENCE_COMPLAINT;
    }

    public Integer getMASTER_ISSUE() {
        return MASTER_ISSUE;
    }

    public void setMASTER_ISSUE(Integer MASTER_ISSUE) {
        this.MASTER_ISSUE = MASTER_ISSUE;
    }

    public Long getSR_STATUS_ID() {
        return SR_STATUS_ID;
    }

    public void setSR_STATUS_ID(Long SR_STATUS_ID) {
        this.SR_STATUS_ID = SR_STATUS_ID;
    }

    public String getSR_STATUS_NAME() {
        return SR_STATUS_NAME;
    }

    public void setSR_STATUS_NAME(String SR_STATUS_NAME) {
        this.SR_STATUS_NAME = SR_STATUS_NAME;
    }

    public Long getSR_SUB_STATUS_ID() {
        return SR_SUB_STATUS_ID;
    }

    public void setSR_SUB_STATUS_ID(Long SR_SUB_STATUS_ID) {
        this.SR_SUB_STATUS_ID = SR_SUB_STATUS_ID;
    }

    public String getSR_SUB_STATUS_NAME() {
        return SR_SUB_STATUS_NAME;
    }

    public void setSR_SUB_STATUS_NAME(String SR_SUB_STATUS_NAME) {
        this.SR_SUB_STATUS_NAME = SR_SUB_STATUS_NAME;
    }

    public Long getOWNER_GROUP_ID() {
        return OWNER_GROUP_ID;
    }

    public void setOWNER_GROUP_ID(Long OWNER_GROUP_ID) {
        this.OWNER_GROUP_ID = OWNER_GROUP_ID;
    }

    public String getOWNER_GROUP_NAME() {
        return OWNER_GROUP_NAME;
    }

    public void setOWNER_GROUP_NAME(String OWNER_GROUP_NAME) {
        this.OWNER_GROUP_NAME = OWNER_GROUP_NAME;
    }

    public Long getESCALATED_BY() {
        return ESCALATED_BY;
    }

    public void setESCALATED_BY(Long ESCALATED_BY) {
        this.ESCALATED_BY = ESCALATED_BY;
    }

    public String getESCALATED_BY_NAME() {
        return ESCALATED_BY_NAME;
    }

    public void setESCALATED_BY_NAME(String ESCALATED_BY_NAME) {
        this.ESCALATED_BY_NAME = ESCALATED_BY_NAME;
    }

    public Long getRESOLVED_BY() {
        return RESOLVED_BY;
    }

    public void setRESOLVED_BY(Long RESOLVED_BY) {
        this.RESOLVED_BY = RESOLVED_BY;
    }

    public String getRESOLVED_BY_NAME() {
        return RESOLVED_BY_NAME;
    }

    public void setRESOLVED_BY_NAME(String RESOLVED_BY_NAME) {
        this.RESOLVED_BY_NAME = RESOLVED_BY_NAME;
    }

    public Long getCLOSED_BY() {
        return CLOSED_BY;
    }

    public void setCLOSED_BY(Long CLOSED_BY) {
        this.CLOSED_BY = CLOSED_BY;
    }

    public String getCLOSED_BY_NAME() {
        return CLOSED_BY_NAME;
    }

    public void setCLOSED_BY_NAME(String CLOSED_BY_NAME) {
        this.CLOSED_BY_NAME = CLOSED_BY_NAME;
    }

    public Long getACCEPTED_BY() {
        return ACCEPTED_BY;
    }

    public void setACCEPTED_BY(Long ACCEPTED_BY) {
        this.ACCEPTED_BY = ACCEPTED_BY;
    }

    public String getACCEPTED_BY_NAME() {
        return ACCEPTED_BY_NAME;
    }

    public void setACCEPTED_BY_NAME(String ACCEPTED_BY_NAME) {
        this.ACCEPTED_BY_NAME = ACCEPTED_BY_NAME;
    }

    public String getREMEDY_INCIDENT_NO() {
        return REMEDY_INCIDENT_NO;
    }

    public void setREMEDY_INCIDENT_NO(String REMEDY_INCIDENT_NO) {
        this.REMEDY_INCIDENT_NO = REMEDY_INCIDENT_NO;
    }

    public String getFULL_ADDRESS() {
        return FULL_ADDRESS;
    }

    public void setFULL_ADDRESS(String FULL_ADDRESS) {
        this.FULL_ADDRESS = FULL_ADDRESS;
    }

    public String getSUMMARY() {
        return SUMMARY;
    }

    public void setSUMMARY(String SUMMARY) {
        this.SUMMARY = SUMMARY;
    }

    public String getDESCRIPTION() {
        return DESCRIPTION;
    }

    public void setDESCRIPTION(String DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }

    public Long getROOT_CAUSE_ID() {
        return ROOT_CAUSE_ID;
    }

    public void setROOT_CAUSE_ID(Long ROOT_CAUSE_ID) {
        this.ROOT_CAUSE_ID = ROOT_CAUSE_ID;
    }

    public String getROOT_CAUSE_NAME() {
        return ROOT_CAUSE_NAME;
    }

    public void setROOT_CAUSE_NAME(String ROOT_CAUSE_NAME) {
        this.ROOT_CAUSE_NAME = ROOT_CAUSE_NAME;
    }

    public String getROOT_CAUSE_DETAIL() {
        return ROOT_CAUSE_DETAIL;
    }

    public void setROOT_CAUSE_DETAIL(String ROOT_CAUSE_DETAIL) {
        this.ROOT_CAUSE_DETAIL = ROOT_CAUSE_DETAIL;
    }

    public String getRESOLUTION_SOLUTION() {
        return RESOLUTION_SOLUTION;
    }

    public void setRESOLUTION_SOLUTION(String RESOLUTION_SOLUTION) {
        this.RESOLUTION_SOLUTION = RESOLUTION_SOLUTION;
    }

    public String getESC_CANCEL_REASON() {
        return ESC_CANCEL_REASON;
    }

    public void setESC_CANCEL_REASON(String ESC_CANCEL_REASON) {
        this.ESC_CANCEL_REASON = ESC_CANCEL_REASON;
    }

    public Long getACC_CLASS_ID() {
        return ACC_CLASS_ID;
    }

    public void setACC_CLASS_ID(Long ACC_CLASS_ID) {
        this.ACC_CLASS_ID = ACC_CLASS_ID;
    }

    public String getACC_CLASS_NAME() {
        return ACC_CLASS_NAME;
    }

    public void setACC_CLASS_NAME(String ACC_CLASS_NAME) {
        this.ACC_CLASS_NAME = ACC_CLASS_NAME;
    }

    public String getADDRESS() {
        return ADDRESS;
    }

    public void setADDRESS(String ADDRESS) {
        this.ADDRESS = ADDRESS;
    }

    public Long getREOPEN_BY() {
        return REOPEN_BY;
    }

    public void setREOPEN_BY(Long REOPEN_BY) {
        this.REOPEN_BY = REOPEN_BY;
    }

    public String getREOPEN_BY_NAME() {
        return REOPEN_BY_NAME;
    }

    public void setREOPEN_BY_NAME(String REOPEN_BY_NAME) {
        this.REOPEN_BY_NAME = REOPEN_BY_NAME;
    }

    public Long getSUBMITTED_BY() {
        return SUBMITTED_BY;
    }

    public void setSUBMITTED_BY(Long SUBMITTED_BY) {
        this.SUBMITTED_BY = SUBMITTED_BY;
    }

    public String getSUBMITTED_BY_NAME() {
        return SUBMITTED_BY_NAME;
    }

    public void setSUBMITTED_BY_NAME(String SUBMITTED_BY_NAME) {
        this.SUBMITTED_BY_NAME = SUBMITTED_BY_NAME;
    }

    public String getCON_MOBILE_PHONE() {
        return CON_MOBILE_PHONE;
    }

    public void setCON_MOBILE_PHONE(String CON_MOBILE_PHONE) {
        this.CON_MOBILE_PHONE = CON_MOBILE_PHONE;
    }

    public String getCON_EMAIL() {
        return CON_EMAIL;
    }

    public void setCON_EMAIL(String CON_EMAIL) {
        this.CON_EMAIL = CON_EMAIL;
    }

    public Integer getNOTIFICATION_EMAIL() {
        return NOTIFICATION_EMAIL;
    }

    public void setNOTIFICATION_EMAIL(Integer NOTIFICATION_EMAIL) {
        this.NOTIFICATION_EMAIL = NOTIFICATION_EMAIL;
    }

    public Integer getNOTIFICATION_CALL() {
        return NOTIFICATION_CALL;
    }

    public void setNOTIFICATION_CALL(Integer NOTIFICATION_CALL) {
        this.NOTIFICATION_CALL = NOTIFICATION_CALL;
    }

    public Integer getNOTIFICATION_SMS() {
        return NOTIFICATION_SMS;
    }

    public void setNOTIFICATION_SMS(Integer NOTIFICATION_SMS) {
        this.NOTIFICATION_SMS = NOTIFICATION_SMS;
    }

    public Integer getIS_ESCALATED() {
        return IS_ESCALATED;
    }

    public void setIS_ESCALATED(Integer IS_ESCALATED) {
        this.IS_ESCALATED = IS_ESCALATED;
    }

    public Integer getIS_FEEDBACK_RECEIVED() {
        return IS_FEEDBACK_RECEIVED;
    }

    public void setIS_FEEDBACK_RECEIVED(Integer IS_FEEDBACK_RECEIVED) {
        this.IS_FEEDBACK_RECEIVED = IS_FEEDBACK_RECEIVED;
    }

    public String getFEEDBACK_TYPE() {
        return FEEDBACK_TYPE;
    }

    public void setFEEDBACK_TYPE(String FEEDBACK_TYPE) {
        this.FEEDBACK_TYPE = FEEDBACK_TYPE;
    }

    public Integer getIS_WRONG_CLASSIFICATION() {
        return IS_WRONG_CLASSIFICATION;
    }

    public void setIS_WRONG_CLASSIFICATION(Integer IS_WRONG_CLASSIFICATION) {
        this.IS_WRONG_CLASSIFICATION = IS_WRONG_CLASSIFICATION;
    }

    public Integer getIS_REOPENED() {
        return IS_REOPENED;
    }

    public void setIS_REOPENED(Integer IS_REOPENED) {
        this.IS_REOPENED = IS_REOPENED;
    }

    public String getREMARKS() {
        return REMARKS;
    }

    public void setREMARKS(String REMARKS) {
        this.REMARKS = REMARKS;
    }

    public String getACTIVE() {
        return ACTIVE;
    }

    public void setACTIVE(String ACTIVE) {
        this.ACTIVE = ACTIVE;
    }

    public Long getCREATED_BY() {
        return CREATED_BY;
    }

    public void setCREATED_BY(Long CREATED_BY) {
        this.CREATED_BY = CREATED_BY;
    }

    public String getCREATED_BY_USERNAME() {
        return CREATED_BY_USERNAME;
    }

    public void setCREATED_BY_USERNAME(String CREATED_BY_USERNAME) {
        this.CREATED_BY_USERNAME = CREATED_BY_USERNAME;
    }

    public Long getUPDATED_BY() {
        return UPDATED_BY;
    }

    public void setUPDATED_BY(Long UPDATED_BY) {
        this.UPDATED_BY = UPDATED_BY;
    }

    public String getUPDATED_BY_USERNAME() {
        return UPDATED_BY_USERNAME;
    }

    public void setUPDATED_BY_USERNAME(String UPDATED_BY_USERNAME) {
        this.UPDATED_BY_USERNAME = UPDATED_BY_USERNAME;
    }

    public Long getUPDATED_BY_APP() {
        return UPDATED_BY_APP;
    }

    public void setUPDATED_BY_APP(Long UPDATED_BY_APP) {
        this.UPDATED_BY_APP = UPDATED_BY_APP;
    }

    public String getUPDATED_BY_NAME_APP() {
        return UPDATED_BY_NAME_APP;
    }

    public void setUPDATED_BY_NAME_APP(String UPDATED_BY_NAME_APP) {
        this.UPDATED_BY_NAME_APP = UPDATED_BY_NAME_APP;
    }

    public Long getLOG_AT() {
        return LOG_AT;
    }

    public void setLOG_AT(Long LOG_AT) {
        this.LOG_AT = LOG_AT;
    }

    public Long getCOMMITED_AT() {
        return COMMITED_AT;
    }

    public void setCOMMITED_AT(Long COMMITED_AT) {
        this.COMMITED_AT = COMMITED_AT;
    }

    public Long getAPPOINTMENT_DT() {
        return APPOINTMENT_DT;
    }

    public void setAPPOINTMENT_DT(Long APPOINTMENT_DT) {
        this.APPOINTMENT_DT = APPOINTMENT_DT;
    }

    public Long getESCALATED_AT() {
        return ESCALATED_AT;
    }

    public void setESCALATED_AT(Long ESCALATED_AT) {
        this.ESCALATED_AT = ESCALATED_AT;
    }

    public Long getRESOLVED_AT() {
        return RESOLVED_AT;
    }

    public void setRESOLVED_AT(Long RESOLVED_AT) {
        this.RESOLVED_AT = RESOLVED_AT;
    }

    public Long getCLOSED_AT() {
        return CLOSED_AT;
    }

    public void setCLOSED_AT(Long CLOSED_AT) {
        this.CLOSED_AT = CLOSED_AT;
    }

    public Long getACCEPTED_AT() {
        return ACCEPTED_AT;
    }

    public void setACCEPTED_AT(Long ACCEPTED_AT) {
        this.ACCEPTED_AT = ACCEPTED_AT;
    }

    public Long getREOPEN_AT() {
        return REOPEN_AT;
    }

    public void setREOPEN_AT(Long REOPEN_AT) {
        this.REOPEN_AT = REOPEN_AT;
    }

    public Long getSUBMITTED_AT() {
        return SUBMITTED_AT;
    }

    public void setSUBMITTED_AT(Long SUBMITTED_AT) {
        this.SUBMITTED_AT = SUBMITTED_AT;
    }

    public Long getPROBLEM_SINCE() {
        return PROBLEM_SINCE;
    }

    public void setPROBLEM_SINCE(Long PROBLEM_SINCE) {
        this.PROBLEM_SINCE = PROBLEM_SINCE;
    }

    public Long getPROBLEM_TILL() {
        return PROBLEM_TILL;
    }

    public void setPROBLEM_TILL(Long PROBLEM_TILL) {
        this.PROBLEM_TILL = PROBLEM_TILL;
    }

    public Long getKEEPINVIEW_DATE() {
        return KEEPINVIEW_DATE;
    }

    public void setKEEPINVIEW_DATE(Long KEEPINVIEW_DATE) {
        this.KEEPINVIEW_DATE = KEEPINVIEW_DATE;
    }

    public Long getCREATED_AT() {
        return CREATED_AT;
    }

    public void setCREATED_AT(Long CREATED_AT) {
        this.CREATED_AT = CREATED_AT;
    }

    public Long getUPDATED_AT() {
        return UPDATED_AT;
    }

    public void setUPDATED_AT(Long UPDATED_AT) {
        this.UPDATED_AT = UPDATED_AT;
    }

    public Long getUPDATED_AT_APP() {
        return UPDATED_AT_APP;
    }

    public void setUPDATED_AT_APP(Long UPDATED_AT_APP) {
        this.UPDATED_AT_APP = UPDATED_AT_APP;
    }
}
