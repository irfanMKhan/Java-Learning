package com.reddot.ecrm_bulk.enums.bulk;

public enum BulkProcessStatusEnum {
    Success,
    Failed,
    Pre_Process,
    Partial_Success,
    TODO,
    Complete,
    Pending //not submitted
}
