package com.reddot.ecrm_bulk.service.company;

import com.reddot.ecrm_bulk.dto.contract.ContractInfo;
import com.reddot.ecrm_bulk.entity.annex.Annex;
import com.reddot.ecrm_bulk.entity.contract.Contract;
import com.reddot.ecrm_bulk.entity.msisdn.MSISDN;

import java.util.List;

public interface MSISDNService {
    MSISDN findByMSISDN(String msisdn);

    List<MSISDN> findAllByMSISDN(String msisdn);

    MSISDN save(MSISDN msisdn);

    MSISDN update(MSISDN msisdn);

    void insertMSISDN(Contract contract, Annex annex, ContractInfo contractInfo);
}
