package com.reddot.ecrm_bulk.service.number_activation.strategy.payment;

import com.reddot.ecrm_bulk.enums.payment.PaymentOption;

public interface PaymentStrategyFactory {
    PaymentStrategy createPaymentStrategy(PaymentOption paymentOption);
}
