package com.reddot.ecrm_bulk.enums.approval;

public enum ApprovalRequestStatusEnum {
    PENDING,
    APPROVED,
    REJECTED,
    SUBMITTED,
    DelegationExpired,
    DelegateUserExecuted
}
