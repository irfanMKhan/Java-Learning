package com.reddot.ecrm_bulk.entity.bulk;

import com.reddot.ecrm_bulk.enums.bulk.BulkProcessStatusEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "bulk_file_details")
public class BulkUploadFileDetailsEntity extends AbstractEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "bulk_file_id")
    private Long bulkFileId;
    @Column(name = "process_type_id")
    private Integer processTypeId;
    @Column(name = "process_type_name")
    private String processTypeName;
    @Column(name = "file_row_data")
    private String fileRowData;
    @Column(name = "file_row_num")
    private Integer fileRowNum;

    @Enumerated(EnumType.STRING)
    @Column(name = "final_status")
    private BulkProcessStatusEnum finalStatus;
    @Column(name = "failed_reason")
    private String failedReason;
    @Column(name = "orderid")
    private Long orderID;
    @Column(name = "is_active")
    private Boolean isActive;
    private String description;
    @Column(name = "company_id")
    private Long companyId;
    @Column(name = "company_name")
    private String companyName;

}
