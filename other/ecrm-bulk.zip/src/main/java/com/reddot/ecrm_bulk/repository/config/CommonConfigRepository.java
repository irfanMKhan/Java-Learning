package com.reddot.ecrm_bulk.repository.config;

import com.reddot.ecrm_bulk.entity.company.Company;
import com.reddot.ecrm_bulk.entity.config.CommonConfig;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import java.util.List;

@Repository
public class CommonConfigRepository {
    @PersistenceContext
    private EntityManager entityManager;

    public String findNameByIdAndTypeNameAndSubTypeName(Long id, String typeName, String subTypeName) {
        TypedQuery<String> query = entityManager.createQuery(
                "SELECT cc.name from CommonConfig cc where cc.id = :id and cc.typeName = :typeName and cc.subTypeName = :subTypeName",
                String.class);
        return query.setParameter("id", id)
                .setParameter("typeName", typeName)
                .setParameter("subTypeName", subTypeName)
                .getSingleResult();
    }
}
