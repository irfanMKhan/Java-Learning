package com.reddot.ecrm_bulk.enums.requestType;

import lombok.Getter;

import java.util.AbstractMap;
import java.util.Map;

@Getter
public enum RequestTypeEnum {
    Add_New_Number("Add New Number", 1001),
    Change_Plan("Change Plan", 1002),
    Add_Remove_Service("Add Remove Service", 1003),
    Increase_Decrease_Credit_Limit("Increase / Decrease Credit Limit", 1004),
    Terminate("Terminate", 1005),
    Postpaid_To_Prepaid("Postpaid To Prepaid", 1006),
    WP_Add_New_Number("Add New Number WP", 1007),
    WP_Change_Plan("Change Plan WP", 1008),
    WP_Add_Remove_Service("Add Remove Service WP", 1009),
    WP_Increase_Decrease_Credit_Limit("Increase / Decrease Credit Limit WP", 1010),
    WP_Terminate("Terminate WP", 1011),
    WP_Postpaid_To_Prepaid("Postpaid To Prepaid WP", 1012),

    CHANGE_SIM("CHANGE_SIM", 1013),
    Phone_Stolen_Reactive("Phone_Stolen_Reactive", 1014),
    RESET_NETWORK("RESET_NETWORK", 1015),
    Change_Branch("Change Branch", 1016),
    Join_CUG("Join CUG", 1017),

    HOT_BILL("HotBill", 3000),

    SWAP_SIM("SwapSim", 4000),
    Create_Order("CreateOrder", 4001),

    Contract("Contract", 5001),
    Opportunity("Opportunity", 5002),
    Lead("Lead", 5003);


    private final String key;
    private final int value;

    RequestTypeEnum(String key, int value) {
        this.key = key;
        this.value = value;
    }

    public Map.Entry<String, Integer> getBoth() {
        return new AbstractMap.SimpleEntry<>(key, value);
    }

}
