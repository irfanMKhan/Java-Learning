package com.reddot.ecrm_bulk.repository.delegation;


import com.reddot.ecrm_bulk.entity.delegation.DelegationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface DelegationRepo extends JpaRepository<DelegationEntity, Long> {
    List<DelegationEntity> findAllByDelegatorId(Long id);

    List<DelegationEntity> findAllByStartDateEqualsAndIsActiveAndHasDelegateAllPendingMail(LocalDate today,Boolean isActive, Boolean hasDelegateAllPendingMail);

    List<DelegationEntity> findAllByEndDateEqualsAndIsActiveAndHasAssignedMailBack(LocalDate today, Boolean isActive, Boolean hasDelegateAllPendingMail);

}
