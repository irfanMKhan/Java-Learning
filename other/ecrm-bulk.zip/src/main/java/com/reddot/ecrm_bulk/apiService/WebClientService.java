package com.reddot.ecrm_bulk.apiService;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Map;

import javax.xml.parsers.DocumentBuilderFactory;

import com.reddot.ecrm_bulk.model.token.ECRMTokenModel;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;


@Service
public class WebClientService {

    @Value("${apigate.baseurl}")
    static String baseurll;
    private static final Logger logger = LoggerFactory.getLogger(WebClientService.class);


    public static String HttpTokenRequest() {
        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        params.add("grant_type", "password");
        params.add("username", "username");
        params.add("password", "password");
        params.add("scope", "PRODUCTION");
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "Basic dfdsfsdfsdfsd");
        HttpEntity<MultiValueMap> request = new HttpEntity<MultiValueMap>(params, headers);
        return restTemplate.exchange("https://apigate.smart.com.kh/token", HttpMethod.POST, request, String.class).getBody();
    }


    public static ResponseEntity<String> HttpRequestGetData(String baseurl, String auth, String RequestType) {
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> res = null;
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", auth);
        HttpEntity<String> requestAll = new HttpEntity<String>(headers);
        try {
            res = restTemplate.exchange(baseurl, HttpRequestType(RequestType), requestAll, String.class);
        } catch (Exception e) {
            logger.warn(baseurl + ":: " + e.getMessage());
            System.out.println("Error: " + e.getMessage());
        }
        return res;
    }


    public static ResponseEntity<String> HttpPOSTRequest(String url, MultiValueMap<String, String> par, String token) {
        ResponseEntity<String> res = null;
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        if (token != "") {
            headers.add("Authorization", "Bearer " + token);
        }
        headers.add("Content-Type", "application/x-www-form-urlencoded");
        HttpEntity<MultiValueMap> request = new HttpEntity<MultiValueMap>(par, headers);
        try {
            res = restTemplate.exchange(url, HttpMethod.POST, request, String.class);
        } catch (Exception e) {
            logger.warn(url + ":: " + e.getMessage());
            System.out.println("Error: " + e.getMessage());
        }
        return res;
    }

    public static ResponseEntity<String> HttpPUTRequest(String url, MultiValueMap<String, String> par, String token) {
        ResponseEntity<String> res = null;
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        if (token != "") {
            headers.add("Authorization", "Bearer " + token);
        }
        headers.add("Content-Type", "application/x-www-form-urlencoded");
        HttpEntity<MultiValueMap> request = new HttpEntity<MultiValueMap>(par, headers);
        try {
            res = restTemplate.exchange(url, HttpMethod.PUT, request, String.class);
        } catch (Exception e) {
            logger.warn(url + ":: " + e.getMessage());
            System.out.println("Error: " + e.getMessage());
        }
        return res;
    }

    public static HttpMethod HttpRequestType(String Type) {
        if (Type.equals("GET")) {
            return HttpMethod.GET;
        } else if (Type.equals("POST")) {
            return HttpMethod.POST;
        } else {
            return null;
        }
    }


    public static ECRMTokenModel getTokenRequestForDCRM() {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.add("username", "username");
        headers.add("password", "password");
        headers.add("Content-Type", "application/json");
        HttpEntity entity = new HttpEntity(headers);
        ECRMTokenModel tList = null;
        try {
            tList = restTemplate.exchange("https://ecrm.smart.com.kh/ecrmapi/authenticate", HttpMethod.GET, entity, ECRMTokenModel.class).getBody();
        } catch (Exception e) {
            logger.warn(e.getMessage());
        }

        return tList;
    }


    public static ResponseEntity<String> HttpPOSTRequestDCRM(String url, JSONObject req, String token) {
        ResponseEntity<String> res = null;
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        if (token != "") {
            headers.add("Authorization", token);
        }
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<String> entity = new HttpEntity<String>(req.toString(), headers);
        try {
            res = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
            logger.info(req.toString(),res.toString());
        } catch (Exception e) {
            logger.warn(url + ":: " + e.getMessage());
            System.out.println("Error: " + e.getMessage());
        }
        return res;
    }

    public static ResponseEntity<String> HttpPOSTRequestDCRMNew(String url, JSONObject req, String token) {
        ResponseEntity<String> res = null;
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        if(token!="") {
            headers.add("Authorization", token);
        }
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        HttpEntity<String> entity = new HttpEntity<String>(req.toString(), headers);
        try {
            res = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
        } catch (Exception e) {
//			logger.warn(url + ":: "+e.getMessage());
            logger.info(url);
            logger.error(e.getMessage(), e);
            System.out.println("Error: " + e.getMessage());
        }
        return res;
    }


    public static String HttpPost(String url, String token, String dtocda) throws IOException {

        CloseableHttpClient httpClient = HttpClients.createDefault();

        try {

            HttpPost request = new HttpPost(url);
            request.addHeader("Content-Type", "application/json");
            request.addHeader("username", "username");
            request.addHeader("password", "password");

            // add request headers
            request.addHeader("Content-Type", "application/json");
            if (token != null || !token.equals("")) {
                request.addHeader("Authorization", "Bearer " + token);
            }
            request.setEntity(new StringEntity(dtocda));
            CloseableHttpResponse response = httpClient.execute(request);

            try {

                org.apache.http.HttpEntity entity = response.getEntity();
                if (entity != null) {
                    // return it as a String
                    String result = EntityUtils.toString(entity);

                    System.out.println(result);
                    return result;
                }

            } finally {
                response.close();
            }
        } finally {
            httpClient.close();
        }

        return "";
    }


    public static ResponseEntity<String> getRequest(String url) {
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> result = null;
        URI uri;
        try {
            uri = new URI(url);
            result = restTemplate.getForEntity(uri, String.class);
        } catch (URISyntaxException e) {
            e.printStackTrace();
            logger.warn(e.getMessage(), e);
        }
        return result;
    }

    public static ResponseEntity<String> getRequestWithToken(String url, String token) {
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> result = null;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add("Authorization", "Bearer " + token);
//			headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> entity = new HttpEntity<String>(headers);
            result = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
        } catch (Exception e) {
            logger.warn(url + ":: " + e.getMessage());
        }
        return result;
    }

    public static ResponseEntity<String> getRequestWithOutToken(String url) {
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> result = null;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> entity = new HttpEntity<String>(headers);
            result = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
        } catch (Exception e) {
            logger.warn(url + ":: " + e.getMessage());
        }
        return result;
    }

    public static Element HttpPOSTRequestDCRMXML(String url, String contents) {
        Element err = null;
        try {
            logger.info(contents.toString());
            String charset = "UTF-8";
            URLConnection connection = new URL(url).openConnection();
            connection.setDoOutput(true);
            connection.setRequestProperty("Accept-Charset", charset);
            connection.setRequestProperty("Content-Type", "application/json;charset=" + charset);
            OutputStream output = connection.getOutputStream();
            output.write(contents.getBytes(charset));
            output.close();
            InputStream response = connection.getInputStream();
            BufferedReader in = new BufferedReader(new InputStreamReader(response));
            String inputLine;
            StringBuffer resp = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                resp.append(inputLine.trim());
            }
            in.close();

            logger.info(resp.toString());

            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder()
                    .parse(new InputSource(new StringReader(resp.toString())));
            NodeList errNodes = doc.getElementsByTagName("S:Envelope");
            if (errNodes.getLength() > 0) {
                err = (Element) errNodes.item(0);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return err;
    }

    public static ResponseEntity<String> httpPostRequestWithHeaderMap(String url, JSONObject req, Map<String, String> headerInfo) {
        ResponseEntity<String> res = null;
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        for (String key : headerInfo.keySet()) {
            headers.add(key, headerInfo.get(key));
        }
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<String>(req.toString(), headers);
        try {
            res = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return res;
    }

    public static ResponseEntity<String> AdjustmentFreeUnitBulk(String api, JSONObject req) {
        ResponseEntity<String> res = null;
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.add("username", "username");
        headers.add("password", "password");
        headers.add("Content-Type", "application/json");
        HttpEntity<String> entity = new HttpEntity<String>(req.toString(), headers);
        try {
            res = restTemplate.exchange(api, HttpMethod.POST, entity, String.class);
        } catch (Exception e) {  logger.warn(e.getMessage());  }
        return res;
    }
}
