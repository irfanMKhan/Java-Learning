package com.reddot.ecrm_bulk.service.bulk;

import com.reddot.ecrm_bulk.entity.bulk.BulkFileDetails;
import com.reddot.ecrm_bulk.enums.status.Status;
import com.reddot.ecrm_bulk.repository.bulk.BulkFileDetailsRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class BulkFileDetailsServiceImpl implements BulkFileDetailsService {
    private final BulkFileDetailsRepository bulkFileDetailsRepository;

    @Override
    public List<BulkFileDetails> bulkSave(List<BulkFileDetails> entities) {
        try {
            return bulkFileDetailsRepository.bulkSave(entities);
        } catch (Exception e) {
            log.error("Bulk File Details Bulk Insert Error: {}", e.getMessage(), e.getCause());
            return null;
        }
    }

    @Override
    public List<BulkFileDetails> findAllByBulkFileId(Long bulkFileId) {
        try {
            List<BulkFileDetails> bulkFileDetails = bulkFileDetailsRepository.findAllByBulkFileId(bulkFileId);
            if (CollectionUtils.isEmpty(bulkFileDetails)) {
                return new ArrayList<>();
            } else {
                return bulkFileDetails;
            }
        } catch (Exception e) {
            log.error("Bulk File Details Find By File Id: {} Error: {}", bulkFileId, e.getMessage(), e.getCause());
            return new ArrayList<>();
        }
    }

    @Override
    public List<BulkFileDetails> findByBulkFileIdAndStatus(Long bulkFileId, Status status) {
        try {
            List<BulkFileDetails> bulkFileDetails = bulkFileDetailsRepository.findByBulkFileIdAndStatus(bulkFileId, status);
            if (CollectionUtils.isEmpty(bulkFileDetails)) {
                log.debug("Bulk File Not Found with File Id: {}", bulkFileId);
                return new ArrayList<>();
            } else {
                return bulkFileDetails;
            }
        } catch (Exception e) {
            log.error("Bulk File Details Find By File Id: {} Status: {} Error: {}", bulkFileId, status.name(), e.getMessage(), e.getCause());
            return new ArrayList<>();
        }
    }

    @Override
    public BulkFileDetails update(BulkFileDetails bulkFileDetails) {
        try {
            return bulkFileDetailsRepository.update(bulkFileDetails);
        } catch (Exception e) {
            log.debug("Bulk File Details Update Error: {}", e.getMessage(), e.getCause());
            return null;
        }
    }
}
