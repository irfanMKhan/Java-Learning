package com.reddot.ecrm_bulk.service.notification;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm_bulk.config.Utility;
import com.reddot.ecrm_bulk.model.RPAModel;
import com.reddot.ecrm_bulk.pool_repository.CommonRepository;
import com.reddot.ecrm_bulk.service.SRManagerService;
import com.reddot.ecrm_bulk.service.notification.email.EmailSenderService;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class NotificationService {
    @Autowired
    CommonRepository commonDAO;
    private final Logger logger = LoggerFactory.getLogger(getClass().getName());

    @Autowired
    EmailSenderService emailSenderService;

    @Autowired
    SRManagerService srManagerService;

    @Value("${rpa.report.receiver}")
    private String receiver;

    @Value("${rpa.report.receiver_cc}")
    private String receiverCC;

    @Value("${rpa.report.callcostrebate.receiver}")
    private String receiverCallCostRebate;

    @Value("${rpa.report.callcostrebate.receiver_cc}")
    private String receiverCCCallCostRebate;

    public void processRPAReport(String rpaName, String subject) throws IOException, TemplateException {

        Calendar cal = Calendar.getInstance();
        DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");

        Map<String, Object> templateModel = new HashMap<>();
        templateModel.put("userFullName", "Concern");
        templateModel.put("subjectLine", subject);
        templateModel.put("date", dateFormat.format(cal.getTime()));
        Configuration cfg = new Configuration();
        cfg.setClassForTemplateLoading(this.getClass(), "/templates/");
        Template freemarkerTemplate = cfg.getTemplate("commonRPAReport.ftl");
        String htmlBody = FreeMarkerTemplateUtils.processTemplateIntoString(freemarkerTemplate, templateModel);
        //Generate File and Save
        String filename = createRPAReport(rpaName);

        try {
            if (!filename.isEmpty()) {
                File file = new File(filename);
                if(rpaName.equals("DCRM_CC_CALL_COST_REBATE")) {
                    emailSenderService.sendEmailwithAttachment(receiverCallCostRebate, htmlBody, subject, file, receiverCCCallCostRebate);
                }
                else {
                    emailSenderService.sendEmailwithAttachment(receiver, htmlBody, subject, file, receiverCC);
                }
            }
        } catch (Exception ex) {
            logger.error(ex.getMessage());
        }
    }

    public String createRPAReport(String rpaName) {
        List<Map<String, Object>> mapList = new ArrayList<>();
        List<RPAModel> rpaList = new ArrayList<>();
        String from = "";
        String to = "";

        try {
            Calendar cal = Calendar.getInstance();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            logger.info("Today's date is " + dateFormat.format(cal.getTime()));
            String today = dateFormat.format(cal.getTime());

            cal.add(Calendar.DATE, -1);
            logger.info("Yesterday's date was " + dateFormat.format(cal.getTime()));
            String yesterday = dateFormat.format(cal.getTime());

            DateFormat reportDateFormat = new SimpleDateFormat("ddMMyyyyHHmmss");
            String reportDay = reportDateFormat.format(new Date());
            String fileName = rpaName.replace(" ", "_") + "_" + reportDay;

            //Need to modify if cron expression changes
            //Call cost rebate falls in second condition as starting from 12:00PM (RPA: 8:00AM)
            if (new Date().getHours() < 12) {
                from = yesterday + " 18:00:00";
                to = today + " 05:59:59";
            } else {
                from = today + " 06:00:00";
                to = today + " 17:59:59";
            }

            String query = getQuery(rpaName, from, to);

            logger.info("Export query: " + query);
            Object listObject = commonDAO.CommoGetData(query);
            rpaList = new Gson().fromJson(Utility.ObjectToJson(listObject), new TypeToken<List<RPAModel>>() {
            }.getType());

            String[] columnTitles = {"RPA NAME", "SR NUMBER", "MSISDN", "PACK", "PACK ID", "BONUS PACK", "BONUS PACK ID", "PRICE",
                    "USAGE", "ERROR", "CREATED TIME", "SR STATUS", "REMARKS", "MSISDN CATEGORY"};

            String[] headers = {"RPA_NAME", "SR_NUMBER", "MSISDN", "PACK", "PACK_ID", "BONUS_PACK", "BONUS_PACK_ID", "PRICE",
                    "USAGE", "ERROR", "CREATED_AT_DT", "SR_STATUS", "REMARKS", "MSISDN_CATEGORY"};

            for (RPAModel tblRPA : rpaList) {
                HashMap<String, Object> hashMap = new HashMap<>();
                hashMap.put("RPA_NAME", tblRPA.getRPA_NAME());
                hashMap.put("SR_NUMBER", tblRPA.getSR_NUMBER());
                hashMap.put("MSISDN", tblRPA.getMSISDN());
                hashMap.put("PACK", tblRPA.getPACK());
                hashMap.put("PACK_ID", tblRPA.getPACK_ID());
                hashMap.put("BONUS_PACK", tblRPA.getBONUS_PACK());
                hashMap.put("BONUS_PACK_ID", tblRPA.getBONUS_PACK_ID());
                hashMap.put("PRICE", tblRPA.getPRICE());
                hashMap.put("USAGE", tblRPA.getUSAGE());
                hashMap.put("ERROR", tblRPA.getERROR());
//                hashMap.put("LIST_TYPE", tblRPA.getLIST_TYPE());
                hashMap.put("CREATED_AT_DT", tblRPA.getCREATED_AT_DT());
                hashMap.put("SR_STATUS", tblRPA.getSR_STATUS());
                hashMap.put("REMARKS", tblRPA.getREMARKS());
                hashMap.put("MSISDN_CATEGORY", tblRPA.getMSISDN_CATEGORY());

                mapList.add(hashMap);
            }
            String filename = generateRPAExcel(fileName, mapList, headers, columnTitles);

            rpaList.clear();
            if (!filename.isEmpty())
                return filename;

        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        } finally {
            mapList.clear();
        }

        return "";

    }

    private String generateRPAExcel(String fileName, List<Map<String, Object>> mapList, String[] headers, String[] columnTitles) {
        try {

            String filename = fileName + ".xlsx";

            OutputStream fileOut = new FileOutputStream(new File(filename));
            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("RPA Sheet");

            Row row = sheet.createRow(0);
            CellStyle headerCellStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerFont.setColor(IndexedColors.WHITE.index);
            headerCellStyle.setFont(headerFont);
            DataFormat dataFormat = workbook.createDataFormat();
            headerCellStyle.setDataFormat(dataFormat.getFormat("@"));

            headerCellStyle.setFillForegroundColor(IndexedColors.GREY_80_PERCENT.index);
            headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            getBorderStyle(headerCellStyle);

            for (int i = 0; i < columnTitles.length; i++) {
                Cell cell = row.createCell(i);
                cell.setCellValue(columnTitles[i]);
                cell.setCellStyle(headerCellStyle);
                sheet.autoSizeColumn(i);
            }

            CellStyle childCellStyle = workbook.createCellStyle();
            childCellStyle.setDataFormat(dataFormat.getFormat("@"));
            getBorderStyle(childCellStyle);

            for (int i = 0; i < mapList.size(); i++) {
                Row cellRow = sheet.createRow(i + 1);

                for (int j = 0; j < columnTitles.length; j++) {
                    Cell cell = cellRow.createCell(j);
                    Object cellValue = mapList.get(i).get(headers[j]);
                    if (cellValue != null && !cellValue.toString().isEmpty()) {
                        cell.setCellValue(mapList.get(i).get(headers[j]).toString());
                    }

                    cell.setCellStyle(childCellStyle);
                    sheet.autoSizeColumn(j);
                }
            }

            workbook.write(fileOut);
            logger.info("Write successfully!");
            return filename;
        } catch (Exception e) {
            e.printStackTrace();
             logger.error(e.getMessage(), e);
        }
        return "";
    }

    private void getBorderStyle(CellStyle cellStyle) {
        cellStyle.setBorderTop(BorderStyle.THIN);
        cellStyle.setBorderBottom(BorderStyle.THIN);
        cellStyle.setBorderLeft(BorderStyle.THIN);
        cellStyle.setBorderRight(BorderStyle.THIN);
    }

    private String getQuery(String rpaName, String from, String to) {
        return "Select RPA_NAME, SR_NUMBER, MSISDN, PACK, PACK_ID, BONUS_PACK, BONUS_PACK_ID, PRICE, \n" +
                "            USAGE, ERROR, LIST_TYPE, CREATED_AT_DT, SR_STATUS, REMARKS, MSISDN_CATEGORY " +
                " from TBL_SR_RPA_LOGS \n" +
                "where RPA_NAME = '" + rpaName + "' " +
                "  and CREATED_AT_DT >= to_date('" + from + "', 'dd-mm-yyyy hh24:mi:ss') \n" +
                "  and CREATED_AT_DT <= to_date('" + to + "', 'dd-mm-yyyy hh24:mi:ss')  \n" +
                " order by id ";
    }
}
