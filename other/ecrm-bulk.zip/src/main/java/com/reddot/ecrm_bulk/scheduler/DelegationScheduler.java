package com.reddot.ecrm_bulk.scheduler;

import com.reddot.ecrm_bulk.service.delegation.DelegationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@RequiredArgsConstructor
public class DelegationScheduler {
    private final DelegationService delegationService;

    @Scheduled(cron = "0 */30 * ? * *")  //30 min ---> now 2 min
    private void setDelegationService() {
        delegationService.delegateAllPendingMail();
    }

    @Scheduled(cron = "0 */30 * ? * *")  //30 min ---> now 3 min
    private void backDelegationService() {
        delegationService.backAllPendingMailAndDelegateMail();
    }

}
