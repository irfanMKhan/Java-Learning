package com.reddot.ecrm_bulk.service.number_activation.strategy.payment;

import com.reddot.ecrm_bulk.entity.annex.Annex;
import com.reddot.ecrm_bulk.entity.contract.Contract;
import com.reddot.ecrm_bulk.service.number_activation.ActivationService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;

@Service
public class PromiseToPayStrategy implements PaymentStrategy {
    private final ActivationService activationService;

    public PromiseToPayStrategy(ActivationService _activationService) {
        activationService = _activationService;
    }

    @Override
    public void process(Contract contract, Annex annex) throws UnsupportedEncodingException {
        if (activationService.todayIsEffectiveDate(annex)) {
            activationService.executeActivation(contract, annex);
        }
        if (activationService.todayIsPromiseToPayDate(annex)) {
            if (activationService.hasDevice(annex)) {
                if (! activationService.hasNoOutstanding(annex)) {
                    activationService.notify(contract, annex);
                }
            }
        }
    }
}
