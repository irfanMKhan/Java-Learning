package com.reddot.ecrm_bulk.enums.status;

public enum ActivationStatus {
    Create_Order_Success,
    Create_Order_Invoked,
    Pre2Post_Success,
    Pre2Post_Invoked,
    ChangeCreditLimit_Invoked,
    ChangeCreditLimit_Success,
    DeleteSupplementaryOffering_Invoked,
    DeleteSupplementaryOffering_Success,
    AddSupplementaryOffering_Invoked,
    AddSupplementaryOffering_Success,
    ChangeAccountInformation_Invoked,
    ChangeAccountInformation_Success,
    CorporateGroup_Success,
    CorporateGroup_Invoked,
    CUGGroup_Success,
    CUGGroup_Invoked,
    Activate
}
