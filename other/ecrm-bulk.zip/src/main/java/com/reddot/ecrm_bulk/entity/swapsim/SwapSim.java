package com.reddot.ecrm_bulk.entity.swapsim;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;
import java.time.LocalDate;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "tbl_swap_sim")
public class SwapSim {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String oldMsisdn;
    private String newMsisdn;
    private String oldIccId;
    private String newIccId;
    private String swapType;

    private Double discount;
    private Double serviceCharge;
    private Double upfrontFee;
    private String effectiveMode;
    private LocalDate date;
    private Boolean emailNotification;
    private Boolean requestForPtoP;
    private String documentType;
    private String documentName;
    private String remarks;
    private Boolean ptp;
    private Boolean email;
    private Long companyId;
    private String companyName;
    private String accountCode;
    private String status;
    private String transactionId;
    private String error;

    @Column(name = "api_request",columnDefinition="text")

    private String apiRequest;
    @Column(name = "api_response",columnDefinition="text")

    private String apiResponse;
    @Column(name = "api_request_for_debit_note",columnDefinition="text")
    private String apiRequestForDebitNote;
    @Column(name = "api_response_for_debit_note",columnDefinition="text")

    private String apiResponseForDebitNote;
    private String debitNoteApiCallStatus;


    //newly added
    private String financialType;
    private String financialTypeText;
    private Double financialTypeAmount;
    private Double finalCost;
    private String ptpDate;
    private Integer ptpDays;
    private String adjustmentSerialNo;


    @Column(name = "created_at")
    private Long createdAt;

    @Column(name = "created_at_dt")
    private Timestamp createdAtDt;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_by_username")
    private String createdUsername;

    @Column(name = "updated_at")
    private Long updatedAt;

    @Column(name = "updated_at_dt")
    private Timestamp updatedAtDt;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_by_username")
    private String updatedUsername;
}
