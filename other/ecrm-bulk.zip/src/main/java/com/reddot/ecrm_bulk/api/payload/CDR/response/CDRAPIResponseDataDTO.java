package com.reddot.ecrm_bulk.api.payload.CDR.response;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class CDRAPIResponseDataDTO {
    private Integer Id;
    private String date;
    private String time;
    private String destination;
    private String durationOrAmount;
    private String calledNumber;
    private String amountUSD;
}
