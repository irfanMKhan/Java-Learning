package com.reddot.ecrm_bulk.service.account;

import com.reddot.ecrm_bulk.entity.account_details.Address;
import com.reddot.ecrm_bulk.repository.account.AddressRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class
AddressRepositoryImpl implements AddressService {
    private final AddressRepository addressRepository;
    @Override
    public Address findById(Long contractId) {
        try {
            return addressRepository.findById(contractId);
        } catch (Exception e) {
            if (e instanceof EmptyResultDataAccessException) {
                log.debug("Address not found with contract id: {}", contractId);
            } else {
                log.error("Address findById Error: {}", e.getMessage(), e.getCause());
            }
            return null;
        }
    }
}
