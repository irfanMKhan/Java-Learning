package com.reddot.ecrm_bulk.service.delegation;

import com.reddot.ecrm_bulk.dto.common.HttpServletRequestDto;
import com.reddot.ecrm_bulk.dto.user.UserModel;
import com.reddot.ecrm_bulk.entity.approval.ApprovalLogDetailsEntity;
import com.reddot.ecrm_bulk.entity.delegation.DelegationEntity;
import com.reddot.ecrm_bulk.enums.approval.ApprovalRequestStatusEnum;
import com.reddot.ecrm_bulk.repository.approval.ApprovalLogDetailsRepo;
import com.reddot.ecrm_bulk.repository.delegation.DelegationRepo;
import com.reddot.ecrm_bulk.service.approval.ApprovalRequestService;
import com.reddot.ecrm_bulk.service.user.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class DelegationService {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    private final ApprovalLogDetailsRepo approvalLogDetailsRepo;
    private final UserService userService;
    ModelMapper modelMapper = new ModelMapper();
    @Autowired
    DelegationRepo delegationRepo;
    @Autowired
    ApprovalRequestService approvalRequestService;

    public void delegateAllPendingMail() {
        try {
            List<DelegationEntity> todayDelegationDateList = delegationRepo.findAllByStartDateEqualsAndIsActiveAndHasDelegateAllPendingMail(
                    LocalDate.now(), true, false);
            logger.info("Inside DelegationService  delegateAllPendingMail() Scheduler: list size={} ", todayDelegationDateList.size());

            List<ApprovalLogDetailsEntity> updateLogDetailsList = new ArrayList<>();
            List<DelegationEntity> updateDelegationList = new ArrayList<>();
            for (DelegationEntity delegationEntity : todayDelegationDateList) {
                if (delegationEntity.getHasAssignedMailBack()) {
                    continue;  //already back
                }
                singleProcessPendingMailDelegation(delegationEntity, updateDelegationList, updateLogDetailsList);
            }

            delegationRepo.saveAll(updateDelegationList);
            approvalLogDetailsRepo.saveAll(updateLogDetailsList);
        } catch (Exception e) {
            logger.error(String.format("DelegationService:delegateAllPendingMail() Error: %s", e.getMessage()));
        }
    }

    private void singleProcessPendingMailDelegation(DelegationEntity delegationEntity, List<DelegationEntity> updateDelegationList, List<ApprovalLogDetailsEntity> updateLogDetailsList) {
        try {
            List<ApprovalLogDetailsEntity> pendingApprovalLogList = approvalLogDetailsRepo.findAllByApproverIDAndStatusAndIsActive(
                    delegationEntity.getDelegatorId(), ApprovalRequestStatusEnum.PENDING.name(), true);
            for (ApprovalLogDetailsEntity approvalLogDetailsEntity : pendingApprovalLogList) {
                if (!ObjectUtils.isEmpty(approvalLogDetailsEntity.getIsDelegationMail()) && approvalLogDetailsEntity.getIsDelegationMail()) {
                    continue;
                }

                if (!ObjectUtils.isEmpty(approvalLogDetailsEntity.getIsDelegationMail()) && approvalLogDetailsEntity.getIsPendingMailDelegation()) {
                    continue;
                }

                ApprovalLogDetailsEntity newApprovalLogDetails = new ApprovalLogDetailsEntity();
                modelMapper.map(approvalLogDetailsEntity, newApprovalLogDetails);
                newApprovalLogDetails.setId(null);
                newApprovalLogDetails.setIsPendingMailDelegation(true);
                newApprovalLogDetails.setApproverID(delegationEntity.getDelegateId());
                newApprovalLogDetails.setApproverName(delegationEntity.getDelegateUsername());
                newApprovalLogDetails.setApproverEmail(delegationEntity.getDelegateEmail());
                newApprovalLogDetails.setGrpPositionId(null);
                newApprovalLogDetails.setGrpPositionName(null);
                newApprovalLogDetails.setIsActive(true);
                newApprovalLogDetails.setDelegationId(delegationEntity.getId());
                newApprovalLogDetails.setDelegatorId(delegationEntity.getDelegatorId());
                newApprovalLogDetails.setDelegatorUsername(delegationEntity.getDelegatorUsername());

                approvalLogDetailsEntity.setIsActive(false);  //current is_active = false
                updateLogDetailsList.add(newApprovalLogDetails);
                updateLogDetailsList.add(approvalLogDetailsEntity);
            }

            delegationEntity.setHasDelegateAllPendingMail(true);
            updateDelegationList.add(delegationEntity);
        } catch (Exception e) {
            logger.error(String.format("DelegationService:singleProcessPendingMailDelegation() Error: %s", e.getMessage()));
        }
    }

    public void backAllPendingMailAndDelegateMail() {
        try {
            LocalDate beforeToday = LocalDate.now().minusDays(1);
            List<DelegationEntity> todayDelegationDateList = delegationRepo.findAllByEndDateEqualsAndIsActiveAndHasAssignedMailBack(
                    beforeToday, true, false);
            logger.info("Inside DelegationService  backAllPendingMailAndDelegateMail() Scheduler: list size={} ", todayDelegationDateList.size());

            List<ApprovalLogDetailsEntity> updateLogDetailsList = new ArrayList<>();
            List<DelegationEntity> updateDelegationList = new ArrayList<>();
            for (DelegationEntity delegationEntity : todayDelegationDateList) {
                if (!delegationEntity.getHasDelegateAllPendingMail()) {
                    continue; //if not send any pending mail why need to call that
                }
                singleProcessToBackAssignedMail(delegationEntity, updateDelegationList, updateLogDetailsList);
            }

            delegationRepo.saveAll(updateDelegationList);
            approvalLogDetailsRepo.saveAll(updateLogDetailsList);
        } catch (Exception e) {
            logger.error(String.format("DelegationService:backAllPendingMailAndDelegateMail() Error: %s", e.getMessage()));
        }
    }

    /*
     * Notes
     * singleProcessToBackAssignedMail()
     * is_pending_mail---> pending -->isActive(false) otherwise no change(history)--->delegate_userId
     * is_delegate_mail --> pending--->isActive(false) otherwise no change(history)--->delegate_userId
     * last step: delegator --->pending && isActive(false)---> then isActive(true)---->delegatorr_userId
     * */
    private void singleProcessToBackAssignedMail(DelegationEntity delegationEntity, List<DelegationEntity> updateDelegationList, List<ApprovalLogDetailsEntity> updateLogDetailsList) {

        Long delegatorUserId = delegationEntity.getDelegatorId();

        backPendingMailToConcern(delegationEntity, updateLogDetailsList);

        backDelegateMailToConcern(delegationEntity, updateLogDetailsList);
        //last step
        updateDelegatorPendingListToActive(delegatorUserId, updateLogDetailsList);

        String delegationMailTitle = "Notification for Ending of Delegation Request";
        HttpServletRequestDto httpServletRequestDto = new HttpServletRequestDto();
        httpServletRequestDto.setCreatedBy(delegationEntity.getCreatedBy());
        httpServletRequestDto.setCreatedUsername(delegationEntity.getCreatedUsername());
        approvalRequestService.sendDelegationMailNotification(httpServletRequestDto, delegationEntity, delegationMailTitle);


        delegationEntity.setHasAssignedMailBack(true);
        updateDelegationList.add(delegationEntity);
    }

    private void backPendingMailToConcern(DelegationEntity delegationEntity, List<ApprovalLogDetailsEntity> updateLogDetailsList) {
        try {
            List<ApprovalLogDetailsEntity> delegateMailList = approvalLogDetailsRepo.findAllByApproverIDAndIsActiveAndIsPendingMailDelegation(
                    delegationEntity.getDelegateId(), true, true
            );

            for (ApprovalLogDetailsEntity delegateLogDetails : delegateMailList) {
                if (delegateLogDetails.getDelegatorId() != null && !delegateLogDetails.getDelegatorId().equals(delegationEntity.getDelegatorId())) {
                    //multiple person delegate to same user, so only valid delegation mail will be returned, otherwise skip
                    continue;
                }

                if (delegateLogDetails.getStatus().equalsIgnoreCase(ApprovalRequestStatusEnum.PENDING.name())) {
                    delegateLogDetails.setIsActive(false);  //delegateLog is_active = false for pending
                    delegateLogDetails.setStatus(ApprovalRequestStatusEnum.DelegationExpired.name());
                } else if (delegateLogDetails.getStatus().equalsIgnoreCase(ApprovalRequestStatusEnum.APPROVED.name())
                        || delegateLogDetails.getStatus().equalsIgnoreCase(ApprovalRequestStatusEnum.REJECTED.name())) {
                    //do nothing
                }
                updateLogDetailsList.add(delegateLogDetails);
            }

        } catch (Exception e) {
            logger.error(String.format("DelegationService:backPendingMailToConcern() Error: %s", e.getMessage()));
        }
    }

    private void backDelegateMailToConcern(DelegationEntity delegationEntity,
                                           List<ApprovalLogDetailsEntity> updateLogDetailsList) {
        try {
            List<ApprovalLogDetailsEntity> delegateMailList = approvalLogDetailsRepo.findAllByApproverIDAndIsActiveAndIsDelegationMail(
                    delegationEntity.getDelegateId(), true, true
            );

            for (ApprovalLogDetailsEntity delegateLogDetails : delegateMailList) {
                if (delegateLogDetails.getDelegatorId() != null && !delegateLogDetails.getDelegatorId().equals(delegationEntity.getDelegatorId())) {
                    //multiple person delegate to same user, so only valid delegation mail will be returned, otherwise skip
                    continue;
                }
                ApprovalLogDetailsEntity newApprovalLogDetails = new ApprovalLogDetailsEntity();
                modelMapper.map(delegateLogDetails, newApprovalLogDetails);
                newApprovalLogDetails.setId(null);
                newApprovalLogDetails.setDelegatorUsername(null);
                newApprovalLogDetails.setDelegatorId(null);
                newApprovalLogDetails.setDelegateId(delegateLogDetails.getApproverID());
                newApprovalLogDetails.setDelegateUsername(delegateLogDetails.getApproverName());
                newApprovalLogDetails.setIsActive(true);
                newApprovalLogDetails.setApproverID(delegationEntity.getDelegatorId());
                newApprovalLogDetails.setApproverName(delegationEntity.getDelegatorUsername());
                UserModel userModel = userService.getUserById(delegationEntity.getDelegatorId());
                newApprovalLogDetails.setApproverEmail(userModel.getEmail());

                if (delegateLogDetails.getStatus().equalsIgnoreCase(ApprovalRequestStatusEnum.PENDING.name())) {
                    delegateLogDetails.setIsActive(false);  //delegateLog is_active = false for pending
                    delegateLogDetails.setStatus(ApprovalRequestStatusEnum.DelegationExpired.name());
                } else if (delegateLogDetails.getStatus().equalsIgnoreCase(ApprovalRequestStatusEnum.APPROVED.name())
                        || delegateLogDetails.getStatus().equalsIgnoreCase(ApprovalRequestStatusEnum.REJECTED.name())) {
                    newApprovalLogDetails.setStatus(ApprovalRequestStatusEnum.DelegateUserExecuted.name());
                }

                updateLogDetailsList.add(newApprovalLogDetails);
                updateLogDetailsList.add(delegateLogDetails);
            }

        } catch (Exception e) {
            logger.error(String.format("DelegationService:backDelegateMailToConcern() Error: %s", e.getMessage()));
        }
    }


    private void updateDelegatorPendingListToActive(Long delegatorUserId, List<ApprovalLogDetailsEntity> updateLogDetailsList) {
        try {
            List<ApprovalLogDetailsEntity> delegatorPendingList = approvalLogDetailsRepo.findAllByApproverIDAndStatusAndIsActive(
                    delegatorUserId, ApprovalRequestStatusEnum.PENDING.name(), false
            );

            for (ApprovalLogDetailsEntity delegatorPendingLogEntity : delegatorPendingList) {
                delegatorPendingLogEntity.setIsActive(true);
                updateLogDetailsList.add(delegatorPendingLogEntity);
            }
        } catch (Exception e) {
            logger.error(String.format("DelegationService:updateDelegatorPendingListToActive() Error: %s", e.getMessage()));
        }
    }

}




