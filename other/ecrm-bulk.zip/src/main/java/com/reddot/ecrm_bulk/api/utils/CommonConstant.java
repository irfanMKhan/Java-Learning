package com.reddot.ecrm_bulk.api.utils;

public class CommonConstant {
    public static final String LOGOUT_JWT = "session#blacklist#";
    public static final String COMMON_ERROR = "Request processing failed. Please try again";
    public static final int AUTHORIZATION_CREDENTIALS_ERROR_CODE = 1401;
    public static final int THROTTLE_ERROR_CODE = 900800;
    public static final String AUTHORIZATION_CREDENTIALS_ERROR_MGS = "Invalid Client Credentials";

    public static final int ACCESS_TOKEN_ERROR_CODE = 2401;
    public static final String ACCESS_TOKEN_ERROR_MGS = "Invalid Authorization Token";
}
