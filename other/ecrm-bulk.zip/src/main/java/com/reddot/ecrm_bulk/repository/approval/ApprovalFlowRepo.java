package com.reddot.ecrm_bulk.repository.approval;

import com.reddot.ecrm_bulk.entity.approval.ApprovalFlowEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ApprovalFlowRepo extends JpaRepository<ApprovalFlowEntity, Long> {
    List<ApprovalFlowEntity> findAllByHasRuleAndTenantId(Boolean hasRule, Long tenantId);



    Optional<ApprovalFlowEntity> findByNameAndTenantId(String flowName, Long tenantId);

    List<ApprovalFlowEntity> findAllByTenantId(Long tenantId);
}