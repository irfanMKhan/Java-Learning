package com.reddot.ecrm_bulk.service.cr;

import com.reddot.ecrm_bulk.api.exception.NotFoundException;
import com.reddot.ecrm_bulk.entity.cr.CRMasterEntity;
import com.reddot.ecrm_bulk.enums.requestType.CommonStatusEnum;
import com.reddot.ecrm_bulk.enums.requestType.RequestTypeEnum;
import com.reddot.ecrm_bulk.repository.cr.CRMasterRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class CRMasterServiceImpl implements CRMasterService {
    private final CRMasterRepository crMasterRepository;

    @Override
    public List<CRMasterEntity> findAllOpenStatus() {
        return crMasterRepository.findAllByFinalStatusAndRequestTypeId(CommonStatusEnum.Open.name(), RequestTypeEnum.Change_Branch.getValue());
    }

    @Override
    public CRMasterEntity findById(Long id) {
        Optional<CRMasterEntity> crMasterEntity = crMasterRepository.findById(id);
        return crMasterEntity.orElse(null);
    }

    @Override
    public void updateFinalStatus(CRMasterEntity crMasterEntity, CommonStatusEnum commonStatusEnum) {
        CRMasterEntity crMaster = findById(crMasterEntity.getId());
        if (! ObjectUtils.isEmpty(crMaster)) {
            crMaster.setFinalStatus(commonStatusEnum.name());
        } else {
            log.debug("CRMaster Not Found with Id: {}", crMaster.getId());
            throw new NotFoundException("CRMaster Not Found with Id: " + crMaster.getId());
        }
    }

    @Override
    public void updateCRMasterRemarksAndFailedStatus(CRMasterEntity crMasterEntity, String remarks) {
        CRMasterEntity crMaster = findById(crMasterEntity.getId());
        if (! ObjectUtils.isEmpty(crMaster)) {
            crMaster.setFinalStatus(CommonStatusEnum.Failed.name());
            crMaster.setRemarks(remarks);
            update(crMaster);
        } else {
            log.debug("CRMaster Not Found with Id: {}", crMaster.getId());
            throw new NotFoundException("CRMaster Not Found with Id: " + crMaster.getId());
        }
    }

    public int update(List<Long> ids, String finalStatus) {
        return crMasterRepository.update(ids, finalStatus);
    }

    @Override
    public CRMasterEntity update(CRMasterEntity crMasterEntity) {
        return crMasterRepository.save(crMasterEntity);
    }

    @Override
    public void updateFinalStatus(List<List<CRMasterEntity>> crMasterList, CommonStatusEnum status) {
        for (List<CRMasterEntity> crMasterEntityList: crMasterList) {
            List<Long> ids = new ArrayList<>();
            for (CRMasterEntity crMasterEntity: crMasterEntityList) {
                ids.add(crMasterEntity.getId());
            }
            update(ids, status.name());
        }
    }
}
