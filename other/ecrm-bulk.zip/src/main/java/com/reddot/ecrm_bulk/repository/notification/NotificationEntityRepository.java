package com.reddot.ecrm_bulk.repository.notification;

import com.reddot.ecrm_bulk.entity.notification.NotificationEntity;
import com.reddot.ecrm_bulk.enums.notification.NotificationStatusEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface NotificationEntityRepository extends JpaRepository<NotificationEntity, Long> {
    Optional<List<NotificationEntity>> findAllByNotificationStatusIn(List<NotificationStatusEnum> status);


    @Query(value = "select *\n " +
            "from notification_details\n " +
            "where (notification_status = 'TODO' and DATE(effective_date) = current_date);", nativeQuery = true)
    List<NotificationEntity> findAllNotificationTODODataAndEffectiveDate();

    Optional<NotificationEntity> getById(Long id);
}
