package com.reddot.ecrm_bulk.response;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class SendSMSResponse implements Serializable {
    private OutboundSMSMessageRequest outboundSMSMessageRequest;

    @Data
    public static class OutboundSMSMessageRequest implements Serializable {
        private String senderAddress;

        private String senderName;

        private List<String> address;

        private String resourceURL;

        private ReceiptRequest receiptRequest;

        private DeliveryInfoList deliveryInfoList;

        private OutboundSMSTextMessage outboundSMSTextMessage;

        private String clientCorrelator;

        @Data
        public static class ReceiptRequest implements Serializable {
            private String callbackData;

            private String notifyURL;
        }

        @Data
        public static class DeliveryInfoList implements Serializable {
            private List<DeliveryInfo> deliveryInfo;

            private String resourceURL;

            @Data
            public static class DeliveryInfo implements Serializable {
                private String address;

                private String deliveryStatus;
            }
        }

        @Data
        public static class OutboundSMSTextMessage implements Serializable {
            private String message;
        }
    }
}

