package com.reddot.ecrm_bulk.bulkFileDTO;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@Data
public class CDRJsonDataDTO  {
    @SerializedName("filetype")
    @Expose
    private String file_type;
    @SerializedName("usagetype")
    @Expose
    private String usage_type;
    @SerializedName("startdate(dd-mm-yyyy)")
    @Expose
    private String start_date;
    @SerializedName("msisdn")
    @Expose
    private String msisdn;
    @SerializedName("enddate(dd-mm-yyyy)")
    @Expose
    private String end_date;


}
