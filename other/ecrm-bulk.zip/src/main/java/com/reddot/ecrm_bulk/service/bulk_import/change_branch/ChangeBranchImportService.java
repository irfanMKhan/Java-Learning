package com.reddot.ecrm_bulk.service.bulk_import.change_branch;

import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.reddot.ecrm_bulk.dto.bulk.ChangeBranchInfo;
import com.reddot.ecrm_bulk.entity.bulk.BulkFile;
import com.reddot.ecrm_bulk.entity.bulk.BulkFileDetails;
import com.reddot.ecrm_bulk.enums.status.Status;
import com.reddot.ecrm_bulk.service.bulk.BulkFileDetailsService;
import com.reddot.ecrm_bulk.service.bulk.BulkFileService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.StopWatch;
import org.dhatim.fastexcel.reader.ExcelReaderException;
import org.dhatim.fastexcel.reader.ReadableWorkbook;
import org.dhatim.fastexcel.reader.Row;
import org.jobrunr.scheduling.JobScheduler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

@Service
@Slf4j
@RequiredArgsConstructor
public class ChangeBranchImportService {
    private final JobScheduler jobScheduler;
    private final BulkFileService bulkFileService;
    private final BulkFileDetailsService bulkFileDetailsService;
    private final Gson gson;
    @Value("${batch.chunkSize}")
    private int chunkSize;

    public void proceedExecution() {
        List<BulkFile> bulkFileList = bulkFileService.findAllTodosByIsRun(false);
        List<List<BulkFile>> result = Lists.partition(bulkFileList, chunkSize);

        // Todos and IsTrue Bulk Files List
        for (List<BulkFile> bulkFiles : result) {
            for (BulkFile bulkFile : bulkFiles) {
                jobScheduler.enqueue(() -> this.proceedBulkFileExecution(bulkFile));
            }
        }
    }

    public void proceedBulkFileExecution(BulkFile bulkFile) {
        readExcel(bulkFile);
    }

    private void readExcel(BulkFile bulkFile) {
        String path = bulkFile.getFilePath();
        List<BulkFileDetails> bulkFileDetailsList = new ArrayList<>();

        if (!ObjectUtils.isEmpty(path)) {
            try (InputStream is = Files.newInputStream(Paths.get(path));
                 ReadableWorkbook wb = new ReadableWorkbook(is)) {
                StopWatch watch = new StopWatch();
                watch.start();
                log.info("Processing started. File: {} ", bulkFile.getFileName());

                wb.getSheets().forEach(sheet ->
                {
                    try (Stream<Row> rows = sheet.openStream()) {
                        rows.skip(1).forEach(r -> {
                            BigDecimal msisdn = r.getCellAsNumber(1).orElse(null);
                            String groupName = r.getCellAsString(2).orElse(null);
                            BigDecimal groupCode = r.getCellAsNumber(3).orElse(BigDecimal.ZERO);

                            BulkFileDetails bulkFileDetails = new BulkFileDetails();
                            ChangeBranchInfo changeBranchInfo = new ChangeBranchInfo();

                            changeBranchInfo.setMsisdn(String.valueOf(msisdn));
                            changeBranchInfo.setBranchName(groupName);
                            changeBranchInfo.setBranchCode(String.valueOf(groupCode.doubleValue()));

                            bulkFileDetails.setBulkFileId(bulkFile.getId());
                            bulkFileDetails.setBulkFileName(bulkFile.getFileName());
                            bulkFileDetails.setFinalStatus(Status.TODO.name());
                            bulkFileDetails.setCompanyId(bulkFile.getCompanyId());
                            bulkFileDetails.setCompanyName(bulkFile.getCompanyName());
                            bulkFileDetails.setFileRowData(gson.toJson(changeBranchInfo));
                            bulkFileDetails.setBulkFileProcessTypeId(bulkFile.getProcessTypeId());
                            bulkFileDetails.setBulkFileProcessTypeName(bulkFile.getProcessTypeName());

                            bulkFileDetailsList.add(bulkFileDetails);
                        });
                    } catch (Exception e) {
                        if (e instanceof ExcelReaderException) {
                            log.debug("Excel Reader Exception: {}", e.getMessage(), e.getCause());
                        }
                        e.printStackTrace();
                    }
                    watch.stop();
                    log.info("Processing ended. File: {} and time: {}", bulkFile.getFileName(), watch.getTime(TimeUnit.MILLISECONDS));
                });

                writeToDatabase(bulkFile, bulkFileDetailsList);
            } catch (IOException e) {
                log.debug("IO Exception: {}", e.getMessage(), e.getCause());
            }
        } else {
            log.debug("Path is empty for file: {}", bulkFile.getFileName());
        }
    }

    private void writeToDatabase(BulkFile bulkFile, List<BulkFileDetails> bulkFileDetailsList) {
        // Chunk BulkFile Details and Bulk Save
        List<List<BulkFileDetails>> result = Lists.partition(bulkFileDetailsList, chunkSize);
        for (List<BulkFileDetails> bulkFileDetails : result) {
            bulkFileDetailsService.bulkSave(bulkFileDetails);
        }

        // Update total rows and status is run true
        bulkFileService.updateBulkFileTotalRowsAndIsRun(bulkFile, bulkFileDetailsList.size(), true);
    }
}
