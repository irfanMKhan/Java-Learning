package com.reddot.ecrm_bulk.repository.bulk;

import com.reddot.ecrm_bulk.entity.bulk.BulkFile;
import com.reddot.ecrm_bulk.enums.bulk.BulkProcessFileType;
import com.reddot.ecrm_bulk.enums.status.Status;
import lombok.Synchronized;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import java.util.List;

@Repository
@Slf4j
public class BulkFileRepository {
    @PersistenceContext
    private EntityManager entityManager;

    public List<BulkFile> findAll() {
        TypedQuery<BulkFile> query = entityManager.createQuery(
                "SELECT b FROM BulkFile b WHERE (b.processStatus = :processStatus OR b.processStatus = :processStatusInProgress)",
                BulkFile.class);
        return query.setParameter("processStatus", Status.TODO.name())
                .setParameter("processStatusInProgress", Status.InProgress.name())
                .getResultList();
    }

    @Synchronized
    public BulkFile findById(Long id) {
        TypedQuery<BulkFile> query = entityManager.createQuery(
                "SELECT b FROM BulkFile b WHERE b.id = :id",
                BulkFile.class);
        return query.setParameter("id", id)
                .getSingleResult();
    }

    public List<BulkFile> findAllTodosByIsRun(Boolean isRun, BulkProcessFileType bulkProcessFileType) {
        TypedQuery<BulkFile> query = entityManager.createQuery(
                "SELECT b FROM BulkFile b WHERE b.processStatus = :processStatus AND b.isRun = :isRun AND b.processTypeId = :processTypeId",
                BulkFile.class);
        return query.setParameter("processStatus", Status.TODO.name())
                .setParameter("isRun", isRun)
                .setParameter("processTypeId", bulkProcessFileType.getValue())
                .getResultList();
    }

    public List<BulkFile> findAllTodosAndInProgressByIsRun(Boolean isRun) {
        TypedQuery<BulkFile> query = entityManager.createQuery(
                "SELECT b FROM BulkFile b WHERE b.isRun = :isRun AND (b.processStatus = :processStatusTodo OR b.processStatus = :processStatusInProgress)",
                BulkFile.class);
        return query.setParameter("processStatusTodo", Status.TODO.name())
                .setParameter("processStatusInProgress", Status.InProgress.name())
                .setParameter("isRun", isRun)
                .getResultList();
    }

    @Transactional
    public int update(List<Long> ids, Status status) {
        return entityManager.createQuery(
                "UPDATE BulkFile b SET b.processStatus = :processStatus WHERE b.id IN (:ids)")
                .setParameter("processStatus", status.name())
                .setParameter("ids", ids)
                .executeUpdate();
    }

    @Transactional
    public BulkFile update(BulkFile bulkFile) {
        entityManager.merge(bulkFile);
        entityManager.flush();
        return bulkFile;
    }
}
