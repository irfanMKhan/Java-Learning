package com.reddot.ecrm_bulk.repository.approval;

import com.reddot.ecrm_bulk.entity.approval.ApprovalLogDetailsEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface ApprovalLogDetailsRepo extends JpaRepository<ApprovalLogDetailsEntity, Long> {
    //get all log details based on reqId
    List<ApprovalLogDetailsEntity> findAllByApprovalReqIdOrderByIdDesc(Long reqId);

//    List<ApprovalLogDetailsEntity> findAllByApproverIDAndStatusAndIsActive(Long approverId,
//                                                                           String status,
//                                                                           Boolean isActive);

    List<ApprovalLogDetailsEntity> findAllByApproverIDAndStatusAndIsActive(Long approverId, String status,Boolean isActive);

    List<ApprovalLogDetailsEntity> findAllByApproverIDAndIsActiveAndIsDelegationMail(Long approverId, Boolean isActive,
                                                                                     Boolean isDelegationMail);

    List<ApprovalLogDetailsEntity> findAllByApproverIDAndIsActiveAndIsPendingMailDelegation(Long approverId, Boolean isActive,
                                                                                     Boolean isPendingMailDelegation);


    //pageable
    Page<ApprovalLogDetailsEntity> findAllByApproverIDOrderByIdDesc(Long reqId, Pageable pageable);

    //find logDetails by approverID and reqId
    ApprovalLogDetailsEntity findByApprovalReqIdAndApproverID(Long reqId, Long approverID);

    //get all log details based on reqId and uuid(security purpose) and order by stepOrder
    List<ApprovalLogDetailsEntity> findAllByApprovalReqIdAndUuidTokenOrderByStepOrderDesc(Long reqId, String token);

    //find by id and uuid
    Optional<ApprovalLogDetailsEntity> findByApproverIDAndUuidToken(Long id, String token);

    //find all by userID and uuid token(security purpose)
    List<ApprovalLogDetailsEntity> findAllByApproverIDOrderByIdDesc(Long approverId);


    @Query(value = "SELECT a FROM ApprovalLogDetailsEntity a WHERE a.requestedBy = ?1 " +
            "AND ( CAST(a.approvedAtDt AS text) LIKE %?2% OR LOWER(a.approvalFlowName) LIKE %?2% OR " +
            " LOWER(a.status) = ?2)", nativeQuery = true)
    Page<ApprovalLogDetailsEntity> searchNativeQuery(Long aLong, String lowerCase, Pageable pageable);
}
