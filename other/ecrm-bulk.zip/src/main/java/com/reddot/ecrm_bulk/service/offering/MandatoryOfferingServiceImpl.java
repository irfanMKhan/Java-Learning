package com.reddot.ecrm_bulk.service.offering;

import com.reddot.ecrm_bulk.entity.mandatory_offering.MandatoryOfferingEntity;
import com.reddot.ecrm_bulk.repository.mandatory_offering.MandatoryOfferingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class MandatoryOfferingServiceImpl implements MandatoryOfferingService {
    private final MandatoryOfferingRepository mandatoryOfferingRepository;
    @Override
    public Boolean IsMandatoryOffering(String supplementaryOfferingId) {
        List<MandatoryOfferingEntity> mandatoryOfferingList = mandatoryOfferingRepository.findAllByActive(true);
        log.debug("MandatoryOffering List: :{}", mandatoryOfferingList);
        try {
            for (MandatoryOfferingEntity mandatoryOffering : mandatoryOfferingList) {
                if (mandatoryOffering.getOfferingId().equals(supplementaryOfferingId)) {
                    return true;
                }
            }
        } catch (Exception e) {
            log.debug(String.format("CreateRequestEntityForContractAPI:IsMandatoryOffering() Error: %s", e.getMessage()));
        }
        return false;
    }
}
