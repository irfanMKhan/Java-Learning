package com.reddot.ecrm_bulk.repository.company;

import com.reddot.ecrm_bulk.entity.company.Company;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CompanyJPARepository extends JpaRepository<Company, Long> {

    Optional<Company> findByNameIgnoreCase(String companyName);

    Optional<Company> findByName(String companyName);

    Company findByNameIgnoreCaseAndActiveIsTrue(String companyName);

    Company findByIdAndActive(Long id, Boolean isActive);

    List<Company> findAllByActiveAndContractStatus(Boolean isActive, Integer contractStatus);

    List<Company> findCompanyEntitiesByKamName(String name);

    List<Company> findCompanyEntitiesByKamId(Long kamId);

    List<Company> findAllByActive(boolean b);
}
