package com.reddot.ecrm_bulk.service.change_branch;

import com.google.common.collect.Lists;
import com.reddot.ecrm_bulk.entity.company.CompanyAccount;
import com.reddot.ecrm_bulk.entity.cr.CRMasterEntity;
import com.reddot.ecrm_bulk.entity.cr.CRMsisdnDetailsEntity;
import com.reddot.ecrm_bulk.enums.cr.CRStatusEnum;
import com.reddot.ecrm_bulk.enums.requestType.CommonStatusEnum;
import com.reddot.ecrm_bulk.service.company.CompanyAccountService;
import com.reddot.ecrm_bulk.service.cr.CRMasterService;
import com.reddot.ecrm_bulk.service.cr.CRMsisdnDetailsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jobrunr.scheduling.JobScheduler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.time.LocalDate;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class CRChangeBranchService {
    @Value("${batch.chunkSize}")
    private int chunkSize;
    private final JobScheduler jobScheduler;
    private final CRMasterService crMasterService;
    private final CRMsisdnDetailsService crMsisdnDetailsService;
    private final CRBranchService crBranchService;
    private final CompanyAccountService companyAccountService;

    // Traverse CRMasters
    public void proceedExecution() {
        List<CRMasterEntity> crMasterList = crMasterService.findAllOpenStatus();
        List<List<CRMasterEntity>> result = Lists.partition(crMasterList, chunkSize);

        for (List<CRMasterEntity> crMasterEntityList: result) {
            for (CRMasterEntity crMasterEntity: crMasterEntityList) {
                jobScheduler.enqueue(() -> proceedCRMaster(crMasterEntity));
            }
        }
    }

    // Traverse CRMasterDetails
    // Update CRMaster Status
    public void proceedCRMaster(CRMasterEntity crMasterEntity) {
        try {
            CompanyAccount parentCustomer = companyAccountService.findParentCustomerByAccountName(crMasterEntity.getCompanyName());

            if (ObjectUtils.isEmpty(parentCustomer)) {
                crMasterService.updateCRMasterRemarksAndFailedStatus(crMasterEntity, "Parent Customer Is Empty with Company Id: " + crMasterEntity.getCompanyName());
                return;
            }

            if (!ObjectUtils.isEmpty(parentCustomer) && ObjectUtils.isEmpty(parentCustomer.getAccountId())) {
                crMasterService.updateCRMasterRemarksAndFailedStatus(crMasterEntity, "Parent Customer Account Code Is Empty with Company Id: " + crMasterEntity.getCompanyName());
                return;
            }

            List<CRMsisdnDetailsEntity> crMsisdnDetailsList = crMsisdnDetailsService.findAllCRMsisdnDetailsByCRMasterId(crMasterEntity.getId());

            List<List<CRMsisdnDetailsEntity>> result = Lists.partition(crMsisdnDetailsList, chunkSize);

            for (List<CRMsisdnDetailsEntity> crMsisdnDetails : result) {
                for (CRMsisdnDetailsEntity crMsisdnDetailsEntity : crMsisdnDetails) {
                    jobScheduler.enqueue(() -> proceedCRMsisdnNDetails(parentCustomer.getAccountId(), crMasterEntity, crMsisdnDetailsEntity));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error("ProceedCRMaster error: {}", e.getMessage(), e.getCause());
        }

    }

    public void proceedCRMsisdnNDetails(String customerId, CRMasterEntity crMasterEntity, CRMsisdnDetailsEntity crMsisdnDetailsEntity) {
        try {
            if (todayIsEffectiveDate(crMsisdnDetailsEntity)) {
                crBranchService.updateCRMasterStatus(crMasterEntity, CRStatusEnum.InProgress);
                crBranchService.executeChangeBranch(customerId, crMasterEntity, crMsisdnDetailsEntity);
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error("ProceedCRMsisdnNDetails error: {}", e.getMessage(), e.getCause());
        }
    }

    public Boolean todayIsEffectiveDate(CRMsisdnDetailsEntity crMsisdnDetailsEntity) {
        if (!ObjectUtils.isEmpty(crMsisdnDetailsEntity.getEffectiveDate())) {
            LocalDate parsedStringDate = crMsisdnDetailsEntity.getEffectiveDate();
            LocalDate currentDate = LocalDate.now();

            return parsedStringDate.compareTo(currentDate) == 0;
        } else {
            return false;
        }
    }
}
