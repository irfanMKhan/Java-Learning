package com.reddot.ecrm_bulk.implement;


import com.reddot.ecrm_bulk.config.Utility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.support.JdbcDaoSupport;



import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import com.reddot.ecrm_bulk.dao.commonDao.CommonDAO;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.util.Map;

public class CommonImpl extends JdbcDaoSupport implements CommonDAO {
    private static final Logger logger = LoggerFactory.getLogger(CommonImpl.class);

	@Override
	public Object CommoPagination(String sql) {
		Object Lists = new Object();
        try {
            Lists = getJdbcTemplate().queryForList(sql);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        return Lists;
	}

	@Override
	public Object CommoGetData(String sql) {
		Object Lists = new Object();
        logger.info(sql);
        try {
            Lists = getJdbcTemplate().queryForList(sql);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        return Lists;
	}

	@Override
	public String CommoGetJsonData(String sql) {
		Object Lists = new Object();
        logger.info(sql);
        try {
            Lists = getJdbcTemplate().queryForList(sql);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        return Utility.ObjectToJson(Lists);
	}

	@Override
	public int CommoNumberOfRow(String sql) {
		logger.info(sql);
        int count = 0;
        try {
            count = getJdbcTemplate().queryForObject(sql, Integer.class);

        } catch (Exception e) {
            logger.error(e.getMessage());
            System.out.println("Count Error: " + e.getMessage());
        }

        return count;
	}

	@Override
	public boolean CommoInsert(String tbl, Map<String, Object> query, Logger logger) {
		String Query = "";
        String inQryFields = "";
        String inQryVal = "";
        String InsQuery = "";
        String inQryInit = "";
        int list_size = query.size();
        Object[] inputs = new Object[list_size];
        if (query.size() > 0) {
            int i = 0;
            for (Map.Entry<String, Object> entry : query.entrySet()) {
                inQryFields += entry.getKey() + ",";
                inQryVal += "'" + entry.getValue() + "',";
                inQryInit += "?,";
                inputs[i++] = entry.getValue();
            }
            inQryInit = inQryInit.substring(0, inQryInit.trim().length() - 1);
            InsQuery = "INSERT INTO " + tbl + " (" + inQryFields.substring(0, inQryFields.trim().length() - 1) + ") VALUES (" + inQryInit + ")";
        }

        logger.info("Insert Query for " + tbl);
        logger.info(InsQuery);
        //System.out.println(InsQuery);
        logger.info("Insert Query data: ");
        logger.info(Utility.ObjectToJson(inputs));
        //System.out.println(Utility.ObjectToJson(inputs));

        try {
            getJdbcTemplate().update(InsQuery, inputs);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }
        return false;
	}

	@Override
	public boolean CommoUpdate(String tbl, Map<String, Object> setQry, Map<String, Object> whereQry, Logger logger) {
		String Query = "";
        String UpQryWhere = "";
        String UpQry = "";
        String UpsQuery = "";
        int i = 0;
        int setQrySize = setQry.size();
        int whereQrySize = whereQry.size();
        int total_size = setQrySize + whereQrySize;
        Object[] inputs = new Object[total_size];

        if (setQry.size() > 0) {
            for (Map.Entry<String, Object> entry : setQry.entrySet()) {
                UpQry += entry.getKey() + " =?,";
                inputs[i++] = entry.getValue();
            }
            UpQry = UpQry.substring(0, UpQry.trim().length() - 1);
        }

        if (whereQry.size() > 0) {
            for (Map.Entry<String, Object> entrys : whereQry.entrySet()) {
                UpQryWhere += entrys.getKey() + " =? AND ";
                inputs[i++] = entrys.getValue();
            }
            UpQryWhere = " WHERE " + UpQryWhere.substring(0, UpQryWhere.trim().length() - 4);
        }

        Query = "UPDATE " + tbl + " SET " + UpQry + UpQryWhere;
        System.out.println(Query);
        logger.info("Update Query: " + Query);
        logger.info("Update Query data: "+Utility.ObjectToJson(inputs));

        try {
            getJdbcTemplate().update(Query, inputs);
            return true;
        } catch (Exception e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        }
        return false;
	}

	@Override
	public boolean CommoUpdate(String qry, Logger logger) {
		try {
            getJdbcTemplate().update(qry);
            return true;
        } catch (Exception e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        }
        return false;
	}
	
	@Override
	public boolean CommoInsertSQL(String qry, Logger logger) {
		try {
            getJdbcTemplate().update(qry);
            return true;
        } catch (Exception e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        }
        return false;
	}

	@Override
	public boolean CommoDelete(String tbl, Map<String, Object> whereQry, Logger logger) {
		String Query = "";
        String UpQryWhere = "";
        int i = 0;
        int total_size = whereQry.size();
        Object[] inputs = new Object[total_size];


        if (whereQry.size() > 0) {
            for (Map.Entry<String, Object> entrys : whereQry.entrySet()) {
                UpQryWhere += entrys.getKey() + " =? AND ";
                inputs[i++] = entrys.getValue();
            }
            UpQryWhere = " WHERE " + UpQryWhere.substring(0, UpQryWhere.trim().length() - 4);
        }

        Query = "DELETE FROM " + tbl + " " + UpQryWhere;
        logger.info(Query);
        logger.info("Delete Query for " + tbl);
        logger.info(Query);
        logger.info("Delete Query data: ");
        logger.info(Utility.ObjectToJson(inputs));

        try {
            getJdbcTemplate().update(Query, inputs);
            return true;
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return false;
	}

	@Override
	public String getNextId(String sequenceName) {
		String nextId = null;
        try {
            String query = "SELECT  " + sequenceName + ".NEXTVAL FROM   dual";
            nextId = getJdbcTemplate().queryForObject(query, String.class);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return nextId;
	}

	@Override
	public String commonInsertGetReturn(String tbl, Map<String, Object> params, Logger logger, String returnColumn) {
		String generatedValue = "";
        String inQryFields = "";
        String inQryInit = "";
        int list_size = params.size();
        Object[] inputs = new Object[list_size];

        try {
            if (params.size() > 0) {
                int i = 0;
                for (Map.Entry<String, Object> entry : params.entrySet()) {
                    inQryFields += entry.getKey() + ",";
                    inQryInit += "?,";
                    inputs[i++] = entry.getValue();
                }
                inQryInit = inQryInit.substring(0, inQryInit.trim().length() - 1);
            } else {
                return "";
            }
            String query = "INSERT INTO " + tbl + " (" + inQryFields.substring(0, inQryFields.trim().length() - 1) + ") VALUES (" + inQryInit + ")";

            logger.info("Insert with return query: " + query);
            logger.info(Utility.ObjectToJson(inputs));

            KeyHolder keyHolder = new GeneratedKeyHolder();

            getJdbcTemplate().update(connection -> {
                PreparedStatement ps = connection
                        .prepareStatement(query, new String[]{returnColumn});
                for (int i = 0; i < inputs.length; i++) {
                    ps.setObject(i + 1, inputs[i]);
                }
                return ps;
            }, keyHolder);

            generatedValue = ((BigDecimal) keyHolder.getKeys().get(returnColumn)).toString();
            logger.info("Insert with return column: " + returnColumn + " and value: " + generatedValue);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return generatedValue;
	}
	
    @Override
    public boolean commonQuery(String query, Logger logger) {
        try {
            int rows = getJdbcTemplate().update(query);
            if (rows>0)
                return true;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return false;
    }
}
