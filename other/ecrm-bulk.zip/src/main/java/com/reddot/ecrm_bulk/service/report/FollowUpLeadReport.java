package com.reddot.ecrm_bulk.service.report;

import com.reddot.ecrm_bulk.pool_repository.CommonRepository;
import com.reddot.ecrm_bulk.service.notification.email.EmailSenderService;
import com.reddot.ecrm_bulk.service.notification.email.ThymleafService;
import lombok.RequiredArgsConstructor;
import org.apache.commons.codec.CharEncoding;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedCaseInsensitiveMap;

import javax.mail.internet.MimeMessage;
import java.util.*;

@Service
@RequiredArgsConstructor
public class FollowUpLeadReport {
    private final Logger logger = LoggerFactory.getLogger(getClass().getName());

    private final JavaMailSender sender;
    private final EmailSenderService emailSenderService;
    private final ThymleafService thymeleafService;
    private final CommonRepository commonRepository;
    private final JdbcTemplate jdbcTemplate;
    @Value("${spring.mail.from}")
    private String emailFromAddress;
    @Value("${file.directory}")
    String fileLocation;

    public void getEmailAddressOfFollowUpLeadsForToday(){
        try{
            String leadListSQL = "select u.name, u.email, l.kam_name, l.kam_id, l.follow_up_dt, l.lead_number, l.status_name from tbl_lead l join md_user u on u.name=l.kam_name where follow_up_dt < now()::date::timestamp and status_name not in ('Converted', 'Lost') order by kam_id;";
            Object data = commonRepository.CommoGetData(leadListSQL);

            List<LinkedCaseInsensitiveMap<String>> list = (List<LinkedCaseInsensitiveMap<String>>) data;
            if(!list.isEmpty()){
                logger.info("Lead found!");
                Map<String, List<Object>> result = new HashMap<>();

                list.forEach(item->{
                    result.computeIfAbsent(item.get("email"), k-> new ArrayList<>()).add(item);
                });

                result.keySet().forEach(item->{
                    Map<String, Object> model = new HashMap<>();
                    model.put("kam_name", item);
                    model.put("items", result.get(item));
                    MimeMessage mimeMessage = sender.createMimeMessage();
                    MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, CharEncoding.UTF_8);

                    try{
                        helper.setTo("arif.onoy@reddotdigitalit.com");
                        helper.setSubject("Lead Follow-up for today!");
                        helper.setText(thymeleafService.createContent("LeadFollowUp.html", model), true);
                        helper.setFrom(emailFromAddress);
//                        sender.send(mimeMessage);
                    }
                    catch (Exception e){
                        logger.error(e.getMessage());
                    }
                });

            }
            else{
                logger.info("No lead needs follow-up on "+ new Date());
            }
        }
        catch (Exception e){
            logger.error( "Error in getEmailAddressOfFollowUpLeadsForToday() :: "+ e.getMessage() , e);
        }
    }

    public void processMail(Map<String, List<Object>> items){
    }
}
