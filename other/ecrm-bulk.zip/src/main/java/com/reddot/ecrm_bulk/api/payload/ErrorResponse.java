package com.reddot.ecrm_bulk.api.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ErrorResponse implements Serializable {
  private Fault fault;

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class Fault implements Serializable {
    private Integer code;

    private String description;

    private String message;
  }
}
