package com.reddot.ecrm_bulk.api.gateway;

import com.google.gson.Gson;
import com.reddot.ecrm_bulk.api.exception.ApiRequestException;
import com.reddot.ecrm_bulk.api.exception.InvalidAccessTokenException;
import com.reddot.ecrm_bulk.api.exception.InvalidClientCredentialsException;
import com.reddot.ecrm_bulk.api.payload.subscriber.*;
import com.reddot.ecrm_bulk.api.utils.CommonConstant;
import com.reddot.ecrm_bulk.api.utils.HttpClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor
public class SubscriberGateway {
    private final HttpClient httpClient;
    private final Gson gson;
    private final AuthorizationGateway authorizationGateway;

    @Value("${smart.egw.base.url}")
    String baseUrlEGW;
    @Value("${smart.igw.base.url}")
    String baseUrlIGW;

    public ChangeSubscriberMSISDNResponse changeSubscriberMSISDN(String subscriberId, ChangeSubscriberMSISDNRequest subscriberMSISDNRequest) {
        String apiUrl = baseUrlIGW + "/api/bss/1208/subscribers/v2/" + subscriberId + "/change-msisdn?id_type=4";
        String json = gson.toJson(subscriberMSISDNRequest);

        try (Response response = httpClient.put(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), ChangeSubscriberMSISDNResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ChangeSubscriberMSISDNResponse errorResponse = gson.fromJson(response.body().string(), ChangeSubscriberMSISDNResponse.class);
                throw new ApiRequestException(errorResponse.getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("ChangeSubscriberMSISDN Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("ChangeSubscriberMSISDN Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            }
            log.error("ChangeSubscriberMSISDN Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    public ChangeSubscriberSIMResponse changeSubscriberSIM(String subscriberId, ChangeSubscriberSIMRequest subscriberSIMRequest) {
        String apiUrl = baseUrlIGW + "/api/bss/1210/subscribers/v2/" + subscriberId + "/change-sim?id_type=4";
        String json = gson.toJson(subscriberSIMRequest);

        try (Response response = httpClient.put(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), ChangeSubscriberSIMResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ChangeSubscriberSIMResponse errorResponse = gson.fromJson(response.body().string(), ChangeSubscriberSIMResponse.class);
                throw new ApiRequestException(errorResponse.getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("ChangeSubscriberSIM Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("ChangeSubscriberSIM Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            }
            log.error("ChangeSubscriberSIM Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    public ResetNetworkResponse resetNetwork(String subscriberId, ResetNetworkRequest resetNetworkRequest) {
        String apiUrl = baseUrlIGW + "/api/bss/1201/cust-service/v2/" + subscriberId + "/change-network-setting?id_type=4";
        String json = gson.toJson(resetNetworkRequest);

        try (Response response = httpClient.put(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), ResetNetworkResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ResetNetworkResponse errorResponse = gson.fromJson(response.body().string(), ResetNetworkResponse.class);
                throw new ApiRequestException(errorResponse.getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("ResetNetwork Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("ResetNetwork Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialsException) {
                log.debug("ResetNetwork Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialsException(e.getMessage());
            }
            log.error("ResetNetwork Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    public ReportLostResponse reportLost(String subscriberId, ReportLostRequest lostRequest) {
        String apiUrl = baseUrlIGW + "/api/bss/subscribers/v1/" + subscriberId + "/report_lost?id_type=msisdn";
        String json = gson.toJson(lostRequest);

        try (Response response = httpClient.put(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), ReportLostResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ReportLostErrorResponse errorResponse = gson.fromJson(response.body().string(), ReportLostErrorResponse.class);
                throw new ApiRequestException(errorResponse.getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("ReportLost Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("ReportLost Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialsException) {
                log.debug("ReportLost Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialsException(e.getMessage());
            }
            log.error("ReportLost Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    public ReportLostResponse cancelLost(String subscriberId, ReportLostRequest lostRequest) {
        String apiUrl = baseUrlIGW + "/api/bss/subscribers/v1/" + subscriberId + "/cancel_lost?id_type=msisdn";
        String json = gson.toJson(lostRequest);

        try (Response response = httpClient.put(json, apiUrl, getIGWHeaders())) {
            assert response.body() != null;
            if (response.code() == HttpStatus.OK.value()) {
                return gson.fromJson(response.body().string(), ReportLostResponse.class);
            } else if (response.code() == HttpStatus.NOT_FOUND.value()) {
                log.debug("Url Not Found: " + apiUrl);
                throw new ApiRequestException(CommonConstant.COMMON_ERROR);
            } else if (response.code() == HttpStatus.UNAUTHORIZED.value()) {
                throw new InvalidAccessTokenException();
            } else {
                ReportLostErrorResponse errorResponse = gson.fromJson(response.body().string(), ReportLostErrorResponse.class);
                throw new ApiRequestException(errorResponse.getMessage());
            }
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("ReportLost Api Request Error: {}", e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof InvalidAccessTokenException) {
                log.debug("ReportLost Access Token Error: {}", e.getMessage());
                throw new InvalidAccessTokenException();
            } else if (e instanceof InvalidClientCredentialsException) {
                log.debug("ReportLost Credentials Error: {}", e.getMessage());
                throw new InvalidClientCredentialsException(e.getMessage());
            }
            log.error("ReportLost Error: {}", e.getMessage(), e.getCause());
            throw new ApiRequestException(CommonConstant.COMMON_ERROR);
        }
    }

    private Map<String, String> getIGWHeaders() {
        String bearerToken = authorizationGateway.getTokenIGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }

    private Map<String, String> getHeaders() {
        String bearerToken = authorizationGateway.getTokenEGW().getAccess_token();
        return new HashMap<String, String>() {{
            put("Authorization", "Bearer " + bearerToken);
            put("Accept", "application/json");
        }};
    }
}
