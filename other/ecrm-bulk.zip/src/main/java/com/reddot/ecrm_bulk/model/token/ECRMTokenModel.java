package com.reddot.ecrm_bulk.model.token;

public class ECRMTokenModel {
	private String expireTime, token;

	public String getExpireTime() {
		return expireTime;
	}

	public void setExpireTime(String expireTime) {
		this.expireTime = expireTime;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
	
	
}
