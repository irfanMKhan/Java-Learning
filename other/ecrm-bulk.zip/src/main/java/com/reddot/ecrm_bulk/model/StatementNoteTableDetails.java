package com.reddot.ecrm_bulk.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class StatementNoteTableDetails {
    private int tbl_no;
    private String tbl_purpose;
    private int tbl_quantity;
    private double tbl_unit_price;
    private double tbl_amount;

    public StatementNoteTableDetails(int tbl_no,
                                     String tbl_purpose,
                                     int tbl_quantity,
                                     double tbl_unit_price) {
        this.tbl_no = tbl_no;
        this.tbl_purpose = tbl_purpose;
        this.tbl_quantity = tbl_quantity;

        double unitPrice = tbl_unit_price /100000000;
        this.tbl_unit_price = unitPrice;

        this.tbl_amount = tbl_quantity * unitPrice;
    }
}
