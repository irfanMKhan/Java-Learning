package com.reddot.ecrm_bulk.service.bulk;

import com.reddot.ecrm_bulk.entity.bulk.BulkFile;
import com.reddot.ecrm_bulk.enums.bulk.BulkProcessFileType;
import com.reddot.ecrm_bulk.enums.status.Status;
import com.reddot.ecrm_bulk.repository.bulk.BulkFileRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class BulkFileServiceImpl implements BulkFileService {
    private final BulkFileRepository bulkFileRepository;

    @Override
    public List<BulkFile> findAll() {
        try {
            List<BulkFile> bulkFiles = bulkFileRepository.findAll();
            if (CollectionUtils.isEmpty(bulkFiles)) {
                return new ArrayList<>();
            } else {
                return bulkFiles;
            }
        } catch (Exception e) {
            log.error("Bulk File Find All Error: {}", e.getMessage(), e.getCause());
            return new ArrayList<>();
        }
    }

    @Override
    public BulkFile findById(Long id) {
        try {
            return bulkFileRepository.findById(id);
        } catch (EmptyResultDataAccessException e) {
            log.debug("Bulk File Not Found with Id: {}", id);
            return null;
        }
    }

    @Override
    public List<BulkFile> findAllTodosByIsRun(Boolean isRun) {
        try {
            List<BulkFile> bulkFiles = bulkFileRepository.findAllTodosByIsRun(isRun, BulkProcessFileType.Change_Branch);
            if (CollectionUtils.isEmpty(bulkFiles)) {
                return new ArrayList<>();
            } else {
                return bulkFiles;
            }
        } catch (Exception e) {
            log.error("Bulk File Find All Todos Error: {}", e.getMessage(), e.getCause());
            return new ArrayList<>();
        }
    }
    @Override
    public List<BulkFile> findAllTodosAndInProgressByIsRun(Boolean isRun) {
        try {
            List<BulkFile> bulkFiles = bulkFileRepository.findAllTodosAndInProgressByIsRun(isRun);
            if (CollectionUtils.isEmpty(bulkFiles)) {
                return new ArrayList<>();
            } else {
                return bulkFiles;
            }
        } catch (Exception e) {
            log.error("Bulk File Find All Todos And InProgress Error: {}", e.getMessage(), e.getCause());
            return new ArrayList<>();
        }
    }

    @Override
    public int update(List<Long> ids, Status status) {
        try {
            return bulkFileRepository.update(ids, status);
        } catch (Exception e) {
            log.debug("Bulk File Ids Update Error: {}", e.getMessage(), e.getCause());
            return 0;
        }
    }

    @Override
    public BulkFile update(BulkFile bulkFile) {
        try {
            return bulkFileRepository.update(bulkFile);
        } catch (Exception e) {
            log.debug("Bulk File Update Error: {}", e.getMessage(), e.getCause());
            return null;
        }
    }

    @Override
    public void updateBulkFileStatus(List<List<BulkFile>> bulkFileList, Status status) {
        for (List<BulkFile> bulkFiles: bulkFileList) {
            List<Long> ids = new ArrayList<>();
            for (BulkFile bulkFile: bulkFiles) {
                ids.add(bulkFile.getId());
            }
            update(ids, status);
        }
    }

    @Override
    public void updateBulkFileTotalRowsAndIsRun(BulkFile bulkFile, int totalRows, boolean isRun) {
        bulkFile.setTotalRows(totalRows);
        bulkFile.setIsRun(true);
        update(bulkFile);
    }
}
