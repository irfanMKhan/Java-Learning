package com.reddot.ecrm_bulk.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

public class SingletonTransactionNumberGenerator {
    private static final SingletonTransactionNumberGenerator object = new SingletonTransactionNumberGenerator();
    private static AtomicInteger counter = null;
    private static LocalDate lastResetDate;

    private SingletonTransactionNumberGenerator() {
        if (counter != null) {
            //if anyone reinitialized using java reflection.
            throw new RuntimeException("Counter already initialized.");
        }
        counter = new AtomicInteger(0);
        lastResetDate = LocalDate.now();
    }

    private static SingletonTransactionNumberGenerator getInstance() {
        return object;
    }

    public static synchronized String getNextTransactionNumber() {
        resetCounterValue();
        String dateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        dateTime = new String(dateTime.substring(2, dateTime.length()));  //23MMddHHmmss
        int number = counter.incrementAndGet();
        String transactionNumber = dateTime + String.format("%02d", number);
        return transactionNumber;
    }

    private static void resetCounterValue() {
        if (counter == null) {
            new SingletonTransactionNumberGenerator();
        }
        //if counter == 99 then it will reset to 0
        if (counter.incrementAndGet() == 99) {
            counter.set(0);
        }
        //new date will auto set counter to 0
        LocalDate currentDate = LocalDate.now();
        if (!currentDate.equals(lastResetDate)) {
            counter.set(0);
            lastResetDate = currentDate;
        }
    }
}
