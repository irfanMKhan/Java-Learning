package com.reddot.ecrm_bulk.service.number_activation.strategy.payment;

import com.reddot.ecrm_bulk.entity.annex.Annex;
import com.reddot.ecrm_bulk.entity.contract.Contract;
import com.reddot.ecrm_bulk.service.number_activation.ActivationService;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;

@Service
public class NoDeviceStrategy implements PaymentStrategy {
    private final ActivationService activationService;

    public NoDeviceStrategy(ActivationService _activationService) {
        activationService = _activationService;
    }

    @Override
    public void process(Contract contract, Annex annex) throws UnsupportedEncodingException {
        if (! activationService.hasDevice(annex)) {
            if (activationService.todayIsEffectiveDate(annex)) {
                activationService.executeActivation(contract, annex);
            }
        }
    }
}
