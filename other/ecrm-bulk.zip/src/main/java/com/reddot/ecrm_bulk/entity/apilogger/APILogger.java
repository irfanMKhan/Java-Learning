package com.reddot.ecrm_bulk.entity.apilogger;


import io.hypersistence.utils.hibernate.type.json.JsonBinaryType;
import io.hypersistence.utils.hibernate.type.json.JsonStringType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.*;
import java.sql.Timestamp;

@Table(name = "tbl_api_logger")
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@TypeDefs({
        @TypeDef(name = "json", typeClass = JsonStringType.class),
        @TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
})
public class APILogger {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "id_generator_api_logger")
    @SequenceGenerator(name = "id_generator_api_logger", initialValue = 1, allocationSize = 1)
    private Long id;
    @Column(name = "http_method")
    private String httpMethod;

    @Column(name = "channel")
    private String channel;

    @Column(name = "correlation_id")
    private String correlationId;

    @Column(name = "path_info")
    private String pathInfo;

    @Type(type = "jsonb")
    @Column(name = "request_parameters", columnDefinition = "json")
    private String requestParameters;

    @Type(type = "jsonb")
    @Column(name = "request_body", columnDefinition = "json")
    private String requestBody;

    @Type(type = "jsonb")
    @Column(name = "response", columnDefinition = "json")
    private String response;

    @Column(name = "response_status")
    private Integer responseStatus;

    @Column(name = "remote_address")
    private String remoteAddress;

    @Column(name = "request_time")
    private Timestamp requestTime;

    @Column(name = "response_time")
    private Timestamp responseTime;

    @Column(name = "elapsed_time")
    private Long elapsedTime;

    private String featureName;
    private Long featureId;
    private String transaction;
    private Integer stepNumber;
    private String stepDescription;
    private String status;
    private Long primaryTableId;
    private String primaryTableName;
}
