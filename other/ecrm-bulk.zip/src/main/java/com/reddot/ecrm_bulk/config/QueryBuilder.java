package com.reddot.ecrm_bulk.config;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QueryBuilder {
    public static String getWherQueryPagination(String tbl, Map<String, Object> query, int StartPage, int limitPage, Map<String, Object> whereSearchType) {
        String where = "";
        String Query = "";

        if (query.size() > 0) {
            for (Map.Entry<String, Object> entry : query.entrySet()) {
                if (whereSearchType.get(entry.getKey()).toString().toUpperCase().equals("AND")) {
                    where += entry.getKey() + " = '" + entry.getValue() + "' AND ";
                } else if (whereSearchType.get(entry.getKey()).toString().toUpperCase().equals("LIKE")) {
                    where += entry.getKey() + " LIKE '%" + entry.getValue() + "%' AND ";
                }
            }
            if (!where.equals("")) {
                //System.out.println("where" + where);
                where = "where " + where.substring(0, where.trim().length() - 4);
            }
        }

        Query = "SELECT * FROM " + tbl + " " + where + " ORDER BY ID DESC OFFSET " + StartPage + " ROWS FETCH NEXT " + limitPage + " ROWS ONLY";
        System.out.println(Query);
        return Query.trim();
    }
    
    
    

    public static String getSelectWhereQuery(String tbl, Map<String, Object> query, Map<String, Object> whereSearchType) {
        String where = "";
        String Query = "";

        if (query.size() > 0) {
            for (Map.Entry<String, Object> entry : query.entrySet()) {
                if (whereSearchType.get(entry.getKey()).toString().toUpperCase().equals("AND")) {
                    where += entry.getKey() + " = '" + entry.getValue() + "' AND ";
                } else   if (whereSearchType.get(entry.getKey()).toString().toUpperCase().equals("LIKE")) {
                    where += entry.getKey() + " LIKE '%" + entry.getValue() + "%' AND ";
                }
            }

            where = "where " + where.substring(0, where.trim().length() - 4);
        }
        Query = "Select * from " + tbl + " " + where;
        System.out.println(Query);
        return Query.trim();
    }

    public static String getSelectWhereQuery(String tbl, Map<String, Object> query, Map<String, Object> whereSearchType, List selectItem) {
        String where = "";
        String Query = "";

        if (query.size() > 0) {
            for (Map.Entry<String, Object> entry : query.entrySet()) {
                if (whereSearchType.get(entry.getKey()).toString().toUpperCase().equals("AND")) {
                    where += entry.getKey() + " = '" + entry.getValue() + "' AND ";
                } else   if (whereSearchType.get(entry.getKey()).toString().toUpperCase().equals("LIKE")) {
                    where += entry.getKey() + " LIKE '%" + entry.getValue() + "%' AND ";
                }
            }

            where = "where " + where.substring(0, where.trim().length() - 4);
        }
        Query = "Select "+ String.join(",", selectItem)+" from " + tbl + " " + where;
        System.out.println(Query);
        return Query.trim();
    }


    public static String getCountWhereQuery(String tbl, Map<String, Object> query, Map<String, Object> whereSearchType) {
        String where = "";
        String Query = "";
        // whereSearchType.get('test')
        if (query.size() > 0) {
            for (Map.Entry<String, Object> entry : query.entrySet()) {
                if (whereSearchType.get(entry.getKey()).toString().toUpperCase().equals("AND")) {
                    where += entry.getKey() + " = '" + entry.getValue() + "' AND ";
                } else if (whereSearchType.get(entry.getKey()).toString().toUpperCase().equals("LIKE")) {
                    where += entry.getKey() + " LIKE '%" + entry.getValue() + "%' AND ";
                }
            }
            where = "where " + where.substring(0, where.trim().length() - 4);
        }
        Query = "Select count(ID) from " + tbl + " " + where;
        System.out.println(Query);
        return Query.trim();
    }


    public static String getSelectWhereFieldsQuery(String tbl, Map<String, Object> query, String fields, Map<String, Object> whereSearchType) {
        String where = "";
        String Query = "";
        if (query.size() > 0) {
            for (Map.Entry<String, Object> entry : query.entrySet()) {
                if (whereSearchType.get(entry.getKey()).toString().toUpperCase().equals("AND")) {
                    where += entry.getKey() + " = '" + entry.getValue() + "' AND ";
                }  else if (whereSearchType.get(entry.getKey()).toString().toUpperCase().equals("LIKE")) {
                    where += entry.getKey() + " LIKE '%" + entry.getValue() + "%' AND ";
                }
            }

            where = "where " + where.substring(0, where.trim().length() - 4);
        }
        Query = "Select "+fields+" from " + tbl + " " + where;
        System.out.println(Query);
        return Query.trim();
    }
    
    
    public static String getWherQueryPaginationWithoutOrder(String tbl, Map<String, Object> query, int StartPage, int limitPage, Map<String, Object> whereSearchType) {
        String where = "";
        String Query = "";

        if (query.size() > 0) {
            for (Map.Entry<String, Object> entry : query.entrySet()) {
                if (whereSearchType.get(entry.getKey()).toString().toUpperCase().equals("AND")) {
                    where += entry.getKey() + " = '" + entry.getValue() + "' AND ";
                } else if (whereSearchType.get(entry.getKey()).toString().toUpperCase().equals("LIKE")) {
                    where += entry.getKey() + " LIKE '%" + entry.getValue() + "%' AND ";
                }
            }
            if (!where.equals("")) {
                where = "where " + where.substring(0, where.trim().length() - 4);
            }
        }

        Query = "SELECT * FROM " + tbl + " " + where + " OFFSET " + StartPage + " ROWS FETCH NEXT " + limitPage + " ROWS ONLY";
//        System.out.println(Query);
        return Query.trim();
    }

}
