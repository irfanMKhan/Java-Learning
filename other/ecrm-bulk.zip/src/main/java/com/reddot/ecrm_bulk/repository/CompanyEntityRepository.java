package com.reddot.ecrm_bulk.repository;

import com.reddot.ecrm_bulk.entity.company.Company;
import com.reddot.ecrm_bulk.entity.notification.NotificationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CompanyEntityRepository extends JpaRepository<Company,Long> {
    Company findByName(String companyName);

}
