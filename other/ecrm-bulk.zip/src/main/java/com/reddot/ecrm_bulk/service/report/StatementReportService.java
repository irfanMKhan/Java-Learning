package com.reddot.ecrm_bulk.service.report;

import com.reddot.ecrm_bulk.entity.company.Company;
import com.reddot.ecrm_bulk.entity.contract.ContactEntity;
import com.reddot.ecrm_bulk.entity.statement_note.StatementNoteEntity;
import com.reddot.ecrm_bulk.enums.notification.NotificationStatusEnum;
import com.reddot.ecrm_bulk.model.StatementNoteModel;
import com.reddot.ecrm_bulk.model.StatementNoteTableDetails;
import com.reddot.ecrm_bulk.repository.CompanyEntityRepository;
import com.reddot.ecrm_bulk.repository.ContactJPARepository;
import com.reddot.ecrm_bulk.repository.statement.StatementNoteRepository;
import com.reddot.ecrm_bulk.service.notification.email.EmailSenderService;
import com.reddot.ecrm_bulk.util.Utility;
import lombok.RequiredArgsConstructor;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.*;

@Service
@RequiredArgsConstructor
public class StatementReportService {
    private final Logger logger = LoggerFactory.getLogger(getClass().getName());
    private final StatementNoteRepository statementNoteRepository;
    private final EmailSenderService emailSenderService;
    private final CompanyEntityRepository companyEntityRepository;
    private final ContactJPARepository contactJPARepository;

    @Value("${smart.statement.note.country.code}")
    private String countryCode;
    @Value("${smart.statement.note.country.lang}")
    private String lang;
    @Value("${smart.statement.note.country.fractional.unit}")
    private String fractionalUnits;
    @Value("${smart.statement.note.bank.account.name}")
    private String bankAccountName;
    @Value("${smart.statement.note.bank.account.no}")
    private String bankAccountNo;
    @Value("${smart.statement.note.beneficiary.bank.name}")
    private String beneficiaryBankName;
    @Value("${smart.statement.note.swift}")
    private String swift;
    @Value("${smart.statement.note.authorized.signature.name}")
    private String authorizedName;
    @Value("${smart.statement.note.authorized.signature.position}")
    private String authorizedPosition;
    @Value("${smart.statement.reports.template}")
    private String reportingTemplate;
    @Value("${smart.statement.dataSourceLocation}")
    private String dataSourceLocation;
    @Value("${smart.statement.personType}")
    private String personType;
    @Value("${smart.statement.emailSubject}")
    private String emailSubject;
    @Value("${smart.statement.emailBody}")
    private String emailBody;

    private static Map<String, Object> convertDetailsToParameters(StatementNoteModel receiptData) {
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("to", receiptData.getTo());
        parameters.put("address", receiptData.getAddress());
        parameters.put("ref", receiptData.getRef());
        parameters.put("attn", receiptData.getAttn());
        parameters.put("date", receiptData.getDate());
        parameters.put("sn", receiptData.getSn());
        parameters.put("total", receiptData.getTotal());
        parameters.put("amount_in_word", receiptData.getAmount_in_word());
        parameters.put("bank_account_name", receiptData.getBank_account_name());
        parameters.put("bank_account_no", receiptData.getBank_account_no());
        parameters.put("beneficiary_bank_name", receiptData.getBeneficiary_bank_name());
        parameters.put("swift", receiptData.getSwift());
        parameters.put("authorized_signer_name", receiptData.getAuthorized_signer_name());
        parameters.put("authorized_signer_position", receiptData.getAuthorized_signer_position());

        return parameters;
    }

    public void processStatementReportData() {
        try {
            List<StatementNoteEntity> notificationEntityListWithIsIndividualTrue = fetchStatementNoteDataIsIndividual(NotificationStatusEnum.TODO.toString().toUpperCase(), true);
            List<StatementNoteEntity> notificationEntityListWithIsIndividualFalse = fetchStatementNoteDataIsIndividual(NotificationStatusEnum.TODO.toString().toUpperCase(), false);
            List<StatementNoteEntity> allnotificationEntityList = new ArrayList<>();
            if (Objects.nonNull(notificationEntityListWithIsIndividualTrue)) {
                allnotificationEntityList.addAll(notificationEntityListWithIsIndividualTrue);
            }

            if (Objects.nonNull(notificationEntityListWithIsIndividualFalse)) {
                allnotificationEntityList.addAll(notificationEntityListWithIsIndividualFalse);
            }

            if (allnotificationEntityList == null) {
                return;
            }

            Boolean created = createDirectoryIfNotExist(reportingTemplate);
            if (created) {
                for (StatementNoteEntity statementNoteEntity : allnotificationEntityList) {
                    //BackgroundJob.enqueue(() -> processForSendSMSOrEmail(notificationEntity));
                    String filename = generateStatementReport(statementNoteEntity);
                    List<ContactEntity> picEmail = picEmailList(statementNoteEntity.getCompanyId());

                    List<String> emailList = new ArrayList<>();
                    //picEmail.add("sajibcse42@gmail.com");//added for test purpose
                    if (picEmail != null) {
                        for (ContactEntity contactEntity : picEmail) {
                            String mail = contactEntity.getEmail();
                            if (mail != null)
                                emailList.add(mail);
                        }

                        Boolean emailSent = sendEmail(emailList, filename);
                        if (emailSent) {
                            statementNoteEntity.setStatus(NotificationStatusEnum.Sent.toString());
                            statementNoteRepository.save(statementNoteEntity);
                            logger.info("StatementReportService: processStatementReportData  statementNoteEntity transactionId: " + statementNoteEntity.getTransactionId() + "success");
                        } else {
                            logger.info("StatementReportService: processStatementReportData  statementNoteEntity transactionId: " + statementNoteEntity.getTransactionId() + "fail");
                        }
                    } else {
                        logger.info("StatementReportService: processStatementReportData PIC mail list is null for statementNoteEntity transactionId: " + statementNoteEntity.getTransactionId() + "fail");
                    }
                }
            } else {
                logger.info("StatementReportService: Error in Directory Creation");
            }
        } catch (Exception ex) {
            logger.info("StatementReportService: processStatementReportData Exception : " + ex.getMessage());
        }
    }

    public List<StatementNoteEntity> fetchStatementNoteDataIsIndividual(String status, Boolean isIndividual) {
        try {
            Optional<List<StatementNoteEntity>> statementNoteEntityList = statementNoteRepository.findAllByStatusAndIsIndividual(status, isIndividual);
            if (!statementNoteEntityList.isPresent()) {
                logger.info("statementNoteEntityList is null");
                return new ArrayList<>(); //no data found, return empty array list
            }
            return statementNoteEntityList.get();
        } catch (Exception ex) {
            logger.info("StatementReportService: fetchStaementNoteData Exception: " + ex.getMessage());
            return null;
        }

    }


    public Boolean sendEmail(List<String> emailList, String filename) throws MessagingException {
        try {
            String subject = emailSubject;//will change later make dynamic
            String body = emailBody;///will change later make dynamic
            File file = new File(dataSourceLocation + filename);
            if (emailList == null || emailList.size() == 0) {
                logger.info("StatementReportService: sendEmail : emailList is empty. ");
                return false;
            }
            Boolean isSent = emailSenderService.sendEmailwithAttachmentForStatement(emailList, body, subject, file, "");
            return isSent;
        } catch (Exception ex) {
            logger.info("StatementReportService: sendEmail Exception: " + ex.getMessage());
            return false;
        }
    }

    //just copy and paste download function from ecrm

    public String generateStatementReport(StatementNoteEntity statementNoteEntity) {
        List<StatementNoteEntity> entityList = new ArrayList<>();
        if (!statementNoteEntity.getIsIndividual()) {
            entityList = statementNoteRepository.findAllByTransactionId(statementNoteEntity.getTransactionId());
        } else {
            entityList = statementNoteRepository.findAllByIndivisualTransactionId(statementNoteEntity.getIndivisualTransactionId());
        }

        StatementNoteEntity entity = entityList.get(0);

        StatementNoteModel statementDetails = new StatementNoteModel();
        statementDetails.setTo(entity.getCompanyName());
        statementDetails.setRef("-");
        statementDetails.setAttn("-");
        String localDate = LocalDate.now().toString();
        statementDetails.setDate(localDate);
        statementDetails.setSn(entity.getTransactionId());
        statementDetails.setBank_account_name(bankAccountName);
        statementDetails.setBank_account_no(bankAccountNo);
        statementDetails.setBeneficiary_bank_name(beneficiaryBankName);
        statementDetails.setSwift(swift);
        statementDetails.setAuthorized_signer_name(authorizedName);
        statementDetails.setAuthorized_signer_position(authorizedPosition);

        List<StatementNoteTableDetails> tableDetails = new ArrayList<>();

        int count = 1;
        for (StatementNoteEntity statementNote : entityList) {
            StatementNoteTableDetails noteTableDetails = new StatementNoteTableDetails(count++, statementNote.getFeatureName(), 1, statementNote.getUnitPrice());
            tableDetails.add(noteTableDetails);
        }
        statementDetails.setTable_details(tableDetails);

        statementDetails.setTotal(StatementNoteModel.calculateTotalCost(statementDetails.getTable_details()));

        statementDetails.setAmount_in_word(Utility.translate(countryCode, lang, String.valueOf(statementDetails.getTotal()), fractionalUnits));

        Company companyEntity = companyEntityRepository.findByName(entity.getCompanyName());

        String address = "";

        if (companyEntity.getHouseNum() != null) {
            if (!Objects.equals(companyEntity.getHouseNum().trim(), "")) {
                address = address + "House: " + companyEntity.getHouseNum() + ", ";
            }
        }

        if (companyEntity.getStreet() != null) {
            if (!Objects.equals(companyEntity.getStreet().trim(), "")) {
                address = address + "Street: " + companyEntity.getStreet() + ", ";
            }
        }

        if (companyEntity.getSangkatCommuneName() != null) {
            if (!Objects.equals(companyEntity.getSangkatCommuneName().trim(), "-- Select --")) {
                address = address + "SangKat: " + companyEntity.getSangkatCommuneName() + ", ";
            }
        }
        if (companyEntity.getCityProvinceName() != null) {
            if (!Objects.equals(companyEntity.getCityProvinceName().trim(), "-- Select --")) {
                address = address + "City: " + companyEntity.getCityProvinceName() + ", ";
            }
        }
        if (companyEntity.getKhanDistrictName() != null) {
            if (!Objects.equals(companyEntity.getKhanDistrictName().trim(), "-- Select --")) {
                address = address + "Khan: " + companyEntity.getKhanDistrictName() + ", ";
            }
        }
        if (companyEntity.getCountryName() != null) {
            if (!Objects.equals(companyEntity.getCountryName().trim(), "-- Select --")) {
                address = address + "Country: " + companyEntity.getCountryName() + ", ";
            }
        }
//        statementDetails.setAddress(entity.getAddress());
        statementDetails.setAddress(address);

        InputStream topLeftLogo = convertResourceToInputStream("reports/" + statementDetails.getSmartLogoFileName());
        InputStream signatureImg = convertResourceToInputStream("reports/" + statementDetails.getSignatureImgName());

        try {
            File resource = new File(reportingTemplate + "statementNote.jrxml");

            InputStream transactionReportStream = new FileInputStream(resource);

            JasperReport jasperReport = JasperCompileManager.compileReport(transactionReportStream);

            Map<String, Object> parameters = convertDetailsToParameters(statementDetails);

            // Including the images
            parameters.put("topLeftLogo", topLeftLogo);
            parameters.put("signatureImg", signatureImg);

            String fileName = "Statement_note_" + statementDetails.getDate() + "_" + statementDetails.getSn() + ".pdf";


            List<StatementNoteTableDetails> table_details = statementDetails.getTable_details();
            JRBeanCollectionDataSource table_details_dataSource = new JRBeanCollectionDataSource(table_details);
            parameters.put("table_details_dataSource", table_details_dataSource);
            parameters.put("total_amount", statementDetails.getTotal());


            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, new JREmptyDataSource());

            JRPdfExporter exporter = new JRPdfExporter();
            exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
            File outputFile = new File(dataSourceLocation + fileName);
            exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(outputFile));
            exporter.exportReport();
            return fileName;

        } catch (IOException | JRException e) {
            throw new RuntimeException(e);
        }
    }

    public List<ContactEntity> picEmailList(Long companyId) {
//        List<String> emailList = new ArrayList<>();
        List<ContactEntity> emailList = new ArrayList<>();
        try {
            emailList = contactJPARepository.findAllEntityByCompanyIdAndPersonTypeText(companyId, personType);
            if (emailList.size() == 0) {
                logger.info("StatementReportService: picEmailList is null  for companyId ={}", companyId);
            }

        } catch (Exception e) {
            e.printStackTrace();
            logger.error("StatementReportService: picEmailList:{0} " + e.getMessage());
        }
        return emailList;
    }

    private InputStream convertResourceToInputStream(String path) {
        Resource resource = new ClassPathResource(path);
        InputStream imageData = null;
        try {
            imageData = resource.getInputStream();

        } catch (IOException e) {
            e.printStackTrace();
            logger.error("StatementReportService: convertResourceToInputStream:{0} " + e.getMessage());
        }
        return imageData;
    }

    public boolean createDirectoryIfNotExist(String path) {
        File directory = new File(path);

        if (!directory.exists()) {
            boolean created = directory.mkdirs();

            if (created) {
                System.out.println("Directory created successfully.");
                return true;
            } else {
                System.out.println("Failed to create the directory.");
                return false;
            }
        } else {
            System.out.println("Directory already exists.");
            return true;
        }

    }


}
