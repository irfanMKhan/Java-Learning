package com.reddot.ecrm_bulk.dto.SwapSim;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Getter
@Setter
@Data
public class SwapJsonDataDTO {
    private String newmsisdn;
    private String finalcost;
    private String oldmsisdn;
    private String financialtypetext;
    private String oldiccid;
    private String ptpdays;
    private String financialtypeamount;
    private String newiccid;
    @SerializedName("ptpdate(dd-mm-yyyy)")
    @Expose
    private String ptp_date;
    private Boolean ptp;
    private String swaptype;
    private String servicecharge;
    private String companyname;
    private String filelocation;
    private String accountcode;

}
