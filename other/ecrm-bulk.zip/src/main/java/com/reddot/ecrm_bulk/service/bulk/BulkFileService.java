package com.reddot.ecrm_bulk.service.bulk;

import com.reddot.ecrm_bulk.entity.bulk.BulkFile;
import com.reddot.ecrm_bulk.enums.status.Status;

import java.util.List;

public interface BulkFileService {
    List<BulkFile> findAll();

    BulkFile findById(Long id);

    List<BulkFile> findAllTodosByIsRun(Boolean isRun);

    List<BulkFile> findAllTodosAndInProgressByIsRun(Boolean isRun);

    int update(List<Long> ids, Status status);

    BulkFile update(BulkFile bulkFile);

    void updateBulkFileStatus(List<List<BulkFile>> bulkFileList, Status status);

    void updateBulkFileTotalRowsAndIsRun(BulkFile bulkFile, int totalRows, boolean isRun);
}
