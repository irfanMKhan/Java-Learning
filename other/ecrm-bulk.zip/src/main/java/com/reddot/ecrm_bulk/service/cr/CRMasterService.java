package com.reddot.ecrm_bulk.service.cr;

import com.reddot.ecrm_bulk.entity.cr.CRMasterEntity;
import com.reddot.ecrm_bulk.enums.requestType.CommonStatusEnum;

import java.util.List;

public interface CRMasterService {
    List<CRMasterEntity> findAllOpenStatus();

    CRMasterEntity findById(Long id);

    void updateFinalStatus(CRMasterEntity crMasterEntity, CommonStatusEnum commonStatusEnum);

    void updateCRMasterRemarksAndFailedStatus(CRMasterEntity crMasterEntity, String remarks);

    CRMasterEntity update(CRMasterEntity crMasterEntity);

    void updateFinalStatus(List<List<CRMasterEntity>> crMasterList, CommonStatusEnum status);
}
