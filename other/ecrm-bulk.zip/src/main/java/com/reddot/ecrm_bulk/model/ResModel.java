package com.reddot.ecrm_bulk.model;

public class ResModel {
    String ResultCode,ResultDesc,Url,ActionName;
    boolean IsSuccess;

    public ResModel() {
    }

    public ResModel(String resultCode, String resultDesc, boolean isSuccess) {
        ResultCode = resultCode;
        ResultDesc = resultDesc;
        IsSuccess = isSuccess;
    }

    public ResModel(String url,String resultCode, String resultDesc,  boolean isSuccess) {
        ResultCode = resultCode;
        ResultDesc = resultDesc;
        Url = url;
        IsSuccess = isSuccess;
    }

    public ResModel( String  actionName,String resultDesc) {
        ActionName = actionName;
        ResultDesc = resultDesc;
    }

    public String getResultCode() {
        return ResultCode;
    }

    public void setResultCode(String resultCode) {
        ResultCode = resultCode;
    }

    public String getResultDesc() {
        return ResultDesc;
    }

    public void setResultDesc(String resultDesc) {
        ResultDesc = resultDesc;
    }

    public boolean isSuccess() {
        return IsSuccess;
    }

    public void setSuccess(boolean success) {
        IsSuccess = success;
    }

    public String getUrl() {
        return Url;
    }

    public void setUrl(String url) {
        Url = url;
    }

    public String getActionName() {
        return ActionName;
    }

    public void setActionName(String actionName) {
        ActionName = actionName;
    }
}
