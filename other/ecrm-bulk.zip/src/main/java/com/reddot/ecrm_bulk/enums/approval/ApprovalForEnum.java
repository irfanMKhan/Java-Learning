package com.reddot.ecrm_bulk.enums.approval;

public enum ApprovalForEnum {
    CONTRACT("Contract"),
    ADD_NEW_NUMBER("Add New Number"),
    Change_Plan("Change Plan"),
    Suspended_Approval("Suspended Approval"),

    FINANCIAL_ADJUSTMENT("Financial Adjustment"),
    CREDIT_CEILING("Credit Ceiling"),

    Deposit_Approval("Deposit Approval Request"),

    Delay_Payment_Request("Delay Payment Request"),
    FINANCIAL_ADJUSTMENT_Swap_Sim("Financial Adjustment Request");

    private final String key;

    ApprovalForEnum(String key) {
        this.key = key;
    }

    public String getKey() {
        return this.key;
    }
}
