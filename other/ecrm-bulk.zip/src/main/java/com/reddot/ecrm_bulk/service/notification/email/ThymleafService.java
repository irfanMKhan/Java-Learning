package com.reddot.ecrm_bulk.service.notification.email;

import java.util.Map;

public interface ThymleafService {
    String  createContent(String template, Map<String,Object> model);
}
