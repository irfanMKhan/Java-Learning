package com.reddot.ecrm_bulk.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
public class StatementNoteModel {
    String smartLogoFileName = "axiata_logo.png";
    String signatureImgName = "signature.png";

    String to;
    String address;
    String ref;
    String attn;
    String date;
    String sn;

    List<StatementNoteTableDetails> table_details = new ArrayList<>();

    double total;
    String amount_in_word;
    String bank_account_name;
    String bank_account_no;
    String beneficiary_bank_name;
    String swift;

    String authorized_signer_name;
    String authorized_signer_position;


    public StatementNoteModel(String to,
                              String address,
                              String ref,
                              String attn,
                              String date,
                              String sn,
                              List<StatementNoteTableDetails> table_details,
                              String amount_in_word,
                              String bank_account_name,
                              String bank_account_no,
                              String beneficiary_bank_name,
                              String swift,
                              String authorized_signer_name,
                              String authorized_signer_position) {
        this.to = to;
        this.address = address;
        this.ref = ref;
        this.attn = attn;
        this.date = date;
        this.sn = sn;
        this.table_details = table_details;
        this.total = calculateTotalCost(table_details);
        this.amount_in_word = amount_in_word;
        this.bank_account_name = bank_account_name;
        this.bank_account_no = bank_account_no;
        this.beneficiary_bank_name = beneficiary_bank_name;
        this.swift = swift;
        this.authorized_signer_name = authorized_signer_name;
        this.authorized_signer_position = authorized_signer_position;
    }

    public static double calculateTotalCost(List<StatementNoteTableDetails> table_details) {
        double total = 0;

        for (StatementNoteTableDetails row : table_details) {
            total += row.getTbl_amount();
        }
        return total;
    }
}

