package com.reddot.ecrm_bulk.dto.user;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

@Data
@AllArgsConstructor
public class MDUserModel implements Serializable {
    private Long ID;
    private String NAME;
    private String LOGIN_NAME;
    private String EMAIL;
    private String WALLET_ACCOUNT_NO;
    private String WALLET_ACCOUNT_TYPE;
    private Long USER_GROUP_ID;
    private String USER_GROUP_NAME;
    private String REMARKS;
    private Long CREATED_AT;
    private Long CREATED_BY;
    private String CREATED_BY_USERNAME;
    private Long UPDATED_BY;
    private String UPDATED_BY_USERNAME;
    private Long UPDATED_AT;
    private Integer ACTIVE;
    private Long PRIMARY_RESP_ID;
    private String PRIMARY_RESP_NAME;
    private Long POSITION_ID;
    private String WORK_PHONE;
    private Integer FAILED_ATTEMPT;
    private String TOKEN;
    private Boolean IS_BLOCKED;
    private Timestamp LAST_LOGGED_IN;
    private String USER_PASSWORD;
    private Long DIVISION_ID;
    private Long DISTRICT_ID;
    private Long UPAZILA_PS_ID;
    private Timestamp EXPIRED_DT;

    private Long INSTITUTE_ID;
    private Long ACADEMIC_YEAR_ID;
    private String INSTITUTE_NAME;
    private String ACADEMIC_YEAR_NAME;

    private String USER_TYPE;
    private Integer USER_TYPE_ID;
    private Long TENANT_ID;
    private Long IS_TENANT_ADMIN;

    private Long COMPANY_ID;
    private String COMPANY_NAME;

    public String getUSER_TYPE() {
        return USER_TYPE;
    }

    public void setUSER_TYPE(String USER_TYPE) {
        this.USER_TYPE = USER_TYPE;
    }

    public Integer getUSER_TYPE_ID() {
        return USER_TYPE_ID;
    }

    public void setUSER_TYPE_ID(Integer USER_TYPE_ID) {
        this.USER_TYPE_ID = USER_TYPE_ID;
    }

    public Long getCOMPANY_ID() {
        return COMPANY_ID;
    }

    public void setCOMPANY_ID(Long COMPANY_ID) {
        this.COMPANY_ID = COMPANY_ID;
    }

    public String getCOMPANY_NAME() {
        return COMPANY_NAME;
    }

    public void setCOMPANY_NAME(String COMPANY_NAME) {
        this.COMPANY_NAME = COMPANY_NAME;
    }

    //private List<RoleEntity> roleEntityList;

    public MDUserModel() {
    }



    public String getWALLET_ACCOUNT_NO() {
        return WALLET_ACCOUNT_NO;
    }

    public void setWALLET_ACCOUNT_NO(String WALLET_ACCOUNT_NO) {
        this.WALLET_ACCOUNT_NO = WALLET_ACCOUNT_NO;
    }

    public String getWALLET_ACCOUNT_TYPE() {
        return WALLET_ACCOUNT_TYPE;
    }

    public void setWALLET_ACCOUNT_TYPE(String WALLET_ACCOUNT_TYPE) {
        this.WALLET_ACCOUNT_TYPE = WALLET_ACCOUNT_TYPE;
    }

    public String getINSTITUTE_NAME() {
        return INSTITUTE_NAME;
    }

    public void setINSTITUTE_NAME(String INSTITUTE_NAME) {
        this.INSTITUTE_NAME = INSTITUTE_NAME;
    }

    public String getACADEMIC_YEAR_NAME() {
        return ACADEMIC_YEAR_NAME;
    }

    public void setACADEMIC_YEAR_NAME(String ACADEMIC_YEAR_NAME) {
        this.ACADEMIC_YEAR_NAME = ACADEMIC_YEAR_NAME;
    }

    public Long getACADEMIC_YEAR_ID() {
        return ACADEMIC_YEAR_ID;
    }

    public void setACADEMIC_YEAR_ID(Long ACADEMIC_YEAR_ID) {
        this.ACADEMIC_YEAR_ID = ACADEMIC_YEAR_ID;
    }

    public Long getINSTITUTE_ID() {
        return INSTITUTE_ID;
    }

    public void setINSTITUTE_ID(Long INSTITUTE_ID) {
        this.INSTITUTE_ID = INSTITUTE_ID;
    }

    public Timestamp getEXPIRED_DT() {
        return EXPIRED_DT;
    }

    public void setEXPIRED_DT(Timestamp EXPIRED_DT) {
        this.EXPIRED_DT = EXPIRED_DT;
    }

    public Integer getFAILED_ATTEMPT() {
        return FAILED_ATTEMPT;
    }

    public void setFAILED_ATTEMPT(Integer FAILED_ATTEMPT) {
        this.FAILED_ATTEMPT = FAILED_ATTEMPT;
    }

    public String getTOKEN() {
        return TOKEN;
    }

    public void setTOKEN(String TOKEN) {
        this.TOKEN = TOKEN;
    }

    public Boolean getIS_BLOCKED() {
        return IS_BLOCKED;
    }

    public void setIS_BLOCKED(Boolean IS_BLOCKED) {
        this.IS_BLOCKED = IS_BLOCKED;
    }

    public Timestamp getLAST_LOGGED_IN() {
        return LAST_LOGGED_IN;
    }

    public void setLAST_LOGGED_IN(Timestamp LAST_LOGGED_IN) {
        this.LAST_LOGGED_IN = LAST_LOGGED_IN;
    }

    public String getUSER_PASSWORD() {
        return USER_PASSWORD;
    }

    public void setUSER_PASSWORD(String USER_PASSWORD) {
        this.USER_PASSWORD = USER_PASSWORD;
    }

    public Long getDIVISION_ID() {
        return DIVISION_ID;
    }

    public void setDIVISION_ID(Long DIVISION_ID) {
        this.DIVISION_ID = DIVISION_ID;
    }

    public Long getDISTRICT_ID() {
        return DISTRICT_ID;
    }

    public void setDISTRICT_ID(Long DISTRICT_ID) {
        this.DISTRICT_ID = DISTRICT_ID;
    }

    public Long getUPAZILA_PS_ID() {
        return UPAZILA_PS_ID;
    }

    //

    public void setUPAZILA_PS_ID(Long UPAZILA_PS_ID) {
        this.UPAZILA_PS_ID = UPAZILA_PS_ID;
    }

    public Long getPOSITION_ID() {
        return POSITION_ID;
    }

    public void setPOSITION_ID(Long POSITION_ID) {
        this.POSITION_ID = POSITION_ID;
    }

    public String getWORK_PHONE() {
        return WORK_PHONE;
    }
//    private String CREATED_AT_ST;
//    private String UPDATED_AT_ST;
//
//    public String getCREATED_AT_ST() {
//        return Utility.convertTimestampToDateTime(this.CREATED_AT,"yyyy-MM-dd HH:mm:ss");
//    }
//
//    public void setCREATED_AT_ST(String CREATED_AT_ST) {
//        this.CREATED_AT_ST = CREATED_AT_ST;
//    }
//
//    public String getUPDATED_AT_ST() {
//        return Utility.convertTimestampToDateTime(this.UPDATED_AT,"yyyy-MM-dd HH:mm:ss");
//    }
//
//    public void setUPDATED_AT_ST(String UPDATED_AT_ST) {
//        this.UPDATED_AT_ST = UPDATED_AT_ST;
//    }

    public void setWORK_PHONE(String WORK_PHONE) {
        this.WORK_PHONE = WORK_PHONE;
    }

    public Long getID() {
        return ID;
    }

    public void setID(Long ID) {
        this.ID = ID;
    }

    public String getNAME() {
        return NAME;
    }

    public void setNAME(String NAME) {
        this.NAME = NAME;
    }

    public String getREMARKS() {
        return REMARKS;
    }

    public void setREMARKS(String REMARKS) {
        this.REMARKS = REMARKS;
    }

    public Long getCREATED_AT() {
        return CREATED_AT;
    }

    public void setCREATED_AT(Long CREATED_AT) {
        this.CREATED_AT = CREATED_AT;
    }

    public Long getCREATED_BY() {
        return CREATED_BY;
    }

    public void setCREATED_BY(Long CREATED_BY) {
        this.CREATED_BY = CREATED_BY;
    }

    public String getCREATED_BY_USERNAME() {
        return CREATED_BY_USERNAME;
    }

    public void setCREATED_BY_USERNAME(String CREATED_BY_USERNAME) {
        this.CREATED_BY_USERNAME = CREATED_BY_USERNAME;
    }

    public Long getUPDATED_BY() {
        return UPDATED_BY;
    }

    public void setUPDATED_BY(Long UPDATED_BY) {
        this.UPDATED_BY = UPDATED_BY;
    }

    public String getUPDATED_BY_USERNAME() {
        return UPDATED_BY_USERNAME;
    }

    public void setUPDATED_BY_USERNAME(String UPDATED_BY_USERNAME) {
        this.UPDATED_BY_USERNAME = UPDATED_BY_USERNAME;
    }

    public Long getUPDATED_AT() {
        return UPDATED_AT;
    }

    public void setUPDATED_AT(Long UPDATED_AT) {
        this.UPDATED_AT = UPDATED_AT;
    }

    public Integer getACTIVE() {
        return ACTIVE;
    }

    public void setACTIVE(Integer ACTIVE) {
        this.ACTIVE = ACTIVE;
    }

    public String getLOGIN_NAME() {
        return LOGIN_NAME;
    }

    public void setLOGIN_NAME(String LOGIN_NAME) {
        this.LOGIN_NAME = LOGIN_NAME;
    }

    public String getEMAIL() {
        return EMAIL;
    }

    public void setEMAIL(String EMAIL) {
        this.EMAIL = EMAIL;
    }

    public Long getUSER_GROUP_ID() {
        return USER_GROUP_ID;
    }

    public void setUSER_GROUP_ID(Long USER_GROUP_ID) {
        this.USER_GROUP_ID = USER_GROUP_ID;
    }

    public String getUSER_GROUP_NAME() {
        return USER_GROUP_NAME;
    }

    public void setUSER_GROUP_NAME(String USER_GROUP_NAME) {
        this.USER_GROUP_NAME = USER_GROUP_NAME;
    }

    public Long getPRIMARY_RESP_ID() {
        return PRIMARY_RESP_ID;
    }

    public void setPRIMARY_RESP_ID(Long PRIMARY_RESP_ID) {
        this.PRIMARY_RESP_ID = PRIMARY_RESP_ID;
    }

    public String getPRIMARY_RESP_NAME() {
        return PRIMARY_RESP_NAME;
    }

    public void setPRIMARY_RESP_NAME(String PRIMARY_RESP_NAME) {
        this.PRIMARY_RESP_NAME = PRIMARY_RESP_NAME;
    }

    private String REQUESTED_SESSION_ID;

    public String getREQUESTED_SESSION_ID() {
        return REQUESTED_SESSION_ID;
    }

    public void setREQUESTED_SESSION_ID(String REQUESTED_SESSION_ID) {
        this.REQUESTED_SESSION_ID = REQUESTED_SESSION_ID;
    }

    //private List<MenuModelItemRedis> PERMITTED_MENUS;

    /*public List<MenuModelItemRedis> getPERMITTED_MENUS() {
        return PERMITTED_MENUS;
    }

    public void setPERMITTED_MENUS(List<MenuModelItemRedis> PERMITTED_MENUS) {
        this.PERMITTED_MENUS = PERMITTED_MENUS;
    }

    private List<UserInstituteModel> PERMITTED_INSTITUTES;

    public List<UserInstituteModel> getPERMITTED_INSTITUTES() {
        return PERMITTED_INSTITUTES;
    }

    public void setPERMITTED_INSTITUTES(List<UserInstituteModel> PERMITTED_INSTITUTES) {
        this.PERMITTED_INSTITUTES = PERMITTED_INSTITUTES;
    }*/
}