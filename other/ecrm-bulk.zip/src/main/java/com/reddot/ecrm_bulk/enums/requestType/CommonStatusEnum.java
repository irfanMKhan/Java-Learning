package com.reddot.ecrm_bulk.enums.requestType;

public enum CommonStatusEnum {
    Active,
    Open,
    Submitted,
    Approved,
    Rejected,
    Pending,
    TODO,
    Done,
    Complete,
    Paid,
    Unpaid,
    None,
    Success,
    Failed,
    AutoReservedFailed,
    InProgress
}
