package com.reddot.ecrm_bulk.enums.role;

public enum UserRole {
    ES_MANAGER("ES Manager"),
    RETAIL("Retail"),
    NEW_ROLE_FROM_UI("New role from UI"),
    BO("BO"),
    LOGISTIC("Logistic"),
    ADMIN("Admin"),
    CREDIT_CONTROL_MANAGER("Credit Control Manager"),
    HEAD_OF_ES("Head of ES"),
    CEO("CEO"),
    RESPONSIBILITY("Responsibility"),
    PIC("PIC"), KAM("KAM");


    private final String description;

    UserRole(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}

