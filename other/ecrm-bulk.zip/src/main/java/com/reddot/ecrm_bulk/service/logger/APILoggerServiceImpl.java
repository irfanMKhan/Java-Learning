package com.reddot.ecrm_bulk.service.logger;

import com.google.gson.Gson;
import com.reddot.ecrm_bulk.entity.apilogger.APILogger;
import com.reddot.ecrm_bulk.enums.requestType.CommonStatusEnum;
import com.reddot.ecrm_bulk.enums.requestType.RequestTypeEnum;
import com.reddot.ecrm_bulk.repository.apiLoggerRepo.APILoggerRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.sql.Timestamp;

@Service
@Slf4j
@RequiredArgsConstructor
public class APILoggerServiceImpl implements APILoggerService {
    private final APILoggerRepository apiLoggerRepository;
    private final Gson gson;

    @Override
    public void log(String featureName, Integer featureId, String uniqueTransaction,
                           Integer stepNumber, String stepDescription, String request,
                           String response, String requestParameter,
                           Timestamp requestTime, Timestamp responseTime, Long elapsedTime,
                           Long primaryId, String tableName, String remoteAddress,
                           Integer responseStatus, String status) {
        try {
            APILogger apiLogger = new APILogger();
            apiLogger.setFeatureName(featureName);
            apiLogger.setFeatureId(Long.valueOf(featureId));
            apiLogger.setTransaction(uniqueTransaction);
            apiLogger.setStepNumber(stepNumber);
            apiLogger.setRequestBody(request);
            apiLogger.setResponse(response);
            apiLogger.setRequestTime(requestTime);
            apiLogger.setResponseTime(responseTime);
            apiLogger.setStatus(status);
            apiLogger.setStepDescription(stepDescription);
            apiLogger.setElapsedTime(elapsedTime);
            apiLogger.setPrimaryTableId(primaryId);
            apiLogger.setPrimaryTableName(tableName);
            apiLogger.setRemoteAddress(remoteAddress);
            apiLogger.setResponseStatus(responseStatus);
            apiLogger.setRequestParameters(requestParameter);

            apiLoggerRepository.saveAndFlush(apiLogger);
        } catch (Exception e) {
            log.debug("APILogger Service Error: {}", e.getMessage(), e.getCause());
        }
    }

    @Override
    public void store(RequestTypeEnum requestTypeEnum, String txnId, Integer stepNum, String stepDec, String request, String response, String errorResponse, long startTime, long elapsed, CommonStatusEnum status) {
        log(
                requestTypeEnum.getKey(),
                requestTypeEnum.getValue(),
                txnId,
                stepNum,
                stepDec,
                request,
                ObjectUtils.isEmpty(response) ? errorResponse : response,
                null,
                new Timestamp(startTime),
                new Timestamp(System.currentTimeMillis()),
                elapsed,
                null,
                null,
                null,
                status == CommonStatusEnum.Success ? 1 : 0,
                status.name()
        );
    }
}
