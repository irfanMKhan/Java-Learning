package com.reddot.ecrm_bulk.config.fileExport;

import com.opencsv.CSVWriter;
import org.slf4j.Logger;

import java.io.File;
import java.io.FileWriter;
import java.util.List;
import java.util.Map;

public class GenerateCSV {


    public static boolean writeApacheCSVtoResponse( List<Map<String, Object>> data, Logger logger, String[] headers, String[] columnTitles,String filename) {
        if (data == null || data.size() == 0) {
            return false;
        }
        int index = 0;
        try {
            File file = new File(filename);
            CSVWriter csvWriter = new CSVWriter(new FileWriter(file),
                    CSVWriter.DEFAULT_SEPARATOR,
                    CSVWriter.DEFAULT_QUOTE_CHARACTER,
                    CSVWriter.DEFAULT_ESCAPE_CHARACTER,
                    CSVWriter.DEFAULT_LINE_END);
            csvWriter.writeNext(columnTitles);

            for (int i = 0; i < data.size(); i++) {
                String[] items = new String[headers.length];
                index = 0;
                for (String key : headers) {
                    if (key.equalsIgnoreCase("SR_NUM") || key.equalsIgnoreCase("MSISDN") || key.equalsIgnoreCase("PAR_SR_NUM") || key.equalsIgnoreCase("REFERENCE_COMPLAINT")) {
                        if (data.get(i).get(key) == null)
                            items[index++] = "";
                        else
                            items[index++] = "=\"" + data.get(i).get(key).toString() + "\"";
                    } else {
                        if (data.get(i).get(key) == null)
                            items[index++] = "";
                        else
                            items[index++] = data.get(i).get(key).toString();
                    }
                }
                csvWriter.writeNext(items);
            }
            System.out.println("writeCSVtoResponse successful");
            csvWriter.flush();
            csvWriter.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
return false;
    }


}
