package com.reddot.ecrm_bulk.api.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class QueryPurchasedSupplementaryOfferingResponse implements Serializable {
  private QueryPurchasedSupplementaryOfferingRspMsg QueryPurchasedSupplementaryOfferingRspMsg;
  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  public static class QueryPurchasedSupplementaryOfferingRspMsg implements Serializable {
    private RspHeader RspHeader;

    private List<? extends SupplementaryOffering> SupplementaryOffering;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class RspHeader implements Serializable {
      private Long RspTime;

      private String ReturnCode;

      private String ReturnMsg;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class SupplementaryOffering implements Serializable {
      private String Status;

      private Long StatusDate;

      private Long ExpireDate;

      private String OfferingName;

      private OfferingId OfferingId;

      private Long EffectiveDate;

      @Data
      @AllArgsConstructor
      @NoArgsConstructor
      public static class OfferingId implements Serializable {
        private Long PurchaseSeq;

        private Integer OfferingId;
      }
    }
  }
}
