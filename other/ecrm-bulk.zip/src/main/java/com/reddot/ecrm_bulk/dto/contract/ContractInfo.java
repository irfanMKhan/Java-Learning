package com.reddot.ecrm_bulk.dto.contract;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
public class ContractInfo {
    private Long companyId;
    private String parentAccountAccountCode;
    private Long parentCustomerAccountId;
    private Long mainCorAccountAccountId;
    private Long mainCorSubscriberAccountId;
    private Long branchAccountAccountId;
    private Long branchSubscriberAccountId;
    private Long cugId;
    private Long cugAccountId;

    private String custId;
    private String cugGroupCode;

    private String branchGRPId;
    private String branchGRPCode;
    private String branchGRPName;

    private String Main_Grp_ID;
    private String Main_Grp_Code;
    private String Main_Grp_Name;

    private LogRelatedInfo logRelatedInfo;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class LogRelatedInfo {
        private Integer lastStepNumber;
        private String transactionNumber;
    }

}
