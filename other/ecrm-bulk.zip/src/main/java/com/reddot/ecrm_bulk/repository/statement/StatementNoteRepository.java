package com.reddot.ecrm_bulk.repository.statement;

import com.reddot.ecrm_bulk.entity.statement_note.StatementNoteEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StatementNoteRepository extends JpaRepository<StatementNoteEntity,Long> {
    Optional<List<StatementNoteEntity>> findAllByStatusAndIsIndividual(String status, Boolean isIndividual);
    List<StatementNoteEntity> findAllByTransactionId(String transactionId);
    List<StatementNoteEntity> findAllByIndivisualTransactionId(String indivisualTransactionId);


}
