package com.reddot.ecrm_bulk.enums.requestType;

import lombok.Getter;

@Getter
public enum PrimaryTableNameEnum {
    Contract("tbl_ecrm_contract"),
    SWAP_SIM("tbl_swap_sim");


    private final String key;


    PrimaryTableNameEnum(String key) {
        this.key = key;
    }

}
