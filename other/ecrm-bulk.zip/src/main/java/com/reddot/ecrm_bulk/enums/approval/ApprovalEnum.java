package com.reddot.ecrm_bulk.enums.approval;

import lombok.Getter;

@Getter
public enum ApprovalEnum {

    SPECIAL_NUMBER("Special Numbers"),
    CREDIT_CEILING("Credit Ceiling"),
    SPECIAL_OFFER("Special Offer"),
    FINANCIAL_ADJUSTMENT("Financial Adjustment Request"),
    PTP_REQUEST("PTP Request"),
    DEVICE_REQUEST("Device Request"),
    Suspended_Approval("Suspended Approval Request"),

    Deposit_Approval("Deposit Approval Request"),
    //    Delay_Payment_Request ("Delay Payment Request"),
    Change_Plan_Total_Number("Change Plan Notification (Total Number)"),
    Change_Plan_Percentage("Change Plan Notification (Percentage)");


    private final String key;


    ApprovalEnum(String key) {
        this.key = key;
    }

    public String getKey() {
        return this.key;
    }

}