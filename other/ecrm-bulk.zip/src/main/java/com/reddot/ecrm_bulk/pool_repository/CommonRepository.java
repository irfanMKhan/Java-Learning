package com.reddot.ecrm_bulk.pool_repository;

import com.reddot.ecrm_bulk.config.Utility;
import com.reddot.ecrm_bulk.model.*;
import com.reddot.ecrm_bulk.model.CommonMDModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class CommonRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    
    public Object CommoPagination(String sql) {
        Object Lists = new Object();
        try {
            Lists = jdbcTemplate.queryForList(sql);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        return Lists;
    }

    
    public Object CommoGetData(String sql) {
        Object Lists = new Object();
        logger.info(sql);
        try {
            Lists = jdbcTemplate.queryForList(sql);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        return Lists;
    }

    
    public String CommoGetJsonData(String sql) {
        Object Lists = new Object();
        logger.info(sql);
        try {
            Lists = jdbcTemplate.queryForList(sql);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        return Utility.ObjectToJson(Lists);
    }

    
    public int CommoNumberOfRow(String sql) {
        logger.info(sql);
        int count = 0;
        try {
            count = jdbcTemplate.queryForObject(sql, Integer.class);

        } catch (Exception e) {
            logger.error(e.getMessage());
            System.out.println("Count Error: " + e.getMessage());
        }

        return count;
    }

    
    public boolean CommoInsert(String tbl, Map<String, Object> query, Logger logger) {
        String Query = "";
        String inQryFields = "";
        String inQryVal = "";
        String InsQuery = "";
        String inQryInit = "";
        int list_size = query.size();
        Object[] inputs = new Object[list_size];
        if (query.size() > 0) {
            int i = 0;
            for (Map.Entry<String, Object> entry : query.entrySet()) {
                inQryFields += entry.getKey() + ",";
                inQryVal += "'" + entry.getValue() + "',";
                inQryInit += "?,";
                inputs[i++] = entry.getValue();
            }
            inQryInit = inQryInit.substring(0, inQryInit.trim().length() - 1);
            InsQuery = "INSERT INTO " + tbl + " (" + inQryFields.substring(0, inQryFields.trim().length() - 1) + ") VALUES (" + inQryInit + ")";
        }

        logger.info("Insert Query for " + tbl);
        logger.info(InsQuery);
        //System.out.println(InsQuery);
        logger.info("Insert Query data: ");
        logger.info(Utility.ObjectToJson(inputs));
        //System.out.println(Utility.ObjectToJson(inputs));

        try {
            jdbcTemplate.update(InsQuery, inputs);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }
        return false;
    }

    
    public boolean CommoUpdate(String tbl, Map<String, Object> setQry, Map<String, Object> whereQry, Logger logger) {
        String Query = "";
        String UpQryWhere = "";
        String UpQry = "";
        String UpsQuery = "";
        int i = 0;
        int setQrySize = setQry.size();
        int whereQrySize = whereQry.size();
        int total_size = setQrySize + whereQrySize;
        Object[] inputs = new Object[total_size];

        if (setQry.size() > 0) {
            for (Map.Entry<String, Object> entry : setQry.entrySet()) {
                UpQry += entry.getKey() + " =?,";
                inputs[i++] = entry.getValue();
            }
            UpQry = UpQry.substring(0, UpQry.trim().length() - 1);
        }

        if (whereQry.size() > 0) {
            for (Map.Entry<String, Object> entrys : whereQry.entrySet()) {
                UpQryWhere += entrys.getKey() + " =? AND ";
                inputs[i++] = entrys.getValue();
            }
            UpQryWhere = " WHERE " + UpQryWhere.substring(0, UpQryWhere.trim().length() - 4);
        }

        Query = "UPDATE " + tbl + " SET " + UpQry + UpQryWhere;
        logger.info("Update Query: " + Query);
        logger.info("Update Query data: "+Utility.ObjectToJson(inputs));

        try {
            jdbcTemplate.update(Query, inputs);
            return true;
        } catch (Exception e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    
    public boolean CommoUpdate(String qry, Logger logger) {
        try {
            jdbcTemplate.update(qry);
            return true;
        } catch (Exception e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    
    public boolean CommoInsertSQL(String qry, Logger logger) {
        try {
            jdbcTemplate.update(qry);
            return true;
        } catch (Exception e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    
    public boolean CommoDelete(String tbl, Map<String, Object> whereQry, Logger logger) {
        String Query = "";
        String UpQryWhere = "";
        int i = 0;
        int total_size = whereQry.size();
        Object[] inputs = new Object[total_size];


        if (whereQry.size() > 0) {
            for (Map.Entry<String, Object> entrys : whereQry.entrySet()) {
                UpQryWhere += entrys.getKey() + " =? AND ";
                inputs[i++] = entrys.getValue();
            }
            UpQryWhere = " WHERE " + UpQryWhere.substring(0, UpQryWhere.trim().length() - 4);
        }

        Query = "DELETE FROM " + tbl + " " + UpQryWhere;
        logger.info(Query);
        logger.info("Delete Query for " + tbl);
        logger.info(Query);
        logger.info("Delete Query data: ");
        logger.info(Utility.ObjectToJson(inputs));

        try {
            jdbcTemplate.update(Query, inputs);
            return true;
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return false;
    }

    
    public String getNextId(String sequenceName) {
        String nextId = null;
        try {
            String query = "SELECT  " + sequenceName + ".NEXTVAL FROM   dual";
            nextId = jdbcTemplate.queryForObject(query, String.class);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return nextId;
    }

    
    public String commonInsertGetReturn(String tbl, Map<String, Object> params, Logger logger, String returnColumn) {
        String generatedValue = "";
        String inQryFields = "";
        String inQryInit = "";
        int list_size = params.size();
        Object[] inputs = new Object[list_size];

        try {
            if (params.size() > 0) {
                int i = 0;
                for (Map.Entry<String, Object> entry : params.entrySet()) {
                    inQryFields += entry.getKey() + ",";
                    inQryInit += "?,";
                    inputs[i++] = entry.getValue();
                }
                inQryInit = inQryInit.substring(0, inQryInit.trim().length() - 1);
            } else {
                return "";
            }
            String query = "INSERT INTO " + tbl + " (" + inQryFields.substring(0, inQryFields.trim().length() - 1) + ") VALUES (" + inQryInit + ")";

            logger.info("Insert with return query: " + query);
            logger.info(Utility.ObjectToJson(inputs));

            KeyHolder keyHolder = new GeneratedKeyHolder();

            jdbcTemplate.update(connection -> {
                PreparedStatement ps = connection
                        .prepareStatement(query, new String[]{returnColumn});
                for (int i = 0; i < inputs.length; i++) {
                    ps.setObject(i + 1, inputs[i]);
                }
                return ps;
            }, keyHolder);

            generatedValue = ((BigDecimal) keyHolder.getKeys().get(returnColumn)).toString();
            logger.info("Insert with return column: " + returnColumn + " and value: " + generatedValue);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return generatedValue;
    }

    public boolean commonQuery(String query, Logger logger) {
        try {
            int rows = jdbcTemplate.update(query);
            if (rows>0)
                return true;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return false;
    }

    public boolean BatchInsertSQL(List<Object[]> Res, String SQL, Logger logger) {
        try {
            jdbcTemplate.batchUpdate(SQL, Res);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return false;
    }

    public CommonMDModel isExists (String table, String name, String nameValue, String addition) {
        try {
            List<CommonMDModel> list = new ArrayList<>();

            String query = " SELECT * FROM " + table + " WHERE " + name + " = " + nameValue + " " + addition;

            list = jdbcTemplate.query(query, new BeanPropertyRowMapper(CommonMDModel.class));
            if (list.size() > 0) {
                return list.get(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return null;
    }




}
