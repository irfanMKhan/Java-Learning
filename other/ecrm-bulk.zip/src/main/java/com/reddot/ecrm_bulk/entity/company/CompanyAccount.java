package com.reddot.ecrm_bulk.entity.company;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "company_account")
public class CompanyAccount {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long companyId;
    private String companyName;
    private String accountCode;
    private String accountId;
    private Long parentAccountId;
    private Boolean active;
    private String status;
    private String accountName;
    private String customerAccountType;
    private Long parentCustomerId;

    private Long parentSubscriberId;
    private String serviceTypeName;
    private Long serviceTypeId;
    //  private Long contractId;
    private String contractNumber;
    private String opportunityNumber;
    private Boolean isParent;
    private Boolean isParentCorporateAccount;
    private Boolean isParentSubscriberAccount;
    private String transactionNumber;
    private String branchName;
    private Boolean isBranchCorporateAccount;
    private Boolean isBranchSubscriber;
//    @Column(columnDefinition = "text")
//    private String requestDetails;
//    @Column(columnDefinition = "text")
//    private String responseDetails;

    private Long deposit;

    @Column(name = "created_at")
    private Long createdAt;

    @Column(name = "created_at_dt")
    private Timestamp createdAtDt;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_by_username")
    private String createdUsername;

    @Column(name = "updated_at")
    private Long updatedAt;

    @Column(name = "updated_at_dt")
    private Timestamp updatedAtDt;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_by_username")
    private String updatedUsername;
}
