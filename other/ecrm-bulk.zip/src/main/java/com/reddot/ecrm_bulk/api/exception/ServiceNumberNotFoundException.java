package com.reddot.ecrm_bulk.api.exception;

public class ServiceNumberNotFoundException extends RuntimeException {
    public ServiceNumberNotFoundException(String message) {
        super(message);
    }

    public ServiceNumberNotFoundException(String message, Throwable throwable) {
        super(message, throwable);
    }
}
