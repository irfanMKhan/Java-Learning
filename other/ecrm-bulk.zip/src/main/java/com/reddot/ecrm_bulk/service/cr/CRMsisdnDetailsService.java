package com.reddot.ecrm_bulk.service.cr;

import com.reddot.ecrm_bulk.entity.cr.CRMsisdnDetailsEntity;

import java.util.List;

public interface CRMsisdnDetailsService {
    List<CRMsisdnDetailsEntity> findAllCRMsisdnDetailsByCRMasterId(Long id);

    List<CRMsisdnDetailsEntity> findAllCRMsisdnDetailsByCRMasterIdWithSuccessStatus(Long id);

    CRMsisdnDetailsEntity findById(Long id);

    CRMsisdnDetailsEntity update(CRMsisdnDetailsEntity crMsisdnDetailsEntity);

    void updateMsisdnDetailsRemarksAndFailedStatus(CRMsisdnDetailsEntity crMsisdnDetailsEntity, String remarks);
}
