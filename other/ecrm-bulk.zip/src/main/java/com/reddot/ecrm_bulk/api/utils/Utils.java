package com.reddot.ecrm_bulk.api.utils;

import com.ibm.icu.text.RuleBasedNumberFormat;
import com.ibm.icu.util.CurrencyAmount;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.util.StringUtils;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Currency;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

@Slf4j
public class Utils {
    public static String getTimeInFormatyyyyMMddHHmmss() {
        try {
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
            return now.format(formatter);
        } catch (Exception e) {
            log.error("Utils:getTimeInFormatyyyyMMddHHmmss() Error: {}", e.getMessage());
            return null;
        }
    }

    public static String generateTransactionId() {
        Random rand = new Random();
        int randomNumber = rand.nextInt(1000);
        return "CRM" + Utils.getTimeInFormatyyyyMMddHHmmss() + randomNumber;
    }

    public static String getTransactionIdTimeIn_Date_T_Time_Format() {
        try {
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
            Random rand = new Random();
            int randomNumber = rand.nextInt(1000);

            return now.format(formatter) + randomNumber;
        } catch (Exception e) {
            log.error("Utils:getTransactionTimeInTFormat() Error: {}", e.getMessage());
            return null;
        }
    }

    public static String getTransactionIdTimeIn_Date_T_Time_FormatWithRandom() {
        try {
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
            return now.format(formatter);
        } catch (Exception e) {
            log.error("Utils:getTransactionTimeInTFormat() Error: {}", e.getMessage());
            return null;
        }
    }

    public static String getTransactionId() {
        try {
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
            return now.format(formatter);
        } catch (Exception e) {
            log.error("Utils:getTransactionId() Error: {}", e.getMessage());
            return null;
        }
    }


    public static long getCurrentTimestamp() {
        Date date = new Date();
        return date.getTime();
    }

    public static String urlEncode(String originalString) throws UnsupportedEncodingException {
        return URLEncoder.encode(originalString, StandardCharsets.UTF_8.toString());
    }

    public static JSONArray convertJsonObjectToArray(JSONObject jsonObject) {
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(jsonObject);
        return jsonArray;
    }

    public static Long loggedInCurrentTime() {
        return System.currentTimeMillis();
    }


}
