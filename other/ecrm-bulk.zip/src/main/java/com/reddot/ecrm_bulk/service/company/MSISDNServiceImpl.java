package com.reddot.ecrm_bulk.service.company;

import com.reddot.ecrm_bulk.dto.contract.ContractInfo;
import com.reddot.ecrm_bulk.entity.annex.Annex;
import com.reddot.ecrm_bulk.entity.contract.Contract;
import com.reddot.ecrm_bulk.entity.msisdn.MSISDN;
import com.reddot.ecrm_bulk.repository.company.MSISDNRepository;
import com.reddot.ecrm_bulk.api.utils.Utils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class MSISDNServiceImpl implements MSISDNService {
    private final MSISDNRepository msisdnRepository;


    @Override
    public MSISDN findByMSISDN(String msisdn) {
        try {
            return msisdnRepository.findByMSISDN(msisdn);
        } catch (Exception e) {
            if (!(e instanceof EmptyResultDataAccessException)) {
                log.debug("FindByMSISDN Error for MSISDN: {} and Error: {}", msisdn, e.getMessage(), e.getCause());
            }
            return null;
        }
    }

    @Override
    public List<MSISDN> findAllByMSISDN(String msisdn) {
        try {
            return msisdnRepository.findAllByMSISDN(msisdn);
        } catch (Exception e) {
            log.debug("findAllByMSISDN Error for MSISDN: {} and Error: {}", msisdn, e.getMessage(), e.getCause());
            return null;
        }
    }

    @Override
    public MSISDN save(MSISDN msisdn) {
        try {
           return msisdnRepository.save(msisdn);
        } catch (Exception e) {
            log.debug("Failed to save in database. MSISDN Entity: {}", msisdn);
            log.error("Save msisdn error: {} {}", e.getMessage(), e.getCause());
        }
        return null;
    }

    @Override
    public MSISDN update(MSISDN msisdn) {
        try {
            return msisdnRepository.update(msisdn);
        } catch (Exception e) {
            log.debug("Failed to update in database. MSISDN Entity: {}", msisdn);
            log.error("Save msisdn error: {} {}", e.getMessage(), e.getCause());
        }
        return null;
    }

    @Override
    public void insertMSISDN(Contract contract, Annex annex, ContractInfo contractInfo) {
        try {
             MSISDN msisdn = new MSISDN();
             msisdn.setCreatedAt(Utils.getCurrentTimestamp());
             msisdn.setMsisdn(annex.getMsisdn());
             msisdn.setIccid(annex.getIccid());
             msisdn.setActive(true);
             msisdn.setCompanyName(contract.getCustomerName());
             msisdn.setCompanyId(contract.getCompanyId());
             msisdn.setContractDuration(Integer.valueOf(annex.getContractDuration()));
             msisdn.setTotalCredit(annex.getTotalCredit());
             msisdn.setCreditLimit(annex.getDefaultCredit());
             msisdn.setMonthlyFee(annex.getMonthlyFee());
             msisdn.setMaxMonthlyFee(annex.getMaximumMonthlyFee());
             msisdn.setMaturityDate(LocalDate.parse(annex.getContractMaturityDate()));
             msisdn.setEffectiveDate(LocalDate.parse(annex.getEffectiveDate()));
             msisdn.setMsisdnAccountCode(contractInfo.getParentAccountAccountCode());
             msisdn.setRemainingCredit(annex.getRemainingCredit());
             if (annex.getReserveCredit() == null) {
                 msisdn.setReserveCredit(0.0);
             } else {
                 msisdn.setReserveCredit(annex.getReserveCredit());
             }

             msisdn.setMasterAccountId(contractInfo.getParentCustomerAccountId());
             msisdn.setBranchAccountId(contractInfo.getBranchSubscriberAccountId());
             msisdn.setCugAccountId(contractInfo.getCugAccountId());
             msisdn.setCugId(contractInfo.getCugId());
             msisdn.setPlanName(annex.getPlan());
             msisdn.setPlanId(annex.getPlanId());
             msisdn.setAddOn(annex.getAddOns());
             msisdn.setNgbssPlanOfferingId(annex.getNgbssPlanOfferingId());
             msisdn.setNgbssAddOnsOfferingId(annex.getNgbssAddOnsOfferingId());
             Timestamp dateTime = new Timestamp(Utils.loggedInCurrentTime());
             msisdn.setCreatedAtDt(dateTime);
             msisdn.setCreatedAt(Utils.getCurrentTimestamp());
             msisdn.setIsSuspended(false);
             save(msisdn);
             log.debug("MSISDN Inserted : {}", annex.getMsisdn());
         } catch (Exception e) {
             log.error("Failed to insert msisdn: {}", annex.getMsisdn());
         }
    }
}
