package com.reddot.ecrm_bulk.api.payload.CDR.response;

import lombok.Data;

import java.io.Serializable;

@Data
public class CDRDetailsErrorResponse implements Serializable {

    private String code;

    private String message;

    private String variables;
}