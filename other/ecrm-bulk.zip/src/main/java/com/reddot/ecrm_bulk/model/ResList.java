package com.reddot.ecrm_bulk.model;

import java.util.List;

public class ResList {
    boolean IsSuccess;
    List<ResModel> resModelList;

    public List<ResModel> getResModelList() {
        return resModelList;
    }

    public void setResModelList(List<ResModel> resModelList) {
        this.resModelList = resModelList;
    }

    public boolean isSuccess() {
        return IsSuccess;
    }

    public void setSuccess(boolean success) {
        IsSuccess = success;
    }
}
