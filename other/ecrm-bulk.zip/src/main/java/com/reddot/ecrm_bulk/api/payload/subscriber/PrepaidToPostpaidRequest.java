package com.reddot.ecrm_bulk.api.payload.subscriber;

import lombok.Data;

import java.io.Serializable;
import java.lang.String;

@Data
public class PrepaidToPostpaidRequest implements Serializable {

  private ChangePrepaidToPostpaidReq ChangePrepaidToPostpaidReq;

  @Data
  public static class ChangePrepaidToPostpaidReq implements Serializable {
    private PostpaidCust PostpaidCust;

    private PostpaidAcct PostpaidAcct;

    private Offering Offering;

    @Data
    public static class PostpaidCust implements Serializable {
      private String CustId;

      private String Birthday;

      private String Nationality;

      private Name Name;

      @Data
      public static class Name implements Serializable {
        private String FirstName;

        private String LastName;

        private String MiddleName;
      }
    }

    @Data
    public static class PostpaidAcct implements Serializable {
      private Account Account;

      @Data
      public static class Account implements Serializable {
        private String AcctName;

        private Address Address;

        private String CustId;

        private String BillCycleType;

        private String Currency;

        private CreditLimit CreditLimit;

        private BillMedium BillMedium;

        private String PaymentType;

        private String Title;

        private String BillLanguage;

        private PostpaidCust.Name Name;

        private Contact Contact;

        @Data
        public static class Address implements Serializable {
          private String Address7;

          private String Address11;

          private String Address5;

          private String Address2;

          private String Address3;

          private String Address1;

          private String AddressType;
        }

        @Data
        public static class CreditLimit implements Serializable {
          private String LimitType;

          private String LimitValue;
        }

        @Data
        public static class BillMedium implements Serializable {
          private String BillMediumId;

          private String BillMediumCode;

          private String BillContentType;

          private String BillMediumInfo;
        }

        @Data
        public static class Contact implements Serializable {
          private String ContactType;

          private String Email;

          private String Priority;

          private String Title;

          private String MobilePhone;

          private PostpaidCust.Name Name;
        }
      }
    }

    @Data
    public static class Offering implements Serializable {
      private NewPrimaryOffering NewPrimaryOffering;

      @Data
      public static class NewPrimaryOffering implements Serializable {
        private EffectiveMode EffectiveMode;

        private OfferingId OfferingId;

        @Data
        public static class EffectiveMode implements Serializable {
          private String Mode;
        }

        @Data
        public static class OfferingId implements Serializable {
          private String OfferingId;
        }
      }
    }
  }
  private String transaction_id;
}
