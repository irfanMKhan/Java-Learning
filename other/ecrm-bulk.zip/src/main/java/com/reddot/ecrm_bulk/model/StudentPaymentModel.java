package com.reddot.ecrm_bulk.model;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class StudentPaymentModel {
    private Long ID;
    private String CODE;
    private String WALLET;
    private String REGISTRATION_ID;
    private Double AMOUNT;
    private String STATUS;
    private String TXN_NO;
    @Temporal(TemporalType.TIMESTAMP)
    private Timestamp TXN_DATE;
    private Integer ACTIVE;
    private Integer IS_PROCESSED;
    @Temporal(TemporalType.DATE)
    private Date UPDATED_AT_DT;

    public Long getID() {
        return ID;
    }

    public void setID(Long ID) {
        this.ID = ID;
    }

    public String getCODE() {
        return CODE;
    }

    public void setCODE(String CODE) {
        this.CODE = CODE;
    }

    public String getWALLET() {
        return WALLET;
    }

    public void setWALLET(String WALLET) {
        this.WALLET = WALLET;
    }

    public String getREGISTRATION_ID() {
        return REGISTRATION_ID;
    }

    public void setREGISTRATION_ID(String REGISTRATION_ID) {
        this.REGISTRATION_ID = REGISTRATION_ID;
    }

    public Double getAMOUNT() {
        return AMOUNT;
    }

    public void setAMOUNT(Double AMOUNT) {
        this.AMOUNT = AMOUNT;
    }

    public String getSTATUS() {
        return STATUS;
    }

    public void setSTATUS(String STATUS) {
        this.STATUS = STATUS;
    }

    public String getTXN_NO() {
        return TXN_NO;
    }

    public void setTXN_NO(String TXN_NO) {
        this.TXN_NO = TXN_NO;
    }

    public Timestamp getTXN_DATE() {
        return TXN_DATE;
    }

    public void setTXN_DATE(Timestamp TXN_DATE) {
        this.TXN_DATE = TXN_DATE;
    }

    public Integer getACTIVE() {
        return ACTIVE;
    }

    public void setACTIVE(Integer ACTIVE) {
        this.ACTIVE = ACTIVE;
    }

    public Integer getIS_PROCESSED() {
        return IS_PROCESSED;
    }

    public void setIS_PROCESSED(Integer IS_PROCESSED) {
        this.IS_PROCESSED = IS_PROCESSED;
    }

    public Date getUPDATED_AT_DT() {
        return UPDATED_AT_DT;
    }

    public void setUPDATED_AT_DT(Date UPDATED_AT_DT) {
        this.UPDATED_AT_DT = UPDATED_AT_DT;
    }
}
