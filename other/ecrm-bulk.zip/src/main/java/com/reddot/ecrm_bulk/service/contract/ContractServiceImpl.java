package com.reddot.ecrm_bulk.service.contract;

import com.google.gson.Gson;
import com.reddot.ecrm_bulk.api.exception.*;
import com.reddot.ecrm_bulk.api.gateway.ContractGateway;
import com.reddot.ecrm_bulk.api.payload.ChangeSupplementaryOfferingRequest;
import com.reddot.ecrm_bulk.api.payload.ChangeSupplementaryOfferingResponse;
import com.reddot.ecrm_bulk.api.payload.QueryDebitNoteResponse;
import com.reddot.ecrm_bulk.api.payload.QueryPurchasedSupplementaryOfferingResponse;
import com.reddot.ecrm_bulk.api.payload.change_account_information.ChangeAccountInformationCommonResponse;
import com.reddot.ecrm_bulk.api.payload.change_account_information.ChangeAccountInformationRequest;
import com.reddot.ecrm_bulk.api.payload.customer.CBSBCCustomerResponse;
import com.reddot.ecrm_bulk.api.payload.group.*;
import com.reddot.ecrm_bulk.api.payload.order.CreateOrderRequest;
import com.reddot.ecrm_bulk.api.payload.order.CreateOrderResponse;
import com.reddot.ecrm_bulk.api.payload.subscriber.*;
import com.reddot.ecrm_bulk.api.utils.Utils;
import com.reddot.ecrm_bulk.entity.account_details.Address;
import com.reddot.ecrm_bulk.entity.annex.Annex;
import com.reddot.ecrm_bulk.entity.contract.Contact;
import com.reddot.ecrm_bulk.entity.contract.Contract;
import com.reddot.ecrm_bulk.entity.primary_offering.PrimaryOffering;
import com.reddot.ecrm_bulk.enums.requestType.PrimaryTableNameEnum;
import com.reddot.ecrm_bulk.enums.requestType.RequestTypeEnum;
import com.reddot.ecrm_bulk.enums.service.ServiceType;
import com.reddot.ecrm_bulk.repository.contract.ContractRepository;
import com.reddot.ecrm_bulk.service.logger.APILoggerService;
import com.reddot.ecrm_bulk.service.offering.MandatoryOfferingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class ContractServiceImpl implements ContractService {
    @Value("${smart.api.channel}")
    private String channel;
    @Value("${smart.api.partnerId}")
    private String partnerId;
    @Value("${smart.api.version}")
    private String version;
    @Value("${smart.access.user}")
    private String accessUser;
    @Value("${smart.access.password}")
    private String accessPassword;
    @Value("${smart.supplementary.offering.expiration}")
    private String supplementaryOfferingExpiration;
    private final ContractGateway contractGateway;
    private final ContractRepository contractRepository;
    private final AnnexService annexService;
    private final Gson gson;
    private final MandatoryOfferingService mandatoryOfferingService;

    @Override
    public List<Contract> findAll() {
        return contractRepository.findAll();
    }

    @Override
    public Boolean isDebitNoteClosed(String extTransId) {
        try {
            List<QueryDebitNoteResponse> debitNoteResponse = contractGateway.queryDebitNote(extTransId);
            log.debug("Query Debit Note Response: {} for ExtTransId: {}", gson.toJson(debitNoteResponse), extTransId);
            return debitNoteResponse.size() > 0 && debitNoteResponse.get(0).getInvoice_status().equalsIgnoreCase("C");
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("QueryDebitNote Api Request Service Error for ExtId: {} Message: {}", extTransId, e.getMessage());
                throw new ApiRequestException(e.getMessage());
            }
            log.error("QueryDebitNote Service Error for ExtId: {} {}", extTransId, e.getMessage(), e.getCause());
            return false;
        }
    }
    @Override
    public CBSBCCustomerResponse cbsbcCustomer(String msisdn) {
        try {
            CBSBCCustomerResponse response = contractGateway.cbsbcCustomer(msisdn, accessUser, accessPassword);
            log.debug("CBS-BC-Customer Cust Key: {} for MSISDN: {}", response.getQueryCustomerInfoResult().getCustomer().getCustKey(), msisdn);
            return response;
        } catch (Exception e) {
            if (e instanceof SubscriberNotFoundException) {
                throw new SubscriberNotFoundException(e.getMessage());
            } else {
                throw new ApiRequestException(e.getMessage());
            }
        }
    }
    @Override
    public Boolean prepaidToPostpaid(String custId, String birthDay, Contract contract, Annex annex, List<Contact> contactList, Address address) {
       try {
           PrepaidToPostpaidRequest prepaidToPostpaidRequest = new PrepaidToPostpaidRequest();
           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq changePrepaidToPostpaidReq = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq();

           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidCust postpaidCust = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidCust();
           postpaidCust.setCustId(custId);

           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidCust.Name postPaidCustName = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidCust.Name();
           postPaidCustName.setFirstName(contract.getCustomerName());
           postPaidCustName.setMiddleName("");
           postPaidCustName.setLastName(contract.getCustomerName());
           postpaidCust.setName(postPaidCustName);

           postpaidCust.setBirthday(birthDay);
           postpaidCust.setNationality("1116");

           changePrepaidToPostpaidReq.setPostpaidCust(postpaidCust);

           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct postpaidAcct = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct();

           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct.Account postPaidAccount = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct.Account();
           postPaidAccount.setCustId("");
           postPaidAccount.setAcctName(contract.getCustomerName());
           postPaidAccount.setPaymentType("1");
           postPaidAccount.setTitle("0");

           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidCust.Name postPaidAcctName = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidCust.Name();
           postPaidAcctName.setFirstName(contract.getCustomerName());
           postPaidAcctName.setMiddleName("");
           postPaidAcctName.setLastName(contract.getCustomerName());
           postPaidAccount.setName(postPaidAcctName);

           postPaidAccount.setCustId(custId);
           postPaidAccount.setBillCycleType("01");
           postPaidAccount.setBillLanguage("2002");

           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct.Account.Contact contact = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct.Account.Contact();
           contact.setPriority("1");
           contact.setContactType("1");
           contact.setTitle("0");

           String[] name = contactList.get(0).getName().split(" ");
           String firstName = name[0];
           String lastName = name.length > 1 ? name[1] : "";

           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidCust.Name contactName = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidCust.Name();
           contactName.setFirstName(firstName);
           contactName.setMiddleName("");
           contactName.setLastName(lastName);

           contact.setName(contactName);
           contact.setMobilePhone(contactList.get(0).getMobile());
           contact.setEmail(contactList.get(0).getEmail());
           postPaidAccount.setContact(contact);

           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct.Account.Address postPaidAcctAddress = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct.Account.Address();
           postPaidAcctAddress.setAddressType("4");
           postPaidAcctAddress.setAddress1("1116");

           if (!ObjectUtils.isEmpty(address.getCityProvinceApiValue())) {
               postPaidAcctAddress.setAddress2(address.getCityProvinceApiValue());
           }
           if (!ObjectUtils.isEmpty(address.getKhanDistrictApiValue())) {
               postPaidAcctAddress.setAddress3(address.getKhanDistrictApiValue());
           }
           if (!ObjectUtils.isEmpty(address.getStreet())) {
               postPaidAcctAddress.setAddress5(address.getStreet());
           }
           if (!ObjectUtils.isEmpty(address.getHouseNumber())) {
               postPaidAcctAddress.setAddress7(address.getHouseNumber());
           }
           if (!ObjectUtils.isEmpty(address.getSangkatCommuneApiValue())) {
               postPaidAcctAddress.setAddress11(address.getSangkatCommuneApiValue());
           }
           postPaidAccount.setAddress(postPaidAcctAddress);

           if (!ObjectUtils.isEmpty(annex.getServiceTypeName()) &&
                   !annex.getServiceTypeName().equalsIgnoreCase(ServiceType.Hybrid.name())) {
               PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct.Account.BillMedium billMedium = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct.Account.BillMedium();

               billMedium.setBillMediumId("1084702653");
               billMedium.setBillMediumCode("5");  //E-BILL
               billMedium.setBillContentType("1"); //Summary

               postPaidAccount.setBillMedium(billMedium);
           }

           postPaidAccount.setCurrency("1153");

           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct.Account.CreditLimit creditLimit = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct.Account.CreditLimit();
           creditLimit.setLimitType("All");
           creditLimit.setLimitValue("0");
           postPaidAccount.setCreditLimit(creditLimit);

           postpaidAcct.setAccount(postPaidAccount);

           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.Offering offering = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.Offering();
           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.Offering.NewPrimaryOffering newPrimaryOffering = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.Offering.NewPrimaryOffering();
           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.Offering.NewPrimaryOffering.OfferingId offeringId = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.Offering.NewPrimaryOffering.OfferingId();
           offeringId.setOfferingId(annex.getNgbssPlanOfferingId());
           newPrimaryOffering.setOfferingId(offeringId);

           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.Offering.NewPrimaryOffering.EffectiveMode effectiveMode = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.Offering.NewPrimaryOffering.EffectiveMode();
           effectiveMode.setMode("0");
           newPrimaryOffering.setEffectiveMode(effectiveMode);
           offering.setNewPrimaryOffering(newPrimaryOffering);

           changePrepaidToPostpaidReq.setPostpaidAcct(postpaidAcct);
           changePrepaidToPostpaidReq.setOffering(offering);
           prepaidToPostpaidRequest.setTransaction_id(Utils.getTransactionIdTimeIn_Date_T_Time_Format());

           prepaidToPostpaidRequest.setChangePrepaidToPostpaidReq(changePrepaidToPostpaidReq);

           if (! isSubscriberExists(annex.getMsisdn())) {
               return false;
           }

           log.debug("Pre2Post Request: {} for MSISDN: {}", gson.toJson(prepaidToPostpaidRequest), annex.getMsisdn());
           PrepaidToPostpaidResponse response = contractGateway.prepaidToPostpaid(annex.getMsisdn(), prepaidToPostpaidRequest);
           log.debug("Pr2Post Response: {} for MSISDN: {}", response, annex.getMsisdn());

           return !ObjectUtils.isEmpty(response) && response.getTransaction_status().equals("SUCCESS");
       } catch (Exception e) {
           if (e instanceof ApiRequestException) {
               log.debug("Pr2Post Api Request for MSISDN: {} and message: {}", annex.getMsisdn(), e.getMessage());
               throw new ApiRequestException(e.getMessage());
           } else if (e instanceof NoDataModifiedException) {
               log.debug("Pr2Post NoDataModified for MSISDN: {} and message: {}", annex.getMsisdn(), e.getMessage());
               return prepaidToPostpaidWithoutPostpaidCust(custId, contract, annex, contactList, address);
           } else if (e instanceof IncorrectSubscriberPaymentTypeException) {
               log.debug("Pr2Post IncorrectSubscriberPaymentType for MSISDN: {} and message: {}", annex.getMsisdn(), e.getMessage());
               throw new IncorrectSubscriberPaymentTypeException(e.getMessage());
           } else if (e instanceof PendingBusinessOrderException) {
               log.debug("Pr2Post Pending Business Order for MSISDN: {} and message: {}", annex.getMsisdn(), e.getMessage());
               throw new PendingBusinessOrderException(e.getMessage());
           } else if (e instanceof SubscriberNotFoundException) {
               log.debug("Pr2Post SubscriberNotFound for MSISDN: {} and message: {}", annex.getMsisdn(), e.getMessage());
               throw new SubscriberNotFoundException(e.getMessage());
           } else {
               log.error("Pr2Post Service Error for MSISDN: {} Error: {}", annex.getMsisdn(), e.getMessage(), e.getCause());
               throw new ApiRequestException(e.getMessage());
           }
       }
    }
    public Boolean prepaidToPostpaidWithoutPostpaidCust(String custId, Contract contract, Annex annex, List<Contact> contactList, Address address) {
       try {
           PrepaidToPostpaidRequest prepaidToPostpaidRequest = new PrepaidToPostpaidRequest();
           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq changePrepaidToPostpaidReq = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq();

           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct postpaidAcct = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct();

           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct.Account postPaidAccount = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct.Account();
           postPaidAccount.setCustId("");
           postPaidAccount.setAcctName(contract.getCustomerName());
           postPaidAccount.setPaymentType("1");
           postPaidAccount.setTitle("0");

           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidCust.Name postPaidAcctName = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidCust.Name();
           postPaidAcctName.setFirstName(contract.getCustomerName());
           postPaidAcctName.setMiddleName("");
           postPaidAcctName.setLastName(contract.getCustomerName());
           postPaidAccount.setName(postPaidAcctName);

           postPaidAccount.setCustId(custId);
           postPaidAccount.setBillCycleType("01");
           postPaidAccount.setBillLanguage("2002");


           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct.Account.Contact contact = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct.Account.Contact();
           contact.setPriority("1");
           contact.setContactType("1");
           contact.setTitle("0");

           String[] name = contactList.get(0).getName().split(" ");
           String firstName = name[0];
           String lastName = name.length > 1 ? name[1] : "";
           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidCust.Name contactName = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidCust.Name();
           contactName.setFirstName(firstName);
           contactName.setMiddleName("");
           contactName.setLastName(lastName);

           contact.setName(contactName);
           contact.setMobilePhone(contactList.get(0).getMobile());
           contact.setEmail(contactList.get(0).getEmail());
           postPaidAccount.setContact(contact);

           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct.Account.Address postPaidAcctAddress = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct.Account.Address();
           postPaidAcctAddress.setAddressType("4");
           postPaidAcctAddress.setAddress1("1116");

           if (!ObjectUtils.isEmpty(address.getCityProvinceApiValue())) {
               postPaidAcctAddress.setAddress2(address.getCityProvinceApiValue());
           }
           if (!ObjectUtils.isEmpty(address.getKhanDistrictApiValue())) {
               postPaidAcctAddress.setAddress3(address.getKhanDistrictApiValue());
           }
           if (!ObjectUtils.isEmpty(address.getStreet())) {
               postPaidAcctAddress.setAddress5(address.getStreet());
           }
           if (!ObjectUtils.isEmpty(address.getHouseNumber())) {
               postPaidAcctAddress.setAddress7(address.getHouseNumber());
           }
           if (!ObjectUtils.isEmpty(address.getSangkatCommuneApiValue())) {
               postPaidAcctAddress.setAddress11(address.getSangkatCommuneApiValue());
           }
           postPaidAccount.setAddress(postPaidAcctAddress);

           if (!ObjectUtils.isEmpty(annex.getServiceTypeName()) &&
                   !annex.getServiceTypeName().equalsIgnoreCase(ServiceType.Hybrid.name())) {
               PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct.Account.BillMedium billMedium = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct.Account.BillMedium();

               billMedium.setBillMediumId("1084702653");
               billMedium.setBillMediumCode("5");  //E-BILL
               billMedium.setBillContentType("1"); //Summary

               postPaidAccount.setBillMedium(billMedium);
           }

           postPaidAccount.setCurrency("1153");

           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct.Account.CreditLimit creditLimit = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.PostpaidAcct.Account.CreditLimit();
           creditLimit.setLimitType("All");
           creditLimit.setLimitValue("0");
           postPaidAccount.setCreditLimit(creditLimit);

           postpaidAcct.setAccount(postPaidAccount);

           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.Offering offering = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.Offering();
           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.Offering.NewPrimaryOffering newPrimaryOffering = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.Offering.NewPrimaryOffering();
           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.Offering.NewPrimaryOffering.OfferingId offeringId = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.Offering.NewPrimaryOffering.OfferingId();
           offeringId.setOfferingId(annex.getNgbssPlanOfferingId());
           newPrimaryOffering.setOfferingId(offeringId);

           PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.Offering.NewPrimaryOffering.EffectiveMode effectiveMode = new PrepaidToPostpaidRequest.ChangePrepaidToPostpaidReq.Offering.NewPrimaryOffering.EffectiveMode();
           effectiveMode.setMode("0");
           newPrimaryOffering.setEffectiveMode(effectiveMode);
           offering.setNewPrimaryOffering(newPrimaryOffering);

           changePrepaidToPostpaidReq.setPostpaidAcct(postpaidAcct);
           changePrepaidToPostpaidReq.setOffering(offering);
           prepaidToPostpaidRequest.setTransaction_id(Utils.getTransactionIdTimeIn_Date_T_Time_Format());

           prepaidToPostpaidRequest.setChangePrepaidToPostpaidReq(changePrepaidToPostpaidReq);

           if (! isSubscriberExists(annex.getMsisdn())) {
               return false;
           }

           log.debug("Pre2Post Without Postpaid Cust Request: {} for MSISDN: {}", gson.toJson(prepaidToPostpaidRequest), annex.getMsisdn());
           PrepaidToPostpaidResponse prepaidToPostpaidResponse = contractGateway.prepaidToPostpaid(annex.getMsisdn(), prepaidToPostpaidRequest);
           log.debug("Pre2Post Without Postpaid Cust Response: {} for MSISDN: {}", prepaidToPostpaidResponse, annex.getMsisdn());

           return !ObjectUtils.isEmpty(prepaidToPostpaidResponse) && prepaidToPostpaidResponse.getTransaction_status().equals("SUCCESS");
       } catch (Exception e) {
           if (e instanceof ApiRequestException) {
               log.debug("Pre2Post Without Postpaid Cust Api Request for MSISDN: {} and message: {}", annex.getMsisdn(), e.getMessage());
               throw new ApiRequestException(e.getMessage());
           } else if (e instanceof NoDataModifiedException) {
               log.debug("Pre2Post Without Postpaid Cust NoDataModified for MSISDN: {} and message: {}", annex.getMsisdn(), e.getMessage());
               return false;
           } else if (e instanceof IncorrectSubscriberPaymentTypeException) {
               log.debug("Pre2Post without Postpaid Cust Incorrect Payment Option for MSISDN: {} and message: {}", annex.getMsisdn(), e.getMessage());
               throw new IncorrectSubscriberPaymentTypeException(e.getMessage());
           } else if (e instanceof PendingBusinessOrderException) {
               log.debug("Pre2Post Without Postpaid Cust pending business order for: {} and message: {}", annex.getMsisdn(), e.getMessage());
               throw new PendingBusinessOrderException(e.getMessage());
           } else if (e instanceof SubscriberNotFoundException) {
               log.debug("Pr2Post SubscriberNotFound for MSISDN: {} and message: {}", annex.getMsisdn(), e.getMessage());
               throw new SubscriberNotFoundException(e.getMessage());
           }  else {
               log.error("Pre2Post Without Postpaid Cust Service Error for MSISDN: {} Error: {}", annex.getMsisdn(), e.getMessage());
               throw new ApiRequestException(e.getMessage());
           }
       }
    }
    @Override
    public Boolean addCorporateGroup(String customerId, String groupId, String serviceNumber, String departmentName, String departmentId) {
       try {
           AddCorporateGroupRequest addCorporateGroupRequest = new AddCorporateGroupRequest();
           addCorporateGroupRequest.setReqHeader(buildReqHeaderCorporateGroup());
           addCorporateGroupRequest.setCustomerId(customerId);
           addCorporateGroupRequest.setGroupId(groupId);
           addCorporateGroupRequest.setAddMemberInfo(buildMemberInfo(serviceNumber, departmentId, departmentName));

           log.debug("Add Corporate Group Request: {} for MSISDN: {} and Group Id: {}", gson.toJson(addCorporateGroupRequest), serviceNumber, groupId);
           AddCorporateGroupResponse addCorporateGroupResponse = contractGateway.addCorporateGroup(addCorporateGroupRequest);
           log.debug("Add Corporate Group Response: {}, Message: {} for MSISDN: {} and Group Id: {}", gson.toJson(addCorporateGroupResponse), addCorporateGroupResponse.getAddCorporateGroupMemberRspMsg().getRspHeader().getReturnMsg(), serviceNumber, groupId);

           return !ObjectUtils.isEmpty(addCorporateGroupResponse) && (addCorporateGroupResponse.getAddCorporateGroupMemberRspMsg().getRspHeader().getReturnCode().equals("0000") ||
                       addCorporateGroupResponse.getAddCorporateGroupMemberRspMsg().getRspHeader().getReturnMsg().equals("Success"));
       } catch (Exception e) {
           if (e instanceof AlreadyExistsException) {
               log.debug("AddCorporateGroup Already Exists Service Message for MSISDN: {} Message: {}", serviceNumber, e.getMessage());
               throw new AlreadyExistsException(e.getMessage());
           } else if (e instanceof PendingBusinessOrderException) {
               log.debug("AddCorporateGroup Pending Business Order Service Message for MSISDN: {} Message: {}", serviceNumber, e.getMessage());
               throw new PendingBusinessOrderException(e.getMessage());
           } else {
               log.error("AddCorporateGroup Service Error for MSISDN: {} Error: {}", serviceNumber, e.getMessage(), e.getCause());
               throw new ApiRequestException(e.getMessage(), e.getCause());
           }
       }
    }
    private AddCorporateGroupRequest.ReqHeader buildReqHeaderCorporateGroup() {
        AddCorporateGroupRequest.ReqHeader reqHeader = new AddCorporateGroupRequest.ReqHeader();
        String transactionId = "CRM" + Utils.getTransactionId();
        reqHeader.setVersion(version);
        reqHeader.setPartnerId(partnerId);
        reqHeader.setBusinessCode("AD0001");
        reqHeader.setTransactionId(transactionId);
        reqHeader.setReqTime(Utils.getTimeInFormatyyyyMMddHHmmss());
        reqHeader.setChannel(channel);
        reqHeader.setAccessUser(accessUser);
        reqHeader.setAccessPassword(accessPassword);

        return reqHeader;
    }
    private AddCorporateGroupRequest.AddMemberInfo buildMemberInfo(String serviceNumber, String departmentName, String departmentId) {
        AddCorporateGroupRequest.AddMemberInfo addMemberInfo = new AddCorporateGroupRequest.AddMemberInfo();

        addMemberInfo.setHybridFlag("0");
        addMemberInfo.setMemberServiceNum(serviceNumber);
        addMemberInfo.setMemberType("Default");
        addMemberInfo.setDepartmentName(departmentName);
        addMemberInfo.setText("i");
        addMemberInfo.setDepartmentID(departmentId);
        addMemberInfo.setOperateType("1");

        return addMemberInfo;
    }
    @Override
    public Boolean addGroupCUG(Contract contract, Annex annex, String groupCode) {
        try {
            AddGroupCUGRequest addGroupCUGRequest = new AddGroupCUGRequest();

            AddGroupCUGRequest.AddCUGGroupMemberReq addCUGGroupMemberReq = new AddGroupCUGRequest.AddCUGGroupMemberReq();
            AddGroupCUGRequest.AddCUGGroupMemberReq.AddMemberInfo addMemberInfo = new AddGroupCUGRequest.AddCUGGroupMemberReq.AddMemberInfo();
            addMemberInfo.setMemberServiceNum(annex.getMsisdn());
            addCUGGroupMemberReq.setAddMemberInfo(addMemberInfo);
            addGroupCUGRequest.setAddCUGGroupMemberReq(addCUGGroupMemberReq);
            addGroupCUGRequest.setTransaction_id(Utils.getTransactionIdTimeIn_Date_T_Time_Format());
            log.debug("AddCUGGroup Request: {} for MSISDN: {} and Group Code: {}", gson.toJson(addGroupCUGRequest), addGroupCUGRequest.getAddCUGGroupMemberReq().getAddMemberInfo().getMemberServiceNum(), groupCode);
            AddGroupCUGResponse addGroupCUGResponse = contractGateway.addGroupCUG(addGroupCUGRequest, groupCode);
            log.debug("AddCUGGroup Response: {}, Message: {} for MSISDN: {} and Group Code: {}", gson.toJson(addGroupCUGResponse), addGroupCUGResponse.getTransaction_status(), addGroupCUGRequest.getAddCUGGroupMemberReq().getAddMemberInfo().getMemberServiceNum(), groupCode);

            if (!ObjectUtils.isEmpty(addGroupCUGResponse)) {
                return addGroupCUGResponse.getTransaction_status().equalsIgnoreCase("SUCCESS");
            } else {
                return false;
            }
        } catch (Exception e) {
            if (e instanceof AlreadyExistsException) {
                log.debug("AddGroupCUG Already Exists Message for MSISDN: {} Message: {}", annex.getMsisdn(), e.getMessage());
                throw new AlreadyExistsException(e.getMessage());
            } else if (e instanceof PendingBusinessOrderException) {
                log.debug("AddGroupCUG Pending Business Order Service Message for MSISDN: {} Message: {}", annex.getMsisdn(), e.getMessage());
                throw new PendingBusinessOrderException(e.getMessage());
            } else {
                log.error("AddGroupCUG Service Error For MSISDN: {} Error: {}", annex.getMsisdn(), e.getMessage(), e.getCause());
                throw new ApiRequestException(e.getMessage(), e.getCause());
            }
        }
    }

    private ChangeSupplementaryOfferingRequest.ReqHeader buildChangeSupplementaryOfferingRequest() {
        ChangeSupplementaryOfferingRequest.ReqHeader reqHeader = new ChangeSupplementaryOfferingRequest.ReqHeader();
        reqHeader.setPartnerId(partnerId);
        reqHeader.setVersion(version);
        reqHeader.setReqTime(Utils.getTimeInFormatyyyyMMddHHmmss());
        reqHeader.setTransactionId(Utils.getTransactionIdTimeIn_Date_T_Time_Format());
        reqHeader.setChannel(channel);
        reqHeader.setBusinessCode("B201707190001");
        reqHeader.setAccessUser(accessUser);
        reqHeader.setAccessPassword(accessPassword);

        return reqHeader;
    }

    public List<ChangeSupplementaryOfferingRequest.DeleteOffering> buildChangeSupplementaryOfferingDeleteOffering(List<String> existingOfferingList) {
        List<ChangeSupplementaryOfferingRequest.DeleteOffering> deleteOfferingList = new ArrayList<>();

        for (String offering: existingOfferingList) {
            ChangeSupplementaryOfferingRequest.DeleteOffering deleteOffering = new ChangeSupplementaryOfferingRequest.DeleteOffering();

            ChangeSupplementaryOfferingRequest.DeleteOffering.OfferingId offeringId = new ChangeSupplementaryOfferingRequest.DeleteOffering.OfferingId();
            offeringId.setOfferingId(offering);
            deleteOffering.setOfferingId(offeringId);

            com.reddot.ecrm_bulk.api.payload.ChangeSupplementaryOfferingRequest.DeleteOffering.ExpireMode expireMode = new ChangeSupplementaryOfferingRequest.DeleteOffering.ExpireMode();
            expireMode.setMode("I");
            deleteOffering.setExpireMode(expireMode);

            deleteOfferingList.add(deleteOffering);
        }

        return deleteOfferingList;
    }

    public ChangeSupplementaryOfferingRequest.AccessInfo buildAccessInfo(Annex annex) {
        ChangeSupplementaryOfferingRequest.AccessInfo accessInfo = new ChangeSupplementaryOfferingRequest.AccessInfo();
        accessInfo.setObjectId(annex.getMsisdn());
        accessInfo.setObjectIdType("4");

        return accessInfo;
    }

    @Override
    public Boolean changeSupplementaryOffering(Annex annex, List<String> existingOfferingList) {
        try {
            ChangeSupplementaryOfferingRequest changeSupplementaryOfferingRequest = new ChangeSupplementaryOfferingRequest();
            changeSupplementaryOfferingRequest.setReqHeader(buildChangeSupplementaryOfferingRequest());
            changeSupplementaryOfferingRequest.setDeleteOffering(buildChangeSupplementaryOfferingDeleteOffering(existingOfferingList));
            changeSupplementaryOfferingRequest.setAccessInfo(buildAccessInfo(annex));

            log.debug("ChangeSupplementaryOffering Request : {} for MSISDN: {}", gson.toJson(changeSupplementaryOfferingRequest), annex.getMsisdn());
            ChangeSupplementaryOfferingResponse changeSupplementaryOfferingResponse = contractGateway.changeSupplementaryOffering(changeSupplementaryOfferingRequest);
            log.debug("ChangeSupplementaryOffering Response : {} for MSISDN: {}", gson.toJson(changeSupplementaryOfferingResponse), annex.getMsisdn());

            if (! ObjectUtils.isEmpty(changeSupplementaryOfferingResponse)) {
                return changeSupplementaryOfferingResponse.getChangeSupplementaryOfferingRspMsg().getRspHeader().getReturnCode().equalsIgnoreCase("0000");
            } else {
                log.debug("ChangeSupplementaryOffering response is empty for MSISDN: {}", annex.getMsisdn());
                return false;
            }
        } catch (Exception e) {
            log.debug("ChangeSupplementaryOffering Error: {} for MSISDN: {}", e.getMessage(), annex.getMsisdn());
            throw new ApiRequestException(e.getMessage());
        }
    }

    @Override
    public Boolean addSupplementaryOffering(Annex annex) {
       try {
           ChangeSupplementaryOfferingRequest changeSupplementaryOfferingRequest = new ChangeSupplementaryOfferingRequest();
           changeSupplementaryOfferingRequest.setReqHeader(buildChangeSupplementaryOfferingRequest());
           changeSupplementaryOfferingRequest.setAddOffering(buildChangeSupplementaryAddOffering(annex));
           changeSupplementaryOfferingRequest.setAccessInfo(buildAccessInfo(annex));

           log.debug("AddSupplementaryOffering Request : {} for MSISDN: {}", gson.toJson(changeSupplementaryOfferingRequest), annex.getMsisdn());
           ChangeSupplementaryOfferingResponse changeSupplementaryOfferingResponse = contractGateway.changeSupplementaryOffering(changeSupplementaryOfferingRequest);
           log.debug("AddSupplementaryOffering Response : {} for MSISDN: {}", gson.toJson(changeSupplementaryOfferingResponse), annex.getMsisdn());

           if (! ObjectUtils.isEmpty(changeSupplementaryOfferingResponse)) {
               return changeSupplementaryOfferingResponse.getChangeSupplementaryOfferingRspMsg().getRspHeader().getReturnCode().equalsIgnoreCase("0000");
           } else {
               log.debug("AddSupplementaryOffering Response is Empty for MSISDN: {}", annex.getMsisdn());
               return false;
           }
       } catch (Exception e) {
           log.debug("AddSupplementaryOffering Error: {} for MSISDN: {}", e.getMessage(), annex.getMsisdn());
           throw new ApiRequestException(e.getMessage());
       }
    }

    public ChangeAccountInformationRequest buildCreateChangeAccountInformationRequest(Contract contract, Address address) {
        try {
            ChangeAccountInformationRequest request = new ChangeAccountInformationRequest();
            request.setTransaction_id(Utils.getTransactionIdTimeIn_Date_T_Time_Format());
            ChangeAccountInformationRequest.ChangeAcctInfoReq changeAcctInfoReq = new ChangeAccountInformationRequest.ChangeAcctInfoReq();
            ChangeAccountInformationRequest.ChangeAcctInfoReq.Account account = new ChangeAccountInformationRequest.ChangeAcctInfoReq.Account();
            account.setBillLanguage("2002");

            ChangeAccountInformationRequest.ChangeAcctInfoReq.Account.Name name = new ChangeAccountInformationRequest.ChangeAcctInfoReq.Account.Name();
            name.setFirstName(contract.getCustomerName());
            name.setLastName(contract.getCustomerName());

            account.setName(name);
            account.setBillCycleType("01");
            account.setAcctPayMethod("2");

            List<ChangeAccountInformationRequest.ChangeAcctInfoReq.Account.AdditionalProperty> AdditionalProperty = new ArrayList<>();
            AdditionalProperty.add(new ChangeAccountInformationRequest.ChangeAcctInfoReq.Account.AdditionalProperty("marketingCategory", "2"));
            AdditionalProperty.add(new ChangeAccountInformationRequest.ChangeAcctInfoReq.Account.AdditionalProperty("billingGroup", "7"));
            AdditionalProperty.add(new ChangeAccountInformationRequest.ChangeAcctInfoReq.Account.AdditionalProperty("creditMode", "1"));
            AdditionalProperty.add(new ChangeAccountInformationRequest.ChangeAcctInfoReq.Account.AdditionalProperty("freeBillMediumFlag", "1"));
            AdditionalProperty.add(new ChangeAccountInformationRequest.ChangeAcctInfoReq.Account.AdditionalProperty("dunningPlan", "28"));
            AdditionalProperty.add(new ChangeAccountInformationRequest.ChangeAcctInfoReq.Account.AdditionalProperty("zoneId", "1"));
            account.setAdditionalProperty(AdditionalProperty);

            List<ChangeAccountInformationRequest.ChangeAcctInfoReq.Account.Address> addressList = new ArrayList<>();
            ChangeAccountInformationRequest.ChangeAcctInfoReq.Account.Address newAccountAddress = new ChangeAccountInformationRequest.ChangeAcctInfoReq.Account.Address();
            newAccountAddress.setAddressType("0"); //Register company address
            newAccountAddress.setAddress1("1116");
            newAccountAddress.setActionType("2");
            if (!ObjectUtils.isEmpty(address.getCityProvinceApiValue())) {
                newAccountAddress.setAddress2(address.getCityProvinceApiValue());
            }
            if (!ObjectUtils.isEmpty(address.getKhanDistrictApiValue())) {
                newAccountAddress.setAddress3(address.getKhanDistrictApiValue());
            }
            if (!ObjectUtils.isEmpty(address.getSangkatCommuneApiValue())) {
                newAccountAddress.setAddress11(address.getSangkatCommuneApiValue());
            }

            addressList.add(newAccountAddress);
            account.setAddress(addressList);

            changeAcctInfoReq.setAccount(account);
            request.setChangeAcctInfoReq(changeAcctInfoReq);

            return request;
        } catch (Exception e) {
            log.debug("buildCreateChangeAccountInformationRequest Error: {}", e.getMessage(), e.getCause());
            throw new RuntimeException(e.getMessage());
        }
    }

    @Override
    public Boolean changeAccountInformation(String accountId, Contract contract, Annex annex, Address address) {
        try {
            ChangeAccountInformationRequest changeAccountInformationRequest = buildCreateChangeAccountInformationRequest(contract, address);

            log.debug("ChangeAccountInformation Request: {} for MSISDN:  {}", gson.toJson(changeAccountInformationRequest), annex.getMsisdn());
            ChangeAccountInformationCommonResponse changeAccountInformationResponse = contractGateway.changeAccountInformation(accountId, changeAccountInformationRequest);
            log.debug("ChangeAccountInformation Response: {} for MSISDN:  {}", gson.toJson(changeAccountInformationResponse), annex.getMsisdn());
            if (! ObjectUtils.isEmpty(changeAccountInformationResponse)) {
                return changeAccountInformationResponse.getMessage().equalsIgnoreCase("SUCCESS");
            } else {
                log.debug("ChangeAccountInformationCommonResponse is empty for MSISDN: {}", annex.getMsisdn());
                return false;
            }
        } catch (Exception e) {
            log.debug("ChangeAccountInformation Error: {} for MSISDN: {}", e.getMessage(), annex.getMsisdn());
            throw new ApiRequestException(e.getMessage());
        }
    }

    @Override
    public List<String> queryPurchasedSupplementaryOffering(String msisdn) {
      try {
          QueryPurchasedSupplementaryOfferingResponse queryPurchasedSupplementaryOfferingResponse = contractGateway.queryPurchasedSupplementaryOffering(partnerId, Utils.generateTransactionId(), Utils.getTimeInFormatyyyyMMddHHmmss(), channel, accessUser, accessPassword, "4", msisdn);

          if (! ObjectUtils.isEmpty(queryPurchasedSupplementaryOfferingResponse)) {
              if (queryPurchasedSupplementaryOfferingResponse.getQueryPurchasedSupplementaryOfferingRspMsg().getRspHeader().getReturnCode().equalsIgnoreCase("0000")) {

                  if (! ObjectUtils.isEmpty(queryPurchasedSupplementaryOfferingResponse.getQueryPurchasedSupplementaryOfferingRspMsg().getSupplementaryOffering())) {

                      List<? extends QueryPurchasedSupplementaryOfferingResponse.QueryPurchasedSupplementaryOfferingRspMsg.SupplementaryOffering> offerings = queryPurchasedSupplementaryOfferingResponse.getQueryPurchasedSupplementaryOfferingRspMsg().getSupplementaryOffering();
                      List<String> supplementaryOfferingList = new ArrayList<>();

                      for (QueryPurchasedSupplementaryOfferingResponse.QueryPurchasedSupplementaryOfferingRspMsg.SupplementaryOffering offering : offerings) {
                          supplementaryOfferingList.add(String.valueOf(offering.getOfferingId().getOfferingId()));
                      }

                      return supplementaryOfferingList;
                  } else {
                      log.debug("QueryPurchasedSupplementaryOfferingResponse getSupplementaryOffering is empty for MSISDN: {}", msisdn);
                      return new ArrayList<>();
                  }
              } else {
                  return new ArrayList<>();
              }
          } else {
              return new ArrayList<>();
          }
      } catch (Exception e) {
          log.debug("QueryPurchasedSupplementaryOffering Service Error: {} for MSISDN: {}", e.getMessage(), msisdn);
          throw new ApiRequestException(e.getMessage());
      }
    }

    @Override
    public ChangeCorporateGroupMemberInfoResponse changeCorporateGroupMemberInfo(String customerId, String groupId, String serviceNumber, String departmentName, String departmentId) {
        try {
            ChangeCorporateGroupMemberInfoRequest request = new ChangeCorporateGroupMemberInfoRequest();
            request.setReqHeader(buildReqHeaderChangeCorporateGroup());
            request.setAccessInfo(buildMemberAccessInfo(serviceNumber));
            request.setCustomerId(customerId);
            request.setGroupId(groupId);
            request.setChangeMemberInfo(buildChangeMemberInfo(departmentName, departmentId));

            log.debug("ChangeCorporateGroupInfo Request: {} for MSISDN: {}", request, serviceNumber);
            ChangeCorporateGroupMemberInfoResponse response = contractGateway.changeCorporateGroupMemberInfo(request);
            log.debug("ChangeCorporateGroupInfo Response: {}, Message: {} for MSISDN: {}", gson.toJson(response), response.getChangeCorporateGroupMemberInfoRspMsg().getRspHeader().getReturnMsg(), serviceNumber);
            return response;
        } catch (Exception e) {
            if (e instanceof AlreadyExistsException) {
                log.debug("ChangeCorporateGroup Already Exists Service Message for MSISDN: {} Message: {}", serviceNumber, e.getMessage());
                throw new AlreadyExistsException(e.getMessage());
            } else if (e instanceof SubscriberHasSomeOutstandingException) {
                log.debug("ChangeCorporateGroup Subscriber Has Some Outstanding Message for MSISDN: {} Message: {}", serviceNumber, e.getMessage());
                throw new SubscriberHasSomeOutstandingException(e.getMessage());
            } else {
                log.error("ChangeCorporateGroup Service Error for MSISDN: {} Error: {}", serviceNumber, e.getMessage());
                throw new ApiRequestException(e.getMessage());
            }
        }
    }
    private ChangeCorporateGroupMemberInfoRequest.AccessInfo buildMemberAccessInfo(String serviceNum) {
        ChangeCorporateGroupMemberInfoRequest.AccessInfo accessInfo = new ChangeCorporateGroupMemberInfoRequest.AccessInfo();
        accessInfo.setObjectIdType("4");
        accessInfo.setObjectId(serviceNum);
        return accessInfo;
    }

    private ChangeCorporateGroupMemberInfoRequest.ReqHeader buildReqHeaderChangeCorporateGroup() {
        ChangeCorporateGroupMemberInfoRequest.ReqHeader reqHeader = new ChangeCorporateGroupMemberInfoRequest.ReqHeader();

        String transactionId = Utils.generateTransactionId();
        reqHeader.setVersion(version);
        reqHeader.setPartnerId(partnerId);
        reqHeader.setBusinessCode("AD0001");
        reqHeader.setTransactionId(transactionId);
        reqHeader.setReqTime(Utils.getTimeInFormatyyyyMMddHHmmss());
        reqHeader.setChannel(channel);
        reqHeader.setAccessUser(accessUser);
        reqHeader.setAccessPassword(accessPassword);

        return reqHeader;
    }
    private ChangeCorporateGroupMemberInfoRequest.ChangeMemberInfo buildChangeMemberInfo(String departmentName, String departmentId) {
        ChangeCorporateGroupMemberInfoRequest.ChangeMemberInfo changeMemberInfo = new ChangeCorporateGroupMemberInfoRequest.ChangeMemberInfo();

        changeMemberInfo.setMemberType("Default");
        changeMemberInfo.setOperateType("1");
        changeMemberInfo.setDepartmentName(departmentName);
        changeMemberInfo.setDepartmentID(departmentId);
        changeMemberInfo.setHybridFlag("0");

        return changeMemberInfo;
    }

    @Override
    public Boolean changeAccountCreditLimit(String acctId, Annex annex) {
        try {
            ChangeAccountCreditLimitRequest creditLimitRequest = new ChangeAccountCreditLimitRequest();
            creditLimitRequest.setReqHeader(buildReqHeaderChangeCreditLimit());
            creditLimitRequest.setAccount(buildChangeCreditLimitAccount(acctId, annex));

            log.debug("ChangeAccountCreditLimit Request: {} for MSISDN: {}", gson.toJson(creditLimitRequest), annex.getMsisdn());
            ChangeAccountCreditLimitResponse changeAccountCreditLimitResponse = contractGateway.changeAccountCreditLimit(creditLimitRequest);
            log.debug("ChangeAccountCreditLimit Response: {} for MSISDN: {}", gson.toJson(changeAccountCreditLimitResponse), annex.getMsisdn());

            if (! ObjectUtils.isEmpty(changeAccountCreditLimitResponse)) {
                return changeAccountCreditLimitResponse.getChangeAccountCreditLimitRspMsg().getRspHeader().getReturnCode().equalsIgnoreCase("0000");
            } else {
                return false;
            }
        } catch (Exception e) {
            if (e instanceof ThrottleException) {
                throw new ThrottleException(e.getMessage());
            }
            throw new ApiRequestException(e.getMessage(), e.getCause());
        }
    }

    private ChangeAccountCreditLimitRequest.Account buildChangeCreditLimitAccount(String acctId, Annex annex) {
        ChangeAccountCreditLimitRequest.Account account = new ChangeAccountCreditLimitRequest.Account();
        account.setAcctId(acctId);
        account.setActionType("MOD");

        ChangeAccountCreditLimitRequest.Account.CreditLimit creditLimit = new ChangeAccountCreditLimitRequest.Account.CreditLimit();
        creditLimit.setLimitType("I");
        creditLimit.setLimitValue(String.valueOf(convertLimitValue(annex)));
        creditLimit.setEffectiveDate(localDateFormatted());

        List<ChangeAccountCreditLimitRequest.Account.CreditLimit> creditLimitList = new ArrayList<>();
        creditLimitList.add(creditLimit);

        account.setCreditLimit(creditLimitList);

        return account;
    }

    private ChangeAccountCreditLimitRequest.ReqHeader buildReqHeaderChangeCreditLimit() {
        ChangeAccountCreditLimitRequest.ReqHeader reqHeader = new ChangeAccountCreditLimitRequest.ReqHeader();
        reqHeader.setVersion(version);
        reqHeader.setPartnerId(partnerId);
        reqHeader.setTransactionId(Utils.getTransactionIdTimeIn_Date_T_Time_Format());
        reqHeader.setReqTime(Utils.getTimeInFormatyyyyMMddHHmmss());
        reqHeader.setChannel(channel); //
        reqHeader.setAccessUser(accessUser);
        reqHeader.setAccessPassword(accessPassword);
        return reqHeader;
    }

    @Override
    public Boolean createOrder(Contract contract, Annex annex, PrimaryOffering primaryOffering, List<Contact> contactList, Address address) {
      try {
          CreateOrderRequest createOrderRequest = new CreateOrderRequest();

          createOrderRequest.setReqHeader(buildReqHeaderCreateOrder());
          createOrderRequest.setOrder(buildOrder());
          createOrderRequest.setCustomer(buildCustomer(contract, contactList, address));
          createOrderRequest.setAccount(buildAccount(contract, annex, address));
          createOrderRequest.setSubscriber(buildSubscriber(annex));
          createOrderRequest.setPrimaryOffering(buildPrimaryOffering(primaryOffering));

          if (!ObjectUtils.isEmpty(annex.getNgbssAddOnsOfferingId())) {
              createOrderRequest.setSupplementaryOffering(buildSupplementaryOffering(annex));
          }

          log.debug("CreateOrder Request: {} for MSISDN: {}", gson.toJson(createOrderRequest), annex.getMsisdn());
          CreateOrderResponse createOrderResponse = contractGateway.createOrder(createOrderRequest);
          log.debug("CreateOrder Response: {} for MSISDN: {}", gson.toJson(createOrderResponse), annex.getMsisdn());

          if (! ObjectUtils.isEmpty(createOrderResponse)) {
              if (createOrderResponse.getCreateOrderRspMsg().getRspHeader().getReturnCode().equals("0000") ||
                      createOrderResponse.getCreateOrderRspMsg().getRspHeader().getReturnMsg().equals("Success")) {
                  return isSubscriberExists(annex.getMsisdn());
              } else {
                  log.debug("CreateOrder API Response Message for MSISDN: {} Message: {}", annex.getMsisdn(), createOrderResponse.getCreateOrderRspMsg().getRspHeader().getReturnMsg());
                  return false;
              }
          } else {
              log.debug("CreateOrder API Response is Empty for MSISDN: {}", annex.getMsisdn());
              return false;
          }
      } catch (Exception e) {
          if (e instanceof AlreadyExistsException) {
              log.debug("CreateOrder Already Exists Service Message for MSISDN: {} Message: {}", annex.getMsisdn(), e.getMessage());
              annexService.updateAnnexAPIMessage(annex, e.getMessage());
              return isSubscriberExists(annex.getMsisdn());
          } else if (e instanceof ServiceNumberNotFoundException) {
              log.debug("CreateOrder ServiceNumberNotFound Service Message for MSISDN: {} Message: {}", annex.getMsisdn(), e.getMessage());
              throw new ServiceNumberNotFoundException(e.getMessage());
          } else if (e instanceof SubscriberNotFoundException) {
              throw new SubscriberNotFoundException(e.getMessage());
          } else if (e instanceof SIMCardNotExistsException) {
              throw new SIMCardNotExistsException(e.getMessage());
          } else {
              log.error("CreateOrder Service Error for MSISDN: {} Error: {}", annex.getMsisdn(), e.getMessage(), e.getCause());
              throw new ApiRequestException(e.getMessage(), e.getCause());
          }
      }
    }
    private Boolean isSubscriberExists(String msisdn) {
        try {
            SubscriberInfoResponse subscriberInfoResponse = getSubscriberInfo(msisdn);
            log.debug("Subscriber Info Response: {} for MSISDN: {}", subscriberInfoResponse, msisdn);
            return !ObjectUtils.isEmpty(subscriberInfoResponse) && !ObjectUtils.isEmpty(subscriberInfoResponse.getSubscriber());
        } catch (Exception e) {
            if (e instanceof SubscriberNotFoundException) {
                throw new SubscriberNotFoundException(e.getMessage());
            } else {
                throw new ApiRequestException(e.getMessage());
            }
        }
    }
    @Override
    public SubscriberInfoResponse getSubscriberInfo(String msisdn) {
        try {
            return contractGateway.subscriberInfo(msisdn, accessUser, accessPassword);
        } catch (Exception e) {
            if (e instanceof ApiRequestException) {
                log.debug("SubscriberInfo Api Request Service Error for MSISDN: {} Error: {}", msisdn, e.getMessage());
                throw new ApiRequestException(e.getMessage());
            } else if (e instanceof SubscriberNotFoundException) {
                log.debug("Subscriber {} does not exists.", msisdn);
                throw new SubscriberNotFoundException(e.getMessage());
            } else {
                log.error("SubscriberInfo Service Error for MSISDN: {} Error: {}", msisdn, e.getMessage());
                throw new ApiRequestException(e.getMessage());
            }
        }
    }
    private CreateOrderRequest.ReqHeader buildReqHeaderCreateOrder() {
        CreateOrderRequest.ReqHeader reqHeader = new CreateOrderRequest.ReqHeader();
        String transactionId = "CRM" + Utils.getTransactionId();
        reqHeader.setVersion(version);
        reqHeader.setPartnerId(partnerId);
        reqHeader.setTransactionId(transactionId);
        reqHeader.setReqTime(Utils.getTimeInFormatyyyyMMddHHmmss());
        reqHeader.setChannel(channel); //
        reqHeader.setAccessUser(accessUser);
        reqHeader.setAccessPassword(accessPassword);
        return reqHeader;
    }
    private CreateOrderRequest.Customer buildCustomer(Contract contract, List<Contact> contactList, Address address) {
        CreateOrderRequest.Customer customer = new CreateOrderRequest.Customer();
        CreateOrderRequest.Customer.NewCustomer newCustomer = new CreateOrderRequest.Customer.NewCustomer();

        newCustomer.setCustLevel("1");
        newCustomer.setTitle("0");

        CreateOrderRequest.Account.NewAccount.Name newCustomerName = new CreateOrderRequest.Account.NewAccount.Name();
        newCustomerName.setFirstName(contract.getCustomerName());
        newCustomerName.setLastName("");
        newCustomerName.setMiddleName("");
        newCustomer.setName(newCustomerName);
        customer.setNewCustomer(newCustomer);

        if (!ObjectUtils.isEmpty(address.getMocNumber())) {
            CreateOrderRequest.Customer.NewCustomer.Certificate certificate = new CreateOrderRequest.Customer.NewCustomer.Certificate();
            certificate.setIdNum(address.getMocNumber());
            certificate.setIdType(address.getCertificationTypeApiValue());
            newCustomer.setCertificate(certificate);
        }

        List<CreateOrderRequest.Customer.NewCustomer.Contact> contacts = new ArrayList<>();
        Integer priorityNum = 1;
        for (Contact contactEntity : contactList) {
            CreateOrderRequest.Customer.NewCustomer.Contact contact = new CreateOrderRequest.Customer.NewCustomer.Contact();
            contact.setContactType("2"); //0:Oneself.

            String[] name = contactEntity.getName().split(" ");
            String firstName = name[0];
            String lastName = name.length > 1 ? name[1] : "";
            CreateOrderRequest.Account.NewAccount.Name NewAccountName = new CreateOrderRequest.Account.NewAccount.Name();
            NewAccountName.setFirstName(firstName);
            NewAccountName.setLastName(lastName);
            NewAccountName.setMiddleName(" ");
            contact.setName(NewAccountName);

            contact.setEmail(contactEntity.getEmail());
            contact.setTitle(contactEntity.getSalutationApiValue());
            contact.setPriority(String.valueOf(priorityNum));
            contact.setMobilePhone(contact.getMobilePhone());
            contacts.add(contact);
            priorityNum++;
        }
        newCustomer.setContact(contacts);

        List<CreateOrderRequest.Account.NewAccount.Address> addressList = new ArrayList<>();
        CreateOrderRequest.Account.NewAccount.Address newAccountAddress = new CreateOrderRequest.Account.NewAccount.Address();
        newAccountAddress.setAddressType("9"); //Register company address
        newAccountAddress.setAddress1("1116");

        if (!ObjectUtils.isEmpty(address.getCityProvinceApiValue())) {
            newAccountAddress.setAddress2(address.getCityProvinceApiValue());
        }
        if (!ObjectUtils.isEmpty(address.getKhanDistrictApiValue())) {
            newAccountAddress.setAddress3(address.getKhanDistrictApiValue());
        }
        if (!ObjectUtils.isEmpty(address.getStreet())) {
            newAccountAddress.setAddress5(address.getStreet());
        }
        if (!ObjectUtils.isEmpty(address.getHouseNumber())) {
            newAccountAddress.setAddress7(address.getHouseNumber());
        }
        if (!ObjectUtils.isEmpty(address.getSangkatCommuneApiValue())) {
            newAccountAddress.setAddress11(address.getSangkatCommuneApiValue());
        }
        addressList.add(newAccountAddress);

        newCustomer.setAddress(addressList);

        List<CreateOrderRequest.Account.NewAccount.AdditionalProperty> additionalPropertyList = new ArrayList<>();
        CreateOrderRequest.Account.NewAccount.AdditionalProperty additionalPropertyVerifiedCust = new CreateOrderRequest.Account.NewAccount.AdditionalProperty();
        additionalPropertyVerifiedCust.setCode("verifiedcust");
        additionalPropertyVerifiedCust.setValue("0");
        additionalPropertyList.add(additionalPropertyVerifiedCust);
        CreateOrderRequest.Account.NewAccount.AdditionalProperty additionalPropertyCustCategory = new CreateOrderRequest.Account.NewAccount.AdditionalProperty();
        additionalPropertyCustCategory.setCode("custcategory");
        additionalPropertyCustCategory.setValue("1");
        additionalPropertyList.add(additionalPropertyCustCategory);
        CreateOrderRequest.Account.NewAccount.AdditionalProperty additionalPropertyAgreementNum = new CreateOrderRequest.Account.NewAccount.AdditionalProperty();
        additionalPropertyAgreementNum.setCode("agreementNum");
        additionalPropertyAgreementNum.setValue("3244325432");
        additionalPropertyList.add(additionalPropertyAgreementNum);
        CreateOrderRequest.Account.NewAccount.AdditionalProperty additionalPropertyMotherMaidenName = new CreateOrderRequest.Account.NewAccount.AdditionalProperty();
        additionalPropertyMotherMaidenName.setCode("MOTHER_MAIDEN_NAME");
        additionalPropertyMotherMaidenName.setValue("AAAA");
        additionalPropertyList.add(additionalPropertyMotherMaidenName);
        newCustomer.setAdditionalProperty(additionalPropertyList);

        return customer;
    }
    private List<CreateOrderRequest.Account> buildAccount(Contract contract, Annex annex, Address address) {
        List<CreateOrderRequest.Account> accountList = new ArrayList<>();
        CreateOrderRequest.Account account = new CreateOrderRequest.Account();

        CreateOrderRequest.Account.NewAccount newAccount = new CreateOrderRequest.Account.NewAccount();

        newAccount.setAcctName(contract.getCustomerName());
        newAccount.setPaymentType("1");
        newAccount.setTitle("0");

        CreateOrderRequest.Account.NewAccount.Name Name = new CreateOrderRequest.Account.NewAccount.Name();
        String[] name = contract.getCustomerName().split(" ");
        String firstName = name[0];
        String lastName = name.length > 1 ? name[name.length - 1] : firstName;

        Name.setFirstName(firstName);
        Name.setMiddleName("");
        Name.setLastName(lastName);
        newAccount.setName(Name);

        List<CreateOrderRequest.Account.NewAccount.Address> addressList = new ArrayList<>();
        CreateOrderRequest.Account.NewAccount.Address newAccountAddress = new CreateOrderRequest.Account.NewAccount.Address();
        newAccountAddress.setAddressType("4"); //Register company address
        newAccountAddress.setAddress1("1116");
        if (!ObjectUtils.isEmpty(address.getCityProvinceApiValue())) {
            newAccountAddress.setAddress2(address.getCityProvinceApiValue());
        }
        if (!ObjectUtils.isEmpty(address.getKhanDistrictApiValue())) {
            newAccountAddress.setAddress3(address.getKhanDistrictApiValue());
        }
        if (!ObjectUtils.isEmpty(address.getStreet())) {
            newAccountAddress.setAddress5(address.getStreet());
        }
        if (!ObjectUtils.isEmpty(address.getHouseNumber())) {
            newAccountAddress.setAddress7(address.getHouseNumber());
        }
        if (!ObjectUtils.isEmpty(address.getSangkatCommuneApiValue())) {
            newAccountAddress.setAddress11(address.getSangkatCommuneApiValue());
        }
        addressList.add(newAccountAddress);
        newAccount.setAddress(addressList);

        if (!ObjectUtils.isEmpty(annex.getServiceTypeName()) &&
                !annex.getServiceTypeName().equalsIgnoreCase(ServiceType.Hybrid.name())) {
            List<CreateOrderRequest.Account.NewAccount.BillMedium> billMediumList = new ArrayList<>();
            CreateOrderRequest.Account.NewAccount.BillMedium billMedium = new CreateOrderRequest.Account.NewAccount.BillMedium();

            billMedium.setBillMediumId("1084702653");
            billMedium.setBillMediumCode("5");  //E-BILL
            billMedium.setBillContentType("1"); //Summary

            billMediumList.add(billMedium);
            newAccount.setBillMedium(billMediumList);
        }

        newAccount.setCurrency("1153");

        List<CreateOrderRequest.Account.NewAccount.CreditLimit> creditLimitList = new ArrayList<>();
        CreateOrderRequest.Account.NewAccount.CreditLimit creditLimit = new CreateOrderRequest.Account.NewAccount.CreditLimit();
        creditLimit.setLimitType("All");
        creditLimit.setLimitValue(String.valueOf(convertLimitValue(annex)));
        creditLimitList.add(creditLimit);
        newAccount.setCreditLimit(creditLimitList);

        List<CreateOrderRequest.Account.NewAccount.AdditionalProperty> additionalPropertyList = new ArrayList<>();
        CreateOrderRequest.Account.NewAccount.AdditionalProperty additionalPropertyMarketingCategory = new CreateOrderRequest.Account.NewAccount.AdditionalProperty();
        additionalPropertyMarketingCategory.setCode("marketingCategory");
        additionalPropertyMarketingCategory.setValue("2");
        additionalPropertyList.add(additionalPropertyMarketingCategory);
        CreateOrderRequest.Account.NewAccount.AdditionalProperty additionalPropertyBillingGroup = new CreateOrderRequest.Account.NewAccount.AdditionalProperty();
        additionalPropertyBillingGroup.setCode("billingGroup");
        additionalPropertyBillingGroup.setValue("7");
        additionalPropertyList.add(additionalPropertyBillingGroup);
        CreateOrderRequest.Account.NewAccount.AdditionalProperty additionalPropertyCreditMode = new CreateOrderRequest.Account.NewAccount.AdditionalProperty();
        additionalPropertyCreditMode.setCode("creditMode");
        additionalPropertyCreditMode.setValue("1");
        additionalPropertyList.add(additionalPropertyCreditMode);
        CreateOrderRequest.Account.NewAccount.AdditionalProperty additionalPropertyDunningPlan = new CreateOrderRequest.Account.NewAccount.AdditionalProperty();
        additionalPropertyDunningPlan.setCode("dunningPlan");
        additionalPropertyDunningPlan.setValue("28");
        additionalPropertyList.add(additionalPropertyDunningPlan);
        CreateOrderRequest.Account.NewAccount.AdditionalProperty additionalPropertyZoneId = new CreateOrderRequest.Account.NewAccount.AdditionalProperty();
        additionalPropertyZoneId.setCode("zoneId");
        additionalPropertyZoneId.setValue("1");
        additionalPropertyList.add(additionalPropertyZoneId);
        CreateOrderRequest.Account.NewAccount.AdditionalProperty additionalFreeBillMediumFlag = new CreateOrderRequest.Account.NewAccount.AdditionalProperty();
        additionalFreeBillMediumFlag.setCode("freeBillMediumFlag");
        additionalFreeBillMediumFlag.setValue("1");
        additionalPropertyList.add(additionalFreeBillMediumFlag);
        newAccount.setAdditionalProperty(additionalPropertyList);

        account.setNewAccount(newAccount);

        accountList.add(account);

        return accountList;
    }

    private Long convertLimitValue(Annex annex) {
        double totalCredit = !ObjectUtils.isEmpty(annex.getTotalCredit()) ? annex.getTotalCredit() : 0;
        int totalCreditInteger = Math.toIntExact(Math.round(totalCredit));

        int totalCreditIntegerWithTwo = totalCreditInteger * 100; //2

        return (long) totalCreditIntegerWithTwo * 1000000;
    }
    private CreateOrderRequest.PrimaryOffering buildPrimaryOffering(PrimaryOffering offeringPrimary) {
        CreateOrderRequest.PrimaryOffering primaryOffering = new CreateOrderRequest.PrimaryOffering();
        CreateOrderRequest.PrimaryOffering.OfferingId offeringId = new CreateOrderRequest.PrimaryOffering.OfferingId();
        offeringId.setOfferingId(offeringPrimary.getNgbssOfferingId());
        primaryOffering.setOfferingId(offeringId);

        if (!ObjectUtils.isEmpty(offeringPrimary.getAgreementId())) {
            CreateOrderRequest.PrimaryOffering.Contract primaryOfferingContract = new CreateOrderRequest.PrimaryOffering.Contract();
            primaryOfferingContract.setAgreementId(offeringPrimary.getAgreementId());
            primaryOfferingContract.setDurationUnit("Y");
            primaryOfferingContract.setDurationValue("1");
            primaryOffering.setContract(primaryOfferingContract);
        }
        return primaryOffering;
    }
    private List<CreateOrderRequest.SupplementaryOffering> buildSupplementaryOffering(Annex annex) {
        List<CreateOrderRequest.SupplementaryOffering> supplementaryOfferingList = new ArrayList<>();

        for (String offering: annex.getNgbssAddOnsOfferingId().split(",")) {
            CreateOrderRequest.SupplementaryOffering supplementaryOffering = new CreateOrderRequest.SupplementaryOffering();
            supplementaryOffering.setOfferingId(offering);
            supplementaryOffering.setEffectiveMode(new CreateOrderRequest.SupplementaryOffering.EffectiveMode("I", localDateFormatted()));
            supplementaryOffering.setActiveMode(new CreateOrderRequest.SupplementaryOffering.ActiveMode("A", localDateFormatted()));
            supplementaryOffering.setExpirationDate(supplementaryOfferingExpiration);
            supplementaryOfferingList.add(supplementaryOffering);
        }

        return supplementaryOfferingList;
    }



    private List<ChangeSupplementaryOfferingRequest.AddOffering> buildChangeSupplementaryAddOffering(Annex annex) {
        List<ChangeSupplementaryOfferingRequest.AddOffering> supplementaryOfferingList = new ArrayList<>();

        for (String offering: annex.getNgbssAddOnsOfferingId().split(",")) {

            if(mandatoryOfferingService.IsMandatoryOffering(offering)) {
                continue;
            }

            ChangeSupplementaryOfferingRequest.AddOffering supplementaryOffering = new ChangeSupplementaryOfferingRequest.AddOffering();
            supplementaryOffering.setOfferingId(new ChangeSupplementaryOfferingRequest.AddOffering.OfferingId(offering));
            supplementaryOffering.setEffectiveMode(new ChangeSupplementaryOfferingRequest.AddOffering.EffectiveMode("0"));
            supplementaryOfferingList.add(supplementaryOffering);
        }

        return supplementaryOfferingList;
    }

    private CreateOrderRequest.Subscriber buildSubscriber(Annex annex) {
        CreateOrderRequest.Subscriber subscriber = new CreateOrderRequest.Subscriber();
        subscriber.setServiceNum(annex.getMsisdn());
        subscriber.setICCID(annex.getIccid());
        subscriber.setLanguage("2061");
        subscriber.setWrittenLanguage("2061");
        subscriber.setPassword(accessPassword);

        return subscriber;
    }
    private CreateOrderRequest.Order buildOrder() {
        CreateOrderRequest.Order order = new CreateOrderRequest.Order();
        order.setOrderType("CO011");
        return order;
    }
    public String localDateFormatted() {
        try {
            LocalDate Date = LocalDate.parse(LocalDate.now().toString());
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
            String dateTimeFormat = Date.format(formatter);
            dateTimeFormat = dateTimeFormat + "000000";
            return dateTimeFormat;
        } catch (Exception e) {
            log.error("Local Date Formatted Error: {}", e.getMessage());
            return null;
        }
    }
}
