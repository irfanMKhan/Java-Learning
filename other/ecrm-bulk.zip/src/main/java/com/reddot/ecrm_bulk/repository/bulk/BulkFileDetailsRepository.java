package com.reddot.ecrm_bulk.repository.bulk;

import com.reddot.ecrm_bulk.entity.annex.Annex;
import com.reddot.ecrm_bulk.entity.bulk.BulkFile;
import com.reddot.ecrm_bulk.entity.bulk.BulkFileDetails;
import com.reddot.ecrm_bulk.enums.status.Status;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Repository
public class BulkFileDetailsRepository {
    @PersistenceContext
    private EntityManager entityManager;

    @Value("${spring.jpa.properties.hibernate.jdbc.batch_size}")
    private int batchSize;

    @Transactional
    public List<BulkFileDetails> bulkSave(List<BulkFileDetails> entities) {
        final List<BulkFileDetails> savedEntities = new ArrayList<>(entities.size());
        int i = 0;
        for (BulkFileDetails bulkFileDetails : entities) {
            savedEntities.add(persistOrMerge(bulkFileDetails));
            i++;
            if (i % batchSize == 0) {
                // Flush a batch of inserts and release memory.
                entityManager.flush();
                entityManager.clear();
            }
        }
        return savedEntities;
    }

    private BulkFileDetails persistOrMerge(BulkFileDetails bulkFileDetails) {
        if (bulkFileDetails.getId() == null) {
            entityManager.persist(bulkFileDetails);
            return bulkFileDetails;
        } else {
            return entityManager.merge(bulkFileDetails);
        }
    }

    public List<BulkFileDetails> findByBulkFileIdAndStatus(Long bulkFileId, Status status) {
        TypedQuery<BulkFileDetails> query = entityManager.createQuery(
                "SELECT b FROM BulkFileDetails b WHERE b.bulkFileId = :bulkFileId AND b.finalStatus = :finalStatus",
                BulkFileDetails.class);
        return query.setParameter("bulkFileId", bulkFileId)
                .setParameter("finalStatus", status.name())
                .getResultList();
    }

    public List<BulkFileDetails> findAllByBulkFileId(Long bulkFileId) {
        TypedQuery<BulkFileDetails> query = entityManager.createQuery(
                "SELECT b FROM BulkFileDetails b WHERE b.bulkFileId = :bulkFileId",
                BulkFileDetails.class);
        return query.setParameter("bulkFileId", bulkFileId)
                .getResultList();
    }

    @Transactional
    public BulkFileDetails update(BulkFileDetails bulkFileDetails) {
        entityManager.merge(bulkFileDetails);
        return bulkFileDetails;
    }
}
