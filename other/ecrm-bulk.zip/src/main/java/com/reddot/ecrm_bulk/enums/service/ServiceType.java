package com.reddot.ecrm_bulk.enums.service;

public enum ServiceType {
    Prepaid,
    Postpaid,
    Hybrid,
    PBX
}
