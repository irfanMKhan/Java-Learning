package com.reddot.ecrm_bulk.repository.company;

import com.reddot.ecrm_bulk.entity.company.Company;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

@Repository
public class CompanyRepository {
    @PersistenceContext
    private EntityManager entityManager;

    public Company findByName(String name) {
        TypedQuery<Company> query = entityManager.createQuery(
                "SELECT c FROM Company c WHERE c.name = :name",
                Company.class);
        return query.setParameter("name", name).getSingleResult();
    }
    public Company findByIdAndActive(Long id,Boolean active) {
        TypedQuery<Company> query = entityManager.createQuery(
                "SELECT c FROM Company c WHERE c.id = :id and c.active = :active",
                Company.class);
        return query.setParameter("id", id).setParameter("active", active).getSingleResult();
    }

    @Transactional
    public Company save(Company company) {
        entityManager.persist(company);
        return company;
    }

    @Transactional
    public Company update(Company company) {
        entityManager.merge(company);
        return company;
    }
}
