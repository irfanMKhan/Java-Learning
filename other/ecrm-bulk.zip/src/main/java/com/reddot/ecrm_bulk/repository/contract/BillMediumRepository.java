package com.reddot.ecrm_bulk.repository.contract;

import com.reddot.ecrm_bulk.entity.annex.Annex;
import com.reddot.ecrm_bulk.entity.contract.BillMedium;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import java.util.List;

@Repository
public class BillMediumRepository {
    @PersistenceContext
    private EntityManager entityManager;

    public BillMedium findByContractIdAndServiceTypeName(Long contractId, String serviceTypeName) {
        TypedQuery<BillMedium> query = entityManager.createQuery(
                "SELECT b FROM BillMedium b WHERE b.contractId = :contractId AND b.serviceTypeName = :serviceTypeName",
                BillMedium.class);
        return query.setParameter("contractId", contractId)
                .setParameter("serviceTypeName", serviceTypeName)
                .getSingleResult();
    }
}
