package com.reddot.ecrm_bulk.api.payload.group;

import lombok.Data;

import java.io.Serializable;

@Data
public class AddGroupCUGErrorResponse {
    private Error error;

    @Data
    public static class Error implements Serializable {
        private String exception;

        private String code;

        private String detail;

        private String message;
    }
}
