package com.reddot.ecrm_bulk.service.contract;

import com.reddot.ecrm_bulk.entity.annex.Annex;
import com.reddot.ecrm_bulk.enums.status.Status;
import com.reddot.ecrm_bulk.repository.contract.AnnexRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class AnnexServiceImpl implements AnnexService {
    private final AnnexRepository annexRepository;

    @Override
    public void updateAnnexAPIMessage(Annex annex, String message) {
        annex.setApiMessage(message);
        update(annex);
    }

    @Override
    public void updateAnnexStatus(Annex annex, Status status) {
        annex.setStatus(status.name());
        update(annex);
    }

    @Override
    public void updateAnnexRemarksAndSetStatusFailed(Annex annex, String remarks) {
        annex.setRemarks(remarks);
        annex.setStatus(Status.Failed.name());
        update(annex);
    }
    @Override
    public Annex update(Annex annex) {
        try {
            return annexRepository.update(annex);
        } catch (Exception e) {
            log.error("Annex update exception: {}", e.getMessage(), e.getCause());
            return null;
        }
    }

    @Override
    public List<Annex> findAllByContractId(Long contractId) {
        return annexRepository.findAllByContractId(contractId);
    }
}
