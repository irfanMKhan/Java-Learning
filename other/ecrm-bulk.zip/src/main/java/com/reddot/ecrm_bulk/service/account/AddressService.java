package com.reddot.ecrm_bulk.service.account;

import com.reddot.ecrm_bulk.entity.account_details.Address;

public interface AddressService {
    Address findById(Long contractId);
}
