package com.reddot.ecrm_bulk.entity.approval;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "approval_flow")
public class ApprovalFlowEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String description;
    private Boolean hasRule;
    private Long commonConfigUnitId;
    private String unit;
    private Long tenantId;

    @Column(name = "created_at")
    private Long createdAt;

    @Column(name = "created_at_dt")
    private Timestamp createdAtDt;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_by_username")
    private String createdUsername;

    @Column(name = "updated_at")
    private Long updatedAt;

    @Column(name = "updated_at_dt")
    private Timestamp updatedAtDt;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "updated_by_username")
    private String updatedUsername;
}
