package com.reddot.ecrm_bulk.scheduler;

import com.reddot.ecrm_bulk.service.report.DailyReportService;
import freemarker.template.TemplateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;


@Component
public class DailyReportScheduler {

    private final Logger logger = LoggerFactory.getLogger(getClass().getName());

    @Autowired
    DailyReportService dailyReportService;

    @Scheduled(cron = "0 0 9 * * *")
//    @Scheduled(fixedRate = 1000000000)
    public void dailySyncScheduler() throws TemplateException, IOException {
        logger.info("Inside dailySyncScheduler");
        //dailyReportService.PushDailySRReport();
    }
}
