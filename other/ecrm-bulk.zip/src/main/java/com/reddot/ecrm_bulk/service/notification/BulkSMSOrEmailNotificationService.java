package com.reddot.ecrm_bulk.service.notification;

import com.reddot.ecrm_bulk.api.gateway.SendSMSGateway;
import com.reddot.ecrm_bulk.api.utils.Utils;
import com.reddot.ecrm_bulk.entity.notification.NotificationEntity;
import com.reddot.ecrm_bulk.enums.notification.NotificationStatusEnum;
import com.reddot.ecrm_bulk.enums.notification.NotificationTypeEnum;
import com.reddot.ecrm_bulk.repository.notification.NotificationEntityRepository;
import com.reddot.ecrm_bulk.request.SendSMSRequest;
import com.reddot.ecrm_bulk.response.SendSMSResponse;
import com.reddot.ecrm_bulk.service.notification.email.EmailSenderService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class BulkSMSOrEmailNotificationService {
    private final Logger logger = LoggerFactory.getLogger(getClass().getName());
    private final NotificationEntityRepository notificationEntityRepository;
    private final EmailSenderService emailSenderService;
    private final SendSMSGateway sendSMSGateway;

    //if we need any custom query we will it this later
    @PersistenceContext
    private final EntityManager entityManager;

    public void processBulkSMSOrEmailNotificationService() throws MessagingException {
        try {
            List<NotificationEntity> notificationEntityList = fetchNotificationData();
            if (notificationEntityList == null) {
                return;
            }
            for (NotificationEntity notificationEntity : notificationEntityList) {
                //BackgroundJob.enqueue(() -> processForSendSMSOrEmail(notificationEntity));
                processForSendSMSOrEmail(notificationEntity);
            }
        } catch (Exception ex) {
            logger.info("BulkSMSOrEmailNotificationService: processBulkSMSOrEmailNotificationService Exception : " + ex.getMessage());
        }
    }

    public List<NotificationEntity> fetchNotificationData() {
        try {
            List<NotificationEntity> list = notificationEntityRepository.findAllNotificationTODODataAndEffectiveDate();
            return list;
        } catch (Exception ex) {
            logger.info("BulkSMSOrEmailNotificationService: fetchNotificationData Exception: " + ex.getMessage());
            return null;
        }

    }

    public Boolean sendEmail(NotificationEntity notificationEntity) throws MessagingException {
        try {
            Boolean isSent = emailSenderService.sendEmailForNotification(notificationEntity);
            return isSent;

            //return false;
        } catch (Exception ex) {
            logger.info("BulkSMSOrEmailNotificationService: sendEmail Exception: " + ex.getMessage());
            return false;
        }
    }

    public Boolean sendSMS(SendSMSRequest sendSMSRequest) {
        try {
            SendSMSResponse sendSMSResponse = sendSMSGateway.sendSMS(sendSMSRequest);
            return sendSMSResponse.getOutboundSMSMessageRequest().getDeliveryInfoList().getDeliveryInfo().get(0).getDeliveryStatus().equals("MessageWaiting");

        } catch (Exception ex) {
            logger.info("BulkSMSOrEmailNotificationService: sendSMS Exception: " + ex.getMessage());
            return false;
        }
    }

    public Boolean processForSendSMSOrEmail(NotificationEntity notificationEntity) throws MessagingException {
        Boolean isSuccess;
        try {
            if (notificationEntity.getNotificationType().equals(NotificationTypeEnum.Mail)) {
                isSuccess = sendEmail(notificationEntity);
            } else {
                SendSMSRequest sendSMSRequest = sendSMSRequestForAPI(notificationEntity);
                isSuccess = sendSMS(sendSMSRequest);
            }
            if (isSuccess) {
                notificationEntity.setNotificationStatus(NotificationStatusEnum.Sent);
            } else {
                notificationEntity.setNotificationStatus(NotificationStatusEnum.Failed);
            }
            notificationEntityRepository.save(notificationEntity);
            return true;
        } catch (Exception ex) {
            logger.info("BulkSMSOrEmailNotificationService: sendSMSOrEmail  Exception: " + ex.getMessage());
            return false;
        }
    }

    public SendSMSRequest sendSMSRequestForAPI(NotificationEntity notificationEntity) {
        SendSMSRequest sendSMSRequest = new SendSMSRequest();
        SendSMSRequest.OutboundSMSMessageRequest outboundSMSMessageRequest = new SendSMSRequest.OutboundSMSMessageRequest();
        outboundSMSMessageRequest.setSenderAddress("tel:888"); // Replace with the actual sender address
        outboundSMSMessageRequest.setSenderName("Smart"); // Replace with the sender's name

        List<String> recipientAddresses = new ArrayList<>();
        recipientAddresses.add("tel:+855" + "10202606");
        //recipientAddresses.add("tel:+855"+notificationEntity.getRecipientNumber());// Replace with recipient addresses
        //recipientAddresses.add("987654322");
        outboundSMSMessageRequest.setAddress(recipientAddresses);

        SendSMSRequest.OutboundSMSMessageRequest.ReceiptRequest receiptRequest = new SendSMSRequest.OutboundSMSMessageRequest.ReceiptRequest();
        receiptRequest.setCallbackData(""); // Replace with callback data
        receiptRequest.setNotifyURL(""); // Replace with notify URL
        outboundSMSMessageRequest.setReceiptRequest(receiptRequest);

        SendSMSRequest.OutboundSMSMessageRequest.OutboundSMSTextMessage outboundSMSTextMessage = new SendSMSRequest.OutboundSMSMessageRequest.OutboundSMSTextMessage();
        outboundSMSTextMessage.setMessage(notificationEntity.getNotificationBody()); // Replace with your SMS message
        outboundSMSMessageRequest.setOutboundSMSTextMessage(outboundSMSTextMessage);

        outboundSMSMessageRequest.setClientCorrelator(Utils.getTransactionId()); // Replace with the client correlator

        sendSMSRequest.setOutboundSMSMessageRequest(outboundSMSMessageRequest);

        return sendSMSRequest;
    }

}
