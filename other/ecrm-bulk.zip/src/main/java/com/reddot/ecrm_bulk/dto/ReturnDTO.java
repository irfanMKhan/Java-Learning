package com.reddot.ecrm_bulk.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ReturnDTO {
    private Boolean isMasterSuccess;
    private Boolean returnValue;
}
