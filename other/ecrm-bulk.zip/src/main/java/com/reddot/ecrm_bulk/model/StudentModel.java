package com.reddot.ecrm_bulk.model;

import java.sql.Timestamp;

public class StudentModel {
private Long ID;
private Long INSTITUTE_ID;
private String INSTITUTE_NAME;
private Long ACADEMIC_YEAR_ID;
private String ACADEMIC_YEAR_NAME;
private Long CLASS_ID;
private String CLASS_NAME ;
private Long PREVIOUS_CLASS_ID;
private String PREVIOUS_CLASS_NAME ;
private Long REGISTRATION_ID;
private Long SECTION_ID ;
private String SECTION_NAME ;
private Long SHIFT_ID;
private String SHIFT_NAME ;
private Long HOSTEL_ID ;
private String HOSTEL_NAME;
private Long SESSION_ID;
private String SESSION_NAME;
private Long GROUP_ID ;
private String GROUP_NAME;
private String NAME;
private Timestamp DATE_OF_BIRTH ;
private String ADDRESS;
private String EMAIL;
private String FATHER_NAME ;
private String MOTHER_NAME;
private String RELIGION ;
private String ROLL_NO;
private String GENDER;
private String GUARDIAN_NAME;
private String SCHOLARSHIP ;
private Integer IS_NEWLY_ADMITTED ;
private String LAST_IMPORTED_EXCEPTION ;
private String MOBILE_NUMBER ;
private Timestamp REGISTRATION_DATE;
private String STUDENT_TYPE ;
private Integer ACTIVE;
private Long CREATED_AT;
private Timestamp CREATED_AT_DT;
private Long CREATED_BY ;
private String CREATED_BY_USERNAME ;
private Long UPDATED_AT;
private Timestamp UPDATED_AT_DT;
private Long UPDATED_BY ;
private String UPDATED_BY_USERNAME ;

    public Long getID() {
        return ID;
    }

    public void setID(Long ID) {
        this.ID = ID;
    }

    public Long getINSTITUTE_ID() {
        return INSTITUTE_ID;
    }

    public void setINSTITUTE_ID(Long INSTITUTE_ID) {
        this.INSTITUTE_ID = INSTITUTE_ID;
    }

    public String getINSTITUTE_NAME() {
        return INSTITUTE_NAME;
    }

    public void setINSTITUTE_NAME(String INSTITUTE_NAME) {
        this.INSTITUTE_NAME = INSTITUTE_NAME;
    }

    public Long getACADEMIC_YEAR_ID() {
        return ACADEMIC_YEAR_ID;
    }

    public void setACADEMIC_YEAR_ID(Long ACADEMIC_YEAR_ID) {
        this.ACADEMIC_YEAR_ID = ACADEMIC_YEAR_ID;
    }

    public String getACADEMIC_YEAR_NAME() {
        return ACADEMIC_YEAR_NAME;
    }

    public void setACADEMIC_YEAR_NAME(String ACADEMIC_YEAR_NAME) {
        this.ACADEMIC_YEAR_NAME = ACADEMIC_YEAR_NAME;
    }

    public Long getCLASS_ID() {
        return CLASS_ID;
    }

    public void setCLASS_ID(Long CLASS_ID) {
        this.CLASS_ID = CLASS_ID;
    }

    public String getCLASS_NAME() {
        return CLASS_NAME;
    }

    public void setCLASS_NAME(String CLASS_NAME) {
        this.CLASS_NAME = CLASS_NAME;
    }

    public Long getPREVIOUS_CLASS_ID() {
        return PREVIOUS_CLASS_ID;
    }

    public void setPREVIOUS_CLASS_ID(Long PREVIOUS_CLASS_ID) {
        this.PREVIOUS_CLASS_ID = PREVIOUS_CLASS_ID;
    }

    public String getPREVIOUS_CLASS_NAME() {
        return PREVIOUS_CLASS_NAME;
    }

    public void setPREVIOUS_CLASS_NAME(String PREVIOUS_CLASS_NAME) {
        this.PREVIOUS_CLASS_NAME = PREVIOUS_CLASS_NAME;
    }

    public Long getREGISTRATION_ID() {
        return REGISTRATION_ID;
    }

    public void setREGISTRATION_ID(Long REGISTRATION_ID) {
        this.REGISTRATION_ID = REGISTRATION_ID;
    }

    public Long getSECTION_ID() {
        return SECTION_ID;
    }

    public void setSECTION_ID(Long SECTION_ID) {
        this.SECTION_ID = SECTION_ID;
    }

    public String getSECTION_NAME() {
        return SECTION_NAME;
    }

    public void setSECTION_NAME(String SECTION_NAME) {
        this.SECTION_NAME = SECTION_NAME;
    }

    public Long getSHIFT_ID() {
        return SHIFT_ID;
    }

    public void setSHIFT_ID(Long SHIFT_ID) {
        this.SHIFT_ID = SHIFT_ID;
    }

    public String getSHIFT_NAME() {
        return SHIFT_NAME;
    }

    public void setSHIFT_NAME(String SHIFT_NAME) {
        this.SHIFT_NAME = SHIFT_NAME;
    }

    public Long getHOSTEL_ID() {
        return HOSTEL_ID;
    }

    public void setHOSTEL_ID(Long HOSTEL_ID) {
        this.HOSTEL_ID = HOSTEL_ID;
    }

    public String getHOSTEL_NAME() {
        return HOSTEL_NAME;
    }

    public void setHOSTEL_NAME(String HOSTEL_NAME) {
        this.HOSTEL_NAME = HOSTEL_NAME;
    }

    public Long getSESSION_ID() {
        return SESSION_ID;
    }

    public void setSESSION_ID(Long SESSION_ID) {
        this.SESSION_ID = SESSION_ID;
    }

    public String getSESSION_NAME() {
        return SESSION_NAME;
    }

    public void setSESSION_NAME(String SESSION_NAME) {
        this.SESSION_NAME = SESSION_NAME;
    }

    public Long getGROUP_ID() {
        return GROUP_ID;
    }

    public void setGROUP_ID(Long GROUP_ID) {
        this.GROUP_ID = GROUP_ID;
    }

    public String getGROUP_NAME() {
        return GROUP_NAME;
    }

    public void setGROUP_NAME(String GROUP_NAME) {
        this.GROUP_NAME = GROUP_NAME;
    }

    public String getNAME() {
        return NAME;
    }

    public void setNAME(String NAME) {
        this.NAME = NAME;
    }

    public Timestamp getDATE_OF_BIRTH() {
        return DATE_OF_BIRTH;
    }

    public void setDATE_OF_BIRTH(Timestamp DATE_OF_BIRTH) {
        this.DATE_OF_BIRTH = DATE_OF_BIRTH;
    }

    public String getADDRESS() {
        return ADDRESS;
    }

    public void setADDRESS(String ADDRESS) {
        this.ADDRESS = ADDRESS;
    }

    public String getEMAIL() {
        return EMAIL;
    }

    public void setEMAIL(String EMAIL) {
        this.EMAIL = EMAIL;
    }

    public String getFATHER_NAME() {
        return FATHER_NAME;
    }

    public void setFATHER_NAME(String FATHER_NAME) {
        this.FATHER_NAME = FATHER_NAME;
    }

    public String getMOTHER_NAME() {
        return MOTHER_NAME;
    }

    public void setMOTHER_NAME(String MOTHER_NAME) {
        this.MOTHER_NAME = MOTHER_NAME;
    }

    public String getRELIGION() {
        return RELIGION;
    }

    public void setRELIGION(String RELIGION) {
        this.RELIGION = RELIGION;
    }

    public String getROLL_NO() {
        return ROLL_NO;
    }

    public void setROLL_NO(String ROLL_NO) {
        this.ROLL_NO = ROLL_NO;
    }

    public String getGENDER() {
        return GENDER;
    }

    public void setGENDER(String GENDER) {
        this.GENDER = GENDER;
    }

    public String getGUARDIAN_NAME() {
        return GUARDIAN_NAME;
    }

    public void setGUARDIAN_NAME(String GUARDIAN_NAME) {
        this.GUARDIAN_NAME = GUARDIAN_NAME;
    }

    public String getSCHOLARSHIP() {
        return SCHOLARSHIP;
    }

    public void setSCHOLARSHIP(String SCHOLARSHIP) {
        this.SCHOLARSHIP = SCHOLARSHIP;
    }

    public Integer getIS_NEWLY_ADMITTED() {
        return IS_NEWLY_ADMITTED;
    }

    public void setIS_NEWLY_ADMITTED(Integer IS_NEWLY_ADMITTED) {
        this.IS_NEWLY_ADMITTED = IS_NEWLY_ADMITTED;
    }

    public String getLAST_IMPORTED_EXCEPTION() {
        return LAST_IMPORTED_EXCEPTION;
    }

    public void setLAST_IMPORTED_EXCEPTION(String LAST_IMPORTED_EXCEPTION) {
        this.LAST_IMPORTED_EXCEPTION = LAST_IMPORTED_EXCEPTION;
    }

    public String getMOBILE_NUMBER() {
        return MOBILE_NUMBER;
    }

    public void setMOBILE_NUMBER(String MOBILE_NUMBER) {
        this.MOBILE_NUMBER = MOBILE_NUMBER;
    }

    public Timestamp getREGISTRATION_DATE() {
        return REGISTRATION_DATE;
    }

    public void setREGISTRATION_DATE(Timestamp REGISTRATION_DATE) {
        this.REGISTRATION_DATE = REGISTRATION_DATE;
    }

    public String getSTUDENT_TYPE() {
        return STUDENT_TYPE;
    }

    public void setSTUDENT_TYPE(String STUDENT_TYPE) {
        this.STUDENT_TYPE = STUDENT_TYPE;
    }

    public Integer getACTIVE() {
        return ACTIVE;
    }

    public void setACTIVE(Integer ACTIVE) {
        this.ACTIVE = ACTIVE;
    }

    public Long getCREATED_AT() {
        return CREATED_AT;
    }

    public void setCREATED_AT(Long CREATED_AT) {
        this.CREATED_AT = CREATED_AT;
    }

    public Timestamp getCREATED_AT_DT() {
        return CREATED_AT_DT;
    }

    public void setCREATED_AT_DT(Timestamp CREATED_AT_DT) {
        this.CREATED_AT_DT = CREATED_AT_DT;
    }

    public Long getCREATED_BY() {
        return CREATED_BY;
    }

    public void setCREATED_BY(Long CREATED_BY) {
        this.CREATED_BY = CREATED_BY;
    }

    public String getCREATED_BY_USERNAME() {
        return CREATED_BY_USERNAME;
    }

    public void setCREATED_BY_USERNAME(String CREATED_BY_USERNAME) {
        this.CREATED_BY_USERNAME = CREATED_BY_USERNAME;
    }

    public Long getUPDATED_AT() {
        return UPDATED_AT;
    }

    public void setUPDATED_AT(Long UPDATED_AT) {
        this.UPDATED_AT = UPDATED_AT;
    }

    public Timestamp getUPDATED_AT_DT() {
        return UPDATED_AT_DT;
    }

    public void setUPDATED_AT_DT(Timestamp UPDATED_AT_DT) {
        this.UPDATED_AT_DT = UPDATED_AT_DT;
    }

    public Long getUPDATED_BY() {
        return UPDATED_BY;
    }

    public void setUPDATED_BY(Long UPDATED_BY) {
        this.UPDATED_BY = UPDATED_BY;
    }

    public String getUPDATED_BY_USERNAME() {
        return UPDATED_BY_USERNAME;
    }

    public void setUPDATED_BY_USERNAME(String UPDATED_BY_USERNAME) {
        this.UPDATED_BY_USERNAME = UPDATED_BY_USERNAME;
    }

    @Override
    public String toString() {
        return "StudentModel{" +
                "ID=" + ID +
                ", INSTITUTE_ID=" + INSTITUTE_ID +
                ", INSTITUTE_NAME='" + INSTITUTE_NAME + '\'' +
                ", ACADEMIC_YEAR_ID=" + ACADEMIC_YEAR_ID +
                ", ACADEMIC_YEAR_NAME='" + ACADEMIC_YEAR_NAME + '\'' +
                ", CLASS_ID=" + CLASS_ID +
                ", CLASS_NAME='" + CLASS_NAME + '\'' +
                ", PREVIOUS_CLASS_ID=" + PREVIOUS_CLASS_ID +
                ", PREVIOUS_CLASS_NAME='" + PREVIOUS_CLASS_NAME + '\'' +
                ", REGISTRATION_ID=" + REGISTRATION_ID +
                ", SECTION_ID=" + SECTION_ID +
                ", SECTION_NAME='" + SECTION_NAME + '\'' +
                ", SHIFT_ID=" + SHIFT_ID +
                ", SHIFT_NAME='" + SHIFT_NAME + '\'' +
                ", HOSTEL_ID=" + HOSTEL_ID +
                ", HOSTEL_NAME='" + HOSTEL_NAME + '\'' +
                ", SESSION_ID=" + SESSION_ID +
                ", SESSION_NAME='" + SESSION_NAME + '\'' +
                ", GROUP_ID=" + GROUP_ID +
                ", GROUP_NAME='" + GROUP_NAME + '\'' +
                ", NAME='" + NAME + '\'' +
                ", DATE_OF_BIRTH=" + DATE_OF_BIRTH +
                ", ADDRESS='" + ADDRESS + '\'' +
                ", EMAIL='" + EMAIL + '\'' +
                ", FATHER_NAME='" + FATHER_NAME + '\'' +
                ", MOTHER_NAME='" + MOTHER_NAME + '\'' +
                ", RELIGION='" + RELIGION + '\'' +
                ", ROLL_NO='" + ROLL_NO + '\'' +
                ", GENDER='" + GENDER + '\'' +
                ", GUARDIAN_NAME='" + GUARDIAN_NAME + '\'' +
                ", SCHOLARSHIP='" + SCHOLARSHIP + '\'' +
                ", IS_NEWLY_ADMITTED=" + IS_NEWLY_ADMITTED +
                ", LAST_IMPORTED_EXCEPTION='" + LAST_IMPORTED_EXCEPTION + '\'' +
                ", MOBILE_NUMBER='" + MOBILE_NUMBER + '\'' +
                ", REGISTRATION_DATE=" + REGISTRATION_DATE +
                ", STUDENT_TYPE='" + STUDENT_TYPE + '\'' +
                ", ACTIVE=" + ACTIVE +
                ", CREATED_AT=" + CREATED_AT +
                ", CREATED_AT_DT=" + CREATED_AT_DT +
                ", CREATED_BY=" + CREATED_BY +
                ", CREATED_BY_USERNAME='" + CREATED_BY_USERNAME + '\'' +
                ", UPDATED_AT=" + UPDATED_AT +
                ", UPDATED_AT_DT=" + UPDATED_AT_DT +
                ", UPDATED_BY=" + UPDATED_BY +
                ", UPDATED_BY_USERNAME='" + UPDATED_BY_USERNAME + '\'' +
                '}';
    }
}
