package com.reddot.ecrm_bulk.entity.annex;

import com.reddot.ecrm_bulk.entity.AbstractEntity;
import lombok.Data;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Data
@Table(name = "TBL_ECRM_CONTRACT_Product_Annex")
public class Annex {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long contractId;


    @Column(name = "product_id")
    private String productId;

    @Column(name = "product_name")
    private String productName;

    @Column(name = "MSISDN")
    private String msisdn;
    private String msisdnCategory;
    @Column(name = "ICCID")
    private String iccid;

    private Long planId;
    @Column(name = "PLAN")
    private String plan;
    private String ngbssPlanOfferingId;
    @Column(name = "DEFAULT_CREDIT")
    private Double defaultCredit;

    @Column(name = "RESERVE_CREDIT")
    private Double reserveCredit;

    @Column(name = "TOTAL_CREDIT")
    private Double totalCredit;

    @Column(name = "MONTHLY_FEE")
    private Double monthlyFee;

    @Column(name = "MAXIMUM_MONTHLY_FEE")
    private Double maximumMonthlyFee;

    @Column(name = "CONTRACT_DURATION")
    private String contractDuration;

    @Column(name = "add_ons")
    private String addOns;
    private String ngbssAddOnsOfferingId;

    @Column(name = "EFFECTIVE_DATE")
    private String effectiveDate;

    @Column(name = "contract_maturity_date")
    private String contractMaturityDate;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "employee_name")
    private String employeeName;

    @Column(name = "branch")
    private String branch;

    @Column(name = "device")
    private String device;
    private String deviceName;

    @Column(name = "imei")
    private String imei;

    @Column(name = "upfront_payment")
    private String upfrontPayment;

    @Column(name = "payment")
    private String payment;

    @Column(name = "status_of_payment")
    private String statusOfPayment;

    @Column(name = "location_address")
    private String locationAddress;

    @Column(name = "priority")
    private String priority;

    @Column(name = "number_of_onu")
    private String numberOfOnu;

    @Column(name = "testing_period")
    private String testingPeriod;

    @Column(name = "sla")
    private String sla;

    @Column(name = "discount")
    private String discount;

    @Column(name = "deposit")
    private String deposit;

    @Column(name = "setup_fee")
    private String setupFee;

    @Column(name = "last_mile")
    private String lastMile;

    @Column(name = "remarks")
    private String remarks;

    @Column(name = "CONTRACT_NUMBER")
    private String contractNumber;

    @Column(name = "OPPORTUNITY_NUMBER")
    private String opportunityNumber;


    @Column(name = "PRE_TO_POST")
    private Boolean preToPost;

    private Double remainingCredit;

    private String serviceTypeName;
    private Long serviceTypeId;

    private Boolean isCRContract;

    private String financialType;
    private String financialTypeText;
    private Double financialAmount;
    private Integer ptpPaymentProcessDays;
    private LocalDate ptpPaymentProcessDate;
    private String upfrontPaymentAfterFA;
    private String adjustmentSerialNo;
    private String primaryOfferingAgreementId;
    private String status;
    @Column(name = "API_STATUS")
    private String apiStatus;
    @Column(name = "API_MESSAGE")
    private String apiMessage;
}
