package com.reddot.ecrm_bulk.service.cug;

import com.reddot.ecrm_bulk.entity.cug.CUG;

public interface CUGService {
    CUG findByCugAccountId(Long cugAccountId);
}
