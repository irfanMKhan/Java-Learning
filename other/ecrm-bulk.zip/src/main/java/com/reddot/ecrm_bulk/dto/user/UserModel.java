package com.reddot.ecrm_bulk.dto.user;

import java.sql.Date;
import java.util.List;

public class UserModel {
    private Long id;
    private String name;
    private String login_name;
    private String email;
    private Long user_group_id;
    private String user_group_name;
    private Long user_type_id;
    private String user_type;
    private Integer active;
    private Long created_at;
    private Long created_by;
    private String created_by_username;
    private Long updated_at;
    private Long updated_by;
    private String updated_by_username;
    private Long primary_resp_id;
    private String primary_resp_name;
    private Long position_id;
    private String work_phone;
    private String remarks;
    private Date created_at_dt;
    private Date updated_at_dt;
    private Integer has_eapproval;
    private String eapproval_id;
    private Date expired_dt;
    private Integer is_active_user;
    private String ad_type;
    private Integer can_assign_activity;
    private Integer final_okay;
    private String upazila_ps_id;
    private String district_id;
    private String division_id;
    private String division_name;
    private String district_name;
    private String upazila_ps_name;
    private String user_password;
    private String token;
    private Integer failed_attempt;
    private Integer is_blocked;
    private Date last_logged_in;

    private String cust_manager_seq;
    private String operator_id;
    private String department_id;
    private String company_id;

    public Long getTenant_id() {
        return tenant_id;
    }

    public void setTenant_id(Long tenant_id) {
        this.tenant_id = tenant_id;
    }

    private Long tenant_id;
  /*  public List<UserResponsibilityMapModel> getMapList() {
        return mapList;
    }

    public void setMapList(List<UserResponsibilityMapModel> mapList) {
        this.mapList = mapList;
    }

    private List<UserRoleMapModel> userRoleMapList;

    public List<UserRoleMapModel> getUserRoleMapList() {
        return userRoleMapList;
    }

    public void setUserRoleMapList(List<UserRoleMapModel> userRoleMapList) {
        this.userRoleMapList = userRoleMapList;
    }

    private List<UserResponsibilityMapModel> mapList;*/

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLogin_name() {
        return login_name;
    }

    public void setLogin_name(String login_name) {
        this.login_name = login_name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Long getUser_group_id() {
        return user_group_id;
    }

    public void setUser_group_id(Long user_group_id) {
        this.user_group_id = user_group_id;
    }

    public String getUser_group_name() {
        return user_group_name;
    }

    public void setUser_group_name(String user_group_name) {
        this.user_group_name = user_group_name;
    }

    public Integer getActive() {
        return active;
    }

    public void setActive(Integer active) {
        this.active = active;
    }

    public Long getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Long created_at) {
        this.created_at = created_at;
    }

    public Long getCreated_by() {
        return created_by;
    }

    public void setCreated_by(Long created_by) {
        this.created_by = created_by;
    }

    public String getCreated_by_username() {
        return created_by_username;
    }

    public void setCreated_by_username(String created_by_username) {
        this.created_by_username = created_by_username;
    }

    public Long getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(Long updated_at) {
        this.updated_at = updated_at;
    }

    public Long getUpdated_by() {
        return updated_by;
    }

    public void setUpdated_by(Long updated_by) {
        this.updated_by = updated_by;
    }

    public String getUpdated_by_username() {
        return updated_by_username;
    }

    public void setUpdated_by_username(String updated_by_username) {
        this.updated_by_username = updated_by_username;
    }

    public Long getPrimary_resp_id() {
        return primary_resp_id;
    }

    public void setPrimary_resp_id(Long primary_resp_id) {
        this.primary_resp_id = primary_resp_id;
    }

    public String getPrimary_resp_name() {
        return primary_resp_name;
    }

    public void setPrimary_resp_name(String primary_resp_name) {
        this.primary_resp_name = primary_resp_name;
    }

    public Long getPosition_id() {
        return position_id;
    }

    public void setPosition_id(Long position_id) {
        this.position_id = position_id;
    }

    public String getWork_phone() {
        return work_phone;
    }

    public void setWork_phone(String work_phone) {
        this.work_phone = work_phone;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Date getCreated_at_dt() {
        return created_at_dt;
    }

    public void setCreated_at_dt(Date created_at_dt) {
        this.created_at_dt = created_at_dt;
    }

    public Date getUpdated_at_dt() {
        return updated_at_dt;
    }

    public void setUpdated_at_dt(Date updated_at_dt) {
        this.updated_at_dt = updated_at_dt;
    }

    public Integer getHas_eapproval() {
        return has_eapproval;
    }

    public void setHas_eapproval(Integer has_eapproval) {
        this.has_eapproval = has_eapproval;
    }

    public String getEapproval_id() {
        return eapproval_id;
    }

    public void setEapproval_id(String eapproval_id) {
        this.eapproval_id = eapproval_id;
    }

    public Date getExpired_dt() {
        return expired_dt;
    }

    public void setExpired_dt(Date expired_dt) {
        this.expired_dt = expired_dt;
    }

    public Integer getIs_active_user() {
        return is_active_user;
    }

    public void setIs_active_user(Integer is_active_user) {
        this.is_active_user = is_active_user;
    }

    public String getAd_type() {
        return ad_type;
    }

    public void setAd_type(String ad_type) {
        this.ad_type = ad_type;
    }

    public Integer getCan_assign_activity() {
        return can_assign_activity;
    }

    public void setCan_assign_activity(Integer can_assign_activity) {
        this.can_assign_activity = can_assign_activity;
    }

    public Integer getFinal_okay() {
        return final_okay;
    }

    public void setFinal_okay(Integer final_okay) {
        this.final_okay = final_okay;
    }

    public String getUpazila_ps_id() {
        return upazila_ps_id;
    }

    public void setUpazila_ps_id(String upazila_ps_id) {
        this.upazila_ps_id = upazila_ps_id;
    }

    public String getDistrict_id() {
        return district_id;
    }

    public void setDistrict_id(String district_id) {
        this.district_id = district_id;
    }

    public String getDivision_id() {
        return division_id;
    }

    public void setDivision_id(String division_id) {
        this.division_id = division_id;
    }

    public String getDivision_name() {
        return division_name;
    }

    public void setDivision_name(String division_name) {
        this.division_name = division_name;
    }

    public String getDistrict_name() {
        return district_name;
    }

    public void setDistrict_name(String district_name) {
        this.district_name = district_name;
    }

    public String getUpazila_ps_name() {
        return upazila_ps_name;
    }

    public void setUpazila_ps_name(String upazila_ps_name) {
        this.upazila_ps_name = upazila_ps_name;
    }

    public String getUser_password() {
        return user_password;
    }

    public void setUser_password(String user_password) {
        this.user_password = user_password;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Integer getFailed_attempt() {
        return failed_attempt;
    }

    public void setFailed_attempt(Integer failed_attempt) {
        this.failed_attempt = failed_attempt;
    }

    public Integer getIs_blocked() {
        return is_blocked;
    }

    public void setIs_blocked(Integer is_blocked) {
        this.is_blocked = is_blocked;
    }

    public Date getLast_logged_in() {
        return last_logged_in;
    }

    public void setLast_logged_in(Date last_logged_in) {
        this.last_logged_in = last_logged_in;
    }

    public Long getUser_type_id() {
        return user_type_id;
    }

    public void setUser_type_id(Long user_type_id) {
        this.user_type_id = user_type_id;
    }

    public String getUser_type() {
        return user_type;
    }

    public void setUser_type_name(String user_type) {
        this.user_type = user_type;
    }

    public String getCust_manager_seq() {
        return cust_manager_seq;
    }

    public void setCust_manager_seq(String cust_manager_seq) {
        this.cust_manager_seq = cust_manager_seq;
    }

    public String getOperator_id() {
        return operator_id;
    }

    public void setOperator_id(String operator_id) {
        this.operator_id = operator_id;
    }

    public String getDepartment_id() {
        return department_id;
    }

    public void setDepartment_id(String department_id) {
        this.department_id = department_id;
    }

    public String getCompany_id() {
        return company_id;
    }

    public void setCompany_id(String company_id) {
        this.company_id = company_id;
    }

    public UserModel() {
    }
    public UserModel(Long id, String name, String login_name, String email, Long user_group_id, String user_group_name, Long user_type_id, String user_type, Integer active, Long created_at, Long created_by, String created_by_username, Long updated_at, Long updated_by, String updated_by_username, Long primary_resp_id, String primary_resp_name, Long position_id, String work_phone, String remarks, Date created_at_dt, Date updated_at_dt, Integer has_eapproval, String eapproval_id, Date expired_dt, Integer is_active_user, String ad_type, Integer can_assign_activity, Integer final_okay, String upazila_ps_id, String district_id, String division_id, String division_name, String district_name, String upazila_ps_name, String user_password, String token, Integer failed_attempt, Integer is_blocked, Date last_logged_in, String cust_manager_seq, String operator_id, String department_id) {
        this.id = id;
        this.name = name;
        this.login_name = login_name;
        this.email = email;
        this.user_group_id = user_group_id;
        this.user_group_name = user_group_name;
        this.user_type_id = user_type_id;
        this.user_type = user_type;
        this.active = active;
        this.created_at = created_at;
        this.created_by = created_by;
        this.created_by_username = created_by_username;
        this.updated_at = updated_at;
        this.updated_by = updated_by;
        this.updated_by_username = updated_by_username;
        this.primary_resp_id = primary_resp_id;
        this.primary_resp_name = primary_resp_name;
        this.position_id = position_id;
        this.work_phone = work_phone;
        this.remarks = remarks;
        this.created_at_dt = created_at_dt;
        this.updated_at_dt = updated_at_dt;
        this.has_eapproval = has_eapproval;
        this.eapproval_id = eapproval_id;
        this.expired_dt = expired_dt;
        this.is_active_user = is_active_user;
        this.ad_type = ad_type;
        this.can_assign_activity = can_assign_activity;
        this.final_okay = final_okay;
        this.upazila_ps_id = upazila_ps_id;
        this.district_id = district_id;
        this.division_id = division_id;
        this.division_name = division_name;
        this.district_name = district_name;
        this.upazila_ps_name = upazila_ps_name;
        this.user_password = user_password;
        this.token = token;
        this.failed_attempt = failed_attempt;
        this.is_blocked = is_blocked;
        this.last_logged_in = last_logged_in;
        this.cust_manager_seq = cust_manager_seq;
        this.operator_id = operator_id;
        this.department_id = department_id;
    }

    @Override
    public String toString() {
        return "UserModel{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", login_name='" + login_name + '\'' +
                ", email='" + email + '\'' +
                ", user_group_id=" + user_group_id +
                ", user_group_name='" + user_group_name + '\'' +
                ", user_type_id=" + user_type_id +
                ", user_type='" + user_type + '\'' +
                ", active=" + active +
                ", created_at=" + created_at +
                ", created_by=" + created_by +
                ", created_by_username='" + created_by_username + '\'' +
                ", updated_at=" + updated_at +
                ", updated_by=" + updated_by +
                ", updated_by_username='" + updated_by_username + '\'' +
                ", primary_resp_id=" + primary_resp_id +
                ", primary_resp_name='" + primary_resp_name + '\'' +
                ", position_id=" + position_id +
                ", work_phone='" + work_phone + '\'' +
                ", remarks='" + remarks + '\'' +
                ", created_at_dt=" + created_at_dt +
                ", updated_at_dt=" + updated_at_dt +
                ", has_eapproval=" + has_eapproval +
                ", eapproval_id='" + eapproval_id + '\'' +
                ", expired_dt=" + expired_dt +
                ", is_active_user=" + is_active_user +
                ", ad_type='" + ad_type + '\'' +
                ", can_assign_activity=" + can_assign_activity +
                ", final_okay=" + final_okay +
                ", upazila_ps_id='" + upazila_ps_id + '\'' +
                ", district_id='" + district_id + '\'' +
                ", division_id='" + division_id + '\'' +
                ", division_name='" + division_name + '\'' +
                ", district_name='" + district_name + '\'' +
                ", upazila_ps_name='" + upazila_ps_name + '\'' +
                ", user_password='" + user_password + '\'' +
                ", token='" + token + '\'' +
                ", failed_attempt=" + failed_attempt +
                ", is_blocked=" + is_blocked +
                ", last_logged_in=" + last_logged_in +
                ", cust_manager_seq='" + cust_manager_seq + '\'' +
                ", operator_id='" + operator_id + '\'' +
                ", department_id='" + department_id + '\'' +
                '}';
    }
}

