package com.reddot.ecrm_bulk.repository.swap;

import com.reddot.ecrm_bulk.entity.swapsim.SwapSim;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface SwapSimRepository extends JpaRepository<SwapSim, Long> {
    List<SwapSim> findAllByCompanyId(Long companyId);

    Page<SwapSim> findAllByCompanyId(Long companyId, Pageable pageable);

    List<SwapSim> findAllByNewMsisdnOrDate(String newMsisdn, LocalDate date);

    List<SwapSim> findAllByOldMsisdn(String oldMsisdn);
}