package com.reddot.ecrm_bulk.service.testing;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.reddot.ecrm_bulk.entity.notification.NotificationEntity;
import com.reddot.ecrm_bulk.repository.notification.NotificationEntityRepository;
import com.reddot.ecrm_bulk.service.notification.email.EmailSenderService;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;

import javax.mail.MessagingException;
import java.util.Optional;


@RequiredArgsConstructor
public class TestingService {
    public final EmailSenderService emailSenderService;
    public final NotificationEntityRepository notificationRepo;

    @Scheduled(cron = "0 3 * * * *") //every 3 min
    public String test2() throws MessagingException, JsonProcessingException {
        Optional<NotificationEntity> notificationEntity = notificationRepo.getById(277L);
        if (notificationEntity.isPresent()) {
            return emailSenderService.sendEmailForNotification(notificationEntity.get()).toString();
        }

        return "OK";
    }
}
