package com.reddot.ecrm_bulk.entity.notification;

import com.reddot.ecrm_bulk.enums.notification.NotificationStatusEnum;
import com.reddot.ecrm_bulk.enums.notification.NotificationTypeEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "notification_details")
public class NotificationEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Enumerated(EnumType.STRING)
    private NotificationTypeEnum notificationType;
    @Enumerated(EnumType.STRING)
    private NotificationStatusEnum notificationStatus;
    private Timestamp notificationTimeDt;
    private Long notificationTime;
    private Long recipientId;
    private String recipientName;

    @Column(columnDefinition = "text")
    private String recipientEmailAddress;

    @Column(columnDefinition = "text")
    private String recipientCCEmailList;

    @Column(columnDefinition = "text")
    private String notificationTitle;

    @Column(columnDefinition = "text")
    private String notificationBody;
    private String moduleName;
    private String featureName;
    private String transactionNo;

    // private String responseMsg;
    private String recipientNumber;

    @Column(columnDefinition = "text")
    private String mailParameters;
    private LocalDate effectiveDate;

    @Column(columnDefinition = "text")
    private String failedReasonMsg;


    @Column(name = "created_at")
    private Long createdAt;

    @Column(name = "created_at_dt")
    private Timestamp createdAtDt;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_by_username")
    private String createdUsername;
}
