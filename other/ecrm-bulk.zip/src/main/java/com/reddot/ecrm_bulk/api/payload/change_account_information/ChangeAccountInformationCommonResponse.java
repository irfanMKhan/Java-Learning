package com.reddot.ecrm_bulk.api.payload.change_account_information;

import lombok.Data;

@Data
public class ChangeAccountInformationCommonResponse {
    private Boolean isSuccess;
    private String code;
    private String message;
}
