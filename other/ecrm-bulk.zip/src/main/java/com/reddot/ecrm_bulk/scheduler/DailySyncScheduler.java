package com.reddot.ecrm_bulk.scheduler;

import com.reddot.ecrm_bulk.service.bulk_import.change_branch.ChangeBranchImportService;
import com.reddot.ecrm_bulk.service.change_branch.CRChangeBranchService;
import com.reddot.ecrm_bulk.service.change_branch.ChangeBranchService;
import com.reddot.ecrm_bulk.service.number_activation.NumberActivationService;
import com.reddot.ecrm_bulk.service.report.ReportService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jobrunr.scheduling.JobScheduler;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@RequiredArgsConstructor
public class DailySyncScheduler {
    private final JobScheduler jobScheduler;
    private final NumberActivationService numberActivationService;
    private final ChangeBranchService changeBranchService;
    private final ChangeBranchImportService changeBranchImportService;
    private final CRChangeBranchService crChangeBranchService;
    private final ReportService reportService;

    @Scheduled(fixedRate = 60000)
    public void dailySyncScheduler() {
        jobScheduler.enqueue(numberActivationService::proceedExecution);
//        jobScheduler.enqueue(changeBranchService::proceedExecution);
//        jobScheduler.enqueue(changeBranchImportService::proceedExecution);
        jobScheduler.enqueue(crChangeBranchService::proceedExecution);
    }

//    @Scheduled(fixedRate = 15000)
    @Scheduled(cron = "0 0 9 * * *") // 9am everyday
    public void minuteSyncScheduler(){
        reportService.followUpLeadReportProcess();
    }
}
