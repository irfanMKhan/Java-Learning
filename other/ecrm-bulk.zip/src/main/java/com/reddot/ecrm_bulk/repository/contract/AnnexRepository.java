package com.reddot.ecrm_bulk.repository.contract;

import com.reddot.ecrm_bulk.entity.annex.Annex;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import java.util.List;

@Repository
public class AnnexRepository {
    @PersistenceContext
    private EntityManager entityManager;

    public List<Annex> findAllByContractId(Long contractId) {
        TypedQuery<Annex> query = entityManager.createQuery(
                "SELECT a FROM Annex a WHERE a.contractId = :contractId AND a.status = :statusTODO",
                Annex.class);
        return query.setParameter("contractId", contractId)
                .setParameter("statusTODO", "TODO")
                .getResultList();
    }

    public Annex findById(long id) {
        return entityManager.find(Annex.class, id);
    }

    @Transactional
    public Annex update(Annex annex) {
        entityManager.merge(annex);
        return annex;
    }
}
