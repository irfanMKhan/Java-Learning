package com.reddot.ecrm_bulk.api.payload.group;

import lombok.Data;

import java.io.Serializable;

@Data
public class ChangeCorporateGroupMemberInfoResponse implements Serializable {
  private ChangeCorporateGroupMemberInfoRspMsg ChangeCorporateGroupMemberInfoRspMsg;

  @Data
  public static class ChangeCorporateGroupMemberInfoRspMsg implements Serializable {
    private RspHeader RspHeader;

    @Data
    public static class RspHeader implements Serializable {
      private Long RspTime;

      private String ReturnCode;

      private String ReturnMsg;

      private Integer Version;
    }
  }
}
