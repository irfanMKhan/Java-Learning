package com.reddot.ecrm_bulk.service.offering;

public interface MandatoryOfferingService {
    public Boolean IsMandatoryOffering(String supplementaryOfferingId);
}
