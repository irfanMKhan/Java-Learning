package com.reddot.ecrm_bulk.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import java.time.LocalDate;
import java.time.LocalDateTime;

@MappedSuperclass
@Data
public class AbstractEntity {
    @Column(name = "CREATE_BY")
    private String createBy;
    private String createByName;
    @Column(name = "CREATE_DATE")
    private LocalDateTime createDate = LocalDateTime.now();
    private LocalDate createdDateOnly = LocalDate.now();

    @Column(name = "UPDATE_BY")
    private String updateBy;
    private String updateByName;
    @Column(name = "UPDATE_DATE")
    private LocalDateTime updateDate;
    private LocalDate updatedDateOnly;

    @Column(name = "DELETE_BY")
    private String deleteBy;
    private String deleteByName;
    @Column(name = "DELETE_DATE")
    private LocalDateTime deleteDate;
    private LocalDate deletedDateOnly;
}
