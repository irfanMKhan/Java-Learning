package com.reddot.ecrm_bulk.service;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.reddot.ecrm_bulk.config.Utility;
import com.reddot.ecrm_bulk.model.*;
import com.reddot.ecrm_bulk.model.BulkFileTemp;
import com.reddot.ecrm_bulk.model.CommonMDModel;
import com.reddot.ecrm_bulk.model.FeeDetailModel;
import com.reddot.ecrm_bulk.model.UploadedFileModel;
import com.reddot.ecrm_bulk.pool_repository.CommonRepository;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class StudentImportService {
    @Autowired
    private CommonRepository commonDAO;

    private final Logger logger = LoggerFactory.getLogger(getClass().getName());

    public void studentBulkImport(UploadedFileModel uploadedFileModel, String processId) {
        try {
            logger.info("Calling Student Import..");
            List<BulkFileTemp> bulkFileTemps = new ArrayList<BulkFileTemp>();
            int successCount = 0;
            final int batchSize = 1000;
            int count = 0;
            String queryInsertBulkApiResponse = "INSERT INTO " + Utility.epm_bulkprocess_response + " ("
                    + "BULK_FILE_ID,"
                    + "FILE_DATA,"
                    + "FILE_ROW_NUM,"
                    + "CONNECTION_TYPE,"
                    + "API_NAME,"
                    + "API_URL,"
                    + "API_SEQUENCE, REGISTRATION_ID, API_REQUEST, PROCESS_TYPE_ID, API_RESPONSE, FAILED_REASON,PREVIUS_RESPONSE) "
                    + "values (?,?,?,?,?,?,?,?,?,?,?,?,?)";

            Object detailsTmplist = commonDAO.CommoGetData("Select * FROM " + Utility.epm_bulkprocess_file_details + " where BULK_FILE_ID = '" + uploadedFileModel.getID() + "' and PROCESS_TYPE_ID = '" + uploadedFileModel.getPROCESS_TYPE_ID() + "' and FINAL_STATUS is null FETCH NEXT 100000 ROWS ONLY");
            bulkFileTemps = new Gson().fromJson(Utility.ObjectToJson(detailsTmplist), new TypeToken<List<BulkFileTemp>>() {
            }.getType());

            String monthSql = "SELECT * FROM " + Utility.epm_month + " ";
            Object monthObj = this.commonDAO.CommoGetData(monthSql);
            List<CommonMDModel> monthList = new Gson().fromJson(Utility.ObjectToJson(monthObj), new TypeToken<List<CommonMDModel>>() {
            }.getType());

            String periodSql = "SELECT * FROM " + Utility.epm_payment_period + " ";
            Object pObj = this.commonDAO.CommoGetData(periodSql);
            List<CommonMDModel> periodList = new Gson().fromJson(Utility.ObjectToJson(pObj), new TypeToken<List<CommonMDModel>>() {
            }.getType());

            String classSql = "SELECT * FROM " + Utility.epm_class + " where INSTITUTE_ID = " + uploadedFileModel.getINSTITUTE_ID() + " and ACTIVE = 1 ";
            Object classObj = this.commonDAO.CommoGetData(classSql);
            List<CommonMDModel> classList = new Gson().fromJson(Utility.ObjectToJson(classObj), new TypeToken<List<CommonMDModel>>() {
            }.getType());

            String instituteSql = "SELECT * FROM " + Utility.epm_institute + " where ID = '" + uploadedFileModel.getINSTITUTE_ID() + "' FETCH NEXT 1 ROWS ONLY ";
            Object insObj = this.commonDAO.CommoGetData(instituteSql);
            List<CommonMDModel> insList = new Gson().fromJson(Utility.ObjectToJson(insObj), new TypeToken<List<CommonMDModel>>() {
            }.getType());

            List<Object[]> ApiResponseList = new ArrayList<Object[]>();
            if (bulkFileTemps.size() > 0) {
                for (BulkFileTemp row : bulkFileTemps) {
                    String fStatus = "Failed";
                    String fResn = "Internal Processing Error.";

                    try {
                        String[] insName = row.getINSTITUTE_NAME().trim().split("\\s+");

                        if (insList.size() > 0) {
                            if(insList.get(0).getCODE().equals(insName[0]) &&
                                    insList.get(0).getWALLET().equals(insName[1])){
                                if(classList.stream().anyMatch(o -> row.getCLASS().equals(o.getNAME()))){
                                    List<CommonMDModel> classData = classList.stream().filter(x -> row.getCLASS().equals(x.getNAME())).collect(Collectors.toList());

                                    CommonMDModel checkStd = commonDAO.isExists(Utility.epm_student, "REGISTRATION_ID", "'" + row.getREGISTRATION_ID() + "'", "AND INSTITUTE_ID = " + row.getINSTITUTE_ID() + " AND ACADEMIC_YEAR_ID = " + row.getACADEMIC_YEAR_ID());
                                    if(checkStd == null){
                                        Map<String, Object> insertData = new HashMap<String, Object>();

                                        insertData.put("INSTITUTE_ID", insList.get(0).getID());
                                        insertData.put("INSTITUTE_NAME", insList.get(0).getNAME());
                                        insertData.put("ACADEMIC_YEAR_ID", row.getACADEMIC_YEAR_ID());
                                        insertData.put("ACADEMIC_YEAR_NAME", row.getACADEMIC_YEAR_NAME());
                                        insertData.put("CLASS_ID", classData.get(0).getID());
                                        insertData.put("CLASS_NAME", row.getCLASS());
                                        insertData.put("PREVIOUS_CLASS_NAME", row.getPREVIOUS_CLASS());
                                        insertData.put("REGISTRATION_ID", row.getREGISTRATION_ID());
                                        insertData.put("SECTION_NAME", row.getSECTION());
                                        insertData.put("SHIFT_NAME", row.getSHIFT());
                                        insertData.put("HOSTEL_NAME", row.getHOSTEL());
                                        insertData.put("SESSION_NAME", row.getSTUDENT_SESSION());
                                        insertData.put("GROUP_NAME", row.getGROUP());
                                        insertData.put("NAME", row.getNAME());
                                        insertData.put("GUARDIAN_NAME", row.getGUARDIAN_NAME());
                                        insertData.put("RELIGION", row.getRELIGION());
                                        insertData.put("ROLL_NO", row.getROLL());
                                        insertData.put("GENDER", row.getGENDER());
                                        insertData.put("SCHOLARSHIP", row.getSCHOLARSHIP());
                                        insertData.put("MOBILE_NUMBER", row.getMOBILE_NO());
                                        insertData.put("STUDENT_TYPE", row.getSTUDENT_TYPE());
                                        //insertData.put("REGISTRATION_DATE", row.getUPDATE_DATE()); //TODO
                                        insertData.put("ACTIVE", row.getISACTIVE());
                                        insertData.put("CREATED_AT_DT", new java.sql.Date(new java.util.Date().getTime()));
                                        insertData.put("CREATED_BY", row.getCREATED_BY());
                                        insertData.put("CREATED_BY_USERNAME", row.getCREATED_BY_USERNAME());
                                        insertData.put("UPDATED_AT_DT", new java.sql.Date(new java.util.Date().getTime()));
                                        insertData.put("UPDATED_BY_USERNAME", row.getUPDATED_BY_USERNAME());
                                        insertData.put("UPDATED_BY", row.getUPDATED_BY());

                                        row.setSTUDENT_ID(commonDAO.commonInsertGetReturn(Utility.epm_student, insertData, logger, "ID"));
                                    }else{
                                        row.setSTUDENT_ID(checkStd.getID());
                                        Map<String, Object> updateData = new HashMap<>();
                                        Map<String, Object> updateWhere = new HashMap<>();

                                        updateData.put("CLASS_ID", classData.get(0).getID());
                                        updateData.put("CLASS_NAME", row.getCLASS());
                                        updateData.put("PREVIOUS_CLASS_NAME", row.getPREVIOUS_CLASS());
                                        updateData.put("INSTITUTE_NAME", insList.get(0).getNAME());
                                        updateData.put("ACADEMIC_YEAR_NAME", row.getACADEMIC_YEAR_NAME());
                                        updateData.put("SECTION_NAME", row.getSECTION());
                                        updateData.put("SHIFT_NAME", row.getSHIFT());
                                        updateData.put("HOSTEL_NAME", row.getHOSTEL());
                                        updateData.put("SESSION_NAME", row.getSTUDENT_SESSION());
                                        updateData.put("GROUP_NAME", row.getGROUP());
                                        updateData.put("NAME", row.getNAME());
                                        updateData.put("GUARDIAN_NAME", row.getGUARDIAN_NAME());
                                        updateData.put("RELIGION", row.getRELIGION());
                                        updateData.put("ROLL_NO", row.getROLL());
                                        updateData.put("GENDER", row.getGENDER());
                                        updateData.put("SCHOLARSHIP", row.getSCHOLARSHIP());
                                        updateData.put("MOBILE_NUMBER", row.getMOBILE_NO());
                                        updateData.put("STUDENT_TYPE", row.getSTUDENT_TYPE());
                                        //updateData.put("REGISTRATION_DATE", row.getUPDATE_DATE());//TODO
                                        updateData.put("ACTIVE", row.getISACTIVE());
                                        updateData.put("UPDATED_AT_DT", new java.sql.Date(new java.util.Date().getTime()));
                                        updateData.put("UPDATED_BY_USERNAME", row.getUPDATED_BY_USERNAME());
                                        updateData.put("UPDATED_BY", row.getUPDATED_BY());

                                        updateWhere.put("ID", checkStd.getID());

                                        commonDAO.CommoUpdate(Utility.epm_student, updateData, updateWhere, logger);
                                    }
                                    try{
                                        JSONObject data = new JSONObject(row.getFILE_DATA());
                                        data.keySet().forEach(keyStr ->
                                        {
                                            String[] categoryArray = new String[3];
                                            Object keyvalue = data.get(keyStr);
                                            //System.out.println("key: "+ keyStr + " value: " + keyvalue);

                                            if (keyvalue instanceof JSONObject){
                                                JSONObject detailData = (JSONObject)keyvalue;
                                                detailData.keySet().forEach(detailKeyStr ->
                                                {

                                                    Object detailKeyValue = detailData.get(detailKeyStr);
                                                    //System.out.println("key: "+ detailKeyStr + " value: " + detailKeyValue);

                                                    if(detailKeyStr.equals("p")){
                                                        if(periodList.stream().anyMatch(o -> detailKeyValue.toString().equals(o.getNAME()))){
                                                            categoryArray[0] = detailKeyValue.toString();
                                                        }
                                                    }else if(detailKeyStr.equals("m")){
                                                        if(monthList.stream().anyMatch(o -> detailKeyValue.toString().toUpperCase().equals(o.getNAME()))){
                                                            categoryArray[1] = detailKeyValue.toString().toUpperCase();
                                                        }
                                                    }else {
                                                        categoryArray[2] = detailKeyValue.toString();
                                                    }

                                                });
                                            }
                                            List<CommonMDModel> periodData = periodList.stream().filter(x -> categoryArray[0].equals(x.getNAME())).collect(Collectors.toList());
                                            List<CommonMDModel> monthData = monthList.stream().filter(x -> categoryArray[1].equals(x.getNAME())).collect(Collectors.toList());

                                            CommonMDModel checkCategory = commonDAO.isExists(Utility.epm_fee_category, "NAME", "'"+ keyStr + "'", "AND INSTITUTE_ID = " + row.getINSTITUTE_ID() + " AND ACADEMIC_YEAR_ID = " + row.getACADEMIC_YEAR_ID());
                                            String getCatId = "";
                                            if(checkCategory == null){
                                                Map<String, Object> insertCategoryData = new HashMap<String, Object>();

                                                insertCategoryData.put("INSTITUTE_ID", insList.get(0).getID());
                                                insertCategoryData.put("INSTITUTE_NAME", insList.get(0).getNAME());
                                                insertCategoryData.put("ACADEMIC_YEAR_ID", row.getACADEMIC_YEAR_ID());
                                                insertCategoryData.put("ACADEMIC_YEAR_NAME", row.getACADEMIC_YEAR_NAME());
                                                insertCategoryData.put("PAYMENT_PERIOD_ID", periodData.get(0).getID());
                                                insertCategoryData.put("PAYMENT_PERIOD_NAME", periodData.get(0).getNAME());
                                                insertCategoryData.put("START_MONTH_ID", monthData.get(0).getID());
                                                insertCategoryData.put("START_MONTH_NAME", monthData.get(0).getNAME());
                                                insertCategoryData.put("NAME", keyStr);
                                                insertCategoryData.put("ACTIVE", 1);
                                                insertCategoryData.put("CREATED_AT_DT", new java.sql.Date(new java.util.Date().getTime()));
                                                insertCategoryData.put("CREATED_BY", row.getCREATED_BY());
                                                insertCategoryData.put("CREATED_BY_USERNAME", row.getCREATED_BY_USERNAME());
                                                insertCategoryData.put("UPDATED_AT_DT", new java.sql.Date(new java.util.Date().getTime()));
                                                insertCategoryData.put("UPDATED_BY_USERNAME", row.getUPDATED_BY_USERNAME());
                                                insertCategoryData.put("UPDATED_BY", row.getUPDATED_BY());

                                                getCatId = commonDAO.commonInsertGetReturn(Utility.epm_fee_category, insertCategoryData, logger, "ID");
                                            }else {
                                                getCatId = checkCategory.getID();
                                                Map<String, Object> updateCategoryData = new HashMap<>();
                                                Map<String, Object> updateCategoryWhere = new HashMap<>();

                                                updateCategoryData.put("INSTITUTE_NAME", insList.get(0).getNAME());
                                                updateCategoryData.put("ACADEMIC_YEAR_NAME", row.getACADEMIC_YEAR_NAME());
                                                updateCategoryData.put("PAYMENT_PERIOD_ID", periodData.get(0).getID());
                                                updateCategoryData.put("PAYMENT_PERIOD_NAME", periodData.get(0).getNAME());
                                                updateCategoryData.put("START_MONTH_ID", monthData.get(0).getID());
                                                updateCategoryData.put("START_MONTH_NAME", monthData.get(0).getNAME());
                                                updateCategoryData.put("NAME", keyStr);
                                                updateCategoryData.put("ACTIVE", 1);

                                                updateCategoryData.put("UPDATED_AT_DT", new java.sql.Date(new java.util.Date().getTime()));
                                                updateCategoryData.put("UPDATED_BY_USERNAME", row.getUPDATED_BY_USERNAME());
                                                updateCategoryData.put("UPDATED_BY", row.getUPDATED_BY());

                                                updateCategoryWhere.put("ID", checkCategory.getID());

                                                commonDAO.CommoUpdate(Utility.epm_fee_category, updateCategoryData, updateCategoryWhere, logger);
                                            }

                                            List<FeeDetailModel> feeDetailModels = Utility.getFeeDetailPeriodMonth(monthList,periodList,"yyyy-mm-dd",uploadedFileModel.getSTART_TIME_DT(),uploadedFileModel.getEND_TIME_DT(),categoryArray[0],categoryArray[1],categoryArray[2]);
                                            for (FeeDetailModel detail:feeDetailModels) {
                                                if(checkStd == null){
                                                    Map<String, Object> insertFeeData = new HashMap<String, Object>();

                                                    insertFeeData.put("INSTITUTE_ID", insList.get(0).getID());
                                                    insertFeeData.put("INSTITUTE_NAME", insList.get(0).getNAME());
                                                    insertFeeData.put("ACADEMIC_YEAR_ID", row.getACADEMIC_YEAR_ID());
                                                    insertFeeData.put("ACADEMIC_YEAR_NAME", row.getACADEMIC_YEAR_NAME());
                                                    insertFeeData.put("CLASS_ID", classData.get(0).getID());
                                                    insertFeeData.put("CLASS_NAME", row.getCLASS());
                                                    insertFeeData.put("STUDENT_ID", row.getSTUDENT_ID());
                                                    insertFeeData.put("STUDENT_NAME", row.getNAME());

                                                    insertFeeData.put("FEE_CATEGORY_ID", getCatId);
                                                    insertFeeData.put("FEE_CATEGORY_NAME", keyStr);
                                                    insertFeeData.put("MONTH_ID", detail.getMONTH_ID());
                                                    insertFeeData.put("MONTH_NAME", detail.getMONTH_NAME());

                                                    insertFeeData.put("AMOUNT", detail.getAMOUNT());
                                                    insertFeeData.put("IS_PAID", "0");

                                                    insertFeeData.put("ACTIVE", row.getISACTIVE());
                                                    insertFeeData.put("CREATED_AT_DT", new java.sql.Date(new java.util.Date().getTime()));
                                                    insertFeeData.put("CREATED_BY", row.getCREATED_BY());
                                                    insertFeeData.put("CREATED_BY_USERNAME", row.getCREATED_BY_USERNAME());
                                                    insertFeeData.put("UPDATED_AT_DT", new java.sql.Date(new java.util.Date().getTime()));
                                                    insertFeeData.put("UPDATED_BY_USERNAME", row.getUPDATED_BY_USERNAME());
                                                    insertFeeData.put("UPDATED_BY", row.getUPDATED_BY());

                                                    if(commonDAO.CommoInsert(Utility.epm_student_fee, insertFeeData, logger)){

                                                    }
                                                }else{
                                                    if(checkCategory == null){
                                                        Map<String, Object> insertFeeData = new HashMap<String, Object>();

                                                        insertFeeData.put("INSTITUTE_ID", insList.get(0).getID());
                                                        insertFeeData.put("INSTITUTE_NAME", insList.get(0).getNAME());
                                                        insertFeeData.put("ACADEMIC_YEAR_ID", row.getACADEMIC_YEAR_ID());
                                                        insertFeeData.put("ACADEMIC_YEAR_NAME", row.getACADEMIC_YEAR_NAME());
                                                        insertFeeData.put("CLASS_ID", classData.get(0).getID());
                                                        insertFeeData.put("CLASS_NAME", row.getCLASS());
                                                        insertFeeData.put("STUDENT_ID", row.getSTUDENT_ID());
                                                        insertFeeData.put("STUDENT_NAME", row.getNAME());

                                                        insertFeeData.put("FEE_CATEGORY_ID", getCatId);
                                                        insertFeeData.put("FEE_CATEGORY_NAME", keyStr);
                                                        insertFeeData.put("MONTH_ID", detail.getMONTH_ID());
                                                        insertFeeData.put("MONTH_NAME", detail.getMONTH_NAME());

                                                        insertFeeData.put("AMOUNT", detail.getAMOUNT());
                                                        insertFeeData.put("IS_PAID", "0");

                                                        insertFeeData.put("ACTIVE", row.getISACTIVE());
                                                        insertFeeData.put("CREATED_AT_DT", new java.sql.Date(new java.util.Date().getTime()));
                                                        insertFeeData.put("CREATED_BY", row.getCREATED_BY());
                                                        insertFeeData.put("CREATED_BY_USERNAME", row.getCREATED_BY_USERNAME());
                                                        insertFeeData.put("UPDATED_AT_DT", new java.sql.Date(new java.util.Date().getTime()));
                                                        insertFeeData.put("UPDATED_BY_USERNAME", row.getUPDATED_BY_USERNAME());
                                                        insertFeeData.put("UPDATED_BY", row.getUPDATED_BY());

                                                        if(commonDAO.CommoInsert(Utility.epm_student_fee, insertFeeData, logger)){
                                                            //TODO
                                                        }
                                                    }else {
                                                        CommonMDModel checkStdFee = commonDAO.isExists(Utility.epm_student_fee, "STUDENT_ID", row.getSTUDENT_ID(), "AND INSTITUTE_ID = " + row.getINSTITUTE_ID() + " AND ACADEMIC_YEAR_ID = " + row.getACADEMIC_YEAR_ID() + " AND FEE_CATEGORY_ID = " + getCatId + " AND MONTH_ID = " + detail.getMONTH_ID()+ " AND IS_PAID = 0 ");
                                                        if(checkStdFee == null){
                                                            Map<String, Object> insertFeeData = new HashMap<String, Object>();

                                                            insertFeeData.put("INSTITUTE_ID", insList.get(0).getID());
                                                            insertFeeData.put("INSTITUTE_NAME", insList.get(0).getNAME());
                                                            insertFeeData.put("ACADEMIC_YEAR_ID", row.getACADEMIC_YEAR_ID());
                                                            insertFeeData.put("ACADEMIC_YEAR_NAME", row.getACADEMIC_YEAR_NAME());
                                                            insertFeeData.put("CLASS_ID", classData.get(0).getID());
                                                            insertFeeData.put("CLASS_NAME", row.getCLASS());
                                                            insertFeeData.put("STUDENT_ID", row.getSTUDENT_ID());
                                                            insertFeeData.put("STUDENT_NAME", row.getNAME());

                                                            insertFeeData.put("FEE_CATEGORY_ID", getCatId);
                                                            insertFeeData.put("FEE_CATEGORY_NAME", keyStr);
                                                            insertFeeData.put("MONTH_ID", detail.getMONTH_ID());
                                                            insertFeeData.put("MONTH_NAME", detail.getMONTH_NAME());

                                                            insertFeeData.put("AMOUNT", detail.getAMOUNT());
                                                            insertFeeData.put("IS_PAID", "0");

                                                            insertFeeData.put("ACTIVE", row.getISACTIVE());
                                                            insertFeeData.put("CREATED_AT_DT", new java.sql.Date(new java.util.Date().getTime()));
                                                            insertFeeData.put("CREATED_BY", row.getCREATED_BY());
                                                            insertFeeData.put("CREATED_BY_USERNAME", row.getCREATED_BY_USERNAME());
                                                            insertFeeData.put("UPDATED_AT_DT", new java.sql.Date(new java.util.Date().getTime()));
                                                            insertFeeData.put("UPDATED_BY_USERNAME", row.getUPDATED_BY_USERNAME());
                                                            insertFeeData.put("UPDATED_BY", row.getUPDATED_BY());

                                                            if(commonDAO.CommoInsert(Utility.epm_student_fee, insertFeeData, logger)){
                                                                //TODO
                                                            }
                                                        }else{
                                                            Map<String, Object> updateFeeData = new HashMap<>();
                                                            Map<String, Object> updateFeeWhere = new HashMap<>();

                                                            updateFeeData.put("INSTITUTE_NAME", insList.get(0).getNAME());
                                                            updateFeeData.put("ACADEMIC_YEAR_NAME", row.getACADEMIC_YEAR_NAME());
                                                            updateFeeData.put("CLASS_NAME", row.getCLASS());
                                                            updateFeeData.put("STUDENT_NAME", row.getNAME());
                                                            updateFeeData.put("FEE_CATEGORY_NAME", keyStr);
                                                            updateFeeData.put("MONTH_NAME", detail.getMONTH_NAME());
                                                            updateFeeData.put("AMOUNT", detail.getAMOUNT());
                                                            updateFeeData.put("IS_PAID", "0");

                                                            updateFeeData.put("ACTIVE", row.getISACTIVE());
                                                            updateFeeData.put("UPDATED_AT_DT", new java.sql.Date(new java.util.Date().getTime()));
                                                            updateFeeData.put("UPDATED_BY_USERNAME", row.getUPDATED_BY_USERNAME());
                                                            updateFeeData.put("UPDATED_BY", row.getUPDATED_BY());

                                                            updateFeeWhere.put("ID", checkStdFee.getID());

                                                            commonDAO.CommoUpdate(Utility.epm_student_fee, updateFeeData, updateFeeWhere, logger);
                                                        }
                                                    }
                                                }
                                            }
                                        });
                                        successCount++;
                                        fResn = "Success";
                                        fStatus = "Success";
                                    }catch (Exception ex){
                                        fStatus = "Failed";
                                        fResn = "Student fee processing failed: " + ex.getMessage();
                                    }

                                }else{
                                    fResn = "Class mismatched";
                                }
                            }else {
                                fResn = "Institute mismatched";
                            }

                        } else {
                            fResn = "Institute mapping failed";
                        }
                    } catch (Exception e) {
                        fStatus = "Failed";
                        fResn = "Server error: " + e.getMessage();
                    }

                    String TMPSQL = "UPDATE " + Utility.epm_bulkprocess_file_details + " SET FINAL_STATUS = '" + fStatus + "', Failed_REASON = '" + fResn + "' WHERE ID = '" + row.getID() + "'";
                    commonDAO.CommoUpdate(TMPSQL, logger);

                    Object[] ApiArray = {
                            row.getBULK_FILE_ID(),
                            row.getFILE_DATA(),
                            row.getFILE_ROW_NUM(),
                            row.getCONNECTION_TYPE(),
                            "", "", "",
                            row.getREGISTRATION_ID(),
                            row.getFILE_DATA(),
                            uploadedFileModel.getPROCESS_TYPE_ID(), fResn, fStatus, ""
                    };
                    ApiResponseList.add(ApiArray);

                    if (++count % batchSize == 0) {
                        if (commonDAO.BatchInsertSQL(ApiResponseList, queryInsertBulkApiResponse, logger)) {
                            ApiResponseList = new ArrayList<Object[]>();
                        }
                    }
                }
                try {
                    commonDAO.BatchInsertSQL(ApiResponseList, queryInsertBulkApiResponse, logger);
                } catch (Exception e) {
                    e.printStackTrace();
                    logger.error(e.getMessage(), e);
                }
                try {
                    UpdateFileTBL(Integer.parseInt(uploadedFileModel.getTOTAL_ROWS()), "3", "COMPLETED", successCount, uploadedFileModel.getID());
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
                logger.info("Student File Import Done");
            } else {
                UpdateFileTBL(Integer.parseInt(uploadedFileModel.getTOTAL_ROWS()), "4", "Failed", 0, uploadedFileModel.getID());
            }
        } catch (Exception ex) {
            UpdateFileTBL(Integer.parseInt(uploadedFileModel.getTOTAL_ROWS()), "4", "Failed", 0, uploadedFileModel.getID());
            logger.error(ex.getMessage(), ex);
        }
    }

    public void studentBulkImportv2(UploadedFileModel uploadedFileModel, String processId) {
        try {
            logger.info("Calling Student Import..");
            List<BulkFileTemp> bulkFileTemps = new ArrayList<BulkFileTemp>();
            int successCount = 0;
            final int batchSize = 1000;
            int count = 0;
            int feeInsertCount = 0;
            int feeUpdateCount = 0;
            String queryInsertBulkApiResponse = "INSERT INTO " + Utility.epm_bulkprocess_response + " ("
                    + "BULK_FILE_ID,"
                    + "FILE_DATA,"
                    + "FILE_ROW_NUM,"
                    + "CONNECTION_TYPE,"
                    + "API_NAME,"
                    + "API_URL,"
                    + "API_SEQUENCE, REGISTRATION_ID, API_REQUEST, PROCESS_TYPE_ID, API_RESPONSE, FAILED_REASON,PREVIUS_RESPONSE) "
                    + "values (?,?,?,?,?,?,?,?,?,?,?,?,?)";

            String queryInsertFee = "INSERT INTO " + Utility.epm_student_fee + " ("
                    + "INSTITUTE_ID,"
                    + "INSTITUTE_NAME,"
                    + "ACADEMIC_YEAR_ID,"
                    + "ACADEMIC_YEAR_NAME,"
                    + "CLASS_ID,"
                    + "CLASS_NAME,"
                    + "STUDENT_ID, STUDENT_NAME, FEE_CATEGORY_ID, FEE_CATEGORY_NAME, MONTH_ID, MONTH_NAME,AMOUNT, IS_PAID,ACTIVE, CREATED_AT_DT,CREATED_BY,CREATED_BY_USERNAME) "
                    + "values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

            String queryUpdateFee = " UPDATE " + Utility.epm_student_fee
                    + " SET INSTITUTE_NAME =? "
                    + " ,ACADEMIC_YEAR_NAME = ? "
                    + " ,CLASS_NAME = ? "
                    + " ,STUDENT_NAME = ? "
                    + " ,MONTH_NAME = ? "
                    + " ,AMOUNT = ? "
                    + " ,ACTIVE = ? "
                    + " ,UPDATED_AT_DT = ? "
                    + " ,UPDATED_BY_USERNAME = ? "
                    + " ,UPDATED_BY = ? "
                    + " WHERE  ID=? ";

            String queryUpdateCategory = " UPDATE " + Utility.epm_fee_category
                    + " SET INSTITUTE_NAME =? "
                    + " ,ACADEMIC_YEAR_NAME = ? "
                    + " ,PAYMENT_PERIOD_ID = ? "
                    + " ,PAYMENT_PERIOD_NAME = ? "
                    + " ,START_MONTH_ID = ? "
                    + " ,START_MONTH_NAME = ? "
                    + " ,NAME = ? "
                    + " ,ACTIVE = ? "
                    + " ,UPDATED_AT_DT = ? "
                    + " ,UPDATED_BY_USERNAME = ? "
                    + " ,UPDATED_BY = ? "
                    + " WHERE  ID=? ";

            Object detailsTmplist = commonDAO.CommoGetData("Select * FROM " + Utility.epm_bulkprocess_file_details + " where BULK_FILE_ID = '" + uploadedFileModel.getID() + "' and PROCESS_TYPE_ID = '" + uploadedFileModel.getPROCESS_TYPE_ID() + "' and FINAL_STATUS is null FETCH NEXT 100000 ROWS ONLY");
            bulkFileTemps = new Gson().fromJson(Utility.ObjectToJson(detailsTmplist), new TypeToken<List<BulkFileTemp>>() {
            }.getType());

            String monthSql = "SELECT * FROM " + Utility.epm_month + " ";
            Object monthObj = this.commonDAO.CommoGetData(monthSql);
            List<CommonMDModel> monthList = new Gson().fromJson(Utility.ObjectToJson(monthObj), new TypeToken<List<CommonMDModel>>() {
            }.getType());

            String periodSql = "SELECT * FROM " + Utility.epm_payment_period + " ";
            Object pObj = this.commonDAO.CommoGetData(periodSql);
            List<CommonMDModel> periodList = new Gson().fromJson(Utility.ObjectToJson(pObj), new TypeToken<List<CommonMDModel>>() {
            }.getType());

            String classSql = "SELECT * FROM " + Utility.epm_class + " where INSTITUTE_ID = " + uploadedFileModel.getINSTITUTE_ID() + " and ACTIVE = 1 ";
            Object classObj = this.commonDAO.CommoGetData(classSql);
            List<CommonMDModel> classList = new Gson().fromJson(Utility.ObjectToJson(classObj), new TypeToken<List<CommonMDModel>>() {
            }.getType());

            String sectionSql = "SELECT * FROM " + Utility.epm_section + " where INSTITUTE_ID = " + uploadedFileModel.getINSTITUTE_ID() + " and ACTIVE = 1 ";
            Object sectionObj = this.commonDAO.CommoGetData(sectionSql);
            List<CommonMDModel> sectionList = new Gson().fromJson(Utility.ObjectToJson(sectionObj), new TypeToken<List<CommonMDModel>>() {
            }.getType());

            String groupSql = "SELECT * FROM " + Utility.epm_student_group + " where INSTITUTE_ID = " + uploadedFileModel.getINSTITUTE_ID() + " and ACTIVE = 1 ";
            Object groupObj = this.commonDAO.CommoGetData(groupSql);
            List<CommonMDModel> groupList = new Gson().fromJson(Utility.ObjectToJson(groupObj), new TypeToken<List<CommonMDModel>>() {
            }.getType());

            String shiftSql = "SELECT * FROM " + Utility.epm_shift + " where INSTITUTE_ID = " + uploadedFileModel.getINSTITUTE_ID() + " and ACTIVE = 1 ";
            Object shiftObj = this.commonDAO.CommoGetData(shiftSql);
            List<CommonMDModel> shiftList = new Gson().fromJson(Utility.ObjectToJson(shiftObj), new TypeToken<List<CommonMDModel>>() {
            }.getType());

            String sessionSql = "SELECT * FROM " + Utility.epm_student_session + " where INSTITUTE_ID = " + uploadedFileModel.getINSTITUTE_ID() + " and ACTIVE = 1 ";
            Object sessionObj = this.commonDAO.CommoGetData(sessionSql);
            List<CommonMDModel> sessionList = new Gson().fromJson(Utility.ObjectToJson(sessionObj), new TypeToken<List<CommonMDModel>>() {
            }.getType());

            String hostelSql = "SELECT * FROM " + Utility.epm_hostel + " where INSTITUTE_ID = " + uploadedFileModel.getINSTITUTE_ID() + " and ACTIVE = 1 ";
            Object hostelObj = this.commonDAO.CommoGetData(hostelSql);
            List<CommonMDModel> hostelList = new Gson().fromJson(Utility.ObjectToJson(hostelObj), new TypeToken<List<CommonMDModel>>() {
            }.getType());

            String instituteSql = "SELECT * FROM " + Utility.epm_institute + " where ID = '" + uploadedFileModel.getINSTITUTE_ID() + "' FETCH NEXT 1 ROWS ONLY ";
            Object insObj = this.commonDAO.CommoGetData(instituteSql);
            List<CommonMDModel> insList = new Gson().fromJson(Utility.ObjectToJson(insObj), new TypeToken<List<CommonMDModel>>() {
            }.getType());

            String studentSql = "SELECT ID, REGISTRATION_ID FROM " + Utility.epm_student + " where INSTITUTE_ID = " + uploadedFileModel.getINSTITUTE_ID() + " AND ACADEMIC_YEAR_ID = " + uploadedFileModel.getACADEMIC_YEAR_ID() + " ";
            Object stdObj = this.commonDAO.CommoGetData(studentSql);
            List<CommonMDModel> studentList = new Gson().fromJson(Utility.ObjectToJson(stdObj), new TypeToken<List<CommonMDModel>>() {
            }.getType());

            String categorySql = "SELECT ID, NAME FROM " + Utility.epm_fee_category + " where INSTITUTE_ID = " + uploadedFileModel.getINSTITUTE_ID() + " AND ACADEMIC_YEAR_ID = " + uploadedFileModel.getACADEMIC_YEAR_ID() + " ";
            Object categoryObj = this.commonDAO.CommoGetData(categorySql);
            List<CommonMDModel> categoryList = new Gson().fromJson(Utility.ObjectToJson(categoryObj), new TypeToken<List<CommonMDModel>>() {
            }.getType());

            List<Object[]> ApiResponseList = new ArrayList<Object[]>();
            List<Object[]> updateFeeCategoryList = new ArrayList<Object[]>();
            List<String> updateFeeCategoryIds = new ArrayList<>();

            if (bulkFileTemps.size() > 0) {
                for (BulkFileTemp row : bulkFileTemps) {
                    List<Object[]> insertFeeList = new ArrayList<Object[]>();
                    List<Object[]> updateFeeList = new ArrayList<Object[]>();
                    String fStatus = "Failed";
                    String fResn = "Internal Processing Error.";

                    try {
                        String[] insName = row.getINSTITUTE_NAME().trim().split("\\s+");

                        if (insList.size() > 0) {
                            if(insList.get(0).getCODE().equals(insName[0]) &&
                                    insList.get(0).getWALLET().equals(insName[1])){

                                if(classList.stream().anyMatch(o -> row.getCLASS().equals(o.getNAME()))){
                                    List<CommonMDModel> classData = classList.stream().filter(x -> row.getCLASS().equals(x.getNAME())).collect(Collectors.toList());

                                    CommonMDModel checkStd = studentList.stream().filter(x-> x.getREGISTRATION_ID().equals(row.getREGISTRATION_ID())).findFirst().orElse(null);
                                    CommonMDModel checkSection = sectionList.stream().filter(x-> x.getNAME().equals(row.getSECTION())).findFirst().orElse(null);
                                    CommonMDModel checkGroup = groupList.stream().filter(x-> x.getNAME().equals(row.getGROUP())).findFirst().orElse(null);
                                    CommonMDModel checkShift = shiftList.stream().filter(x-> x.getNAME().equals(row.getSHIFT())).findFirst().orElse(null);
                                    CommonMDModel checkSession = sessionList.stream().filter(x-> x.getNAME().equals(row.getSTUDENT_SESSION())).findFirst().orElse(null);
                                    CommonMDModel checkHostel = hostelList.stream().filter(x-> x.getNAME().equals(row.getHOSTEL())).findFirst().orElse(null);
                                    if(checkStd == null){
                                        Map<String, Object> insertData = new HashMap<String, Object>();

                                        insertData.put("INSTITUTE_ID", insList.get(0).getID());
                                        insertData.put("INSTITUTE_NAME", insList.get(0).getNAME());
                                        insertData.put("ACADEMIC_YEAR_ID", row.getACADEMIC_YEAR_ID());
                                        insertData.put("ACADEMIC_YEAR_NAME", row.getACADEMIC_YEAR_NAME());
                                        insertData.put("CLASS_ID", classData.get(0).getID());
                                        insertData.put("CLASS_NAME", row.getCLASS());
                                        insertData.put("PREVIOUS_CLASS_NAME", row.getPREVIOUS_CLASS());
                                        insertData.put("REGISTRATION_ID", row.getREGISTRATION_ID());
                                        insertData.put("SECTION_NAME", row.getSECTION());
                                        insertData.put("SECTION_ID", checkSection == null? null : checkSection.getID());
                                        insertData.put("SHIFT_NAME", row.getSHIFT());
                                        insertData.put("SHIFT_ID", checkShift == null? null : checkShift.getID());
                                        insertData.put("HOSTEL_NAME", row.getHOSTEL());
                                        insertData.put("HOSTEL_ID", checkHostel == null? null : checkHostel.getID());
                                        insertData.put("SESSION_NAME", row.getSTUDENT_SESSION());
                                        insertData.put("SESSION_ID", checkSession == null? null : checkSession.getID());
                                        insertData.put("GROUP_NAME", row.getGROUP());
                                        insertData.put("GROUP_ID", checkGroup == null? null : checkGroup.getID());
                                        insertData.put("NAME", row.getNAME());
                                        insertData.put("GUARDIAN_NAME", row.getGUARDIAN_NAME());
                                        insertData.put("RELIGION", row.getRELIGION());
                                        insertData.put("ROLL_NO", row.getROLL());
                                        insertData.put("GENDER", row.getGENDER());
                                        insertData.put("SCHOLARSHIP", row.getSCHOLARSHIP());
                                        insertData.put("MOBILE_NUMBER", row.getMOBILE_NO());
                                        insertData.put("STUDENT_TYPE", row.getSTUDENT_TYPE());
                                        //insertData.put("REGISTRATION_DATE", row.getUPDATE_DATE()); //TODO
                                        insertData.put("ACTIVE", row.getISACTIVE());
                                        insertData.put("CREATED_AT_DT", new java.sql.Date(new java.util.Date().getTime()));
                                        insertData.put("CREATED_BY", row.getCREATED_BY());
                                        insertData.put("CREATED_BY_USERNAME", row.getCREATED_BY_USERNAME());
                                        insertData.put("UPDATED_AT_DT", new java.sql.Date(new java.util.Date().getTime()));
                                        insertData.put("UPDATED_BY_USERNAME", row.getUPDATED_BY_USERNAME());
                                        insertData.put("UPDATED_BY", row.getUPDATED_BY());

                                        row.setSTUDENT_ID(commonDAO.commonInsertGetReturn(Utility.epm_student, insertData, logger, "ID"));
                                        studentList.add(new CommonMDModel(row.getSTUDENT_ID(),row.getNAME(), row.getREGISTRATION_ID()));
                                    }else{
                                        row.setSTUDENT_ID(checkStd.getID());
                                        Map<String, Object> updateData = new HashMap<>();
                                        Map<String, Object> updateWhere = new HashMap<>();

                                        updateData.put("INSTITUTE_NAME", insList.get(0).getNAME());
                                        updateData.put("CLASS_ID", classData.get(0).getID());
                                        updateData.put("CLASS_NAME", row.getCLASS());
                                        updateData.put("ACADEMIC_YEAR_NAME", row.getACADEMIC_YEAR_NAME());
                                        if(row.getPREVIOUS_CLASS() != null){
                                            updateData.put("PREVIOUS_CLASS_NAME", row.getPREVIOUS_CLASS());
                                        }
                                        if(row.getSECTION() != null){
                                            updateData.put("SECTION_NAME", row.getSECTION());
                                            updateData.put("SECTION_ID", checkSection == null? null : checkSection.getID());
                                        }
                                        if(row.getSHIFT() != null){
                                            updateData.put("SHIFT_NAME", row.getSHIFT());
                                            updateData.put("SHIFT_ID", checkShift == null? null : checkShift.getID());
                                        }
                                        if(row.getHOSTEL() != null){
                                            updateData.put("HOSTEL_NAME", row.getHOSTEL());
                                            updateData.put("HOSTEL_ID", checkHostel == null? null : checkHostel.getID());
                                        }
                                        if(row.getSTUDENT_SESSION() != null){
                                            updateData.put("SESSION_NAME", row.getSTUDENT_SESSION());
                                            updateData.put("SESSION_ID", checkSession == null? null : checkSession.getID());
                                        }
                                        if(row.getGROUP() != null){
                                            updateData.put("GROUP_NAME", row.getGROUP());
                                            updateData.put("GROUP_ID", checkGroup == null? null : checkGroup.getID());
                                        }
                                        if(row.getNAME() != null){
                                            updateData.put("NAME", row.getNAME());
                                        }
                                        if(row.getGUARDIAN_NAME() != null){
                                            updateData.put("GUARDIAN_NAME", row.getGUARDIAN_NAME());
                                        }
                                        if(row.getRELIGION() != null){
                                            updateData.put("RELIGION", row.getRELIGION());
                                        }
                                        if(row.getROLL() != null){
                                            updateData.put("ROLL_NO", row.getROLL());
                                        }
                                        if(row.getGENDER() != null){
                                            updateData.put("GENDER", row.getGENDER());
                                        }
                                        if(row.getSCHOLARSHIP() != null){
                                            updateData.put("SCHOLARSHIP", row.getSCHOLARSHIP());
                                        }
                                        if(row.getMOBILE_NO() != null){
                                            updateData.put("MOBILE_NUMBER", row.getMOBILE_NO());
                                        }
                                        if(row.getSTUDENT_TYPE() != null){
                                            updateData.put("STUDENT_TYPE", row.getSTUDENT_TYPE());
                                        }
                                        //updateData.put("REGISTRATION_DATE", row.getUPDATE_DATE());//TODO
                                        updateData.put("ACTIVE", row.getISACTIVE());
                                        updateData.put("UPDATED_AT_DT", new java.sql.Date(new java.util.Date().getTime()));
                                        updateData.put("UPDATED_BY_USERNAME", row.getUPDATED_BY_USERNAME());
                                        updateData.put("UPDATED_BY", row.getUPDATED_BY());

                                        updateWhere.put("ID", checkStd.getID());

                                        commonDAO.CommoUpdate(Utility.epm_student, updateData, updateWhere, logger);
                                    }
                                    try{
                                        String stdFeeSql = "SELECT ID, FEE_CATEGORY_ID, MONTH_ID  FROM " + Utility.epm_student_fee + " where STUDENT_ID = " + row.getSTUDENT_ID() + " AND INSTITUTE_ID = " + uploadedFileModel.getINSTITUTE_ID() + " AND ACADEMIC_YEAR_ID = " + uploadedFileModel.getACADEMIC_YEAR_ID() + " AND IS_PAID = 0 ";
                                        Object stdFeeObj = this.commonDAO.CommoGetData(stdFeeSql);
                                        List<CommonMDModel> stdFeeList = new Gson().fromJson(Utility.ObjectToJson(stdFeeObj), new TypeToken<List<CommonMDModel>>() {
                                        }.getType());

                                        if(row.getFILE_DATA() != null){
                                            JSONObject data = new JSONObject(row.getFILE_DATA());
                                            data.keySet().forEach(keyStr ->
                                            {
                                                String[] categoryArray = new String[3];
                                                Object keyvalue = data.get(keyStr);
                                                //System.out.println("key: "+ keyStr + " value: " + keyvalue);

                                                if (keyvalue instanceof JSONObject){
                                                    JSONObject detailData = (JSONObject)keyvalue;
                                                    detailData.keySet().forEach(detailKeyStr ->
                                                    {

                                                        Object detailKeyValue = detailData.get(detailKeyStr);
                                                        //System.out.println("key: "+ detailKeyStr + " value: " + detailKeyValue);

                                                        if(detailKeyStr.equals("p")){
                                                            if(periodList.stream().anyMatch(o -> detailKeyValue.toString().equals(o.getNAME()))){
                                                                categoryArray[0] = detailKeyValue.toString();
                                                            }
                                                        }else if(detailKeyStr.equals("m")){
                                                            if(monthList.stream().anyMatch(o -> detailKeyValue.toString().toUpperCase().equals(o.getNAME()))){
                                                                categoryArray[1] = detailKeyValue.toString().toUpperCase();
                                                            }
                                                        }else {
                                                            categoryArray[2] = detailKeyValue.toString();
                                                        }

                                                    });
                                                }
                                                List<CommonMDModel> periodData = periodList.stream().filter(x -> categoryArray[0].equals(x.getNAME())).collect(Collectors.toList());
                                                List<CommonMDModel> monthData = monthList.stream().filter(x -> categoryArray[1].equals(x.getNAME())).collect(Collectors.toList());

                                                CommonMDModel checkCategory = categoryList.stream().filter(x-> x.getNAME().equals(keyStr)).findFirst().orElse(null);
                                                String getCatId = "";
                                                if(checkCategory == null){
                                                    Map<String, Object> insertCategoryData = new HashMap<String, Object>();

                                                    insertCategoryData.put("INSTITUTE_ID", insList.get(0).getID());
                                                    insertCategoryData.put("INSTITUTE_NAME", insList.get(0).getNAME());
                                                    insertCategoryData.put("ACADEMIC_YEAR_ID", row.getACADEMIC_YEAR_ID());
                                                    insertCategoryData.put("ACADEMIC_YEAR_NAME", row.getACADEMIC_YEAR_NAME());
                                                    insertCategoryData.put("PAYMENT_PERIOD_ID", periodData.get(0).getID());
                                                    insertCategoryData.put("PAYMENT_PERIOD_NAME", periodData.get(0).getNAME());
                                                    insertCategoryData.put("START_MONTH_ID", monthData.get(0).getID());
                                                    insertCategoryData.put("START_MONTH_NAME", monthData.get(0).getNAME());
                                                    insertCategoryData.put("NAME", keyStr);
                                                    insertCategoryData.put("ACTIVE", 1);
                                                    insertCategoryData.put("CREATED_AT_DT", new java.sql.Date(new java.util.Date().getTime()));
                                                    insertCategoryData.put("CREATED_BY", row.getCREATED_BY());
                                                    insertCategoryData.put("CREATED_BY_USERNAME", row.getCREATED_BY_USERNAME());
                                                    insertCategoryData.put("UPDATED_AT_DT", new java.sql.Date(new java.util.Date().getTime()));
                                                    insertCategoryData.put("UPDATED_BY_USERNAME", row.getUPDATED_BY_USERNAME());
                                                    insertCategoryData.put("UPDATED_BY", row.getUPDATED_BY());

                                                    getCatId = commonDAO.commonInsertGetReturn(Utility.epm_fee_category, insertCategoryData, logger, "ID");
                                                    categoryList.add(new CommonMDModel(getCatId, keyStr));
                                                }else {
                                                    getCatId = checkCategory.getID();
                                                    if(!updateFeeCategoryIds.contains(getCatId)){
                                                        updateFeeCategoryIds.add(getCatId);
                                                        Object[] categoryUpdateArray = {
                                                                insList.get(0).getNAME(),
                                                                row.getACADEMIC_YEAR_NAME(),
                                                                periodData.get(0).getID(),
                                                                periodData.get(0).getNAME(),
                                                                monthData.get(0).getID(),
                                                                monthData.get(0).getNAME(),
                                                                keyStr,
                                                                1,
                                                                new java.sql.Date(new java.util.Date().getTime()),
                                                                row.getUPDATED_BY_USERNAME(),
                                                                row.getUPDATED_BY(),
                                                                checkCategory.getID()
                                                        };
                                                        updateFeeCategoryList.add(categoryUpdateArray);
                                                    }
                                                }

                                                List<FeeDetailModel> feeDetailModels = Utility.getFeeDetailPeriodMonth(monthList,periodList,"yyyy-mm-dd",uploadedFileModel.getSTART_TIME_DT(),uploadedFileModel.getEND_TIME_DT(),categoryArray[0],categoryArray[1],categoryArray[2]);
                                                for (FeeDetailModel detail:feeDetailModels) {
                                                    if(checkStd == null){
                                                        Object[] feeInsertArray = {
                                                                insList.get(0).getID(),
                                                                insList.get(0).getNAME(),
                                                                row.getACADEMIC_YEAR_ID(),
                                                                row.getACADEMIC_YEAR_NAME(),
                                                                classData.get(0).getID(),
                                                                row.getCLASS(),
                                                                row.getSTUDENT_ID(),
                                                                row.getNAME(),
                                                                getCatId,
                                                                keyStr,
                                                                detail.getMONTH_ID(),
                                                                detail.getMONTH_NAME(),
                                                                detail.getAMOUNT(),
                                                                "0",
                                                                row.getISACTIVE(),
                                                                new java.sql.Date(new java.util.Date().getTime()),
                                                                row.getCREATED_BY(),
                                                                row.getCREATED_BY_USERNAME()
                                                        };
                                                        insertFeeList.add(feeInsertArray);
                                                    }else{
                                                        if(checkCategory == null){
                                                            Object[] feeInsertArray = {
                                                                    insList.get(0).getID(),
                                                                    insList.get(0).getNAME(),
                                                                    row.getACADEMIC_YEAR_ID(),
                                                                    row.getACADEMIC_YEAR_NAME(),
                                                                    classData.get(0).getID(),
                                                                    row.getCLASS(),
                                                                    row.getSTUDENT_ID(),
                                                                    row.getNAME(),
                                                                    getCatId,
                                                                    keyStr,
                                                                    detail.getMONTH_ID(),
                                                                    detail.getMONTH_NAME(),
                                                                    detail.getAMOUNT(),
                                                                    "0",
                                                                    row.getISACTIVE(),
                                                                    new java.sql.Date(new java.util.Date().getTime()),
                                                                    row.getCREATED_BY(),
                                                                    row.getCREATED_BY_USERNAME()
                                                            };
                                                            insertFeeList.add(feeInsertArray);
                                                        }else {
                                                            String feeCategoryId = getCatId;
                                                            CommonMDModel checkStdFee = stdFeeList.stream().filter(x-> x.getMONTH_ID().equals(detail.getMONTH_ID()) && x.getFEE_CATEGORY_ID().equals(feeCategoryId)).findFirst().orElse(null);
                                                            if(checkStdFee == null){
                                                                Object[] feeInsertArray = {
                                                                        insList.get(0).getID(),
                                                                        insList.get(0).getNAME(),
                                                                        row.getACADEMIC_YEAR_ID(),
                                                                        row.getACADEMIC_YEAR_NAME(),
                                                                        classData.get(0).getID(),
                                                                        row.getCLASS(),
                                                                        row.getSTUDENT_ID(),
                                                                        row.getNAME(),
                                                                        getCatId,
                                                                        keyStr,
                                                                        detail.getMONTH_ID(),
                                                                        detail.getMONTH_NAME(),
                                                                        detail.getAMOUNT(),
                                                                        "0",
                                                                        row.getISACTIVE(),
                                                                        new java.sql.Date(new java.util.Date().getTime()),
                                                                        row.getCREATED_BY(),
                                                                        row.getCREATED_BY_USERNAME()
                                                                };
                                                                insertFeeList.add(feeInsertArray);
                                                            }else{
                                                                Object[] feeUpdateArray = {
                                                                        insList.get(0).getNAME(),
                                                                        row.getACADEMIC_YEAR_NAME(),
                                                                        row.getCLASS(),
                                                                        row.getNAME(),
                                                                        detail.getMONTH_NAME(),
                                                                        detail.getAMOUNT(),
                                                                        row.getISACTIVE(),
                                                                        new java.sql.Date(new java.util.Date().getTime()),
                                                                        row.getUPDATED_BY_USERNAME(),
                                                                        row.getUPDATED_BY(),
                                                                        checkStdFee.getID()
                                                                };
                                                                updateFeeList.add(feeUpdateArray);
                                                            }
                                                        }
                                                    }
                                                }
                                            });
                                        }

                                        if (commonDAO.BatchInsertSQL(insertFeeList, queryInsertFee, logger)) {
                                            successCount++;
                                            fResn = "Success";
                                            fStatus = "Success";
                                        }else{
                                            fResn = "Failed";
                                            fStatus = "Fee insert failed. Please try again.";
                                        }

                                        if (commonDAO.BatchInsertSQL(updateFeeList, queryUpdateFee, logger)) {
                                            successCount++;
                                            fResn = "Success";
                                            fStatus = "Success";
                                        }else{
                                            fResn = "Failed";
                                            fStatus = "Fee update failed. Please try again.";
                                        }

                                        stdFeeList.clear();
                                        insertFeeList.clear();
                                        updateFeeList.clear();
                                    }catch (Exception ex){
                                        fStatus = "Failed";
                                        fResn = "Student fee processing failed: " + ex.getMessage();
                                    }

                                }else{
                                    fResn = "Class not found";
                                }
                            }else {
                                fResn = "Institute wallet/code mismatched";
                            }

                        } else {
                            fResn = "Institute mapping failed";
                        }
                    } catch (Exception e) {
                        fStatus = "Failed";
                        fResn = "Server error: " + e.getMessage();
                    }

                    String TMPSQL = "UPDATE " + Utility.epm_bulkprocess_file_details + " SET FINAL_STATUS = '" + fStatus + "', Failed_REASON = '" + fResn + "' WHERE ID = '" + row.getID() + "'";
                    commonDAO.CommoUpdate(TMPSQL, logger);

                    Object[] ApiArray = {
                            row.getBULK_FILE_ID(),
                            row.getFILE_DATA(),
                            row.getFILE_ROW_NUM(),
                            row.getCONNECTION_TYPE(),
                            "", "", "",
                            row.getREGISTRATION_ID(),
                            row.getFILE_DATA(),
                            uploadedFileModel.getPROCESS_TYPE_ID(), fResn, fStatus, ""
                    };
                    ApiResponseList.add(ApiArray);

                    if (++count % batchSize == 0) {
                        if (commonDAO.BatchInsertSQL(ApiResponseList, queryInsertBulkApiResponse, logger)) {
                            ApiResponseList = new ArrayList<Object[]>();
                        }
                    }
                }

                try {
                    commonDAO.BatchInsertSQL(updateFeeCategoryList, queryUpdateCategory, logger); //TODO
                    commonDAO.BatchInsertSQL(ApiResponseList, queryInsertBulkApiResponse, logger);
                } catch (Exception e) {
                    e.printStackTrace();
                    logger.error(e.getMessage(), e);
                }
                try {
                    UpdateFileTBL(Integer.parseInt(uploadedFileModel.getTOTAL_ROWS()), "3", "COMPLETED", successCount, uploadedFileModel.getID());
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
                logger.info("Student File Import Done");
            } else {
                UpdateFileTBL(Integer.parseInt(uploadedFileModel.getTOTAL_ROWS()), "4", "Failed", 0, uploadedFileModel.getID());
            }
        } catch (Exception ex) {
            UpdateFileTBL(Integer.parseInt(uploadedFileModel.getTOTAL_ROWS()), "4", "Failed", 0, uploadedFileModel.getID());
            logger.error(ex.getMessage(), ex);
        }
    }

    public void UpdateFileTBL(int dataSize, String action, String Status, int scsCount, String ID) {
        try {
            int flCount = dataSize - scsCount;
            String BFSQL = "UPDATE " + Utility.epm_bulkprocess_files + " SET ACTIVE = '" + action + "', PROCESS_STATUS = '" + Status + "', SUCCESS_ROWS = '" + scsCount + "', Failed_ROWS='" + flCount + "' WHERE ID = '" + ID + "'";
            commonDAO.CommoUpdate(BFSQL, logger);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }
}
