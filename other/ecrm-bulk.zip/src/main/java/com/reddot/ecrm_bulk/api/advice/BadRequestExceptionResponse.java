package com.reddot.ecrm_bulk.api.advice;

import lombok.Data;

import java.util.Date;
import java.util.Map;

@Data
public class BadRequestExceptionResponse {
    private Integer code;
    private String message;
    private Map<String, String> errors;
    private Date timestamp;
}
