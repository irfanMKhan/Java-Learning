package com.reddot.ecrm_bulk.entity.contract;


import com.reddot.ecrm_bulk.entity.AbstractEntity;
import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "TBL_ECRM_CONTRACT")
@Data
public class Contract extends AbstractEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "id_generator_contract")
    @SequenceGenerator(name = "id_generator_contract", initialValue = 1, allocationSize = 1)
    private Long id;

    private String contractType;
    private Boolean isParentContract;
    private Boolean isAmendedContract;
    private Long parentContractId;
    private Long accountDetailsId;
    private Boolean isParentAccountInformation;
    @Column(name = "CONTRACT_NUMBER", unique = true)
    private String contractNumber;

    @Column(name = "CUSTOMER_NAME")
    private String customerName;
    private Long companyId;
    @Column(name = "PRODUCT_OF_INTEREST")
    private String productOfInterest;

    @Column(name = "KAM")
    private String kam;
    private Long kamId;

    @Column(name = "assign_person")
    private String assignPerson;

    @Column(name = "STATUS")
    private String status;

    private String saveType;

    private String uuidToken;
    private String opportunityNumber;
    private Long tenantId;

    private Boolean isCRContract;
    private Boolean isConvertedToContract;
    private Boolean isIndividual;
}
