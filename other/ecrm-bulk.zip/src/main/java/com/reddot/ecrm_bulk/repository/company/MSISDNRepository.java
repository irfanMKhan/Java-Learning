package com.reddot.ecrm_bulk.repository.company;

import com.reddot.ecrm_bulk.entity.annex.Annex;
import com.reddot.ecrm_bulk.entity.msisdn.MSISDN;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import java.util.List;

@Repository
public class MSISDNRepository {
    @PersistenceContext
    private EntityManager entityManager;

    public MSISDN findByMSISDN(String msisdn) {
        TypedQuery<MSISDN> query = entityManager.createQuery(
                "SELECT m FROM MSISDN m WHERE m.msisdn = :msisdn",
                MSISDN.class);
        return query
                .setParameter("msisdn", msisdn)
                .getSingleResult();
    }

    public List<MSISDN> findAllByMSISDN(String msisdn) {
        TypedQuery<MSISDN> query = entityManager.createQuery(
                "SELECT m FROM MSISDN m WHERE m.msisdn = :msisdn",
                MSISDN.class);
        return query
                .setParameter("msisdn", msisdn)
                .getResultList();
    }

    @Transactional
    public MSISDN save(MSISDN msisdn) {
        entityManager.persist(msisdn);
        return msisdn;
    }

    @Transactional
    public MSISDN update(MSISDN msisdn) {
        entityManager.merge(msisdn);
        return msisdn;
    }
}
