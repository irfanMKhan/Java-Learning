package com.reddot.ecrm_bulk.api.payload.subscriber;

import lombok.Data;

import java.io.Serializable;
@Data
public class ChangeSubscriberMSISDNRequest implements Serializable{
    private String transaction_id;

    private ChangeSubMSISDNReqMsg ChangeSubMSISDNReqMsg;

    @Data
    public static class ChangeSubMSISDNReqMsg implements Serializable {
        private String NewServiceNum;
    }
}
