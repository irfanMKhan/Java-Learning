package com.reddot.ecrm_bulk.service.change_branch;

import com.google.gson.Gson;
import com.reddot.ecrm_bulk.api.payload.group.ChangeCorporateGroupMemberInfoResponse;
import com.reddot.ecrm_bulk.entity.cr.CRMasterEntity;
import com.reddot.ecrm_bulk.entity.cr.CRMsisdnDetailsEntity;
import com.reddot.ecrm_bulk.entity.msisdn.MSISDN;
import com.reddot.ecrm_bulk.enums.cr.CRStatusEnum;
import com.reddot.ecrm_bulk.enums.requestType.CommonStatusEnum;
import com.reddot.ecrm_bulk.repository.company.MSISDNRepository;
import com.reddot.ecrm_bulk.service.company.CompanyAccountService;
import com.reddot.ecrm_bulk.service.contract.ContractService;
import com.reddot.ecrm_bulk.service.cr.CRMasterService;
import com.reddot.ecrm_bulk.service.cr.CRMsisdnDetailsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class CRBranchService {
    private final ContractService contractService;
    private final CompanyAccountService companyAccountService;
    private final CRMsisdnDetailsService crMsisdnDetailsService;
    private final Gson gson;
    private final MSISDNRepository msisdnRepository;
    private final CRMasterService crMasterService;

    public void executeChangeBranch(String customerId, CRMasterEntity crMasterEntity, CRMsisdnDetailsEntity crMsisdnDetailsEntity) {
        String remarks = "";
        String crStatus = CRStatusEnum.Processing.toString();

        try {
           String groupId = companyAccountService.findParentCorporateGroupIdByCorporateGroupCode(crMsisdnDetailsEntity.getNewBranchCode());

           if (ObjectUtils.isEmpty(customerId)) {
               crMsisdnDetailsService.updateMsisdnDetailsRemarksAndFailedStatus(crMsisdnDetailsEntity, "Customer Id Is Empty: " + customerId);
           }

           if (ObjectUtils.isEmpty(groupId)) {
               crMsisdnDetailsService.updateMsisdnDetailsRemarksAndFailedStatus(crMsisdnDetailsEntity, "Group Id Is Empty with Branch Code: " + crMsisdnDetailsEntity.getNewBranchCode());
           }

           ChangeCorporateGroupMemberInfoResponse response = contractService.changeCorporateGroupMemberInfo(customerId, groupId, crMsisdnDetailsEntity.getMsisdn(), crMsisdnDetailsEntity.getNewValue(), crMsisdnDetailsEntity.getNewBranchCode());

           if (!ObjectUtils.isEmpty(response.getChangeCorporateGroupMemberInfoRspMsg().getRspHeader().getReturnCode())) {
               String returnCode = response.getChangeCorporateGroupMemberInfoRspMsg().getRspHeader().getReturnCode();
               String returnMsg = response.getChangeCorporateGroupMemberInfoRspMsg().getRspHeader().getReturnMsg();
               remarks = returnMsg;
               switch (returnCode) {
                   case "0000":
                       MSISDN msisdn = msisdnRepository.findByMSISDN(crMsisdnDetailsEntity.getMsisdn());
                       if (!ObjectUtils.isEmpty(msisdn)) {
                           crStatus = CRStatusEnum.Success.toString();
                           msisdn.setBranchAccountId(crMsisdnDetailsEntity.getNewPrimaryId());
                           msisdnRepository.update(msisdn);
                           log.info("Branch changed in DB successfully for MSISDN: {}", crMsisdnDetailsEntity.getMsisdn());
                       } else {
                           crStatus = CRStatusEnum.Failed.toString();
                       }
                       break;
                   case "1211002195":
                   case "1211000433":
                       crStatus = CRStatusEnum.Failed.toString();
                       break;
               }
           }

           crMsisdnDetailsEntity.setResponseDetails(gson.toJson(response));
           crMsisdnDetailsEntity.setStatus(crStatus);
           crMsisdnDetailsEntity.setRemarks(remarks);
       } catch (Exception e) {
           crMsisdnDetailsEntity.setStatus(CommonStatusEnum.Failed.name());
           crMsisdnDetailsEntity.setResponseDetails(e.getMessage());
           crMsisdnDetailsEntity.setRemarks(remarks);
       } finally {
            updateCompletedStatus(crMasterEntity);
            crMsisdnDetailsService.update(crMsisdnDetailsEntity);
       }
    }

    public void updateCompletedStatus(CRMasterEntity crMasterEntity) {
        CRMasterEntity crMaster = crMasterService.findById(crMasterEntity.getId());
        if (!ObjectUtils.isEmpty(crMaster)) {
            if (!crMaster.getFinalStatus().equalsIgnoreCase(CRStatusEnum.Completed.name())) {
                crMaster.setFinalStatus(CRStatusEnum.Completed.name());
                crMasterService.update(crMaster);
            }
        } else {
            log.debug("UpdateCompletedStatus CRMaster Not Found Entity: {}", crMasterEntity);
        }
    }

    public void updateCRMasterStatus(CRMasterEntity crMasterEntity, CRStatusEnum status) {
        CRMasterEntity crMaster = crMasterService.findById(crMasterEntity.getId());
        if (!ObjectUtils.isEmpty(crMaster)) {
            crMaster.setFinalStatus(status.name());
            crMasterService.update(crMaster);
        } else {
            log.debug("UpdateCRMasterStatus CRMaster Not Found with Entity: {}", crMasterEntity);
        }
    }

//    public void updateBulkFileCompleteStatus(CRMasterEntity crMaster) {
//        List<CRMsisdnDetailsEntity> crMsisdnDetailsList = crMsisdnDetailsService.findAllCRMsisdnDetailsByCRMasterId(crMaster.getId());
//        List<CRMsisdnDetailsEntity> crMsisdnDetailsSuccessList = crMsisdnDetailsService.findAllCRMsisdnDetailsByCRMasterIdWithSuccessStatus(crMaster.getId());
//
//        if (crMsisdnDetailsSuccessList.size() > 0 && crMsisdnDetailsList.size() > 0 && crMsisdnDetailsList.size() == crMsisdnDetailsSuccessList.size()) {
//            crMaster.setFinalStatus(CRStatusEnum.Success.name());
//            crMasterService.update(crMaster);
//        }
//    }
}
