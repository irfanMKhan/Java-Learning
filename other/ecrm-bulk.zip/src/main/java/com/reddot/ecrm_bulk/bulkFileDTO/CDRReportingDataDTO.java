package com.reddot.ecrm_bulk.bulkFileDTO;

import com.reddot.ecrm_bulk.api.payload.CDR.response.CDRAPIResponseDataDTO;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CDRReportingDataDTO {
    private String fromDate;
    private String toDate;
    private String printDate;
    private String fileType;
    private String usageType;
    private String fileName;
    private String token;
    private String accountNumber;
    private String address;
    private String image;
    private Long detailTableId;
    private List<CDRAPIResponseDataDTO> dataList;

}