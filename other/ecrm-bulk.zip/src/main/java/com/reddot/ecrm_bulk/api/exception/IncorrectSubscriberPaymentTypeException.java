package com.reddot.ecrm_bulk.api.exception;

public class IncorrectSubscriberPaymentTypeException extends RuntimeException {
    public IncorrectSubscriberPaymentTypeException(String message) {
        super(message);
    }

    public IncorrectSubscriberPaymentTypeException(String message, Throwable throwable) {
        super(message, throwable);
    }
}
