package com.reddot.ecrm_bulk.service.report;

import com.reddot.ecrm_bulk.enums.role.UserRole;
import com.reddot.ecrm_bulk.model.LeadModel;
import com.reddot.ecrm_bulk.pool_repository.CommonRepository;
import com.reddot.ecrm_bulk.service.notification.email.EmailSenderService;
import com.reddot.ecrm_bulk.service.notification.email.ThymleafService;
import freemarker.template.TemplateException;
import lombok.RequiredArgsConstructor;
import org.apache.commons.codec.CharEncoding;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedCaseInsensitiveMap;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.*;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ReportService {
    private final Logger logger = LoggerFactory.getLogger(getClass().getName());

    private final EmailSenderService emailSenderService;
    private final ThymleafService thymeleafService;
    private final CommonRepository commonRepository;
    private final JavaMailSender sender;
    @Value("${spring.mail.from}")
    private String emailFromAddress;
    @Value("${file.directory}")
    String fileLocation;

    public void pendingLeadReportProcess() throws IOException, TemplateException {
        logger.info("--pendingLeadReportProcess Started--");
        LocalDate todayDateInLocal = LocalDate.now();
        LocalDate backDaysInLocal = todayDateInLocal.minus(15, ChronoUnit.DAYS);
        Timestamp toDate = Timestamp.valueOf(todayDateInLocal.atStartOfDay());
        Timestamp fromDate = Timestamp.valueOf(backDaysInLocal.atStartOfDay());

        // Print the timestamp
        System.out.println("toDate Timestamp: " + toDate);
        System.out.println("fromDate Timestamp: " + fromDate);
        Boolean created = createDirectoryIfNotExist(fileLocation);
        if (created) {
            try {
                List<LeadModel> leadModels = CompletableFuture.supplyAsync(() -> fetchPendingLeadData(fromDate, toDate)).get();//fetchPendingLeadData(fromDate, toDate);
                processLeadModelData(leadModels, todayDateInLocal, backDaysInLocal);

            } catch (Exception ex) {
                logger.error(ex.getMessage());
            }
        } else {
            logger.info("Can't create file directory ");
        }
    }

    public void followUpLeadReportProcess(){
        logger.info("--followUpLeadReportProcess Started--");
        try{
            List<LinkedCaseInsensitiveMap<String>> list = CompletableFuture.supplyAsync(this::processFollowUpLeadList).get();
            if(!list.isEmpty()){
                logger.info("Lead found!");
                Map<String, List<Object>> result = new HashMap<>();

                list.forEach(item->{
                    result.computeIfAbsent(item.get("email"), k-> new ArrayList<>()).add(item);
                });

                result.keySet().forEach(item->{
                    Map<String, Object> model = new HashMap<>();
                    System.err.println(result.get(item).get(0));
                    model.put("kam_name", item);
                    model.put("items", result.get(item));
                    MimeMessage mimeMessage = sender.createMimeMessage();
                    MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, CharEncoding.UTF_8);

                    try{
                        logger.info("sending email");
                        helper.setTo(item);
                        helper.setSubject("Lead Follow-up for today!");
                        helper.setText(thymeleafService.createContent("LeadFollowUp.html", model), true);
                        helper.setFrom(emailFromAddress);
                        sender.send(mimeMessage);
                    }
                    catch (Exception e){
                        logger.error(e.getMessage());
                    }
                });

            }
            else{
                logger.info("No lead needs follow-up on "+ new Date());
            }
        }
        catch (Exception ex) {
            logger.error(ex.getMessage());
        }
    }

    private List<LinkedCaseInsensitiveMap<String>> processFollowUpLeadList(){
        String leadListSQL = "select u.name, u.email, l.kam_name, l.kam_id, l.follow_up_dt, l.lead_number, l.status_name from tbl_lead l join md_user u on u.name=l.kam_name where follow_up_dt = now()::date::timestamp and status_name not in ('Converted', 'Lost') order by kam_id;";
        Object data = commonRepository.CommoGetData(leadListSQL);
        return (List<LinkedCaseInsensitiveMap<String>>) data;
    }

    private void processLeadModelData(List<LeadModel> leadModels, LocalDate todayDateInLocal, LocalDate backDaysInLocal) throws MessagingException, UnsupportedEncodingException, ExecutionException, InterruptedException {

        try {

            String kamEmail = "";
            String kamName = "";

            List<Map<String, Object>> mapList = new ArrayList<>();
            if (!leadModels.isEmpty()) {
                Map<Integer, List<LeadModel>> groupByKamLeads = leadModels.stream().collect(Collectors.groupingBy(LeadModel::getkam_id));

                List<List<LeadModel>> groupedLeadLists = new ArrayList<>(groupByKamLeads.values());

                for (List<LeadModel> leadModelList : groupedLeadLists) {

                    for (LeadModel leadModelTable : leadModelList) {
                        HashMap<String, Object> hashMap = new HashMap<>();
                        hashMap.put("lead_number", leadModelTable.getlead_number());
                        hashMap.put("customer_name", leadModelTable.getcustomer_name());
                        hashMap.put("kam_name", leadModelTable.getkam_name());
                        hashMap.put("created_at_dt", leadModelTable.getcreated_at_dt());
                        hashMap.put("status_name", leadModelTable.getstatus_name());
                        mapList.add(hashMap);
                        kamEmail = leadModelTable.getkam_email();
                        kamName = leadModelTable.getkam_name();
                    }
                    String kemail = kamEmail;
                    String kname = kamName;
                    generateReportAndProcessMail(mapList, todayDateInLocal, backDaysInLocal, kname, kemail);
                    //BackgroundJob.enqueue(() -> generateReportAndProcessMail(mapList, todayDateInLocal, backDaysInLocal, kname, kemail));

                }
                logger.info("Process complete");

            } else {
                logger.info("Data list is empty");
            }
        } catch (Exception e) {
            logger.error("Error in processLeadModelData: ", e.getMessage());

        }
    }

    private Map<String, Object> fetchEmailBodyParam(LocalDate todayDateInLocal, LocalDate backDaysInLocal, String kamName) {
        Map<String, Object> model = new HashMap<>();
        model.put("reportDate", todayDateInLocal);
        model.put("fromDate", backDaysInLocal);
        model.put("toDate", todayDateInLocal);
        model.put("receiverName", kamName);
        return model;
    }

    private List<LeadModel> fetchPendingLeadData(Timestamp fromDate, Timestamp toDate) {
        List<LeadModel> leadModels = new ArrayList<>();

        try {
            //for test date is hard coded please check
            /*String sql = "select tl.id,tl.lead_number  ,tl.customer_name ,tl.kam_id ,tl.kam_name ,tl.status_name ," +
                    "tl.created_at_dt ,mu.email  as kam_email from ecrm.tbl_lead tl \n" +
                    "left join ecrm.md_user mu on mu.id =tl.kam_id \n" + "where tl.status_name='Open'\n" +
                    "and ( tl.created_at_dt >='2023-01-26 00:00:00.000' and tl.created_at_dt <='2023-09-26 00:00:00.000' )  \n" +
                    " and tl.is_test=true " + //for test purpose
                    "order by tl.kam_id ";*/

            String sql = "select tl.id,tl.lead_number  ,tl.customer_name ,tl.kam_id ,tl.kam_name ,tl.status_name ," +
                    "tl.created_at_dt ,mu.email  as kam_email from ecrm.tbl_lead tl \n" +
                    "left join ecrm.md_user mu on mu.id =tl.kam_id \n" + "where tl.status_name='Open'\n" +
                    "and ( tl.created_at_dt >='"+fromDate+"' and tl.created_at_dt <='"+toDate+"' )  \n" +
                    " and tl.is_test=true " + //for test purpose
                    "order by tl.kam_id ";
            Object data = commonRepository.CommoGetData(sql);
            List<?> list = (List<?>) data;

            for (Object item : list) {
                if (item instanceof Map) {
                    Map<?, ?> map = (Map<?, ?>) item;
                    LeadModel leadModel = new LeadModel();
                    leadModel.setid((Long) map.get("id"));
                    leadModel.setkam_id(Integer.parseInt(String.valueOf(map.get("kam_id"))));

                    leadModel.setcustomer_name((String) map.get("customer_name"));
                    leadModel.setkam_email((String) map.get("kam_email"));
                    leadModel.setcreated_at_dt((Timestamp) map.get("created_at_dt"));
                    leadModel.setkam_name((String) map.get("kam_name"));
                    leadModel.setlead_number((String) map.get("lead_number"));
                    leadModel.setstatus_name((String) map.get("status_name"));

                    leadModels.add(leadModel);
                } else {
                    logger.info("No Lead data found to process ");
                }

            }
        } catch (Exception ex) {
            logger.error("Error in fetchPendingLeadData: " + ex.getMessage(), ex);
        }
        return leadModels;
    }

    private String generateLeadReportExcel(List<Map<String, Object>> mapList) {
        try {

            String filename = "Pending Lead Report" + ".xlsx";
            String[] columnTitles = {"Lead No.", "Customer Name", "KAM", "Creation Date", "Status"};
            String[] headers = {"lead_number", "customer_name", "kam_name", "created_at_dt", "status_name"};

            OutputStream fileOut = new FileOutputStream(new File(fileLocation + '/' + filename));
            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("Lead Report Sheet");

            Row row = sheet.createRow(0);
            CellStyle headerCellStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerFont.setColor(IndexedColors.WHITE.index);
            headerCellStyle.setFont(headerFont);
            DataFormat dataFormat = workbook.createDataFormat();
            headerCellStyle.setDataFormat(dataFormat.getFormat("@"));

            headerCellStyle.setFillForegroundColor(IndexedColors.GREY_80_PERCENT.index);
            headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            getBorderStyle(headerCellStyle);

            for (int i = 0; i < columnTitles.length; i++) {
                Cell cell = row.createCell(i);
                cell.setCellValue(columnTitles[i]);
                cell.setCellStyle(headerCellStyle);
                sheet.autoSizeColumn(i);
            }

            CellStyle childCellStyle = workbook.createCellStyle();
            childCellStyle.setDataFormat(dataFormat.getFormat("@"));
            getBorderStyle(childCellStyle);

            for (int i = 0; i < mapList.size(); i++) {
                Row cellRow = sheet.createRow(i + 1);

                for (int j = 0; j < columnTitles.length; j++) {
                    Cell cell = cellRow.createCell(j);
                    Object cellValue = mapList.get(i).get(headers[j]);
                    if (cellValue != null && !cellValue.toString().isEmpty()) {
                        cell.setCellValue(mapList.get(i).get(headers[j]).toString());
                    }

                    cell.setCellStyle(childCellStyle);
                    sheet.autoSizeColumn(j);
                }
            }

            workbook.write(fileOut);
            logger.info("Write successfully!");
            return filename;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
        return "";
    }

    private void getBorderStyle(CellStyle cellStyle) {
        cellStyle.setBorderTop(BorderStyle.THIN);
        cellStyle.setBorderBottom(BorderStyle.THIN);
        cellStyle.setBorderLeft(BorderStyle.THIN);
        cellStyle.setBorderRight(BorderStyle.THIN);
    }

    private List<String> fetchHeadOrEsManagerEmail(String roleName) {
        List<String> email = new ArrayList<>();
        try {
            String sql = "select mu.email  from ecrm.md_role mr   \n" + "left join ecrm.md_user_role mur  on mur.role_id =mr.id \n" + "left join ecrm.md_user mu on mu.id =mur.user_id  \n" + "where mr.name ='" + roleName + "'";

            Object data = commonRepository.CommoGetData(sql);
            List<?> list = (List<?>) data;
            for (Object item : list) {
                if (item instanceof Map) {
                    Map<?, ?> map = (Map<?, ?>) item;
                    email.add((String) map.get("email"));
                }
            }
        } catch (Exception ex) {
            logger.error("Error fetching role data: " + ex.getMessage(), ex);
        }
        return email;
    }

    public void generateReportAndProcessMail(List<Map<String, Object>> mapList, LocalDate todayDateInLocal, LocalDate backDaysInLocal, String kamName, String kamEmail) {
        try {
            List<String> headEmail = new ArrayList<>();
            List<String> esManagerEmail = new ArrayList<>();
            Boolean mailSent;
            String filename = CompletableFuture.supplyAsync(() -> generateLeadReportExcel(mapList)).get();
            File file = new File(fileLocation + '/' + filename);
            logger.info("file generated location: ", file);

            Map<String, Object> model = fetchEmailBodyParam(todayDateInLocal, backDaysInLocal, kamName);
            String subject = "Pending Lead Report for " + todayDateInLocal;
            String body = thymeleafService.createContent("LeadReport.html", model);
            headEmail = fetchHeadOrEsManagerEmail(UserRole.HEAD_OF_ES.getDescription());
            esManagerEmail = fetchHeadOrEsManagerEmail(UserRole.ES_MANAGER.getDescription());
            List<String> emailList = new ArrayList<>();
            emailList.addAll(headEmail);
            emailList.addAll(esManagerEmail);
            //emailList.add("sajibcse42@gmail.com");//added for test
            //emailSenderService.sendEmailwithAttachmentForMultipleRecipient(kamEmail, body, subject, file, emailList);
            CompletableFuture.supplyAsync(() -> {
                try {
                    return emailSenderService.sendEmailwithAttachmentForMultipleRecipient(kamEmail, body, subject, file, emailList);
                } catch (MessagingException e) {
                    logger.error("Error in generateReportAndProcessMail: " + e.getMessage());
                    throw new RuntimeException(e);
                }
            }).get();
            logger.info("Mail Sent to Head,Es Manager and KAM ");

            file.delete();
        } catch (Exception ex) {
            logger.error("Error in generateReportAndProcessMail: " + ex.getMessage(), ex);

        }

    }

    public boolean createDirectoryIfNotExist(String path) {
        File directory = new File(path);

        if (!directory.exists()) {
            boolean created = directory.mkdirs();

            if (created) {
                System.out.println("Directory created successfully.");
                return true;
            } else {
                System.out.println("Failed to create the directory.");
                return false;
            }
        } else {
            System.out.println("Directory already exists.");
            return true;
        }

    }

}
