package com.reddot.ecrm_bulk.service.offering;

import com.reddot.ecrm_bulk.entity.primary_offering.PrimaryOffering;

public interface PrimaryOfferingService {
    PrimaryOffering findByOfferingId(Long offeringId);
}
