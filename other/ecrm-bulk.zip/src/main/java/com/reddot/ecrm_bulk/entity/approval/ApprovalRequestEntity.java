package com.reddot.ecrm_bulk.entity.approval;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "approval_request")
public class ApprovalRequestEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "approval_flow_id")
    private Long approvalFlowId;
    @Column(name = "approval_flow_name")
    private String approvalFlowName;
    @Column(name = "requested_amount")
    private Double requestedAmount;
    private Boolean hasRequestedAmount;  //amount

    private Boolean isCategoryType;  //category
    private String categoryValue;

    private Integer requestedNumberTypeData;  //days,month,percentage,number
    private String unitType;

    private String companyName;

    private String contractNumber;
    private String opportunityNumber;
    private String transactionNumber;
    private Long tenantId;
    private Long requestDetailsId;
    private String requestDescription;
    private String approvalFor;

//    @Column(columnDefinition = "text")
//    private String upfrontFee;

    @Column(name = "requested_at")
    private Long requestedAt;
    @Column(name = "requested_at_dt")
    private LocalDate requestedAtDt;
    @Column(name = "requested_by")
    private Long requestedBy;
    @Column(name = "requested_username")
    private String requestedUsername;

    @Column(name = "status")
    private String status;
    @Column(name = "uuid_token")
    private String uuidToken;
    //for one contract multiple approval has common transaction so that can find them
    //otherwise create a gap for that.
    private String requestTransactionId;
}
