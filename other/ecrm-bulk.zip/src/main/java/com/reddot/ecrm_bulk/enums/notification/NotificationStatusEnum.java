package com.reddot.ecrm_bulk.enums.notification;

public enum NotificationStatusEnum {
    TODO,
    Sent,
    Failed
}
