package com.reddot.ecrm_bulk.service.bulk;

import com.reddot.ecrm_bulk.entity.bulk.BulkFileDetails;
import com.reddot.ecrm_bulk.enums.status.Status;

import java.util.List;

public interface BulkFileDetailsService {
    List<BulkFileDetails> bulkSave(List<BulkFileDetails> entities);

    List<BulkFileDetails> findAllByBulkFileId(Long bulkFileId);

    List<BulkFileDetails> findByBulkFileIdAndStatus(Long bulkFileId, Status status);

    BulkFileDetails update(BulkFileDetails bulkFileDetails);
}
