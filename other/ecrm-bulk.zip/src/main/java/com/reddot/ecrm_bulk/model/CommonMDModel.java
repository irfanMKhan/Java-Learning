package com.reddot.ecrm_bulk.model;

public class CommonMDModel {

    private String ID;
    private String NAME;
    private String CODE;
    private String WALLET;
    private String MONTH_NO;
    private String MONTH_INTERVAL;
    private String REGISTRATION_ID;
    private String FEE_CATEGORY_ID;
    private String MONTH_ID;

    public CommonMDModel(String ID, String NAME) {
        this.ID = ID;
        this.NAME = NAME;
    }

    public CommonMDModel(String ID, String NAME, String REGISTRATION_ID) {
        this.ID = ID;
        this.NAME = NAME;
        this.REGISTRATION_ID = REGISTRATION_ID;
    }

    public String getFEE_CATEGORY_ID() {
        return FEE_CATEGORY_ID;
    }

    public void setFEE_CATEGORY_ID(String FEE_CATEGORY_ID) {
        this.FEE_CATEGORY_ID = FEE_CATEGORY_ID;
    }

    public String getMONTH_ID() {
        return MONTH_ID;
    }

    public void setMONTH_ID(String MONTH_ID) {
        this.MONTH_ID = MONTH_ID;
    }

    public String getREGISTRATION_ID() {
        return REGISTRATION_ID;
    }

    public void setREGISTRATION_ID(String REGISTRATION_ID) {
        this.REGISTRATION_ID = REGISTRATION_ID;
    }

    public String getMONTH_INTERVAL() {
        return MONTH_INTERVAL;
    }

    public void setMONTH_INTERVAL(String MONTH_INTERVAL) {
        this.MONTH_INTERVAL = MONTH_INTERVAL;
    }

    public String getMONTH_NO() {
        return MONTH_NO;
    }

    public void setMONTH_NO(String MONTH_NO) {
        this.MONTH_NO = MONTH_NO;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getNAME() {
        return NAME;
    }

    public void setNAME(String NAME) {
        this.NAME = NAME;
    }

    public String getCODE() {
        return CODE;
    }

    public void setCODE(String CODE) {
        this.CODE = CODE;
    }

    public String getWALLET() {
        return WALLET;
    }

    public void setWALLET(String WALLET) {
        this.WALLET = WALLET;
    }
}
