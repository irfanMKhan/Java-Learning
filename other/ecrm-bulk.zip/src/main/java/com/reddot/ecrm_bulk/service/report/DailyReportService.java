package com.reddot.ecrm_bulk.service.report;

import  com.reddot.ecrm_bulk.pool_repository.CommonRepository;
import com.reddot.ecrm_bulk.service.SRManagerService;
import com.reddot.ecrm_bulk.service.notification.email.EmailSenderService;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

@Service
public class DailyReportService {
    @Autowired
    CommonRepository commonDAO;
    private final Logger logger = LoggerFactory.getLogger(getClass().getName());
    @Autowired
    EmailSenderService emailSenderService;
    @Autowired
    private FreeMarkerConfigurer freemarkerConfigurer;

    @Autowired
    SRManagerService srManagerService;

    @Value("${daily.sr.report.receiver}")
    private  String  receiver;

    @Value("${daily.sr.report.receiver_cc}")
    private  String  receiverCC;

    public void PushDailySRReport() throws IOException, TemplateException {

        Calendar cal = Calendar.getInstance();
        DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
        cal.add(Calendar.DATE, -1);

        Map<String, Object> templateModel = new HashMap<>();
        templateModel.put("userFullName", "Concern");
        templateModel.put("date", dateFormat.format(cal.getTime()));
        Configuration cfg = new Configuration();
        cfg.setClassForTemplateLoading(this.getClass(), "/templates/");
        Template freemarkerTemplate = cfg.getTemplate("dailySRReport.ftl");
        String htmlBody = FreeMarkerTemplateUtils.processTemplateIntoString(freemarkerTemplate, templateModel);
        //Generate File and Save
       String filename= srManagerService.SRMailPUsh();

       try {
           if (!filename.isEmpty())
           {
               File file= new File(filename);
               emailSenderService.sendEmailwithAttachment(receiver, htmlBody, "Daily DnD SR Report",file, receiverCC);
           }
       }catch (Exception ex){
           logger.error(ex.getMessage());
       }


    }
}
